 
import React from "react";
import { Routes, Route } from "react-router-dom";
import AppRoutes from "./AppRoutes";
import MasterLayout from "./layouts/MasterLayout";
import ProtectedRoute from "./ProtectedRoute"; 

  // Separate layout routes vs. non-layout routes
  const layoutRoutes = AppRoutes.filter(
    (r) => !["/Login", "/ForgotPassword", "/unauthorized"].includes(r.path)
  );

  const noLayoutRoutes = AppRoutes.filter((r) =>
    ["/Login", "/ForgotPassword" , "/unauthorized"].includes(r.path)
  );

export default function App() {
    return (
   
      <Routes>
        {/* Routes with master layout */}
        <Route
          element={
            <ProtectedRoute>
              <MasterLayout />
            </ProtectedRoute>
          }
        >
          {layoutRoutes.map((route, index) => (
            <Route key={index} path={route.path} element={route.element} />
          ))}
        </Route>

        {/* Routes without layout (like Login/ForgotPassword) */}
        {noLayoutRoutes.map((route, index) => (
          <Route key={index} path={route.path} element={route.element} />
        ))}
      </Routes>
    
  );
}

 