import Home from "./pages/HomePage";
import Login from "./pages/Login";
import ForgotPassword from "./pages/ForgotPassword";

import FileConfiguration from "./pages/FileConfiguration";
import BranchTerminalRegistration from "./pages/BranchTerminalRegistration";
import CurrencyRegistrationPage from "./pages/CurrencyRegistrationPage";

import FieldIdentificationConfig from "./pages/FieldIdentificationConfig";
import ImportFile from "./pages/ImportFilePage";

//Daily
import ReconTxnsReport from "./pages/dailyReports/ReconReportPage";
import SuccessfulAmountCountReportPage from "./pages/dailyReports/SuccessfulAmountCountReportPage";
import CashTallyReportPage from "./pages/dailyReports/CashTallyReportPage";
import GenerateReportPage from "./pages/dailyReports/GenerateReportPage";
import ReportCheckerPage from "./pages/dailyReports/ReportCheckerPage";
import ViewReportPage from "./pages/dailyReports/ViewReportPage";
import PosDmsTxnsReportPage from "./pages/dailyReports/PosDmsReportPage";

// MIS
import DispenseSummaryReport from "./pages/misReports/DispenseSummaryReport";
import TxnsCountSummaryReport from "./pages/misReports/TxnsCountSummaryReport";
import ReasonWiseSummaryReportPage from "./pages/misReports/ReasonWiseSummaryReportPage";
import ATMTtumReportPage from "./pages/misReports/ATMTtumReportPage";
import POSTtumReportPage from "./pages/misReports/POSTtumReportPage";
import PendingAcqEntryReportPage from "./pages/misReports/PendingAcqEntryReportPage";
import TipsAndSurchargePage from "./pages/misReports/TipsAndSurchargePage";
import IssuerTransactionTTUMReportPage from "./pages/misReports/IssuerTransactionTTUMReportPage";
import RefundCashbackTTUMReportPage from "./pages/misReports/RefundCashbackTTUMReportPage";
import IMPSTTUMReportPage from "./pages/misReports/IMPSTTUMReportPage";
import TtumTransactionReportPage from "./pages/misReports/TtumTransactionReportPage";
import TimeoutTransactionReportPage from "./pages/misReports/TimeoutTransactionReportPage";
import DrcTransactionReportPage from "./pages/misReports/DrcTransactionReportPage";

// Audit
import SettledTransactionsReportPage from "./pages/auditReports/SettledTransactionsReportPage";
import BankSettlementReportPage from "./pages/auditReports/BankSettlementReportPage";
import POSSettlementReportPage from "./pages/auditReports/POSSettlementReportPage";
import RefundTxnsReportPage from "./pages/auditReports/RefundTxnsReportPage";
import IMPSSettlementReportPage from "./pages/auditReports/IMPSSettlementReportPage";
import UPISettlementReportPage from "./pages/auditReports/UPISettlementReportPage";
import AdjustmentReportPage from "./pages/auditReports/AdjustmentReportPage";
import FileStatusReportPage from "./pages/auditReports/FileStatusReportPage";
import ATMChargesReportPage from "./pages/auditReports/ATMChargesReportPage";
import NPCIBulkUploadPage from "./pages/dailyReports/NPCIBulkUploadPage";
import BankFormatReportPage from "./pages/auditReports/BankFormatReportPage";

import MultipleTxnsWithSameTerminalPage from "./pages/fraudReports/MultipleTxnsWithSameTerminalPage";
import MultipleTxnsWithDiffTerminalPage from "./pages/fraudReports/MultipleTxnsWithDiffTerminalPage";
import FrequentReversalReportPage from "./pages/fraudReports/FrequentReversalReportPage";
import MidnightTransactionsPage from "./pages/fraudReports/MidnightTransactionsPage";
import HighValueTransactionsPage from "./pages/fraudReports/HighValueTransactionsPage";

import CBRReportPage from "./pages/cbr/CBRReportPage";
import C3RReportPage from "./pages/cbr/C3RReportPage";
import OnlineCbrEntry from "./pages/cbr/OnlineCbrEntry";
import CBRMissingReportPage from "./pages/cbr/CBRMissingReportPage";

import SearchByRRNPage from "./pages/SearchByRRNPage";

import RunReconProcessPage from "./pages/RunReconProcessReportPage";
import VendorRegistrationPage from "./pages/VendorRegistrationPage";
import ClientRegistrationPage from "./pages/ClientRegistrationPage";
import TerminalRegistrationPage from "./pages/TerminalRegistrationPage";

import RoleCreationPage from "./pages/RoleCreationPage";
import UserRegistrationPage from "./pages/UserRegistrationPage";
import UserDetailsPage from "./pages/UserDetailsPage";
import UserFormPage from "./pages/UserFormPage";
import UserCheckerPage from "./pages/UserCheckerPage";
import ViewUserPage from "./pages/ViewUserPage";
import UserPreferences from "./pages/UserPreferencesPage";
import ChangePasswordPage from "./pages/ChangePasswordPage";
import ForcedSettlement from "./pages/ForcedSettlement";
import MatchingRulePage from "./pages/MatchingRulePage";
import ClientDetails from "./pages/ClientDetailsPage";
import SearchByCardNumberPage from "./pages/SearchByCardNumberPage";
import AllSettlementReportPage from "./pages/auditReports/AllSettlementReportPage";
import AllTTUMReportPage from "./pages/misReports/AllTTUMReportPage";

import TerminalDetails from "./pages/TerminalDetailsPage";
import TerminalBulkUploadPage from "./pages/TerminalBulkUploadPage";
import ReconConfigStatus from "./pages/ReconConfigStatusPage";
import DynamicReconciliationPage from "./pages/DynamicReconciliationPage";
import DynamicImportPage from "./pages/DynamicImportPage";
import DynamicFileConfigPage from "./pages/DynamicFileConfigPage";
import DynamicChannelConfigPage from "./pages/DynamicChannelConfigPage";
import SpreadsheetSplitter from "./pages/SpreadsheetPage";
import PlaintextSplitter from "./pages/PlaintextPage";
import AuditCofigPage from "./pages/AuditCofigPage";

import DynamicImportFile from "./pages/DynamicImportFilePage";
import ChannelRegistrationPage from "./pages/ChannelRegistrationPage";
import DynamicReportPage from "./pages/DynamicReportPage";
import DynamicTablePage from "./pages/DynamicTablePage";
import ModeRegistrationPage from "./pages/ModeRegistrationPage";

import GLReconReportPage from "./pages/auditReports/GLReconReportPage";
import StatusMasterConfigPage from "./pages/StatusMasterConfigPage";

import DbexceptionReportPage from "./pages/logger/DbexceptionReportPage";
import ErrorLogReportPage from "./pages/logger/ErrorLogReportPage";
import UserLoginReportPage from "./pages/logger/UserLoginReportPage";
import UserActivityReportPage from "./pages/logger/UserActivityReportPage";
import EJMissingReportPage from "./pages/exceptionReport/EJMissingReportPage";
import EjErrorConfigPage from "./pages/EjErrorConfigPage";
import ExportRawDataReportPage from "./pages/dailyReports/ExportRawDataPage";

import CashDashboardPage from "./pages/dashboard/CashDashboardPage";
import AcquirerFeeDashboardPage from "./pages/dashboard/AcquirerFeeDashboardPage";
import AcquirerIssuerFeeDashboardPage from "./pages/dashboard/AcquirerIssuerFeeDashboardPage";
import PosDashboardPage from "./pages/dashboard/PosDashboardPage";
import ReconDashboardPage from "./pages/dashboard/ReconDashboardPage";
import DisputeReport from "./pages/disputeManagement/DisputeReport";
import DisputeTrackingNPCIReportPage from "./pages/disputeManagement/DisputeTrackingNPCIReportPage";
import DisputeTypeConfigPage from "./pages/disputeManagement/DisputeTypeConfigPage";
import LogFileTypeConfigPage from "./pages/LogFileTypeConfigPage";
import UserAuditReportPage from "./pages/logger/UserAuditReportPage";
import AtmpredictionDashboardPage from "./pages/dashboard/AtmpredictionDashboardPage";
import RoleCheckerPage from "./pages/RoleCheckerPage";
import DownloadsPage from "./pages/DownloadsPage";
import Unauthorized from "./pages/Unauthorized";
import NotFound from "./pages/NotFound";
import AlertConfigPage from "./pages/AlertConfigurationPage";
import AlertConfigAddNewPage from "./pages/AlertConfigAddNewPage";

const AppRoutes = [
  { path: "/", element: <Home /> },
  { path: "/Home", element: <Home /> },
  { path: "/Login", element: <Login /> },
  { path: "/unauthorized", element:<Unauthorized /> },

  { path: "/ForgotPassword", element: <ForgotPassword /> },
  {
    path: "/client-management/branch-terminal-registration",
    element: <BranchTerminalRegistration />,
  },
  {
    path: "/client-management/currency-registration",
    element: <CurrencyRegistrationPage />,
  },
  {
    path: "/client-management/vendor-registration",
    element: <VendorRegistrationPage />,
  },
  {
    path: "/configuration/field-identification-config",
    element: <FieldIdentificationConfig />,
  },
  { path: "/configuration/file-configuration", element: <FileConfiguration /> },
  { path: "/configuration/force-settled-txns", element: <ForcedSettlement /> },
  {
    path: "/configuration/matching-rule-config",
    element: <MatchingRulePage />,
  },
  {
    path: "/downloads/downloads-report",
    element: <DownloadsPage />,
  },
  { path: "/daily-report/recon-txns-report", element: <ReconTxnsReport /> },
  {
    path: "/daily-report/successful-amount-count-report",
    element: <SuccessfulAmountCountReportPage />,
  },
  {
    path: "/daily-report/Cash-Tally",
    element: <CashTallyReportPage />,
  },
  { path: "/daily-report/generate-report", element: <GenerateReportPage /> },
  { path: "/daily-report/report-Checker", element: <ReportCheckerPage /> },
  { path: "/daily-report/view-report", element: <ViewReportPage /> },
  {
    path: "/daily-report/pos-dms-txns-report",
    element: <PosDmsTxnsReportPage />,
  },
  { path: "/import-logs/import-file", element: <ImportFile /> },
  { path: "/import-logs/dynamic-import-file", element: <DynamicImportFile /> },

  {
    path: "/mis-reports/txncount-summary-report",
    element: <TxnsCountSummaryReport />,
  },
  {
    path: "/mis-reports/dispense-summary-report",
    element: <DispenseSummaryReport />,
  },
  {
    path: "/mis-reports/reasonwise-summary-report",
    element: <ReasonWiseSummaryReportPage />,
  },
  { path: "/mis-reports/atm-ttum-report", element: <ATMTtumReportPage /> },
  { path: "/mis-reports/pos-ttum-report", element: <POSTtumReportPage /> },
  {
    path: "/mis-reports/pending-acq-entry-report",
    element: <PendingAcqEntryReportPage />,
  },
  {
    path: "/mis-reports/tips-and-surcharge",
    element: <TipsAndSurchargePage />,
  },
  {
    path: "/mis-reports/issuer-transaction-ttum-report",
    element: <IssuerTransactionTTUMReportPage />,
  },
  {
    path: "/mis-reports/refund-cashback-ttum-report",
    element: <RefundCashbackTTUMReportPage />,
  },
  { path: "/mis-reports/imps-ttum-report", element: <IMPSTTUMReportPage /> },
  { path: "/mis-reports/all-ttum-report", element: <AllTTUMReportPage /> },
  {
    path: "/mis-reports/ttum-transaction-report",
    element: <TtumTransactionReportPage />,
  },
  {
    path: "/mis-reports/timeout-transaction-report",
    element: <TimeoutTransactionReportPage />,
  },
  {
    path: "/mis-reports/upi-drc-report",
    element: <DrcTransactionReportPage />,
  },

  {
    path: "/audit-reports/settled-transactions-report",
    element: <SettledTransactionsReportPage />,
  },
  {
    path: "/mis-reports/settlement-report",
    element: <BankSettlementReportPage />,
  },
  {
    path: "/audit-reports/pos-settlement-report",
    element: <POSSettlementReportPage />,
  },
  {
    path: "/audit-reports/refund-txns-report",
    element: <RefundTxnsReportPage />,
  },
  {
    path: "/audit-reports/imps-settlement-report",
    element: <IMPSSettlementReportPage />,
  },
  {
    path: "/audit-reports/upi-settlement-report",
    element: <UPISettlementReportPage />,
  },
  {
    path: "/audit-reports/adjustment-report",
    element: <AdjustmentReportPage />,
  },
  {
    path: "/audit-reports/file-status-report",
    element: <FileStatusReportPage />,
  },
  {
    path: "/audit-reports/atm-charges-report",
    element: <ATMChargesReportPage />,
  },
  { path: "/daily-report/npci-bulk-upload", element: <NPCIBulkUploadPage /> },
  {
    path: "/audit-reports/all-settlement-report",
    element: <AllSettlementReportPage />,
  },
  {
    path: "/audit-reports/bank-format-settlement-report",
    element: <BankFormatReportPage />,
  },

  {
    path: "/fraud-reports/multiple-txn-with-same-terminal",
    element: <MultipleTxnsWithSameTerminalPage />,
  },
  {
    path: "/fraud-reports/multiple-txn-with-diff-terminal",
    element: <MultipleTxnsWithDiffTerminalPage />,
  },
  {
    path: "/fraud-reports/frequent-reversal-report",
    element: <FrequentReversalReportPage />,
  },
  {
    path: "/fraud-reports/midnight-transactions",
    element: <MidnightTransactionsPage />,
  },
  {
    path: "/fraud-reports/highvalue-transactions",
    element: <HighValueTransactionsPage />,
  },
  { path: "/cbr/online-cbr-entry", element: <OnlineCbrEntry /> },
  { path: "/exception-report/c3r-report", element: <C3RReportPage /> },
  { path: "/cbr/cbr-report", element: <CBRReportPage /> },
  {
    path: "/exception-report/cbr-missing-report",
    element: <CBRMissingReportPage />,
  },

  { path: "/run-recon/run-recon", element: <RunReconProcessPage /> },
  {
    path: "/client-management/client-registration",
    element: <ClientRegistrationPage />,
  },
  {
    path: "/client-management/terminal-registration",
    element: <TerminalRegistrationPage />,
  },

  { path: "/clientDetails", element: <ClientDetails /> },
  { path: "/search/search-by-rrn", element: <SearchByRRNPage /> },
  {
    path: "/search/search-by-card-number",
    element: <SearchByCardNumberPage />,
  },

  { path: "/user-management/role-creation", element: <RoleCreationPage /> },
  { path: "/user-management/role-checker", element: <RoleCheckerPage /> },
  {
    path: "/user-management/user-registration",
    element: <UserRegistrationPage />,
  },
  { path: "/user-management/userForm", element: <UserFormPage /> },
  { path: "/user-management/user-details", element: <UserDetailsPage /> },
  { path: "/user-management/user-checker", element: <UserCheckerPage /> },
  { path: "/user-management/view-user", element: <ViewUserPage /> },
  { path: "/user-management/change-password", element: <ChangePasswordPage /> },

  {
    path: "/configuration/recon-config-status",
    element: <ReconConfigStatus />,
  },
  {
    path: "/configuration/dynamic-Reconciliation-config/*",
    element: <DynamicReconciliationPage />,
  },
  {
    path: "/configuration/dynamic-Import-config",
    element: <DynamicImportPage />,
  },
  {
    path: "/configuration/dynamic-file-config",
    element: <DynamicFileConfigPage />,
  },
  {
    path: "/configuration/dynamic-channel-config",
    element: <DynamicChannelConfigPage />,
  },
  {
    path: "/configuration/dynamic-report-config",
    element: <DynamicReportPage />,
  },
  {
    path: "/configuration/alert-config" ,
    element: <AlertConfigPage/>,
  },
  {
    path: "/configuration/alert-config/add",
    element: <AlertConfigAddNewPage />,
  },
  {
    path: "/configuration/dynamic-table-config",
    element: <DynamicTablePage />,
  },
  { path: "/configuration/audit-Config", element: <AuditCofigPage /> },
  {
    path: "/dispute-management/dispute-raise-and-tracking/*",
    element: <DisputeReport />,
  },
  {
    path: "/dispute-management/NPCI-Dispute-Tracking-Report",
    element: <DisputeTrackingNPCIReportPage />,
  },
  {
    path: "/dispute-management/DisputeTypeConfig",
    element: <DisputeTypeConfigPage />,
  },
  { path: "/terminalDetails", element: <TerminalDetails /> },
  { path: "/search/search-by-rrn", element: <SearchByRRNPage /> },
  { path: "/userPreferences", element: <UserPreferences /> },

  {
    path: "/client-management/terminal-bulk-upload",
    element: <TerminalBulkUploadPage />,
  },
  { path: "/spreadsheetSplitter", element: <SpreadsheetSplitter /> },
  { path: "/plaintextSplitter", element: <PlaintextSplitter /> },
  {
    path: "/client-management/channel-registration",
    element: <ChannelRegistrationPage />,
  },
  {
    path: "/client-management/mode-registration",
    element: <ModeRegistrationPage />,
  },
  {
    path: "/configuration/status-master-config",
    element: <StatusMasterConfigPage />,
  },
  { path: "/mis-reports/gl-recon-report", element: <GLReconReportPage /> },
  {
    path: "/daily-report/export-raw-data",
    element: <ExportRawDataReportPage />,
  },
  {
    path: "/logger/database-exception-report",
    element: <DbexceptionReportPage />,
  },
  {
    path: "/audit-reports/user-login-report",
    element: <UserLoginReportPage />,
  },
  {
    path: "/audit-reports/user-activity-report",
    element: <UserActivityReportPage />,
  },
  { path: "/logger/error-log-report", element: <ErrorLogReportPage /> },
  {
    path: "/exception-report/ej-missing-report",
    element: <EJMissingReportPage />,
  },
  { path: "/configuration/ej-error-config", element: <EjErrorConfigPage /> },

  {
    path: "/configuration/log-filetype-config",
    element: <LogFileTypeConfigPage />,
  },

  { path: "/dash-board/cash-recon", element: <CashDashboardPage /> },
  { path: "/dash-board/acquirer-dashboard", element: <AcquirerFeeDashboardPage /> },
  { path: "//dash-board/acquirer-issuer-dashboard", element: <AcquirerIssuerFeeDashboardPage /> },
  { path: "/dash-board/pos-dashaboard", element: <PosDashboardPage /> },
  { path: "/dash-board/recon-dashaboard", element: <ReconDashboardPage /> },
  {
    path: "/dash-board/atm-prediction-dashaboard",
    element: <AtmpredictionDashboardPage />,
  },
  {
    path: "/audit-reports/user-audit-report",
    element: <UserAuditReportPage />,
  },
  { path:"*" , element:<NotFound />  },
];

export default AppRoutes;
