﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
import "./AuditCofig.css";
// Components
import SidebarMain from "../common/SidebarMain";
import AuditCofigMainWindow from "./AuditCofigMainWindow";

const AuditCofig = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <AuditCofigMainWindow />
        </div>
    );
};

export default AuditCofig