﻿import React, { useRef, useState, useEffect } from "react";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL" ;

import MessageBox from "../common/MessageBox";
import "datatables.net-dt/js/dataTables.dataTables"
import "datatables.net-dt/css/jquery.dataTables.min.css"
import 'jquery/dist/jquery.min.js';
import $ from 'jquery';
import success from "../../images/common/success.svg";
import redX from "../../images/common/redX.svg";
import LoadingSpinner from "../common/LoadingSpinner";

const AuditCofigMainWindow = () => {
    const [ShowGrid, setShowGrid] = useState(false);
    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });
    const [LoginData, setLoginData] = useState([]);
    const [Reload, setReload] = useState(true);

    const fetchData = () => {
        setIsLoading(true);
        setShowGrid(false);
        let alertMessages = "";

        MaximusAxios.get('api/Logger/GetMenuList', {  mode: 'cors' })
            .then(response => {
                if (response.data.length > 0) {
                    setLoginData(response.data);
                    setShowGrid(true);
                    setIsLoading(false);
                }
                else {
                    alertMessages += "Records Dosen't Exists";
                    setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                    setShowGrid(false);
                    setIsLoading(false);
                }
            })
            .catch(error => {
                if (error.response) {
                    console.log(error.response.data);
                    setIsLoading(false);
                }
            });
    };

    useEffect(() => {
        fetchData();
    }, [Reload]);


    const handleClick = (item) => {
        if (item.isEnable === 'True') {
            alert("Are you sure you want to Disable Menu.");
            setIsLoading(true);
        }
        else if (item.isEnable === 'False' ) {
            alert("Are you sure you want to Enable  Menu.");
            setIsLoading(true);
        }
        MaximusAxios.post("api/Logger/EnableMenuItem", { MenuName : item.menuName}, {  mode: 'cors' })
            .then(function (response) {
                if (response.data === 'Enabled') {
                    alert("Menu Enabled Successfully.");
                    setIsLoading(false);
                    setReload(!Reload);
                }
                else if (response.data === 'Disabled') {
                    alert("Menu Disabled Successfully.");
                    setIsLoading(false);
                    setReload(!Reload);
                }
                else {
                    alert("Changing status failed.");
                    setIsLoading(false);
                    setReload(!Reload);
                }
                }).catch (function (error) {
                    console.log("Error ocuured:" + error);
                    setIsLoading(false);
                    setReload(!Reload);
                });
    };

    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }

    $(document).ready(function () {

        if (LoginData !== null && LoginData.length > 0) {
            $('#gvMatchingList').DataTable();
        }
    });

    return (
        <div className="configLeft dynamicContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Audit Configuration
                </h5>
                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Configuration</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Audit Configuration</p>
                </div>
            </div>
            <div>
            {/* Config Left Top */}
            {/*<div className="configLeftTop">*/}
            {/*    <div className="accordion" id="unmatchedFilters">*/}
            {/*        <div className="accordion-item">*/}
            {/*            <div*/}
            {/*                className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"*/}
            {/*                id="unmatchedFiltersHeading"*/}
            {/*            >*/}
            {/*                <h6 className="fontWeight-600 colorBlack">Filters</h6>*/}




            {/*                <button*/}
            {/*                    className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"*/}
            {/*                    type="button"*/}
            {/*                    data-bs-toggle="collapse"*/}
            {/*                    data-bs-target="#unmatchedFiltersCollapse"*/}
            {/*                    aria-expanded="true"*/}
            {/*                    aria-controls="unmatchedFiltersCollapse"*/}
            {/*                >*/}
            {/*                    <span className="icon-Hide"></span>*/}
            {/*                    <span className="ms-1 fontSize12-m colorPrimaryDefault">*/}
            {/*                        Show / Hide*/}
            {/*                    </span>*/}
            {/*                </button>*/}
            {/*            </div>*/}
            {/*            <div*/}
            {/*                id="unmatchedFiltersCollapse"*/}
            {/*                className="accordion-collapse collapse show"*/}
            {/*                aria-labelledby="unmatchedFiltersHeading"*/}
            {/*                data-bs-parent="#unmatchedFilters"*/}
            {/*            >*/}
            {/*                <div className="accordion-body">*/}
            {/*                    <div className="hrGreyLine"></div>*/}
            {/*                    <div className="configSelectBoxTop row">*/}
            {/*                        <div className="clientNameSelect col">*/}
            {/*                            <label htmlFor="StartDate">From Date</label>*/}
            {/*                            <span className="text-danger font-size13">*</span>*/}
            {/*                            <DatePicker*/}
            {/*                                renderCustomHeader={({*/}
            {/*                                    date,*/}
            {/*                                    changeYear,*/}
            {/*                                    changeMonth,*/}
            {/*                                    decreaseMonth,*/}
            {/*                                    increaseMonth,*/}
            {/*                                    prevMonthButtonDisabled,*/}
            {/*                                    nextMonthButtonDisabled,*/}
            {/*                                }) => (*/}
            {/*                                    <div*/}
            {/*                                        style={{*/}
            {/*                                            margin: 1,*/}
            {/*                                            display: "flex",*/}
            {/*                                            justifyContent: "center",*/}
            {/*                                        }}*/}
            {/*                                    >*/}
            {/*                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>*/}
            {/*                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>*/}
            {/*                                        </button>*/}
            {/*                                        <select*/}
            {/*                                            value={getYear(date)}*/}
            {/*                                            onChange={({ target: { value } }) => changeYear(value)}*/}
            {/*                                        >*/}
            {/*                                            {years.map((option) => (*/}
            {/*                                                <option key={option} value={option}>*/}
            {/*                                                    {option}*/}
            {/*                                                </option>*/}
            {/*                                            ))}*/}
            {/*                                        </select>*/}

            {/*                                        <select*/}
            {/*                                            value={months[getMonth(date)]}*/}
            {/*                                            onChange={({ target: { value } }) =>*/}
            {/*                                                changeMonth(months.indexOf(value))*/}
            {/*                                            }*/}
            {/*                                        >*/}
            {/*                                            {months.map((option) => (*/}
            {/*                                                <option key={option} value={option}>*/}
            {/*                                                    {option}*/}
            {/*                                                </option>*/}
            {/*                                            ))}*/}
            {/*                                        </select>*/}

            {/*                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>*/}
            {/*                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>*/}
            {/*                                        </button>*/}
            {/*                                    </div>*/}
            {/*                                )}*/}
            {/*                                selected={startDate}*/}
            {/*                                dateFormat="dd/MM/yyyy"*/}
            {/*                                onChange={(date) => setStartDateValue(date)}*/}
            {/*                                className="reportDate"*/}
            {/*                                maxDate={new Date()}*/}
            {/*                            />*/}
            {/*                        </div>*/}
            {/*                        <div className="clientNameSelect col">*/}
            {/*                            <label htmlFor="ToDate">To Date</label>*/}
            {/*                            <span className="text-danger font-size13">*</span>*/}
            {/*                            <DatePicker*/}
            {/*                                renderCustomHeader={({*/}
            {/*                                    date,*/}
            {/*                                    changeYear,*/}
            {/*                                    changeMonth,*/}
            {/*                                    decreaseMonth,*/}
            {/*                                    increaseMonth,*/}
            {/*                                    prevMonthButtonDisabled,*/}
            {/*                                    nextMonthButtonDisabled,*/}
            {/*                                }) => (*/}
            {/*                                    <div*/}
            {/*                                        style={{*/}
            {/*                                            margin: 1,*/}
            {/*                                            display: "flex",*/}
            {/*                                            justifyContent: "center",*/}
            {/*                                        }}*/}
            {/*                                    >*/}
            {/*                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>*/}
            {/*                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>*/}
            {/*                                        </button>*/}
            {/*                                        <select*/}
            {/*                                            value={getYear(date)}*/}
            {/*                                            onChange={({ target: { value } }) => changeYear(value)}*/}
            {/*                                        >*/}
            {/*                                            {years.map((option) => (*/}
            {/*                                                <option key={option} value={option}>*/}
            {/*                                                    {option}*/}
            {/*                                                </option>*/}
            {/*                                            ))}*/}
            {/*                                        </select>*/}

            {/*                                        <select*/}
            {/*                                            value={months[getMonth(date)]}*/}
            {/*                                            onChange={({ target: { value } }) =>*/}
            {/*                                                changeMonth(months.indexOf(value))*/}
            {/*                                            }*/}
            {/*                                        >*/}
            {/*                                            {months.map((option) => (*/}
            {/*                                                <option key={option} value={option}>*/}
            {/*                                                    {option}*/}
            {/*                                                </option>*/}
            {/*                                            ))}*/}
            {/*                                        </select>*/}

            {/*                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>*/}
            {/*                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>*/}
            {/*                                        </button>*/}
            {/*                                    </div>*/}
            {/*                                )}*/}
            {/*                                selected={endDate}*/}
            {/*                                dateFormat="dd/MM/yyyy"*/}
            {/*                                onChange={(date) => setEndDateValue(date)}*/}
            {/*                                className="reportDate"*/}
            {/*                                maxDate={new Date()}*/}
            {/*                            />*/}
            {/*                        </div>*/}
            {/*                        */}{/*<div className="clientNameSelect col">*/}
            {/*                        */}{/*    <label htmlFor="ddlChannel">UserId</label>*/}
            {/*                        */}{/*    <span className="text-danger font-size13"></span>*/}
            {/*                        */}{/*    <Select*/}
            {/*                        */}{/*        id="ddlChannel"*/}
            {/*                        */}{/*        value={SelectedUserId}*/}
            {/*                        */}{/*        classNamePrefix="reactSelectBox"*/}
            {/*                        */}{/*        options={optionsUserId.map(x => (*/}
            {/*                        */}{/*            {*/}
            {/*                        */}{/*                value: x.iD,*/}
            {/*                        */}{/*                label:x.userId*/}
            {/*                        */}{/*            }*/}
            {/*                        */}{/*        ))}*/}
            {/*                        */}{/*        loadOptions={fetchUserId}*/}
            {/*                        */}{/*    onChange={handleUserId}*/}
            {/*                        */}{/*    />*/}
            {/*                        */}{/*</div>*/}

            {/*                    </div>*/}

            {/*                    <div className="text-center btnsBtm">*/}
            {/*                        <button*/}
            {/*                            type="button"*/}
            {/*                            className="btnPrimaryOutline"*/}
            {/*                            onClick={(e) => onReset(e)}*/}
            {/*                        >*/}
            {/*                            Reset*/}
            {/*                        </button>*/}
            {/*                        <button*/}
            {/*                            type="button"*/}
            {/*                            className="btnPrimary ms-2"*/}
            {/*                            onClick={onShowClick}*/}
            {/*                            disabled={isShow}*/}
            {/*                        >Show*/}
            {/*                        </button>*/}

            {/*                    </div>*/}
            {/*                </div>*/}
            {/*            </div>*/}
            {/*        </div>*/}

            {/*    </div>*/}
            {/*</div>*/}
            </div>
            {/* Data Grid*/}
            <div className="configLeftBottom">
                <div>
                {(LoginData === null || LoginData.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}

        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                        <table id="gvMatchingList" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }}>
                                            <thead>
                                                <tr>
                                                    <th scope="col">Sr. No.</th>
                                                    <th scope="col">Menu Name</th>
                                                    <th scope="col">Parent Menu Name</th>
                                                    <th scope="col">Action</th>
                                                    
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {LoginData.map((item, index) => (
                                                    <tr key={index}>
                                                        <td>{index + 1}</td> 
                                                        <td>{item.menuName}</td>
                                                        <td>{item.parentMenuName}</td>
                                                        <td ><div className="text-center">
                                                            <button type="button" className="iconButtonBox" onClick={() => handleClick(item)} >
                                                                <img src={item.isEnable === 'True' ? success : redX} alt="Edit" title={item.isEnable === 'True' ? "Disable" : "Enable"} />
                                                            </button>
                                                        </div></td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                </div>
                            </div>
                        </div>
                    </>
                    )}
                </div>
            </div>
             <LoadingSpinner isShow={false} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default AuditCofigMainWindow;
