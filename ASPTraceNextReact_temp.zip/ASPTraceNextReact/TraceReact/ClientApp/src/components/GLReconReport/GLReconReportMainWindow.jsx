import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from 'react-select/async';
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../common/apiURL" ;
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import authHeader from "../../../pages/login/services/auth-header";
import { useSelector } from "react-redux";
import configuration from "../../../images/common/configuration.svg";
import AttachmentsIcon from "../../../images/common/editRow.svg";
import DownloadIcon from "../../../images/common/cloud-240.svg";
import DeleteIcon from "../../../images/common/cancelIcon.svg";
import axios from 'axios';
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"


import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

import ExcelJS from "exceljs";
import { saveAs } from 'file-saver';

// Images
import Pdf from "../../../images/common/pdf.svg";
import ExcelIcon from "../../../images/common/excel.svg";


import jsPDF from 'jspdf'
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns/esm";
import { FileUploader } from "react-drag-drop-files";
import postHeader from "../../../pages/login/services/post-header";
import { useRef } from "react";


const optionsNetworkType = [
    { value: "1", label: "NPCI" },
    { value: "2", label: "VISA" },
    { value: "3", label: "MASTER" },
];


function splitCamelCase(str) {
    // Split the string at each capital letter
    const words = str.split(/(?=[A-Z])/);
    //const words = str.split(/(?<=[A-Z])(?=[a-z])/);
    // Capitalize the first letter of each word and join them with a space
    const result = words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    return result;
}

const DisputeRaiseTrackingMain = () => {


    const currentUser = useSelector((state) => state.authReducer);

    const [IsUserChecker, setIsUserChecker] = useState(false);
    const [checkboxValues, setCheckboxValues] = useState([]);


    const fetchClientData = (inputValue) => {
        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });


    }

    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];


    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const [inputValue, setValue] = useState('0');
    const [titleDate, setTitleDateValue] = useState('');
    const [isShowCardNo, setIsShowCardNo] = useState(false);
    const [isShowTerminalId, setIsShowTerminald] = useState(false);
    const [isShowPStatus, setShowPStatus] = useState(false);

    const [selectedValue, setSelectedValue] = useState(null);
    const [disputeAttachmentModal, setDisputeAttachmentModal] = useState(false);

    // handle input change event
    const handleInputChange = value => {
        setValue(value);
    };
    const [importFile, setImportFile] = useState(null);
    const [fileName, setFileName] = useState(null);
    const [fileTypes, setFileTypes] = useState(['pdf', 'xls', 'xlsx', 'doc', 'docx', 'txt', 'jpg', 'jpeg', 'png']);
    const [optionsChannelType, setOptionsChannelTypeValue] = useState([{ channelID: "0", channelName: "--Select--" }]);

    const [selectedChannelValue, setSelectedChannelValue] = useState(null);

    const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "--Select--" }]);

    const [selectedModeValue, setSelectedModeValue] = useState(null);

    const [optionsTerminalType, setOptionsTerminalValue] = useState([{ ID: "0", TERMINALID: "All" }]);

    const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

    const [selectedNetworkValue, setNetworkTypeValue] = useState(null);

    const [isShowTxnType, setIsShowTxnType] = useState(false);

    const [isShowTerminal, setIsShowTerminal] = useState(false);
    // handle selection

    const [visibleTab, setVisibleTab] = useState("Dispute Tracking");
    const [ShowAttachments, setShowAttachments] = useState(false);
    const [AttachmentsTable, setAttachmentsTable] = useState([]);
    const [checkerDisputeStatus, setCheckerDisputeStatus] = useState({ Remark: '', Status: 'Select' });
    const [makerDisputeStatus, setMakerDisputeStatus] = useState({ Remark: '', Status: 'Select' });
    const [optionsDisputeType, setOptionsDisputeType] = useState([{ value: "0", label: "--Select--" }]);
    const [disputeRowData, setDisputeRowData] = useState(null);
    const [disputeformData, setDisputeformData] = useState({
        DisputeID: '',
        ReferenceNumber: '',
        TxnsDateTime: ''
    });

    const handleOptionsChannelType = value => {
        setOptionsChannelTypeValue(value);
    };

    const handleOptionsModeType = value => {
        setOptionsModeTypeValue(value);
    };

    const handleOptionsTerminalType = value => {
        setOptionsTerminalValue(value);
    };


    const handleClientChange = value => {
        setUnmatchedTxnsReport(null);
        setSelectedChannelValue(null);
        setSelectedModeValue(null);
        setNetworkTypeValue('0');
        setSelectedTerminalValue(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedValue(value);

        if (value.clientID !== '0') {
            return MaximusAxios.get('api/Common/GetChannelOptionList?ClientId=' + value.clientID + '&UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
                handleOptionsChannelType(result.data);
            });
        }



    }

    // handle selection
    const handleChannelChange = value => {
        setUnmatchedTxnsReport(null);
        setSelectedModeValue(null);
        setNetworkTypeValue('0');
        setSelectedTerminalValue(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedChannelValue(value);

        if (value.value === '1') { setIsShowTxnType(true); } else { setIsShowTxnType(false); }
        if (value.value === '4' || value.value === '7') { setIsShowCardNo(false); } else { setIsShowCardNo(true); }
        if (value.value === '7') { setIsShowTerminald(false); } else { setIsShowTerminald(true); }
        if (value.value === '1' || value.value === '4' || value.value === '7') { setShowPStatus(false); }
        if (value.value === '2' || value.value === '3' && selectedValue.value === '45') { setShowPStatus(true); }
        if (value.value === '2' || value.value === '3' && selectedValue.value !== '45') { setShowPStatus(false); }

        if (value.value !== '0' && selectedValue.clientID !== '0') {
            return MaximusAxios.get('api/Common/GetModeOptionList?ClientID=' + selectedValue.clientID + '&ChannelID=' + value.value + '&UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
                handleOptionsModeType(result.data);
            });
        }

    }

    const handleModeChange = value => {

        if (currentUser !== null && currentUser.user !== null) {

            setUnmatchedTxnsReport(null);
            setNetworkTypeValue('0');
            setSelectedTerminalValue(null);
            //setStartDate(null);
            //setEndDate(null);
            setSelectedModeValue(value);

            if (value.value === '1' || value.value === '2') { setIsShowTerminal(true); } else { setIsShowTerminal(false); }

            if (value.value !== '0' && selectedValue.clientID !== '0' && selectedChannelValue.value) {
                return MaximusAxios.get('api/Common/GetTerminalOptionList?ClientID=' + selectedValue.clientID + '&ChannelID=' + selectedChannelValue.value + '&UserName=' + currentUser.user.username, {  mode: 'cors' }).then(result => {

                    var resData = result.data;

                    var myObj = { "ID": "0", "TERMINALID": "All" };

                    resData.push(myObj);

                    handleOptionsTerminalType(resData);
                });
            }
        } else {

            alert('Session Timeout');
        }
    }

    const BulkDisputeType = (type, value) => {

    }

    const handleDisputeTypeChange = (type, value, rowindex, row) => {


        if (type === 'checker') {
            let Values = checkboxValues.map((item) => {
                if (item.id === rowindex) {
                    return { ...item, ...row, checkerStatus: value.label, isChecked: true };
                }
                return { ...item };
            })

            setCheckboxValues(Values);
        }
        else if (type === 'maker') {
            let Values = checkboxValues.map((item) => {
                if (item.id === rowindex) {
                    return { ...item, ...row, makerStatus: value.label, isChecked: true };
                }
                return { ...item };
            })

            setCheckboxValues(Values);
        }

    }
    const handleDisputeRemark = (type, e, rowindex, row) => {


        if (type === 'checker') {
            let Value = e.target.value;
            let Values = checkboxValues.map((item) => {
                if (item.id === rowindex) {
                    return { ...item, ...row, checkerRemarks: Value, isChecked: true };
                }
                return { ...item };
            })

            setCheckboxValues(Values);
        }
        else if (type === 'maker') {
            let Value = e.target.value;
            let Values = checkboxValues.map((item) => {
                if (item.id === rowindex) {
                    return { ...item, ...row, makerRemarks: Value, isChecked: true };
                }
                return { ...item };
            })

            setCheckboxValues(Values);
        }

    }

    const handleTxnTypeChange = value => {
        setUnmatchedTxnsReport(null);
        setSelectedTerminalValue(null);
        //setStartDate(null);
        //setEndDate(null);
        setNetworkTypeValue(value);

    }

    const handleTerminalChange = value => {
        setUnmatchedTxnsReport(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedTerminalValue(value);
    }



    //   Date Calendar
    const [startDate, setStartDate] = useState(new Date());
    //   Date Calendar
    const [endDate, setEndDate] = useState(new Date());



    const setStartDateValue = value => {
        setStartDate(value);
        setUnmatchedTxnsReport(null);
    }

    const setEndDateValue = value => {

        if (startDate === null) {
            setEndDate(null);
            alert('Please enter From date first');
        }
        else {
            if (startDate > value) {
                alert('To date must be greater than From date ');
                setEndDate(null);
            }
            else {
                setEndDate(value);
            }
        }
        setUnmatchedTxnsReport(null);
    }

    // Modals
    const [referenceNo, setReferenceNo] = useState(false);

    const [UnmatchedTxnsReport, setUnmatchedTxnsReport] = useState(null);


    const [DisputeTxnList, setDisputeTxnList] = useState(null);

    const downloadPDF = () => {
        if (UnmatchedTxnsReport !== null) {
            if (UnmatchedTxnsReport.length > 0) {

                MaximusAxios.get('api/Common/GetClientLogoImage?ClientId=' + selectedValue.clientID, {  mode: 'cors' }).then(result => {

                    const title = "Unmatched Txns Report";
                    // {
                    //     worksheet.columns = TblCols;

                    //     worksheet.columns = TblCols.map((item)=>({ width: 10 }));
                    // }
                    const headers = [["Channel", "Mode", "Terminal Id", "Txn DateTime", "Reference Number", "Card Number", "Account No", "Txn Amount", "EJ Status", "Switch Status", "Network Status", "GL Status", "Txns Type", "Remark"]];
                    const headers1 = [["Channel", "Mode", "Terminal Id", "Txn DateTime", "Reference Number", "Account No", "Txn Amount", "EJ Status", "Switch Status", "Network Status", "GL Status", "Txns Type", "Remark"]];
                    const headers2 = [["Channel", "Mode", "Txn DateTime", "Reference Number", "Account No", "Txn Amount", "EJ Status", "Switch Status", "Network Status", "GL Status", "Txns Type", "Remark"]];

                    var dataPDF = $("#gvUnmatchedTxnsReportPDF").dataTable()._('tr', { "filter": "applied" });
                    let filterDataPDF = [];
                    let cntrow = 0; let RefNum = ''; let cardNumber = ''; let remarks = '';
                    //console.log(dataPDF);
                    //{

                    //    for (let i = 0; i < data.length; i++) {
                    //        RefNum = data[cntrow][4];
                    //        RefNum = RefNum.replace('<button class="editBox"><u>', '');
                    //        RefNum = RefNum.replace('</u></button>', '');

                    //        remarks = data[cntrow][12];;
                    //        remarks = remarks.replace('<p class="tableTextInner">', '');
                    //        remarks = remarks.replace('</p>', '');
                    //        var arr = `{${Object.keys(UnmatchedTxnsReport[cntrow]).map((tc) => (`"${tc}":${JSON.stringify(UnmatchedTxnsReport[0][tc] !== null ? UnmatchedTxnsReport[0][tc] : '')}`)).join(',')}}`
                    //        let obj = JSON.parse(arr);
                    //        filterDataExcel.push(obj);
                    //        cntrow++;
                    //    }
                    //}

                    const unit = "pt";
                    const size = "LEGAL"; // Use A1, A2, A3 or A4
                    const orientation = "landscape"; // portrait or landscape

                    const doc = new jsPDF(orientation, unit, size);

                    //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
                    var pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

                    //console.log(result); 

                    doc.addImage(result.data.clientLogo, 'PNG', 20, 20, 150, 50);

                    doc.addImage(result.data.traceLogo, 'PNG', pageWidth - 170, 20, 150, 50);

                    //doc.setTextColor(100);

                    doc.setFontSize(24);

                    doc.text(title, pageWidth / 2, 40, { align: 'center' });

                    doc.setFontSize(20);

                    doc.text(titleDate, pageWidth / 2, 65, { align: 'center' });

                    if (selectedChannelValue.value === '4') {

                        let content = {
                            startY: 80,
                            head: headers1,
                            body: filterDataPDF
                        };

                        doc.autoTable(content);

                    } else if (selectedChannelValue.value === '7') {

                        let content = {
                            startY: 80,
                            head: headers2,
                            body: filterDataPDF
                        };

                        doc.autoTable(content);

                    } else {
                        let content = {
                            startY: 80,
                            head: headers,
                            body: filterDataPDF
                        };

                        doc.autoTable(content);
                    }



                    doc.setFontSize(10);
                    //doc.autoTable(content);
                    doc.save("Unmatched Txns Report.pdf")

                });

            } else {
                alert('No Record Found');
            }
        } else {
            alert('No Record Found');
        }
    };


    // Tooltip
    const renderTooltip = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to pdf
        </Tooltip>
    );

    const renderTooltipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to excel
        </Tooltip>
    );
    const SettletipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Settle Selected Txns
        </Tooltip>
    );

    const renderTooltipShow = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Click to open window
        </Tooltip>
    );

    const formatDate = (date) => {

        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }


    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }


    const onSubmit = async () => {

        setUnmatchedTxnsReport(null);

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            alert("Please select Channel!");
            return false;
        }

        if (selectedModeValue === undefined || selectedModeValue === null) {
            alert("Please select mode Type!");
            return false;
        }

        if ((selectedChannelValue !== undefined && selectedChannelValue !== null && selectedChannelValue.value === '1') && (selectedNetworkValue === undefined || selectedNetworkValue === null)) {
            alert("Please select Txn Type!");
            return false;
        }


        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        let ChannelId = 0;

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }

        let ModeId = 0;

        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }

        let NetworkTypeID = 0;

        if (selectedNetworkValue === undefined || selectedNetworkValue === null) {
            NetworkTypeID = 0;
        }
        else {
            NetworkTypeID = selectedNetworkValue.value;
        }

        let TerminalValue = 0;

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            TerminalValue = 0;
        }
        else {
            TerminalValue = selectedTerminalValue.value;
        }

        setIsLoading(true);

        

        MaximusAxios.get('/api/DMSReport/IsUserChecker?UserName=' + currentUser.user.username, {  mode: 'cors' }).then(result1 => {
            if (result1.data.includes("checker")) {
                setIsUserChecker(true);
            }
            else {
                setIsUserChecker(false);
            }
        });

        MaximusAxios.post('api/AuditReport/GetGLReconReport', {
            ClientID: selectedValue.clientID,
            ChannelID: ChannelId,
            ModeID: ModeId,
            NetworkType: NetworkTypeID,
            FromDateTxns: formatDate(startDate),
            ToDateTxns: formatDate(endDate),
        }, {  mode: 'cors' })
            .then(function (response) {
                setUnmatchedTxnsReport(response.data.table);
                //if (response.data !== null) {
                //    if (response.data.length > 0) {
                //        let Values = response.data.map((item, i) => ({ id: i, isChecked: false }));
                //        setCheckboxValues(Values);
                //    }
                //}
                setTitleDateValue("Report Date : " + formatDate(startDate) + " To " + formatDate(endDate));
                setIsLoading(false);
                if (response.data === null || response.data.length === 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'No records found' }); }
            })
            .catch(function (error) {
                setTitleDateValue("");
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                console.log(error.response);
                setIsLoading(false);
            });
    };


    const onActionClick = (RowData) => {

        let ReferenceNumber = RowData.referenceNumber;
        let TxnsDateTime = RowData.txnDateTime;
        let disputeID = RowData.disputeID;

        setDisputeRowData(RowData);

        setCheckerDisputeStatus({ Remark: RowData.checkerRemarks, Status: RowData.checkerStatus });
        setMakerDisputeStatus({ Remark: RowData.makerRemarks, Status: RowData.makerStatus });
        setIsLoading(true);

        setDisputeformData({
            DisputeID: disputeID,
            ReferenceNumber: ReferenceNumber,
            TxnsDateTime: formatDate(TxnsDateTime)
        });

        MaximusAxios.post('api/DMSReport/GetDisputeByReferenceNumber', {
            ClientID: selectedValue.clientID,
            ChannelID: selectedChannelValue.value,
            ModeID: selectedModeValue.value,
            NetworkType: '1',
            TxnDateTime: formatDate(TxnsDateTime),
            ReferenceNumber: ReferenceNumber,
        }, {  mode: 'cors' })
            .then(function (response) {


                setIsLoading(false);
                setDisputeAttachmentModal(true);
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setIsLoading(false);
            });

    }
    const onReferenceNumberClick = (row) => {



        setIsLoading(true);

        MaximusAxios.post('api/DMSReport/GetDisputeByReferenceNumber', {
            ClientID: selectedValue.clientID,
            ChannelID: selectedChannelValue.value,
            ModeID: selectedModeValue.value,
            NetworkType: '1',
            TxnDateTime: formatDate(row.txnDateTime),
            ReferenceNumber: row.referenceNumber,
        }, {  mode: 'cors' })
            .then(function (response) {

                setDisputeTxnList(response.data);
                setIsLoading(false);
                setReferenceNo(row.referenceNumber);
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setIsLoading(false);
            });
    };



    $(document).ready(function () {

        if (UnmatchedTxnsReport !== null && UnmatchedTxnsReport.length > 0) {
            $('#gvUnmatchedTxnsReportPDF').DataTable();
        }
    });


    // ----------BY KUNDAN
    const ExportToExcelKS = () => {

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            alert("Please select Channel!");
            return false;
        }

        if (selectedModeValue === undefined || selectedModeValue === null) {
            alert("Please select mode Type!");
            return false;
        }

        


        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        let ChannelId = 0;

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }

        let ModeId = 0;

        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }

        let TxnType = '';


        let TerminalValue = 0;

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            TerminalValue = 0;
        }
        else {
            TerminalValue = selectedTerminalValue.value;
        }
        let FileName = 'GLReconReport_' + selectedChannelValue.label + '_' + selectedModeValue.label + '_' + formatDate(startDate) + '.xlsx'
        setIsLoading(true);

        MaximusAxios.post('api/AuditReport/ExportExcelGLReconReport', {
            ClientID: selectedValue.clientID,
            ChannelID: ChannelId,
            ModeID: ModeId,
            TerminalID: TerminalValue,
            TxnType: TxnType,
            FromDate: formatDate(startDate),
            ToDate: formatDate(endDate),
        }, {  responseType: 'blob', })
            .then(function (response) {
                saveAs(response.data, FileName);
                setIsLoading(false);
            })
            .catch(function (error) {

                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                console.log(error.response);
                setIsLoading(false);
            });
    }

    const ExportToExcel = async () => {

        const workbook = new ExcelJS.Workbook();

        try {

            setIsLoading(true);

            var data = $("#gvUnmatchedTxnsReportPDF").dataTable()._('tr', { "filter": "applied" });
            let TblCols = Object.keys(UnmatchedTxnsReport[0]).filter((item) => item !== 'futureActions').map((item) => ({ header: splitCamelCase(item), key: item }));
            let filterDataExcel = [];
            let cntrow = 0;
            let RefNum = '';
            let cardNumber = '';
            let remarks = '';


            for (let i = 0; i < data.length; i++) {
                var arr = `{${Object.keys(UnmatchedTxnsReport[cntrow]).filter((item) => item !== 'futureActions').map((tc) => (`"${tc}":${JSON.stringify(UnmatchedTxnsReport[i][tc] !== null ? UnmatchedTxnsReport[i][tc] : '')}`)).join(',')}}`
                // var arr = { "Channel": data[cntrow][0], "Mode": data[cntrow][1], "TerminalId": data[cntrow][2], "TxnDateTime": data[cntrow][3], "ReferenceNumber": RefNum, "AccountNo": data[cntrow][5], "TxnAmount": data[cntrow][6], "EJStatus": data[cntrow][7], "SwitchStatus": data[cntrow][8], "NetworkStatus": data[cntrow][9], "GLStatus": data[cntrow][10], "TxnsType": data[cntrow][11], "Remark": remarks }
                let obj = JSON.parse(arr);
                filterDataExcel.push(obj);
                cntrow++;
            }

            // Create Excel workbook and worksheet           
            const worksheet = workbook.addWorksheet('DisputeTxns');

            // Define columns in the worksheet, these columns are identified using a key.

            worksheet.columns = TblCols;

            worksheet.columns = TblCols.map((item) => ({ width: 10 }));



            // loop through all of the columns and set the alignment with width.
            worksheet.columns.forEach(column => {
                column.alignment = { horizontal: 'center' };
            });

            worksheet.columns.forEach(column => {
                if (selectedChannelValue.value === '4') {
                    if (column._number === 7) {
                        column.alignment = { horizontal: 'right' };
                    }
                } else if (selectedChannelValue.value === '7') {
                    if (column._number === 6) {
                        column.alignment = { horizontal: 'right' };
                    }
                } else {
                    if (column._number === 8) {
                        column.alignment = { horizontal: 'right' };
                    }
                }
            });


            // updated the font for first row.
            worksheet.getRow(1).font = { bold: true, color: { argb: 'ffffff' } };

            // loop through data and add each one to worksheet
            filterDataExcel.forEach(singleData => {
                worksheet.addRow(singleData);
            });

            // Add auto-filter on each column
            //worksheet.autoFilter = 'A1:D1';

            // Process each row for calculations and beautification 
            worksheet.eachRow((row, rowNumber) => {

                row.eachCell((cell, colNumber) => {
                    if (rowNumber === 1) {
                        // First set the background of header row
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: { argb: 'df5015' }
                        };
                    };
                    // Set border of each cell 
                    cell.border = {
                        top: { style: 'thin' },
                        left: { style: 'thin' },
                        bottom: { style: 'thin' },
                        right: { style: 'thin' }
                    };
                })
                //Commit the changed row to the stream
                row.commit();
            });

            //console.log(filterDataExcel);

            var today = new Date();
            var dateHeading = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear() + ' ' + today.getHours() + '_' + today.getMinutes() + '_' + today.getSeconds();
            // write the content using writeBuffer
            const buf = await workbook.xlsx.writeBuffer();

            // download the processed file
            saveAs(new Blob([buf]), 'Dispute Tracking Report ' + dateHeading + '.xlsx');

            setIsLoading(false);
        }
        catch (error) {
            console.error('<<<ERRROR>>>', error);
            console.error('Something Went Wrong', error.message);
        } finally {
            // removing worksheet's instance to create new one
            workbook.removeWorksheet('Unmatched');
        }
    };

    const DeleteAttachment = async (AttachmentDetails) => {

        await MaximusAxios.post('api/DMSReport/DeleteAttachmentFile', AttachmentDetails, {  mode: 'cors' })
            .then(function (response) {

                setIsLoading(false);
                OnShowAttachments();
                //setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Delete Status', alertMessage: response.data });

                setShowAttachments(true);
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Delete Status', alertMessage: 'No Record Found' });
                }

                setShowAttachments(false);
                setIsLoading(false);
            });


    }

    const DownloadAttachment = async (AttachmentDetails) => {

        await MaximusAxios.post('api/DMSReport/GetAttachmentFile', AttachmentDetails, {  responseType: 'blob', })
            .then(function (response) {

                setIsLoading(false);
                saveAs(response.data, AttachmentDetails.fileName)

                setShowAttachments(true);
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }

                setShowAttachments(false);
                setIsLoading(false);
            });


    }

    const OnShowAttachments = async (row) => {

        let ReferenceNumber = row !== undefined ? row.referenceNumber : disputeformData.ReferenceNumber;
        let TxnsDateTime = row !== undefined ? row.txnDateTime : disputeformData.TxnsDateTime;
        let DisputeID = row !== undefined ? row.disputeID : disputeformData.DisputeID;

        if (row !== undefined) {
            setDisputeformData({
                DisputeID: DisputeID,
                ReferenceNumber: ReferenceNumber,
                TxnsDateTime: formatDate(TxnsDateTime)
            });
        }

        await MaximusAxios.post('api/DMSReport/GetAttachmentsData', {
            DisputeID: DisputeID,
            TxnDateTime: formatDate(TxnsDateTime),
            ReferenceNumber: ReferenceNumber,
        }, {  mode: 'cors' })
            .then(function (response) {

                setIsLoading(false);
                let DataTable = [];
                if (response.data === null || response.data === undefined || response.data.length === 0) {

                    //setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'No Attachments Present' });
                    //return false;
                }
                else {
                    DataTable = response.data;
                }
                setAttachmentsTable(DataTable);
                setShowAttachments(true);
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }

                setShowAttachments(false);
                setIsLoading(false);
                return false;
            });


    }

    const BulkSubmitRemarks = async () => {

        let Data = checkboxValues.filter((item) => item.isChecked === true).map((rowitem) => (
            {
                DisputeID: rowitem.disputeID,
                TxnDateTime: formatDate(rowitem.txnDateTime),
                ReferenceNumber: rowitem.referenceNumber,
                CheckerStatus: { Remark: rowitem.checkerRemarks, Status: rowitem.checkerStatus },
                MakerStatus: { Remark: rowitem.makerRemarks, Status: rowitem.makerStatus }
            }
        ))
        await MaximusAxios.post('api/DMSReport/BulkSubmitRemarks', Data, {  mode: 'cors' })
            .then(function (response) {
                onSubmit();
                setIsLoading(false);
                setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Status Submit', alertMessage: 'Remarks Updated Successfully' });
                setDisputeAttachmentModal(false);
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }

                setDisputeAttachmentModal(false);
                setIsLoading(false);
            });

    }

    const SubmitRemarks = async () => {

        await MaximusAxios.post('api/DMSReport/SubmitRemarks', {
            DisputeID: disputeformData.DisputeID,
            TxnDateTime: formatDate(disputeformData.TxnsDateTime),
            ReferenceNumber: disputeformData.ReferenceNumber,
            CheckerStatus: checkerDisputeStatus,
            MakerStatus: makerDisputeStatus,
        }, {  mode: 'cors' })
            .then(function (response) {
                onSubmit();
                setIsLoading(false);
                setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Status Submit', alertMessage: 'Remarks Updated Successfully' });
                setDisputeAttachmentModal(false);
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }

                setDisputeAttachmentModal(false);
                setIsLoading(false);
            });

    }
    const OnSelectAll = (e) => {
        const Checked = e.target.checked;

        let Values = checkboxValues.map((item) => {
            return { ...item, isChecked: Checked };
        })
        setCheckboxValues(Values);


    }

    const OnChangeCheckBoxValues = (e, i) => {
        const Checked = e.target.checked;

        let Values = checkboxValues.map((item) => {
            if (item.id === i) {
                return { ...item, isChecked: Checked };
            }
            return { ...item };
        })

        setCheckboxValues(Values);
    }

    const OnFileUpload = async () => {

        if (currentUser !== null && currentUser.user !== null) {

            try {

                let alertMessages = "";


                if (importFile === null || importFile === undefined) {
                    alertMessages += 'Please select File. \n';
                }
                else if (importFile.length === 0) {
                    alertMessages += 'Please select File. \n';
                }

                if (alertMessages.length > 0) {
                    setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                    return false;
                }

                var arr = [];
                for (var i = 0; i < importFile.length; i++) {
                    arr.push(importFile[i]);
                }

                if (arr.length > 0) {

                    setIsLoading(true);

                    const posts = await Promise.all(arr.map(async (file) => {

                        const data = new FormData();
                        data.append('DisputeID', disputeformData.DisputeID);
                        data.append('ReferenceNumber', disputeformData.ReferenceNumber);
                        data.append('TxnsDateTime', disputeformData.TxnsDateTime);
                        data.append('Attachment', file);

                        //console.log(data);

                        return await axios.post("api/DMSReport/UploadDisputeAttachments", data, { headers: postHeader(), mode: 'cors' })
                            .then((res) => {
                                return res.data;
                            }, error => {
                                return `${error}`;
                            });
                    }));


                    if (posts !== null && posts.length > 0) {
                        posts.forEach((post) => {
                            alertMessages += `${post} \n`;
                        });

                    }
                    if (alertMessages.length > 0) {
                        setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "File Upload Status", alertMessage: alertMessages });
                    }
                    setImportFile(null);
                    OnShowAttachments()
                    setIsLoading(false);
                }
            }
            catch (ex) {
                console.log(ex);
                setIsLoading(false);
            }
        }
        else {
            alert('Session Timeout');
        }
    }
    const handleuploadFile = async (files) => {
        setImportFile(files);
        var FileNames = '';
        for (var i = 0; i < files.length; i++) {
            FileNames = FileNames + files[i].name + ", ";
        }
        if (files.length === 0) {
            setFileName('No File Found');
        }
        else if (files.length > 1)
            setFileName(`Files Count ${files.length}`);
        else
            setFileName(FileNames);
    }

    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    GL Recon Report
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Audit Report</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">GL Recon Report</p>
                </div>
            </div>
            {/* Config Tabs */}
            <>
                <div className="configLeftTop">
                    <div className="accordion" id="unmatchedFilters">
                        <div className="accordion-item">
                            <div
                                className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                                id="unmatchedFiltersHeading"
                            >
                                <h6 className="fontWeight-600 colorBlack">Filters</h6>
                                <button
                                    className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                    type="button"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#unmatchedFiltersCollapse"
                                    aria-expanded="true"
                                    aria-controls="unmatchedFiltersCollapse"
                                >
                                    <span className="icon-Hide"></span>
                                    <span className="ms-1 fontSize12-m colorBlack">
                                        Show / Hide
                                    </span>
                                </button>
                            </div>
                            <div
                                id="unmatchedFiltersCollapse"
                                className="accordion-collapse collapse show"
                                aria-labelledby="unmatchedFiltersHeading"
                                data-bs-parent="#unmatchedFilters"
                            >
                                <div className="accordion-body">
                                    <div className="hrGreyLine"></div>
                                    <div className="configSelectBoxTop row">
                                        <div className="clientNameSelect col">
                                            <label htmlFor="clientName">Client Name</label>
                                            <span className="text-danger font-size13">*</span>
                                            <AsyncSelect
                                                cacheOptions
                                                defaultOptions
                                                value={selectedValue}
                                                getOptionLabel={e => e.clientName}
                                                getOptionValue={e => e.clientID}
                                                loadOptions={fetchClientData}
                                                onInputChange={handleInputChange}
                                                onChange={handleClientChange}
                                                id="ddlClient"
                                            />
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="ddlChannel">Channel Type</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlChannel"
                                                value={selectedChannelValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsChannelType.map(x => (
                                                    {
                                                        value: x.channelID,
                                                        label: x.channelName
                                                    }
                                                ))}
                                                onChange={handleChannelChange}
                                            />
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="ddlMode">Mode Type</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlMode"
                                                value={selectedModeValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsModeType.map(x => (
                                                    {
                                                        value: x.modeID,
                                                        label: x.modeName
                                                    }
                                                ))}
                                                onChange={handleModeChange}
                                            />
                                        </div>
                                        <div className="clientNameSelect col" id="dvTxnType">
                                            <label htmlFor="logType">Network Type</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                defaultValue={selectedNetworkValue}
                                                options={optionsNetworkType}
                                                id="ddlTxnType"
                                                onChange={handleTxnTypeChange}
                                                classNamePrefix="reactSelectBox"
                                            />
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="StartDate">From Date</label>
                                            <span className="text-danger font-size13">*</span>
                                            <DatePicker
                                                renderCustomHeader={({
                                                    date,
                                                    changeYear,
                                                    changeMonth,
                                                    decreaseMonth,
                                                    increaseMonth,
                                                    prevMonthButtonDisabled,
                                                    nextMonthButtonDisabled,
                                                }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                                selected={startDate}
                                                dateFormat="dd/MM/yyyy"
                                                onChange={(date) => setStartDateValue(date)}
                                                className="reportDate"
                                                maxDate={new Date()}
                                            />
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="ToDate">To Date</label>
                                            <span className="text-danger font-size13">*</span>
                                            <DatePicker
                                                renderCustomHeader={({
                                                    date,
                                                    changeYear,
                                                    changeMonth,
                                                    decreaseMonth,
                                                    increaseMonth,
                                                    prevMonthButtonDisabled,
                                                    nextMonthButtonDisabled,
                                                }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                                selected={endDate}
                                                dateFormat="dd/MM/yyyy"
                                                onChange={(date) => setEndDateValue(date)}
                                                className="reportDate"
                                                maxDate={new Date()}
                                            />
                                        </div>
                                    </div>

                                    <div className="text-center btnsBtm">
                                        <button
                                            type="button"
                                            className="btnPrimaryOutline"
                                            onClick={(e) => onReset(e)}
                                        >
                                            Reset
                                        </button>
                                        <button
                                            type="button"
                                            className="btnPrimary ms-2"
                                            onClick={onSubmit}
                                            disabled={isShow}
                                        >
                                            Show
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                {/* Bottom Content */}
                <div className="configLeftBottom">
                    {(UnmatchedTxnsReport === null || UnmatchedTxnsReport.length === 0) &&
                        <div className="tableBorderBox pb-3 pt-3">
                            <div className="clientNameSelect configFormatEntities">
                                <p className="text-danger font-size12">No Records</p>
                            </div>
                        </div>
                    }
                    {/* Table */}
                    {(UnmatchedTxnsReport !== null && UnmatchedTxnsReport.length > 0) ? (
                        <div className="DisputeTable">                           
                            <div className="tableBorderBox pt-3">
                                <div className="DisputeTable exportButton">
                                    <OverlayTrigger
                                        placement="top"
                                        delay={{ show: 150, hide: 400 }}
                                        overlay={renderTooltipExcel}
                                    >
                                        <button type="button" className="iconButtonBox" onClick={ExportToExcelKS}>
                                            <img src={ExcelIcon} alt="Excel" />
                                        </button>
                                    </OverlayTrigger>

                                    <OverlayTrigger
                                        placement="top"
                                        delay={{ show: 150, hide: 400 }}
                                        overlay={renderTooltip}
                                    >
                                        <button type="button" className="iconButtonBox" onClick={downloadPDF} >
                                            <img src={Pdf} alt="Pdf" />
                                        </button>
                                    </OverlayTrigger>
                                </div>

                                <div className="w-100 table-responsive">
                                    <div className="tableContentBox" >
                                        <table id="gvUnmatchedTxnsReportPDF" className="table table-striped table-hover table-borderless align-middle">
                                            <thead>
                                                <tr >                                                   
                                                    {
                                                        Object.keys(UnmatchedTxnsReport[0]).map((item) => {
                                                            if (item === 'futureActions') {
                                                                return (<></>);

                                                            }                                                            
                                                            else {
                                                                return (<th key={item} scope="col">{splitCamelCase(item)}</th>);
                                                            }
                                                        })
                                                    }
                                                </tr>
                                            </thead>
                                            <tbody className="table-responsive">
                                                {UnmatchedTxnsReport.map((row, rowindex) => (
                                                    <tr key={rowindex}>                                                       
                                                        {
                                                            Object.keys(row).map((column, colindex) => {
                                                                if (column === 'futureActions') {
                                                                    return (<></>);
                                                                }                                                               
                                                                else {

                                                                    return (
                                                                        <td key={`${rowindex}${colindex}`}>{row[column]}</td>
                                                                    )
                                                                }
                                                            })
                                                        }
                                                    </tr>
                                                ))
                                                }

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : null}
                    {/* Save Filters */}
                    {referenceNo && (
                        <Modal
                            show={referenceNo}
                            onHide={() => setReferenceNo(!referenceNo)}
                            centered
                            className="defaultThemeModal saveFiltersModal reportTableModal"
                        >
                            <Modal.Header closeButton>
                                <Modal.Title className="fontSize16-sm letterSpacing-2">
                                    Dispute Details
                                </Modal.Title>
                            </Modal.Header>
                            <Modal.Body className="text-center">
                                <div className="w-100 table-responsive">
                                    <div style={{ display: 'flex', flexDirection: 'column', margin: '20px 0' }}>
                                        <table className="table table-striped table-hover table-borderless align-middle">
                                            <thead>
                                                <tr>
                                                    <th>Attachments</th>
                                                    {
                                                        Object.keys(DisputeTxnList[0]).map((item) => {
                                                            return (<th key={item} scope="col">{splitCamelCase(item)}</th>);
                                                        })
                                                    }
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {DisputeTxnList.map((row, rowindex) => (
                                                    <tr key={rowindex}>
                                                        <td>
                                                            <div className="clientNameSelect col">
                                                                <span>
                                                                    <button type="button" className="iconButtonBox" onClick={() => (OnShowAttachments(row))} >
                                                                        <img style={{ width: '24px', height: '24px' }} src={AttachmentsIcon} alt="Attachments" />
                                                                    </button>
                                                                </span>
                                                            </div>
                                                        </td>
                                                        {
                                                            Object.keys(row).map((column, colindex) => (
                                                                <td key={`${rowindex}${colindex}`}>{row[column]}</td>
                                                            ))
                                                        }
                                                    </tr>
                                                ))
                                                }

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </Modal.Body>
                        </Modal>
                    )}                   
                </div>
                <LoadingSpinner isShow={isShow} />
                <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
            </>
        </div>
    )

}

export default DisputeRaiseTrackingMain;