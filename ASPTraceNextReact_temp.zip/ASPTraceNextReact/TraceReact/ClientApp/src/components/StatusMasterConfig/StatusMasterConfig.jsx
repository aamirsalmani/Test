﻿import React from "react";
import { useSelector } from "react-redux";
// Components
import "./StatusMasterConfig.css";
import SidebarMain from "../common/SidebarMain";
import StatusMasterConfigMainWindow from "./StatusMasterConfigMainWindow";

const StatusMasterConfig = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <StatusMasterConfigMainWindow />
        </div>
    );
};

export default StatusMasterConfig;
