﻿import React, { useRef, useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import Select from "react-select";
import { Modal, Button, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL";
import AsyncSelect from 'react-select/async';
import axios from 'axios';
import MessageBox from "../common/MessageBox";
import "datatables.net-dt/js/dataTables.dataTables"
import "datatables.net-dt/css/jquery.dataTables.min.css"
import 'jquery/dist/jquery.min.js';
import { useSelector } from "react-redux";
import Delete from "../../images/common/redDelete.svg";
import editRow from "../../images/common/editRow.svg";
import ExcelIcon from "../../images/common/excel_small.svg";
import fileupload from "../../images/common/fileuploadicon.svg";
import * as XLSX from 'xlsx';
import postHeader from "../../pages/login/services/post-header";

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

import ExcelJS from "exceljs";
import { saveAs } from 'file-saver';
import LoadingSpinner from "../common/LoadingSpinner";

const StatusMasterMainWindow = () => {

    const [Show, setShow] = useState(false);
    const fileInputRef = useRef(null);

    const triggerFileInput = () => {
        fileInputRef.current.click();
    };

    const [showModal, setShowModal] = useState(false);
    const [ShowGrid, setShowGrid] = useState(false);
    const currentUser = useSelector((state) => state.authReducer);
    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });
    const [Change, setChange] = useState(true);
    const [selectedClientValue, setSelectedClientValue] = useState(null);

    const [inputValue, setValue] = useState('0');
    const [optionsChannelType, setOptionsChannelType] = useState([{ channelID: "0", channelName: "ALL" }]);
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);
    const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "ALL" }]);
    const [optionsStatusType, setOptionsStatusTypeValue] = useState([{ statusID: "0", statusName: "ALL" }]);
    const [selectedModeValue, setSelectedModeValue] = useState(null);
    const [selectedReconType, setSelectedReconType] = useState(null);

    const [NewEntry, setNewEntry] = useState(false);
    const [EditEntry, setEditEntry] = useState(false);

    const [EditChannel, setEditChannel] = useState(null);
    const [EditMode, setEditMode] = useState(null);
    const [EditReconType, setEditReconType] = useState(null);
    const [selectedEJType, setSelectedEJType] = useState(null);
    const [selectedGLType, setSelectedGLType] = useState(null);
    const [selectedSWType, setSelectedSWType] = useState(null);
    const [selectedNWType, setSelectedNWType] = useState(null);

    
    const defaultFilter = { value: "0", label: "ALL" };
    const [selectedEJFilter, setSelectedEJFilter] = useState(defaultFilter);
    const [selectedGLFilter, setSelectedGLFilter] = useState(defaultFilter);
    const [selectedSWFilter, setSelectedSWFilter] = useState(defaultFilter);
    const [selectedNWFilter, setSelectedNWFilter] = useState(defaultFilter);

    const [selectedRemark, setSelectedRemark] = useState("");
    const [selectedSettledRemark, setSelectedSettledRemark] = useState(null);

    const [StatusMasterData, setStatusMasterData] = useState([]);

    const optionsReconType = [
        { reconID: '0', reconName: 'ALL' },
        { reconID: '2', reconName: '2' },
        { reconID: '3', reconName: '3' },
        { reconID: '4', reconName: '4' }
    ];
    const optionsSettelRemark = [
        { settelID: '0', settelRemark: 'Successful' },
        { settelID: '1', settelRemark: 'Reversal' },
        { settelID: '2', settelRemark: 'Unsuccessful' },
        { settelID: '3', settelRemark: 'Unmatched' },
        { settelID: '4', settelRemark: 'Deemed Successful' }
    ];


    function splitCamelCase(str) {
        // Split the string at each capital letter
        const words = str.split(/(?=[A-Z])/);
        // Capitalize the first letter of each word and join them with a space
        const result = words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
        return result;
    }
    const onShowClick = () => {
        setStatusMasterData([])
        setShowGrid(false);
        let alertMessages = "";

        if (selectedClientValue === null || selectedClientValue === undefined) {
            alertMessages += "Please select client. \n";
        }
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            alertMessages += "Please select Channel. \n";
        }
        else if (selectedModeValue === undefined || selectedModeValue === null) {
            alertMessages += "Please select mode Type. \n";
        }
        else if (selectedReconType === undefined || selectedReconType === null) {
            alertMessages += "Please select recon Type. \n";
        }
        if (alertMessages.length > 0) {
            setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
            return false;
        }
        CheckSelectedValues();
        setIsLoading(true);
        MaximusAxios.post('api/DynamicStatusConfig/GetDynamicStatusDataList', {
            ClientID: String(selectedClientValue.clientID),
            ChannelID: String(selectedChannelValue.value),
            ModeID: String(selectedModeValue.value),
            ReconType: selectedReconType.value,
            EJFilter:selectedEJFilter.value,
            GLFilter:selectedGLFilter.value,
            SWFilter:selectedSWFilter.value,
            NWFilter:selectedNWFilter.value,
            // UserName: currentUser.user.username,
        }, { mode: 'cors' })
            .then(function (response) {
                const parsedData = response.data.map(row => {
                    let Data = Object.keys(row).map((tc) => {
                        return `"${tc}":${row[tc]}`;
                    }).join(',');
                    let FinalObj = JSON.parse(`{${Data}}`);
                    return { ...row, ...FinalObj }

                });
                if(parsedData.length > 0 )
                {
                    console.log(parsedData.length);
                    setStatusMasterData(parsedData);
                    
                    setShowGrid(true);
                    setIsLoading(false);
                }
                else if(selectedEJFilter.value == '0' && selectedGLFilter.value == '0' && selectedSWFilter.value == '0' && selectedNWFilter.value == '0')
                {
                    const userConfirmed = window.confirm("No Records Found! Do you want to set default Status?");
  
                    if (userConfirmed) 
                    {
                        MaximusAxios.post('api/DynamicStatusConfig/SetDefaultStatus',{
                            ClientID: String(selectedClientValue.clientID),
                            ChannelID: String(selectedChannelValue.value),
                            ModeID: String(selectedModeValue.value),
                            ReconType: selectedReconType.value
                        }, { mode: 'cors' }).then(resultMode => {
                            if(resultMode.data ==='1')
                            {
                                alert("Default status has been set.");
                            }
                            else
                            {
                                alert('Error occurred.');
                            }
                        });
                    }
                    setIsLoading(false);
                }
                else
                {
                    alert("No Records Found!");
                    setIsLoading(false);
                }
            })
            .catch(function (error) {
                console.log(error.response);
                setIsLoading(false);
            });
    };

    const handleInputChange = value => {
        setValue(value);
    };

    const fetchClientData = (inputValue) => {
        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, { mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    const handleClientChange = value => {
        setShow(false);
        setSelectedClientValue(value);
        setSelectedChannelValue(null);
        setSelectedModeValue(null);
        setSelectedReconType(null);
        setStatusMasterData([]);
        try {

            setIsLoading(true);

            if (value.clientID !== '0') {

                MaximusAxios.get('api/DynamicFileConfig/GetChannelOptionList?ClientID=' + value.clientID, { mode: 'cors' }).then(resultChannel => {

                    setOptionsChannelType(resultChannel.data);
                    setIsLoading(false);
                });
            }
        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }
    }
    const handleChannelChange = value => {
        setShow(false);
        setSelectedChannelValue(value);
        setSelectedModeValue(null);
        setSelectedReconType(null);
        setStatusMasterData([]);

        let ChannelId = 0;
        if (value === undefined || value === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = value.value;
        }
        setIsLoading(true);
        MaximusAxios.get('api/DynamicFileConfig/GetDynamicModeOptionList?ClientID=' + selectedClientValue.clientID + '&ChannelID=' + ChannelId, { mode: 'cors' }).then(resultMode => {
            setOptionsModeTypeValue(resultMode.data);
        });
        setIsLoading(false);
    }
    const handleModeChange = value => {
        setShow(false);
        setSelectedModeValue(value);
        setSelectedReconType(null);
        setStatusMasterData([]);
    }
    const handleReconChange = value => {
        setShow(false);
        MaximusAxios.get('api/DynamicStatusConfig/GetDynamicFileStatusList', { mode: 'cors' }).then(resultMode => {
            const finalOptions = [{ statusID: "0", statusName: "ALL" }, ...resultMode.data];
            setOptionsStatusTypeValue(finalOptions);
        });

        setSelectedEJFilter(defaultFilter);
        setSelectedGLFilter(defaultFilter);
        setSelectedSWFilter(defaultFilter);
        setSelectedNWFilter(defaultFilter);
        setStatusMasterData([]);
        setSelectedReconType(value);
    }

    const handleEJFilter = value => {
        setShow(false);
        setSelectedEJFilter(value);
        setStatusMasterData([]);
    }
    const handleGLFilter = value => {
        setShow(false);
        setSelectedGLFilter(value);
        setStatusMasterData([]);
    }
    const handleSWFilter = value => {
        setShow(false);
        setSelectedSWFilter(value);
        setStatusMasterData([]);
    }
    const handleNWFilter = value => {
        setShow(false);
        setSelectedNWFilter(value);
        setStatusMasterData([]);
    }


    const handleSettelRemarks = value => {
        setSelectedSettledRemark(value);
    }
    const handleEJChange = value => { setSelectedEJType(value); }
    const handleGLChange = value => { setSelectedGLType(value); }
    const handleSWChange = value => { setSelectedSWType(value); }
    const handleNWChange = value => { setSelectedNWType(value); }

    const onDeleteClick = (item) => {
        if (window.confirm("Are you sure you want to delete.")) {
            MaximusAxios.post('api/DynamicStatusConfig/DeleteDynamicStatus', {
                ClientID: String(item.clientID.value),
                ChannelID: String(item.channelID.value),
                ModeID: String(item.modeID.value),
                ReconType: String(item.reconType.value),
                EJStatus: String(item.ejStatus.value),
                GLStatus: String(item.glStatus.value),
                SwitchStatus: String(item.switchStatus.value),
                NetworkStatus: String(item.networkStatus.value),
                Remarks: item.remarks.value,
                SettledRemarks: item.settledRemarks.value,
                UserName: currentUser.user.username,
            }, { mode: 'cors' })
                .then(response => {
                    if (response.data === "" || response.data.length > 0) {
                        alert('Configuration deleted successfully!');
                        onShowClick();
                    }
                })
                .catch(error => {
                    if (error.response) {
                        console.log(error.response.data);
                        alert('Configuration deleted failed!');
                        onShowClick();
                    }
                });
        }
    };

    const onEditClick = (item) => {
        try {
            setSelectedSettledRemark(item.settledRemarks);
            setEditChannel(item.channelID);
            setEditMode(item.modeID);
            setEditReconType(item.reconType);
            setSelectedEJType(item.ejStatus);
            setSelectedGLType(item.glStatus);
            setSelectedSWType(item.switchStatus);
            setSelectedNWType(item.networkStatus);
            setSelectedRemark(item.remarks.value);


            if (window.confirm("Are you sure you want to Update.")) {
                let alertMessages = "";


                if (selectedChannelValue === '0' || selectedChannelValue === null) {
                    alertMessages += "You cannot add configuration to all Channel. \n";
                }
                if (selectedModeValue === '0' || selectedModeValue === 'ALL') {
                    alertMessages += "You cannot add configuration to all  modes. \n";
                }
                if (selectedReconType === '0' || selectedReconType === 'ALL') {
                    alertMessages += "You cannot add configuration to all  recon Type. \n";
                }

                if (alertMessages.length > 0) {
                    setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                    return false;
                }

                setNewEntry(false);
                setEditEntry(true);
                setShowModal(true);
            }
        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }
    }
    const onSubmit = () => {
        try {
            MaximusAxios.post('api/DynamicStatusConfig/UpdateDynamicStatus', {
                ClientID: String(selectedClientValue.clientID),
                ChannelID: String(EditChannel.value),
                ModeID: String(EditMode.value),
                ReconType: String(EditReconType.value),
                ejStatus: String(selectedEJType.value),
                glStatus: String(selectedGLType.value),
                switchStatus: String(selectedSWType.value),
                networkStatus: String(selectedNWType.value),
                remarks: selectedRemark,
                settledRemarks: selectedSettledRemark.label,
                UserName: currentUser.user.username,
            }, { mode: 'cors' })
                .then(response => {
                    if (response.data !== "" || response.data.length > 0) {
                        alert('Updation failed');
                        setEditEntry(false);
                        setShowModal(false);
                        onShowClick();
                    }
                    else if (response.data === "" || response.data.length == 0) {
                        alert('Configuration  updated successfully');
                        setEditEntry(false);
                        setShowModal(false);
                        onShowClick();
                    }
                })
                .catch(error => {
                    if (error.response) {
                        console.log(error.response.data);
                    }
                });
        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }

    }

    const onNewClick = () => {
        let alertMessages = "";


        if (selectedClientValue === null || selectedClientValue === undefined) {
            alertMessages += "Please select client. \n";
        }
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            alertMessages += "Please select Channel. \n";
        }
        else if (selectedChannelValue.value === 0 || selectedChannelValue.label === 'ALL') {
            alertMessages += "You cannot add configuration to all Channel. \n";
        }
        else if (selectedModeValue === undefined || selectedModeValue === null) {
            alertMessages += "Please select mode Type. \n";
        }
        else if (selectedModeValue.value === 0 || selectedModeValue.label === 'ALL') {
            alertMessages += "You cannot add configuration to all  modes. \n";
        }
        else if (selectedReconType === undefined || selectedReconType === null) {
            alertMessages += "Please select recon Type. \n";
        }
        else if (selectedReconType.value === 0 || selectedReconType.label === 'ALL') {
            alertMessages += "You cannot add configuration to all  recon Type. \n";
        }

        if (alertMessages.length > 0) {
            setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
            return false;
        }

        setSelectedEJType(null);
        setSelectedGLType(null);
        setSelectedSWType(null);
        setSelectedNWType(null);
        setSelectedRemark(null);
        setSelectedSettledRemark(null);

        setIsLoading(true);
        MaximusAxios.get('api/DynamicStatusConfig/GetDynamicFileStatusList', { mode: 'cors' }).then(resultMode => {
            setOptionsStatusTypeValue(resultMode.data);
        });

        onShowClick();
        setIsLoading(false);
        setEditEntry(false);
        setNewEntry(true);
        setShowModal(true);

    };

    const handleDownload = async () => {
        try {
            const response = await MaximusAxios.get('api/DynamicStatusConfig/GetDynamicFileStatusList', { mode: 'cors' });
            const data = response.data;

            const formattedData = data.map(x => ({
                statusId: x.statusID,
                statusName: x.statusName,
            }));

            const demoSheetData = [
                { EJStatus: '1', GLStatus: '1', SWStatus: '1', NWStatus: '1', Remarks: ' Successful transaction', SettledRemarks: ' Successful transaction' },
                { EJStatus: '10', GLStatus: '4', SWStatus: '1', NWStatus: '2', Remarks: ' Reversal transaction, no action requires', SettledRemarks: ' Reversal transaction' },
                {},
                { EJStatus: 'Please select ClientId, ChannelId,ModeId, ReconType before file upload.' },
            ];

            const worksheet1 = XLSX.utils.json_to_sheet(demoSheetData);

            const worksheet2 = XLSX.utils.json_to_sheet(formattedData);

            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet1, 'Sheet1');
            XLSX.utils.book_append_sheet(workbook, worksheet2, 'Sheet2');
            XLSX.writeFile(workbook, 'example.xlsx');
        } catch (error) {
            console.error('Error fetching data from API', error);
        }
    };

    const handleUpload = (e) => {
        setIsLoading(true);
        const file = e.target.files[0];
        if (file) {
            const fileExtension = file.name.split('.').pop().toLowerCase();
            const allowedExtensions = ['xls', 'xlsx'];
            if (!allowedExtensions.includes(fileExtension)) {
                alert('Please upload an Excel file.');
                setIsLoading(false);
                return;
            }
            const reader = new FileReader();
            reader.onload = async (e) => {


                try {
                    const formData = new FormData();
                    formData.append('file', file);
                    formData.append('ClientID', String(selectedClientValue.clientID));
                    formData.append('ChannelID', String(selectedChannelValue.value));
                    formData.append('ModeID', String(selectedModeValue.value));
                    formData.append('ReconType', String(selectedReconType.value));
                    const response = await axios.post('api/DynamicStatusConfig/UploadExcelFile', formData, { headers: postHeader(), mode: 'cors' });
                    if (response.data && response.data.toString().includes('Successful')) {
                        window.alert(response.data.toString());
                    }
                    else window.alert(response.data.toString());
                    setIsLoading(false);
                    setChange(!Change);
                } catch (error) {
                    console.error('Error uploading file to API', error);
                    setIsLoading(false);
                    setChange(!Change);
                }
            };
            reader.readAsArrayBuffer(file);
        }
    };

    const ExportToExcel = async () => {

        const workbook = new ExcelJS.Workbook();

        try {

            setIsLoading(true);

            var data = $("#gvUnmatchedTxnsReportPDF").dataTable()._('tr', { "filter": "applied" });
            let TblCols = Object.keys(StatusMasterData[0]).filter((item) => item !== 'userName').map((item) => {
                return { header: splitCamelCase(item), key: item };
            });
            let filterDataExcel = [];
            let cntrow = 0;
            let RefNum = '';
            let cardNumber = '';
            let remarks = '';


            for (let i = 0; i < data.length; i++) {
                var arr = `{${Object.keys(StatusMasterData[cntrow]).filter((item) => item !== 'futureActions').map((tc) => (`"${tc}":${JSON.stringify(StatusMasterData[i][tc] !== null && StatusMasterData[i][tc] !== 'userName' ? StatusMasterData[i][tc].label : '')}`)).join(',')}}`
                // var arr = { "Channel": data[cntrow][0], "Mode": data[cntrow][1], "TerminalId": data[cntrow][2], "TxnDateTime": data[cntrow][3], "ReferenceNumber": RefNum, "AccountNo": data[cntrow][5], "TxnAmount": data[cntrow][6], "EJStatus": data[cntrow][7], "SwitchStatus": data[cntrow][8], "NetworkStatus": data[cntrow][9], "GLStatus": data[cntrow][10], "TxnsType": data[cntrow][11], "Remark": remarks }
                let obj = JSON.parse(arr);
                filterDataExcel.push(obj);
                cntrow++;
            }

            // Create Excel workbook and worksheet           
            const worksheet = workbook.addWorksheet('StatusMaster');

            // Define columns in the worksheet, these columns are identified using a key.

            worksheet.columns = TblCols;

            worksheet.columns = TblCols.map((item) => ({ width: 10 }));



            // loop through all of the columns and set the alignment with width.
            worksheet.columns.forEach(column => {
                column.alignment = { horizontal: 'center' };
            });

            worksheet.columns.forEach(column => {
                if (selectedChannelValue.value === '4') {
                    if (column._number === 7) {
                        column.alignment = { horizontal: 'right' };
                    }
                } else if (selectedChannelValue.value === '7') {
                    if (column._number === 6) {
                        column.alignment = { horizontal: 'right' };
                    }
                } else {
                    if (column._number === 8) {
                        column.alignment = { horizontal: 'right' };
                    }
                }
            });


            // updated the font for first row.
            worksheet.getRow(1).font = { bold: true, color: { argb: 'ffffff' } };

            // loop through data and add each one to worksheet
            filterDataExcel.forEach(singleData => {
                worksheet.addRow(singleData);
            });

            // Add auto-filter on each column
            //worksheet.autoFilter = 'A1:D1';

            // Process each row for calculations and beautification 
            worksheet.eachRow((row, rowNumber) => {

                row.eachCell((cell, colNumber) => {
                    if (rowNumber === 1) {
                        // First set the background of header row
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: { argb: 'df5015' }
                        };
                    };
                    // Set border of each cell 
                    cell.border = {
                        top: { style: 'thin' },
                        left: { style: 'thin' },
                        bottom: { style: 'thin' },
                        right: { style: 'thin' }
                    };
                })
                //Commit the changed row to the stream
                row.commit();
            });

            //console.log(filterDataExcel);

            var today = new Date();
            var dateHeading = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear() + ' ' + today.getHours() + '_' + today.getMinutes() + '_' + today.getSeconds();
            // write the content using writeBuffer
            const buf = await workbook.xlsx.writeBuffer();

            // download the processed file
            saveAs(new Blob([buf]), 'StatusMaster Report ' + dateHeading + '.xlsx');

            setIsLoading(false);
        }
        catch (error) {
            console.error('<<<ERRROR>>>', error);
            console.error('Something Went Wrong', error.message);
        } finally {
            // removing worksheet's instance to create new one
            workbook.removeWorksheet('Unmatched');
        }
    };

    const renderTooltipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to excel
        </Tooltip>
    );

    const onProceed = () => {
        try {
            let alertMessages = "";

            if (selectedEJType === undefined || selectedEJType === null) {
                alertMessages += "Please select EJ Status. \n";
            }
            if (selectedGLType === undefined || selectedGLType === null) {
                alertMessages += "Please select GL Status. \n";
            }
            if (selectedSWType === undefined || selectedSWType === null) {
                alertMessages += "Please select Switch Status. \n";
            }
            if (selectedNWType === undefined || selectedNWType === null) {
                alertMessages += "Please select Network Status. \n";
            }
            if (selectedRemark === undefined || selectedRemark === null) {
                alertMessages += "Please Enter Remark. \n";
            }
            if (selectedSettledRemark === undefined || selectedSettledRemark === null) {
                alertMessages += "Please Enter Remark. \n";
            }
            if (alertMessages.length > 0) {
                setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                return false;
            }
            else {
                MaximusAxios.post('api/DynamicStatusConfig/AddDynamicStatus', {
                    ClientID: selectedClientValue.clientID,
                    ChannelID: selectedChannelValue.value,
                    ModeID: selectedModeValue.value,
                    ReconType: selectedReconType.value,
                    ejStatus: selectedEJType.value,
                    glStatus: selectedGLType.value,
                    switchStatus: selectedSWType.value,
                    networkStatus: selectedNWType.value,
                    remarks: selectedRemark,
                    settledRemarks: selectedSettledRemark.label,
                    UserName: currentUser.user.username,
                }, { mode: 'cors' })
                    .then(response => {
                        if (response.data === 1 || response.data.length > 0) {
                            alert('Configuration already exists');
                            setNewEntry(false);
                            setShowModal(false);
                            setChange(!Change);
                        }
                        else if (response.data === "" || response.data.length > 0) {
                            alert('New Configuration configured successfully!');
                            setNewEntry(false);
                            setShowModal(false);
                            setChange(!Change);
                        }
                    })
                    .catch(error => {
                        if (error.response) {
                            console.log(error.response.data);
                        }
                    });
            }
        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }

    }

    const onCancelClick = () => {

        setChange(!Change);
        setNewEntry(false);
        setShowModal(false);
    };

    const CheckSelectedValues = () => {
        let Count = 0;
        if (selectedClientValue === null || selectedClientValue === undefined) {
            Count++;
        }
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            Count++;
        }
        else if (selectedChannelValue.value === 0 || selectedChannelValue.label === 'ALL') {
            Count++;
        }
        else if (selectedModeValue === undefined || selectedModeValue === null) {
            Count++;
        }
        else if (selectedModeValue.value === 0 || selectedModeValue.label === 'ALL') {
            Count++;
        }
        else if (selectedReconType === undefined || selectedReconType === null) {
            Count++;
        }
        else if (selectedReconType.value === 0 || selectedReconType.label === 'ALL') {
            Count++;
        }
        if (Count === 0) {
            setShow(true);
        }
        else {
            setShow(false);
        }
    };

    const onResetFilter = (e) => {
        e.preventDefault();
        setShow(false);
        setSelectedClientValue(null);
        setSelectedChannelValue(null);
        setSelectedModeValue(null);
        setSelectedReconType(null);
        setSelectedEJFilter(defaultFilter);
        setSelectedGLFilter(defaultFilter);
        setSelectedSWFilter(defaultFilter);
        setSelectedNWFilter(defaultFilter);
        setStatusMasterData([])
       // window.location.reload(false);
    }

    const onReset=(e)=>{
        setSelectedEJType(null);
        setSelectedGLType(null);
        setSelectedSWType(null);
        setSelectedNWType(null);
        setSelectedRemark("");
        setSelectedSettledRemark(null);
    }

    $(document).ready(function () {

        if (StatusMasterData !== null && StatusMasterData.length > 0) {
            $('#gvUnmatchedTxnsReportPDF').DataTable();
        }
    });

    return (
        <div className="configLeft dynamicContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Dynamic Status Configuration
                </h5>
                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Status Configuration</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Dynamic Status Configuration</p>
                </div>
            </div>
            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="unmatchedFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="unmatchedFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>




                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#unmatchedFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="unmatchedFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="unmatchedFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="unmatchedFiltersHeading"
                            data-bs-parent="#unmatchedFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedClientValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedChannelValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            onChange={handleChannelChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedModeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.modeName
                                                }
                                            ))}
                                            onChange={handleModeChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Recon Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedReconType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsReconType.map(x => (
                                                {
                                                    value: x.reconID,
                                                    label: x.reconName
                                                }
                                            ))}
                                            onChange={handleReconChange}
                                        />
                                    </div>

                                    {/* --------------------------- Optional Filters ------------------------------- */}

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">EJ Status</label>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedEJFilter}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            onChange={handleEJFilter}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Gl Status</label>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedGLFilter}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            onChange={handleGLFilter}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Switch Status</label>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedSWFilter}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            onChange={handleSWFilter}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Network Status</label>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedNWFilter}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            onChange={handleNWFilter}
                                        />
                                    </div>

                                    {/* --------------------------- Optional Filters ------------------------------- */}
                                </div>

                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onResetFilter(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onShowClick}
                                        disabled={isShow}
                                    >Show
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onNewClick}
                                        disabled={isShow}
                                    >Add New
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div className="configLeftBottomStatus">
                {(StatusMasterData !== null || StatusMasterData.length !== 0)  &&
                    <div style={{ paddingTop: '10px' }}>
                        <button type="button" className="btn btn-light" onClick={handleDownload} style={{ backgroundColor: 'white', height: '40px', border: '0.5px solid black', padding: '5px 10px', borderRadius: '5px', marginRight: '10px' }}>
                            <img src={ExcelIcon} alt="Edit" title="Download Sample Excel" /> <span style={{ fontSize: '14px', fontWeight: 'bold' }}>Download Sample Excel</span>
                        </button>

                        <input
                            type="file"
                            className="btn btn-light"
                            ref={fileInputRef}
                            style={{ display: 'none' }}
                            onChange={handleUpload}
                        />

                        <button onClick={triggerFileInput} style={{ backgroundColor: 'white', height: '40px', border: '0.5px solid black', padding: '5px 10px', borderRadius: '5px', marginLeft: '10px' }}>
                            <img src={fileupload} alt="Edit" title="Upload Excel File" /> <span style={{ fontSize: '14px', fontWeight: 'bold' }}>Upload Excel File</span>
                        </button>
                        <div className="DisputeTable exportButton">
                            <OverlayTrigger
                                placement="top"
                                delay={{ show: 150, hide: 400 }}
                                overlay={renderTooltipExcel}
                            >
                                <button type="button" className="iconButtonBox" onClick={ExportToExcel}>
                                    <img src={ExcelIcon} alt="Excel" />
                                </button>
                            </OverlayTrigger>
                        </div>
                    </div>
                }
            </div>
            {/* Data Grid*/}
            <div className="configLeftBottom">
                <div>
                {(StatusMasterData === null || StatusMasterData.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>

          {(StatusMasterData !== null && StatusMasterData.length > 0) ? (
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="tableContentBox" >
                                    <table id="gvUnmatchedTxnsReportPDF" className="table table-striped table-hover table-borderless align-middle">
                                        <thead>
                                            <tr>
                                                <th scope="col">Client Name</th>
                                                <th scope="col">Channel Name</th>
                                                <th scope="col">Mode Name</th>
                                                <th scope="col">Recon Type</th>
                                                <th scope="col">EJ Status</th>
                                                <th scope="col">GL Status</th>
                                                <th scope="col">SW Status</th>
                                                <th scope="col">NW Status</th>
                                                <th scope="col">Operation Remarks</th>
                                                <th scope="col">Settled Remarks</th>
                                                <th scope="col">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {StatusMasterData.map((row, rowIndex) => (
                                                <tr key={rowIndex}>
                                                    <td>{row.clientID?.label || 'N/A'}</td>
                                                    <td>{row.channelID?.label || 'N/A'}</td>
                                                    <td>{row.modeID?.label || 'N/A'}</td>
                                                    <td>{row.reconType?.label || 'N/A'}</td>
                                                    <td>{row.ejStatus?.label || 'N/A'}</td>
                                                    <td>{row.glStatus?.label || 'N/A'}</td>
                                                    <td>{row.switchStatus?.label || 'N/A'}</td>
                                                    <td>{row.networkStatus?.label || 'N/A'}</td>
                                                    <td>{row.remarks?.label || 'N/A'}</td>
                                                    <td>{row.settledRemarks?.label || 'N/A'}</td>
                                                    <td>
                                                        <div className="text-center">
                                                            <button
                                                                type="button"
                                                                className="iconButtonBox"
                                                                onClick={() => onEditClick(row)}
                                                                aria-label="Edit"
                                                            >
                                                                <img src={editRow} alt="Edit" title="Edit" />
                                                            </button>
                                                            <button
                                                                type="button"
                                                                className="iconButtonBox"
                                                                onClick={() => onDeleteClick(row)}
                                                                aria-label="Delete"
                                                            >
                                                                <img src={Delete} alt="Delete" title="Delete" />
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    ): null}
                    </>
                    )}
                </div>
            </div>
            {/* Edit Modal Popup*/}
            <div>
                <Modal
                    centered
                    className="AddNewTableModal"
                    size='xl'
                    show={showModal && EditEntry}
                    onHide={() => setShowModal(false)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Edit item</Modal.Title>
                    </Modal.Header>
                    <Modal.Body size='xl'>
                        <div
                            id="unmatchedFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="unmatchedFiltersHeading"
                            data-bs-parent="#unmatchedFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedClientValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                            isDisabled={true}
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={EditChannel}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={EditMode}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.modeName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Recon Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={EditReconType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsReconType.map(x => (
                                                {
                                                    value: x.reconID,
                                                    label: x.reconName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">EJ Status</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedEJType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Gl Status</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedGLType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Switch Status</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedSWType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Network Status</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedNWType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                </div>
                                <br />
                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlMode">Operation Remark</label>
                                    <span className="text-danger font-size13">*</span>
                                    <input
                                        type="text"
                                        id="RemarkInput"
                                        className="form-control"
                                        onChange={(e) => setSelectedRemark(e.target.value)}
                                        value={selectedRemark}
                                        placeholder="Remark"
                                        style={{ fontSize: '13px' }}
                                    />
                                </div>
                                <br />
                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlMode">Settled Remark</label>
                                    <span className="text-danger font-size14">*</span>
                                    <Select
                                        id="ddlReconType"
                                        value={selectedSettledRemark}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsSettelRemark.map(x => (
                                            {
                                                value: x.settelID,
                                                label: x.settelRemark
                                            }
                                        ))}
                                        onChange={handleSettelRemarks}
                                    // styles={{ control: (provided) => ({ ...provided, height: '15%' }) }}
                                    />
                                </div>
                                <br />
                                <div className="text-center btnsBtm">
                                    {/* <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button> */}
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onSubmit}
                                        disabled={isShow}
                                    >Submit
                                    </button>
                                </div>

                            </div>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={onCancelClick}>Cancel</Button>
                    </Modal.Footer>
                </Modal>
            </div>
            {/* New Modal Popup*/}
            <div>
                <Modal
                    centered
                    className="AddNewTableModal"
                    size='xl'
                    show={showModal && NewEntry}
                    onHide={() => setShowModal(false)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Add New Item</Modal.Title>
                    </Modal.Header>
                    <Modal.Body size='xl'>
                        <div
                            id="unmatchedFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="unmatchedFiltersHeading"
                            data-bs-parent="#unmatchedFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedClientValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                            isDisabled={true}
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedChannelValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedModeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.modeName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Recon Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedReconType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsReconType.map(x => (
                                                {
                                                    value: x.reconID,
                                                    label: x.reconName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">EJ Status</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedEJType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            onChange={handleEJChange}
                                            styles={{ control: (provided) => ({ ...provided, height: '15%' }) }}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Gl Status</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedGLType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            onChange={handleGLChange}
                                            styles={{ control: (provided) => ({ ...provided, height: '15%' }) }}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Switch Status</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedSWType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            onChange={handleSWChange}
                                            styles={{ control: (provided) => ({ ...provided, height: '15%' }) }}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Network Status</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedNWType}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsStatusType.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusName
                                                }
                                            ))}
                                            onChange={handleNWChange}
                                            styles={{ control: (provided) => ({ ...provided, height: '15%' }) }}
                                        />
                                    </div>

                                </div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Remark</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="RemarkInput"
                                            className="form-control"
                                            onChange={(e) => setSelectedRemark(e.target.value)}
                                            value={selectedRemark}
                                            placeholder="Remark"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Settled Remark</label>
                                        <span className="text-danger font-size14">*</span>
                                        <Select
                                            id="ddlReconType"
                                            value={selectedSettledRemark}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsSettelRemark.map(x => (
                                                {
                                                    value: x.settelID,
                                                    label: x.settelRemark
                                                }
                                            ))}
                                            onChange={handleSettelRemarks}
                                            styles={{ control: (provided) => ({ ...provided, height: '15%' }) }}
                                        />
                                    </div>
                                </div>
                                <div className="text-center btnsBtm">
                                    <br />
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onProceed}
                                        disabled={isShow}
                                    >Submit
                                    </button>
                                </div>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>
            </div>
            <LoadingSpinner isShow={false} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default StatusMasterMainWindow;
