﻿import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import AsyncSelect from 'react-select/async';
import MaximusAxios from "../common/apiURL" ;   
import "datatables.net-dt/js/dataTables.dataTables";
 

import 'jquery/dist/jquery.min.js';



const AddNewClientMainWindow = () => {

  
    const [ChannelAdd, setChannelAdd] = useState(true); 


    const FetchChannelType = () => {

        MaximusAxios.get('api/ClientReg/GetClientChannelList', { headers: authHeader() , mode:'cors' }).then(result => {
            if (result.data !== null && result.data.length > 0) {
                setSelectedChannelValue(result.data);
            }
            else {
                setSelectedChannelValue([{ channelID: "0", channelName: "--Select--" }]);
            }
        });

    }

    useEffect(() => {

        FetchChannelType()
    },
        [ChannelAdd]
    );


    const fetchCountryData = (inputValue) => {

        return MaximusAxios.get('/api/CurrencyReg/GetCountryRegList', {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.country.toLowerCase().includes(inputValue.toLowerCase()));
            }

        });

    }
    const fetchCurrencyData = (inputValue) => {

        return MaximusAxios.get('/api/CurrencyReg/GetCurrencyRegList', {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.currencyCode.toLowerCase().includes(inputValue.toLowerCase()));
            }

        });

    }

    const fetchDomainData = (inputValue) => {
        return MaximusAxios.get('/api/ClientReg/GetClientDomainList', {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.domainType.toLowerCase().includes(inputValue.toLowerCase()));
            }
        });
    }


    const fetchModuleData = (inputValue) => {
        MaximusAxios.get('/api/ClientReg/GetClientDomainList', {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.domainType.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            if (error.response) {
                console.log(error.response.data);
            } 
        }); 
    }

    const handleInputChange = value => {
        setValue(value);
    };

    const [inputValue, setValue] = useState('0');
    const [selectedCountryValue, setSelectedCountryValue] = useState(null);
    const [selectedCurrencyValue, setSelectedCurrencyValue] = useState(null);
    const [selectedModuleValue, setSelectedModuleValue] = useState(null);
    const [selectedDomainValue, setSelectedDomainValue] = useState(null);
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);
    const [ClientNameValue, setClientNameValue] = useState(null);
    const [ClientCodeValue, setClientCodeValue] = useState(null);
    const [ClientAddressValue, setClientAddressValue] = useState(null);
    const [ContactNoValue, setContactNoValue] = useState(null);
    const [EmailIdValue, setEmailIdValue] = useState(null);
    const [ConcernPersonNameValue, setConcernPersonNameValue] = useState(null);
    const [ConcernPersonContactValue, setConcernPersonContactValue] = useState(null);
    const [ConcernPersonEmailIdValue, setConcernPersonEmailIdValue] = useState(null);
    const [FTPUsernameValue, setFTPUsernameValue] = useState(null);
    const [FTPIPValue, setFTPIPValue] = useState(null);
    const [FTPPasswordValue, setFTPPasswordValue] = useState(null);
    const [FTPPortValue, setFTPPortValue] = useState(null);
    const [TerminalCountValue, setTerminalCountValue] = useState(null);
    const [UserLimitValue, setUserLimitValue] = useState(null);
    const [ReportCutOffTimeValue, setReportCutOffTimeValue] = useState(null);
    const [LogoValue, setLogoValue] = useState(null);
    const [ChooseColorCodeValue, setChooseColorCodeValue] = useState(null);
    const [IsBankValue, setIsBankValue] = useState(null);
    const [IsActiveValue, setIsActiveValue] = useState(null);

    const handleCountryChange = value => {
        setSelectedCountryValue(value);
    }
    const handleCurrencyChange = value => {
        setSelectedCurrencyValue(value);
    }
    const handleDomainTypeChange = value => {
        setSelectedDomainValue(value);
    }

    const handleModuleTypeChange = value => {
        setSelectedModuleValue(value);
    }
    
    const handleClientNameChange = value => {
        setClientNameValue(value);

    }

    const handleClientCodeChange = value => {
        setClientCodeValue(value);

    }
    const handleClientAddressChange = value => {
        setClientAddressValue(value);

    }
    const handleContactNoChange = value => {
        setContactNoValue(value);

    }

    const handleEmailIdChange = value => {
        setEmailIdValue(value);

    }
    const handleConcernPersonNameChange = value => {
        setConcernPersonNameValue(value);

    }
    const handleConcernPersonContactChange = value => {
        setConcernPersonContactValue(value);

    }
    const handleConcernPersonEmailIdChange = value => {
        setConcernPersonEmailIdValue(value);

    }
    const handleFTPUsernameChange = value => {
        setFTPUsernameValue(value);

    }
    const handleFTPIPChange = value => {
        setFTPIPValue(value);

    }
    const handleFTPPasswordChange = value => {
        setFTPPasswordValue(value);

    }
    const handleFTPPortChange = value => {
        setFTPPortValue(value);

    }
    const handleTerminalCountChange = value => {
        setTerminalCountValue(value);

    }
    const handleUserLimitChange = value => {
        setUserLimitValue(value);

    }
    const handleReportCutOffTimeChange = value => {
        setReportCutOffTimeValue(value);

    }
    const handleLogoChange = value => {
        setLogoValue(value);

    }
    const handleChooseColorCodeChange = value => {
        setChooseColorCodeValue(value);

    }
    const handleIsBankChange = value => {
        setIsBankValue(value);

    }
    const handleIsActiveChange = value => {
        setIsActiveValue(value);

    }


    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }


    return (
        <div className="configLeft identificationContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Client Registration
        </h5>
                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12 colorPrimaryDefault">Client Management</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12">Client Registration</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <Link to="/">
                        <p className="fontSize12">Add New Client</p>
                    </Link>
                </div>

            </div>

            {/* Bottom Content */}

            <div className="configLeftBottom">
                <div className="tableBorderBox">
                    <div className="configLeftBottom"><label>Basic Information</label>
                    </div>
                    <div className="configSelectBoxTop row">

                        <div className="clientNameSelect col">
                            <label htmlFor="clientname">Client Name</label>
                            <input
                                type="text"
                                name="clientname"
                                id="clientname"
                                placeholder="Enter Client Name"
                                className="inputTextBox"
                                onChange={handleClientNameChange}
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="clientcode">Client Code</label>
                            <input
                                type="text"
                                name="clientcode"
                                id="clientcode"
                                placeholder="Enter Client Code"
                                className="inputTextBox"
                                onChange={handleClientCodeChange}
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="clientaddress">Client Address</label>
                            <textarea
                                type="textarea"
                                name="clientaddress"
                                id="clientaddress"
                                placeholder="Enter Address here...."
                                className="inputTextBox"
                                onchange={handleClientAddressChange}
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="contactno">Contact No</label>
                            <input
                                type="Number"
                                name="contactno"
                                id="contactno"
                                placeholder="123-456-7890"
                                pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"
                                required
                                className="inputTextBox"
                                onchange={handleContactNoChange}
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="emailid">Email Id</label>
                            <input
                                type="email"
                                name="emailid"
                                id="emailid"
                                placeholder="Enter Email Id"
                                className="inputTextBox"
                                onchange={handleEmailIdChange}
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="concernpersonname">Concern Person Name</label>
                            <input
                                type="text"
                                name="concernpersonname"
                                id="concernpersonname"
                                placeholder="Enter Concern Person Name"
                                className="inputTextBox"
                                onChange={handleConcernPersonNameChange}

                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="concernpersoncontact">Concern Person Contact</label>
                            <input
                                type="Number"
                                name="concernpersoncontact"
                                id="concernpersoncontact"
                                placeholder="123-456-7890"
                                pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"
                                required
                                className="inputTextBox"
                                onChange={handleConcernPersonContactChange}
                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="concernpersonemailid">Concern Person Email Id</label>
                            <input
                                type="email"
                                name="concernpersonemailid"
                                id="concernpersonemailid"
                                placeholder="Enter Concern Person Email Id"
                                className="inputTextBox"
                                onChange={handleConcernPersonEmailIdChange}
                            />
                        </div>

                        <div className="configLeftBottom"><label>FTP Credentials</label>
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="ftpusername">FTP Username</label>
                            <input
                                type="text"
                                name="ftpusername"
                                id="ftpusername"
                                placeholder="Enter FTP Username"
                                className="inputTextBox"
                                onChange={handleFTPUsernameChange}
                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="ftpip">FTP IP</label>
                            <input
                                type="text"
                                name="ftpip"
                                id="ftpip"
                                placeholder="Enter FTP IP"
                                pattern="[0-9]{3}-[0-9]{2}-[0-9]{2}-[0-9]{3}"
                                required
                                className="inputTextBox"
                                onChange={handleFTPIPChange}
                                minlength="7"
                                maxlength="15"
                                size="15"
                                pattern="^((\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.){3}(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$"
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="ftppassword">FTP Password</label>
                            <input
                                type="Password"
                                name="ftppassword"
                                id="ftppassword"
                                placeholder="Enter FTP Password"
                                className="inputTextBox"
                                onChange={handleFTPPasswordChange}
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="ftpport">FTP Port</label>
                            <input
                                type="text"
                                name="ftpport"
                                id="ftpport"
                                placeholder="Enter FTP Port"
                                className="inputTextBox"
                                onChange={handleFTPPortChange}
                                minlength="2"
                                maxlength="4"
                                size="4"
                            />
                        </div>

                        <div className="configLeftBottom"><label>Other Details</label>
                        </div>

                        <div className="clientNameSelect col" id="Country">
                            <label htmlFor="clientName">Country Code</label>
                            <span className="text-danger font-size13">*</span>
                            <AsyncSelect
                                cacheOptions
                                defaultOptions
                                value={selectedCountryValue}
                                getOptionLabel={e => e.country}
                                getOptionValue={e => e.id}
                                loadOptions={fetchCountryData}
                                onInputChange={handleInputChange}
                                onChange={handleCountryChange}
                                id="ddlCountry"
                            />
                        </div>

                        <div className="clientNameSelect col" id="Currency">
                            <label htmlFor="clientName">Currency Code</label>
                            <span className="text-danger font-size13">*</span>
                            <AsyncSelect
                                cacheOptions
                                defaultOptions
                                value={selectedCurrencyValue}
                                getOptionLabel={e => e.currencyCode}
                                getOptionValue={e => e.currencyID}
                                loadOptions={fetchCurrencyData}
                                onInputChange={handleInputChange}
                                onChange={handleCurrencyChange}
                                id="ddlCountry"
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="clientName">Domain Type</label>
                            <span className="text-danger font-size13">*</span>
                            <AsyncSelect
                                cacheOptions
                                defaultOptions
                                value={selectedDomainValue}
                                getOptionLabel={e => e.domainType}
                                getOptionValue={e => e.domainID}
                                loadOptions={fetchDomainData}
                                onInputChange={handleInputChange}
                                onChange={handleDomainTypeChange}
                                id="ddlDomain"
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="clientName">Module Type</label>
                            <span className="text-danger font-size13">*</span>
                            <AsyncSelect
                                cacheOptions
                                defaultOptions
                                value={selectedModuleValue}
                                getOptionLabel={e => e.moduleType}
                                getOptionValue={e => e.moduleID}
                                loadOptions={fetchModuleData}
                                onInputChange={handleInputChange}
                                onChange={handleModuleTypeChange}
                                id="ddlModule"
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="terminalcount">Terminal Count</label>
                            <input
                                type="Number"
                                name="terminalcount"
                                id="terminalcount"
                                className="inputTextBox"
                                onchange={handleTerminalCountChange}
                                onkeypress="CheckNumeric(event);"
                                Text="0"
                                Style="text-align: right;"
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="userlimit">User Limit</label>
                            <input
                                type="Number"
                                name="userlimit"
                                id="userlimit"
                                className="inputTextBox"
                                onchange={handleUserLimitChange}
                                onkeypress="CheckNumeric(event);"
                                Text="0"
                                Style="text-align: right;"
                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="reportcutofftime">Report Cut-Off Time</label>
                            <input
                                type="time"
                                name="reportcutofftime"
                                id="reportcutofftime"
                                className="inputTextBox"
                                onchange={handleReportCutOffTimeChange}
                                Text="11:59:59:999"
                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="logo">Logo</label>
                            <input
                                type="file"
                                name="logo"
                                id="logo"
                                className="inputTextBox"
                                onChange={handleLogoChange}
                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="choosecolorcode">Choose Color Code</label>
                            <input
                                name="choosecolorcode"
                                id="choosecolorcode"
                                className="inputTextBox"
                                type="color"
                                onChange={handleChooseColorCodeChange}
                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="isbank">Is Bank</label><br />
                            <label><br />Yes
                             &nbsp; &nbsp;<input
                                    type="radio"
                                    name="isbank"
                                    id="isbank"
                                    className="radiobutton"
                                    value="Yes"
                                    onChange={handleIsBankChange}
                                /></label> &nbsp; &nbsp;
                            <label>No &nbsp;
                            <input
                                    type="radio"
                                    name="isbank"
                                    id="isbank"
                                    className="radiobutton"
                                    value="No"
                                    onChange={handleIsBankChange}
                                /></label>
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="isactive">Is Active</label><br />
                            <label><br />Yes
                            &nbsp; &nbsp;<input
                                    type="radio"
                                    name="isactive"
                                    id="isactive"
                                    className="radiobutton"
                                    value="Yes"
                                    onChange={handleIsActiveChange}
                                /></label>&nbsp; &nbsp;
                            <label>No &nbsp;
                            <input
                                    type="radio"
                                    name="isactive"
                                    id="isactive"
                                    className="radiobutton"
                                    value="No"
                                    onChange={handleIsActiveChange}
                                /></label>
                        </div>
                    </div>

                    <div className="text-center btnsBtm">

                        <button
                            type="button"
                            className="btnPrimary ms-2"
                            onClick={btnSubmitClick}
                        >
                            ADD
           </button>&nbsp;
              <button
                            type="button"
                            className="btnPrimaryOutline"
                            onClick={(e) => onReset(e)}
                        >
                            Reset
                                    </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddNewClientMainWindow;
