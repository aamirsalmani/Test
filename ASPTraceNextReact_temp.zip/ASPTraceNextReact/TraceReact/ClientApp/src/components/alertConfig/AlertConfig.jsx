﻿import React from "react";
import { useSelector } from "react-redux";
import AlertConfigMainWindow from "./AlertConfigMainWindow";

const AlertConfig = () => {
    return (        
           <div className="mainView">
                <AlertConfigMainWindow />
        </div>
    );
};

export default AlertConfig;
