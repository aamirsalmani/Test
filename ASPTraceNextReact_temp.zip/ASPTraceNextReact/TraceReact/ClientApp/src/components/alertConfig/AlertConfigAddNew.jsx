﻿import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import AsyncSelect from 'react-select/async';
import MaximusAxios from "../common/apiURL";
import "datatables.net-dt/js/dataTables.dataTables";
import { useSelector } from "react-redux";
import Select from "react-select";
import 'jquery/dist/jquery.min.js';
import { useNavigate } from "react-router-dom";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { Modal, Button, Tooltip, OverlayTrigger } from "react-bootstrap";



const AlertConfigAddNew = () => {

    const navigate = useNavigate();
    const [isShow, setIsLoading] = useState(false);
    const [isEscalationEnabled, setIsEscalationEnabled] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });
    const [NewEntry, setNewEntry] = useState(false);
    const [showModal, setShowModal] = useState(false);



    const [alertName, setAlertName] = useState("");
    const [description, setDescription] = useState("");
    const [spName, setSpName] = useState("");
    const [emailRecipients, setEmailRecipients] = useState("");
    const [smsRecipients, setSmsRecipients] = useState("");
    const [emailSubject, setEmailSubject] = useState("");
    const [emailBody, setEmailBody] = useState("");
    const [emailFooter, setEmailFooter] = useState("");
    const [smsBody, setSmsBody] = useState("");
    const [smsFooter, setSmsFooter] = useState("");



    useEffect(() => {
        fetchClientData();
        fetchAlertTypeData();
        fetchSeverityTypeData();
        fetchAlertChannelTypeData();
        fetchAlertScheduleTypeData();
    }, []);



    //All  UseStates for dropdowns and textboxes START
    //1. Client Master
    const [optionsClient, setOptionsClient] = useState([{ clientID: "0", clientName: "ALL" }])
    const [selectedClientValue, setSelectedClientValue] = useState(null);

    //2. Alert Type Master
    const [optionsAlertType, setOptionsAlertType] = useState([{ alertID: "0", alertName: "ALL" }])
    const [selectedAlertTypeValue, setSelectedAlertTypeValue] = useState(null);

    //3. Alert Severity Master
    const [optionsSeverityType, setOptionsSeverityType] = useState([{ severityID: "0", severityName: "ALL" }])
    const [selectedAlertSeverityValue, setSelectedAlertSeverityValue] = useState(null);

    //4. Alert Schedule Type Master
    const [optionsAlertScheduleTypeType, setOptionsAlertScheduleTypeType] = useState([{ alertScheduleTypeID: "0", alertScheduleTypeName: "All" }])
    const [selectedAlertScheduleTypeValue, setSelectedAlertScheduleTypeValue] = useState(null);

    //5. Alert Channel Master
    const [optionsAlertChannelType, setOptionsAlertChannelType] = useState([{ alertChannelID: "0", alertChannelName: "ALL" }])
    const [selectedAlertChannelValue, setSelectedAlertChannelValue] = useState(null);

    //6. Alert  Escalation User Master
    const [selectedAlertEscalationUserValue, setSelectedAlertEscalationUserValue] = useState(null);

    //6. WeekDays Master

    const minutes = [
        { value: -1, label: "Select All" },
        ...Array.from({ length: 60 }, (_, i) => ({ value: i, label: `${i} min` })),
    ];

    const hours = [
        { value: -1, label: "Select All" },
        ...Array.from({ length: 24 }, (_, i) => ({ value: i, label: `${i} hr` })),
    ];

    const months = [
        { value: -1, label: "Select All" },
        { value: 1, label: "January" },
        { value: 2, label: "February" },
        { value: 3, label: "March" },
        { value: 4, label: "April" },
        { value: 5, label: "May" },
        { value: 6, label: "June" },
        { value: 7, label: "July" },
        { value: 8, label: "August" },
        { value: 9, label: "September" },
        { value: 10, label: "October" },
        { value: 11, label: "November" },
        { value: 12, label: "December" },
    ];

    const monthDays = [
        { value: -1, label: "Select All" },
        ...Array.from({ length: 31 }, (_, i) => ({ value: i + 1, label: `Day ${i + 1}` })),
    ];

    const [selectedMinute, setSelectedMinute] = useState(null);
    const [selectedHour, setSelectedHour] = useState(null);
    const [selectedMonth, setSelectedMonth] = useState(null);
    const [selectedMonthDay, setSelectedMonthDay] = useState(null);

    useEffect(() => {
        setSelectedMinute(null);
        setSelectedHour(null);
        setSelectedMonth(null);
        setSelectedMonthDay(null);
    }, [selectedAlertScheduleTypeValue]);


    //All Master select UseStates and dropdowns END



    //All Master Dropdown Value fetch START


    const currentUser = useSelector((state) => state.authReducer);

    const fetchClientData = (value) => {
        setIsLoading(true);
        MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, { mode: 'cors' }).then(resultChannel => {
            setOptionsClient(resultChannel.data);
            setIsLoading(false);
        }).catch(function (error) {
            console.log(error.response);
        });
        setIsLoading(false);
    };

    const fetchAlertTypeData = (value) => {
        setIsLoading(true);
        MaximusAxios.get('api/Common/GetAlertTypeList', { mode: 'cors' }).then(resultChannel => {
            const filteredData = resultChannel.data.filter(
                item => item.alertID !== '0' && item.alertName !== 'All'
            );
            setOptionsAlertType(filteredData);
            setIsLoading(false);
        }).catch(function (error) {
            console.log(error.response);
        });
        setIsLoading(false);
    };

    const fetchSeverityTypeData = (value) => {
        setIsLoading(true);
        MaximusAxios.get('api/Common/GetAlertSeverityList', { mode: 'cors' }).then(resultChannel => {
            const filteredData = resultChannel.data.filter(
                item => item.severityID !== '0' && item.severityName !== 'All'
            );
            setOptionsSeverityType(filteredData);
            setIsLoading(false);
        }).catch(function (error) {
            console.log(error.response);
        });
        setIsLoading(false);
    };

    const fetchAlertScheduleTypeData = (value) => {
        setIsLoading(true);
        MaximusAxios.get('api/Common/GetAlertScheduleTypeList', { mode: 'cors' }).then(resultChannel => {
            const filteredData = resultChannel.data.filter(
                item => item.alertScheduleTypeID !== '0' && item.alertScheduleTypeName !== 'All'
            );
            setOptionsAlertScheduleTypeType(filteredData);
            setIsLoading(false);
        }).catch(function (error) {
            console.log(error.response);
        });
        setIsLoading(false);
    };

    const fetchAlertChannelTypeData = (value) => {
        setIsLoading(true);
        MaximusAxios.get('api/Common/GetAlertNotificationChannelList', { mode: 'cors' }).then(resultChannel => {
            const filteredData = resultChannel.data.filter(
                item => item.alertChannelID !== '0' && item.alertChannelName !== 'All'
            );
            setOptionsAlertChannelType(filteredData);
            setIsLoading(false);
        }).catch(function (error) {
            console.log(error.response);
        });
        setIsLoading(false);
    };


    //All Master Dropdown Value fetch END






    //All Master Dropdown Handle change START


    const handleClientChange = (value) => {
        setSelectedClientValue(value);
    };
    const handleAlertTypeChange = (value) => {
        setSelectedAlertTypeValue(value);
    };
    const handleSeverityTypeChange = (value) => {
        setSelectedAlertSeverityValue(value);
    };
    const handleScheduleTypeChange = (value) => {
        setSelectedAlertScheduleTypeValue(value);
    };
    const handleNotificationChannelsChange = (value) => {
        setSelectedAlertChannelValue(value);
        if (!selectedAlertChannelValue?.label.includes("Email")) {
            setEmailRecipients(null);
            setEmailSubject(null);
            setEmailBody(null);
            setEmailFooter(null);
        }

        if (!selectedAlertChannelValue?.label.includes("SMS")) {
            setSmsRecipients(null);
            setChips([]);
            setCurrentText("");
            setSmsBody(null);
            setSmsFooter(null);
        }
    };

    //All Master Dropdown Handle change END



    const handleMultiSelect = (selectedOptions, options, setState) => {
        if (!selectedOptions) {
            setState([]);
            return;
        }

        const isSelectAll = selectedOptions.some(opt => opt.value === -1);

        if (isSelectAll) {
            setState([{ value: -1, label: "Select All" }]);
        } else {
            setState(selectedOptions);
        }
    };



    const users = [
        { value: "1", label: "Dev" },
        { value: "2", label: "QA" },
        { value: "3", label: "Ops" },
    ];


    // API Validation,Reset and Call Start

    const handleSubmit = () => {
        let errors = validateForm();

        if (errors.length > 0) {
            setShowMessageBox({
                isShow: true,
                alertVariant: "danger",
                alertTitle: "Mandatory Field",
                alertMessage: errors,
            });
            return;
        }

        try {
            const payload = buildSaveAlertPayload();

            setIsLoading(true);
            MaximusAxios.post(
                "api/AlertConfig/SaveAlertConfig",
                {
                    ...payload,
                    userName: currentUser.user.username,
                },
                { mode: "cors" }
            )
                .then((response) => {
                    const status = response.data;
                    if (status === "SUCCESS") {
                        alert("Alert configuration submitted successfully.");
                    }
                    else if (status === "Duplicate") {
                        const client = selectedClientValue?.label || "Client";
                        const name = alertName?.trim() || "Alert";

                        alert(`Duplicate alert found for ${client} — ${name}`);
                    }
                    else {
                        alert("Backend Error: " + status);
                    }})
                .catch((error) => {
                    console.error("API Error →", error);

                    setShowMessageBox({
                        isShow: true,
                        alertVariant: "danger",
                        alertTitle: "API Error",
                        alertMessage: "Backend rejected the payload. Check logs.",
                    });
                })
                .finally(() => {
                    setIsLoading(false);
                    navigate("/configuration/alert-config");
                });

        } catch (err) {
            console.error("Payload Builder Crashed →", err);
        }

    };

    const validateForm = () => {
        let alertMessages = "";

        if (!selectedClientValue) {
            alertMessages += "Client Name is required.\n";
        }

        if (!selectedAlertTypeValue) {
            alertMessages += "Alert Type is required.\n";
        }

        if (!alertName?.trim()) {
            alertMessages += "Alert Name is required.\n";
        }

        if (!selectedAlertSeverityValue) {
            alertMessages += "Severity is required.\n";
        }

        if (!description?.trim()) {
            alertMessages += "Description is required.\n";
        }

        if (!spName?.trim()) {
            alertMessages += "SP Name is required.\n";
        }

        if (!selectedAlertScheduleTypeValue) {
            alertMessages += "Schedule Type is required.\n";
        }

        if (["Monthly"].includes(selectedAlertScheduleTypeValue?.label)) {
            if (!selectedMonth || !selectedMonth.length) alertMessages += "Months selection is required.\n";
        }

        if (["Monthly", "Daily"].includes(selectedAlertScheduleTypeValue?.label)) {
            if (!selectedMonthDay || !selectedMonthDay.length) alertMessages += "Days selection is required.\n";
        }

        if (["Hourly", "Monthly", "Daily"].includes(selectedAlertScheduleTypeValue?.label)) {
            if (!selectedHour || !selectedHour.length) alertMessages += "Hours selection is required.\n";
        }

        if (["Minutely", "Hourly", "Monthly", "Daily"].includes(selectedAlertScheduleTypeValue?.label)) {
            if (!selectedMinute || !selectedMinute.length) alertMessages += "Minutes selection is required.\n";
        }

        if (!selectedAlertChannelValue?.length) {
            alertMessages += "At least one Notification Channel is required.\n";
        }

        if (selectedAlertChannelValue?.some(x => x.label === "Email")) {
            if (!emailRecipients?.trim()) {
                alertMessages += `Please enter Email Recipients.\n`;
            } else if (!isValidEmailList(emailRecipients)) {
                alertMessages += `Invalid Email format. Please enter valid comma-separated Email IDs.\n`;
            }
            if (!emailSubject?.trim()) alertMessages += "Email subject required.\n";
            if (!emailBody?.trim()) alertMessages += "Email body required.\n";
            if (!emailFooter?.trim()) alertMessages += "Email footer required.\n";
        }

        if (selectedAlertChannelValue?.some(x => x.label === "SMS")) {
            if (!smsRecipients?.trim()) {
                alertMessages += `Please enter SMS Recipients.\n`;
            } else if (!isValidMobileList(smsRecipients)) {
                alertMessages += `Invalid Mobile numbers. Please enter comma-separated 10-digit Indian mobile numbers starting with 6-9.\n`;
            }
            if (!smsBody?.trim()) alertMessages += "SMS body required.\n";
            if (!smsFooter?.trim()) alertMessages += "SMS footer required.\n";
        }

        if (isEscalationEnabled) {
            let escalationMsg = validateEscalations();
            if (escalationMsg) {
                alertMessages += `\nEscalation Configuration Validation:\n${escalationMsg}`;
            }
        }

        return alertMessages;
    };

    const onReset = (e) => {
        e.preventDefault();
        setSelectedClientValue(null);
        setSelectedAlertTypeValue(null);
        setAlertName("");
        setSelectedAlertSeverityValue(null);
        setDescription("");
        setSpName("");
        setSelectedAlertScheduleTypeValue(null);
        setSelectedMonth([]);
        setSelectedMonthDay([]);
        setSelectedHour([]);
        setSelectedMinute([]);
        setSelectedAlertChannelValue([]);
        setEmailRecipients("");
        setEmailSubject("");
        setEmailBody("");
        setEmailFooter("");
        setSmsRecipients("");
        setSmsBody("");
        setSmsFooter("");
        setIsEscalationEnabled(false);
        setEscalations([{ ...escalationTemplate }]);
    };

    // API Validation,Reset and Call End



    // API call for submit Start

    const buildSaveAlertPayload = () => {
        return {
            clientID: String(selectedClientValue.value),
            alertTypeID: String(selectedAlertTypeValue.value),
            alertName: alertName?.trim(),
            alertSeverityID: String(selectedAlertSeverityValue.value),
            description: description?.trim(),
            spName: spName?.trim(),
            scheduleTypeID: String(selectedAlertScheduleTypeValue.value),

            scheduleConfig: {
                months: selectedMonth?.map(m => String(m.value)) || [],
                days: selectedMonthDay?.map(m => String(m.value)) || [],
                hours: selectedHour?.map(m => String(m.value)) || [],
                minutes: selectedMinute?.map(m => String(m.value)) || []
            },

            channels: selectedAlertChannelValue.map(x => ({
                channelID: x.value,
                channelName: x.label
            })),

            emailConfig: selectedAlertChannelValue.some(x => x.label === "Email")
                ? {
                    recipients: emailRecipients,
                    subject: emailSubject,
                    body: emailBody,
                    footer: emailFooter
                }
                : null,

            smsConfig: selectedAlertChannelValue.some(x => x.label === "SMS")
                ? {
                    recipients: smsRecipients,
                    body: smsBody,
                    footer: smsFooter
                }
                : null,

            isEscalationEnabled: isEscalationEnabled,

            escalations: isEscalationEnabled
                ? escalations.map(item => ({
                    level: item.level,
                    userID: String(item.user?.value || ""),
                    delayType: item.delayType?.label || "",
                    month: item.month?.value != null ? String(item.month.value) : null,
                    day: item.day?.value != null ? String(item.day.value) : null,
                    hour: item.hour?.value != null ? String(item.hour.value) : null,
                    minute: item.minute?.value != null ? String(item.minute.value) : null,

                    channels: item.channels?.map(c => ({
                        channelID: c.value,
                        channelName: c.label
                    })) || [],

                    emailConfig: item.channels?.some(c => c.label === "Email")
                        ? {
                            recipients: item.emailRecipients,
                            subject: item.emailSubject,
                            body: item.emailBody,
                            footer: item.emailFooter
                        }
                        : null,

                    smsConfig: item.channels?.some(c => c.label === "SMS")
                        ? {
                            recipients: item.smsRecipients,
                            body: item.smsBody,
                            footer: item.smsFooter
                        }
                        : null
                }))
                : []
        };
    };


    // API call for submit End


    // Escalation Validation and Config Start


    const escalationTemplate = {
        level: 1,
        user: null,
        delayType: null,

        // schedule components
        month: null,
        day: null,
        hour: null,
        minute: null,

        schedule: "",

        // channels
        channels: [],

        // email
        emailRecipients: "",
        emailSubject: "",
        emailBody: "",
        emailFooter: "",

        // sms
        smsRecipients: "",
        smsBody: "",
        smsFooter: ""
    };

    const [escalations, setEscalations] = useState([escalationTemplate]);

    const addNewEscalationLevel = () => {
        setEscalations(prev => [
            ...prev,
            {
                ...escalationTemplate,
                level: prev.length + 1
            }
        ]);
    };

    const onResetEscalation = () => {
        setEscalations([{ ...escalationTemplate }]);
    };

    const handleEscalationConfig = () => {
        setShowModal(true);

        setEscalations(prev => {
            return prev && prev.length > 0 ? prev : [{ ...escalationTemplate }];
        });
    };


    // Alert Escalation Submit button
    const onProceedEscalation = () => {
        let alertMessages = validateEscalations();

        if (alertMessages.length > 0) {
            setShowMessageBox({
                isShow: true,
                alertVariant: "info",
                alertTitle: "Mandatory Field",
                alertMessage: alertMessages
            });
            return;
        }
       
        alert("Escalation details Submitted successfully");
        setShowModal(false);
    };


    const validateEscalations = () => {
        let alertMessages = "";

        escalations.forEach((item, index) => {
            const lvl = item.level;
            const prefix = `Level ${lvl}: `;

            if (!item.user) {
                alertMessages += `${prefix}Please select User.\n`;
            }

            if (!item.delayType) {
                alertMessages += `${prefix}Please select Delay Type.\n`;
            }

            const type = item.delayType?.label;

            if (["Monthly"].includes(type)) {
                if (!item.month) alertMessages += `${prefix}Please select Month.\n`;
                if (!item.day) alertMessages += `${prefix}Please select Day.\n`;
                if (!item.hour) alertMessages += `${prefix}Please select Hour.\n`;
                if (!item.minute) alertMessages += `${prefix}Please select Minute.\n`;
            }

            if (["Daily"].includes(type)) {
                if (!item.day) alertMessages += `${prefix}Please select Day.\n`;
                if (!item.hour) alertMessages += `${prefix}Please select Hour.\n`;
                if (!item.minute) alertMessages += `${prefix}Please select Minute.\n`;
            }

            if (["Hourly"].includes(type)) {
                if (!item.hour) alertMessages += `${prefix}Please select Hour.\n`;
                if (!item.minute) alertMessages += `${prefix}Please select Minute.\n`;
            }

            if (["Minutely"].includes(type)) {
                if (!item.minute) alertMessages += `${prefix}Please select Minute.\n`;
            }

            if (!item.channels || item.channels.length === 0) {
                alertMessages += `${prefix}Please select at least 1 Notification Channel.\n`;
            }

            const hasEmail = item.channels?.some(c => c.label === "Email");
            const hasSMS = item.channels?.some(c => c.label === "SMS");

            if (hasEmail) {
                if (!item.emailRecipients?.trim()) {
                    alertMessages += `${prefix}Please enter Email Recipients.\n`;
                } else if (!isValidEmailList(item.emailRecipients)) {
                    alertMessages += `${prefix}Invalid Email format. Please enter valid comma-separated Email IDs.\n`;
                }

                if (!item.emailSubject?.trim()) {
                    alertMessages += `${prefix}Please enter Email Subject.\n`;
                }

                if (!item.emailBody?.trim()) {
                    alertMessages += `${prefix}Please enter Email Body.\n`;
                }

                if (!item.emailFooter?.trim()) {
                    alertMessages += `${prefix}Please enter Email Footer.\n`;
                }
            }

            if (hasSMS) {
                if (!item.smsRecipients?.trim()) {
                    alertMessages += `${prefix}Please enter SMS Recipients.\n`;
                } else if (!isValidMobileList(item.smsRecipients)) {
                    alertMessages += `${prefix}Invalid Mobile numbers. Please enter comma-separated 10-digit Indian mobile numbers starting with 6-9.\n`;
                }

                if (!item.smsBody?.trim()) {
                    alertMessages += `${prefix}Please enter SMS Body.\n`;
                }

                if (!item.smsFooter?.trim()) {
                    alertMessages += `${prefix}Please enter SMS Footer.\n`;
                }
            }
        });

        return alertMessages;
    };

    const isValidEmailList = (value) => {
        if (!value) return false;

        const emails = value.split(",").map(x => x.trim());
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        return emails.every(email => email.length > 0 && emailRegex.test(email));
    };

    const isValidMobileList = (value) => {
        if (!value) return false;

        const numbers = value.split(",").map(x => x.trim()).filter(x => x.length > 0);
        const mobileRegex = /^[6-9]\d{9}$/;

        return numbers.every(num => mobileRegex.test(num));
    };


    // Escalation Validation and Config End

    // Extra UI Changes
    const [currentText, setCurrentText] = useState("");
    const inputRef = useRef(null);

    const [chips, setChips] = useState([]);
    const mobileRegex = /^[6-9]\d{9}$/;

    const handleChipInput = (value) => {
        const digits = value.replace(/\D/g, "");
        setCurrentText(digits);

        if (digits.length === 10) {
            const isValid = mobileRegex.test(digits);

            const newChip = { number: digits, isValid };

            const updatedChips = [...chips, newChip];
            setChips(updatedChips);

            const finalString = updatedChips.map(x => x.number).join(",");
            setSmsRecipients(finalString);

            setCurrentText("");
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === "Backspace" && currentText === "") {
            const updated = [...chips];
            updated.pop();

            setChips(updated);

            const newString = updated.map(x => x.number).join(",");
            setSmsRecipients(newString);
        }
    };


    const escInputRef = useRef(null);
    const [escCurrentText, setEscCurrentText] = useState("");
    const [escChips, setEscChips] = useState([]);

    const handleEscChipInput = (value, idx) => {
        const digits = value.replace(/\D/g, "");
        setEscCurrentText(digits);

        if (digits.length === 10) {
            const isValid = mobileRegex.test(digits);
            const newChip = { number: digits, isValid };

            const updatedChips = [...escChips, newChip];
            setEscChips(updatedChips);

            const updated = [...escalations];
            updated[idx].smsRecipients = updatedChips.map(x => x.number).join(",");
            setEscalations(updated);

            setEscCurrentText("");
        }
    };

    const handleEscKeyPress = (e, idx) => {
        if (e.key === "Backspace" && escCurrentText === "") {
            const updated = [...escChips];
            updated.pop();

            setEscChips(updated);

            const escString = updated.map(x => x.number).join(",");

            const newEscalations = [...escalations];
            newEscalations[idx].smsRecipients = escString;
            setEscalations(newEscalations);
        }
    };

    // Extra UI Changes


    return (
        <div className="mainView">
            <div className="configLeft identificationContainer">
                <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                    <h5 className="fontWeight-600 fileConfigHead colorBlack">
                        Configure New Alert
                    </h5>
                    <div className="d-flex align-items-center">
                        <Link to="/">
                            <p className="fontSize12 colorPrimaryDefault">Home</p>
                        </Link>
                        <span>
                            <svg
                                width="8"
                                height="100%"
                                viewBox="0 0 10 16"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                className="mx-1"
                            >
                                <path
                                    d="M3 4L7 8L3 12"
                                    stroke="black"
                                    strokeWidth="1.5"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    className="breadcrumbIcon"
                                />
                            </svg>
                        </span>
                        <p className="fontSize12 colorPrimaryDefault">Configuration</p>
                        <span>
                            <svg
                                width="8"
                                height="100%"
                                viewBox="0 0 10 16"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                className="mx-1"
                            >
                                <path
                                    d="M3 4L7 8L3 12"
                                    stroke="black"
                                    strokeWidth="1.5"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    className="breadcrumbIcon"
                                />
                            </svg>
                        </span>
                        <p className="fontSize12">Alert Configuration</p>
                        <span>
                            <svg
                                width="8"
                                height="100%"
                                viewBox="0 0 10 16"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                className="mx-1"
                            >
                                <path
                                    d="M3 4L7 8L3 12"
                                    stroke="black"
                                    strokeWidth="1.5"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    className="breadcrumbIcon"
                                />
                            </svg>
                        </span>
                        <p className="fontSize12">Configure New Alert</p>
                    </div>

                </div>
                <div className="configLeftBottom">
                    <div id="unmatchedFilters">
                        <div className="border rounded-3 p-3 shadow-sm bg-white">

                            <div
                                className="d-flex justify-content-between align-items-center configLeftFilters accordion-header p-2 rounded"
                                style={{ backgroundColor: "#e9ecef" }}
                            >
                                <h6 className="fontWeight-600 colorBlack mb-0">Alert Configuration Form</h6>
                            </div>

                            <div className="configLeftBottom">
                                <div className="accordion-body">
                                    <h5 className="fontWeight-600 fileConfigHead colorBlack ">
                                        Basic Information
                                    </h5>
                                    <div className="hrGreyLine"></div>
                                    <div className="configSelectBoxTop row">
                                        <div className="clientNameSelect col">
                                            <label htmlFor="clientname">Client Name</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlChannel"
                                                value={selectedClientValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsClient.map(x => (
                                                    {
                                                        value: x.clientID,
                                                        label: x.clientName
                                                    }
                                                ))}
                                                onChange={handleClientChange}
                                                placeholder="Select Client Name"
                                            />
                                        </div>

                                        <div className="clientNameSelect col">
                                            <label htmlFor="clientname">Alert Type</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlChannel"
                                                value={selectedAlertTypeValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsAlertType.map(x => (
                                                    {
                                                        value: x.alertID,
                                                        label: x.alertName
                                                    }
                                                ))}
                                                onChange={handleAlertTypeChange}
                                                placeholder="Select Alert Type"
                                            />
                                        </div>

                                        <div className="clientNameSelect col">
                                            <label htmlFor="clientname">Alert Name</label>
                                            <span className="text-danger font-size13">*</span>
                                            <input
                                                type="text"
                                                className="form-control form-control-sm"
                                                placeholder="Enter Alert Name"
                                                value={alertName}
                                                onChange={(e) => setAlertName(e.target.value)}
                                            />
                                        </div>

                                        <div className="clientNameSelect col">
                                            <label htmlFor="clientname">Severity</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlChannel"
                                                value={selectedAlertSeverityValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsSeverityType.map(x => (
                                                    {
                                                        value: x.severityID,
                                                        label: x.severityName
                                                    }
                                                ))}
                                                onChange={handleSeverityTypeChange}
                                                placeholder="Select Severity"
                                            />
                                        </div>

                                        <div className="clientNameSelect col">
                                            <label htmlFor="clientname">Description</label>
                                            <span className="text-danger font-size13">*</span>
                                            <input
                                                type="text"
                                                className="form-control form-control-sm"
                                                placeholder="Enter Description"
                                                value={description}
                                                onChange={(e) => setDescription(e.target.value)}
                                            />
                                        </div>

                                        <div className="clientNameSelect col">
                                            <label htmlFor="clientname">SP Name</label>
                                            <span className="text-danger font-size13">*</span>
                                            <input
                                                type="text"
                                                className="form-control form-control-sm"
                                                placeholder="Enter stored procedure name"
                                                value={spName}
                                                onChange={(e) => setSpName(e.target.value)}
                                            />
                                        </div>

                                        <div className="clientNameSelect col">
                                            <label htmlFor="clientname">Schedule Type</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlChannel"
                                                value={selectedAlertScheduleTypeValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsAlertScheduleTypeType.map(x => (
                                                    {
                                                        value: x.alertScheduleTypeID,
                                                        label: x.alertScheduleTypeName
                                                    }
                                                ))}
                                                onChange={handleScheduleTypeChange}
                                                placeholder="Select Schedule Type"
                                                isClearable
                                            />
                                        </div>

                                        <div className="clientNameSelect col">
                                            <label htmlFor="clientname">Notification Channels</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlChannel"
                                                isMulti
                                                value={selectedAlertChannelValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsAlertChannelType.map(x => (
                                                    {
                                                        value: x.alertChannelID,
                                                        label: x.alertChannelName
                                                    }
                                                ))}
                                                onChange={handleNotificationChannelsChange}
                                                placeholder="Select Notification Channels"
                                            />
                                        </div>

                                        <div>
                                            {["Minutely", "Hourly", "Daily", "Weekly", "Monthly"].includes(selectedAlertScheduleTypeValue?.label) && (
                                                <>
                                                    <h5 className="fontWeight-600 fileConfigHead colorBlack mt-20  ">
                                                        Schedule / Frequency
                                                    </h5>
                                                    <div className="hrGreyLine"></div>
                                                    <div style={{ height: "1rem" }}></div>
                                                </>
                                            )}
                                        </div>

                                        <div className="clientNameSelect">
                                            {["Monthly"].includes(selectedAlertScheduleTypeValue?.label) && (
                                                <div className="fullWidthSelect">
                                                    <label>
                                                        Months<span className="text-danger">*</span>
                                                    </label>
                                                    <Select
                                                        isMulti
                                                        options={months}
                                                        value={selectedMonth}
                                                        onChange={(selected) =>
                                                            handleMultiSelect(selected, months, setSelectedMonth)
                                                        }
                                                        classNamePrefix="reactSelectBox"
                                                        placeholder="Select Month"
                                                        closeMenuOnSelect={false}
                                                    />
                                                </div>
                                            )}

                                            {["Monthly", "Daily"].includes(selectedAlertScheduleTypeValue?.label) && (
                                                <div className="fullWidthSelect">
                                                    <label>
                                                        Days<span className="text-danger">*</span>
                                                    </label>
                                                    <Select
                                                        isMulti
                                                        options={monthDays}
                                                        value={selectedMonthDay}
                                                        onChange={(selected) =>
                                                            handleMultiSelect(selected, monthDays, setSelectedMonthDay)
                                                        }
                                                        classNamePrefix="reactSelectBox"
                                                        placeholder="Select day of month"
                                                        closeMenuOnSelect={false}
                                                    />
                                                </div>
                                            )}

                                            {["Hourly", "Monthly", "Daily"].includes(selectedAlertScheduleTypeValue?.label) && (
                                                <div className="fullWidthSelect">
                                                    <label>
                                                        Hours<span className="text-danger">*</span>
                                                    </label>
                                                    <Select
                                                        isMulti
                                                        options={hours}
                                                        value={selectedHour}
                                                        onChange={(selected) =>
                                                            handleMultiSelect(selected, hours, setSelectedHour)
                                                        }
                                                        classNamePrefix="reactSelectBox"
                                                        placeholder="Select hour"
                                                        closeMenuOnSelect={false}
                                                    />
                                                </div>
                                            )}

                                            {["Minutely", "Hourly", "Monthly", "Daily"].includes(selectedAlertScheduleTypeValue?.label) && (
                                                <div className="fullWidthSelect">
                                                    <label>
                                                        Minutes<span className="text-danger">*</span>
                                                    </label>
                                                    <Select
                                                        isMulti
                                                        options={minutes}
                                                        value={selectedMinute}
                                                        onChange={(selected) =>
                                                            handleMultiSelect(selected, minutes, setSelectedMinute)
                                                        }
                                                        classNamePrefix="reactSelectBox"
                                                        placeholder="Select minutes"
                                                        closeMenuOnSelect={false}
                                                    />
                                                </div>
                                            )}
                                        </div>

                                        <div>
                                            {(selectedAlertChannelValue?.some((x) => x.label === "Email") || selectedAlertChannelValue?.some((x) => x.label === "SMS")) && (
                                                <>
                                                    <h5 className="fontWeight-600 fileConfigHead colorBlack mt-20  ">
                                                        Email / SMS Configuration
                                                    </h5>
                                                    <div className="hrGreyLine"></div>
                                                    <div style={{ height: "1rem" }}></div>
                                                </>
                                            )}
                                        </div>

                                        <div>
                                            {selectedAlertChannelValue?.some(x => x.label === "Email") && (
                                                <div className="fullWidthInput">
                                                    <label>Recipients (Email):</label>
                                                    <input
                                                        type="text"
                                                        placeholder="Enter comma separated Email Id's"
                                                        value={emailRecipients}
                                                        onChange={(e) => setEmailRecipients(e.target.value)}
                                                    />
                                                </div>
                                            )}
                                        </div>

                                        <div>
                                            {selectedAlertChannelValue?.some(x => x.label === "SMS") && (
                                                <div className="fullWidthInput">
                                                    <label>Recipients (SMS Number):</label>

                                                    <div
                                                        className="form-control form-control-sm d-flex flex-wrap align-items-center gap-2"
                                                        style={{ minHeight: "38px", cursor: "text" }}
                                                        onClick={() => inputRef.current?.focus()}
                                                    >
                                                        {chips.map((item, index) => (
                                                            <span
                                                                key={index}
                                                                className={item.isValid ? "badge bg-success text-white" : "badge bg-danger text-white"}
                                                            >
                                                                {item.number}
                                                            </span>
                                                        ))}

                                                        <input
                                                            ref={inputRef}
                                                            type="text"
                                                            style={{ border: "none", outline: "none", flex: 1, minWidth: 100 }}
                                                            placeholder="Enter 10 digit numbers"
                                                            value={currentText}
                                                            onChange={(e) => handleChipInput(e.target.value)}
                                                            onKeyDown={handleKeyPress}
                                                        />
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                        <div>
                                            {selectedAlertChannelValue?.some(x => x.label === "Email") && (
                                                <div className="fullWidthInput">
                                                    <label>Email Subject:</label>
                                                    <input
                                                        type="text"
                                                        placeholder="Enter suitable Email subject"
                                                        value={emailSubject}
                                                        onChange={(e) => setEmailSubject(e.target.value)}
                                                    />
                                                </div>
                                            )}
                                        </div>

                                        <div>
                                            {selectedAlertChannelValue?.some(x => x.label === "Email") && (
                                                <div className="fullWidthInput">
                                                    <label>Email Body:</label>
                                                    <textarea
                                                        rows="3"
                                                        placeholder="Enter suitable Email body"
                                                        value={emailBody}
                                                        onChange={(e) => setEmailBody(e.target.value)}
                                                    />
                                                </div>
                                            )}
                                        </div>

                                        <div>
                                            {selectedAlertChannelValue?.some(x => x.label === "Email") && (
                                                <div className="fullWidthInput">
                                                    <label>Email Footer:</label>
                                                    <textarea
                                                        rows="2"
                                                        placeholder="Enter suitable Email footer"
                                                        value={emailFooter}
                                                        onChange={(e) => setEmailFooter(e.target.value)}
                                                    />
                                                </div>
                                            )}
                                        </div>

                                        <div>
                                            {selectedAlertChannelValue?.some(x => x.label === "SMS") && (
                                                <div className="fullWidthInput">
                                                    <label>SMS Body:</label>
                                                    <textarea
                                                        rows="3"
                                                        placeholder="Enter suitable SMS body"
                                                        value={smsBody}
                                                        onChange={(e) => setSmsBody(e.target.value)}
                                                    />
                                                </div>
                                            )}
                                        </div>

                                        <div>
                                            {selectedAlertChannelValue?.some(x => x.label === "SMS") && (
                                                <div className="fullWidthInput">
                                                    <label>SMS Footer:</label>
                                                    <textarea
                                                        rows="2"
                                                        placeholder="Enter suitable SMS footer"
                                                        value={smsFooter}
                                                        onChange={(e) => setSmsFooter(e.target.value)}
                                                    />
                                                </div>
                                            )}
                                        </div>



                                        {selectedAlertChannelValue?.length > 0 && (
                                            <div className="inlineInputGroup">
                                                <label htmlFor="clientname">
                                                    Escalation Enabled? <span className="text-danger">*</span>
                                                </label>

                                                <input
                                                    type="checkbox"
                                                    className="form-check-input"
                                                    checked={isEscalationEnabled}
                                                    onChange={(e) => setIsEscalationEnabled(e.target.checked)}
                                                />

                                                {isEscalationEnabled && (
                                                    <button
                                                        className="btn btn-outline-primary escalationBtn ms-3"
                                                        onClick={handleEscalationConfig}
                                                    >
                                                        + Escalation Configuration
                                                    </button>
                                                )}
                                            </div>
                                        )}



                                    </div>
                                </div>



                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={handleSubmit}
                                        disabled={isShow}
                                    >Submit
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={() => navigate("/configuration/alert-config")}
                                        disabled={isShow}
                                    >Go Back
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div>
                    <Modal
                        centered
                        className="AddNewTableModal"
                        size='xl'
                        show={showModal}
                        onHide={() => setShowModal(false)}>
                        <Modal.Header closeButton>
                            <Modal.Title>Escalation Configuration</Modal.Title>
                        </Modal.Header>
                        <Modal.Body size='xl'>
                            <div
                                id="unmatchedFiltersCollapse"
                                className="accordion-collapse collapse show"
                                aria-labelledby="unmatchedFiltersHeading"
                                data-bs-parent="#unmatchedFilters"
                            >

                                <div className="accordion-body">
                                    <div className="configSelectBoxTop row">

                                        {escalations.map((item, index) => (
                                            <div key={index} className="card shadow-sm mb-3">
                                                <div className="card-body">
                                                    <h4 className="fontWeight-800 fileConfigHead colorBlack" style={{ textAlign: "center" }} >
                                                        Level {item.level}
                                                    </h4>

                                                    <h5 className="fontWeight-200 fileConfigHead colorBlack ">
                                                        Basic Information
                                                    </h5>
                                                    <div className="hrGreyLine"></div>
                                                    <div className="configSelectBoxTop row">


                                                        <div className="clientNameSelect col">
                                                            <label htmlFor="clientname">User</label>
                                                            <span className="text-danger font-size13">*</span>
                                                            <Select
                                                                options={users}
                                                                value={item.user}
                                                                onChange={(value) => {
                                                                    const updated = [...escalations];
                                                                    updated[index].user = value;
                                                                    setEscalations(updated);
                                                                }}
                                                                classNamePrefix="reactSelectBox"
                                                                placeholder="Select User"
                                                            />
                                                        </div>

                                                        <div className="clientNameSelect col">
                                                            <label htmlFor="clientname">Delay Type</label>
                                                            <span className="text-danger font-size13">*</span>
                                                            <Select
                                                                id="ddlChannel"
                                                                classNamePrefix="reactSelectBox"
                                                                value={item.delayType}
                                                                options={optionsAlertScheduleTypeType.map(x => (
                                                                    {
                                                                        value: x.alertScheduleTypeID,
                                                                        label: x.alertScheduleTypeName
                                                                    }
                                                                ))}
                                                                onChange={(value) => {
                                                                    const updated = [...escalations];
                                                                    updated[index].delayType = value;
                                                                    updated[index].month = null;
                                                                    updated[index].day = null;
                                                                    updated[index].hour = null;
                                                                    updated[index].minute = null;
                                                                    setEscalations(updated);
                                                                }}
                                                                placeholder="Select Schedule Type"
                                                            />
                                                        </div>

                                                        <div className="clientNameSelect col">
                                                            <label htmlFor="clientname">Notification Channels</label>
                                                            <span className="text-danger font-size13">*</span>
                                                            <Select
                                                                id="ddlChannel"
                                                                isMulti
                                                                value={escalations[index].channels}
                                                                classNamePrefix="reactSelectBox"
                                                                options={optionsAlertChannelType.map(x => (
                                                                    {
                                                                        value: x.alertChannelID,
                                                                        label: x.alertChannelName
                                                                    }
                                                                ))}
                                                                onChange={(value) => {
                                                                    const updated = [...escalations];
                                                                    updated[index].channels = value;

                                                                    const selectedLabels = value.map(c => c.label);

                                                                    if (!selectedLabels.includes("Email")) {
                                                                        updated[index].emailRecipients = "";
                                                                        updated[index].emailSubject = "";
                                                                        updated[index].emailBody = "";
                                                                        updated[index].emailFooter = "";
                                                                    }

                                                                    if (!selectedLabels.includes("SMS")) {
                                                                        updated[index].smsRecipients = "";
                                                                        setEscChips([]);
                                                                        setEscCurrentText("");
                                                                        updated[index].smsBody = "";
                                                                        updated[index].smsFooter = "";
                                                                    }

                                                                    setEscalations(updated);
                                                                }}
                                                                placeholder="Select Notification Channels"
                                                            />
                                                        </div>

                                                        <div>
                                                            {["Minutely", "Hourly", "Daily", "Weekly", "Monthly"].includes(item?.delayType?.label) && (
                                                                <>
                                                                    <h5 className="fontWeight-200 fileConfigHead colorBlack mt-20  ">
                                                                        Schedule / Frequency
                                                                    </h5>
                                                                    <div className="hrGreyLine"></div>
                                                                    <div style={{ height: "1rem" }}></div>
                                                                </>
                                                            )}
                                                        </div>

                                                        <div className="clientNameSelect">
                                                            {["Monthly"].includes(item?.delayType?.label) && (
                                                                <div className="fullWidthSelect">
                                                                    <label>
                                                                        Months<span className="text-danger">*</span>
                                                                    </label>
                                                                    <div className="select-col" >
                                                                        <Select
                                                                            options={months.filter(x => x.label !== "Select All")}
                                                                            value={item.month}
                                                                            onChange={(value) => {
                                                                                const updated = [...escalations];
                                                                                updated[index].month = value;
                                                                                setEscalations(updated);
                                                                            }}
                                                                            classNamePrefix="reactSelectBox"
                                                                            placeholder="Select Month"
                                                                        />
                                                                    </div>
                                                                </div>
                                                            )}

                                                            {["Monthly", "Daily"].includes(item?.delayType?.label) && (
                                                                <div className="fullWidthSelect">
                                                                    <label>
                                                                        Days<span className="text-danger">*</span>
                                                                    </label>
                                                                    <div className="select-col" >
                                                                        <Select
                                                                            options={monthDays.filter(x => x.label !== "Select All")}
                                                                            value={item.day}
                                                                            onChange={(value) => {
                                                                                const updated = [...escalations];
                                                                                updated[index].day = value;
                                                                                setEscalations(updated);
                                                                            }}
                                                                            classNamePrefix="reactSelectBox"
                                                                            placeholder="Select day of month"
                                                                        />
                                                                    </div>
                                                                </div>
                                                            )}

                                                            {["Hourly", "Monthly", "Daily"].includes(item?.delayType?.label) && (
                                                                <div className="fullWidthSelect">
                                                                    <label>
                                                                        Hours<span className="text-danger">*</span>
                                                                    </label>
                                                                    <div className="select-col" >
                                                                        <Select
                                                                            options={hours.filter(x => x.label !== "Select All")}
                                                                            value={item.hour}
                                                                            onChange={(value) => {
                                                                                const updated = [...escalations];
                                                                                updated[index].hour = value;
                                                                                setEscalations(updated);
                                                                            }}
                                                                            classNamePrefix="reactSelectBox"
                                                                            placeholder="Select hour"
                                                                        />
                                                                    </div>
                                                                </div>
                                                            )}

                                                            {["Minutely", "Hourly", "Monthly", "Daily"].includes(item?.delayType?.label) && (
                                                                <div className="fullWidthSelect">
                                                                    <label>
                                                                        Minutes<span className="text-danger">*</span>
                                                                    </label>
                                                                    <div className="select-col" >
                                                                        <Select
                                                                            options={minutes.filter(x => x.label !== "Select All")}
                                                                            value={item.minute}
                                                                            onChange={(value) => {
                                                                                const updated = [...escalations];
                                                                                updated[index].minute = value;
                                                                                setEscalations(updated);
                                                                            }}
                                                                            classNamePrefix="reactSelectBox"
                                                                            placeholder="Select minutes"
                                                                        />
                                                                    </div>
                                                                </div>
                                                            )}
                                                        </div>

                                                        <div>
                                                            {escalations[index]?.channels?.some(ch => ["Email", "SMS"].includes(ch.label)) && (
                                                                <>
                                                                    <h5 className="fontWeight-200 fileConfigHead colorBlack mt-20  ">
                                                                        Email / SMS Configuration
                                                                    </h5>
                                                                    <div className="hrGreyLine"></div>
                                                                    <div style={{ height: "1rem" }}></div>
                                                                </>
                                                            )}
                                                        </div>

                                                        <div>
                                                            {escalations[index].channels?.some(c => c.label === "Email") && (
                                                                <div className="fullWidthInput">
                                                                    <label>Recipients (Email):</label>
                                                                    <input
                                                                        type="text"
                                                                        className="form-control form-control-sm"
                                                                        placeholder="Enter comma separated Email IDs"
                                                                        value={escalations[index].emailRecipients || ""}
                                                                        onChange={(e) => {
                                                                            const updated = [...escalations];
                                                                            updated[index].emailRecipients = e.target.value;
                                                                            setEscalations(updated);
                                                                        }}
                                                                    />
                                                                </div>
                                                            )}
                                                        </div>

                                                        <div>
                                                            {escalations[index].channels?.some(x => x.label === "SMS") && (
                                                                <div className="fullWidthInput">
                                                                    <label>Recipients (SMS Number):</label>

                                                                    <div
                                                                        className="form-control form-control-sm d-flex flex-wrap align-items-center gap-2"
                                                                        style={{ minHeight: "38px", cursor: "text" }}
                                                                        onClick={() => escInputRef.current?.focus()}
                                                                    >
                                                                        {escChips.map((item, i) => (
                                                                            <span
                                                                                key={i}
                                                                                className={
                                                                                    item.isValid
                                                                                        ? "badge bg-success text-white"
                                                                                        : "badge bg-danger text-white"
                                                                                }
                                                                            >
                                                                                {item.number}
                                                                            </span>
                                                                        ))}
                                                                        <input
                                                                            ref={escInputRef}
                                                                            type="text"
                                                                            style={{
                                                                                border: "none",
                                                                                outline: "none",
                                                                                flex: 1,
                                                                                minWidth: 100
                                                                            }}
                                                                            placeholder="Enter 10 digit numbers"
                                                                            value={escCurrentText}
                                                                            onChange={(e) => handleEscChipInput(e.target.value, index)}
                                                                            onKeyDown={(e) => handleEscKeyPress(e, index)}
                                                                        />
                                                                    </div>
                                                                </div>
                                                            )}
                                                        </div>

                                                        <div>
                                                            {escalations[index].channels?.some(x => x.label === "Email") && (
                                                                <div className="fullWidthInput">
                                                                    <label>Email Subject:</label>
                                                                    <input
                                                                        type="text"
                                                                        placeholder="Enter suitable Email subject"
                                                                        value={escalations[index].emailSubject}
                                                                        onChange={(e) => {
                                                                            const updated = [...escalations];
                                                                            updated[index].emailSubject = e.target.value;
                                                                            setEscalations(updated);
                                                                        }}
                                                                    />
                                                                </div>
                                                            )}
                                                        </div>

                                                        <div>
                                                            {escalations[index].channels?.some(x => x.label === "Email") && (
                                                                <div className="fullWidthInput">
                                                                    <label>Email Body:</label>
                                                                    <textarea
                                                                        rows="3"
                                                                        placeholder="Enter suitable Email body"
                                                                        value={escalations[index].emailBody}
                                                                        onChange={(e) => {
                                                                            const updated = [...escalations];
                                                                            updated[index].emailBody = e.target.value;
                                                                            setEscalations(updated);
                                                                        }}
                                                                    />
                                                                </div>
                                                            )}
                                                        </div>

                                                        <div>
                                                            {escalations[index].channels?.some(x => x.label === "Email") && (
                                                                <div className="fullWidthInput">
                                                                    <label>Email Footer:</label>
                                                                    <textarea
                                                                        rows="2"
                                                                        placeholder="Enter suitable Email footer"
                                                                        value={escalations[index].emailFooter}
                                                                        onChange={(e) => {
                                                                            const updated = [...escalations];
                                                                            updated[index].emailFooter = e.target.value;
                                                                            setEscalations(updated);
                                                                        }}
                                                                    />
                                                                </div>
                                                            )}
                                                        </div>

                                                        <div>
                                                            {escalations[index].channels?.some(x => x.label === "SMS") && (
                                                                <div className="fullWidthInput">
                                                                    <label>SMS Body:</label>
                                                                    <textarea
                                                                        rows="3"
                                                                        placeholder="Enter suitable SMS body"
                                                                        value={escalations[index].smsBody}
                                                                        onChange={(e) => {
                                                                            const updated = [...escalations];
                                                                            updated[index].smsBody = e.target.value;
                                                                            setEscalations(updated);
                                                                        }}
                                                                    />
                                                                </div>
                                                            )}
                                                        </div>

                                                        <div>
                                                            {escalations[index].channels?.some(x => x.label === "SMS") && (
                                                                <div className="fullWidthInput">
                                                                    <label>SMS Footer:</label>
                                                                    <textarea
                                                                        rows="2"
                                                                        placeholder="Enter suitable SMS footer"
                                                                        value={escalations[index].smsFooter}
                                                                        onChange={(e) => {
                                                                            const updated = [...escalations];
                                                                            updated[index].smsFooter = e.target.value;
                                                                            setEscalations(updated);
                                                                        }}
                                                                    />
                                                                </div>
                                                            )}
                                                        </div>

                                                    </div>

                                                </div>
                                            </div>
                                        ))}

                                        <div className="text-center btnsBtm">
                                            <br />
                                            <button
                                                type="button"
                                                className="btnPrimaryOutline"
                                                onClick={(e) => onResetEscalation(e)}
                                            >
                                                Reset
                                            </button>
                                            <button
                                                type="button"
                                                className="btnPrimary ms-2"
                                                onClick={onProceedEscalation}
                                                disabled={isShow}
                                            >Submit
                                            </button>
                                            <button
                                                type="button"
                                                className="btnPrimary ms-2"
                                                onClick={addNewEscalationLevel}
                                            > + Add Level
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Modal.Body>
                    </Modal>
                </div>
            </div>
            <LoadingSpinner isShow={false} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div >
    );
};

export default AlertConfigAddNew;
