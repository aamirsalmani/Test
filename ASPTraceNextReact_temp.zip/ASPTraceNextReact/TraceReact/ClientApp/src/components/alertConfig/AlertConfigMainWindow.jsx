import React, { useState } from "react";
import { Link } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import AsyncSelect from 'react-select/async';
import MaximusAxios from "../common/apiURL";
import "datatables.net-dt/js/dataTables.dataTables";
import { useSelector } from "react-redux";
import Select from "react-select";
import 'jquery/dist/jquery.min.js';
import { useNavigate } from "react-router-dom";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { Modal, Button } from "react-bootstrap";
import { splitCamelCase } from "../common/Utils";

// Images
import Delete from "../../images/common/redDelete.svg";
import editRow from "../../images/common/editRow.svg";
import openeye from "../../images/common/openeye.svg";


const AlertConfigMainWindow = () => {

    const navigate = useNavigate();

    const [Show, setShow] = useState(false);
    const [showModal, setShowModal] = useState(false);
    const [modalType, setModalType] = useState(null);




    const [alertJson, setShowMessageBox] = useState({
        isShow: false,
        alertVariant: "success",
        alertTitle: "",
        alertMessage: "",
    });
    const [selectedClientValue, setSelectedClientValue] = useState(null);
    const [isShow, setIsLoading] = useState(false);
    const [selectedAlertTypeValue, setSelectedAlertTypeValue] = useState(null);
    const [optionsAlertType, setOptionsAlertType] = useState([{ alertID: "0", alertName: "ALL" }]);
    const [selectedSeverityTypeValue, setSelectedSeverityTypeValue] = useState(null);
    const [optionsSeverityType, setOptionsSeverityType] = useState([{ severityID: "0", severityName: "ALL" }]);
    const [selectedCreatedByValue, setSelectedCreatedByValue] = useState(null);
    const [optionsCreatedBy, setOptionsCreatedBy] = useState([{ iD: "0", userId: "ALL" }]);

    const [AlertConfigData, setAlertConfigData] = useState(null);
    const [ModalData, setmodalData] = useState(null);

    const currentUser = useSelector((state) => state.authReducer);

    const CONFIG_TYPES = {
        SCHEDULE: "schedule",
        DESCRIPTION: "description",
        EMAIL: "email",
        SMS: "sms",
        ESCALATION: "escalation"
    };


    const fetchClientData = (inputValue) => {
        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, { mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    };

   

    const handleClientChange = value => {
        setShow(false);
        setSelectedClientValue(value);
        setSelectedAlertTypeValue(null);
        setSelectedSeverityTypeValue(null);
        setSelectedCreatedByValue(null);
        setIsLoading(true);
        MaximusAxios.get('api/Common/GetAlertTypeList', { mode: 'cors' }).then(resultChannel => {
            setOptionsAlertType(resultChannel.data);
            setIsLoading(false);
        }).catch(function (error) {
            console.log(error.response);
        });
        setIsLoading(false);
    };

    const handleAlertTypeChange = value => {
        setShow(false);
        setSelectedAlertTypeValue(value);
        setSelectedSeverityTypeValue(null);
        setSelectedCreatedByValue(null);
        setIsLoading(true);
        MaximusAxios.get('api/Common/GetAlertSeverityList', { mode: 'cors' }).then(resultMode => {
            setOptionsSeverityType(resultMode.data);
        }).catch(function (error) {
            console.log(error.response);
        });
        setIsLoading(false);
    };

    const handleSeverityTypeChange = value => {
        setShow(false);
        setSelectedSeverityTypeValue(value);
        setSelectedCreatedByValue(null);
        setIsLoading(true);
        MaximusAxios.get('api/Logger/GetUserList', { mode: 'cors' }).then(resultMode => {
            setOptionsCreatedBy([
                { iD: "0", userId: "ALL" },
                ...resultMode.data
            ]);
        }).catch(function (error) {
            console.log(error.response);
        });
        setIsLoading(false);
    };

    const handleCreatedByChange = value => {
        setShow(false);
        setSelectedCreatedByValue(value);
    };

    const onResetFilter = (e) => {
        e.preventDefault();
        setShow(false);
        setSelectedClientValue(null);
        setSelectedAlertTypeValue(null);
        setSelectedSeverityTypeValue(null);
        setSelectedCreatedByValue(null);
    };


    const onShowClick = () => {
        setAlertConfigData([])
        let alertMessages = "";

        if (selectedClientValue === null || selectedClientValue === undefined) {
            alertMessages += "Please select client. \n";
        }
        else if (selectedAlertTypeValue === undefined || selectedAlertTypeValue === null) {
            alertMessages += "Please select Alert Type. \n";
        }
        else if (selectedSeverityTypeValue === undefined || selectedSeverityTypeValue === null) {
            alertMessages += "Please select Severity Type. \n";
        }
        else if (selectedCreatedByValue === undefined || selectedCreatedByValue === null) {
            alertMessages += "Please select Created By. \n";
        }
        if (alertMessages.length > 0) {
            setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
            return false;
        }

        setIsLoading(true);
        MaximusAxios.post('api/AlertConfig/GetAlertConfigData', {
            ClientID: String(selectedClientValue.clientID),
            AlertTypeID: String(selectedAlertTypeValue.value),
            AlertSeverityID: String(selectedSeverityTypeValue.value),
            CreatedBy: String(selectedCreatedByValue.value),
        }, { mode: 'cors' })
            .then(function (response) {
                if (response.data.length > 0) {
                    setAlertConfigData(response.data);
                    setIsLoading(false);
                    setShow(true);
                }
                else {
                    alert("No Records Found!");
                    setIsLoading(false);
                }
            })
            .catch(function (error) {
                console.log(error.response);
                setIsLoading(false);
            });
    };

    const onCancelClick = () => {
        setModalType(null)
        setmodalData(null);
        setShowModal(false);
    };


    const openConfigPopup = (alertId, type) => {
        setModalType(type);
        fetchConfigData(alertId, type);
        setShowModal(true);
    };


    const fetchConfigData = (alertId, type) => {
        MaximusAxios.get(
            `api/AlertConfig/GetAdditionalDataByAlertID?AlertId=${alertId}&Type=${type}`
        )
            .then((result) => {
                setmodalData(result.data);
            })
            .catch(err => {
                console.log(err);
                alert("Error fetching config details.");
            });
    };


    return (
        <div className="configLeft identificationContainer">
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Alert Configuration
                </h5>
                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Configuration</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Alert Configuration</p>
                </div>

            </div>


            <div className="configLeftBottom">
                <div className="accordion" id="unmatchedFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="unmatchedFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>

                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#unmatchedFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="unmatchedFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="unmatchedFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="unmatchedFiltersHeading"
                            data-bs-parent="#unmatchedFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedClientValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Alert Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedAlertTypeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsAlertType.map(x => (
                                                {
                                                    value: x.alertID,
                                                    label: x.alertName
                                                }
                                            ))}
                                            onChange={handleAlertTypeChange}
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Severity</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedSeverityTypeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsSeverityType.map(x => (
                                                {
                                                    value: x.severityID,
                                                    label: x.severityName
                                                }
                                            ))}
                                            onChange={handleSeverityTypeChange}
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Created By</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedCreatedByValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsCreatedBy.map(x => (
                                                {
                                                    value: x.iD,
                                                    label: x.userId
                                                }
                                            ))}
                                            onChange={handleCreatedByChange}
                                        />
                                    </div>

                                </div>

                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onResetFilter(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onShowClick}
                                        disabled={isShow}
                                    >Show
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={() => navigate("/configuration/alert-config/add")}
                                        disabled={isShow}
                                    >Add New
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


            {/* Table Content */}

            <div className="configLeftBottom">
                {(AlertConfigData === null || AlertConfigData.length === 0) &&
                    <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div>
                }
                {/* Table */}
                {(AlertConfigData !== null && AlertConfigData.length > 0 && Show ) ? (
                    <div>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                {(AlertConfigData != null && AlertConfigData.length > 0) ? (
                                    <div className="table-responsive tableContentBox" >
                                        <table id="gvUPISettlementReportPDF" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }}>
                                            <thead>
                                                <tr style={{ border: "1px dashed black !important" }}>
                                                    <th scope="col">Client Name</th>
                                                    <th scope="col">Alert Name</th>
                                                    <th scope="col">Alert Type</th>
                                                    <th scope="col">Severity</th>
                                                    <th scope="col">Alert Channels</th>
                                                    <th scope="col">Schedule Type</th>
                                                    <th scope="col">SPName</th>
                                                    <th scope="col">Schedule/Frequency</th>
                                                    <th scope="col">Description</th>
                                                    <th scope="col">Email Config</th>
                                                    <th scope="col">SMS Config</th>
                                                    <th scope="col">Escalation</th>
                                                    <th scope="col">CreatedBy</th>
                                                    <th scope="col">CreatedOn</th>
                                                    <th scope="col">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {AlertConfigData.map((p, index) => (
                                                    <tr key={index}>
                                                        <td>{p.clientName}</td>
                                                        <td>{p.alertName}</td>
                                                        <td>{p.alertTypeName}</td>
                                                        <td>{p.alertSeverityName}</td>
                                                        <td>{p.alertChannels}</td>
                                                        <td>{p.scheduleType}</td>
                                                        <td>{p.spName}</td>
                                                        <td>
                                                            <button type="button" className="iconButtonBox">
                                                                <img src={openeye} alt="Edit" title="Open Schedule Details" onClick={() => openConfigPopup(p.alertID, CONFIG_TYPES.SCHEDULE)} />
                                                            </button>
                                                        </td>
                                                        <td>{p.description === "Yes" ? (
                                                            <button type="button" className="iconButtonBox">
                                                                <img src={openeye} alt="Edit" title="Open Description" onClick={() => openConfigPopup(p.alertID, CONFIG_TYPES.DESCRIPTION)} />
                                                            </button>
                                                        ) : "No Data"}</td>
                                                        <td>{p.hasEmailConfig === "Yes" ? (
                                                            <button type="button" className="iconButtonBox">
                                                                <img src={openeye} alt="Edit" title="Open Email Details" onClick={() => openConfigPopup(p.alertID, CONFIG_TYPES.EMAIL)} />
                                                            </button>
                                                        ) : "No Data"}</td>
                                                        <td>{p.hasSmsConfig === "Yes" ? (
                                                            <button type="button" className="iconButtonBox">
                                                                <img src={openeye} alt="Edit" title="Open SMS Details" onClick={() => openConfigPopup(p.alertID, CONFIG_TYPES.SMS)} />
                                                            </button>
                                                        ) : "No Data"}</td>
                                                        <td>{p.hasEscalationConfig === "Yes" ? (
                                                            <button type="button" className="iconButtonBox">
                                                                <img src={openeye} alt="Edit" title="Open Escalation Details" onClick={() => openConfigPopup(p.alertID, CONFIG_TYPES.ESCALATION)} />
                                                            </button>
                                                        ) : "No Data"}</td>
                                                        <td>{p.createdBy}</td>
                                                        <td>{p.createdOn}</td>
                                                        <td>
                                                            <div className="text-center">
                                                                <button type="button" className="iconButtonBox">
                                                                    <img src={editRow} alt="Edit" title="Edit" />
                                                                </button>
                                                                <button type="button" className="iconButtonBox">
                                                                    <img src={Delete} alt="Delete" title="Delete" />
                                                                </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                ) : null
                                }
                            </div>
                        </div>
                    </div>
                ) : null}
            </div>


            <div>
                <Modal
                    centered
                    className="AddNewTableModal"
                    size='xl'
                    show={showModal}
                    onHide = { onCancelClick }>

                    <Modal.Header closeButton>
                        <Modal.Title>
                            {modalType === CONFIG_TYPES.DESCRIPTION && "Description Details"}
                            {modalType === CONFIG_TYPES.SCHEDULE && "Schedule Config Details"}
                            {modalType === CONFIG_TYPES.EMAIL && "Email Config Details"}
                            {modalType === CONFIG_TYPES.SMS && "SMS Config Details"}
                            {modalType === CONFIG_TYPES.ESCALATION && "Escalation Config Details"}
                        </Modal.Title>
                    </Modal.Header>

                    <Modal.Body size='xl'>
                        <div className="configLeftBottom">
                            {(ModalData === null || ModalData.length === 0) &&
                                <div className="tableBorderBox pb-3 pt-3">
                                    <div className="clientNameSelect configFormatEntities">
                                        <p className="text-danger font-size12">No Records</p>
                                    </div>
                                </div>
                            }

                            {(ModalData !== null && ModalData.length > 0) ? (
                                <div>
                                    <div className="tableBorderBox pt-3">
                                        <div className="w-100 table-responsive">
                                            {(ModalData != null && ModalData.length > 0) ? (
                                                <div className="table-responsive tableContentBox" >
                                                    <table id="gvUPISettlementReportPDF" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }}>
                                                        <thead>
                                                            <tr>
                                                                {Object.keys(ModalData[0]).map((Column) => {
                                                                    return (
                                                                        <>
                                                                            <th scope="col">{splitCamelCase(Column)}</th>
                                                                        </>
                                                                    );
                                                                })}
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {ModalData.map((Row, index) => {
                                                                return (
                                                                    <tr key={index}>
                                                                        {Object.keys(ModalData[index]).map(
                                                                            (Column) => {
                                                                                return (
                                                                                    <>
                                                                                        <td>{Row[Column]}</td>
                                                                                    </>
                                                                                );
                                                                            }
                                                                        )}
                                                                    </tr>
                                                                );
                                                            })}
                                                        </tbody>
                                                    </table>
                                                </div>
                                            ) : null
                                            }
                                        </div>
                                    </div>
                                </div>
                            ) : null}
                        </div>
                    </Modal.Body>

                    <Modal.Footer>
                        <Button variant="secondary" onClick={onCancelClick}>Cancel</Button>
                    </Modal.Footer>
                </Modal>
            </div>
            <LoadingSpinner isShow={false} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default AlertConfigMainWindow;
