﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import AdjustmentReportMainWindow from "./AdjustmentReportMainWindow";

const AdjustmentReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <AdjustmentReportMainWindow />
        </div>
    );
};

export default AdjustmentReport;
