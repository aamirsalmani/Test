﻿import { React, useState } from "react";
import Select from "react-select";
import AsyncSelect from "react-select/async";
import { Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import { useSelector } from "react-redux";
import authHeader from "../../../pages/login/services/auth-header";

import MaximusAxios from "../../common/apiURL";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import $ from "jquery";
import "jquery/dist/jquery.min.js";

import ExcelJS from "exceljs";
import { saveAs } from "file-saver";

// Images
import Pdf from "../../../images/common/pdf.svg";
import CsvIcon from "../../../images/common/csv.svg";
import ExcelIcon from "../../../images/common/excel.svg";
import { formatDate, splitCamelCase } from "../../common/Utils";

import jsPDF from "jspdf";
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";

const optionsReportType = [
  { value: "1", label: "ATM Adjustment" },
  { value: "2", label: "IMPS Adjustment" },
  { value: "3", label: "UPI Adjustment" },
  { value: "4", label: "POS Adjustment(Refund)" },
];

const AdjustmentReportMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [isShowATMAdjustment, setIsShowATMAdjustment] = useState(false);
  const [isShowIMPSAdjustment, setIsShowIMPSAdjustment] = useState(false);
  const [isShowPOSAdjustment, setIsShowPOSAdjustment] = useState(false);

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const fetchClientData = (inputValue) => {
    setStartDate(null);
    setEndDate(null);

    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  const [inputValue, setValue] = useState("0");
  const [selectedValue, setSelectedValue] = useState(null);
  const [titleDate, setTitleDateValue] = useState("");

  // handle input change event
  const handleInputChange = (value) => {
    setValue(value);
  };

  const [selectedReportTypeValue, setSelectedReportTypeValue] = useState(null);

  const handleClientChange = (value) => {
    setAdjustmentReport(null);
    setSelectedReportTypeValue(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedValue(value);
  };

  const handleReportTypeChange = (value) => {
    setAdjustmentReport(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedReportTypeValue(value);

    if (value.value === "1") {
      setIsShowATMAdjustment(true);
    } else {
      setIsShowATMAdjustment(false);
    }
    if (value.value === "2") {
      setIsShowIMPSAdjustment(true);
    } else {
      setIsShowIMPSAdjustment(false);
    }
  };

  //   Date Calendar
  const [startDate, setStartDate] = useState(new Date());
  //   Date Calendar
  const [endDate, setEndDate] = useState(new Date());

  const setStartDateValue = (value) => {
    setStartDate(value);
    setEndDate(value);
    setAdjustmentReport(null);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date ");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    setAdjustmentReport(null);
  };

  const [AdjustmentReport, setAdjustmentReport] = useState(null);

  // Tooltip
  const renderTooltip = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to pdf
    </Tooltip>
  );

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to excel
    </Tooltip>
  );

  const onReset = (e) => {
    e.preventDefault();
    // window.location.reload(false);
    setAdjustmentReport(null);
    setSelectedReportTypeValue(null);
    selectedReportTypeValue(null);
    setSelectedValue(null);
    setEndDate(null);
    setStartDate(null);
    setTitleDateValue(null);
    setIsShowPOSAdjustment(false);
    setIsShowIMPSAdjustment(false);
    setIsShowATMAdjustment(false);
  };

  const onSubmit = () => {
    if (currentUser !== null && currentUser.user !== null) {
      setAdjustmentReport(null);

      if (selectedValue === null || selectedValue.clientID === 0) {
        alert("Please select client!");
        return false;
      }

      if (
        selectedReportTypeValue === undefined ||
        selectedReportTypeValue === null
      ) {
        alert("Please select Report Type!");
        return false;
      }

      if (startDate === undefined || startDate === null) {
        alert("Please enter From Date!");
        return false;
      }

      if (endDate === undefined || endDate === null) {
        alert("Please enter To Date!");
        return false;
      }

      let ReportTypeX = "";

      if (
        selectedReportTypeValue === undefined ||
        selectedReportTypeValue === null
      ) {
        ReportTypeX = "";
      } else {
        ReportTypeX = selectedReportTypeValue.value;
      }

      console.log(selectedReportTypeValue);

      setIsLoading(true);

      MaximusAxios.post(
        "api/AuditReport/GetAdjustmentTxnsReportList",
        {
          ClientID: selectedValue.clientID,
          TR_POSTDATE: formatDate(startDate),
          TR_ENDDATE: formatDate(endDate),
          ReportType: ReportTypeX,
          UserName: currentUser.user.username,
        },
        { mode: "cors" }
      )
        .then(function (response) {
          setAdjustmentReport(response.data);
          setTitleDateValue(
            "Report Date : " +
              formatDate(startDate) +
              " To " +
              formatDate(endDate)
          );
          setIsLoading(false);
          if (response.data === null || response.data.length === 0) {
            setShowMessageBox({
              isShow: true,
              alertVariant: "info",
              alertTitle: "Info",
              alertMessage: "No records found",
            });
          }
        })
        .catch(function (error) {
          setTitleDateValue("");
          if (error.response) {
            console.log(error.response.data);
            setShowMessageBox({
              isShow: true,
              alertVariant: "danger",
              alertTitle: "Error",
              alertMessage: "Error occurred while processing your request",
            });
          }
          setIsLoading(false);
        });
    } else {
      alert("Session Timeout");
    }
  };

  $(document).ready(function () {
    if (AdjustmentReport !== null && AdjustmentReport.length > 0) {
      $("#gvAdjustmentReportPDF").DataTable();
    }
  });

  function POSRefundFiledate(inputDate) {
    const date = new Date(inputDate);

    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0"); // zero-based month
    const year = date.getFullYear(); // full year

    return `${day}-${month}-${year}`;
  }

  const ExportToExcelKS = () => {
    if (currentUser !== null && currentUser.user !== null) {
      setAdjustmentReport(null);

      if (selectedValue === null || selectedValue.clientID === 0) {
        alert("Please select client!");
        return false;
      }

      if (
        selectedReportTypeValue === undefined ||
        selectedReportTypeValue === null
      ) {
        alert("Please select Report Type!");
        return false;
      }

      if (startDate === undefined || startDate === null) {
        alert("Please enter From Date!");
        return false;
      }

      if (endDate === undefined || endDate === null) {
        alert("Please enter To Date!");
        return false;
      }

      let ReportTypeX = "";

      if (
        selectedReportTypeValue === undefined ||
        selectedReportTypeValue === null
      ) {
        ReportTypeX = "";
      } else {
        ReportTypeX = selectedReportTypeValue.value;
      }

      //console.log(selectedReportTypeValue);

      //RefundTxns Report
      let FileName = "";
      console.log(selectedValue.clientID + selectedReportTypeValue.value);
      if (
        selectedValue.clientID === "82" &&
        selectedReportTypeValue.value === "4"
      ) {
        FileName =
          "RefundTxns Report " + POSRefundFiledate(startDate) + ".xlsx";
      } else {
        FileName =
          selectedReportTypeValue.label +
          " Report_" +
          formatDate(startDate) +
          ".xlsx";
      }

      setIsLoading(true);

      MaximusAxios.post(
        "api/Excel/ExportExcelAdjustment",
        {
          ClientID: selectedValue.clientID,
          TR_POSTDATE: formatDate(startDate),
          TR_ENDDATE: formatDate(endDate),
          ReportType: ReportTypeX,
          UserName: currentUser.user.username,
          ChannelName: selectedReportTypeValue.label,
        },
        { mode: "cors", responseType: "blob" }
      )
        .then(function (response) {
          saveAs(response.data, FileName);
          setIsLoading(false);
        })
        .catch(function (error) {
          if (error.response) {
            setShowMessageBox({
              isShow: true,
              alertVariant: "danger",
              alertTitle: "Error",
              alertMessage: "Error occurred while processing your request",
            });
            console.log(error.response.data);
          }
          setIsLoading(false);
        });
    } else {
      alert("Session Timeout");
    }
  };

  const ExportToCsvKS = () => {
    if (currentUser !== null && currentUser.user !== null) {
      setAdjustmentReport(null);

      if (selectedValue === null || selectedValue.clientID === 0) {
        alert("Please select client!");
        return false;
      }

      if (
        selectedReportTypeValue === undefined ||
        selectedReportTypeValue === null
      ) {
        alert("Please select Report Type!");
        return false;
      }

      if (startDate === undefined || startDate === null) {
        alert("Please enter From Date!");
        return false;
      }

      if (endDate === undefined || endDate === null) {
        alert("Please enter To Date!");
        return false;
      }

      let ReportTypeX = "";

      if (
        selectedReportTypeValue === undefined ||
        selectedReportTypeValue === null
      ) {
        ReportTypeX = "";
      } else {
        ReportTypeX = selectedReportTypeValue.value;
      }

      //console.log(selectedReportTypeValue);
      let FileName = "";

      if (
        selectedValue.clientID === "82" &&
        selectedReportTypeValue.value === "4"
      ) {
        FileName = "RefundTxns Report " + POSRefundFiledate(startDate) + ".csv";
      } else {
        FileName =
          selectedReportTypeValue.label +
          " Report_" +
          formatDate(startDate) +
          ".csv";
      }

      setIsLoading(true);

      MaximusAxios.post(
        "api/Excel/ExportCsvAdjustment",
        {
          ClientID: selectedValue.clientID,
          TR_POSTDATE: formatDate(startDate),
          TR_ENDDATE: formatDate(endDate),
          ReportType: ReportTypeX,
          UserName: currentUser.user.username,
          ChannelName: selectedReportTypeValue.label,
        },
        { mode: "cors", responseType: "blob" }
      )
        .then(function (response) {
          saveAs(response.data, FileName);
          setIsLoading(false);
        })
        .catch(function (error) {
          if (error.response) {
            setShowMessageBox({
              isShow: true,
              alertVariant: "danger",
              alertTitle: "Error",
              alertMessage: "Error occurred while processing your request",
            });
            console.log(error.response.data);
          }
          setIsLoading(false);
        });
    } else {
      alert("Session Timeout");
    }
  };

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Adjustment Report
        </h5>

        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Audit Reports</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Adjustment Report</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="unmatchedFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="unmatchedFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#unmatchedFiltersCollapse"
                aria-expanded="true"
                aria-controls="unmatchedFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="unmatchedFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="unmatchedFiltersHeading"
              data-bs-parent="#unmatchedFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>
                  <div className="clientNameSelect col" id="dvReportType">
                    <label htmlFor="ReportType">Report Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      value={selectedReportTypeValue}
                      options={optionsReportType}
                      id="ddlReportType"
                      onChange={handleReportTypeChange}
                      classNamePrefix="reactSelectBox"
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onSubmit}
                    disabled={isShow}
                  >
                    Show
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={ExportToExcelKS}
                    disabled={isShow}
                  >
                    Download Excel
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={ExportToCsvKS}
                    disabled={isShow}
                  >
                    Download CSV
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Content */}
      <div className="configLeftBottom">
        {(AdjustmentReport === null || AdjustmentReport.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {/* Table */}
            {AdjustmentReport != null && AdjustmentReport.length > 0 ? (
              <div>
                <div className="exportButton">
                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltipExcel}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={ExportToExcelKS}
                    >
                      <img src={ExcelIcon} alt="Excel" />
                    </button>
                  </OverlayTrigger>

                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltip}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={ExportToCsvKS}
                    >
                      <img src={CsvIcon} alt="Pdf" />
                    </button>
                  </OverlayTrigger>
                </div>
                <div className="tableBorderBox pt-3">
                  <div className="w-100 table-responsive">
                    <div className="table-responsive tableContentBox">
                      <table
                        id="gvAdjustmentReportPDF"
                        className="table table-striped table-hover table-borderless align-middle"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            {Object.keys(AdjustmentReport[0]).map((Column) => {
                              return (
                                <>
                                  <th scope="col">{splitCamelCase(Column)}</th>
                                </>
                              );
                            })}
                          </tr>
                        </thead>
                        <tbody>
                          {AdjustmentReport.map((Row, index) => {
                            return (
                              <tr key={index}>
                                {Object.keys(AdjustmentReport[index]).map(
                                  (Column) => {
                                    return (
                                      <>
                                        <td scope="col">{Row[Column]}</td>
                                      </>
                                    );
                                  }
                                )}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        )}
      </div>
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default AdjustmentReportMainWindow;
