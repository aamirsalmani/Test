﻿import React from "react";
import { useSelector } from "react-redux";
// Components
import SidebarMain from "../../common/SidebarMain";
import AllSettlementReportMainWindow from "./AllSettlementReportMainWindow";

const AllSettlementReport = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView">
        <AllSettlementReportMainWindow />
    </div>
  );
};

export default AllSettlementReport;
