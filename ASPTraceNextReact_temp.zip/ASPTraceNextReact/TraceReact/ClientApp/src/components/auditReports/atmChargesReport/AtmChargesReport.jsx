﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import AtmChargesReportMainWindow from "./AtmChargesReportMainWindow";

const AdjustmentReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView d-flex">
            <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
                <AtmChargesReportMainWindow />
            </div>
        </div>
    );
};

export default AdjustmentReport;
