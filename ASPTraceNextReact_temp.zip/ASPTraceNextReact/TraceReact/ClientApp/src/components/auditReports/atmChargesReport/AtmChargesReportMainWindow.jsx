﻿import { React, useState } from "react";
import Select from "react-select";
import AsyncSelect from 'react-select/async';
import { Tooltip, OverlayTrigger} from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL" ;
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import { useSelector } from "react-redux"; 
import authHeader from "../../../pages/login/services/auth-header";


//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

import ExcelJS from "exceljs";
import { saveAs } from 'file-saver';

// Images
import Pdf from "../../../images/common/pdf.svg";
import ExcelIcon from "../../../images/common/excel.svg";

import jsPDF from 'jspdf'
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";

const optionsTxnType = [
    { value: "1", label: "Receivable" },
    { value: "2", label: "Payable" },
];

const AtmChargesReportMainWindow = () => {

    const currentUser = useSelector((state) => state.authReducer);

    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }

    const [isShow, setIsLoading] = useState(false);    
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];

    const fetchClientData = (inputValue) => {
        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);
    const [titleDate, setTitleDateValue] = useState(''); 


    const handleInputChange = value => {
        setValue(value);
    };    

    const [optionsTerminalType, setOptionsTerminalValue] = useState([{ ID: "0", TERMINALID: "All" }]);

    const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

    const [selectedTxnTypeValue, setSelectedTxnTypeValue] = useState(null);
         
    const handleOptionsTerminalType = value => {
        setOptionsTerminalValue(value);
    };


    const handleClientChange = value => {
        setATMChargesReport(null);
        setSelectedTxnTypeValue(null);
        setSelectedTerminalValue(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedValue(value);
    }


    const handleTxnTypeChange = value => {

        if (currentUser !== null && currentUser.user !== null) {

            setATMChargesReport(null);
            setSelectedTerminalValue(null);
            //setStartDate(null);
            //setEndDate(null);
            setSelectedTxnTypeValue(value);


            if (value.value === '1')

                if (value.value !== '0' && selectedValue.clientID !== '0') {
                    return MaximusAxios.get('api/Common/GetTerminalOptionList?ClientID=' + selectedValue.clientID + '&ChannelID=' + value.value + '&UserName=' + currentUser.user.username, {  mode: 'cors' }).then(result => {

                        var resData = result.data;

                        var myObj = { "ID": "0", "TERMINALID": "All" };

                        resData.push(myObj);

                        handleOptionsTerminalType(resData);
                    });
                }
        } else {

            alert('Session Timeout');
        }
    }

    const handleTerminalChange = value => {
        setATMChargesReport(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedTerminalValue(value);
    }

    const [ATMChargesReport, setATMChargesReport] = useState(null);

    //   Date Calendar
    const [startDate, setStartDate] = useState(new Date());
    //   Date Calendar
    const [endDate, setEndDate] = useState(new Date());

    const setStartDateValue = value => {
        setStartDate(value);
        setATMChargesReport(null);
    }

    const setEndDateValue = value => {

        if (startDate === null) {
            setEndDate(null);
            alert('Please enter From date first');
        }
        else {
            if (startDate > value) {
                alert('To date must be greater than From date ');
                setEndDate(null);
            }
            else {
                setEndDate(value);
            }
        }
        setATMChargesReport(null);
    }


    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }

    //const downloadExcel = () => {

    //    if (ATMChargesReport !== null) {
    //        if (ATMChargesReport.length > 0) {
    //            var data = $("#gvATMChargesReportPDF").dataTable()._('tr', { "filter": "applied" });
    //            let filterDataExcel = [];
    //            let cntrow = 0;
    //            //console.log(data);
    //            for (let i = 0; i < data.length; i++) {
    //                var arr = { "Date": data[cntrow][0], "Txn_Type": data[cntrow][1], "No_of_Txn": data[cntrow][2], "Interchange_Non_Fanancial": data[cntrow][3], "Interchange_Fanancial": data[cntrow][4], "NonFanancialGST": data[cntrow][5], "FanancialGST": data[cntrow][6], "Total_Interchange": data[cntrow][7], "Total_GST": data[cntrow][8], "Total_Amount": data[cntrow][9]}
    //                filterDataExcel.push(arr);
    //                cntrow++;
    //            }
    //            //console.log(filterDataExcel);
    //            var wb = XLSX.utils.book_new();
    //            var ws = XLSX.utils.json_to_sheet(filterDataExcel);
    //            XLSX.utils.book_append_sheet(wb, ws);
    //            XLSX.writeFile(wb, "ATMCharges Report.xlsx");
    //        } else {
    //            alert('No Record Found');
    //        }
    //    } else {
    //        alert('No Record Found');
    //    }


    //};


    const downloadPDF = () => {
        if (ATMChargesReport !== null) {
            if (ATMChargesReport.length > 0) {

                MaximusAxios.get('api/Common/GetClientLogoImage?ClientId=' + selectedValue.clientID, {  mode: 'cors' }).then(result => {

                    const title = "ATM Charges Report";
                    const headers = [["Date", "Txn_Type", "No_of_Txn", "Interchange_Non_Fanancial", "Interchange_Fanancial", "NonFanancialGST", "FanancialGST", "Total_Interchange", "Total_GST", "Total_Amount"]];

                    var data = $("#gvATMChargesReportPDF").dataTable()._('tr', { "filter": "applied" });
                    let filterDataPDF = [];
                    let cntrow = 0;
                    console.log(data);
                    for (let i = 0; i < data.length; i++) {
                        var arr = [data[cntrow][0], data[cntrow][1], data[cntrow][2], data[cntrow][3], data[cntrow][4], data[cntrow][5], data[cntrow][6], data[cntrow][7], data[cntrow][8], data[cntrow][9]];
                        filterDataPDF.push(arr);
                        cntrow++;
                    }
                    console.log(filterDataPDF);

                    const unit = "pt";
                    const size = "LEGAL";
                    const orientation = "landscape";

                    const doc = new jsPDF(orientation, unit, size);

                    //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
                    var pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

                    //console.log(result); 

                    doc.addImage(result.data.clientLogo, 'PNG', 20, 20, 150, 50);

                    doc.addImage(result.data.traceLogo, 'PNG', pageWidth - 170, 20, 150, 50);

                    //doc.setTextColor(100);

                    doc.setFontSize(24);

                    doc.text(title, pageWidth / 2, 40, { align: 'center' });

                    doc.setFontSize(20);

                    doc.text(titleDate, pageWidth / 2, 65, { align: 'center' });

                    let content = {
                        startY: 80,
                        head: headers,
                        body: filterDataPDF
                    };

                    doc.setFontSize(10);
                    doc.autoTable(content);
                    doc.save("ATMCharges Report.pdf")
                });

            } else {
                alert('No Record Found');
            }
        } else {
            alert('No Record Found');
        }
    };


    // Tooltip
    const renderTooltip = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to pdf
        </Tooltip>
    );

    const renderTooltipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to excel
        </Tooltip>
    );


    const onSubmit = () => {

        setATMChargesReport(null);

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null) {
            alert("Please select Txn Type!");
            return false;
        }
        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            alert("Please select Terminal Value!");
            return false;
        }

        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        let TxnType = '';

        if (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null) {
            TxnType = '';
        }
        else {
            TxnType = selectedTxnTypeValue.label;
        }

        let TerminalValue = 0;

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            TerminalValue = 0;
        }
        else {
            TerminalValue = selectedTerminalValue.label;
        }

        setIsLoading(true);

        MaximusAxios.post('api/AuditReport/GetATMChargesReportDetailsList', {
            TR_POSTDATE: formatDate(startDate),
            TR_ENDDATE: formatDate(endDate),
            ClientID: selectedValue.clientID,
            TxnMode: TxnType
        }, {  mode: 'cors' })
            .then(function (response) {
                setATMChargesReport(response.data);
                setTitleDateValue("Report Date : " + formatDate(startDate) + " To " + formatDate(endDate));
                setIsLoading(false);
                if (response.data === null || response.data.length === 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'No records found' }); }
            })
            .catch(function (error) {
                setTitleDateValue("");
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setIsLoading(false);
            });
    };

   

    $(document).ready(function () {

        if (ATMChargesReport !== null && ATMChargesReport.length > 0) {
            $('#gvATMChargesReportPDF').DataTable();
        }
    });

    const ExportToExcel = async () => {

        const workbook = new ExcelJS.Workbook();

        try {

            setIsLoading(true);

            var data = $("#gvATMChargesReportPDF").dataTable()._('tr', { "filter": "applied" });
            let filterDataExcel = [];
            let cntrow = 0;


            for (let i = 0; i < data.length; i++) {
                var arr = { "Date": data[cntrow][0], "Txn_Type": data[cntrow][1], "No_of_Txn": data[cntrow][2], "Interchange_Non_Fanancial": data[cntrow][3], "Interchange_Fanancial": data[cntrow][4], "NonFanancialGST": data[cntrow][5], "FanancialGST": data[cntrow][6], "Total_Interchange": data[cntrow][7], "Total_GST": data[cntrow][8], "Total_Amount": data[cntrow][9] }
                filterDataExcel.push(arr);
                cntrow++;
            }

            // Create Excel workbook and worksheet           
            const worksheet = workbook.addWorksheet('ATMCharges');

            // Define columns in the worksheet, these columns are identified using a key.

            worksheet.columns = [{ header: 'Date', key: 'Date' }, { header: 'Txn_Type', key: 'Txn_Type' }, { header: 'No_of_Txn', key: 'No_of_Txn' }, { header: 'Interchange_Non_Fanancial', key: 'Interchange_Non_Fanancial' }, { header: 'Interchange_Fanancial', key: 'Interchange_Fanancial' }, { header: 'NonFanancialGST', key: 'NonFanancialGST' }, { header: 'FanancialGST', key: 'FanancialGST' }, { header: 'Total_Interchange', key: 'Total_Interchange' }, { header: 'Total_GST', key: 'Total_GST' }, { header: 'Total_Amount', key: 'Total_Amount' }];

            worksheet.columns = [
                { width: 20 }, { width: 10 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }
            ];

            // loop through all of the columns and set the alignment with width.
            worksheet.columns.forEach(column => {
                column.alignment = { horizontal: 'center' };
            });

            worksheet.columns.forEach(column => {

                if (column._number === 3) {
                    column.alignment = { horizontal: 'right' };
                }

            });


            // updated the font for first row.
            worksheet.getRow(1).font = { bold: true, color: { argb: 'ffffff' } };

            // loop through data and add each one to worksheet
            filterDataExcel.forEach(singleData => {
                worksheet.addRow(singleData);
            });

            // Add auto-filter on each column
            //worksheet.autoFilter = 'A1:D1';

            // Process each row for calculations and beautification 
            worksheet.eachRow((row, rowNumber) => {

                row.eachCell((cell, colNumber) => {
                    if (rowNumber == 1) {
                        // First set the background of header row
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: { argb: 'df5015' }
                        };
                    };
                    // Set border of each cell 
                    cell.border = {
                        top: { style: 'thin' },
                        left: { style: 'thin' },
                        bottom: { style: 'thin' },
                        right: { style: 'thin' }
                    };
                })
                //Commit the changed row to the stream
                row.commit();
            });

            //console.log(filterDataExcel);

            var today = new Date();
            var dateHeading = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear() + ' ' + today.getHours() + '_' + today.getMinutes() + '_' + today.getSeconds();
            // write the content using writeBuffer
            const buf = await workbook.xlsx.writeBuffer();

            // download the processed file
            saveAs(new Blob([buf]), 'ATMCharges Report ' + dateHeading + '.xlsx');

            setIsLoading(false);
        }
        catch (error) {
            console.error('<<<ERRROR>>>', error);
            console.error('Something Went Wrong', error.message);
        } finally {
            // removing worksheet's instance to create new one
            workbook.removeWorksheet('ATMCharges');
        }
    };

    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    ATM Charges Report
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12 colorPrimaryDefault">Audit Reports</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <Link to="/">
                        <p className="fontSize12">ATM Charges Report</p>
                    </Link>
                </div>
            </div>
            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="atmchargesreportFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="atmchargesreportFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>
                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#atmchargesreportFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="atmchargesreportFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="atmchargesreportFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="atmchargesreportFiltersHeading"
                            data-bs-parent="#atmchargesreportFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>


                                    <div className="clientNameSelect col" id="dvTxnType">
                                        <label htmlFor="logType">Txn Mode</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            defaultValue={selectedTxnTypeValue}
                                            options={optionsTxnType}
                                            id="ddlTxnType"
                                            onChange={handleTxnTypeChange}
                                            classNamePrefix="reactSelectBox"
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="logType">Terminal</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlTerminal"
                                            value={selectedTerminalValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTerminalType.map(x => (
                                                {
                                                    value: x.ID,
                                                    label: x.TERMINALID
                                                }
                                            ))}
                                            onChange={handleTerminalChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="StartDate">From Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                            selected={startDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setStartDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ToDate">To Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                            selected={endDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setEndDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                </div>

                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onSubmit}
                                    >
                                        Show
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Bottom Content */}
            <div className="configLeftBottom">
                {(ATMChargesReport === null || ATMChargesReport.length === 0) &&
                    <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div>
                }
                {/* Table */}
                {(ATMChargesReport != null && ATMChargesReport.length > 0) ? (
                    <div>
                        <div className="exportButton">

                            <OverlayTrigger
                                placement="top"
                                delay={{ show: 150, hide: 400 }}
                                overlay={renderTooltipExcel}
                            >
                                <button type="button" className="iconButtonBox" onClick={ExportToExcel}>
                                    <img src={ExcelIcon} alt="Excel" />
                                </button>
                            </OverlayTrigger>

                            <OverlayTrigger
                                placement="top"
                                delay={{ show: 150, hide: 400 }}
                                overlay={renderTooltip}
                            >
                                <button type="button" className="iconButtonBox" onClick={downloadPDF} >
                                    <img src={Pdf} alt="Pdf" />
                                </button>
                            </OverlayTrigger>
                        </div>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvATMChargesReportPDF" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }}>
                                        <thead>
                                            <tr>
                                                <th scope="col">Date</th>
                                                <th scope="col">Txn Type</th>
                                                <th scope="col">No of Txns</th>
                                                <th scope="col">Interchange Non Financial</th>
                                                <th scope="col">Interchange Financial</th>
                                                <th scope="col">GST Non Financial</th>
                                                <th scope="col">GST Financial</th>
                                                <th scope="col">Total Interchange</th>
                                                <th scope="col">Total GST</th>
                                                <th scope="col">Total Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                ATMChargesReport.map((p, i) => {
                                                    return <tr key={i}>
                                                        <td >{p.date}</td>
                                                        <td >{p.txn_Type}</td>
                                                        <td >{p.no_of_Txn}</td>
                                                        <td >{p.interchange_Non_Fanancial}</td>
                                                        <td >{p.interchange_Fanancial}</td>
                                                        <td >{p.nonFanancialGST}</td>
                                                        <td >{p.fanancialGST}</td>
                                                        <td >{p.total_Interchange}</td>
                                                        <td >{p.total_GST}</td>
                                                        <td >{p.total_Amount}</td>
                                                    </tr>
                                                })
                                            }

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
            </div>

            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />

        </div>
    );
};

export default AtmChargesReportMainWindow;
