﻿import React, { useState } from "react";
import AsyncSelect from 'react-select/async';
import { Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL" ;
import * as XLSX from "xlsx";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import authHeader from "../../../pages/login/services/auth-header";
import { useSelector } from "react-redux";
import Select from "react-select";
import ExcelJS from 'exceljs';

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

//import ExcelJS from "exceljs";
//import { saveAs } from 'file-saver';


// Images
import Pdf from "../../../images/common/pdf.svg";
import Excel from "../../../images/common/excel.svg";

import jsPDF from 'jspdf'
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";

import 'jquery/dist/jquery.min.js';

const BankFormatReportMainWindow = () => {
    const currentUser = useSelector((state) => state.authReducer);

    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const [inputValue, setValue] = useState('0');
    const [channelInput, setChannelInput] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);
    const [titleDate, setTitleDateValue] = useState('');


    const [startDate, setStartDate] = useState(new Date());

    const [endDate, setEndDate] = useState(new Date());


    const [BankSettlementReport, setBankSettlementReport] = useState(null);
    const [BankSettlementColumn, setBankSettlementColumn] = useState(null);
    const [BankSettlementFooter, setBankSettlementFooter] = useState(null);

    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const optionsChannelType = [
        { value: "UPI", label: "UPI" },
        { value: "IMPS", label: "IMPS" },
    ];

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];

    const fetchClientData = (inputValue) => {

        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }



    const handleInputChange = value => {
        setValue(value);
 
    };
    const handlechannelChange = value => {
        setChannelInput(value);
    };


    const setStartDateValue = value => {
        setStartDate(value);
        setBankSettlementColumn(null);
        setBankSettlementReport(null);
    }

    const setEndDateValue = value => {

        if (startDate === null) {
            setEndDate(null);
            alert('Please enter From date first');
        }
        else {
            if (startDate > value) {
                alert('To date must be greater than From date ');
                setEndDate(null);
            }
            else {
                setEndDate(value);
            }
        }
        setBankSettlementColumn(null);
        setBankSettlementReport(null);
    }



    const handleClientChange = value => {
        setChannelInput(null);
        setStartDate(null);
        setEndDate(null);
        setSelectedValue(value);
    }


    const handleChannelChange = (value) => {
        setStartDate(null);
        setEndDate(null);
        setSelectedChannelValue(value);


    };

    const downloadExcel = async () => {
        if (!BankSettlementReport || BankSettlementReport.length === 0) {
            alert('No Record Found');
            return;
        }

        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('BankSettlementReport');
        const headers = Object.keys(BankSettlementReport[0]);

        // Define columns dynamically based on headers
        worksheet.columns = headers.map(header => ({
            header,
            key: header,
            width: 20
        }));

        // Add rows to the worksheet
        BankSettlementReport.forEach(record => {
            worksheet.addRow(record);
        });

        // Style the header row
        const headerRow = worksheet.getRow(1);
        headerRow.eachCell(cell => {
            cell.font = { bold: true, size: 14, color: { argb: 'FFFFFFFF' } };
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFDF5015' } };
            cell.alignment = { horizontal: 'center' };
        });
        headerRow.height = 25;

        // Process each row for calculations and beautification 
        worksheet.eachRow((row, rowNumber) => {
            row.eachCell((cell, colNumber) => {
                if (rowNumber > 1) {
                    cell.alignment = { horizontal: 'center' };
                    cell.font = { size: 12 };
                }
                cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
            });
            row.height = 20;
            row.commit();
        });

        // Style the last row
        const lastRow = worksheet.getRow(worksheet.lastRow.number);
        lastRow.eachCell(cell => {
            cell.font = { bold: true, size: 14, color: { argb: 'FFFFFFFF' } };
            cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF5E5F5F' } };
        });

        // Apply color to remaining cells
        worksheet.eachRow((row, rowNumber) => {
            if (rowNumber > 1 && rowNumber < worksheet.lastRow.number) {
                row.eachCell(cell => {
                    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEFF3FB' } };
                });
            }
        });

        // Adjust the range to the data
        const endCol = headers.length;
        const endRow = worksheet.lastRow.number;

        // Hide or remove extra cells by setting the range of the sheet
        worksheet.views = [{ state: 'frozen', ySplit: 1, rightToLeft: false, activeCell: 'A1', showGridLines: false }];

        // Only write the relevant part of the worksheet
        worksheet.autoFilter = `A1:${String.fromCharCode(64 + endCol)}${endRow}`;

        // Generate the Excel file and download it
        const buffer = await workbook.xlsx.writeBuffer();
        const blob = new Blob([buffer], { type: 'application/octet-stream' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'BankSettlementReport.xlsx';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };















    //const downloadExcel = () => {

    //    if (BankSettlementReport !== null) {
    //        if (BankSettlementReport.length > 0) {
    //            var wb = XLSX.utils.book_new();
    //            var ws = XLSX.utils.json_to_sheet(BankSettlementReport);
    //            XLSX.utils.book_append_sheet(wb, ws);
    //            XLSX.writeFile(wb, "BankSettlementReport.xlsx");
    //        } else {
    //            alert('No Record Found');
    //        }
    //    } else {
    //        alert('No Record Found');
    //    }
    //};

    //const downloadExcel = () => {
    //    if (BankSettlementReport !== null) {
    //        if (BankSettlementReport.length > 0) {
    //            var wb = XLSX.utils.book_new();
    //            var ws = XLSX.utils.json_to_sheet(BankSettlementReport);

    //            var columnSettings = BankSettlementReport[0] ?
    //                Object.keys(BankSettlementReport[0]).map(column => ({
    //                    width: 20,
    //                    alignment: { horizontal: 'center' }, // Corrected alignment property
    //                    style: { fill: { type: 'pattern', pattern: 'solid', fgColor: { rgb: 'FF00FF' } } }

    //                })) :
    //                [];
    //            ws['!cols'] = columnSettings;

    //            XLSX.utils.book_append_sheet(wb, ws);

    //            XLSX.writeFile(wb, "BankSettlementReport.xlsx");
    //        } else {
    //            alert('No Record Found');
    //        }
    //    } else {
    //        alert('No Record Found');
    //    }
    //};


    //const downloadExcel = () => {
    //    if (BankSettlementReport !== null) {
    //        if (BankSettlementReport.length > 0) {
    //            var wb = XLSX.utils.book_new();
    //            var ws = XLSX.utils.aoa_to_sheet([Object.keys(BankSettlementReport[0])]); // Create header row

    //            // Add data rows
    //            BankSettlementReport.forEach(obj => {
    //                const values = Object.values(obj);
    //                XLSX.utils.sheet_add_aoa(ws, [values], { origin: -1 });
    //            });

    //            // Define column settings
    //            var columnSettings = [];
    //            for (let i = 0; i < BankSettlementReport[0].length; i++) {
    //                columnSettings.push({ width: 20, alignment: { horizontal: 'center' } });
    //            }

    //            // Set column settings in the worksheet
    //            ws['!cols'] = columnSettings;

    //            // Apply additional styling and alignment
    //            // Example: applying a background color to the header row
    //            const headerCellStyle = { pattern: 'solid', fgColor: { argb: 'df5015' } };
    //            const headerRow = 1; // Assuming header row is the first row
    //            const totalColumns = Object.keys(BankSettlementReport[0]).length;
    //            for (let col = 1; col <= totalColumns; col++) {
    //                const cellAddress = XLSX.utils.encode_cell({ r: headerRow - 1, c: col - 1 });
    //                ws[cellAddress].s = headerCellStyle;
    //            } 

    //            // Save workbook and trigger download
    //            XLSX.utils.book_append_sheet(wb, ws);
    //            XLSX.writeFile(wb, "BankSettlementReport.xlsx");
    //        } else {
    //            alert('No Record Found');
    //        }
    //    } else {
    //        alert('No Record Found');
    //    }
    //};



    //var columnSettings = BankSettlementReport[0] ?
    //    Object.keys(BankSettlementReport[0]).map(column => ({
    //        width: 20,
    //        style: { fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF00FF00' } } }
    //    })) : // Set default width and color for each column
    //    [];

    //// Set the column settings in the worksheet
    //ws['!cols'] = columnSettings;








    // Tooltip
    const renderTooltip = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to pdf
        </Tooltip>
    );

    const renderTooltipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to excel
        </Tooltip>
    );



    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }




    const onSubmit = () => {

        setBankSettlementColumn(null);
        setBankSettlementReport(null);
        //setBankSettlementFooter(null);

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedChannelValue === null || selectedChannelValue.channelInput === 0) {
            alert("Please select client!");
            return false;
        }

        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }
        //alert(startDate + " " + endDate + " " + selectedValue.clientID + " " + selectedChannelValue.value)

        setIsLoading(true);
        //console.log(startDate + " " + endDate + " " + selectedValue.clientID)

      /*  alert("Your choice is IMPS")*/
        MaximusAxios.post('api/AuditReport/GetBankFormatSettlementReports', {
            TR_POSTDATE: formatDate(startDate),
            TR_ENDDATE: formatDate(endDate),
            ReportType: selectedChannelValue.value,
            ClientID: selectedValue.clientID

        }, {  mode: 'cors' })
            .then(function (response) {
                //console.log(response.data);
                if (response.data == null) {
                    setBankSettlementColumn(null);
                    setBankSettlementReport(null);
                    //setBankSettlementFooter(null);
                    setShowMessageBox({ isShow: true, alertVariant: 'Info', alertTitle: 'Info', alertMessage: 'No records found' });
                }
                else if (response.data !== null && JSON.parse(response.data.columns).length == 0) {
                    setBankSettlementColumn(null);
                    setBankSettlementReport(null);
                    //setBankSettlementFooter(null);
                    setShowMessageBox({ isShow: true, alertVariant: 'Info', alertTitle: 'Info', alertMessage: 'No records found' });
                }
                else {
                    setBankSettlementReport(JSON.parse(response.data.jsonData));
                    setBankSettlementColumn(JSON.parse(response.data.columns));
                    //setBankSettlementFooter(JSON.parse(response.data.footer));
                    setTitleDateValue("Report Date : " + formatDate(startDate) + " To " + formatDate(endDate));
                }
                setIsLoading(false);
            })
            .catch(function (error) {
                setTitleDateValue("");
                if (error.response) {
                    console.log(error.response);
                    setBankSettlementColumn(null);
                    setBankSettlementReport(null);
                    //setBankSettlementFooter(null);
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setIsLoading(false);
            });


    };


    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }


    $(document).ready(function () {

        if (BankSettlementReport !== null && BankSettlementReport.length > 0) {
            var noSortColumns = [];
            var thindex = 1;
            
            Object.keys(BankSettlementReport[0]).forEach(key => {
                noSortColumns.push(thindex);
                thindex = thindex + 1;
            }); 

            $('#gvBankSettlementReportPDF').DataTable({
                "bDestroy": true,
                "columnDefs": [{
                    "targets": noSortColumns,
                    "orderable": false
                }]
            });
        }
    });


    return (
    <div className="configLeft reportContainer">
        {/* Breadcrumb Box */}
        <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
            <h5 className="fontWeight-600 fileConfigHead colorBlack">
                Bank Format Settlement Report
            </h5>

            <div className="d-flex align-items-center">
                <Link to="/">
                    <p className="fontSize12 colorPrimaryDefault">Home</p>
                </Link>
                <span>
                    <svg
                        width="8"
                        height="100%"
                        viewBox="0 0 10 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        className="mx-1"
                    >
                        <path
                            d="M3 4L7 8L3 12"
                            stroke="black"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="breadcrumbIcon"
                        />
                    </svg>
                </span>
                <p className="fontSize12 colorPrimaryDefault">Audit Reports</p>
                <span>
                    <svg
                        width="8"
                        height="100%"
                        viewBox="0 0 10 16"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                        className="mx-1"
                    >
                        <path
                            d="M3 4L7 8L3 12"
                            stroke="black"
                            strokeWidth="1.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="breadcrumbIcon"
                        />
                    </svg>
                </span>
                <p className="fontSize12">Bank Format Settlement Report</p>
            </div>
        </div>

        {/* Config Left Top */}
        <div className="configLeftTop">
            <div className="accordion" id="banksettlementreportFilters">
                <div className="accordion-item">
                    <div
                        className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                        id="banksettlementreportFiltersHeading"
                    >
                        <h6 className="fontWeight-600 colorBlack">Filters</h6>
                        <button
                            className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#banksettlementreportFiltersCollapse"
                            aria-expanded="true"
                            aria-controls="banksettlementreportFiltersCollapse"
                        >
                            <span className="icon-Hide"></span>
                            <span className="ms-1 fontSize12-m colorBlack">
                                Show / Hide
                            </span>
                        </button>
                    </div>
                    <div
                        id="banksettlementreportFiltersCollapse"
                        className="accordion-collapse collapse show"
                        aria-labelledby="banksettlementreportFiltersHeading"
                        data-bs-parent="#banksettlementreportFilters"
                    >
                        <div className="accordion-body">
                            <div className="hrGreyLine"></div>
                            <div className="configSelectBoxTop row">
                                <div className="clientNameSelect col">
                                    <label htmlFor="clientName">Client Name</label>
                                    <span className="text-danger font-size13">*</span>
                                    <AsyncSelect
                                        cacheOptions
                                        defaultOptions
                                        value={selectedValue}
                                        getOptionLabel={e => e.clientName}
                                        getOptionValue={e => e.clientID}
                                        loadOptions={fetchClientData}
                                        onInputChange={handleInputChange}
                                        onChange={handleClientChange}
                                        id="ddlClient"
                                    />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="channelName">Channel Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            //defaultValue={channelInput}
                                            value={selectedChannelValue}
                                            options={optionsChannelType}
                                            id="ddlMode"
                                            onChange={handleChannelChange}
                                            
                                            classNamePrefix="reactSelectBox"
                                        />
                                    </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="StartDate">From Date</label>
                                    <span className="text-danger font-size13">*</span>
                                    <DatePicker
                                        renderCustomHeader={({
                                            date,
                                            changeYear,
                                            changeMonth,
                                            decreaseMonth,
                                            increaseMonth,
                                            prevMonthButtonDisabled,
                                            nextMonthButtonDisabled,
                                        }) => (
                                            <div
                                                style={{
                                                    margin: 1,
                                                    display: "flex",
                                                    justifyContent: "center",
                                                }}
                                            >
                                                <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                    <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                </button>
                                                <select
                                                    value={getYear(date)}
                                                    onChange={({ target: { value } }) => changeYear(value)}
                                                >
                                                    {years.map((option) => (
                                                        <option key={option} value={option}>
                                                            {option}
                                                        </option>
                                                    ))}
                                                </select>

                                                <select
                                                    value={months[getMonth(date)]}
                                                    onChange={({ target: { value } }) =>
                                                        changeMonth(months.indexOf(value))
                                                    }
                                                >
                                                    {months.map((option) => (
                                                        <option key={option} value={option}>
                                                            {option}
                                                        </option>
                                                    ))}
                                                </select>

                                                <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                    <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                </button>
                                            </div>
                                        )}
                                        selected={startDate}
                                        dateFormat="dd/MM/yyyy"
                                        onChange={(date) => setStartDateValue(date)}
                                        className="reportDate"
                                        maxDate={new Date()}
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="ToDate">To Date</label>
                                    <span className="text-danger font-size13">*</span>
                                    <DatePicker
                                        renderCustomHeader={({
                                            date,
                                            changeYear,
                                            changeMonth,
                                            decreaseMonth,
                                            increaseMonth,
                                            prevMonthButtonDisabled,
                                            nextMonthButtonDisabled,
                                        }) => (
                                            <div
                                                style={{
                                                    margin: 1,
                                                    display: "flex",
                                                    justifyContent: "center",
                                                }}
                                            >
                                                <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                    <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                </button>
                                                <select
                                                    value={getYear(date)}
                                                    onChange={({ target: { value } }) => changeYear(value)}
                                                >
                                                    {years.map((option) => (
                                                        <option key={option} value={option}>
                                                            {option}
                                                        </option>
                                                    ))}
                                                </select>

                                                <select
                                                    value={months[getMonth(date)]}
                                                    onChange={({ target: { value } }) =>
                                                        changeMonth(months.indexOf(value))
                                                    }
                                                >
                                                    {months.map((option) => (
                                                        <option key={option} value={option}>
                                                            {option}
                                                        </option>
                                                    ))}
                                                </select>

                                                <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                    <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                </button>
                                            </div>
                                        )}
                                        selected={endDate}
                                        dateFormat="dd/MM/yyyy"
                                        onChange={(date) => setEndDateValue(date)}
                                        className="reportDate"
                                        maxDate={new Date()}
                                    />
                                </div>
                            </div>

                            <div className="text-center btnsBtm">
                                <button
                                    type="button"
                                    className="btnPrimaryOutline"
                                    onClick={(e) => onReset(e)}
                                >
                                    Reset
                                </button>
                                <button
                                    type="button"
                                    className="btnPrimary ms-2"
                                    onClick={onSubmit}
                                >
                                    Show
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        {/* Bottom Content */}
        <div className="configLeftBottom">
            {(BankSettlementReport === null || BankSettlementReport.length === 0) &&
                <div className="tableBorderBox pb-3 pt-3">
                    <div className="clientNameSelect configFormatEntities">
                        <p className="text-danger font-size12">No Records</p>
                    </div>
                </div>
            }
            {/* Table */}
            {(BankSettlementReport != null && BankSettlementReport.length > 0) ? (
                    <div>
                        <div className="rightExcelButton">
                            <OverlayTrigger
                                placement="top"
                                delay={{ show: 150, hide: 400 }}
                                overlay={renderTooltipExcel}
                            >
                                <button type="button" className="iconButtonBox" onClick={downloadExcel}>
                                    <img src={Excel} alt="Excel" />
                                </button>
                            </OverlayTrigger>

                        </div>

                    <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive ">
                            {(BankSettlementColumn != null && BankSettlementColumn.length > 0) ? (
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvBankSettlementReportPDF" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                        <thead>
                                            <tr>
                                                {BankSettlementColumn.map((item) => {
                                                    return <th scope="col">{item}</th>
                                                })}
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {(BankSettlementReport !== null && BankSettlementReport.length > 0) ? (
                                                BankSettlementReport.map((p, i) => {
                                                    return <tr key={i}>
                                                        {BankSettlementColumn.map((item) => {
                                                            if (i === BankSettlementReport.length - 1) {
                                                                return <td scope="col"><b>{p[item]}</b></td>
                                                            }
                                                            else {
                                                                return <td scope="col">{p[item]}</td>
                                                            }
                                                        })}
                                                    </tr>
                                                })
                                                ) : null}
                                            </tbody>
                                           
                                    </table>
                                </div>
                            ) : null
                            }
                        </div>

                    </div>
                </div>
            ) : null}
        </div>

        <LoadingSpinner isShow={isShow} />
        <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
    );
};

export default BankFormatReportMainWindow;
