﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import BankSettlementReportMainWindow from "./BankSettlementReportMainWindow";

const BankSettlementReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <BankSettlementReportMainWindow />
        </div>
    );
};

export default BankSettlementReport;
