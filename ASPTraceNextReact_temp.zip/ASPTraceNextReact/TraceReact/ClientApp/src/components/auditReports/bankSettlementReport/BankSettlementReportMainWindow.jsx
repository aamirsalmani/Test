import React, { useState } from "react";
import AsyncSelect from 'react-select/async';
import Select from "react-select";
import { Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link, useLocation } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL";
import * as XLSX from "xlsx";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import authHeader from "../../../pages/login/services/auth-header";
import { useSelector } from "react-redux";
import { saveAs } from "file-saver";

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

//import ExcelJS from "exceljs";
//import { saveAs } from 'file-saver'; 

// Images
import Pdf from "../../../images/common/pdf.svg";
import Excel from "../../../images/common/excel.svg";

import { getYear, getMonth } from "date-fns";


const optionsReportType = [
    { value: "1", label: "ATM Settlement" },
    { value: "2", label: "IMPS Settlement" },
    { value: "3", label: "UPI Settlement" },
    { value: "4", label: "POS Settlement(DSR)" },
    { value: "8", label: "POS Settlement(Presentment)" },
    // { value: "9", label: "POS Refund" },
];

const BankSettlementReportMainWindow = () => {

    const currentUser = useSelector((state) => state.authReducer);

    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);
    const [titleDate, setTitleDateValue] = useState('');


    const [startDate, setStartDate] = useState(new Date());

    const [endDate, setEndDate] = useState(new Date());


    const [BankSettlementReport, setBankSettlementReport] = useState(null);
    const [BankSettlementColumn, setBankSettlementColumn] = useState(null);

    let location = useLocation();
    let capitalizedLocation = location.pathname.replace(/\b\w/g, (char) =>
        char.toUpperCase()
    );

    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];

    const fetchClientData = (inputValue) => {

        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, { mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    const [selectedReportTypeValue, setSelectedReportTypeValue] = useState(null);


    const handleInputChange = value => {
        setValue(value);
    };

    const handleClientChange = value => {
        setBankSettlementColumn(null);
        setBankSettlementReport(null);
        setSelectedReportTypeValue(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedValue(value);

    }

    const setStartDateValue = value => {
        setStartDate(value);
        setEndDate(value);
        setBankSettlementColumn(null);
        setBankSettlementReport(null);
    }

    const handleReportTypeChange = value => {
        setBankSettlementColumn(null);
        setBankSettlementReport(null);
        setSelectedReportTypeValue(value);
    }

    const setEndDateValue = value => {

        if (startDate === null) {
            setEndDate(null);
            alert('Please enter From date first');
        }
        else {
            if (startDate > value) {
                alert('To date must be greater than From date ');
                setEndDate(null);
            }
            else {
                setEndDate(value);
            }
        }
        setBankSettlementColumn(null);
        setBankSettlementReport(null);
    }

    const downloadExcel = () => {

        MaximusAxios.post(
            "api/Logger/InsertUserActivityReport",
            {
                UserId: currentUser.user.username,
                PageName: capitalizedLocation,
                Activity: "Download Excel",
            },
            { headers: authHeader() }
        );
        if (selectedValue === null || selectedValue === undefined) {
            alert("Please select client!");
            return false;
        }

        if (
            startDate === undefined ||
            startDate === null
        ) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        let datePart = formatDate(startDate) === formatDate(endDate) ? formatDate(startDate) : `${formatDate(startDate)}_To_${formatDate(endDate)}`;

        const FileName = `${selectedValue.clientName}_Settlement_${selectedReportTypeValue.label}_${datePart}.xlsx`;

        // let FileName =
        //   "Settlement_" +   selectedReportTypeValue.label +  "_" +  formatDate(startDate) + ".xlsx";
        // setIsLoading(true);
        MaximusAxios.post(
            `api/Excel/SettlementTxnsReport`,
            {
                ClientId: String(selectedValue.clientID),
                ReportType: String(selectedReportTypeValue.value),
                ReportName: String(selectedReportTypeValue.label),
                FromDate: formatDate(startDate),
                ToDate: formatDate(endDate),
                UserID: String(currentUser.user.username),
            },
            { responseType: "blob" }
        )
            .then(function (response) {
                saveAs(response.data, FileName);
                // setIsLoading(false);
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({
                        isShow: true,
                        alertVariant: "danger",
                        alertTitle: "Error",
                        alertMessage: "Error occurred while processing your request",
                    });
                }
                console.log(error.response);
                //setIsLoading(false);
            });
    };

    //const ExportToExcel = async () => {

    //    const workbook = new ExcelJS.Workbook();

    //    try {

    //        setIsLoading(true);

    //        var data = (BankSettlementReport);
    //        let filterDataExcel = [];

    //        filterDataExcel.push(data);

    //        // Create Excel workbook and worksheet           
    //        const worksheet = workbook.addWorksheet('BankSettlement');

    //        // Define columns in the worksheet, these columns are identified using a key.


    //        // loop through all of the columns and set the alignment with width.
    //        worksheet.columns.forEach(column => {
    //            column.alignment = { horizontal: 'center' };
    //        });


    //        // updated the font for first row.
    //        worksheet.getRow(1).font = { bold: true, color: { argb: 'ffffff' } };

    //        // loop through data and add each one to worksheet
    //        filterDataExcel.forEach(singleData => {
    //            worksheet.addRow(singleData);
    //        });

    //        // Add auto-filter on each column
    //        //worksheet.autoFilter = 'A1:D1';

    //        // Process each row for calculations and beautification 
    //        worksheet.eachRow((row, rowNumber) => {

    //            row.eachCell((cell, colNumber) => {
    //                if (rowNumber == 1) {
    //                    // First set the background of header row
    //                    cell.fill = {
    //                        type: 'pattern',
    //                        pattern: 'solid',
    //                        fgColor: { argb: 'df5015' }
    //                    };
    //                };
    //                // Set border of each cell 
    //                cell.border = {
    //                    top: { style: 'thin' },
    //                    left: { style: 'thin' },
    //                    bottom: { style: 'thin' },
    //                    right: { style: 'thin' }
    //                };
    //            })
    //            //Commit the changed row to the stream
    //            row.commit();
    //        });

    //        //console.log(filterDataExcel);

    //        var today = new Date();
    //        var dateHeading = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear() + ' ' + today.getHours() + '_' + today.getMinutes() + '_' + today.getSeconds();
    //        // write the content using writeBuffer
    //        const buf = await workbook.xlsx.writeBuffer();

    //        // download the processed file
    //        saveAs(new Blob([buf]), 'BankSettlement Report ' + dateHeading + '.xlsx');

    //        setIsLoading(false);
    //    }

    //    catch (error) {
    //        console.error('<<<ERRROR>>>', error);
    //        console.error('Something Went Wrong', error.message);
    //    } finally {
    //        // removing worksheet's instance to create new one
    //        workbook.removeWorksheet('BankSettlement');
    //    }
    //};

    const downloadPDF = () => {
        if (BankSettlementReport !== null) {
            if (BankSettlementReport.length > 0) {
                alert('Please download report using excel utility');
            } else {
                alert('No Record Found');
            }
        } else {
            alert('No Record Found');
        }
    };


    // Tooltip
    const renderTooltip = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to pdf
        </Tooltip>
    );

    const renderTooltipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to excel
        </Tooltip>
    );



    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }

    const onSubmit = () => {

        setBankSettlementColumn(null);
        setBankSettlementReport(null);

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedReportTypeValue === undefined || selectedReportTypeValue === null) {
            alert("Please select Report Type!");
            return false;
        }

        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        let ReportTypeX = '';

        if (selectedReportTypeValue === undefined || selectedReportTypeValue === null) {
            ReportTypeX = '';
        }
        else {
            ReportTypeX = selectedReportTypeValue.value;
        }

        setIsLoading(true);

        MaximusAxios.post('api/AuditReport/GetBankSettlementReportDetailsList', {
            TR_POSTDATE: formatDate(startDate),
            TR_ENDDATE: formatDate(endDate),
            ReportType: ReportTypeX,
            ClientID: selectedValue.clientID

        }, { mode: 'cors' })
            .then(function (response) {
                //console.log(response.data);
                if (response.data == null) {
                    setBankSettlementColumn(null);
                    setBankSettlementReport(null);
                    setShowMessageBox({ isShow: true, alertVariant: 'Info', alertTitle: 'Info', alertMessage: 'No records found' });
                }
                else if (response.data !== null && JSON.parse(response.data.columns).length == 0) {
                    setBankSettlementColumn(null);
                    setBankSettlementReport(null);
                    setShowMessageBox({ isShow: true, alertVariant: 'Info', alertTitle: 'Info', alertMessage: 'No records found' });
                }
                else {
                    setBankSettlementReport(JSON.parse(response.data.jsonData));
                    setBankSettlementColumn(JSON.parse(response.data.columns));
                    setTitleDateValue("Report Date : " + formatDate(startDate) + " To " + formatDate(endDate));
                    //console.log(JSON.parse(response.data.jsonData));
                    //console.log(JSON.parse(response.data.columns));
                }
                setIsLoading(false);
            })
            .catch(function (error) {
                setTitleDateValue("");
                if (error.response) {
                    console.log(error.response);
                    setBankSettlementColumn(null);
                    setBankSettlementReport(null);
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setIsLoading(false);
            });
    };


    const onReset = (e) => {
        e.preventDefault();
        // window.location.reload(false);
        setBankSettlementColumn(null);
        setBankSettlementReport(null);

        setSelectedReportTypeValue(null);
        setValue(null);
        setSelectedValue(null);
        setTitleDateValue(null);
        setStartDate(null);
        setEndDate(null);

    }


    $(document).ready(function () {

        if (BankSettlementReport !== null && BankSettlementReport.length > 0) {
            $('#gvBankSettlementReportPDF').DataTable();
        }
    });

    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Settlement Report
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Audit Reports</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Bank Settlement Report</p>
                </div>
            </div>

            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="banksettlementreportFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="banksettlementreportFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>
                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#banksettlementreportFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="banksettlementreportFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="banksettlementreportFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="banksettlementreportFiltersHeading"
                            data-bs-parent="#banksettlementreportFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>
                                    <div className="clientNameSelect col" id="dvReportType">
                                        <label htmlFor="ReportType">Report Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            value={selectedReportTypeValue}
                                            options={optionsReportType}
                                            id="ddlReportType"
                                            onChange={handleReportTypeChange}
                                            classNamePrefix="reactSelectBox"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="StartDate">From Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                <div
                                                    style={{
                                                        margin: 1,
                                                        display: "flex",
                                                        justifyContent: "center",
                                                    }}
                                                >
                                                    <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                    </button>
                                                    <select
                                                        value={getYear(date)}
                                                        onChange={({ target: { value } }) => changeYear(value)}
                                                    >
                                                        {years.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <select
                                                        value={months[getMonth(date)]}
                                                        onChange={({ target: { value } }) =>
                                                            changeMonth(months.indexOf(value))
                                                        }
                                                    >
                                                        {months.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                    </button>
                                                </div>
                                            )}
                                            selected={startDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setStartDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ToDate">To Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                <div
                                                    style={{
                                                        margin: 1,
                                                        display: "flex",
                                                        justifyContent: "center",
                                                    }}
                                                >
                                                    <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                    </button>
                                                    <select
                                                        value={getYear(date)}
                                                        onChange={({ target: { value } }) => changeYear(value)}
                                                    >
                                                        {years.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <select
                                                        value={months[getMonth(date)]}
                                                        onChange={({ target: { value } }) =>
                                                            changeMonth(months.indexOf(value))
                                                        }
                                                    >
                                                        {months.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                    </button>
                                                </div>
                                            )}
                                            selected={endDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setEndDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                </div>

                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onSubmit}
                                    >
                                        Show
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            {/* Bottom Content */}
            <div className="configLeftBottom">
                {(BankSettlementReport === null || BankSettlementReport.length === 0) &&
                    <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div>
                }
                {/* Table */}
                {isShow ? (
                    <div className="spinner-container">
                        <div className="loading-spinner"></div>
                    </div>
                ) : (
                    <>
                        {(BankSettlementReport != null && BankSettlementReport.length > 0) ? (
                            <div>
                                <div className="exportButton">

                                    <OverlayTrigger
                                        placement="top"
                                        delay={{ show: 150, hide: 400 }}
                                        overlay={renderTooltipExcel}
                                    >
                                        <button type="button" className="iconButtonBox" onClick={downloadExcel}>
                                            <img src={Excel} alt="Excel" />
                                        </button>
                                    </OverlayTrigger>

                                    <OverlayTrigger
                                        placement="top"
                                        delay={{ show: 150, hide: 400 }}
                                        overlay={renderTooltip}
                                    >
                                        <button type="button" className="iconButtonBox" onClick={downloadPDF} >
                                            <img src={Pdf} alt="Pdf" />
                                        </button>
                                    </OverlayTrigger>
                                </div>
                                <div className="tableBorderBox pt-3">
                                    <div className="w-100 table-responsive">
                                        {(BankSettlementColumn != null && BankSettlementColumn.length > 0) ? (
                                            <div className="table-responsive tableContentBox" >
                                                <table id="gvBankSettlementReportPDF" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                                    <thead>
                                                        <tr key='-1'>
                                                            {BankSettlementColumn.map((item) => {
                                                                return <th scope="col">{item}</th>
                                                            })}
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {(BankSettlementReport !== null && BankSettlementReport.length > 0) ? (
                                                            BankSettlementReport.map((p, i) => {
                                                                return <tr key={i}>
                                                                    {BankSettlementColumn.map((item) => {
                                                                        return <td scope="col">{p[item]}</td>
                                                                    })}
                                                                </tr>
                                                            })
                                                        ) : null}
                                                    </tbody>
                                                </table>
                                            </div>
                                        ) : null
                                        }
                                    </div>

                                </div>
                            </div>
                        ) : null}
                    </>
                )}
            </div>

            <LoadingSpinner isShow={false} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default BankSettlementReportMainWindow;
