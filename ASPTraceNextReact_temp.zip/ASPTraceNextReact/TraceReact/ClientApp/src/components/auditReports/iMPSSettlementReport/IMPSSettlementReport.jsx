﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import IMPSSettlementReportMainWindow from "./IMPSSettlementReportMainWindow";

const IMPSSettlementReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView d-flex">
            <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
                <IMPSSettlementReportMainWindow />
            </div>
        </div>
    );
};

export default IMPSSettlementReport;
