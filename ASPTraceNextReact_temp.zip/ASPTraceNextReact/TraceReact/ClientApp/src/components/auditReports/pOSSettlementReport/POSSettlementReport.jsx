﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import POSSettlementReportMainWindow from "./POSSettlementReportMainWindow";

const POSSettlementReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView d-flex">
            <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
                <POSSettlementReportMainWindow />
            </div>
        </div>
    );
};

export default POSSettlementReport;
