import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from 'react-select/async';
import { Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker"; 
import MaximusAxios from "../../common/apiURL" ;
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import authHeader from "../../../pages/login/services/auth-header";
import { useSelector } from "react-redux"; 


//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

import ExcelJS from "exceljs";
import { saveAs } from 'file-saver';


// Images
import Pdf from "../../../images/common/pdf.svg";
import ExcelIcon from "../../../images/common/excel.svg";

import jsPDF from 'jspdf'
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";

const optionsSummaryType = [
    { value: "1", label: "DSRSummary" },
    { value: "2", label: "InterchangeSummary" },
    { value: "3", label: "NPCIBillingSummary" },
    { value: "4", label: "NetSettlementSummary" },
    { value: "5", label: "Presentment" },
];

const POSSettlementReportMainWindow = () => {

    const currentUser = useSelector((state) => state.authReducer);

    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const [isShowSummary, setShowSummary] = useState(false);
    const [isShowChannelSummary, setShowChannelSummary] = useState(false);
    const [isShowDRCRSummary, setShowDRCRSummary] = useState(false);
    const [isShowFinalDRCRDSRSummary, setShowFinalDRCRDSRSummary] = useState(false);
    const [isShowFinalDRCRNetSummary, setShowFinalDRCRNetSummary] = useState(false);
    const [isShowNetSummary, setShowNetSummary] = useState(false);
    const [isShowTxnCountSummary, setShowTxnCountSummary] = useState(false);
    const [isShowAmtDRCRSummary, setShowAmtDRCRSummary] = useState(false);
    const [isShowFeeDRCRSummary, setShowFeeDRCRSummary] = useState(false);
    const [isShowFeeAmtSummary, setShowFeeAmtSummary] = useState(false);
    const [isShowCycle, setShowCycle] = useState(false);
    const [isShowPresentmentData, setShowPresentmentData] = useState(false);

    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];

    const fetchClientData = (inputValue) => {

        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }


    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);
    const [titleDate, setTitleDateValue] = useState('');

    const handleInputChange = value => {
        setValue(value);
    };

    const [selectedSummaryTypeValue, setSelectedSummaryTypeValue] = useState(null);



    const handleClientChange = value => {
        setPOSSettlementReport(null);
        setSelectedSummaryTypeValue(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedValue(value);

    }


    const handleSummaryTypeChange = value => {
        setPOSSettlementReport(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedSummaryTypeValue(value);
        
        if (value.value === '1') { setShowSummary(true); } else { setShowSummary(false); }
        if (value.value === '2') { setShowAmtDRCRSummary(true); setShowFeeDRCRSummary(true); } else { setShowAmtDRCRSummary(false); setShowFeeDRCRSummary(false); }
        if (value.value === '1' || value.value === '2') { setShowChannelSummary(true); } else { setShowChannelSummary(false); }
        if (value.value === '1' || value.value === '2' || value.value === '3') { setShowTxnCountSummary(true); } else { setShowTxnCountSummary(false); }
        if (value.value === '3') { setShowFeeAmtSummary(true); } else { setShowFeeAmtSummary(false); }
        if (value.value === '4') { setShowDRCRSummary(true); setShowNetSummary(true); } else { setShowDRCRSummary(false); setShowNetSummary(false); }
        if (value.value === '1' ) { setShowFinalDRCRDSRSummary(true); } else { setShowFinalDRCRDSRSummary(false); }
        if (value.value === '4') { setShowFinalDRCRNetSummary(true); } else { setShowFinalDRCRNetSummary(false); }
        if (value.value === '5') { setShowCycle(false); } else { setShowCycle(true); }
        if (value.value === '5') { setShowPresentmentData(true); } else { setShowPresentmentData(false); }
    }



    //   Date Calendar
    const [startDate, setStartDate] = useState(new Date());
    //   Date Calendar
    const [endDate, setEndDate] = useState(new Date());


    const setStartDateValue = value => {
        setStartDate(value);
        setPOSSettlementReport(null);
    }

    const setEndDateValue = value => {

        if (startDate === null) {
            setEndDate(null);
            alert('Please enter From date first');
        }
        else {
            if (startDate > value) {
                alert('To date must be greater than From date ');
                setEndDate(null);
            }
            else {
                setEndDate(value);
            }
        }
        setPOSSettlementReport(null);
    }


    const [POSSettlementReport, setPOSSettlementReport] = useState(null);


    //const downloadExcel = () => {

    //    if (POSSettlementReport !== null) {
    //        if (POSSettlementReport.length > 0) {
    //            var data = $("#gvPOSSettlementReportPDF").dataTable()._('tr', { "filter": "applied" });
    //            let filterDataExcel = [];
    //            let cntrow = 0;

    //            if (selectedSummaryTypeValue.value === '1') {
    //                for (let i = 0; i < data.length; i++) {

    //                    var arr = { "SettlementDate": data[cntrow][0], "Channel": data[cntrow][1], "TXNCOUNT": data[cntrow][2], "Cycle": data[cntrow][3], "TxnAmtDR": data[cntrow][4], "TxnAmtCR": data[cntrow][5], "SETAMTDR": data[cntrow][6], "SETAMTCR": data[cntrow][7], "IntFeeAmtDR": data[cntrow][8], "IntFeeAmtCR": data[cntrow][9], "MemIncFeeAmtDR": data[cntrow][10], "MemIncFeeAmtCR": data[cntrow][11], "OthFeeAmtDR": data[cntrow][12], "OthFeeAmtCR": data[cntrow][13], "OthFeeGSTDR": data[cntrow][14], "OthFeeGSTCR": data[cntrow][15], "FinalSumCr": data[cntrow][16], "FinalSumDr": data[cntrow][17], "FinalNet": data[cntrow][18], "NPCICount": data[cntrow][19], "NPCIAmount": data[cntrow][20], "GLCount": data[cntrow][21], "GLAmt": data[cntrow][22], "NFSDiff": data[cntrow][23] }
    //                    filterDataExcel.push(arr);
    //                    cntrow++;
    //                }
    //            } else if (selectedSummaryTypeValue.value === '2') {
    //                for (let i = 0; i < data.length; i++) {

    //                    var arr = { "SettlementDate": data[cntrow][0], "Channel": data[cntrow][1], "TXNCOUNT": data[cntrow][2], "AmtCR": data[cntrow][3], "AmtDR": data[cntrow][4], "FeeCR": data[cntrow][5], "Cycle": data[cntrow][6] }
    //                    filterDataExcel.push(arr);
    //                    cntrow++;
    //                }
    //            } else if (selectedSummaryTypeValue.value === '3') {
    //                for (let i = 0; i < data.length; i++) {

    //                    var arr = { "SettlementDate": data[cntrow][0], "TXNCOUNT": data[cntrow][1], "FeeAmt": data[cntrow][2], "FeeAmtGST": data[cntrow][3], "Fee": data[cntrow][4], "Cycle": data[cntrow][5] }
    //                    filterDataExcel.push(arr);
    //                    cntrow++;
    //                }
    //            } else if (selectedSummaryTypeValue.value === '4') {
    //                for (let i = 0; i < data.length; i++) {

    //                    var arr = { "SettlementDate": data[cntrow][0], "DRCR": data[cntrow][1], "FinalSumCr": data[cntrow][2], "FinalSumDr": data[cntrow][3], "Net": data[cntrow][4], "Cycle": data[cntrow][5] }
    //                    filterDataExcel.push(arr);
    //                    cntrow++;
    //                }
    //            } else {
    //                for (let i = 0; i < data.length; i++) {
    //                    var arr = { "SettlementDate": data[cntrow][0], "Channel": data[cntrow][1], "TXNCOUNT": data[cntrow][2], "Cycle": data[cntrow][3], "TxnAmtDR": data[cntrow][4], "TxnAmtCR": data[cntrow][5], "SETAMTDR": data[cntrow][6], "SETAMTCR": data[cntrow][7], "IntFeeAmtDR": data[cntrow][8], "IntFeeAmtCR": data[cntrow][9], "MemIncFeeAmtDR": data[cntrow][10], "MemIncFeeAmtCR": data[cntrow][11], "OthFeeAmtDR": data[cntrow][12], "OthFeeAmtCR": data[cntrow][13], "OthFeeGSTDR": data[cntrow][14], "OthFeeGSTCR": data[cntrow][15], "FinalSumCr": data[cntrow][16], "FinalSumDr": data[cntrow][17], "FinalNet": data[cntrow][18], "NPCICount": data[cntrow][19], "NPCIAmount": data[cntrow][20], "GLCount": data[cntrow][21], "GLAmt": data[cntrow][22], "NFSDiff": data[cntrow][23] }
    //                    filterDataExcel.push(arr);
    //                    cntrow++;
    //                }
    //            }
    //            var wb = XLSX.utils.book_new();
    //            var ws = XLSX.utils.json_to_sheet(filterDataExcel);
    //            XLSX.utils.book_append_sheet(wb, ws);
    //            XLSX.writeFile(wb, "POSSettlement Report.xlsx");
    //        } else {
    //            alert('No Record Found');
    //        }
    //    } else {
    //        alert('No Record Found');
    //    }


    //};


    const downloadPDF = () => {
        if (POSSettlementReport !== null) {
            if (POSSettlementReport.length > 0) {

                MaximusAxios.get('api/Common/GetClientLogoImage?ClientId=' + selectedValue.clientID, {  mode: 'cors' }).then(result => {

                    const title = "POS Settlement Report";
                    const headers = [["RaiseDate", "SettlementDate", "TransactionDate", "RRN", "ProcessingCode", "CurrencyCode", "AmountTransaction", "AmountAdditional", "SettlementTxnAmount", "SettlementAddAmount", "ApprovalCode", "AcquirerID", "IssuerID", "CardType", "CardBrand", "CardAcceptorTerminalID", "Channel", "TXNCOUNT", "Cycle", "TxnAmtDR", "TxnAmtCR", "SETAMTDR", "SETAMTCR", "IntFeeAmtDR", "IntFeeAmtCR", "MemIncFeeAmtDR", "MemIncFeeAmtCR", "OthFeeAmtDR", "OthFeeAmtCR", "OthFeeGSTDR", "OthFeeGSTCR", "FinalSumCr", "FinalSumDr", "FinalNet", "NPCICount", "NPCIAmount", "GLCount", "GLAmt", "NFSDiff"]];
                    const headers1 = [["SettlementDate", "Channel", "TXNCOUNT", "Cycle", "TxnAmtDR", "TxnAmtCR", "SETAMTDR", "SETAMTCR", "IntFeeAmtDR", "IntFeeAmtCR", "MemIncFeeAmtDR", "MemIncFeeAmtCR", "OthFeeAmtDR", "OthFeeAmtCR", "OthFeeGSTDR", "OthFeeGSTCR", "FinalSumCr", "FinalSumDr", "FinalNet", "NPCICount", "NPCIAmount", "GLCount", "GLAmt", "NFSDiff"]];
                    const headers2 = [["SettlementDate", "Channel", "TXNCOUNT", "AmtCR", "AmtDR", "FeeCR", "Cycle"]];
                    const headers3 = [["SettlementDate", "TXNCOUNT", "FeeAmt", "FeeAmtGST", "Fee", "Cycle"]];
                    const headers4 = [["SettlementDate", "DRCR", "FinalSumCr", "FinalSumDr", "Net", "Cycle"]];
                    const headers5 = [["RaiseDate", "SettlementDate", "TransactionDate", "RRN", "ProcessingCode", "CurrencyCode", "AmountTransaction", "AmountAdditional", "SettlementTxnAmount", "SettlementAddAmount", "ApprovalCode", "AcquirerID", "IssuerID", "CardType", "CardBrand", "CardAcceptorTerminalID"]];

                    var data = $("#gvPOSSettlementReportPDF").dataTable()._('tr', { "filter": "applied" });
                    let filterDataPDF = [];
                    let cntrow = 0;
                    //console.log(data);
                    if (selectedSummaryTypeValue.value === '1') {
                        for (let i = 0; i < data.length; i++) {
                            var arr = [data[cntrow][0], data[cntrow][1], data[cntrow][2], data[cntrow][3], data[cntrow][4], data[cntrow][5], data[cntrow][6], data[cntrow][7], data[cntrow][8], data[cntrow][9], data[cntrow][10], data[cntrow][11], data[cntrow][12], data[cntrow][13], data[cntrow][14], data[cntrow][15], data[cntrow][16], data[cntrow][17], data[cntrow][18], data[cntrow][19], data[cntrow][20], data[cntrow][21], data[cntrow][22], data[cntrow][23]];
                            filterDataPDF.push(arr);
                            cntrow++;
                        }
                    } else if (selectedSummaryTypeValue.value === '2') {
                        for (let i = 0; i < data.length; i++) {
                            var arr = [data[cntrow][0], data[cntrow][1], data[cntrow][2], data[cntrow][3], data[cntrow][4], data[cntrow][5], data[cntrow][6]];
                            filterDataPDF.push(arr);
                            cntrow++;
                        }
                    } else if (selectedSummaryTypeValue.value === '3') {
                        for (let i = 0; i < data.length; i++) {
                            var arr = [data[cntrow][0], data[cntrow][1], data[cntrow][2], data[cntrow][3], data[cntrow][4], data[cntrow][5]];
                            filterDataPDF.push(arr);
                            cntrow++;
                        }
                    } else if (selectedSummaryTypeValue.value === '4') {
                        for (let i = 0; i < data.length; i++) {
                            var arr = [data[cntrow][0], data[cntrow][1], data[cntrow][2], data[cntrow][3], data[cntrow][4], data[cntrow][5]];
                            filterDataPDF.push(arr);
                            cntrow++;
                        }
                    } else if (selectedSummaryTypeValue.value === '5')
                    {
                        for (let i = 0; i < data.length; i++) {
                            var arr = [data[cntrow][0], data[cntrow][1], data[cntrow][2], data[cntrow][3], data[cntrow][4], data[cntrow][5], data[cntrow][6], data[cntrow][7], data[cntrow][8], data[cntrow][9], data[cntrow][10], data[cntrow][11], data[cntrow][12], data[cntrow][13], data[cntrow][14], data[cntrow][15]];
                            filterDataPDF.push(arr);
                            cntrow++;
                        }

                    }else {
                        for (let i = 0; i < data.length; i++) {
                            var arr = [data[cntrow][0], data[cntrow][1], data[cntrow][2], data[cntrow][3], data[cntrow][4], data[cntrow][5], data[cntrow][6], data[cntrow][7], data[cntrow][8], data[cntrow][9], data[cntrow][10], data[cntrow][11], data[cntrow][12], data[cntrow][13], data[cntrow][14], data[cntrow][15], data[cntrow][16], data[cntrow][17], data[cntrow][18], data[cntrow][19], data[cntrow][20], data[cntrow][21], data[cntrow][22], data[cntrow][23], data[cntrow][24], data[cntrow][25], data[cntrow][26], data[cntrow][27], data[cntrow][28], data[cntrow][29], data[cntrow][30], data[cntrow][31], data[cntrow][32], data[cntrow][33], data[cntrow][34], data[cntrow][35], data[cntrow][36], data[cntrow][37], data[cntrow][38]];
                            filterDataPDF.push(arr);
                            cntrow++;
                        }
                    }
                    console.log(filterDataPDF);

                    const unit = "pt";
                    const size = "LEGAL";
                    const orientation = "landscape";

                    const doc = new jsPDF(orientation, unit, size);

                    //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
                    var pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

                    //console.log(result); 

                    doc.addImage(result.data.clientLogo, 'PNG', 20, 20, 150, 50);

                    doc.addImage(result.data.traceLogo, 'PNG', pageWidth - 170, 20, 150, 50);

                    //doc.setTextColor(100);

                    doc.setFontSize(24);

                    doc.text(title, pageWidth / 2, 40, { align: 'center' });

                    doc.setFontSize(20);

                    doc.text(titleDate, pageWidth / 2, 65, { align: 'center' });

                    if (selectedSummaryTypeValue.value === '1') {

                        let content = {
                            startY: 80,
                            head: headers1,
                            body: filterDataPDF
                        };

                        doc.autoTable(content);

                    } else if (selectedSummaryTypeValue.value === '2') {

                        let content = {
                            startY: 80,
                            head: headers2,
                            body: filterDataPDF
                        };

                        doc.autoTable(content);
                    } else if (selectedSummaryTypeValue.value === '3') {

                        let content = {
                            startY: 80,
                            head: headers3,
                            body: filterDataPDF
                        };

                        doc.autoTable(content);
                    } else if (selectedSummaryTypeValue.value === '4') {

                        let content = {
                            startY: 80,
                            head: headers4,
                            body: filterDataPDF
                        };

                        doc.autoTable(content);
                    } else if (selectedSummaryTypeValue.value === '5') {

                        let content = {
                            startY: 80,
                            head: headers5,
                            body: filterDataPDF
                        };

                        doc.autoTable(content);

                    } else {

                        let content = {
                            startY: 80,
                            head: headers,
                            body: filterDataPDF
                        };

                        doc.autoTable(content);
                    }
                    doc.setFontSize(10);
                    doc.save("POSSettlement Report.pdf")
                });

            } else {
                alert('No Record Found');
            }
        } else {
            alert('No Record Found');
        }
    };


    // Tooltip
    const renderTooltip = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to pdf
        </Tooltip>
    );

    const renderTooltipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to excel
        </Tooltip>
    );

    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }




    const onSubmit = () => {

        setPOSSettlementReport(null);

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedSummaryTypeValue === null || selectedSummaryTypeValue.value === 0) {
            alert("Please select Summary!");
            return false;
        }

        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        let SummaryType = '';

        if (selectedSummaryTypeValue === undefined || selectedSummaryTypeValue === null) {
            SummaryType = '';
        }
        else {
            SummaryType = selectedSummaryTypeValue.label;
        }

        setIsLoading(true);

        MaximusAxios.post('api/AuditReport/GetPOSSettlementReportDetailsList', {
            ClientID: selectedValue.clientID,
            SettlementType: SummaryType,
            TR_POSTDATE: formatDate(startDate),
            TR_ENDDATE: formatDate(endDate),
        }, {  mode: 'cors' })
            .then(function (response) {
                setPOSSettlementReport(response.data);
                setTitleDateValue("Report Date : " + formatDate(startDate) + " To " + formatDate(endDate));
                setIsLoading(false);
                if (response.data === null || response.data.length === 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'No records found' }); }
            })
            .catch(function (error) {
                setTitleDateValue("");
                if (error.response) {
                    console.log(error.response.data);
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setIsLoading(false);
            });
    };

    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }

    $(document).ready(function () {

        if (POSSettlementReport !== null && POSSettlementReport.length > 0) {
            $('#gvPOSSettlementReportPDF').DataTable();
        }
    });


    const ExportToExcel = async () => {

        const workbook = new ExcelJS.Workbook();

        try {

            setIsLoading(true);

            var data = $("#gvPOSSettlementReportPDF").dataTable()._('tr', { "filter": "applied" });
            let filterDataExcel = [];
            let cntrow = 0;
           
            if (selectedSummaryTypeValue.value === '1') {
                for (let i = 0; i < data.length; i++) {

                    var arr = { "SettlementDate": data[cntrow][0], "Channel": data[cntrow][1], "TXNCOUNT": data[cntrow][2], "Cycle": data[cntrow][3], "TxnAmtDR": data[cntrow][4], "TxnAmtCR": data[cntrow][5], "SETAMTDR": data[cntrow][6], "SETAMTCR": data[cntrow][7], "IntFeeAmtDR": data[cntrow][8], "IntFeeAmtCR": data[cntrow][9], "MemIncFeeAmtDR": data[cntrow][10], "MemIncFeeAmtCR": data[cntrow][11], "OthFeeAmtDR": data[cntrow][12], "OthFeeAmtCR": data[cntrow][13], "OthFeeGSTDR": data[cntrow][14], "OthFeeGSTCR": data[cntrow][15], "FinalSumCr": data[cntrow][16], "FinalSumDr": data[cntrow][17], "FinalNet": data[cntrow][18], "NPCICount": data[cntrow][19], "NPCIAmount": data[cntrow][20], "GLCount": data[cntrow][21], "GLAmt": data[cntrow][22], "NFSDiff": data[cntrow][23] }
                    filterDataExcel.push(arr);
                    cntrow++;
                }
            } else if (selectedSummaryTypeValue.value === '2') {
                for (let i = 0; i < data.length; i++) {

                    var arr = { "SettlementDate": data[cntrow][0], "Channel": data[cntrow][1], "TXNCOUNT": data[cntrow][2], "AmtCR": data[cntrow][3], "AmtDR": data[cntrow][4], "FeeCR": data[cntrow][5], "Cycle": data[cntrow][6] }
                    filterDataExcel.push(arr);
                    cntrow++;
                }
            } else if (selectedSummaryTypeValue.value === '3') {
                for (let i = 0; i < data.length; i++) {

                    var arr = { "SettlementDate": data[cntrow][0], "TXNCOUNT": data[cntrow][1], "FeeAmt": data[cntrow][2], "FeeAmtGST": data[cntrow][3], "Fee": data[cntrow][4], "Cycle": data[cntrow][5] }
                    filterDataExcel.push(arr);
                    cntrow++;
                }
            } else if (selectedSummaryTypeValue.value === '4') {
                for (let i = 0; i < data.length; i++) {

                    var arr = { "SettlementDate": data[cntrow][0], "DRCR": data[cntrow][1], "FinalSumCr": data[cntrow][2], "FinalSumDr": data[cntrow][3], "Net": data[cntrow][4], "Cycle": data[cntrow][5] }
                    filterDataExcel.push(arr);
                    cntrow++;
                }
            } else if (selectedSummaryTypeValue.value === '5') {
                for (let i = 0; i < data.length; i++) {

                    var arr = { "RaiseDate": data[cntrow][0], "SettlementDate": data[cntrow][1], "TransactionDate": data[cntrow][2], "RRN": data[cntrow][3], "ProcessingCode": data[cntrow][4], "CurrencyCode": data[cntrow][5], "AmountTransaction": data[cntrow][6], "AmountAdditional": data[cntrow][7], "SettlementTxnAmount": data[cntrow][8], "SettlementAddAmount": data[cntrow][9], "ApprovalCode": data[cntrow][10], "AcquirerID": data[cntrow][11], "IssuerID": data[cntrow][12], "CardType": data[cntrow][13], "CardBrand": data[cntrow][14], "CardAcceptorTerminalID": data[cntrow][15] }
                    filterDataExcel.push(arr);
                    cntrow++;
                }
            } else {
                for (let i = 0; i < data.length; i++) {
                    var arr = { "RaiseDate": data[cntrow][0], "SettlementDate": data[cntrow][1], "TransactionDate": data[cntrow][2], "RRN": data[cntrow][3], "ProcessingCode": data[cntrow][4], "CurrencyCode": data[cntrow][5], "AmountTransaction": data[cntrow][6], "AmountAdditional": data[cntrow][7], "SettlementTxnAmount": data[cntrow][8], "SettlementAddAmount": data[cntrow][9], "ApprovalCode": data[cntrow][10], "AcquirerID": data[cntrow][11], "IssuerID": data[cntrow][12], "CardType": data[cntrow][13], "CardBrand": data[cntrow][14], "CardAcceptorTerminalID": data[cntrow][15], "Channel": data[cntrow][16], "TXNCOUNT": data[cntrow][17], "Cycle": data[cntrow][18], "TxnAmtDR": data[cntrow][19], "TxnAmtCR": data[cntrow][20], "SETAMTDR": data[cntrow][21], "SETAMTCR": data[cntrow][22], "IntFeeAmtDR": data[cntrow][23], "IntFeeAmtCR": data[cntrow][24], "MemIncFeeAmtDR": data[cntrow][25], "MemIncFeeAmtCR": data[cntrow][26], "OthFeeAmtDR": data[cntrow][27], "OthFeeAmtCR": data[cntrow][28], "OthFeeGSTDR": data[cntrow][29], "OthFeeGSTCR": data[cntrow][30], "FinalSumCr": data[cntrow][31], "FinalSumDr": data[cntrow][32], "FinalNet": data[cntrow][33], "NPCICount": data[cntrow][34], "NPCIAmount": data[cntrow][35], "GLCount": data[cntrow][36], "GLAmt": data[cntrow][37], "NFSDiff": data[cntrow][38] }
                    filterDataExcel.push(arr);
                    cntrow++;
                }
            }

            // Create Excel workbook and worksheet           
            const worksheet = workbook.addWorksheet('POSSettlement');

            // Define columns in the worksheet, these columns are identified using a key.

            if (selectedSummaryTypeValue.value === '1')
            {
                worksheet.columns = [{ header: 'SettlementDate', key: 'SettlementDate' }, { header: 'Channel', key: 'Channel' }, { header: 'TXNCOUNT', key: 'TXNCOUNT' }, { header: 'Cycle', key: 'Cycle' }, { header: 'TxnAmtDR', key: 'TxnAmtDR' }, { header: 'TxnAmtCR', key: 'TxnAmtCR' }, { header: 'SETAMTDR', key: 'SETAMTDR' }, { header: 'SETAMTCR', key: 'SETAMTCR' }, { header: 'IntFeeAmtDR', key: 'IntFeeAmtDR' }, { header: 'IntFeeAmtCR', key: 'IntFeeAmtCR' }, { header: 'MemIncFeeAmtDR', key: 'MemIncFeeAmtDR' }, { header: 'MemIncFeeAmtCR', key: 'MemIncFeeAmtCR' }, { header: 'OthFeeAmtDR', key: 'OthFeeAmtDR' }, { header: 'OthFeeAmtCR', key: 'OthFeeAmtCR' }, { header: 'OthFeeGSTDR', key: 'OthFeeGSTDR' }, { header: 'OthFeeGSTCR', key: 'OthFeeGSTCR' }, { header: 'FinalSumCr', key: 'FinalSumCr' }, { header: 'FinalSumDr', key: 'FinalSumDr' }, { header: 'FinalNet', key: 'FinalNet' }, { header: 'NPCICount', key: 'NPCICount' }, { header: 'NPCIAmount', key: 'NPCIAmount' }, { header: 'GLCount', key: 'GLCount' }, { header: 'GLAmt', key: 'GLAmt' }, { header: 'NFSDiff', key: 'NFSDiff' }];

                worksheet.columns = [
                    { width: 15 }, { width: 10 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }
                ];
            
            } else if (selectedSummaryTypeValue.value === '2')
            {
                worksheet.columns = [{ header: 'SettlementDate', key: 'SettlementDate' }, { header: 'Channel', key: 'Channel' }, { header: 'TXNCOUNT', key: 'TXNCOUNT' }, { header: 'AmtCR', key: 'AmtCR' }, { header: 'AmtDR', key: 'AmtDR' }, { header: 'FeeCR', key: 'FeeCR' }, { header: 'Cycle', key: 'Cycle' }];

                worksheet.columns = [
                    { width: 15 }, { width: 10 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }
                ];
            
            } else if (selectedSummaryTypeValue.value === '3')
            {
                worksheet.columns = [{ header: 'SettlementDate', key: 'SettlementDate' }, { header: 'TXNCOUNT', key: 'TXNCOUNT' }, { header: 'FeeAmt', key: 'FeeAmt' }, { header: 'FeeAmtGST', key: 'FeeAmtGST' }, { header: 'Fee', key: 'Fee' }, { header: 'Cycle', key: 'Cycle' }];

                worksheet.columns = [
                    { width: 15 }, { width: 10 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }
                ];

            } else if (selectedSummaryTypeValue.value === '4')
            {
                worksheet.columns = [{ header: 'SettlementDate', key: 'SettlementDate' }, { header: 'DRCR', key: 'DRCR' }, { header: 'FinalSumCr', key: 'FinalSumCr' }, { header: 'FinalSumDr', key: 'FinalSumDr' }, { header: 'Net', key: 'Net' }, { header: 'Cycle', key: 'Cycle' }];

                worksheet.columns = [
                    { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }
                ];

            } else if (selectedSummaryTypeValue.value === '5')
            {
                worksheet.columns = [{ header: 'RaiseDate', key: 'RaiseDate' }, { header: 'SettlementDate', key: 'SettlementDate' }, { header: 'TransactionDate', key: 'TransactionDate' }, { header: 'RRN', key: 'RRN' }, { header: 'ProcessingCode', key: 'ProcessingCode' }, { header: 'CurrencyCode', key: 'CurrencyCode' }, { header: 'AmountTransaction', key: 'AmountTransaction' }, { header: 'AmountAdditional', key: 'AmountAdditional' }, { header: 'SettlementTxnAmount', key: 'SettlementTxnAmount' }, { header: 'SettlementAddAmount', key: 'SettlementAddAmount' }, { header: 'ApprovalCode', key: 'ApprovalCode' }, { header: 'AcquirerID', key: 'AcquirerID' }, { header: 'IssuerID', key: 'IssuerID' }, { header: 'CardType', key: 'CardType' }, { header: 'CardBrand', key: 'CardBrand' }, { header: 'CardAcceptorTerminalID', key: 'CardAcceptorTerminalID' }];

                worksheet.columns = [
                    { width: 20 }, { width: 20 }, { width: 20 }, { width: 40 }, { width: 15 }, { width: 15 }, { width: 25 }, { width: 25 }, { width: 25 }, { width: 25 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 25 }
                ];

            } else
            {
                worksheet.columns = [{ header: 'RaiseDate', key: 'RaiseDate' }, { header: 'SettlementDate', key: 'SettlementDate' }, { header: 'TransactionDate', key: 'TransactionDate' }, { header: 'RRN', key: 'RRN' }, { header: 'ProcessingCode', key: 'ProcessingCode' }, { header: 'CurrencyCode', key: 'CurrencyCode' }, { header: 'AmountTransaction', key: 'AmountTransaction' }, { header: 'AmountAdditional', key: 'AmountAdditional' }, { header: 'SettlementTxnAmount', key: 'SettlementTxnAmount' }, { header: 'SettlementAddAmount', key: 'SettlementAddAmount' }, { header: 'ApprovalCode', key: 'ApprovalCode' }, { header: 'AcquirerID', key: 'AcquirerID' }, { header: 'IssuerID', key: 'IssuerID' }, { header: 'CardType', key: 'CardType' }, { header: 'CardBrand', key: 'CardBrand' }, { header: 'CardAcceptorTerminalID', key: 'CardAcceptorTerminalID' }, { header: 'SettlementDate', key: 'SettlementDate' }, { header: 'Channel', key: 'Channel' }, { header: 'TXNCOUNT', key: 'TXNCOUNT' }, { header: 'Cycle', key: 'Cycle' }, { header: 'TxnAmtDR', key: 'TxnAmtDR' }, { header: 'TxnAmtCR', key: 'TxnAmtCR' }, { header: 'SETAMTDR', key: 'SETAMTDR' }, { header: 'SETAMTCR', key: 'SETAMTCR' }, { header: 'IntFeeAmtDR', key: 'IntFeeAmtDR' }, { header: 'IntFeeAmtCR', key: 'IntFeeAmtCR' }, { header: 'MemIncFeeAmtDR', key: 'MemIncFeeAmtDR' }, { header: 'MemIncFeeAmtCR', key: 'MemIncFeeAmtCR' }, { header: 'OthFeeAmtDR', key: 'OthFeeAmtDR' }, { header: 'OthFeeAmtCR', key: 'OthFeeAmtCR' }, { header: 'OthFeeGSTDR', key: 'OthFeeGSTDR' }, { header: 'OthFeeGSTCR', key: 'OthFeeGSTCR' }, { header: 'FinalSumCr', key: 'FinalSumCr' }, { header: 'FinalSumDr', key: 'FinalSumDr' }, { header: 'FinalNet', key: 'FinalNet' }, { header: 'NPCICount', key: 'NPCICount' }, { header: 'NPCIAmount', key: 'NPCIAmount' }, { header: 'GLCount', key: 'GLCount' }, { header: 'GLAmt', key: 'GLAmt' }, { header: 'NFSDiff', key: 'NFSDiff' }];

                worksheet.columns = [
                    { width: 20 }, { width: 20 }, { width: 20 }, { width: 30 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }, { width: 15 }
                ];
            }
            
            // loop through all of the columns and set the alignment with width.
            worksheet.columns.forEach(column => {
                column.alignment = { horizontal: 'center' };
            });            

            // updated the font for first row.
            worksheet.getRow(1).font = { bold: true, color: { argb: 'ffffff' } };

            // loop through data and add each one to worksheet
            filterDataExcel.forEach(singleData => {
                worksheet.addRow(singleData);
            });

            // Add auto-filter on each column
            //worksheet.autoFilter = 'A1:D1';

            // Process each row for calculations and beautification 
            worksheet.eachRow((row, rowNumber) => {

                row.eachCell((cell, colNumber) => {
                    if (rowNumber == 1) {
                        // First set the background of header row
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: { argb: 'df5015' }
                        };
                    };
                    // Set border of each cell 
                    cell.border = {
                        top: { style: 'thin' },
                        left: { style: 'thin' },
                        bottom: { style: 'thin' },
                        right: { style: 'thin' }
                    };
                })
                //Commit the changed row to the stream
                row.commit();
            });

            //console.log(filterDataExcel);

            var today = new Date();
            var dateHeading = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear() + ' ' + today.getHours() + '_' + today.getMinutes() + '_' + today.getSeconds();
            // write the content using writeBuffer
            const buf = await workbook.xlsx.writeBuffer();

            // download the processed file
            saveAs(new Blob([buf]), 'POSSettlement Report ' + dateHeading + '.xlsx');

            setIsLoading(false);
        }

        catch (error) {
            console.error('<<<ERRROR>>>', error);
            console.error('Something Went Wrong', error.message);
        } finally {
            // removing worksheet's instance to create new one
            workbook.removeWorksheet('POSSettlement');
        }
    };


    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    POS Settlement Report
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12 colorPrimaryDefault">Audit Reports</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12">POS Settlement Report</p>
                </div>
            </div>

            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="possettlementreportFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="possettlementreportFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>
                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#possettlementreportFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="possettlementreportFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="possettlementreportFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="possettlementreportFiltersHeading"
                            data-bs-parent="#possettlementreportFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>


                                    <div className="clientNameSelect col" id="dvTxnType">
                                        <label htmlFor="logType">Summary Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            defaultValue={selectedSummaryTypeValue}
                                            options={optionsSummaryType}
                                            id="ddlTxnType"
                                            onChange={handleSummaryTypeChange}
                                            classNamePrefix="reactSelectBox"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="StartDate">From Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                            selected={startDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setStartDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ToDate">To Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                            selected={endDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setEndDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                </div>

                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onSubmit}
                                    >
                                        Show
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Bottom Content */}
            <div className="configLeftBottom">
                {(POSSettlementReport === null || POSSettlementReport.length === 0) &&
                    <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div>
                }
                {/* Table */}
                {(POSSettlementReport !== null && POSSettlementReport.length > 0) ? (
                    <div>
                        <div className="exportButton">

                            <OverlayTrigger
                                placement="top"
                                delay={{ show: 150, hide: 400 }}
                                overlay={renderTooltipExcel}
                            >
                                <button type="button" className="iconButtonBox" onClick={ExportToExcel}>
                                    <img src={ExcelIcon} alt="Excel" />
                                </button>
                            </OverlayTrigger>

                            <OverlayTrigger
                                placement="top"
                                delay={{ show: 150, hide: 400 }}
                                overlay={renderTooltip}
                            >
                                <button type="button" className="iconButtonBox" onClick={downloadPDF} >
                                    <img src={Pdf} alt="Pdf" />
                                </button>
                            </OverlayTrigger>
                        </div>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvPOSSettlementReportPDF" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                        <thead>
                                            <tr>
                                                {isShowPresentmentData && (<th scope="col">RaiseDate</th>)}
                                                <th scope="col">SettlementDate</th>
                                                {isShowPresentmentData && (<th scope="col">TransactionDate</th>)}
                                                {isShowPresentmentData && (<th scope="col">RRN</th>)}
                                                {isShowPresentmentData && (<th scope="col">ProcessingCode</th>)}
                                                {isShowPresentmentData && (<th scope="col">CurrencyCode</th>)}
                                                {isShowPresentmentData && (<th scope="col">AmountTransaction</th>)}
                                                {isShowPresentmentData && (<th scope="col">AmountAdditional</th>)}
                                                {isShowPresentmentData && (<th scope="col">SettlementTxnAmount</th>)}
                                                {isShowPresentmentData && (<th scope="col">SettlementAddAmount</th>)}
                                                {isShowPresentmentData && (<th scope="col">ApprovalCode</th>)}
                                                {isShowPresentmentData && (<th scope="col">AcquirerID</th>)}
                                                {isShowPresentmentData && (<th scope="col">IssuerID</th>)}
                                                {isShowPresentmentData && (<th scope="col">CardType</th>)}
                                                {isShowPresentmentData && (<th scope="col">CardBrand</th>)}
                                                {isShowPresentmentData && (<th scope="col">CardAcceptorTerminalID</th>)}
                                                {isShowChannelSummary && (<th scope="col">Channel</th>)}
                                                {isShowTxnCountSummary && (<th scope="col">TXNCOUNT</th>)}
                                                {isShowFeeAmtSummary && (<th scope="col">FeeAmt</th>)}
                                                {isShowFeeAmtSummary && (<th scope="col">FeeAmtGST</th>)}
                                                {isShowFeeAmtSummary && (<th scope="col">Fee</th>)}
                                                {isShowAmtDRCRSummary && (<th scope="col">AmtCR</th>)}
                                                {isShowAmtDRCRSummary && (<th scope="col">AmtDR</th>)}
                                                {isShowFeeDRCRSummary && (<th scope="col">FeeCR</th>)}
                                                {isShowFeeDRCRSummary && (<th scope="col">FeeDR</th>)}
                                                {isShowDRCRSummary && (<th scope="col">DRCR</th>)}
                                                {isShowFinalDRCRNetSummary && (<th scope="col">FinalSumCr</th>)}
                                                {isShowFinalDRCRNetSummary && (<th scope="col">FinalSumDr</th>)}
                                                {isShowNetSummary && (<th scope="col">Net</th>)}
                                                {isShowCycle && (<th scope="col">Cycle</th>)}
                                                {isShowSummary && (<th scope="col">TxnAmtDR</th>      )}
                                                {isShowSummary && (<th scope="col">TxnAmtCR</th>      )}
                                                {isShowSummary && (<th scope="col">SETAMTDR</th>      )}
                                                {isShowSummary && (<th scope="col">SETAMTCR</th>      )}
                                                {isShowSummary && (<th scope="col">IntFeeAmtDR</th>   )}
                                                {isShowSummary && (<th scope="col">IntFeeAmtCR</th>   )}
                                                {isShowSummary && (<th scope="col">MemIncFeeAmtDR</th>)}
                                                {isShowSummary && (<th scope="col">MemIncFeeAmtCR</th>)}
                                                {isShowSummary && (<th scope="col">OthFeeAmtDR</th>   )}
                                                {isShowSummary && (<th scope="col">OthFeeAmtCR</th>   )}
                                                {isShowSummary && (<th scope="col">OthFeeGSTDR</th>   )}
                                                {isShowSummary && (<th scope="col">OthFeeGSTCR</th>   )}
                                                {isShowFinalDRCRDSRSummary && (<th scope="col">FinalSumCr</th>    )}
                                                {isShowFinalDRCRDSRSummary && (<th scope="col">FinalSumDr</th>    )}
                                                {isShowSummary && (<th scope="col">FinalNet</th>      )}
                                                {isShowSummary && (<th scope="col">NPCICount</th>     )}
                                                {isShowSummary && (<th scope="col">NPCIAmount</th>     )}
                                                {isShowSummary && (<th scope="col">GLCount</th>       )}
                                                {isShowSummary && (<th scope="col">GLAmt</th>         )}
                                                {isShowSummary && (<th scope="col">NFSDiff</th>       )}
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                POSSettlementReport.map((p, i) => {
                                                    return <tr key={i}>
                                                        {isShowPresentmentData && (<td >{p.raiseDate}</td>)}
                                                        <td >{p.settlementDate}</td>
                                                        {isShowPresentmentData && (<td >{p.transactionDate}</td>)}
                                                        {isShowPresentmentData && (<td >{p.rrn}</td>)}
                                                        {isShowPresentmentData && (<td >{p.processingCode}</td>)}
                                                        {isShowPresentmentData && (<td >{p.currencyCode}</td>)}
                                                        {isShowPresentmentData && (<td >{p.amountTransaction}</td>)}
                                                        {isShowPresentmentData && (<td >{p.amountAdditional}</td>)}
                                                        {isShowPresentmentData && (<td >{p.settlementTxnAmount}</td>)}
                                                        {isShowPresentmentData && (<td >{p.settlementAddAmount}</td>)}
                                                        {isShowPresentmentData && (<td >{p.approvalCode}</td>)}
                                                        {isShowPresentmentData && (<td >{p.acquirerID}</td>)}
                                                        {isShowPresentmentData && (<td >{p.issuerID}</td>)}
                                                        {isShowPresentmentData && (<td >{p.cardType}</td>)}
                                                        {isShowPresentmentData && (<td >{p.cardBrand}</td>)}
                                                        {isShowPresentmentData && (<td >{p.cardAcceptorTerminalID}</td>)}
                                                        {isShowChannelSummary && (<td >{p.channel}</td>)}
                                                        {isShowTxnCountSummary && (<td >{p.txncount}</td>)}
                                                        {isShowFeeAmtSummary && (<td >{p.feeAmt}</td>)}
                                                        {isShowFeeAmtSummary && (<td >{p.feeAmtGST}</td>)}
                                                        {isShowFeeAmtSummary && (<td >{p.fee}</td>)}
                                                        {isShowAmtDRCRSummary && (<td >{p.amtCR}</td>)}
                                                        {isShowAmtDRCRSummary && (<td >{p.amtDR}</td>)}
                                                        {isShowFeeDRCRSummary && (<td >{p.feeCR}</td>)}
                                                        {isShowFeeDRCRSummary && (<td >{p.feeDR}</td>)}
                                                        {isShowDRCRSummary && (<td >{p.debitCredit}</td>)}
                                                        {isShowFinalDRCRNetSummary && (<td >{p.finalSumCr}</td>)}
                                                        {isShowFinalDRCRNetSummary && (<td >{p.finalSumDr}</td>)}
                                                        {isShowNetSummary && (<td >{p.net}</td>)}
                                                        {isShowCycle && (<td >{p.cycle}</td>)}
                                                        {isShowSummary && (<td >{p.txnAmtDR}</td>)}
                                                        {isShowSummary && (<td >{p.txnAmtCR}</td>)}
                                                        {isShowSummary && (<td >{p.setamtdr}</td>)}
                                                        {isShowSummary && (<td >{p.setamtcr}</td>)}
                                                        {isShowSummary && (<td >{p.intFeeAmtDR}</td>)}
                                                        {isShowSummary && (<td >{p.intFeeAmtCR}</td>)}
                                                        {isShowSummary && (<td >{p.memIncFeeAmtDR}</td>)}
                                                        {isShowSummary && (<td >{p.memIncFeeAmtCR}</td>)}
                                                        {isShowSummary && (<td >{p.othFeeAmtDR}</td>)}
                                                        {isShowSummary && (<td >{p.othFeeAmtCR}</td>)}
                                                        {isShowSummary && (<td >{p.othFeeGSTDR}</td>)}
                                                        {isShowSummary && (<td >{p.othFeeGSTCR}</td>)}
                                                        {isShowFinalDRCRDSRSummary && (<td >{p.finalSumCr}</td>)}
                                                        {isShowFinalDRCRDSRSummary && (<td >{p.finalSumDr}</td>)}
                                                        {isShowSummary && (<td >{p.finalNet}</td>)}
                                                        {isShowSummary && (<td >{p.npciCount}</td>)}
                                                        {isShowSummary && (<td >{p.npciAmt}</td>)}
                                                        {isShowSummary && (<td >{p.glCount}</td>)}
                                                        {isShowSummary && (<td >{p.glAmt}</td>)}
                                                        {isShowSummary && (<td >{p.nfsDiff}</td>)}
                                                    </tr>
                                                })
                                            }

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
            </div>

            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />

        </div>
    );
};

export default POSSettlementReportMainWindow;
