﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
import "../../common/traceReport.css"; 
// Components
import SidebarMain from "../../common/SidebarMain";
import C3RReportMainWindow from "./C3RReportMainWindow";

const C3RReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <C3RReportMainWindow />
        </div>
    );
};

export default C3RReport;
