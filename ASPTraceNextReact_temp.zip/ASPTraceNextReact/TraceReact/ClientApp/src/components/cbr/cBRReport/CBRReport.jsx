﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
import "../../common/traceReport.css"; 
// Components
import SidebarMain from "../../common/SidebarMain";
import CBRReportMainWindow from "./CBRReportMainWindow";

const CBRReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <CBRReportMainWindow />
        </div>
    );
};

export default CBRReport;
