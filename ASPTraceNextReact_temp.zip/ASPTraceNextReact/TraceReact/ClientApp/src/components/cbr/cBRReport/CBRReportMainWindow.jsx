import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from 'react-select/async';
import { Tooltip, OverlayTrigger} from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker"; 
import MaximusAxios from "../../common/apiURL" ;  
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import { useSelector } from "react-redux"; 
import authHeader from "../../../pages/login/services/auth-header";


//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
import { getYear, getMonth } from "date-fns";

import ExcelJS from "exceljs";
import { saveAs } from 'file-saver';

// Images
import Pdf from "../../../images/common/pdf.svg";
import ExcelIcon from "../../../images/common/excel.svg";
import CsvIcon from "../../../images/common/csv.svg";

import jsPDF from 'jspdf'
import "jspdf-autotable";


const CBRReportMainWindow = () => {
    const currentUser = useSelector((state) => state.authReducer); 
    const onReset = (e) => {
        e.preventDefault();
       // window.location.reload(false);
       setSelectedTerminalValue(null);
       setOptionsTerminalValue([]);
       setValue(null);
       setSelectedValue(null);
       setStartDate(null);
       setEndDate(null);

    }

    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const fetchClientData = (inputValue) => {
        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];

    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }


    const chkU = () => {
        return currentUser?.user?.username.includes('Sayali')
    }

    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);

    const [optionsTerminalType, setOptionsTerminalValue] = useState([{ ID: "0", TERMINALID: "All" }]);

    const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

    const [titleDate, setTitleDateValue] = useState(''); 


    const handleInputChange = value => {
        setValue(value);
    };



    const handleClientChange = value => {
        if (currentUser !== null && currentUser.user !== null) {
            setCBRReport(null);
            setSelectedTerminalValue(null);
            //setStartDate(null);
            //setEndDate(null);
            setSelectedValue(value);

            if (value.clientID !== '0') {
                return MaximusAxios.get('api/ExceptionReport/GetAllTerminals?ClientID=' + value.clientID, {  mode: 'cors' }).then(result => {
                    var resData = result.data;
                    var myObj = { "id": "All", "terminalid": "All" };
                    resData.unshift(myObj);
                    //  handleOptionsTerminalType(resData);
                    setOptionsTerminalValue(resData);
                })
                    .catch(error => {
                        console.error('Error fetching terminals:', error);
                    });
            }
        } else {

            alert('Session Timeout');
        }

    }

    const handleTerminalChange = value => {
        setCBRReport(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedTerminalValue(value);
    }

    const [CBRReport, setCBRReport] = useState(null);

    const [startDate, setStartDate] = useState(new Date());

    const [endDate, setEndDate] = useState(new Date());

    const setStartDateValue = value => {
        setStartDate(value);
        setCBRReport(null);
    }

    const setEndDateValue = value => {

        if (startDate === null) {
            setEndDate(null);
            alert('Please enter From date first');
        }
        else {
            if (startDate > value) {
                alert('To date must be greater than From date ');
                setEndDate(null);
            }
            else {
                setEndDate(value);
            }
        }
        setCBRReport(null);
    }

    //const downloadExcel = () => {

    //    if (CBRReport !== null) {
    //        if (CBRReport.length > 0) {
    //            var data = $("#gvCBRReportPDF").dataTable()._('tr', { "filter": "applied" });
    //            let filterDataExcel = [];
    //            let cntrow = 0;
    //            console.log(data);
    //            for (let i = 0; i < data.length; i++) {
    //                var arr = { "TerminalID": data[cntrow][0], "DateTime": data[cntrow][1], "OpeningBalance": data[cntrow][2], "ATMDispense": data[cntrow][3], "AmountDeposit": data[cntrow][4], "PhysicalCashBalance": data[cntrow][5], "AmountReplenished": data[cntrow][6], "AmountReturned": data[cntrow][7], "ClosingBalance": data[cntrow][8], "Overage": data[cntrow][9], "Shortage": data[cntrow][10], "GLBalance": data[cntrow][11], "GLDifference": data[cntrow][12], "OpeningClosingMismatch": data[cntrow][13], "CBRStatus": data[cntrow][14] }
    //                filterDataExcel.push(arr);
    //                cntrow++;
    //            }
    //            console.log(filterDataExcel);
    //            var wb = XLSX.utils.book_new();
    //            var ws = XLSX.utils.json_to_sheet(filterDataExcel);
    //            XLSX.utils.book_append_sheet(wb, ws);
    //            XLSX.writeFile(wb, "CBR Report.xlsx");
    //        } else {
    //            alert('No Record Found');
    //        }
    //    } else {
    //        alert('No Record Found');
    //    }


    //};


    // ----------BY KUNDAN
    const ExportToExcelK = () => {


        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            alert("Please select Terminal Value!");
            return false;
        }


        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        let TerminalValue = '';

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            TerminalValue = '';
        }
        else {
            TerminalValue = selectedTerminalValue.value;
        }
        let FileName = 'CBR Report ' + formatDate(startDate) + '.xlsx'
        setIsLoading(true);

        MaximusAxios.post('api/CBR/ExportExcelReportK', {
            TERMINALID: TerminalValue,
            FROMDATE: formatDate(startDate),
            TODATE: formatDate(endDate),
            Username: currentUser.user.username,
            Clientid: selectedValue.clientID,

        }, {  responseType: 'blob', })
            .then(function (response) {
                saveAs(response.data, FileName);
                setIsLoading(false);
            })
            .catch(function (error) {

                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                console.log(error.response);
                setIsLoading(false);
            });
    }


    const ExportToCsvK = () => {
        

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            alert("Please select Terminal Value!");
            return false;
        }


        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        let TerminalValue = '';

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            TerminalValue = '';
        }
        else {
            TerminalValue = selectedTerminalValue.value;
        }
        let FileName = 'CBR Report ' + formatDate(startDate) + '.csv'
    
        setIsLoading(true);

        MaximusAxios.post('api/CBR/ExportCsvReportK', {
            TERMINALID: TerminalValue,
            FROMDATE: formatDate(startDate),
            TODATE: formatDate(endDate),
            Username: currentUser.user.username,
            Clientid: selectedValue.clientID,

        },{  responseType: 'blob', })
            .then(function (response) {
                saveAs(response.data, FileName);
                setIsLoading(false);
            })
            .catch(function (error) {

                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                console.log(error.response);
                setIsLoading(false);
            });
    }


    // ----------BY KUNDAN


    const downloadPDF = () => {
        if (CBRReport !== null) {
            if (CBRReport.length > 0) {

                MaximusAxios.get('api/Common/GetClientLogoImage?ClientId=' + selectedValue.clientID, {  mode: 'cors' }).then(result => {

                    const title = "CBR Report";  

                    //console.log("CBR Report");

                    const headers = [["Terminal ID", "Date Time", "Opening Balance", "ATM Dispense", "Amount Deposit", "Physical Cash Balance", "Amount Replenished", "Amount Returned", "Closing Balance", "Overage", "Shortage", "GL Balance", "GL Difference", "Opening Closing Mismatch", "CBR Status"]];

                    var data = $("#gvCBRReportPDF").dataTable()._('tr', { "filter": "applied" });
                    let filterDataPDF = [];
                    let cntrow = 0;

                    //console.log(data);

                    for (let i = 0; i < data.length; i++) {
                        var arr = [data[cntrow][0], data[cntrow][1], data[cntrow][2], data[cntrow][3], data[cntrow][4], data[cntrow][5], data[cntrow][6], data[cntrow][7], data[cntrow][8], data[cntrow][9], data[cntrow][10], data[cntrow][11], data[cntrow][12], data[cntrow][13]];
                        filterDataPDF.push(arr);
                        cntrow++;
                    }

                    //console.log(filterDataPDF);

                    const unit = "pt";
                    const size = "LEGAL";
                    const orientation = "landscape";
                      
                    const doc = new jsPDF(orientation, unit, size);

                    //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
                    var pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

                    //console.log(result); 

                    doc.addImage(result.data.clientLogo, 'PNG', 20, 20, 150, 50); 

                    doc.addImage(result.data.traceLogo, 'PNG', pageWidth-170, 20, 150, 50); 

                    //doc.setTextColor(100);

                    doc.setFontSize(24); 

                    doc.text(title, pageWidth / 2, 40, { align: 'center' });

                    doc.setFontSize(20); 

                    doc.text(titleDate, pageWidth / 2, 65, { align: 'center' });

                    let content = {
                        startY: 80,
                        head: headers,
                        body: filterDataPDF
                    }; 

                    doc.setFontSize(10);

                    doc.autoTable(content); 

                    doc.save("CBR Report.pdf");
                });

            } else {
                alert('No Record Found');
            }
        } else {
            alert('No Record Found');
        }
    };


    // Tooltip
    const renderTooltip = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to pdf
        </Tooltip>
    );

    const renderTooltipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to excel
        </Tooltip>
    );

    const renderTooltipCsv = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to  Csv
        </Tooltip>
    );

    const onSubmit = () => {

        setCBRReport(null);

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            alert("Please select Terminal Value!");
            return false;
        }


        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        let TerminalValue = '';

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            TerminalValue = '';
        }
        else {
            TerminalValue = selectedTerminalValue.value;
        }

        setIsLoading(true);

        MaximusAxios.post('api/CBR/GetCBRReportDetailsList', {
            TERMINALID: TerminalValue,
            FROMDATE: formatDate(startDate),
            TODATE: formatDate(endDate),
            Username: currentUser.user.username,
            Clientid: selectedValue.clientID,

        }, {  mode: 'cors' })
            .then(function (response) {
                setCBRReport(response.data);

                console.log(response.data)
                setTitleDateValue("Report Date : " + formatDate(startDate) + " To " + formatDate(endDate));
                setIsLoading(false);
                if (response.data === null || response.data.length == 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'No records found' }); }
            })
            .catch(function (error) {
                setTitleDateValue("");
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setIsLoading(false);
            });
    };


    $(document).ready(function () {

        if (CBRReport !== null && CBRReport.length > 0) {
            $('#gvCBRReportPDF').DataTable();
        }
    });


   //execl 


    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    CBR Report
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12 colorPrimaryDefault">CBR</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12">CBR Report</p>
                </div>
            </div>

            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="cbrreportFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="cbrreportFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>
                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#cbrreportFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="cbrreportFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="cbrreportFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="cbrreportFiltersHeading"
                            data-bs-parent="#cbrreportFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="logType">Terminal</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlTerminal"
                                            value={selectedTerminalValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTerminalType.map(x => (
                                                {
                                                    value: x.terminalid,
                                                    label: x.terminalid
                                                }
                                            ))}
                                            onChange={handleTerminalChange}
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="StartDate">From Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                            selected={startDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setStartDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ToDate">To Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                      {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                            selected={endDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setEndDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>

                                </div>

                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onSubmit}
                                    >
                                        Show
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            {/* Bottom Content */}
            <div className="configLeftBottom">
                {(CBRReport === null || CBRReport.length === 0) &&
                    <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div>
                }
                {/* Table */}
                {isShow ? (
              <div className="spinner-container">
                <div className="loading-spinner"></div>
              </div>
            ) : (
              <>
                {(CBRReport !== null && CBRReport.length > 0) ? (
                    <div>

                        <div className="exportButton">
                            {
                                chkU() &&
                                <OverlayTrigger
                                    placement="top"
                                    delay={{ show: 150, hide: 400 }}
                                    overlay={renderTooltipExcel}
                                >
                                    <button type="button" className="iconButtonBox" onClick={() => ExportToExcelK()}>
                                        <img src={ExcelIcon} alt="Excel" />
                                    </button>
                                </OverlayTrigger>
                            }
                            {
                                chkU() &&
                                <OverlayTrigger
                                    placement="top"
                                    delay={{ show: 150, hide: 400 }}
                                    overlay={renderTooltipCsv}
                                >
                                    <button type="button" className="iconButtonBox" onClick={() => ExportToCsvK()}>
                                        <img src={CsvIcon} alt="Csv" />
                                    </button>
                                </OverlayTrigger>
                            }
                        </div>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvCBRReportPDF" className="table table-striped table-hover table-borderless align-middle">
                                        <thead>
                                            <tr>
                                                <th scope="col">Client ID</th>
                                                <th scope="col">Timestamp</th>
                                                <th scope="col">CIT</th>
                                                <th scope="col">Terminal ID</th>
                                                <th scope="col">Bank</th>
                                                <th scope="col">ATM Location</th>
                                                <th scope="col">Remark</th>
                                                <th scope="col">Deno</th>
                                                <th scope="col">Machine OP Balance</th>
                                                <th scope="col">Machine Dispense</th>
                                                <th scope="col">Machine Remaining</th>
                                                <th scope="col">Machine Loading</th>
                                                <th scope="col">Machine Closing</th>
                                                <th scope="col">Machine Diverted</th>
                                                <th scope="col">Cash Removed</th>
                                                <th scope="col">Physical Cassette</th>
                                                <th scope="col">Physical Remaining</th>
                                                <th scope="col">Physical Loading</th>
                                                <th scope="col">Physical Closing</th>
                                                <th scope="col">Switch OP Balance</th>
                                                <th scope="col">Switch Dispense</th>
                                                <th scope="col">Switch Remaining</th>
                                                <th scope="col">Switch Loading</th>
                                                <th scope="col">Switch Closing</th>
                                                <th scope="col">Switch Increase</th>
                                                <th scope="col">Switch Decrease</th>
                                                <th scope="col">Cash Load Settled Amount</th>
                                                <th scope="col">OVG Settled Amount</th>
                                                <th scope="col">SHTG Settled Amount</th>
                                                <th scope="col">Overage</th>
                                                <th scope="col">Shortage</th>
                                                <th scope="col">Purge Bin</th>
                                                <th scope="col">Cash Dump</th>
                                                <th scope="col">Cash Fill No</th>
                                                <th scope="col">Prev Closing</th> 
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                CBRReport.map((p, rowindex) => (
                                                    <tr key={rowindex}>
                                                        <td>{p.clientID}</td>
                                                        <td>{p.tR_TIMESTAMP}</td>                                                        
                                                        <td>{p.cit}</td>
                                                        <td>{p.terminalID}</td>
                                                        <td>{p.bank}</td>
                                                        <td>{p.atmlocation}</td>
                                                        <td>{p.remark}</td>
                                                        <td>{p.deno}</td>
                                                        <td>{p.machine_OPBALANCE}</td>
                                                        <td>{p.machine_DISPENSE}</td>
                                                        <td>{p.machine_REMANING}</td>
                                                        <td>{p.machine_LOADING}</td>
                                                        <td>{p.machine_CLOSING}</td>
                                                        <td>{p.machine_DIVERTED}</td>
                                                        <td>{p.cash_REMOVED}</td>
                                                        <td>{p.physical_CASSETTE}</td>
                                                        <td>{p.physical_REMANING}</td>
                                                        <td>{p.physical_LOADING}</td>
                                                        <td>{p.physical_CLOSING}</td>
                                                        <td>{p.switch_OPBALANCE}</td>
                                                        <td>{p.switch_DISPENSE}</td>
                                                        <td>{p.switch_REMANING}</td>
                                                        <td>{p.switch_LOADING}</td>
                                                        <td>{p.switch_CLOSING}</td>
                                                        <td>{p.switch_INCREASE}</td>
                                                        <td>{p.switch_DECREASE}</td>
                                                        <td>{p.cashLoadSettledAmount}</td>
                                                        <td>{p.ovgSettledAmount}</td>
                                                        <td>{p.shtgSettledAmount}</td>
                                                        <td>{p.ovg}</td>
                                                        <td>{p.shtg}</td>
                                                        <td>{p.purgE_BIN}</td>
                                                        <td>{p.casH_DUMP}</td>
                                                        <td>{p.cashfillno}</td>
                                                        <td>{p.prev_Closing}</td> 
                                                    </tr>
                                                ))
                                            }
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
                </>)}
            </div>
            <LoadingSpinner isShow={false} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default CBRReportMainWindow;
