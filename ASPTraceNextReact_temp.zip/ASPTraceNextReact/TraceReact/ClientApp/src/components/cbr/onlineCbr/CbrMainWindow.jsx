import React, { useState } from "react";
import AsyncSelect from 'react-select/async';
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import MaximusAxios from "../../common/apiURL";
import $ from 'jquery';

import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";

import { getYear, getMonth } from "date-fns";

import { useSelector } from "react-redux";
import authHeader from "../../../pages/login/services/auth-header";

const CbrMainWindow = () => {

    const currentUser = useSelector((state) => state.authReducer);

    //const Show Loader
    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const fetchATMData = (inputValue) => {
        return MaximusAxios.get('api/CBR/GetTerminalOptionList?UserName=' + currentUser.user.username, { mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.tERMINALID.toLowerCase().includes(inputValue.toLowerCase()));
            }
        });
    }

    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];


    const [startDate, setStartDate] = useState(null);

    const [inputValue, setValue] = useState('0');

    const [selectedATM, setSelectedATM] = useState(null);

    const [TerminalLocation, setTerminalLocation] = useState('');

    const [TerminalType, setTerminalType] = useState('');

    const [AtmTimeValue, setAtmTimeValue] = useState('');

    // handle input change event
    const handleInputChange = value => {
        setValue(value);
    };

    const handleAtmChange = value => {

        clearData();
        setSelectedATM(value);

        if (value !== null && value.terminalid !== '') {
            return MaximusAxios.get('api/CBR/GetTerminalDetails?TerminalId=' + value.terminalid, { mode: 'cors' }).then(result => {
                if (result.data !== undefined) {

                    setTerminalLocation(result.data.terminalLocation);
                    setTerminalType(result.data.terminalType);
                }
            });
        }
    };

    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');

        //console.log('handleAtmChange');
    }


    const handlePaste = event => {
        const clipboardValue = event.clipboardData.getData('text');
        const numberPattern = /^[0-9\b]+$/;
        if (!numberPattern.test(clipboardValue)) {
            event.preventDefault();
        }
    };

    const setStartDateValue = (value, ctlId) => {

        let pattern = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;

        //console.log(value);
        clearDataDeno();
        //console.log('g');
        $('#ATMTxt100').val("");
        $('#ATMTxt200').val("");
        $('#ATMTxt500').val("");
        $('#ATMTxt2000').val("");

        $('#OpTxt100').val("");
        $('#OpTxt200').val("");
        $('#OpTxt500').val("");
        $('#OpTxt2000').val("");

        $('#ATMTxtSum').val('0');

        $('#Totdmpcnt').val('0');
        $('#TxtEjdaispense').val('0');

        let ToDayDate = new Date();

        if (ctlId === "ATM_Date" && value > ToDayDate) {
            setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: "Replenishment date & time cannot be greater than current date" });
            return false;
        }

        if (ctlId === "ATM_Time" && !pattern.test(value)) {
            setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: "Please enter proper ATM Time" });
            return false;
        }

        if (ctlId === "ATM_Time" && (startDate === undefined || startDate === null)) {
            setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: "Please enter ATM date first" });
            return false;
        }

        if (ctlId === "ATM_Time") {
            if (window.confirm("Please confirm if there is NO EOD between Selected CBR Entry Date and Previous EOD date.")) {

                if (window.confirm("Please confirm Current ATM Opening Balance is equal to Previous ATM Closing Balance.")) {
                    setAtmTimeValue(value);
                }
                else {
                    setStartDate(null);
                    setAtmTimeValue('');
                    return false;
                }
            }
            else {
                setStartDate(null);
                setAtmTimeValue('');
                return false;
            }
        }


        let CBRTimeStamp = "";

        if (selectedATM === null || selectedATM.clientID === 0) {
            setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: 'Please select Client. \n' });
            setStartDate(null);
            setAtmTimeValue('');
            return false;
        }
        else {
            if (value !== null) {
                if (ctlId === "ATM_Date") {
                    setStartDate(value);
                    setAtmTimeValue('');
                    CBRTimeStamp = formatDate(value) + " 00:00:00";
                }
                else if (ctlId === "ATM_Time") {
                    setAtmTimeValue(value);
                    CBRTimeStamp = formatDate(startDate) + " " + value + ":00";
                }

                return MaximusAxios.get('api/CBR/GetPreviousClosingDetails?TerminalId=' + selectedATM.terminalid + '&TimeStamp=' + CBRTimeStamp, { mode: 'cors' }).then(result => {
                    if (result.data !== undefined) {

                        var eJDispenseValue = parseInt(result.data.eJDispense);

                        var atmopeningTotalValue = parseInt(result.data.atmopeningTotal);

                        var preBal = parseInt(result.data.previousPHYSICALBALANCE);

                        if (atmopeningTotalValue > eJDispenseValue) {

                            alert('EJ dispense is greater than Opening balance kindly check date and time');
                            setAtmTimeValue('');
                            setStartDate(null);

                            $('#Txtpreviousdate').val('');
                            $('#Txtprevioustome').val('');
                            $('#Txtnextreplishment').val('');
                            $('#Txtnexttime').val('');

                            $('#ATMTxt100').val('');
                            $('#ATMTxt200').val('');
                            $('#ATMTxt500').val('');
                            $('#ATMTxt2000').val('');

                            $('#OpTxt100').val('');
                            $('#OpTxt200').val('');
                            $('#OpTxt500').val('');
                            $('#OpTxt2000').val('');

                            $('#ATMTxtSum').val('');

                            $('#TxtEjdaispense').val('');

                        }
                        else if ((atmopeningTotalValue - preBal) != 0) {

                            alert('CBR Opening / Closing Balance Mismatch');
                            setAtmTimeValue('');
                            setStartDate(null);

                            $('#Txtpreviousdate').val('');
                            $('#Txtprevioustome').val('');
                            $('#Txtnextreplishment').val('');
                            $('#Txtnexttime').val('');

                            $('#ATMTxt100').val('');
                            $('#ATMTxt200').val('');
                            $('#ATMTxt500').val('');
                            $('#ATMTxt2000').val('');

                            $('#OpTxt100').val('');
                            $('#OpTxt200').val('');
                            $('#OpTxt500').val('');
                            $('#OpTxt2000').val('');

                            $('#ATMTxtSum').val('');

                            $('#TxtEjdaispense').val('');
                        }
                        else {
                            $('#Txtpreviousdate').val(result.data.previousdate);
                            $('#Txtprevioustome').val(result.data.previousDateTime);
                            $('#Txtnextreplishment').val(result.data.nextDate);
                            $('#Txtnexttime').val(result.data.nextDateTime);


                            $('#ATMTxt100').val(result.data.atmopening100);
                            $('#ATMTxt200').val(result.data.atmopening50);
                            $('#ATMTxt500').val(result.data.atmopening500);
                            $('#ATMTxt2000').val(result.data.atmopening1000);

                            $('#OpTxt100').val(result.data.atmopening100);
                            $('#OpTxt200').val(result.data.atmopening50);
                            $('#OpTxt500').val(result.data.atmopening500);
                            $('#OpTxt2000').val(result.data.atmopening1000);

                            $('#ATMTxtSum').val(result.data.atmopeningTotal);

                            $('#TxtEjdaispense').val(result.data.eJDispense);

                        }

                    }
                });
            }
        }
    };

    const SyncTextBoxes = (elementId) => {



        var T1 = $.isNumeric($('#ATMTxt200').val()) ? parseInt($('#ATMTxt200').val()) : 0;
        var T2 = $.isNumeric($('#ATMTxt100').val()) ? parseInt($('#ATMTxt100').val()) : 0;
        var T3 = $.isNumeric($('#ATMTxt500').val()) ? parseInt($('#ATMTxt500').val()) : 0;
        var T4 = $.isNumeric($('#ATMTxt2000').val()) ? parseInt($('#ATMTxt2000').val()) : 0;
        var T5 = $('#ATMTxtSum');
        var T6 = $.isNumeric($('#DisTxt200').val()) ? parseInt($('#DisTxt200').val()) : 0;
        var T7 = $.isNumeric($('#DisTxt100').val()) ? parseInt($('#DisTxt100').val()) : 0;
        var T8 = $.isNumeric($('#DisTxt500').val()) ? parseInt($('#DisTxt500').val()) : 0;
        var T9 = $.isNumeric($('#DisTxt2000').val()) ? parseInt($('#DisTxt2000').val()) : 0;
        var T10 = $('#DisTxtSum');
        var T11 = $.isNumeric($('#RMCTxt200').val()) ? parseInt($('#RMCTxt200').val()) : 0;
        var T12 = $.isNumeric($('#RMCTxt100').val()) ? parseInt($('#RMCTxt100').val()) : 0;
        var T13 = $.isNumeric($('#RMCTxt500').val()) ? parseInt($('#RMCTxt500').val()) : 0;
        var T14 = $.isNumeric($('#RMCTxt2000').val()) ? parseInt($('#RMCTxt2000').val()) : 0;
        var T15 = $('#RMCtxtSum');
        var T16 = $.isNumeric($('#Dvt200').val()) ? parseInt($('#Dvt200').val()) : 0;
        var T17 = $.isNumeric($('#Dvt100').val()) ? parseInt($('#Dvt100').val()) : 0;
        var T18 = $.isNumeric($('#Dvt500').val()) ? parseInt($('#Dvt500').val()) : 0;
        var T19 = $.isNumeric($('#Dvt2000').val()) ? parseInt($('#Dvt2000').val()) : 0;
        var T20 = $('#DvtSum');
        var T21 = $('#Totdmpcnt');
        var T22 = $.isNumeric($('#CCTxt200').val()) ? parseInt($('#CCTxt200').val()) : 0;
        var T23 = $.isNumeric($('#CCTxt100').val()) ? parseInt($('#CCTxt100').val()) : 0;
        var T24 = $.isNumeric($('#CCTxt500').val()) ? parseInt($('#CCTxt500').val()) : 0;
        var T25 = $.isNumeric($('#CCTxt2000').val()) ? parseInt($('#CCTxt2000').val()) : 0;
        var T26 = $('#CCTxtTA');
        var T27 = $.isNumeric($('#CPTxt200').val()) ? parseInt($('#CPTxt200').val()) : 0;
        var T28 = $.isNumeric($('#CPTxt100').val()) ? parseInt($('#CPTxt100').val()) : 0;
        var T29 = $.isNumeric($('#CPTxt500').val()) ? parseInt($('#CPTxt500').val()) : 0;
        var T30 = $.isNumeric($('#CPTxt2000').val()) ? parseInt($('#CPTxt2000').val()) : 0;
        var T31 = $('#CPTxtTA');
        var T32 = $.isNumeric($('#TCTxt200').val()) ? parseInt($('#TCTxt200').val()) : 0;
        var T33 = $.isNumeric($('#TCTxt100').val()) ? parseInt($('#TCTxt100').val()) : 0;
        var T34 = $.isNumeric($('#TCTxt500').val()) ? parseInt($('#TCTxt500').val()) : 0;
        var T35 = $.isNumeric($('#TCTxt2000').val()) ? parseInt($('#TCTxt2000').val()) : 0;
        var T36 = $('#TCTxtTA');
        var T37 = $.isNumeric($('#ARxt200').val()) ? parseInt($('#ARxt200').val()) : 0;
        var T38 = $.isNumeric($('#ARxt100').val()) ? parseInt($('#ARxt100').val()) : 0;
        var T39 = $.isNumeric($('#ARxt500').val()) ? parseInt($('#ARxt500').val()) : 0;
        var T40 = $.isNumeric($('#ARxt2000').val()) ? parseInt($('#ARxt2000').val()) : 0;
        var T41 = $('#ARxtAMT');
        var T42 = $.isNumeric($('#AmtReturnedTxt200').val()) ? parseInt($('#AmtReturnedTxt200').val()) : 0;
        var T43 = $.isNumeric($('#AmtReturnedTxt100').val()) ? parseInt($('#AmtReturnedTxt100').val()) : 0;
        var T44 = $.isNumeric($('#AmtReturnedTxt500').val()) ? parseInt($('#AmtReturnedTxt500').val()) : 0;
        var T45 = $.isNumeric($('#AmtReturnedTxt2000').val()) ? parseInt($('#AmtReturnedTxt2000').val()) : 0;
        var T46 = $('#ATRtxtATM');
        var T47 = $.isNumeric($('#NBATMtxt200').val()) ? parseInt($('#NBATMtxt200').val()) : 0;
        var T48 = $.isNumeric($('#NBATMtxt100').val()) ? parseInt($('#NBATMtxt100').val()) : 0;
        var T49 = $.isNumeric($('#NBATMtxt500').val()) ? parseInt($('#NBATMtxt500').val()) : 0;
        var T50 = $.isNumeric($('#NBATMtxt2000').val()) ? parseInt($('#NBATMtxt2000').val()) : 0;
        var T51 = $('#NBtxtATM');
        var T52 = $.isNumeric($('#PCTxt200').val()) ? parseInt($('#PCTxt200').val()) : 0;
        var T53 = $.isNumeric($('#PCTxt100').val()) ? parseInt($('#PCTxt100').val()) : 0;
        var T54 = $.isNumeric($('#PCTxt500').val()) ? parseInt($('#PCTxt500').val()) : 0;
        var T55 = $.isNumeric($('#PCTxt2000').val()) ? parseInt($('#PCTxt2000').val()) : 0;
        var T56 = $('#PCTxtTA');
        var T57 = $('#GlAmt');
        var T58 = $.isNumeric($('#OpTxt200').val()) ? parseInt($('#OpTxt200').val()) : 0;
        var T59 = $.isNumeric($('#OpTxt100').val()) ? parseInt($('#OpTxt100').val()) : 0;
        var T60 = $.isNumeric($('#OpTxt500').val()) ? parseInt($('#OpTxt500').val()) : 0;
        var T61 = $.isNumeric($('#OpTxt2000').val()) ? parseInt($('#OpTxt2000').val()) : 0;
        var T62 = $('#OpTxtTA');
        var T63 = $.isNumeric($('#DiTxt200').val()) ? parseInt($('#DiTxt200').val()) : 0;
        var T64 = $.isNumeric($('#DiTxt100').val()) ? parseInt($('#DiTxt100').val()) : 0;
        var T65 = $.isNumeric($('#DiTxt500').val()) ? parseInt($('#DiTxt500').val()) : 0;
        var T66 = $.isNumeric($('#DiTxt2000').val()) ? parseInt($('#DiTxt2000').val()) : 0;
        var T67 = $('#DiTxtTA');
        var T68 = $.isNumeric($('#ReTxt200').val()) ? parseInt($('#ReTxt200').val()) : 0;
        var T69 = $.isNumeric($('#ReTxt100').val()) ? parseInt($('#ReTxt100').val()) : 0;
        var T70 = $.isNumeric($('#ReTxt500').val()) ? parseInt($('#ReTxt500').val()) : 0;
        var T71 = $.isNumeric($('#ReTxt2000').val()) ? parseInt($('#ReTxt2000').val()) : 0;
        var T72 = $('#ReTxtTA');
        var T73 = $.isNumeric($('#PhcTxt200').val()) ? parseInt($('#PhcTxt200').val()) : 0;
        var T74 = $.isNumeric($('#PhcTxt100').val()) ? parseInt($('#PhcTxt100').val()) : 0;
        var T75 = $.isNumeric($('#PhcTxt500').val()) ? parseInt($('#PhcTxt500').val()) : 0;
        var T76 = $.isNumeric($('#PhcTxt2000').val()) ? parseInt($('#PhcTxt2000').val()) : 0;
        var T77 = $('#PhcTxtTA');
        var T78 = $('#TxtGldiffpc');
        var T79 = $.isNumeric($('#OvTxt200').val()) ? parseInt($('#OvTxt200').val()) : 0;
        var T80 = $.isNumeric($('#OvTxt100').val()) ? parseInt($('#OvTxt100').val()) : 0;
        var T81 = $.isNumeric($('#OvTxt500').val()) ? parseInt($('#OvTxt500').val()) : 0;
        var T82 = $.isNumeric($('#OvTxt2000').val()) ? parseInt($('#OvTxt2000').val()) : 0;
        var T83 = $('#OVTxtTA');
        var T84 = $.isNumeric($('#ShTxt200').val()) ? parseInt($('#ShTxt200').val()) : 0;
        var T85 = $.isNumeric($('#ShTxt100').val()) ? parseInt($('#ShTxt100').val()) : 0;
        var T86 = $.isNumeric($('#ShTxt500').val()) ? parseInt($('#ShTxt500').val()) : 0;
        var T87 = $.isNumeric($('#ShTxt2000').val()) ? parseInt($('#ShTxt2000').val()) : 0;
        var T88 = $('#ShTxtTA');
        var T89 = $('#TxtSat1');
        var T90 = $('#TxtSat2');
        var T91 = $('#TxtSat3');
        var T92 = $('#TxtSat4');

        // added by sachinM
        var T111 = $('#Label1');
        var T112 = $('#Label2');

        var T113 = $('#Label3');
        var T114 = $('#Label4');
        var T115 = $('#Label5');

        var T93 = $.isNumeric($('#DepTxt200').val()) ? parseInt($('#DepTxt200').val()) : 0;
        var T94 = $.isNumeric($('#DepTxt100').val()) ? parseInt($('#DepTxt100').val()) : 0;
        var T95 = $.isNumeric($('#DepTxt500').val()) ? parseInt($('#DepTxt500').val()) : 0;
        var T96 = $.isNumeric($('#DepTxt2000').val()) ? parseInt($('#DepTxt2000').val()) : 0;
        var T97 = $('#DepTxtSum');

        var T98 = $.isNumeric($('#DeTxt200').val()) ? parseInt($('#DeTxt200').val()) : 0;
        var T99 = $.isNumeric($('#DeTxt100').val()) ? parseInt($('#DeTxt100').val()) : 0;
        var T100 = $.isNumeric($('#DeTxt500').val()) ? parseInt($('#DeTxt500').val()) : 0;
        var T101 = $.isNumeric($('#DeTxt2000').val()) ? parseInt($('#DeTxt2000').val()) : 0;
        var T102 = $('#DeTxtTA');


        T5.val((T1 * 200) + (T2 * 100) + (T3 * 500) + (T4 * 2000));

        if (elementId === 'ARxt100' || elementId === 'AmtReturnedTxt100') {
            $('#NBATMtxt100').val(((T38 * 1) + (T12 * 1)) - (T43 * 1));
            T48 = ((T38 * 1) + (T12 * 1)) - (T43 * 1);
        }
        else if (elementId === 'ARxt200' || elementId === 'AmtReturnedTxt200') {
            $('#NBATMtxt200').val(((T37 * 1) + (T11 * 1)) - (T42 * 1));
            T47 = ((T37 * 1) + (T11 * 1)) - (T42 * 1);
        }
        else if (elementId === 'ARxt500' || elementId === 'AmtReturnedTxt500') {
            $('#NBATMtxt500').val(((T39 * 1) + (T13 * 1)) - (T44 * 1));
            T49 = ((T39 * 1) + (T13 * 1)) - (T44 * 1);
        }
        else if (elementId === 'ARxt2000' || elementId === 'AmtReturnedTxt2000') {
            $('#NBATMtxt2000').val(((T40 * 1) + (T14 * 1)) - (T45 * 1));
            T50 = ((T40 * 1) + (T14 * 1)) - (T45 * 1);
        }

        if (TerminalType !== null && TerminalType === "CDM") {

            $('#DisTxt200').val(((T1 * 1) + (T93 * 1)) - (T11 * 1));
            $('#DisTxt100').val(((T2 * 1) + (T94 * 1)) - (T12 * 1));
            $('#DisTxt500').val(((T3 * 1) + (T95 * 1)) - (T13 * 1));
            $('#DisTxt2000').val(((T4 * 1) + (T96 * 1)) - (T14 * 1));

            T6 = ((T1 * 1) + (T93 * 1)) - (T11 * 1);
            T7 = ((T2 * 1) + (T94 * 1)) - (T12 * 1);
            T8 = ((T3 * 1) + (T95 * 1)) - (T13 * 1);
            T9 = ((T4 * 1) + (T96 * 1)) - (T14 * 1);

            $('#DiTxt200').val(((T58 * 1) + (T98 * 1)) - (T68 * 1));
            $('#DiTxt100').val(((T59 * 1) + (T99 * 1)) - (T69 * 1));
            $('#DiTxt500').val(((T60 * 1) + (T100 * 1)) - (T70 * 1));
            $('#DiTxt2000').val(((T61 * 1) + (T101 * 1)) - (T71 * 1));

            T63 = ((T58 * 1) + (T98 * 1)) - (T68 * 1);
            T64 = ((T59 * 1) + (T99 * 1)) - (T69 * 1);
            T65 = ((T60 * 1) + (T100 * 1)) - (T70 * 1);
            T66 = ((T61 * 1) + (T101 * 1)) - (T71 * 1);

            T67.val((T63 * 200) + (T64 * 100) + (T65 * 500) + (T66 * 2000));
            T97.val((T93 * 200) + (T94 * 100) + (T95 * 500) + (T96 * 2000));
            T102.val((T98 * 200) + (T99 * 100) + (T100 * 500) + (T101 * 2000));


            if (((T1 * 1) + (T93 * 1)) < (T11 * 1)) {
                alert("Remaining Count of note 200 cannot be greater than Opening Count or Deposit Count of note 200");
                $('#RMCTxt200').val("0");
                $('#DisTxt200').val("0");
                T11 = 0; T6 = 0;
            }
            else if (T11 !== 0) {
                $('#DisTxt200').val(((T1 * 1) + (T93 * 1)) - (T11 * 1));
                T6 = ((T1 * 1) + (T93 * 1)) - (T11 * 1);
            }
            else {
                $('#DisTxt200').val((T1 * 1) - (T11 * 1));
                T6 = (T1 * 1) - (T11 * 1);
            }

            if (((T2 * 1) + (T94 * 1)) < (T12 * 1)) {
                alert("Remaining Count of note 100 cannot be greater than Opening Count or Deposit Count of note 100");
                $('#RMCTxt100').val("0");
                $('#DisTxt100').val("0");
                T12 = 0; T7 = 0;
            }
            else if (T12 !== 0) {
                $('#DisTxt100').val(((T2 * 1) + (T94 * 1)) - (T12 * 1));
                T7 = ((T2 * 1) + (T94 * 1)) - (T12 * 1);
            }
            else {
                $('#DisTxt100').val((T2 * 1) - (T12 * 1));
                T7 = (T2 * 1) - (T12 * 1);
            }

            if (((T3 * 1) + (T95 * 1)) < (T13 * 1)) {
                alert("Remaining Count of note 500 cannot be greater than Opening Count or Deposit Count of note 500");
                $('#RMCTxt500').val("0");
                $('#DisTxt500').val("0");
                T13 = 0; T8 = 0;
            }
            else if (T13 != 0) {
                $('#DisTxt500').val(((T3 * 1) + (T95 * 1)) - (T13 * 1));
                T8 = ((T3 * 1) + (T95 * 1)) - (T13 * 1);
            }
            else {
                $('#DisTxt500').val((T3 * 1) - (T13 * 1));
                T8 = (T3 * 1) - (T13 * 1);
            }

            if (((T4 * 1) + (T96 * 1)) < (T14 * 1)) {
                alert("Remaining Count of note 2000 cannot be greater than Opening Count or Deposit Count of note 2000");
                $('#RMCTxt2000').val("0");
                $('#DisTxt2000').val("0");
                T14 = 0; T9 = 0;
            }
            else if (T14 != 0) {
                $('#DisTxt2000').val(((T4 * 1) + (T96 * 1)) - (T14 * 1));
                T9 = ((T4 * 1) + (T96 * 1)) - (T14 * 1);
            }
            else {
                $('#DisTxt2000').val((T4 * 1) - (T14 * 1));
                T9 = (T4 * 1) - (T14 * 1);
            }

            if (((T11 * 1)) < (T16 * 1)) {
                alert("Divert Count of note 200 cannot be greater than Opening Count or Remaining Count of note 200");
                $('#Dvt200').val("0");
                T16 = 0;
            }
            if (((T12 * 1)) < (T17 * 1)) {
                alert("Divert Count of note 100 cannot be greater than Opening Count or Remaining Count of note 100");
                $('#Dvt100').val("0");
                T17 = 0;
            }
            if (((T13 * 1)) < (T18 * 1)) {
                alert("Divert Count of note 500 cannot be greater than Opening Count or Remaining Count of note 500");
                $('#Dvt500').val("0");
                T18 = 0;
            }
            if (((T14 * 1)) < (T19 * 1)) {
                alert("Divert Count of note 2000 cannot be greater then Opening Count or Remaining Count of note 2000");
                $('#Dvt2000').val("0");
                T19 = 0;
            }

        }
        else {

            if ((T1 * 1) < (T11 * 1) && (T1 * 1) != 0 && (T11 * 1) !== 0) {
                alert("Remaining Count of note 200 cannot be greater than Opening Count of note 200");
                $('#RMCTxt200').val("0");
                T11 = 0;
            } else if ((T1 * 1) === 0 && (T11 * 1) !== 0) {
                alert("Remaining Count of note 200 cannot be greater than Opening Count of note 200");
                $('#RMCTxt200').val("0");
                T11 = 0;
            } else {
                $('#DisTxt200').val((T1 * 1) - (T11 * 1));
                T6 = (T1 * 1) - (T11 * 1);
            }

            if ((T2 * 1) < (T12 * 1)) {
                alert("Remaining Count of note 100 cannot be greater than Opening Count of note 100");
                $('#RMCTxt100').val("0");
                T12 = 0;
            } else if ((T2 * 1) == 0 && (T12 * 1) !== 0) {
                alert("Remaining Count of note 100 cannot be greater than Opening Count of note 100");
                $('#RMCTxt100').val("0");
                T12 = 0;
            } else {
                $('#DisTxt100').val((T2 * 1) - (T12 * 1));
                T7 = (T2 * 1) - (T12 * 1);
            }

            if ((T3 * 1) < (T13 * 1) && (T13 * 1) !== 0 && (T3 * 1) !== 0) {
                alert("Remaining Count of note 500 cannot be greater than Opening Count of note 500");
                $('#RMCTxt500').val("0");
                T13 = 0;
            } else if ((T3 * 1) === 0 && (T13 * 1) !== 0) {
                alert("Remaining Count of note 500 cannot be greater than Opening Count of note 500");
                $('#RMCTxt500').val("0");
                T13 = 0;
            } else {
                $('#DisTxt500').val((T3 * 1) - (T13 * 1));
                T8 = (T3 * 1) - (T13 * 1);
            }

            if ((T4 * 1) < (T14 * 1) && (T14 * 1) != 0 && (T4 * 1) !== 0) {
                alert("Remaining Count of note 2000 cannot be greater than Opening Count of note 2000");
                $('#RMCTxt2000').val("0");
                T14 = 0;
            } else if ((T4 * 1) === 0 && (T14 * 1) !== 0) {
                alert("Remaining Count of note 2000 cannot be greater than Opening Count of note 2000");
                $('#RMCTxt2000').val("0");
                T14 = 0;
            } else {
                $('#DisTxt2000').val((T4 * 1) - (T14 * 1));
                T9 = (T4 * 1) - (T14 * 1);
            }

            if ((T1 * 1) < (T16 * 1)) {
                alert("Divert Count of note 200 cannot be greater than Opening Count of note 200");
                $('#Dvt200').val("0");
                T16 = 0;
            } else if ((T1 * 1) === 0 && (T16 * 1) !== 0) {
                alert("Divert Count of note 200 cannot be greater than Opening Count of note 200");
                $('#Dvt200').val("0");
                T16 = 0;
            }
            if ((T2 * 1) < (T17 * 1)) {
                alert("Divert Count of note 100 cannot be greater than Opening Count of note 100");
                $('#Dvt100').val("0");
                T17 = 0;
            } else if ((T2 * 1) === 0 && (T17 * 1) !== 0) {
                alert("Divert Count of note 100 cannot be greater than Opening Count of note 100");
                $('#Dvt100').val("0");
                T17 = 0;
            }
            if ((T3 * 1) < (T18 * 1)) {
                alert("Divert Count of note 500 cannot be greater than Opening Count of note 500");
                $('#Dvt500').val("0");
                T18 = 0;
            } else if ((T3 * 1) === 0 && (T18 * 1) !== 0) {
                alert("Divert Count of note 500 cannot be greater than Opening Count of note 500");
                $('#Dvt500').val("0");
                T18 = 0;
            }
            if ((T4 * 1) < (T19 * 1)) {
                alert("Divert Count of note 2000 cannot be greater then Opening Count of note 2000");
                $('#Dvt2000').val("0");
                T19 = 0;
            } else if ((T4 * 1) === 0 && (T19 * 1) !== 0) {
                alert("Divert Count of note 2000 cannot be greater then Opening Count of note 2000");
                $('#Dvt2000').val("0");
                T19 = 0;
            }

        }


        T15.val((T11 * 200) + (T12 * 100) + (T13 * 500) + (T14 * 2000));
        T20.val((T16 * 200) + (T17 * 100) + (T18 * 500) + (T19 * 2000));
        T21.val((T16 * 1) + (T17 * 1) + (T18 * 1) + (T19 * 1));
        T26.val((T22 * 200) + (T23 * 100) + (T24 * 500) + (T25 * 2000));
        T31.val((T27 * 200) + (T28 * 100) + (T29 * 500) + (T30 * 2000));

        $('#TCTxt200').val((T22 * 1) + (T27 * 1));
        $('#TCTxt100').val((T23 * 1) + (T28 * 1));
        $('#TCTxt500').val((T24 * 1) + (T29 * 1));
        $('#TCTxt2000').val((T25 * 1) + (T30 * 1));

        T32 = (T22 * 1) + (T27 * 1);
        T33 = (T23 * 1) + (T28 * 1);
        T34 = (T24 * 1) + (T29 * 1);
        T35 = (T25 * 1) + (T30 * 1);

        T36.val((T32 * 200) + (T33 * 100) + (T34 * 500) + (T35 * 2000));
        T41.val((T37 * 200) + (T38 * 100) + (T39 * 500) + (T40 * 2000));
        T46.val((T42 * 200) + (T43 * 100) + (T44 * 500) + (T45 * 2000));
        T51.val((T47 * 200) + (T48 * 100) + (T49 * 500) + (T50 * 2000));

        $('#PCTxt200').val((T37 * 1) - (T42 * 1) + (T32 * 1));
        $('#PCTxt100').val((T38 * 1) - (T43 * 1) + (T33 * 1));
        $('#PCTxt500').val((T39 * 1) - (T44 * 1) + (T34 * 1));
        $('#PCTxt2000').val((T40 * 1) - (T45 * 1) + (T35 * 1));

        T52 = (T37 * 1) - (T42 * 1) + (T32 * 1);
        T53 = (T38 * 1) - (T43 * 1) + (T33 * 1);
        T54 = (T39 * 1) - (T44 * 1) + (T34 * 1);
        T55 = (T40 * 1) - (T45 * 1) + (T35 * 1);

        T56.val((T52 * 200) + (T53 * 100) + (T54 * 500) + (T55 * 2000));
        T62.val((T58 * 200) + (T59 * 100) + (T60 * 500) + (T61 * 2000));
        T67.val((T63 * 200) + (T64 * 100) + (T65 * 500) + (T66 * 2000));
        T72.val((T68 * 200) + (T69 * 100) + (T70 * 500) + (T71 * 2000));

        $('#PhcTxt200').val(T52);
        $('#PhcTxt100').val(T53);
        $('#PhcTxt500').val(T54);
        $('#PhcTxt2000').val(T55);

        T73 = T52;
        T74 = T53;
        T75 = T54;
        T76 = T55;

        T77.val((T73 * 200) + (T74 * 100) + (T75 * 500) + (T76 * 2000));

        var T26Value = $.isNumeric($('#CCTxtTA').val()) ? parseInt($('#CCTxtTA').val()) : 0;
        var T31Value = $.isNumeric($('#CPTxtTA').val()) ? parseInt($('#CPTxtTA').val()) : 0;
        var T57Value = $.isNumeric($('#GlAmt').val()) ? parseInt($('#GlAmt').val()) : 0;

        if (TerminalType !== null && TerminalType === "CDM") {
            T78.val((T26Value * 1) + (T31Value * 1) - (T57Value * 1));
            //console.log(T26Value);
            //console.log(T31Value);
            //console.log(T57Value);
        }
        else {
            T78.val((T26Value * 1) + (T31Value * 1) - (T57Value * 1));
            //console.log(T26Value);
            //console.log(T31Value);
            //console.log(T57Value);
        }

        if ((T11 * 1) < (T32 * 1)) {
            $('#OvTxt200').val((T32 * 1) - (T11 * 1));
            $('#ShTxt200').val(0);
            T79 = (T32 * 1) - (T11 * 1);
            T84 = 0;
        } else {
            $('#OvTxt200').val(0);
            $('#ShTxt200').val((T11 * 1) - (T32 * 1));
            T79 = 0;
            T84 = (T11 * 1) - (T32 * 1);
        }
        if ((T12 * 1) < (T33 * 1)) {
            $('#OvTxt100').val((T33 * 1) - (T12 * 1));
            $('#ShTxt100').val(0);
            T80 = (T33 * 1) - (T12 * 1);
            T85 = 0;
        } else {
            $('#OvTxt100').val(0);
            $('#ShTxt100').val((T12 * 1) - (T33 * 1));
            T80 = 0;
            T85 = (T12 * 1) - (T33 * 1);
        }

        if ((T13 * 1) < (T34 * 1)) {
            $('#OvTxt500').val((T34 * 1) - (T13 * 1));
            $('#ShTxt500').val(0);
            T81 = (T34 * 1) - (T13 * 1);
            T86 = 0;
        } else {
            $('#OvTxt500').val(0);
            $('#ShTxt500').val((T13 * 1) - (T34 * 1));
            T81 = 0;
            T86 = (T13 * 1) - (T34 * 1);
        }

        if ((T14 * 1) < (T35 * 1)) {
            $('#OvTxt2000').val((T35 * 1) - (T14 * 1));
            $('#ShTxt2000').val(0);
            T82 = (T35 * 1) - (T14 * 1);
            T87 = 0;
        } else {
            $('#OvTxt2000').val(0);
            $('#ShTxt2000').val((T14 * 1) - (T35 * 1));
            T82 = 0;
            T87 = (T14 * 1) - (T35 * 1);
        }

        var T51Value = $.isNumeric($('#NBtxtATM').val()) ? parseInt($('#NBtxtATM').val()) : 0;
        var T56Value = $.isNumeric($('#PCTxtTA').val()) ? parseInt($('#PCTxtTA').val()) : 0;

        if ((T51Value * 1) === (T56Value * 1)) {
            T89.val("OK");
            T111.show();
            T112.hide();
        }
        else {
            T89.val("New Counter Mismatch");
            T111.hide();
            T112.show();
        }

        if (((T22 * 1) + (T23 * 1) + (T24 * 1) + (T25 * 1)) === ((T68 * 1) + (T69 * 1) + (T70 * 1) + (T71 * 1))) {

            T90.val("");
            T113.hide();
        }
        else {
            T90.val("Switch Counters Mismatch");
            T113.show();
        }

        if (((T16 * 1) + (T17 * 1) + (T18 * 1) + (T19 * 1)) === ((T27 * 1) + (T28 * 1) + (T29 * 1) + (T30 * 1))) {
            T91.val("");
            T114.hide();
        } else {
            T91.val("ATM Counters Mismatch");
            T114.show();
        }

        var T15Value = $.isNumeric($('#RMCtxtSum').val()) ? parseInt($('#RMCtxtSum').val()) : 0;
        var T72Value = $.isNumeric($('#ReTxtTA').val()) ? parseInt($('#ReTxtTA').val()) : 0;

        if (T15Value === T72Value) {
            T92.val("");
            T115.hide();
        }
        else {
            T92.val("S Diff");
            T115.show();
        }

        T10.val((T6 * 200) + (T7 * 100) + (T8 * 500) + (T9 * 2000));
        T67.val((T63 * 200) + (T64 * 100) + (T65 * 500) + (T66 * 2000));
        T97.val((T93 * 200) + (T94 * 100) + (T95 * 500) + (T96 * 2000));
        T102.val((T98 * 200) + (T99 * 100) + (T100 * 500) + (T101 * 2000));

        T83.val((T79 * 200) + (T80 * 100) + (T81 * 500) + (T82 * 2000));
        T88.val((T84 * 200) + (T85 * 100) + (T86 * 500) + (T87 * 2000));


    }

    const clearData = () => {

        setTerminalLocation('');
        setTerminalType('');
        setStartDate(null);
        setAtmTimeValue('');
        clearDataDeno();
    }

    const clearDataDeno = () => {
        $('#ATMTxt100').val("0");
        $('#ATMTxt200').val("0");
        $('#ATMTxt500').val("0");
        $('#ATMTxt2000').val("0");
        $('#DisTxt200').val("0");
        $('#DisTxt100').val("0");
        $('#DisTxt500').val("0");
        $('#DisTxt2000').val("0");
        $('#RMCTxt200').val("0");
        $('#RMCTxt100').val("0");
        $('#RMCTxt500').val("0");
        $('#RMCTxt2000').val("0");
        $('#Dvt200').val("0");
        $('#Dvt100').val("0");
        $('#Dvt500').val("0");
        $('#Dvt2000').val("0");
        $('#Totdmpcnt').val("0");
        $('#ATMTxtSum').val("0");
        $('#DisTxtSum').val("0");
        $('#RMCtxtSum').val("0");
        $('#DvtSum').val("0");
        $('#ARxt200').val("0");
        $('#ARxt100').val("0");
        $('#ARxt500').val("0");
        $('#ARxt2000').val("0");
        $('#AmtReturnedTxt200').val("0");
        $('#AmtReturnedTxt100').val("0");
        $('#AmtReturnedTxt500').val("0");
        $('#AmtReturnedTxt2000').val("0");
        $('#NBATMtxt200').val("0");
        $('#NBATMtxt100').val("0");
        $('#NBATMtxt500').val("0");
        $('#NBATMtxt2000').val("0");
        $('#ARxtAMT').val("0");
        $('#ATRtxtATM').val("0");
        $('#NBtxtATM').val("0");
        $('#CCTxt200').val("0");
        $('#CCTxt100').val("0");
        $('#CCTxt500').val("0");
        $('#CCTxt2000').val("0");
        $('#CPTxt200').val("0");
        $('#CPTxt100').val("0");
        $('#CPTxt500').val("0");
        $('#CPTxt2000').val("0");
        $('#TCTxt200').val("0");
        $('#TCTxt100').val("0");
        $('#TCTxt500').val("0");
        $('#TCTxt2000').val("0");
        $('#PCTxt200').val("0");
        $('#PCTxt100').val("0");
        $('#PCTxt500').val("0");
        $('#PCTxt2000').val("0");
        $('#GlAmt').val("0");
        $('#CCTxtTA').val("0");
        $('#CPTxtTA').val("0");
        $('#TCTxtTA').val("0");
        $('#PCTxtTA').val("0");
        $('#OpTxt100').val("");
        $('#OpTxt200').val("");
        $('#OpTxt500').val("");
        $('#OpTxt2000').val("");
        $('#DiTxt200').val("0");
        $('#DiTxt100').val("0");
        $('#DiTxt500').val("0");
        $('#DiTxt2000').val("0");
        $('#ReTxt200').val("0");
        $('#ReTxt100').val("0");
        $('#ReTxt500').val("0");
        $('#ReTxt2000').val("0");
        $('#PhcTxt200').val("0");
        $('#PhcTxt100').val("0");
        $('#PhcTxt500').val("0");
        $('#PhcTxt2000').val("0");
        $('#OpTxtTA').val("0");
        $('#DiTxtTA').val("0");
        $('#ReTxtTA').val("0");
        $('#PhcTxtTA').val("0");
        $('#OvTxt200').val("0");
        $('#OvTxt100').val("0");
        $('#OvTxt500').val("0");
        $('#OvTxt2000').val("0");
        $('#ShTxt200').val("0");
        $('#ShTxt100').val("0");
        $('#ShTxt500').val("0");
        $('#ShTxt2000').val("0");
        $('#TxtSat1').val("");
        $('#TxtSat2').val("");
        $('#TxtSat3').val("");
        $('#TxtSat4').val("");
        $('#OVTxtTA').val("0");
        $('#ShTxtTA').val("0");
        $('#TxtEjdaispense').val("0");
        $('#TxtGldiffpc').val("0");
        $('#Txtpreviousdate').val("");
        $('#Txtprevioustome').val("");
        $('#Txtnextreplishment').val("");
        $('#Txtnexttime').val("");
        $('#DepTxt200').val("0");
        $('#DepTxt100').val("0");
        $('#DepTxt500').val("0");
        $('#DepTxt2000').val("0");
        $('#DepTxtSum').val("0");
        $('#DeTxt200').val("0");
        $('#DeTxt100').val("0");
        $('#DeTxt500').val("0");
        $('#DeTxt2000').val("0");
        $('#DeTxtTA').val("0");
        $('#CDAmt').val("0");
        $('#TxtGlCDdiffpc').val("0");
    }


    const onSubmitClick = () => {

        let alertMessages = "";
        let pattern = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;

        if (selectedATM === null || selectedATM.terminalid === 0) {
            alertMessages += 'Please select ATM. \n';
        }
        if (startDate === undefined || startDate === null) {
            alertMessages += 'Please enter Date. \n';
        }

        if (AtmTimeValue.length > 0 && !pattern.test(AtmTimeValue)) {
            alertMessages += 'Please enter Time in proper format. \n';
        }

        if (alertMessages.length > 0) {
            setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
            return false;
        }


        let TR_TIMESTAMPValue = '';
        if (AtmTimeValue.length > 0) {
            TR_TIMESTAMPValue = formatDate(startDate) + ' ' + AtmTimeValue + ":00";
        }
        else {
            TR_TIMESTAMPValue = formatDate(startDate) + ' 00:00:00';
        }

        setIsLoading(true);

        MaximusAxios.post('api/CBR/CBRInsertUpdate', {
            TerminalId: selectedATM.terminalid,
            TR_TIMESTAMP: TR_TIMESTAMPValue,
            Branchlocation: TerminalLocation,
            Atmopeningbalance50: $.isNumeric($('#ATMTxt200').val()) ? parseInt($('#ATMTxt200').val()).toString() : "0",
            Atmopeningbalance100: $.isNumeric($('#ATMTxt100').val()) ? parseInt($('#ATMTxt100').val()).toString() : "0",
            Atmopeningbalance500: $.isNumeric($('#ATMTxt500').val()) ? parseInt($('#ATMTxt500').val()).toString() : "0",
            Atmopeningbalance1000: $.isNumeric($('#ATMTxt2000').val()) ? parseInt($('#ATMTxt2000').val()).toString() : "0",
            Atmdispensecounter50: "0",
            Atmdispensecounter100: "0",
            Atmdispensecounter500: "0",
            Atmdispensecounter1000: "0",
            Atmremaingcounter50: $.isNumeric($('#RMCTxt200').val()) ? parseInt($('#RMCTxt200').val()).toString() : "0",
            Atmremaingcounter100: $.isNumeric($('#RMCTxt100').val()) ? parseInt($('#RMCTxt100').val()).toString() : "0",
            Atmremaingcounter500: $.isNumeric($('#RMCTxt500').val()) ? parseInt($('#RMCTxt500').val()).toString() : "0",
            Atmremaingcounter1000: $.isNumeric($('#RMCTxt2000').val()) ? parseInt($('#RMCTxt2000').val()).toString() : "0",
            Atmdivertcounter50: $.isNumeric($('#Dvt200').val()) ? parseInt($('#Dvt200').val()).toString() : "0",
            Atmdivertcounter100: $.isNumeric($('#Dvt100').val()) ? parseInt($('#Dvt100').val()).toString() : "0",
            Atmdivertcounter500: $.isNumeric($('#Dvt500').val()) ? parseInt($('#Dvt500').val()).toString() : "0",
            Atmdivertcounter1000: $.isNumeric($('#Dvt2000').val()) ? parseInt($('#Dvt2000').val()).toString() : "0",
            Amountreplenished50: $.isNumeric($('#ARxt200').val()) ? parseInt($('#ARxt200').val()).toString() : "0",
            Amountreplenished100: $.isNumeric($('#ARxt100').val()) ? parseInt($('#ARxt100').val()).toString() : "0",
            Amountreplenished500: $.isNumeric($('#ARxt500').val()) ? parseInt($('#ARxt500').val()).toString() : "0",
            Amountreplenished1000: $.isNumeric($('#ARxt2000').val()) ? parseInt($('#ARxt2000').val()).toString() : "0",
            Amountreturned50: $.isNumeric($('#AmtReturnedTxt200').val()) ? parseInt($('#AmtReturnedTxt200').val()).toString() : "0",
            Amountreturned100: $.isNumeric($('#AmtReturnedTxt100').val()) ? parseInt($('#AmtReturnedTxt100').val()).toString() : "0",
            Amountreturned500: $.isNumeric($('#AmtReturnedTxt500').val()) ? parseInt($('#AmtReturnedTxt500').val()).toString() : "0",
            Amountreturned1000: $.isNumeric($('#AmtReturnedTxt2000').val()) ? parseInt($('#AmtReturnedTxt2000').val()).toString() : "0",
            Newbalperatmcounters50: $.isNumeric($('#NBATMtxt200').val()) ? parseInt($('#NBATMtxt200').val()).toString() : "0",
            Newbalperatmcounters100: $.isNumeric($('#NBATMtxt100').val()) ? parseInt($('#NBATMtxt100').val()).toString() : "0",
            Newbalperatmcounters500: $.isNumeric($('#NBATMtxt500').val()) ? parseInt($('#NBATMtxt500').val()).toString() : "0",
            Newbalperatmcounters1000: $.isNumeric($('#NBATMtxt2000').val()) ? parseInt($('#NBATMtxt2000').val()).toString() : "0",
            Cashincassettes50: $.isNumeric($('#CCTxt200').val()) ? parseInt($('#CCTxt200').val()).toString() : "0",
            Cashincassettes100: $.isNumeric($('#CCTxt100').val()) ? parseInt($('#CCTxt100').val()).toString() : "0",
            Cashincassettes500: $.isNumeric($('#CCTxt500').val()) ? parseInt($('#CCTxt500').val()).toString() : "0",
            Cashincassettes1000: $.isNumeric($('#CCTxt2000').val()) ? parseInt($('#CCTxt2000').val()).toString() : "0",
            CASHFROMPURGEBIN50: $.isNumeric($('#CPTxt200').val()) ? parseInt($('#CPTxt200').val()).toString() : "0",
            CASHFROMPURGEBIN100: $.isNumeric($('#CPTxt100').val()) ? parseInt($('#CPTxt100').val()).toString() : "0",
            CASHFROMPURGEBIN500: $.isNumeric($('#CPTxt500').val()) ? parseInt($('#CPTxt500').val()).toString() : "0",
            CASHFROMPURGEBIN1000: $.isNumeric($('#CPTxt2000').val()) ? parseInt($('#CPTxt2000').val()).toString() : "0",
            ClosingCounter50: "0",
            ClosingCounter100: "0",
            ClosingCounter500: "0",
            ClosingCounter1000: "0",
            switchopeningbal50: $.isNumeric($('#OpTxt200').val()) ? parseInt($('#OpTxt200').val()).toString() : "0",
            switchopeningbal100: $.isNumeric($('#OpTxt100').val()) ? parseInt($('#OpTxt100').val()).toString() : "0",
            switchopeningbal500: $.isNumeric($('#OpTxt500').val()) ? parseInt($('#OpTxt500').val()).toString() : "0",
            switchopeningbal1000: $.isNumeric($('#OpTxt2000').val()) ? parseInt($('#OpTxt2000').val()).toString() : "0",
            switchdispensebal50: $.isNumeric($('#DiTxt200').val()) ? parseInt($('#DiTxt200').val()).toString() : "0",
            switchdispensebal100: $.isNumeric($('#DiTxt100').val()) ? parseInt($('#DiTxt100').val()).toString() : "0",
            switchdispensebal500: $.isNumeric($('#DiTxt500').val()) ? parseInt($('#DiTxt500').val()).toString() : "0",
            switchdispensebal1000: $.isNumeric($('#DiTxt2000').val()) ? parseInt($('#DiTxt2000').val()).toString() : "0",
            Atmdepositcounter50: $.isNumeric($('#DepTxt200').val()) ? parseInt($('#DepTxt200').val()).toString() : "0",
            Atmdepositcounter100: $.isNumeric($('#DepTxt100').val()) ? parseInt($('#DepTxt100').val()).toString() : "0",
            Atmdepositcounter500: $.isNumeric($('#DepTxt500').val()) ? parseInt($('#DepTxt500').val()).toString() : "0",
            Atmdepositcounter1000: $.isNumeric($('#DepTxt2000').val()) ? parseInt($('#DepTxt2000').val()).toString() : "0",
            Switchdepositcounter50: $.isNumeric($('#DeTxt200').val()) ? parseInt($('#DeTxt200').val()).toString() : "0",
            Switchdepositcounter100: $.isNumeric($('#DeTxt100').val()) ? parseInt($('#DeTxt100').val()).toString() : "0",
            Switchdepositcounter500: $.isNumeric($('#DeTxt500').val()) ? parseInt($('#DeTxt500').val()).toString() : "0",
            Switchdepositcounter1000: $.isNumeric($('#DeTxt2000').val()) ? parseInt($('#DeTxt2000').val()).toString() : "0",
            Switchremainingcounter50: $.isNumeric($('#ReTxt200').val()) ? parseInt($('#ReTxt200').val()).toString() : "0",
            Switchremainingcounter100: $.isNumeric($('#ReTxt100').val()) ? parseInt($('#ReTxt100').val()).toString() : "0",
            Switchremainingcounter500: $.isNumeric($('#ReTxt500').val()) ? parseInt($('#ReTxt500').val()).toString() : "0",
            Switchremainingcounter1000: $.isNumeric($('#ReTxt2000').val()) ? parseInt($('#ReTxt2000').val()).toString() : "0",
            CDamount: $.isNumeric($('#CDAmt').val()) ? parseInt($('#CDAmt').val()).toString() : "0",
            Glamount: $.isNumeric($('#GlAmt').val()) ? parseInt($('#GlAmt').val()).toString() : "0",
            UserName: currentUser.user.username,
            ClientCode: '001'
        }, { mode: 'cors' })
            .then(function (response) {
                setIsLoading(false);

                if (response.data === null || response.data === "1") {
                    clearData();
                    setSelectedATM(null);
                    alert('CBR updated successfully!');
                    window.location.reload(true);
                }
                else {
                    setShowMessageBox({ isShow: true, alertVariant: 'success', alertTitle: 'Info', alertMessage: response.data });
                }
            })
            .catch(function (error) {
                if (error.response) {
                    console.log(error.response.data);
                }
                setIsLoading(false);
            });

    };

    const onResetClick = () => {
        setSelectedATM(null);
        clearData();
    };


    return (
        <div className="cbrContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 colorBlack fileConfigHead">
                    Online CBR Entry
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">CBR</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <Link to="/">
                        <p className="fontSize12">Online CBR Entry</p>
                    </Link>
                </div>
            </div>

            {/* Top Content */}
            <div className="accordion" id="onlineCbrEntryTop">
                <div className="accordion-item">
                    <div
                        className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                        id="cbrHeadingOne"
                    >
                        <h6 className="fontWeight-600 colorBlack">Filters</h6>
                        <button
                            className="d-flex justify-content-center align-items-center allFiltersBtn btn p-0 "
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#cbrCollapseOne"
                            aria-expanded="true"
                            aria-controls="cbrCollapseOne"
                        >
                            <span className="icon-Hide"></span>
                            <span className="ms-1 fontSize12-m colorBlack">
                                Show / Hide
                            </span>
                        </button>
                    </div>
                    <div
                        id="cbrCollapseOne"
                        className="accordion-collapse collapse show"
                        aria-labelledby="cbrHeadingOne"
                        data-bs-parent="#onlineCbrEntryTop"
                    >
                        <div className="accordion-body">
                            <div className="hrGreyLine"></div>
                            <div className="configSelectBoxTop row">
                                <div className="clientNameSelect col">
                                    <label htmlFor="atmId">ATM ID</label>
                                    <AsyncSelect
                                        cacheOptions
                                        defaultOptions
                                        value={selectedATM}
                                        getOptionLabel={e => e.terminalid}
                                        getOptionValue={e => e.id}
                                        loadOptions={fetchATMData}
                                        onChange={handleAtmChange}
                                        onInputChange={handleInputChange}
                                        id="DrpATMLIST"
                                    />

                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="atmLocation">ATM Location</label>
                                    <input
                                        type="text"
                                        name="atmLocation"
                                        id="atmLocation"
                                        className="inputTextBox"
                                        value={TerminalLocation}
                                        readOnly
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="date">Date</label>
                                    <DatePicker
                                        renderCustomHeader={({
                                            date,
                                            changeYear,
                                            changeMonth,
                                            decreaseMonth,
                                            increaseMonth,
                                            prevMonthButtonDisabled,
                                            nextMonthButtonDisabled,
                                        }) => (
                                            <div
                                                style={{
                                                    margin: 1,
                                                    display: "flex",
                                                    justifyContent: "center",
                                                }}
                                            >
                                                <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                    <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                </button>
                                                <select
                                                    value={getYear(date)}
                                                    onChange={({ target: { value } }) => changeYear(value)}
                                                >
                                                    {years.map((option) => (
                                                        <option key={option} value={option}>
                                                            {option}
                                                        </option>
                                                    ))}
                                                </select>

                                                <select
                                                    value={months[getMonth(date)]}
                                                    onChange={({ target: { value } }) =>
                                                        changeMonth(months.indexOf(value))
                                                    }
                                                >
                                                    {months.map((option) => (
                                                        <option key={option} value={option}>
                                                            {option}
                                                        </option>
                                                    ))}
                                                </select>

                                                <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                    <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                </button>
                                            </div>
                                        )}
                                        selected={startDate}
                                        dateFormat="dd/MM/yyyy"
                                        onChange={(date) => setStartDateValue(date, 'ATM_Date')}
                                        className="reportDate"
                                        maxDate={new Date()}
                                        id="AtmDate"
                                        autoComplete="no"
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="time">Time</label>
                                    <input
                                        type="time"
                                        name="AtmTime"
                                        id="AtmTime"
                                        className="inputTextBox"
                                        placeholder="HH:MM"
                                        onChange={(e) => setStartDateValue(e.target.value, 'ATM_Time')}
                                        value={AtmTimeValue}
                                    />

                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="previousEodDate">Previous EOD Date</label>
                                    <input
                                        type="text"
                                        name="Txtpreviousdate"
                                        id="Txtpreviousdate"
                                        className="inputTextBox"
                                        disabled
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="previousEodTime">Previous EOD Time</label>
                                    <input
                                        type="text"
                                        name="Txtprevioustome"
                                        id="Txtprevioustome"
                                        className="inputTextBox"
                                        placeholder="HH:MM"
                                        disabled
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="nextEodDate">Next EOD Date</label>
                                    <input
                                        type="text"
                                        name="Txtnextreplishment"
                                        id="Txtnextreplishment"
                                        className="inputTextBox"
                                        disabled
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="nextEodTime">Next EOD Time</label>
                                    <input
                                        type="text"
                                        name="Txtnexttime"
                                        id="Txtnexttime"
                                        className="inputTextBox"
                                        placeholder="HH:MM"
                                        disabled
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Bottom Content */}
            <div className="accordion cbrAccordionBottom" id="onlineCbrEntryBottom">
                {/* ATM Counters */}
                <div className="accordion-item">
                    <h2 className="accordion-header" id="onlineCbrheadingOne">
                        <button
                            className="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#onlineCbrCollapseOne"
                            aria-expanded="false"
                            aria-controls="onlineCbrCollapseOne"
                        >
                            ATM Counters
                        </button>
                    </h2>
                    <div
                        id="onlineCbrCollapseOne"
                        className="accordion-collapse collapse"
                        aria-labelledby="onlineCbrheadingOne"
                        data-bs-parent="#onlineCbrEntryBottom"
                    >
                        <div className="accordion-body">
                            <div className="hrGreyLine"></div>
                            {/* Table */}
                            <div className="table-responsive atmCountersTable">
                                <table className="table table-borderless">
                                    <thead>
                                        <tr>
                                            <th scope="col" className="ps-0">
                                                Denomination
                                            </th>
                                            <th scope="col">ATM Opening Balance</th>
                                            <th scope="col">Dispense Counter</th>
                                            {(TerminalType != null && TerminalType == "CDM") ? (<th scope="col">Deposit Counter</th>) : null}
                                            <th scope="col">
                                                (By Receipt) <br /> Remaining Counter
                                            </th>
                                            <th scope="col" className="pe-0">
                                                Divert Counter
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                100
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ATMTxt100"
                                                    id="ATMTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DisTxt100"
                                                    id="DisTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            {(TerminalType != null && TerminalType == "CDM") ? (<td >
                                                <input
                                                    type="text"
                                                    name="DepTxt100"
                                                    id="DepTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            ) : null}
                                            <td>
                                                <input
                                                    type="text"
                                                    name="RMCTxt100"
                                                    id="RMCTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="Dvt100"
                                                    id="Dvt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                200
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ATMTxt200"
                                                    id="ATMTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DisTxt200"
                                                    id="DisTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            {(TerminalType != null && TerminalType == "CDM") ? (<td >
                                                <input
                                                    type="text"
                                                    name="DepTxt200"
                                                    id="DepTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            ) : null}
                                            <td>
                                                <input
                                                    type="text"
                                                    name="RMCTxt200"
                                                    id="RMCTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="Dvt200"
                                                    id="Dvt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                500
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ATMTxt500"
                                                    id="ATMTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DisTxt500"
                                                    id="DisTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            {(TerminalType != null && TerminalType == "CDM") ? (<td >
                                                <input
                                                    type="text"
                                                    name="DepTxt500"
                                                    id="DepTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            ) : null}
                                            <td>
                                                <input
                                                    type="text"
                                                    name="RMCTxt500"
                                                    id="RMCTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="Dvt500"
                                                    id="Dvt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                2000
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ATMTxt2000"
                                                    id="ATMTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DisTxt2000"
                                                    id="DisTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            {(TerminalType != null && TerminalType == "CDM") ? (<td >
                                                <input
                                                    type="text"
                                                    name="DepTxt2000"
                                                    id="DepTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            ) : null}
                                            <td>
                                                <input
                                                    type="text"
                                                    name="RMCTxt2000"
                                                    id="RMCTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="Dvt2000"
                                                    id="Dvt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                Total Amount
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ATMTxtSum"
                                                    id="ATMTxtSum"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DisTxtSum"
                                                    id="DisTxtSum"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            {(TerminalType != null && TerminalType == "CDM") ? (<td >
                                                <input
                                                    type="text"
                                                    name="DepTxtSum"
                                                    id="DepTxtSum"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            ) : null}
                                            <td>
                                                <input
                                                    type="text"
                                                    name="RMCtxtSum"
                                                    id="RMCtxtSum"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="DvtSum"
                                                    id="DvtSum"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                Total Dump Counter
                                            </th>
                                            <td colSpan="5" className="pe-0">
                                                <input
                                                    type="text"
                                                    name="Totdmpcnt"
                                                    id="Totdmpcnt"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Replenishment Counters */}
                <div className="accordion-item">
                    <h2 className="accordion-header" id="onlineCbrheadingTwo">
                        <button
                            className="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#onlineCbrCollapseTwo"
                            aria-expanded="false"
                            aria-controls="onlineCbrCollapseTwo"
                        >
                            Replenishment Counters
                        </button>
                    </h2>
                    <div
                        id="onlineCbrCollapseTwo"
                        className="accordion-collapse collapse"
                        aria-labelledby="onlineCbrheadingTwo"
                        data-bs-parent="#onlineCbrEntryBottom"
                    >
                        <div className="accordion-body">
                            <div className="hrGreyLine"></div>
                            {/* Table */}
                            <div className="table-responsive atmCountersTable replenishmentCountersTable">
                                <table className="table table-borderless">
                                    <thead>
                                        <tr>
                                            <th scope="col" className="ps-0">
                                                Denomination
                                            </th>
                                            <th scope="col">Amount Replenishment</th>
                                            <th scope="col">Amount Returned</th>
                                            <th scope="col" className="pe-0">
                                                New Bal. As Per ATM Counter
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                100
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ARxt100"
                                                    id="ARxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="AmtReturnedTxt100"
                                                    id="AmtReturnedTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="NBATMtxt100"
                                                    id="NBATMtxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                200
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ARxt200"
                                                    id="ARxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="AmtReturnedTxt200"
                                                    id="AmtReturnedTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="NBATMtxt200"
                                                    id="NBATMtxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                500
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ARxt500"
                                                    id="ARxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="AmtReturnedTxt500"
                                                    id="AmtReturnedTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="NBATMtxt500"
                                                    id="NBATMtxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                2000
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ARxt2000"
                                                    id="ARxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="AmtReturnedTxt2000"
                                                    id="AmtReturnedTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="NBATMtxt2000"
                                                    id="NBATMtxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                Total Amount
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ARxtAMT"
                                                    id="ARxtAMT"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ATRtxtATM"
                                                    id="ATRtxtATM"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="NBtxtATM"
                                                    id="NBtxtATM"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <p className="text-center fontSize14 letterSpacing-2 replenishmentText">
                                Note: Amount Replenishment = New Amount without adding remaining
                                counter
                            </p>
                        </div>
                    </div>
                </div>

                {/* Physical Counters and GL Balance */}
                <div className="accordion-item">
                    <h2 className="accordion-header" id="onlineCbrheadingThree">
                        <button
                            className="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#onlineCbrCollapseThree"
                            aria-expanded="false"
                            aria-controls="onlineCbrCollapseThree"
                        >
                            Physical Counters and GL Balance
                        </button>
                    </h2>
                    <div
                        id="onlineCbrCollapseThree"
                        className="accordion-collapse collapse"
                        aria-labelledby="onlineCbrheadingThree"
                        data-bs-parent="#onlineCbrEntryBottom"
                    >
                        <div className="accordion-body">
                            <div className="hrGreyLine"></div>
                            {/* Table */}
                            <div className="table-responsive atmCountersTable physicalCountersTable">
                                <table className="table table-borderless">
                                    <thead>
                                        <tr>
                                            <th scope="col" className="ps-0">
                                                Denomination
                                            </th>
                                            <th scope="col">Remaining Cash From Cash Cassettes</th>
                                            <th scope="col">Remaining Cash From Purge-Bin</th>
                                            <th scope="col">Total Remaining Cash From ATM</th>
                                            <th scope="col" className="pe-0">
                                                Physical Cash Balance
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                100
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="CCTxt100"
                                                    id="CCTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="CPTxt100"
                                                    id="CPTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="TCTxt100"
                                                    id="TCTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="PCTxt100"
                                                    id="PCTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                200
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="CCTxt200"
                                                    id="CCTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="CPTxt200"
                                                    id="CPTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="TCTxt200"
                                                    id="TCTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="PCTxt200"
                                                    id="PCTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                500
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="CCTxt500"
                                                    id="CCTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="CPTxt500"
                                                    id="CPTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="TCTxt500"
                                                    id="TCTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="PCTxt500"
                                                    id="PCTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                2000
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="CCTxt2000"
                                                    id="CCTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="CPTxt2000"
                                                    id="CPTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="TCTxt2000"
                                                    id="TCTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="PCTxt2000"
                                                    id="PCTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                Total Amount
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="CCTxtTA"
                                                    id="CCTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="CPTxtTA"
                                                    id="CPTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="TCTxtTA"
                                                    id="TCTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="PCTxtTA"
                                                    id="PCTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                GL Balance
                                            </th>
                                            <td colSpan="4" className="pe-0">
                                                <input
                                                    type="text"
                                                    name="GlAmt"
                                                    id="GlAmt"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}

                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                CD Balance
                                            </th>
                                            <td colSpan="4" className="pe-0">
                                                <input
                                                    type="text"
                                                    name="CDAmt"
                                                    id="CDAmt"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Switch Counters */}
                <div className="accordion-item">
                    <h2 className="accordion-header" id="onlineCbrheadingFour">
                        <button
                            className="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#onlineCbrCollapseFour"
                            aria-expanded="false"
                            aria-controls="onlineCbrCollapseFour"
                        >
                            Switch Counters
                        </button>
                    </h2>
                    <div
                        id="onlineCbrCollapseFour"
                        className="accordion-collapse collapse"
                        aria-labelledby="onlineCbrheadingFour"
                        data-bs-parent="#onlineCbrEntryBottom"
                    >
                        <div className="accordion-body">
                            <div className="hrGreyLine"></div>
                            {/* Table */}
                            <div className="table-responsive atmCountersTable">
                                <table className="table table-borderless">
                                    <thead>
                                        <tr>
                                            <th scope="col" className="ps-0">
                                                Denomination
                                            </th>
                                            <th scope="col">Opening Counter</th>
                                            <th scope="col">Dispense</th>
                                            <th scope="col">Deposit</th>
                                            <th scope="col">Remaining Counter</th>
                                            <th scope="col" className="pe-0">
                                                Closing Balance Counter
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                100
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="OpTxt100"
                                                    id="OpTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DiTxt100"
                                                    id="DiTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DeTxt100"
                                                    id="DeTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ReTxt100"
                                                    id="ReTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="PhcTxt100"
                                                    id="PhcTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                200
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="OpTxt200"
                                                    id="OpTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DiTxt200"
                                                    id="DiTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DeTxt200"
                                                    id="DeTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ReTxt200"
                                                    id="ReTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="PhcTxt200"
                                                    id="PhcTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                500
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="OpTxt500"
                                                    id="OpTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DiTxt500"
                                                    id="DiTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DeTxt500"
                                                    id="DeTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ReTxt500"
                                                    id="ReTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="PhcTxt500"
                                                    id="PhcTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                2000
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="OpTxt2000"
                                                    id="OpTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DiTxt2000"
                                                    id="DiTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td >
                                                <input
                                                    type="text"
                                                    name="DeTxt2000"
                                                    id="DeTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ReTxt2000"
                                                    id="ReTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="PhcTxt2000"
                                                    id="PhcTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                Total Amount
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="OpTxtTA"
                                                    id="OpTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DiTxtTA"
                                                    id="DiTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="DeTxtTA"
                                                    id="DeTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ReTxtTA"
                                                    id="ReTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="PhcTxtTA"
                                                    id="PhcTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                {/* GL Difference with Physical Cash */}
                <div className="accordion-item">
                    <h2 className="accordion-header" id="onlineCbrheadingFive">
                        <button
                            className="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#onlineCbrCollapseFive"
                            aria-expanded="false"
                            aria-controls="onlineCbrCollapseFive"
                        >
                            GL Difference with Physical Cash
                        </button>
                    </h2>
                    <div
                        id="onlineCbrCollapseFive"
                        className="accordion-collapse collapse"
                        aria-labelledby="onlineCbrheadingFive"
                        data-bs-parent="#onlineCbrEntryBottom"
                    >
                        <div className="accordion-body physicalCashBox">
                            <div className="hrGreyLine"></div>
                            <div className="row configSelectBoxTop">
                                <div className="col clientNameSelect">
                                    <label htmlFor="physcialCashDifference">
                                        GL & Physical Cash Difference
                                    </label>
                                    <input
                                        type="text"
                                        name="TxtGldiffpc"
                                        id="TxtGldiffpc"
                                        className="inputNumberBox"
                                        placeholder="0"
                                        disabled
                                    />
                                </div>
                                <div className="col clientNameSelect">
                                    <label htmlFor="physcialCashDifference">
                                        GL & CD Cash Difference
                                    </label>
                                    <input
                                        type="text"
                                        name="TxtGlCDdiffpc"
                                        id="TxtGlCDdiffpc"
                                        className="inputNumberBox"
                                        placeholder="0"
                                        disabled
                                    />
                                </div>
                                <div className="col clientNameSelect">
                                    <label htmlFor="physcialCashDifference">
                                        EJ Dispense(Previous EOD to Current EOD)
                                    </label>
                                    <input
                                        type="text"
                                        name="TxtEjdaispense"
                                        id="TxtEjdaispense"
                                        className="inputNumberBox"
                                        placeholder="0"
                                        disabled
                                    />
                                </div>
                            </div>
                            <div className="hrGreyLine"></div>
                            <p className="text-center fontWeight-500 fontSize16 letterSpacing-2 physicalCashHeading">
                                Difference between ATM Counters & Physical Counters
                            </p>
                            {/* Table */}
                            <div className="table-responsive atmCountersTable replenishmentCountersTable">
                                <table className="table table-borderless mt-0">
                                    <thead>
                                        <tr>
                                            <th scope="col" className="ps-0">
                                                Denomination
                                            </th>
                                            <th scope="col">Overage</th>
                                            <th scope="col">Shortage</th>
                                            <th scope="col" className="pe-0">
                                                Status
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row" className="ps-0">
                                                100
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="OvTxt100"
                                                    id="OvTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ShTxt100"
                                                    id="ShTxt100"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="TxtSat2"
                                                    id="TxtSat2"
                                                    className="inputNumberBox"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                200
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="OvTxt200"
                                                    id="OvTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ShTxt200"
                                                    id="ShTxt200"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="TxtSat1"
                                                    id="TxtSat1"
                                                    className="inputNumberBox"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                500
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="OvTxt500"
                                                    id="OvTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ShTxt500"
                                                    id="ShTxt500"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="TxtSat3"
                                                    id="TxtSat3"
                                                    className="inputNumberBox"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                2000
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="OvTxt2000"
                                                    id="OvTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ShTxt2000"
                                                    id="ShTxt2000"
                                                    className="inputNumberBox"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="TxtSat4"
                                                    id="TxtSat4"
                                                    className="inputNumberBox"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    onKeyUp={(e) => SyncTextBoxes(e.target.id)}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>

                                        <tr>
                                            <th scope="row" className="ps-0">
                                                Total Amount
                                            </th>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="OVTxtTA"
                                                    id="OVTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="ShTxtTA"
                                                    id="ShTxtTA"
                                                    className="inputNumberBox inputTotalAmount"
                                                    placeholder="0"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                            <td className="pe-0">
                                                <input
                                                    type="text"
                                                    name="TxtSat5"
                                                    id="TxtSat5"
                                                    className="inputNumberBox inputTotalAmount"
                                                    disabled
                                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                                    autoComplete="no"
                                                    onPaste={handlePaste}
                                                />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div className="text-center btnsBtm">
                                <button type="button" className="btnPrimaryOutline" onClick={onResetClick} >
                                    Reset
                                </button>
                                <button type="button" className="btnPrimary" onClick={onSubmitClick}>
                                    Submit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default CbrMainWindow;
