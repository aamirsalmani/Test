import React from "react";
import { useSelector } from "react-redux";
// CSS
import "./onlineCbr.css";
import "../../common/traceReport.css"; 
// Components
import SidebarMain from "../../common/SidebarMain";
import CbrMainWindow from "./CbrMainWindow";

const OnlineCbr = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });
  
  return (
    <div className="mainView">
        <CbrMainWindow />
    </div>
  );
};

export default OnlineCbr;
