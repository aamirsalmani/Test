﻿import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import MaximusAxios from "../common/apiURL" ;
// CSS
import "./changePassword.css";
// Components
import SidebarMain from "../common/SidebarMain";
import ChangePasswordMainWindow from "./ChangePasswordMainWindow"; 

const ChangePassword = () => {
    const currentUser = useSelector((state) => state.authReducer);

    const [hideMenu, setMenuStatus] = useState('Login');

    const [isPostBack, setIsPostBack] = useState(null);

    // useEffect(() => {
    //     fetchLoginStatus()
    // },
    //     [isPostBack]
    // );

    // const fetchLoginStatus = () => {

    //     let Username = '';
    //     if (currentUser !== null && currentUser.user !== null) {
    //         Username = currentUser.user.username;
    //     }

    //     MaximusAxios.get('api/Home/CheckUserLogin?UserID=' + Username, {  mode: 'cors' }).then(resultLogin => {
    //         if (resultLogin.data !== null) {
    //             setMenuStatus(resultLogin.data);
    //         }
    //         else {
    //             setMenuStatus('Login');
    //         }
    //     });
    // }


    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* {(hideMenu !== null && hideMenu === "Login") ? (
                <SidebarMain />
            ) : null}
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                <ChangePasswordMainWindow />
            {/* </div> */}
        </div>
    );
};

export default ChangePassword;
