﻿import React, { useState } from "react";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { useSelector } from "react-redux";

const ChangePasswordMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const [OldPasswordValue, setOldPasswordValue] = useState("");
  const [NewPasswordValue, setNewPasswordValue] = useState("");
  const [ConfirmPasswordValue, setConfirmPasswordValue] = useState("");
  const [newPasswordVisible, setNewPasswordVisible] = useState(false);
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false);
  const [inputerrors, setInputErrors] = useState({});

  const [inputerrorObject, setinputerrorObject] = useState({
    newpassword: "",
    confirmpassword: "",
  });

  //const Show Loader
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const onReset = (e) => {
    e.preventDefault();
   // setNewPasswordVisible(false);
    //setConfirmPasswordVisible(false);
     setNewPasswordValue("");
      setConfirmPasswordValue("");
  };
  const handlePasswordChange = (event) => {
    const pwdPattern = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*?[#?!@$%^&*-]).{8,}/;
    const { name, value } = event.target;
    setNewPasswordValue(event.target.value);

    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "newpassword") {
        if (value === null || value.trim().length === 0) {
          newErrors.newpassword = "Please enter New Password ";
        } else if (!pwdPattern.test(NewPasswordValue)) {
          newErrors.newpassword =
            "Password must contain at least one number and one special character and one uppercase and lowercase letter, and at least 8 or more characters";
        } else {
          delete newErrors.newpassword;
        }
      }
      return newErrors;
    });
  };

  const handleConfirmedPasswordChange = (event) => {
    setConfirmPasswordValue(event.target.value);
    const pwdPattern = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*?[#?!@$%^&*-]).{8,}/;
    const { name, value } = event.target;

    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "confirmpassword") {
        if (value === null || value.trim().length === 0) {
          newErrors.confirmpassword = "Please enter Password ";
        } else if (!pwdPattern.test(ConfirmPasswordValue)) {
          newErrors.confirmpassword =
            "Password must contain at least one number and one special character and one uppercase and lowercase letter, and at least 8 or more characters";
        } else {
          delete newErrors.confirmpassword;
        }
      }
      return newErrors;
    });
  };

  const OnChangePassword = () => {
    if (OldPasswordValue === null || OldPasswordValue.trim().length === 0) {
      alert("Please enter Old Password!");
      return false;
    }

    if (
      OldPasswordValue.trim().length > 0 &&
      NewPasswordValue.trim().length > 0 &&
      OldPasswordValue === NewPasswordValue.trim()
    ) {
      alert("New Password cannot be the same as Old Password!");
      return false;
    }

    if (NewPasswordValue !== ConfirmPasswordValue) {
      alert(NewPasswordValue !== ConfirmPasswordValue)
      setInputErrors((prevErrors) => ({
        ...prevErrors,
        confirmpassword: "Password Mis-match, re-enter New password and Confirm Password!",
      }));
      return false;
    } else {

      setInputErrors((prevErrors) => {
        const { confirmpassword, ...rest } = prevErrors; 
        return rest; 
      });
    }

   

    const hasErrors = Object.keys(inputerrors).length > 0;
   console.log(inputerrors)
    const isAllFieldsFilled = Object.values(inputerrorObject).every(
      (value) => value.trim() !== ""
    );
    console.log(isAllFieldsFilled)
    if (hasErrors || !isAllFieldsFilled) {
      alert("Please correct all details and try again.");
      return;
    }
    
    setIsLoading(true);

    MaximusAxios.post(
      "/api/UserDetails/ChangePassword",
      {
        ClientCode: "99999",
        UserID: currentUser.user.username,
        OldPassword: OldPasswordValue,
        ConfirmPassword: ConfirmPasswordValue,
        NewPassword: NewPasswordValue,
        NewSalt: NewPasswordValue,
        CreatedBy: currentUser.user.username,
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setIsLoading(false);
        console.log(response.data);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Error",
            alertMessage: "Error occurred",
          });
        } else if (response.data.length > 0) {
          alert(response.data);
          window.location.reload(false);
        } else {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Error",
            alertMessage: "Error occurred",
          });
        }
      })
      .catch(function (error) {
        setIsLoading(false);
        if (error) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred*",
          });
        }
      });
  };

  return (
    <div className="changepasswordContainer">
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Change Password
        </h5>

        {/* BreadCrumb */}
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">User Management</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12"> Change Password</p>
        </div>
      </div>

      <div className="tableBorderBox changepasswordWhiteBox changepasswordWhiteBox2 d-flex justify-content-center w-100">
        <div className="changepasswordSmallBox">
          <div className="clientNameSelect col">
            <label htmlFor="UserName">User Name</label>
            <input
              type="text"
              name="UserName"
              id="UserName"
              className="inputTextBox"
              value={currentUser.user.username}
              autoComplete="no"
              disabled
            />
          </div>
          <div className="clientNameSelect col">
            <label htmlFor="oldpassword">Old Password</label>
            <input
              type="password"
              name="oldpassword"
              id="oldpassword"
              className="inputTextBox"
              placeholder="Enter Old Password"
              onChange={(e) => setOldPasswordValue(e.target.value)}
              value={OldPasswordValue}
              autoComplete="no"
            />
          </div>
          <div>
            <div className="clientNameSelect col">
              <label htmlFor="newPassword">New Password:</label>
              <input
                type={newPasswordVisible ? "text" : "password"}
                name="newpassword"
                id="newpassword"
                className="inputTextBox"
                placeholder="Enter New Password"
                onChange={handlePasswordChange}
                value={NewPasswordValue}
                onBlur={handlePasswordChange}
                autoComplete="no"
              />
              {inputerrors.newpassword && (
                    <span className="text-danger fontSize12">
                      {inputerrors.newpassword}
                    </span>
                  )}

              <div className="mt-1">
                <input
                  type="checkbox"
                  className="mr-2"
                  id="toggleNewPassword"
                  onChange={() => setNewPasswordVisible(!newPasswordVisible)}
                />
                <span> </span>
                <label htmlFor="toggleNewPassword" className="ml-2 small">
                  Show Password
                </label>
              </div>
              
            </div>

            <div className="clientNameSelect col mt-1">
              <label htmlFor="confirmPassword">Confirm Password:</label>
              <input
                type={confirmPasswordVisible ? "text" : "password"}
                name="confirmpassword"
                id="confirmpassword"
                className="inputTextBox"
                placeholder="Enter Confirm Password"
                onChange={handleConfirmedPasswordChange}
                value={ConfirmPasswordValue}
                onBlur={handleConfirmedPasswordChange}
                autoComplete="no"
              />
              {inputerrors.confirmpassword && (
                    <span className="text-danger fontSize12">
                      {inputerrors.confirmpassword}
                    </span>
                  )}
              <div className="clientNameSelect col mt-1">
                <input
                  type="checkbox"
                  id="toggleConfirmPassword"
                  onChange={() =>
                    setConfirmPasswordVisible(!confirmPasswordVisible)
                  }
                />
                <span> </span>
                <label htmlFor="toggleConfirmPassword" className="pl-2">
                  {" "}
                  Show Password
                </label>
              </div>
            </div>
          </div>

          {/* <div className="clientNameSelect col">
                        <label htmlFor="newpassword">New Password</label>
                        <input
                            type="password"
                            name="newpassword"
                            id="newpassword"
                            className="inputTextBox"
                            placeholder="Enter New Password"
                            pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*?[#?!@$%^&*-]).{8,}"
                            onChange={(e) => setNewPasswordValue(e.target.value)}
                            value={NewPasswordValue}
                            autoComplete="no"
                        />
                    </div>

                    <div className="clientNameSelect col">
                        <label htmlFor="confirmpassword">Confirm Password</label>
                        <input
                            type="password"
                            name="confirmpassword"
                            id="confirmpassword"
                            className="inputTextBox"
                            placeholder="Enter Confirm Password"
                            pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*?[#?!@$%^&*-]).{8,}"
                            onChange={(e) => setConfirmPasswordValue(e.target.value)}
                            value={ConfirmPasswordValue}
                            autoComplete="no"
                        />
                    </div> */}
          {/* Buttons */}
          <div className="text-center changepasswordBtnBox">
            <button
              type="button"
              className="btnPrimaryOutline"
              onClick={(e) => onReset(e)}
            >
              {" "}
              Reset
            </button>
            <button className="btnPrimary ms-2" onClick={OnChangePassword}>
              {" "}
              Change Password
            </button>
          </div>
        </div>
      </div>
      <LoadingSpinner isShow={isShow} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default ChangePasswordMainWindow;
