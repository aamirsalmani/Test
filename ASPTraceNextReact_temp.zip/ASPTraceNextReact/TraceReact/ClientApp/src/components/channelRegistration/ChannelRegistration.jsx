import React from "react";
import { useSelector } from "react-redux";
// CSS
import "./channelRegistration.css";
// Components
import SidebarMain from "../common/SidebarMain";
import ChannelRegistrationMainWindow from "./ChannelRegistrationMainWindow";


const ChannelRegistration = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });
    return (
        <div className="mainView">
            {/* <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                <ChannelRegistrationMainWindow />
            {/* </div> */}
        </div>
    );
};

export default ChannelRegistration;