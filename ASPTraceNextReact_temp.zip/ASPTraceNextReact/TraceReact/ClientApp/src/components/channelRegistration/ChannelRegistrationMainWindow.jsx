import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL" ;
// CSS
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import "datatables.net-dt/css/jquery.dataTables.min.css"
import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
// Components

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"
// Images
import Delete from "../../images/common/redDelete.svg";
import editRow from "../../images/common/editRow.svg";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";

const ChannelRegistrationMainWindow = () => {
    const currentUser = useSelector((state) => state.authReducer); 
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });
    const [Mode, setMode] = useState(true);
    const [ChannelRegistrationTableData, setChannelRegistrationTableData] = useState(null);
    const [isNewEntry, setNewEntry] = useState(false);
    const [refresh, setRefresh] = useState(true);
    const [isShowChannelModal, setShowChannelModal] = useState(false);
    const [showChannelID, setshowChannelID] = useState(false);
    const [buttonValue, setButtonValue] = useState('ADD');
    const [ChannelNameValue, setChannelNameValue] = useState(null);
    const [ChannelID, setChannelID] = useState(null);
    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });


    //Get data
    const fetchChannelData = () => {
        setIsLoading(true);
        MaximusAxios.get('api/ChannelReg/GetChannelRegList', {  mode: 'cors' }).then(result => {
            setChannelRegistrationTableData(result.data);
            setIsLoading(false);
        }).catch(function (error) {
            if (error.response) {
                console.log(error.response.data);
            }
            setIsLoading(false);
        }); 
    };
    useEffect(() => {
        fetchChannelData();

    },[refresh]
    );

    const onAddClick = () => {
        if (ChannelNameValue === null || ChannelNameValue.trim().length === 0) {
                    alert("Please select Channel Name");
                    return false;
        }
        console.log(Mode + ChannelID + ChannelNameValue);
        setIsLoading(true);
        MaximusAxios.post('api/ChannelReg/ChannelRegAdd', {
            Mode: buttonValue,
            ChannelID: buttonValue === 'ADD' ? '0' : ChannelID,
            CreatedBy: currentUser.user.username,
            ChannelName: ChannelNameValue
        }, {  mode: 'cors' })
            .then(function (response) {
                setShowChannelModal(false);
                setIsLoading(false);
                if (response.data === "0") {
                    alert("Channel already exists!");
                    setRefresh(!refresh);
                } else if (response.data === "" || response.data === "1") {
                    if (buttonValue === 'ADD') { alert('Channel Registration added successfully!'); }
                    if (buttonValue === 'UPDATE') { alert('Channel details updated successfully!'); }
                    if (buttonValue === 'ADD') setChannelRegistrationTableData(null);
                    setRefresh(!refresh);
                } else {
                    alert(response.data);
                }
            }).catch(function (error) {
                if (error.response) {
                    console.log(error.response.data);
                }
                setIsLoading(false);
            });

    }


    const onNewClick = () => {
        setShowChannelModal(true);
        setButtonValue('ADD');
        setChannelNameValue('');
        setNewEntry(true);


    };

    const onEditClick = (ChannelID) => {
        if (window.confirm("Are you sure you want to edit.")) {
            MaximusAxios.get(`api/ChannelReg/GetChannelRegById/${ChannelID}`, {  mode: 'cors' })
                .then(response => {
                    if (response.data != null) {
                        setShowChannelModal(true);
                        setshowChannelID(true);
                        setChannelID(response.data.channelID);
                        setChannelNameValue(response.data.channelName);
                        setNewEntry(false);
                    }})
                     .catch(function (error) {
                    if (error.response) {
                        console.log(error.response.data);
                    }
                     });
            setButtonValue('UPDATE');
        }
    };


    


    const onDeleteClick = (ChannelID) => {

        if (window.confirm("Are you sure you want to delete.")) {
            MaximusAxios.post(`api/ChannelReg/ChannelRegDelete`,
                {
                    Mode: 'DELETE',
                    ChannelID:String(ChannelID)
                }, {  mode: 'cors' })
                .then(function (response) {
                    if (response.data === "" || response.data.length > 0) {
                        alert('Channel deleted Successfully!');
                        setChannelRegistrationTableData(null);
                        setRefresh(!refresh);
                    }
                }).catch(function (error) {
                    if (error.response) {
                        console.log(error.response.data);
                    }
                });
        }
    
    };

    $(document).ready(function () {
        if (ChannelRegistrationTableData !== null && ChannelRegistrationTableData.length > 0) {
            $('#gvChannelRegistration').DataTable({
                "bDestroy": true,
                "columnDefs": [
                    { orderable: false, targets: [2] }
                ]
            });
        }
    });

    // Tooltip

    const renderTooltipAdd = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Click to add new entry
        </Tooltip>
    );


    return (
        <div className="configLeft ChannelContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Channel Registration
                </h5>
                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Client Management</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Channel Registration</p>
                </div>
            </div>


            {/* Table Content */}
            <div className="configLeftBottom">
                <div>
                    {/* Table */}
                    {(ChannelRegistrationTableData != null && ChannelRegistrationTableData.length > 0 && ChannelRegistrationTableData !=undefined)  ? (
                        <div>
                            <div className="exportButton">

                                <OverlayTrigger
                                    placement="top"
                                    delay={{ show: 150, hide: 400 }}
                                    overlay={renderTooltipAdd}
                                >
                                    <button type="button" className="iconAddButtonBox" onClick={onNewClick}>
                                        <span className="icon-Plus">+</span>
                                        <span className="ms-1 fontSize12-m colorPrimaryDefault">Add New</span>
                                    </button>
                                </OverlayTrigger>
                            </div>
                            <div className="tableBorderBox pt-3">
                                <div className="w-100 table-responsive">
                                    <div className="table-responsive tableChannelContentBox" >
                                        <table id="gvChannelRegistration" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                            <thead>
                                                <tr>
                                                   <th>Channel Name</th>
                                                    <th>Channel ID</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody >
                                                {
                                                    ChannelRegistrationTableData.map((p, index) => {
                                                        return <tr key={index}>
                                                            <td >{p.channelName}</td>
                                                            <td className="text-dark">{p.channelID}</td>
                                                            <td><div className="text-center">
                                                                <button type="button" className="iconButtonBox" onClick={() => onEditClick(p.channelID)} >
                                                                    <img src={editRow} alt="Edit" title="Edit" />
                                                                </button>
                                                                <button type="button" className="iconButtonBox" onClick={() => onDeleteClick(p.channelID)} >
                                                                    <img src={Delete} alt="Delete" title="Delete" />
                                                                </button>
                                                            </div></td>
                                                        </tr>
                                                    })
                                                }

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
                        :
                        (
                            <div className="tableBorderBox pt-3">
                                <div className="addButton">
                                    <button
                                        className="btn p-0 d-flex justify-content-center align-items-center"
                                        type="button" onClick={onNewClick} id="addButtonChannel"
                                    >
                                        <span className="icon-Plus">+</span>
                                        <span className="ms-1 fontSize12-m colorPrimaryDefault">Add New</span>
                                    </button>
                                </div>
                                <div className="w-100 table-responsive">
                                    <div className="table-responsive tableContentBox">
                                        <table className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }}>
                                            <thead>
                                                <tr style={{ border: "1px dashed black !important" }}>
                                                    <th scope="col">Channel Name</th>
                                                    <th scope="col">Channel ID</th>
                                                    <th scope="col">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td colSpan="6" style={{ textAlign: "left", backgroundColor: "var(--table-hover-color) !important", paddingTop: "10px" }}> No Records Found <hr /> </td>
                                                </tr>
                                            </tbody>
                                        </table>

                                    </div>
                                </div>
                            </div>
                        )
                    }
                </div>
            </div>


            {isShowChannelModal && (
                <Modal
                    show={isShowChannelModal}
                    onHide={() => setShowChannelModal(!isShowChannelModal)}
                    centered
                    className="ChannelTableModal"
                >
                    <Modal.Header closeButton>
                        <Modal.Title className="fontSize16-sm letterSpacing-2">
                            {isNewEntry ? <span>Add</span> : <span>Update</span>} Channel
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        {!isNewEntry ? (
                            <div className="ChannelControl">
                                <label htmlFor="ddlVendor">Channel ID</label>
                            <span className="text-danger font-size13">*</span>
                            <input
                                type="text"
                                name="ChannelID"
                                id="ChannelID"                               
                                className="inputTextBox"
                                    value={ChannelID}
                                    disabled
                            />
                            </div>
                        ) : null}

                        <div className="ChannelControl">
                            <label htmlFor="ddlVendor">Channel Name</label>
                            <span className="text-danger font-size13">*</span>
                            <input
                                type="text"
                                name="ChannelName"
                                id="ChannelName"
                                placeholder="Enter Channel Name"
                                className="inputTextBox"
                                onChange={(e) => setChannelNameValue(e.target.value)}
                                value={ChannelNameValue}
                                onKeyPress={(e) => !/[a-zA-Z ]/.test(e.key) && e.preventDefault()}
                            />
                        </div>
                        
                    </Modal.Body>
                    <Modal.Footer>
                        <button type="button" className="btnPrimary ms-2" onClick={onAddClick} >{buttonValue}</button>
                       
                    </Modal.Footer>
                </Modal>
            )}

            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default ChannelRegistrationMainWindow;