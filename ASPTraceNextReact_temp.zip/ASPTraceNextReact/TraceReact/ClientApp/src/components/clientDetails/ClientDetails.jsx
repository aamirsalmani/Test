﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
import "../fieldIdentification/fieldConfig.css";
// Components
import SidebarMain from "../common/SidebarMain";
import ClientDetailsMainWindow from "./ClientDetailsMainWindow";

const ClientDetails = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                <ClientDetailsMainWindow />
            {/* </div> */}
        </div>
    );
};

export default ClientDetails;
