﻿import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Tooltip } from "react-bootstrap";
import "react-datepicker/dist/react-datepicker.css";
import AsyncSelect from "react-select/async";
import MaximusAxios from "../common/apiURL";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import $ from "jquery";
import TableRows from "./TableRows";
import axios from "axios";
import postHeader from "../../pages/login/services/post-header";

import { useSelector } from "react-redux";

const ClientDetailsMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const { state } = useLocation();

  const navigate = useNavigate();

  const [stateClientID, setClientIDValue] = useState(null);
  const [isShow, setIsLoading] = useState(false);
  const [checkIsActive, setcheckIsActive] = useState(false);
  const [IsNewEntry, setIsNewEntry] = useState(null);
  const [ClientAdd, setClientAdd] = useState(null);
  const [inputValue, setValue] = useState("0");
  const [selectedCountryValue, setSelectedCountryValue] = useState(null);
  const [selectedCurrencyValue, setSelectedCurrencyValue] = useState(null);
  const [selectedModuleValue, setSelectedModuleValue] = useState(null);
  const [selectedDomainValue, setSelectedDomainValue] = useState(null);
  const [ClientNameValue, setClientNameValue] = useState(null);
  const [ClientCodeValue, setClientCodeValue] = useState(null);
  const [ClientAddressValue, setClientAddressValue] = useState(null);
  const [ContactNoValue, setContactNoValue] = useState(null);
  const [EmailIdValue, setEmailIdValue] = useState(null);
  const [ConcernPersonNameValue, setConcernPersonNameValue] = useState(null);
  const [ConcernPersonContactValue, setConcernPersonContactValue] =
    useState(null);
  const [ConcernPersonEmailIdValue, setConcernPersonEmailIdValue] =
    useState(null);
  const [FTPUsernameValue, setFTPUsernameValue] = useState(null);
  const [FTPIPValue, setFTPIPValue] = useState(null);
  const [FTPPasswordValue, setFTPPasswordValue] = useState(null);
  const [FTPPortValue, setFTPPortValue] = useState(null);
  const [TerminalCountValue, setTerminalCountValue] = useState("0");
  const [UserLimitValue, setUserLimitValue] = useState(null);
  const [ReportCutOffTimeValue, setReportCutOffTimeValue] = useState(null);
  const [LogoFile, setLogoFile] = useState(null);
  const [ChooseColorCodeValue, setChooseColorCodeValue] = useState("#000000");
  const [IsBankValue, setIsBankValue] = useState(null);
  const [IsActiveValue, setIsActiveValue] = useState(null);
  const [LogoFileName, setLogoFileName] = useState(null);

  const [inputerrors, setInputErrors] = useState({});
  const [inputerrorObject, setinputerrorObject] = useState({
    clientname: "",
    clientcode: "",
    clientaddress: "",
    contactno: "",
    emailid: "",
    concernpersonname: "",
    concernpersoncontact: "",
    concernpersonemailid: "",
    ftpusername: "",
    ftpip: "",
    ftppassword: "",
    ftpport: "",
    userlimit: "",
    choosecolorcode: "",
  });

  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });


  useEffect(() => {
    if (state !== null) {
      setClientIDValue(state.clientID);
      setIsNewEntry(state.IsNewEntry);
      if (state.clientID > 0) {

        fetchClientMasterData(state.clientID);
      }
    }
  }, [ClientAdd]);

  const fetchClientMasterData = (ClientIDValue) => {
    setIsLoading(true);
    console.log("state" + state)
    MaximusAxios.get("/api/ClientReg/GetClientData?ClientID=" + ClientIDValue, {
      mode: "cors",
    })
      .then((ClientData) => {
        // console.log(ClientData.data.ftP_IP)
        if (ClientData.data != null) {
          setClientNameValue(ClientData.data.clientName);
          setClientCodeValue(ClientData.data.clientCode);
          setClientAddressValue(ClientData.data.address);
          setContactNoValue(ClientData.data.contactNo);
          setEmailIdValue(ClientData.data.emailID);
          setConcernPersonNameValue(ClientData.data.concernPerson);
          setConcernPersonContactValue(ClientData.data.cpContactNo);
          setConcernPersonEmailIdValue(ClientData.data.cpEmailID);
          setFTPUsernameValue(ClientData.data.ftpUserName);
          setFTPIPValue(ClientData.data.ftP_IP);
          setFTPPasswordValue(ClientData.data.ftpPassword);
          setFTPPortValue(ClientData.data.ftpPort);
          setTerminalCountValue("0");
          setUserLimitValue(ClientData.data.userLimit);
          setReportCutOffTimeValue(ClientData.data.reportCutoffTime);
          setChooseColorCodeValue(ClientData.data.colorcode);
          $("#choosecolorcode").val(ClientData.data.colorcode);
          setLogoFileName(ClientData.data.clientLogo);
          setIsActiveValue(ClientData.data.isActive); //isActive
          setcheckIsActive(ClientData.data.isActive);
          setIsBankValue(ClientData.data.isBank); //isBank
          if (ClientData.data.isBank) {
            setIsBankValue("Yes");
          } else {
            setIsBankValue("No");
          }

          if (ClientData.data.isActive || IsNewEntry === "Add") {
            setIsActiveValue("Yes");
          } else {
            setIsActiveValue("No");
          }

          setSelectedCountryValue({
            id: ClientData.data.countryID,
            country: ClientData.data.country,
          });
          // setSelectedCurrencyValue({ "currencyID": ClientData.data.currencyID, "currencyCode": ClientData.data.currencyCode });
          setSelectedDomainValue({
            domainID: ClientData.data.domainID,
            domainType: ClientData.data.domainType,
          });
          setSelectedModuleValue({
            moduleID: ClientData.data.moduleID,
            moduleType: ClientData.data.moduleType,
          });

          MaximusAxios.get(
            "/api/ClientReg/GetChannelModeList?ClientID=" + ClientIDValue,
            { mode: "cors" }
          )
            .then((ChannelData) => {
              setRowsData(ChannelData.data);
            })
            .catch(function (error) {
              if (error.response) {
                console.log(error.response.data);
              }
            });
          //alert(ClientData.data.country)
          handleCurrencyChange1(ClientData.data.country)
        }
        // handleClientChange(ClientData.data.clientName)
        // handleClientCodeChange(ClientData.data.clientCode)
        // handleClientAddressChange(ClientData.data.address)
        // handleContactNoChange()
        // handleEmailIDChange()
        // handleConcernPersonName()
        // handleConcernContactChange()
        // handleConcernEmailIDChange()
        // handleFTPUsernameChange()
        // handleFTPIpChange()
        // handleFTPPasswordChange()
        // handleFTPPortChange()
        // handleUserLimitChange()
        // handleChooseColorCodeChange()

        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });
  };
  // const CheckAllFeilds=()=>{
  //   handleClientChange()
  //   handleClientCodeChange()
  //   handleClientAddressChange()
  //   handleContactNoChange()
  //   handleEmailIDChange()
  //   handleConcernPersonName()
  //   handleConcernContactChange()
  //   handleConcernEmailIDChange()
  //   handleFTPUsernameChange()
  //   handleFTPIpChange()
  //   handleFTPPasswordChange()
  //   handleFTPPortChange()
  //   handleUserLimitChange()
  //   handleChooseColorCodeChange()

  // }

  //Check for all input fileds 
  const handleClientChange = (event) => {
    setClientNameValue(event.target.value)
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "clientname") {
        if (value === null || value.trim().length === 0) {
          newErrors.clientname = "Please enter Client Name";
        } else if (value.length < 3) {
          newErrors.clientname = "Client Name  must be greater then 3 length";
        } else if (value.length > 20) {
          newErrors.clientname = "Client Name must be less then 20 length";
        } else if (!/^[A-Za-z\s]+$/.test(value)) {
          newErrors.clientname = "Client Name must contain only alphabets";
        } else {
          delete newErrors.clientname;
        }
      }
      return newErrors;
    });
  }
  const handleClientCodeChange = (event) => {
    setClientCodeValue(event.target.value)
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "clientcode") {
        if (value === null || value.trim().length === 0) {
          newErrors.clientcode = "Please enter Client Code";
        } else if (value.length < 1) {
          newErrors.clientcode = "Client Code  must be greater then 1 length";
        } else if (value.length > 8) {
          newErrors.clientcode = "Client Code must be less then 8 length";
        } else if (!/^\d+$/.test(value)) {
          newErrors.clientcode = "Client Code must contain only numbers";
        } else {
          delete newErrors.clientcode;
        }
      }
      return newErrors;
    });
  }
  const handleClientAddressChange = (event) => {
    setClientAddressValue(event.target.value)
    const { name, value } = event.target;
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "clientaddress") {
        if (!value || value.trim().length === 0) {
          newErrors.clientaddress = "Client address is required.";
        } else {
          delete newErrors.clientaddress;
        }
      }

      return newErrors;
    });
  }
  const handleContactNoChange = (event) => {
    setContactNoValue(event.target.value)
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "contactno") {
        if (!value || value.trim().length === 0) {
          newErrors.contactno = "Please enter your contact number.";
        } else if (!/^[789]/.test(value)) {
          newErrors.contactno = "Contact number must begin with 7, 8, or 9.";
        } else if (/^0/.test(value)) {
          newErrors.contactno = "Leading zeros are not allowed.";
        } else if (!/^\d+$/.test(value)) {
          newErrors.contactno = "Contact number must contain only numbers";
        } else if (value.length !== 10) {
          newErrors.contactno = "Contact number must be exactly 10 digits.";
        } else {
          delete newErrors.contactno; // Remove error if valid
        }
      }

      return newErrors; // Return updated errors
    });
  }
  const handleEmailIDChange = (event) => {
    setEmailIdValue(event.target.value)
    const { name, value } = event.target;
    const ValidEmailID = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "emailid") {
        if (value === null || value.trim().length === 0) {
          newErrors.emailid = "Please enter Email ID ";
        } else if (!ValidEmailID.test(value)) {
          newErrors.emailid = "Please enter valid Email ID ";
        } else {
          delete newErrors.emailid;
        }
      }
      return newErrors;
    });
  }
  const handleConcernPersonName = (event) => {
    setConcernPersonNameValue(event.target.value)
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "concernpersonname") {
        if (value === null || value.trim().length === 0) {
          newErrors.concernpersonname = "Please enter Concern Name";
        } else if (value.length < 3) {
          newErrors.concernpersonname = "Concern Name must be greater then 3 length";
        } else if (value.length > 20) {
          newErrors.concernpersonname = "Concern Name must be less then 20 length";
        } else if (!/^[A-Za-z\s]+$/.test(value)) {
          newErrors.concernpersonname = "Concern Name must contain only alphabets";
        } else {
          delete newErrors.concernpersonname;
        }
      }
      return newErrors;
    });
  }
  const handleConcernContactChange = (event) => {
    setConcernPersonContactValue(event.target.value)
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "concernpersoncontact") {
        if (!value || value.trim().length === 0) {
          newErrors.concernpersoncontact = "Please enter your contact number.";
        } else if (!/^[789]/.test(value)) {
          newErrors.concernpersoncontact = "Contact number must begin with 7, 8, or 9.";
        } else if (/^0/.test(value)) {
          newErrors.concernpersoncontact = "Leading zeros are not allowed.";
        } else if (!/^\d+$/.test(value)) {
          newErrors.concernpersoncontact = "Contact number must contain only numbers";
        } else if (value.length !== 10) {
          newErrors.concernpersoncontact = "Contact number must be exactly 10 digits.";
        } else {
          delete newErrors.concernpersoncontact; // Remove error if valid
        }
      }

      return newErrors; // Return updated errors
    });
  }
  const handleConcernEmailIDChange = (event) => {
    const { name, value } = event.target;
    setConcernPersonEmailIdValue(value);

    const ValidEmailID = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    // Updating input error object correctly
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "concernpersonemailid") {
        if (!value.trim()) {
          newErrors.concernpersonemailid = "Please enter Email ID";
        } else if (!ValidEmailID.test(value)) {
          newErrors.concernpersonemailid = "Please enter a valid Email ID";
        } else {
          delete newErrors.concernpersonemailid;
        }
      }
      return newErrors;
    });
  };

  const handleFTPUsernameChange = (event) => {
    setFTPUsernameValue(event.target.value)
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "ftpusername") {
        if (value === null || value.trim().length === 0) {
          newErrors.ftpusername = "Please enter FTP User Name";
        } else if (value.length < 3) {
          newErrors.ftpusername = "FTP User Name must be greater then 3 length";
        } else if (value.length > 20) {
          newErrors.ftpusername = "FTP User Name must be less then 20 length";
        } else {
          delete newErrors.ftpusername;
        }
      }
      return newErrors;
    });
  }
  const handleFTPIpChange = (event) => {
    setFTPIPValue(event.target.value)
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "ftpip") {
        if (!value || value.trim().length === 0) {
          newErrors.ftpip = "Please enter your FTP IP Address.";
        } else if (
          !/^((25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[0-1]?[0-9][0-9]?)$/.test(
            value
          )
        ) {
          newErrors.ftpip = "Please enter a valid IPv4 address (e.g., 172.25.1.1).";
        } else {
          delete newErrors.ftpip; // Remove error if valid
        }
      }

      return newErrors; // Return updated errors
    });
  }
  const handleFTPPasswordChange = (event) => {
    setFTPPasswordValue(event.target.value);
    const pwdPattern = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*?[#?!@$%^&*-]).{8,}/;
    const { name, value } = event.target;

    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "ftppassword") {
        if (value === null || value.trim().length === 0) {
          newErrors.ftppassword = "Please enter Password ";
        } else if (!pwdPattern.test(value)) {
          newErrors.ftppassword =
            "Password must contain at least one number and one special character and one uppercase and lowercase letter, and at least 8 or more characters";
        } else {
          delete newErrors.ftppassword;
        }
      }
      return newErrors;
    });
  };

  const handleFTPPortChange = (event) => {
    setFTPPortValue(event.target.value);
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "ftpport") {
        if (!value || value.trim().length === 0) {
          newErrors.ftpport = "Please enter FTP Port Number";
        } else if (value.length !== 4) {
          newErrors.ftpport = "FTP Port Number must be exactly 4 digits.";
        } else {
          delete newErrors.ftpport; // Remove error if valid
        }
      }
      return newErrors; // Return updated errors
    });
  }


  const handleCountryChange = (value) => {
    setSelectedCountryValue(value);
    handleCurrencyChange(value);
  };

  const handleUserLimitChange = (event) => {
    setUserLimitValue(event.target.value)
    const { name, value } = event.target;
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "userlimit") {
        if (!value || value.trim().length === 0) {
          newErrors.userlimit = "Users Limit is required.";
        } else if (value <= 0) {
          newErrors.userlimit = "Add atlest  one User.";
        } else if (/^0/.test(value)) {
          newErrors.userlimit = "Leading zeros are not allowed.";
        } else {
          delete newErrors.userlimit;
        }
      }

      return newErrors;
    });
  }
  const handleChooseColorCodeChange = (event) => {
    setChooseColorCodeValue(event.target.value)
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "choosecolorcode") {
        if (!value || value.trim().length === 0) {
          newErrors.choosecolorcode = "Color code is required.";
        } else {
          delete newErrors.choosecolorcode;
        }
      }

      return newErrors;
    });

  };

  const handleInputChange = (value) => {
    setValue(value);
  };

  const checkClientCodeValue = (elementId) => {
    MaximusAxios.get(
      "/api/ClientReg/CheckClientCode?ClientID=" +
      stateClientID +
      "&ClientCode=" +
      $("#" + elementId).val(),
      { mode: "cors" }
    ).then((ClientCodeData) => {
      if (ClientCodeData !== null) {
        if (ClientCodeData.data === "1") {
          setClientCodeValue("");
          $("#" + elementId).val("");
          alert("Client Code already exists.");
        }
      }
    });
  };

  const fetchDomainData = (inputValue) => {
    return MaximusAxios.get("/api/ClientReg/GetClientDomainList", {
      mode: "cors",
    }).then((result) => {
      if (inputValue.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.domainType.toLowerCase().includes(inputValue.toLowerCase())
        );
      }
    });
  };

  const fetchModuleData = (inputValue) => {
    return MaximusAxios.get("/api/ClientReg/GetClientModuleList", {
      mode: "cors",
    }).then((result) => {
      if (inputValue.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.moduleType.toLowerCase().includes(inputValue.toLowerCase())
        );
      }
    });
  };

  const fetchCountryData = (inputValue) => {
    return MaximusAxios.get("/api/CurrencyReg/GetCountryRegList", {
      mode: "cors",
    }).then((result) => {
      if (inputValue.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.country.toLowerCase().includes(inputValue.toLowerCase())
        );
      }
    });
  };

  const handleCurrencyChange = (value) => {
    //alert(value.country)
    // console.log(value);
    MaximusAxios.get(
      `api/CurrencyReg/SetCountryCode?CountryName=${value.country}`,
      { mode: "cors" }
    )
      .then((result) => {
        setSelectedCurrencyValue(result.data);
        //console.log(result.data);
        // alert(result.data.countryCode);
        //  setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });
    //console.log("selectedCurrencyValue.countryCode= :", selectedCurrencyValue.countryCode);
    //setSelectedCurrencyValue(value);
  };
  const handleCurrencyChange1 = (value) => {
    //alert(value.country)
    // console.log(value);
    MaximusAxios.get(
      `api/CurrencyReg/SetCountryCode?CountryName=${value}`,
      { mode: "cors" }
    )
      .then((result) => {
        setSelectedCurrencyValue(result.data);
        //console.log(result.data);
        // alert(result.data.countryCode);
        //  setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });
    //console.log("selectedCurrencyValue.countryCode= :", selectedCurrencyValue.countryCode);
    //setSelectedCurrencyValue(value);
  };
  const handleDomainTypeChange = (value) => {
    setSelectedDomainValue(value);
  };

  const handleModuleTypeChange = (value) => {
    setSelectedModuleValue(value);
  };

  const handleLogoChange = (value) => {
    setLogoFile(value);
  };
  const handleIsBankChange = (evt) => {
    setIsBankValue(evt.target.value);
  };
  const handleIsActiveChange = (evt) => {
    setIsActiveValue(evt.target.value);
  };

  const btnSubmitClick = () => {
    try {
      if (
        selectedCountryValue === undefined ||
        selectedCountryValue === null
      ) {
        alert("Please select Country Code");
        return false;
      } if (
        selectedDomainValue === undefined ||
        selectedDomainValue === null
      ) {
        alert("Please enter Domain Type");
        return false;
      }
      if (
        selectedModuleValue === undefined ||
        selectedModuleValue === null
      ) {
        alert("Please enter Module Type");
        return false;
      }
      if (
        ChooseColorCodeValue === undefined ||
        ChooseColorCodeValue === null
      ) {
        alert("Please Choose Color Code");
        return false;
      }

      if (
        ConcernPersonNameValue === undefined ||
        ConcernPersonNameValue === null
      ) {
        alert("Please enter Concern Person Name ");
        return false;
      }

      if (
        ConcernPersonEmailIdValue === undefined ||
        ConcernPersonEmailIdValue === null
      ) {
        alert("Please enter Concern Person EmailId");
        return false;
      }

      if (
        ConcernPersonContactValue === undefined ||
        ConcernPersonContactValue === null
      ) {
        alert("Please enter Concern Person Contact");
        return false;
      }

      if (state.IsNewEntry === "Add") {
        //   Check all correct or not
        const hasErrors = Object.keys(inputerrors).length > 0;
        console.log(inputerrors)
        console.log(inputerrorObject)
        const isAllFieldsFilled = Object.values(inputerrorObject).every(
          (value) => value.trim() !== ""
        );

        if (hasErrors || !isAllFieldsFilled) {
          alert("Please correct all details and try again.");
          return;
        }
      }
      else {
        const hasErrors = Object.keys(inputerrors).length > 0;
        if (hasErrors) {
          alert("Please correct all details and try again.");
          return;
        }
      }
      setIsLoading(true);

      const ClientData = new FormData();

      ClientData.append("ClientID", stateClientID);
      ClientData.append("Mode", "ADD");
      ClientData.append("DomainID", selectedDomainValue.domainID);
      ClientData.append("ModuleID", selectedModuleValue.moduleID);
      ClientData.append("ClientCode", ClientCodeValue);
      ClientData.append("ClientName", ClientNameValue);
      ClientData.append("Address", ClientAddressValue);
      ClientData.append("ContactNo", ContactNoValue);
      ClientData.append("EmailID", EmailIdValue);
      ClientData.append("ConcernPerson", ConcernPersonNameValue || "");
      ClientData.append("CPEmailID", ConcernPersonEmailIdValue || "");
      ClientData.append("CPContactNo", ConcernPersonContactValue || "");
      ClientData.append("IsBank", "1");
      // ClientData.append("IsBank", IsBankValue === "Yes" ? "1" : "0");
      ClientData.append("IsActive", IsActiveValue === "Yes" ? "1" : "0");
      ClientData.append("CountryID", selectedCountryValue.id);
      ClientData.append("CurrencyID", selectedCurrencyValue.currencyID);
      ClientData.append("currencyCode", setSelectedCurrencyValue.currencyCode)
      ClientData.append("FTP_IP", FTPIPValue);
      ClientData.append("FTPUserName", FTPUsernameValue);
      ClientData.append("FTPPassword", FTPPasswordValue);
      ClientData.append("FTPPort", FTPPortValue);
      ClientData.append("ClientLogo", LogoFileName);
      ClientData.append("UserLimit", UserLimitValue);
      ClientData.append("TerminalCount", TerminalCountValue);
      ClientData.append("ReportTime", ReportCutOffTimeValue);
      ClientData.append("UserName", currentUser.user.username);
      ClientData.append("Colorcode", ChooseColorCodeValue.toUpperCase());
      ClientData.append("ClientChannelModes", JSON.stringify(rowsData));
      ClientData.append("ClientLogoFile", LogoFile);

      axios
        .post("/api/ClientReg/AddUpdateClientMaster", ClientData, {
          headers: postHeader(),
          mode: "cors",
        })
        .then(function (response) {
          setIsLoading(false);
          if (response.data === null || response.data === undefined) {
            setShowMessageBox({
              isShow: true,
              alertVariant: "info",
              alertTitle: "Error",
              alertMessage: "Error occurred",
            });
          } else if (response.data.length > 0) {
            alert(response.data);
            navigate("/client-management/client-registration");
          } else {
            setShowMessageBox({
              isShow: true,
              alertVariant: "info",
              alertTitle: "Error",
              alertMessage: "Error occurred",
            });
          }
        })
        .catch(function (error) {
          setIsLoading(false);
          console.log(error);
        });
    } catch (ex) {
      console.log(ex.data);
      setIsLoading(false);
    }
  };

  const handlePaste = (event) => {
    const clipboardValue = event.clipboardData.getData("text");
    const numberPattern = /^[0-9\b]+$/;
    if (!numberPattern.test(clipboardValue)) {
      event.preventDefault();
    }
  };

  const onBackClick = (e) => {
    navigate("/client-management/client-registration");
  };

  const renderTooltipAdd = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to add new entry
    </Tooltip>
  );

  const [rowsData, setRowsData] = useState([]);

  const addTableRows = () => {
    let ChannelSelectFound = false;

    if (rowsData !== null && rowsData !== undefined) {
      if (rowsData.length > 0) {
        for (var i = 0; i < rowsData.length; i++) {
          if (rowsData[i]["channelID"] === "0") {
            ChannelSelectFound = true;
          }
        }
      }
    }

    if (ChannelSelectFound) {
      alert("Please select Channel for last row ");
    } else {
      const rowsInput = {
        channelName: "--Select--",
        channelID: "0",
        onus: false,
        acquirer: false,
        issuer: false,
        clientID: stateClientID,
      };
      setRowsData([...rowsData, rowsInput]);
      //console.log(rowsData);
    }
  };
  const deleteTableRows = (index) => {
    if (rowsData !== null && rowsData !== undefined) {
      if (rowsData.length > 0) {
        const rowsInput = [...rowsData];
        rowsInput.splice(index, 1);
        setRowsData(rowsInput);
      }
    }
  };

  const handleChange = (index, event) => {
    //console.log('handleChange');

    let ChannelFound = false;
    const rowsInput = [...rowsData];
    if (event.target !== undefined) {
      //console.log(event.target.id);
      if (event.target.id === "chkONUS") {
        rowsInput[index]["onus"] = event.target.checked;
      } else if (event.target.id === "chkACQUIRER") {
        rowsInput[index]["acquirer"] = event.target.checked;
      } else if (event.target.id === "chkISSUER") {
        rowsInput[index]["issuer"] = event.target.checked;
      }
    } else {
      if (event.value !== undefined) {
        if (event.value !== "0") {
          if (rowsData !== null && rowsData !== undefined) {
            if (rowsData.length > 0) {
              for (var i = 0; i < rowsData.length; i++) {
                if (rowsData[i]["channelID"] === event.value) {
                  ChannelFound = true;
                }
              }
            }
          }

          if (!ChannelFound) {
            rowsInput[index]["channelID"] = event.value;
            rowsInput[index]["channelName"] = event.label;
          } else {
            rowsInput[index]["channelID"] = "0";
            rowsInput[index]["channelName"] = "--Select--";
            alert("Given channel already selected");
          }
        } else {
          rowsInput[index]["channelID"] = "0";
          rowsInput[index]["channelName"] = "--Select--";
        }
      }
    }
    console.log(rowsInput);
    setRowsData(rowsInput);
  };

  return (
    <div className="configLeft identificationContainer">
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">&nbsp;</h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Client Management</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Client Registration</p>
        </div>
      </div>

      {/* Bottom Content */}
      <div className="configLeftBottom">
        <div className="accordion-body">
          <h5 className="fontWeight-600 fileConfigHead colorBlack ">
            Basic Information
          </h5>
          <div className="hrGreyLine"></div>
          <div className="configSelectBoxTop row">
            <div className="clientNameSelect col">
              <label htmlFor="clientname">Client Name</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="clientname"
                id="clientname"
                placeholder="Enter Client Name"
                className="inputTextBox"
                onChange={handleClientChange}
                defaultValue={ClientNameValue}
                onKeyPress={(e) =>
                  !/^[a-zA-Z0-9 ]+$/.test(e.key) && e.preventDefault()
                }
              />
              {inputerrors.clientname && (
                <span className="text-danger fontSize12">
                  {inputerrors.clientname}
                </span>
              )}
            </div>

            <div className="clientNameSelect col">
              <label htmlFor="clientcode">Client Code</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="clientcode"
                id="clientcode"
                placeholder="Enter Client Code"
                className="inputTextBox"
                onChange={handleClientCodeChange}
                onBlur={handleClientCodeChange}
                defaultValue={ClientCodeValue}
                maxLength={12}
              />
              {inputerrors.clientcode && (
                <span className="text-danger fontSize12">
                  {inputerrors.clientcode}
                </span>
              )}
            </div>

            <div className="clientNameSelect col">
              <label htmlFor="clientaddress">Client Address</label>
              <span className="text-danger font-size13">*</span>
              <textarea
                type="textarea"
                name="clientaddress"
                id="clientaddress"
                placeholder="Enter Address here...."
                className="inputTextBox"
                onChange={handleClientAddressChange}
                onBlur={handleClientAddressChange}
                defaultValue={ClientAddressValue}
                maxLength={200}
              />
              {inputerrors.clientaddress && (
                <span className="text-danger fontSize12">
                  {inputerrors.clientaddress}
                </span>
              )}
            </div>

            <div className="clientNameSelect col">
              <label htmlFor="contactno">Contact No.</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="contactno"
                id="contactno"
                className="inputTextBox"
                onChange={handleContactNoChange}
                onBlur={handleContactNoChange}
                maxLength="10"
                onPaste={handlePaste}
                required
                defaultValue={ContactNoValue}
              />
              {inputerrors.contactno && (
                <span className="text-danger fontSize12">
                  {inputerrors.contactno}
                </span>
              )}
            </div>

            <div className="clientNameSelect col">
              <label htmlFor="emailid">Email Id</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="email"
                name="emailid"
                id="emailid"
                placeholder="Enter Email Id"
                className="inputTextBox"
                onChange={handleEmailIDChange}
                onBlur={handleEmailIDChange}
                defaultValue={EmailIdValue}
                maxLength={50}
              />
              {inputerrors.emailid && (
                <span className="text-danger fontSize12">
                  {inputerrors.emailid}
                </span>
              )}
            </div>

            <div className="clientNameSelect col">
              <label htmlFor="concernpersonname">Concern Person Name</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="concernpersonname"
                id="concernpersonname"
                placeholder="Enter Concern Person Name"
                className="inputTextBox"
                onChange={handleConcernPersonName}
                onBlur={handleConcernPersonName}
                defaultValue={ConcernPersonNameValue}
                maxLength={50}
              />
              {inputerrors.concernpersonname && (
                <span className="text-danger fontSize12">
                  {inputerrors.concernpersonname}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="concernpersoncontact">
                Concern Person Contact
              </label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="concernpersoncontact"
                id="concernpersoncontact"
                className="inputTextBox"
                onChange={handleConcernContactChange}
                onBlur={handleConcernContactChange}
                onPaste={handlePaste}
                required
                defaultValue={ConcernPersonContactValue}
                maxLength="12"
              />
              {inputerrors.concernpersoncontact && (
                <span className="text-danger fontSize12">
                  {inputerrors.concernpersoncontact}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="concernpersonemailid">
                Concern Person Email Id
              </label>
              <span className="text-danger font-size13">*</span>
              <input
                type="email"
                name="concernpersonemailid"
                id="concernpersonemailid"
                placeholder="Enter Concern Person Email Id"
                className="inputTextBox"
                onChange={handleConcernEmailIDChange}
                onBlur={handleConcernEmailIDChange}
                defaultValue={ConcernPersonEmailIdValue}
                maxLength={50}
              />
              {inputerrors.concernpersonemailid && (
                <span className="text-danger fontSize12">
                  {inputerrors.concernpersonemailid}
                </span>
              )}
            </div>
          </div>

          <h5 className="fontWeight-600 fileConfigHead colorBlack mt-20  ">
            FTP Credential
          </h5>
          <div className="hrGreyLine"></div>
          <div className="configSelectBoxTop row">
            <div className="clientNameSelect col">
              <label htmlFor="ftpusername">FTP Username</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="ftpusername"
                id="ftpusername"
                placeholder="Enter FTP Username"
                className="inputTextBox"
                onChange={handleFTPUsernameChange}
                onBlur={handleFTPUsernameChange}
                defaultValue={FTPUsernameValue}
                maxLength={35}
              />
              {inputerrors.ftpusername && (
                <span className="text-danger fontSize12">
                  {inputerrors.ftpusername}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="ftpip">FTP IP</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="ftpip"
                id="ftpip"
                placeholder="Enter FTP IP"
                required
                className="inputTextBox"
                onChange={handleFTPIpChange}
                onBlur={handleFTPIpChange}
                defaultValue={FTPIPValue}
              />
              {inputerrors.ftpip && (
                <span className="text-danger fontSize12">
                  {inputerrors.ftpip}
                </span>
              )}
            </div>

            <div className="clientNameSelect col">
              <label htmlFor="ftppassword">FTP Password</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="Password"
                name="ftppassword"
                id="ftppassword"
                placeholder="Enter FTP Password"
                className="inputTextBox"
                onChange={handleFTPPasswordChange}
                onBlur={handleFTPPasswordChange}
                defaultValue={FTPPasswordValue}
              />
              {inputerrors.ftppassword && (
                <span className="text-danger fontSize12">
                  {inputerrors.ftppassword}
                </span>
              )}
            </div>

            <div className="clientNameSelect col">
              <label htmlFor="ftpport">FTP Port</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="ftpport"
                id="ftpport"
                placeholder="Enter FTP Port"
                className="inputTextBox"
                onChange={handleFTPPortChange}
                onBlur={handleFTPPortChange}
                defaultValue={FTPPortValue}
                maxLength={4}
                onPaste={handlePaste}
              />
              {inputerrors.ftpport && (
                <span className="text-danger fontSize12">
                  {inputerrors.ftpport}
                </span>
              )}
            </div>
          </div>

          <h5 className="fontWeight-600 fileConfigHead colorBlack mt-20  ">
            Other Details
          </h5>
          <div className="hrGreyLine"></div>
          <div className="configSelectBoxTop row">
            <div className="clientNameSelect col" id="Country">
              <label htmlFor="clientName">Country Name</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedCountryValue}
                getOptionLabel={(e) => e.country}
                getOptionValue={(e) => e.id}
                loadOptions={fetchCountryData}
                onInputChange={handleInputChange}
                onChange={handleCountryChange}
                id="ddlCountry"
                name="ddlCountry"
              />
              {inputerrors.ddlCountry && (
                <span className="text-danger fontSize12">
                  {inputerrors.ddlCountry}
                </span>
              )}
            </div>

            <div className="clientNameSelect col" id="Currency">
              <label htmlFor="ddlCountry">Currency Code</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="ftpport"
                id="ftpport"
                value={selectedCurrencyValue?.countryCode || ""}
                placeholder="Enter Currency Code"
                className="inputTextBox"
                disabled={true}
              />
            </div>
            {/* <AsyncSelect
    cacheOptions
    defaultOptions
    value={selectedCurrencyValue}
    getOptionLabel={(e) => e.currencyCode}
    getOptionValue={(e) => e.currencyID}
    loadOptions={fetchCurrencyData}
    onInputChange={handleInputChange}
    onChange={handleCurrencyChange}
    id="ddlCountry"
    isDisabled={true}
  /> 
</div>
*/}

            <div className="clientNameSelect col">
              <label htmlFor="clientName">Domain Type</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedDomainValue}
                getOptionLabel={(e) => e.domainType}
                getOptionValue={(e) => e.domainID}
                loadOptions={fetchDomainData}
                onInputChange={handleInputChange}
                onChange={handleDomainTypeChange}
                id="ddlDomain"
                name="ddlDomain"
              />
            </div>

            <div className="clientNameSelect col">
              <label htmlFor="clientName">Module Type</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedModuleValue}
                getOptionLabel={(e) => e.moduleType}
                getOptionValue={(e) => e.moduleID}
                loadOptions={fetchModuleData}
                onInputChange={handleInputChange}
                onChange={handleModuleTypeChange}
                id="ddlModule"
                name="ddlModule"
              />
            </div>

            {/* <div className="clientNameSelect col">
                                <label htmlFor="terminalcount">Terminal Count</label>
                                <input
                                    type="text"
                                    name="terminalcount"
                                    id="terminalcount"
                                    className="inputTextBox"
                                    onChange={(e) => setTerminalCountValue(e.target.value)}
                                    onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                                    onPaste={handlePaste}
                                    defaultValue={TerminalCountValue}
                                />
                            </div> */}

            <div className="clientNameSelect col">
              <label htmlFor="userlimit">User Limit</label>
              <input
                type="text"
                name="userlimit"
                id="userlimit"
                className="inputTextBox"
                onChange={handleUserLimitChange}
                onBlur={handleUserLimitChange}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                onPaste={handlePaste}
                defaultValue={UserLimitValue}
                maxLength={5}
              />
              {inputerrors.userlimit && (
                <span className="text-danger fontSize12">
                  {inputerrors.userlimit}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="reportcutofftime">Report Cut-Off Time</label>
              <input
                type="time"
                name="reportcutofftime"
                id="reportcutofftime"
                className="inputTextBox"
                onChange={(e) => setReportCutOffTimeValue(e.target.value)}
                defaultValue={ReportCutOffTimeValue}
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="logo">Logo</label>
              <input
                type="file"
                name="logo"
                id="logo"
                className="inputTextBox"
                onChange={(e) => handleLogoChange(e.target.files[0])}
              />
              <span>{LogoFileName}</span>
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="choosecolorcode">Choose Color Code</label>
              <input
                name="choosecolorcode"
                id="choosecolorcode"
                className="inputTextBox"
                type="color"
                onChange={handleChooseColorCodeChange}
                onBlur={handleChooseColorCodeChange}
              />
              {inputerrors.choosecolorcode && (
                <span className="text-danger fontSize12">
                  {inputerrors.choosecolorcode}
                </span>
              )}
            </div>
            {/* <div className="clientNameSelect col">
                                <label htmlFor="isbank">Is Bank</label><br />
                                <label><br />Yes
                                 &nbsp; &nbsp;<input
                                        type="radio"
                                        name="isbank"
                                        id="isbank"
                                        className="radiobutton"
                                        value="Yes"
                                        onChange={handleIsBankChange}
                                        checked={IsBankValue === "Yes"}
                                    /></label> &nbsp; &nbsp;
                                <label>No &nbsp;
                                <input
                                        type="radio"
                                        name="isbank"
                                        id="isbank"
                                        className="radiobutton"
                                        value="No"
                                        onChange={handleIsBankChange}
                                        checked={IsBankValue === "No"}
                                    /></label>
                            </div> */}
            {IsNewEntry === "Update" ? (
              <div className="clientNameSelect col">
                <label htmlFor="isactive">Is Active</label>
                <div className="form-check">
                  <label className="form-check-label">
                    Yes
                    <input
                      type="radio"
                      name="isactive"
                      className="form-check-input"
                      value="Yes"
                      onChange={handleIsActiveChange}
                      defaultValue={IsActiveValue}
                      checked={IsActiveValue === "Yes"}
                    />
                  </label>
                </div>
                <div className="form-check">
                  <label className="form-check-label">
                    No
                    <input
                      type="radio"
                      name="isactive"
                      className="form-check-input"
                      value="No"
                      onChange={handleIsActiveChange}
                      defaultValue={IsActiveValue}
                      checked={IsActiveValue === "No"}
                    />
                  </label>
                </div>
              </div>
            ) : null}
          </div>

          <h5 className="fontWeight-600 fileConfigHead colorBlack mt-20 ">
            Channel Details
          </h5>
          <div className="hrGreyLine"></div>
          <div className="tableBorderBox w-100 pt-3 mt-3">
            <div className="table-responsive w-100">
              <div className="table-responsive pb-5">
                <table
                  id="gvChannels"
                  className="table table-striped table-hover table-borderless align-middle w-100"
                >
                  <thead>
                    <tr>
                      <th>Channel Type</th>
                      <th>ONUS</th>
                      <th>ACQUIRER / OUTWARD</th>
                      <th>ISSUER / INWARD</th>
                      <th>
                        <button
                          className="btn btn-outline-success"
                          onClick={addTableRows}
                        >
                          +
                        </button>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <TableRows
                      rowsData={rowsData}
                      deleteTableRows={deleteTableRows}
                      handleChange={handleChange}
                    />
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div className="configSelectBoxTop row">
            <div className="text-center btnsBtm">
              <button
                type="button"
                className="btnPrimary ms-2"
                onClick={btnSubmitClick}
              >
                Submit
              </button>
              &nbsp;
              <button
                type="button"
                className="btnPrimaryOutline"
                onClick={(e) => onBackClick(e)}
              >
                Back
              </button>
            </div>
          </div>
        </div>
      </div>
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default ClientDetailsMainWindow;
