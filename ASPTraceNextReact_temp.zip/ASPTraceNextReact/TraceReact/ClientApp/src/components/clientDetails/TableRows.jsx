﻿import React, { useState, useEffect } from "react";
import Select from "react-select";
import MaximusAxios from "../common/apiURL" ;


function TableRows({ rowsData, deleteTableRows, handleChange }) {

    const [getData, setgetData] = useState(null);

    useEffect(() => {
        fetchChannelData();
    },
        [getData]
    );

    const fetchChannelData = () => {

        MaximusAxios.get('api/ClientReg/GetClientChannelList', {  mode: 'cors' }).then(result => {
            setChannelTypeOptions(result.data);
        });

    }

    const [optionsChannelType, setChannelTypeOptions] = useState([{ channelID: "0", channelName: "--Select--" }]);
    
    return (
        rowsData.map((data, index) => {
            const { channelName, channelID, onus, acquirer, issuer } = data;
            return (
                <tr key={index}>
                    <td>
                        <div className="clientNameSelect col">
                            <Select
                                id={"ddlChannelType" + index}
                                value={{ "value": channelID, "label": channelName }}
                                classNamePrefix="reactSelectBox"
                                options={optionsChannelType.map(x => (
                                    {
                                        value: x.channelID,
                                        label: x.channelName
                                    }
                                ))}
                                onChange={(evnt) => (handleChange(index, evnt))}
                            />
                        </div>
                    </td>
                    <td><input type="checkbox"
                        name="chkONUS"
                        id="chkONUS"
                        defaultChecked={onus}
                        onChange={(evnt) => (handleChange(index, evnt))}
                        className="inputCheckBox" /></td>
                    <td><input type="checkbox"
                        name="chkACQUIRER"
                        id="chkACQUIRER"
                        defaultChecked={acquirer}
                        onChange={(evnt) => (handleChange(index, evnt))}
                        className="inputCheckBox" /> </td>
                    <td><input type="checkbox"
                        name="chkISSUER"
                        id="chkISSUER"
                        defaultChecked={issuer}
                        onChange={(evnt) => (handleChange(index, evnt))}
                        className="inputCheckBox" /> </td>
                    <td><button className="btn btn-outline-danger" onClick={() => (deleteTableRows(index))}>x</button></td>
                </tr>
            )
        })
    );
}
export default TableRows;