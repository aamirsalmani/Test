﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
import "../currencyRegistration/currencyRegistration.css";
// Components
import SidebarMain from "../common/SidebarMain";
import ClientRegistrationMainWindow from "./ClientRegistrationMainWindow";

const ClientRegistration = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                <ClientRegistrationMainWindow />
            {/* </div> */}
        </div>
    );
};

export default ClientRegistration;
