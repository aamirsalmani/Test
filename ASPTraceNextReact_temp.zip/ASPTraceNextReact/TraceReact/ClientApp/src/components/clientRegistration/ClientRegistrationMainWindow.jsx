﻿import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import MaximusAxios from "../common/apiURL";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { Tooltip, OverlayTrigger } from "react-bootstrap";
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import $ from "jquery";
import "jquery/dist/jquery.min.js";
import editRow from "../../images/common/editRow.svg";
import greencheckbtn from "../../images/common/greenCheckmark.svg";
import redCheckbtn from "../../images/common/redX.svg";

const ClientRegistrationMainWindow = () => {
  const navigate = useNavigate();

  //const Show Loader
  const [isShow, setIsLoading] = useState(false);

  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [ClientAdd, setClientAdd] = useState(null);
  const [isActive, setIsActive] = useState(true);

  const [ClientRegistrationList, setClientRegistrationList] = useState(null);

  const fetchClientGridData = () => {
    const statusValue = isActive ? 1 : 0;
    setIsLoading(true);

    MaximusAxios.get(
      `api/ClientReg/GetClientMasterList?status=${statusValue}`,
      { mode: "cors" }
    )
      .then((result) => {
        setClientRegistrationList(result.data);
       setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });
  };

  const handlestatusChange = (status) => {
    setIsActive(status);
  };

  useEffect(() => {
    fetchClientGridData();
  }, [ClientAdd, isActive]);

  const onNewClick = () => {
    navigate("/clientDetails", { state: { clientID: 0, IsNewEntry: "Add" } });
  };

  const onEditClick = (ClientIDValue) => {
    navigate("/clientDetails", {
      state: { clientID: ClientIDValue, IsNewEntry: "Update" },
    });
  };

  const renderTooltipShow = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to edit Client details
    </Tooltip>
  );

  const renderTooltipAdd = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to edit Client details
    </Tooltip>
  );
  const renderTooltipIsActiveClients = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to show only active client details
    </Tooltip>
  );
  const renderTooltipIsNotActiveClients = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to all client details
    </Tooltip>
  );

  $(document).ready(function () {
    if (ClientRegistrationList !== null && ClientRegistrationList.length > 0) {
      $("#gvClientRegistration").DataTable();
    }
  });

  return (
    <div className="configLeft currencyContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Client Registration
        </h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Client Management</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Client Registration</p>
        </div>
      </div>
      {/* Table Content */}
      <div className="configLeftBottom">
        <div>

        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
          {/* Table */}
          {ClientRegistrationList !== null &&
          ClientRegistrationList.length > 0 ? (
            <div>
              <div className="exportButton">
                <OverlayTrigger
                  placement="top"
                  delay={{ show: 150, hide: 400 }}
                  overlay={renderTooltipAdd}
                >
                  <button
                    type="button"
                    className="iconAddButtonBox"
                    onClick={onNewClick}
                  >
                    <span className="icon-Plus">+</span>
                    <span className="ms-1 fontSize12-m colorPrimaryDefault">
                      Add New
                    </span>
                  </button>
                </OverlayTrigger>

                <OverlayTrigger
                  placement="top"
                  delay={{ show: 150, hide: 400 }}
                  overlay={
                    isActive
                      ? renderTooltipIsNotActiveClients
                      : renderTooltipIsActiveClients
                  }
                >
                  <label className="toggle-switch">
                    <input
                      type="checkbox"
                      className="toggle-input"
                      checked={isActive}
                      onChange={(e) => handlestatusChange(e.target.checked)}
                    />
                    <span className="slider round"></span>
                  </label>
                </OverlayTrigger>
                {/* <OverlayTrigger
                      placement="top"
                      delay={{ show: 150, hide: 400 }}
                      overlay={
                        isActive
                          ? renderTooltipIsNotActiveClients
                          : renderTooltipIsActiveClients
                      }
                    >
                      <label>
                        <input className="ms-1 ml-4 fontSize12-m colorPrimaryDefault"
                          type="checkbox"
                          checked={isActive}
                          onChange={(e) => handlestatusChange(e.target.checked)}
                        />
                       
                      </label>
                    </OverlayTrigger> */}
              </div>
              <div className="tableBorderBox pt-3">
                <div className="w-100 table-responsive">
                  <div className="table-responsive tableCurrencyContentBox">
                    <table
                      id="gvClientRegistration"
                      className="table table-striped table-hover table-borderless align-middle"
                      style={{ width: "100%" }}
                    >
                      <thead>
                        <tr>
                          <th scope="col">Is Active</th>
                          <th scope="col">Client Code</th>
                          <th scope="col">Client Name</th>
                          <th scope="col">Client Address</th>
                          <th scope="col">Contact No.</th>
                          <th scope="col">EmailID</th>
                          <th scope="col">Concern Person Name</th>
                          <th scope="col">Concern Person Contact No.</th>
                          <th scope="col">Concern Person EmailID</th>
                          <th scope="col">FTP UserName</th>
                          <th scope="col">FTP IP</th>
                          <th scope="col">User Limit</th>
                          <th scope="col">Report Cut-Off Time</th>
                          <th scope="col">Client Logo</th>
                          <th scope="col">Color Code</th>
                        </tr>
                      </thead>
                      <tbody>
                        {ClientRegistrationList.map((p, index) => {
                          return (
                            <tr key={index}>
                              <td>
                                {isActive ? (
                                  <button
                                    onClick={() => {
                                      handlestatusChange(true);
                                    }}
                                  >
                                    <span className="ms-1 fontSize12-m colorPrimaryDefault">
                                      <img
                                        src={greencheckbtn}
                                        style={{ width: "1rem" }}
                                        alt="status"
                                        title="status"
                                        className="ms-1 fontSize12-m"
                                      />
                                    </span>
                                  </button>


                                  
                                ) : (
                                  <button
                                    onClick={() => {
                                      handlestatusChange(false);
                                    }}
                                  >
                                    <span className="ms-1 fontSize12-m colorPrimaryDefault">
                                      <img
                                        src={redCheckbtn}
                                        style={{ width: "1rem" }}
                                        alt="status"
                                        title="status"
                                        className="ms-1 fontSize12-m"
                                      />
                                    </span>
                                  </button>
                                )}
                              </td>
                              <td>
                                <OverlayTrigger
                                  placement="top"
                                  delay={{ show: 250, hide: 400 }}
                                  overlay={renderTooltipShow}
                                >
                                  <button
                                    className="editBox"
                                    onClick={() => onEditClick(p.clientID)}
                                  >
                                    <img
                                      src={editRow}
                                      alt="Edit"
                                      title="Edit"
                                    />
                                    {p.clientCode}
                                  </button>
                                </OverlayTrigger>
                              </td>
                              <td>{p.clientName}</td>
                              <td>
                                <p className="tableTextInner">{p.address}</p>
                              </td>
                              <td>{p.contactNo}</td>
                              <td>
                                <p className="tableTextInner">{p.emailID}</p>
                              </td>
                              <td>{p.concernPerson}</td>
                              <td>{p.cpContactNo}</td>
                              <td>{p.cpEmailID}</td>
                              <td>{p.ftpUserName}</td>
                              <td>{p.ftP_IP}</td>
                              <td>{p.userLimit}</td>
                              <td>{p.reportCutoffTime}</td>
                              <td>{p.clientLogo}</td>
                              <td>{p.colorcode}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="tableBorderBox pt-3">
              <div className="addButton">
                <button
                  className="btn p-0 d-flex justify-content-center align-items-center"
                  type="button"
                  onClick={onNewClick}
                  id="addButtonCurrency"
                >
                  <span className="icon-Plus">+</span>
                  <span className="ms-1 fontSize12-m colorPrimaryDefault">
                    Add New
                  </span>
                </button>
              </div>
              <div className="w-100 table-responsive">
                <div className="table-responsive tableContentBox">
                  <table
                    className="table table-striped table-hover table-borderless align-middle"
                    style={{ width: "100%" }}
                  >
                    <thead>
                      <tr style={{ border: "1px dashed black !important" }}>
                        <th scope="col">Client Code</th>
                        <th scope="col">Client Name</th>
                        <th scope="col">Client Address</th>
                        <th scope="col">Contact No.</th>
                        <th scope="col">Email ID</th>
                        <th scope="col">Concern Person Name</th>
                        <th scope="col">Concern Person Contact No.</th>
                        <th scope="col">Concern Person EmailID</th>
                        <th scope="col">FTP UserName</th>
                        <th scope="col">FTP IP</th>
                        <th scope="col">Terminal Count</th>
                        <th scope="col">User Limit</th>
                        <th scope="col">Report Cut-Off Time</th>
                        <th scope="col">Client Logo</th>
                        <th scope="col">Color Code</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td
                          colSpan="15"
                          style={{
                            textAlign: "left",
                            backgroundColor:
                              "var(--table-hover-color) !important",
                            paddingTop: "10px",
                          }}
                        >
                          {" "}
                          No Records Found <hr />{" "}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
</>
            )}

        </div>
      </div>

      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default ClientRegistrationMainWindow;
