import React from "react";

const FooterPage = () => {
  const currentYear = new Date().getFullYear();
  return (
    <div className="container-fluid d-flex justify-content-center align-items-center footerBox">
      <p className="fontSize12">
        © Maximus Infoware (India) Private Limited {currentYear}
      </p>
    </div>
  );
};

export default FooterPage;
