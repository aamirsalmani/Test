import React, { useState, useEffect, useCallback } from "react";
import { useSelector, useDispatch } from "react-redux";
import Select from "react-select";
import MaximusAxios from "./apiURL";
import Notifications from "./Notifications/Notifications";
import { selectNotifications } from "../../constants/reducers/NotificationsReducer";

import {
  OverlayTrigger,
  Tooltip,
  Popover,
  Button,
  Modal,
  Offcanvas,
} from "react-bootstrap";

import { useNavigate } from "react-router-dom";

// Components
import SideBar from "./SideBar";
import { changeThemes } from "../../constants/actions/themeChangeAction";
import AuthVerify from "../../pages/login/common/AuthVerify";
import { logout } from "../../pages/login/actions/auth";

// Images
import LogoRight from "../../images/common/logo.svg";
import LogoDarkRight from "../../images/common/logoDark.svg";
import axios from "axios";

const options = [
  { value: "chocolate", label: "Chocolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" },
];


const TimeBar = () => {
  const currentUser = useSelector((state) => state.authReducer);
  //Timer

  const parseJwt = (token) => {
    try {
      return JSON.parse(atob(token.split(".")[1]));
    } catch (e) {
      return null;
    }
  };

  const calculateTimeLeft = () => {
    let timeLeft = {};

    if (currentUser !== null && currentUser.user !== null) {
      const decodedJwt = parseJwt(currentUser.user.accessToken);

      const difference = decodedJwt.exp * 1000 - Date.now();

      if (difference > 0) {
        timeLeft = {
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        };
      } else {
        timeLeft = {
          minutes: 0,
          seconds: 0,
        };
      }
    }

    return timeLeft;
  };

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    setTimeout(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
  });

  return (
    <p className="fontSize14">
      Session Time:{" "}
      {timeLeft !== null ? (
        <span className="fontSize14-sb">
          {timeLeft.minutes}:
          {timeLeft.seconds < 10 ? "0" + timeLeft.seconds : timeLeft.seconds}
        </span>
      ) : (
        <span>Time's up!</span>
      )}
    </p>
  );
};

const Header = () => {
  const idleTimeout = 30 * 60 * 1000; // 30 minutes
  const [lastActive, setLastActive] = useState(Date.now());
  let navigate = useNavigate();

  // Set up event listeners for user activity
  useEffect(() => {
    window.addEventListener("mousemove", resetIdleTimer);
    window.addEventListener("keypress", resetIdleTimer);

    const interval = setInterval(checkIdleTimeout, 10000); // Check every 10 seconds

    return () => {
      window.removeEventListener("mousemove", resetIdleTimer);
      window.removeEventListener("keypress", resetIdleTimer);
      clearInterval(interval);
    };
  }, [lastActive]);

  // Reset the idle timer whenever the user interacts with the app
  const resetIdleTimer = () => {
    setLastActive(Date.now());
  };

  // Check for idle timeout or refresh token expiration
  const checkIdleTimeout = () => {
    const currentTime = Date.now();
    const timeSinceLastActive = currentTime - lastActive;

    // If idle for more than the idle timeout period, invalidate the refresh token
    if (timeSinceLastActive > idleTimeout) {
      localStorage.removeItem("user");
      alert("Session expired due to inactivity. Please log in again.");
      navigate("/Login", { replace: true });
    }
  };

  return (
    <HeaderBase>
      <TimeBar />
    </HeaderBase>
  );
};

const HeaderBase = ({ children }) => {
  // Select Menu
  const [selectedOption, setSelectedOption] = useState(null);
  const [logoLeft, setLogoLeft] = useState("/Upload/ClientLogo/001.png");
  const [logoRight, setLogoRight] = useState(LogoRight);
  const notifications = useSelector(selectNotifications);
  const [pngUrl, setPngUrl] = useState("");

  let navigate = useNavigate();

  const dispatch = useDispatch();

  const currentUser = useSelector((state) => state.authReducer);

  const logOut = useCallback(() => {
    dispatch(logout(currentUser));
  }, [dispatch]);

  // Left Tooltip
  const renderTooltip = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Version 6.0.0
    </Tooltip>
  );

  // SideBar Menu
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // Change Theme Modals
  const [siteConfiguration, setSiteConfiguration] = useState(false);
  const [openDefaultModal, setOpenDefaultModal] = useState(false);
  const [openLightModal, setOpenLightModal] = useState(false);
  const [openDarkModal, setOpenDarkModal] = useState(false);
  const [openEsafModal, setOpenEsafModal] = useState(false);

  // Change Logo
  const changeTheme = useSelector((state) => {
    return state.themeChangeReducer;
  });

  useEffect(() => {
    if (
      currentUser !== null &&
      currentUser.user !== null &&
      currentUser.user !== undefined
    ) {
      const fetchPng = async () => {
        try {
          const response = await MaximusAxios.get(
            "api/png?ImageFileName=" + currentUser.user.clientLogo,
            {
              responseType: "blob",
            }
          );
          const objectUrl = URL.createObjectURL(response.data);
          setPngUrl(objectUrl);
        } catch (error) {
          console.error("Error fetching PNG:", error);
        }
      };

      fetchPng();

      return () => {
        // Clean up
        if (pngUrl) {
          URL.revokeObjectURL(pngUrl);
        }
      };
    } else {
      window.location.reload();
      navigate("/Login");
    }
  }, []);

  useEffect(() => {
    if (changeTheme.theme === "default") {
      setLogoRight(LogoRight);
    } else if (changeTheme.theme === "light") {
      setLogoRight(LogoRight);
    } else if (changeTheme.theme === "dark") {
      setLogoRight(LogoDarkRight);
    } else if (changeTheme.theme === "esaf") {
      setLogoRight(LogoRight);
    }
  }, [changeTheme]);

  const handleThemeChange = async (userName, theme) => {
    try {
      const response = await axios.post(
        "/api/Login/AddOrUpdateTheme",
        {
          UserName: userName,
          Theme: theme,
        },
        { withCredentials: true }
      );

      if (response.status === 200) {
        let userObject = JSON.parse(localStorage.getItem("user"));
        if (userObject) {
          userObject.theme = response.data.theme;
          localStorage.setItem("user", JSON.stringify(userObject));
        } else {
          console.error("User object not found in localStorage");
        }
      }
    } catch (error) {
      console.error("Error updating theme:", error);
      alert("An error occurred while updating the theme.");
    }
  };

  // Change Theme
  const userDetails = JSON.parse(localStorage.getItem("user"));
  const getTheme = userDetails ? userDetails.theme : "default";

  //const dispatch = useDispatch();
  const changeThemeDefault = () => {
    dispatch(changeThemes("default"));
    handleThemeChange(userDetails.username, "default");
    // console.log(userDetails);
  };
  const changeThemeLight = () => {
    dispatch(changeThemes("light"));
    handleThemeChange(userDetails.username, "light");
  };
  const changeThemeDark = () => {
    dispatch(changeThemes("dark"));
    handleThemeChange(userDetails.username, "dark");
  };
  const changeThemeEsaf = () => {
    dispatch(changeThemes("esaf"));
    handleThemeChange(userDetails.username, "esaf");
  };
  const logoutClick = () => {
    dispatch(logout(currentUser));
    navigate("/Login", { replace: true });
  };


  const ChangePasswordClick = () => {
    navigate("/user-management/change-password", { replace: true });
  };

  // Notifications Popover
  const NotificationPopover = (
    <Popover
      id="popover-basic"
      className="headerSettingsPopover popover-expand"
    >
      <Popover.Body>
        <div style={{ minWidth: "350px" }}>
          {<Notifications />}
        </div>
      </Popover.Body>
    </Popover>
  );

  // Settings Popover
  const popover = (
    <Popover id="popover-basic" className="headerSettingsPopover">
      <Popover.Body>
        <ul>
          <li className={changeTheme.theme === "default" ? "active" : ""}>
            <button
              className="fontSize14"
              onClick={() => {
                setOpenDefaultModal(!openDefaultModal);
                document.body.click();
              }}
            >
              Default Theme
            </button>
          </li>
          <li className={changeTheme.theme === "light" ? "active" : ""}>
            <button
              className="fontSize14"
              onClick={() => {
                setOpenLightModal(!openLightModal);
                document.body.click();
              }}
            >
              Light Blue Theme
            </button>
          </li>
          <li className={changeTheme.theme === "dark" ? "active" : ""}>
            <button
              className="fontSize14"
              style={{ border: "none" }}
              onClick={() => {
                setOpenDarkModal(!openDarkModal);
                document.body.click();
              }}
            >
              Dark Theme
            </button>
          </li>
          <li className={changeTheme.theme === "esaf" ? "active" : ""}>
            <button
              className="fontSize14"
              onClick={() => {
                setOpenEsafModal(!openEsafModal);
                document.body.click();
              }}
            >
              ESAF Theme
            </button>
          </li>
        </ul>
      </Popover.Body>
    </Popover>
  );

  const popoverLogout = (
    <Popover id="popover-basic" className="headerSettingsPopover">
      <Popover.Body>
        <ul>
          <li>
            <button
              className="fontSize14"
              onClick={() => {
                logoutClick();
                document.body.click();
              }}
            >
              <span className="icon-exit"></span>&nbsp;Logout
            </button>
          </li>
          <li>
            <button
              className="fontSize14"
              onClick={() => {
                ChangePasswordClick();
                document.body.click();
              }}
            >
              <span className="icon-key"></span>&nbsp;Change Password
            </button>
          </li>
        </ul>
      </Popover.Body>
    </Popover>
  );



  return (
    <div className="headerBox w-100 d-flex align-items-center">
      {/* Header Left */}
      <div className="headerLeft d-flex justify-content-between align-items-center">
        <div className="d-flex align-items-center">
          <button className="headerHamburger" onClick={handleShow}>
            <span className="icon-Hamburger-Menu"></span>
          </button>
          <OverlayTrigger
            placement="bottom"
            delay={{ show: 250, hide: 400 }}
            overlay={renderTooltip}
          >
            <img src={pngUrl} alt="Logo" width="122px" height="32px" />
          </OverlayTrigger>
        </div>
        {children}

        <Offcanvas show={show} onHide={handleClose} className="headerSideMenu">
          <Offcanvas.Body>
            <SideBar buttonCollapse={handleClose} />
          </Offcanvas.Body>
        </Offcanvas>
      </div>


      {/* Header Right */}
      <div className="headerRight d-flex justify-content-end align-items-center">
        <div className="d-flex align-items-center">
          {/* Settings */}
          <OverlayTrigger
            trigger="click"
            placement="bottom"
            overlay={popover}
            rootClose={true}
          >
            <button type="button" className="me-3">
              <span className="icon-ant-design_setting-outlined"></span>
            </button>
          </OverlayTrigger>

          {/* Notifications  */}
          <OverlayTrigger
            trigger="click"
            placement="bottom"
            overlay={NotificationPopover}
            rootClose={true}
          >
            <button type="button" className="position-relative me-3">
              <span className="icon-ion_notifications-outline"></span>
              <span className="position-absolute top-0 start-100 translate-middle notificationCount">
                {notifications !== undefined && notifications !== null
                  ? notifications.filter((item) => item.unread)?.length
                  : 0}
                <span className="visually-hidden">unread messages</span>
              </span>
            </button>
          </OverlayTrigger>

          <OverlayTrigger
            trigger="click"
            placement="bottom"
            overlay={popoverLogout}
            rootClose={true}
          >
            <div className="d-flex align-items-center">
              {/* People */}
              <span className="icon-fluent_person-16-regular"></span>
              {currentUser.user && (
                <div className="headerMyAccount">
                  <p className="fontSize14-m colorPrimaryDefault">
                    {currentUser.user.firstName}
                  </p>
                  <p className="text-uppercase fontSize10-m">
                    {currentUser.user.role}
                  </p>
                </div>
              )}
            </div>
          </OverlayTrigger>


        </div>

        <img src={logoRight} alt="Logo Right" className="ms-4" />

        {/* Site Configuration Modal */}
        {siteConfiguration && (
          <Modal
            show={siteConfiguration}
            onHide={() => setSiteConfiguration(!siteConfiguration)}
            centered
            className="defaultThemeModal mobile-defaultThemeModal centeredModal siteConfigurationModal siteConfigurationMobileModal"
          >
            <Modal.Header closeButton>
              <Modal.Title className="fontSize16-sm letterSpacing-2">
                Site Configuration
              </Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div className="clientNameSelect">
                <label htmlFor="siteConfiguration">Select Startup Page</label>
                <Select
                  defaultValue={selectedOption}
                  onChange={setSelectedOption}
                  options={options}
                  id="siteConfiguration"
                />
              </div>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="primary btnPrimary">Submit</Button>
            </Modal.Footer>
          </Modal>
        )}

        {/* Default Theme Modal */}
        {openDefaultModal && (
          <Modal
            show={openDefaultModal}
            onHide={() => setOpenDefaultModal(!openDefaultModal)}
            centered
            className="defaultThemeModal mobile-defaultThemeModal centeredModal"
          >
            <Modal.Header closeButton>
              <Modal.Title className="fontSize16-sm letterSpacing-2">
                Apply Theme
              </Modal.Title>
            </Modal.Header>
            <Modal.Body className="text-center">
              <p className="fontSize14 letterSpacing-2 text-center">
                Are you sure to change the your theme to Default Theme?
              </p>
            </Modal.Body>
            <Modal.Footer>
              <Button
                variant="secondary btnPrimaryOutline"
                onClick={() => setOpenDefaultModal(!openDefaultModal)}
              >
                Cancel
              </Button>
              <Button
                variant="primary btnPrimary"
                onClick={() => {
                  changeThemeDefault();
                  setOpenDefaultModal(!openDefaultModal);
                }}
              >
                Apply Theme
              </Button>
            </Modal.Footer>
          </Modal>
        )}

        {/* Light Theme Modal */}
        {openLightModal && (
          <Modal
            show={openLightModal}
            onHide={() => setOpenLightModal(!openLightModal)}
            centered
            className="defaultThemeModal mobile-defaultThemeModal centeredModal"
          >
            <Modal.Header closeButton>
              <Modal.Title className="fontSize16-sm letterSpacing-2">
                Apply Theme
              </Modal.Title>
            </Modal.Header>
            <Modal.Body className="text-center">
              <p className="fontSize14 letterSpacing-2 text-center">
                Are you sure to change the your theme to Light Theme?
              </p>
            </Modal.Body>
            <Modal.Footer>
              <Button
                variant="secondary btnPrimaryOutline"
                onClick={() => setOpenLightModal(!openLightModal)}
              >
                Cancel
              </Button>
              <Button
                variant="primary btnPrimary"
                onClick={() => {
                  changeThemeLight();
                  setOpenLightModal(!openLightModal);
                }}
              >
                Apply Theme
              </Button>
            </Modal.Footer>
          </Modal>
        )}

        {/* Dark Theme Modal */}
        {openDarkModal && (
          <Modal
            show={openDarkModal}
            onHide={() => setOpenDarkModal(!openDarkModal)}
            className="defaultThemeModal mobile-defaultThemeModal centeredModal"
            centered
          >
            <Modal.Header closeButton>
              <Modal.Title className="fontSize16-sm letterSpacing-2">
                Apply Theme
              </Modal.Title>
            </Modal.Header>
            <Modal.Body className="text-center">
              <p className="fontSize14 letterSpacing-2 text-center">
                Are you sure to change the your theme to Dark Theme?
              </p>
            </Modal.Body>
            <Modal.Footer>
              <Button
                variant="secondary btnPrimaryOutline"
                onClick={() => setOpenDarkModal(!openDarkModal)}
              >
                Cancel
              </Button>
              <Button
                variant="primary btnPrimary"
                onClick={() => {
                  changeThemeDark();
                  setOpenDarkModal(!openDarkModal);
                }}
              >
                Apply Theme
              </Button>
            </Modal.Footer>
          </Modal>
        )}

        {/* Esaf Theme Modal */}
        {openEsafModal && (
          <Modal
            show={openEsafModal}
            onHide={() => setOpenEsafModal(!openEsafModal)}
            className="defaultThemeModal mobile-defaultThemeModal centeredModal"
            centered
          >
            <Modal.Header closeButton>
              <Modal.Title className="fontSize16-sm letterSpacing-2">
                Apply Theme
              </Modal.Title>
            </Modal.Header>
            <Modal.Body className="text-center">
              <p className="fontSize14 letterSpacing-2 text-center">
                Are you sure to change the your theme to ESAF Light Theme?
              </p>
            </Modal.Body>
            <Modal.Footer>
              <Button
                variant="secondary btnPrimaryOutline"
                onClick={() => setOpenEsafModal(!openEsafModal)}
              >
                Cancel
              </Button>
              <Button
                variant="primary btnPrimary"
                onClick={() => {
                  changeThemeEsaf();
                  setOpenEsafModal(!openEsafModal);
                }}
              >
                Apply Theme
              </Button>
            </Modal.Footer>
          </Modal>
        )}
      </div>
    </div>
  );
};

export default Header;
