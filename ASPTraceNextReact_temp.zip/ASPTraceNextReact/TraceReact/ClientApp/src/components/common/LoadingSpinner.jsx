﻿import React from "react";
import "./spinner.css";
import { Modal } from "react-bootstrap";

export default function LoadingSpinner(props) {  
    return (
        <Modal id="LoadingSpinnerModal" show={props.isShow} centered >
            <Modal.Body>
                <div className="spinner-container">
                    <div className="loading-spinner">
                    </div>
                </div>
            </Modal.Body>
        </Modal>
    );
}