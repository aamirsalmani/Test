﻿import React from "react";
import { Modal } from "react-bootstrap";


export default function MessageBox(props) {
    const { alertJson } = props;
    const alertBody = alertJson.alertMessage.split('\n'); ;
    const handleClose = () => { props.setShowMessageBox({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' }) };

    return (
        
        <Modal show={alertJson.isShow} centered className="centeredModal alertModal msgModal"  onHide={handleClose}>
            <Modal.Header closeButton >
                <Modal.Title className="fontSize16-sm letterSpacing-2">
                    {alertJson.alertTitle}
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                {
                    
                    alertBody.map((msg, index) => {
                        return <p className="fontSize16 letterSpacing-2" key={index}>
                            {msg} 
                        </p>
                       
                    })
                    
                    }
            </Modal.Body>
        </Modal>
    );
}