import React, { Fragment } from 'react';
import './NotificationMessage.css'; // CSS file for styling 
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setNotifications } from '../../../constants/reducers/NotificationsReducer';
import MaximusAxios from "../../common/apiURL";
import authHeader from "../../../pages/login/services/auth-header";

const postNotificationFlag = async (Id, type) => {
    try {
        return await MaximusAxios.post(`api/Notifications/MarkNotification?notificationId=${Id}&type=${type}`, { mode: 'cors' });
    } catch (error) {
        //console.error("Error fetching notifications", error);
        return null;
    }
};


const fetchNotifications = async () => {
    try {
        return await MaximusAxios.get("api/Notifications/GetNotifications", { mode: "cors" });
    } catch (error) {
        //console.error("Error fetching notifications", error);
    }
};

const NotificationMessage = ({ notifications }) => {
    return (
        <div className="notification-list">
            {notifications.map((notification) => (
                <div key={notification.ID} className={`notifications-bg ${notification.Unread ? 'unread' : 'read'}`}>
                    <p>{notification.Message}</p>
                    {notification.Path && (
                        <a href={notification.Path} className="notification-link">
                            View Details
                        </a>
                    )}
                </div>
            ))}
        </div>
    );
};
export const NotificationPanel = ({ notification, IsToast }) => {
    const dispatch = useDispatch();
    const nav = useNavigate();

    const postNotificationRead = async (event, notification, type) => {
        event.preventDefault();
        try {

            const flag = await postNotificationFlag(notification.id, type);
            const response = await fetchNotifications();

            if (response.data !== null) {
                dispatch(setNotifications(response.data));
            }
            nav(notification.path);

        } catch (error) {
            console.error("Error fetching notifications", error);
            return null;
        }
    };

    return (
        <div key={notification.id} className={`${IsToast ? '' : 'notifications-bg'} ${notification.unread ? 'unread' : 'read'}`}>
            <div className="notification-card" onClick={(event) => (postNotificationRead(event, notification, 2))}>
                {IsToast === true ?
                    <></> :
                    <div className="notification-avatar" >
                        <span className={`${notification.iconClass}`} style={{ fontSize: '2rem' }} ></span>
                    </div>
                }
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'flex-start', flexDirection: 'column', width: '100%' }}>
                    <div className="notification-header">
                        <div className="notification-info">
                            <p>{notification.notificationType}</p>
                        </div>
                        {IsToast === true ?
                            <></> :
                            <div className="notification-options">
                                <p className="notification-time">{notification.Time}</p>

                            </div>
                        }
                    </div>
                    <div className="notification-body">
                        <p >{notification.message}</p>
                        {IsToast === true ?
                            <></> :
                            <button ><h6 >...</h6></button>
                        }
                    </div>

                </div>
            </div>
        </div>
    );
}
const NotificationMessageModern = ({ notifications }) => {
    return (
        <>
            {notifications.map((notification) => (
                <Fragment key={notification.id} >
                    <NotificationPanel notification={notification} />
                </Fragment>
            ))}
        </>


    );
};

export default NotificationMessageModern;
