import { useEffect, useState } from 'react';
import './Notification.css';
import NotificationMessage from './NotificationMessage';
import { selectNotifications, setNotifications } from '../../../constants/reducers/NotificationsReducer';
import { useDispatch, useSelector } from 'react-redux';

import btnAllRead from '../../../images/common/check-read.svg'
import MaximusAxios from "../../common/apiURL";



const Notifications = () => {
    const [notificationState, setNotificationState] = useState('Unread');
    const notifications = useSelector(selectNotifications);
    const dispatch = useDispatch();

    useEffect(() => {

        (async () => {
            const response = await fetchNotifications();
            //console.log(response.data);
            if (response.data !== null) {
                dispatch(setNotifications(response.data))
            }
        }
        )()
    }, [])

    const MarkAllRead = async () => {
        try {
            const response = await MaximusAxios.post(`api/Notifications/MarkNotification?notificationId=${-1}&type=${-1}`, { mode: 'cors' });
            if (response.data !== null) {
                const response = await fetchNotifications();
                if (response.data !== null) {
                    dispatch(setNotifications(response.data))
                }
            }
            return response;

        } catch (error) {
            //console.error("Error fetching notifications", error);
            return null;
        }
    }

    const fetchNotifications = async () => {
        try {
            return await MaximusAxios.get("api/Notifications/GetNotifications");
        } catch (error) {
            //console.error("Error fetching notifications", error);
        }
    };


    const NotificationsFilter = (data, filter) => {
        switch (filter) {
            case 'All': return data;
            case 'Unread': return data.filter((item) => item.unread === 1);
            case 'Read': return data.filter((item) => item.unread === 0);
            default: return data;
        }
    }

    if (notifications === undefined || notifications === null) {
        return (<></>)
    }

    return (
        <div id="ss-notification-container" className="notification-container">
            <div >
                <div className="header">
                    <div className="header-left">
                        <p className="header-text">Notifications</p>
                        <div className="menu-icon" style={{ cursor: 'pointer' }}>
                            {/* <svg xmlns="http://www.w3.org/2000/svg" width="14" height="10" viewBox="0 0 18 12">
                  <path stroke="#64748B" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.667" d="M4 6h10M1.5 1h15m-10 10h5"></path>
                </svg> */}
                        </div>
                    </div>
                    <div className="header-right">
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }} onClick={() => { MarkAllRead() }}>
                            <a target="_blank" style={{ marginLeft: '6px', cursor: 'pointer' }}>
                                <img src={btnAllRead} style={{ width: '20px' }} />
                            </a>
                            <p className="mark-all-read">Mark all as read</p>
                        </div>
                    </div>
                </div>

                <div className="tab-container">
                    <div className={`tab ${notificationState === 'Unread' ? 'active' : ''}`} onClick={() => (setNotificationState('Unread'))}>Unread</div>
                    <div className={`tab ${notificationState === 'Read' ? 'active' : ''}`} onClick={() => (setNotificationState('Read'))}>Read</div>
                    <div className={`tab ${notificationState === 'All' ? 'active' : ''}`} onClick={() => (setNotificationState('All'))}>All</div>
                </div>

                <div className="notification-list">{
                    NotificationsFilter(notifications, notificationState).length === 0 ?
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '10px' }}>
                            <div className='Notification-messagebox'>
                                <svg xmlns="http://www.w3.org/2000/svg" width="185" height="114" fill="none">
                                    <ellipse cx="92.32" cy="56.616" fill="#9F9F9F" fillOpacity="0.11" rx="60.32" ry="56.616"></ellipse>
                                    <rect width="115.826" height="40.217" x="69.174" y="17.469" fill="#9F9F9F" rx="12.87"></rect>
                                    <rect width="33.783" height="5.63" x="123.065" y="29.533" fill="#D9D9D9" rx="2.815"></rect>
                                    <rect width="59.522" height="5.63" x="95.717" y="39.185" fill="#D9D9D9" rx="2.815"></rect>
                                    <ellipse cx="170.924" cy="37.577" fill="#D9D9D9" rx="8.446" ry="8.043"></ellipse>
                                    <rect width="120.652" height="40.217" y="51.25" fill="#D9E9FF" rx="12.87"></rect>
                                    <rect width="33.783" height="5.63" x="30.565" y="63.315" fill="#93AFD6" rx="2.815"></rect>
                                    <rect width="59.522" height="5.63" x="30.565" y="72.967" fill="#93AFD6" rx="2.815"></rect>
                                    <ellipse cx="17.294" cy="71.358" fill="#93AFD6" rx="8.446" ry="8.043"></ellipse>
                                </svg>
                                <p className="no-notifications-text">No notifications yet</p>
                                <p className="subtext">We'll let you know when we've got something new for you.</p>

                            </div>
                        </div>
                        :
                        (<NotificationMessage notifications={NotificationsFilter(notifications, notificationState)} />)

                }

                </div>
            </div>
        </div>
    );
};


export default Notifications;