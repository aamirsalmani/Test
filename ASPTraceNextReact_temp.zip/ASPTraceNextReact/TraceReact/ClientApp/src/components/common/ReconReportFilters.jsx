import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from "react-select/async";
import DatePicker from "react-datepicker";
import MaximusAxios from "./apiURL";
import { useSelector } from "react-redux";

import { getYear, getMonth } from "date-fns";
import { years, months } from "./Utils";

const ReconReportFilters = ({
    updateReportFilter,
    onSubmit,
    ExportToCsvKS,
    ExportToExcelKS,
}) => {
    const currentUser = useSelector((state) => state.authReducer);

    const [selectedClientValue, setSelectedClientValue] = useState(null);

    const [inputValue, setValue] = useState("0");

    const [optionsChannelType, setOptionsChannelTypeValue] = useState([
        { channelID: "0", channelName: "--Select--" },
    ]);

    const [selectedChannelValue, setSelectedChannelValue] = useState(null);

    const [optionsModeType, setOptionsModeTypeValue] = useState([
        { modeID: "0", modeName: "All" },
    ]);

    const [selectedModeValue, setSelectedModeValue] = useState(null);

    const [optionsTerminalType, setOptionsTerminalValue] = useState([
        { ID: "0", TERMINALID: "All" },
    ]);

    const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

    const [selectedTxnTypeValue, setSelectedTxnTypeValue] = useState(null);

    const [isShowTerminal, setIsShowTerminal] = useState(false);

    const [isShowTxnType, setIsShowTxnType] = useState(false);

    const [selectedReportTypeValue, setSelectedReportTypeValue] = useState(null);

    // handle input change event
    const handleInputChange = (value) => {
        setValue(value);
    };

    const fetchClientData = (inputValue) => {
        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get(
            "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
            { mode: "cors" }
        )
            .then((result) => {
                if (inputValue.length === 0) {
                    return result.data;
                } else {
                    return result.data.filter((d) =>
                        d.clientName.toLowerCase().includes(inputValue.toLowerCase())
                    );
                }
            })
            .catch(function (error) {
                console.log(error.response);
            });
    };

    const optionsTxnType = [
        { value: "0", label: "All" },
        { value: "1", label: "Withdrawal" },
        { value: "2", label: "Deposit" },
    ];

    const optionsReportType = [
        { value: "Unmatched", label: "Unmatched Transactions" },
        { value: "Matched", label: "Matched Transactions" },
        { value: "Unsuccessful", label: "Unsuccessful Transactions" },
        { value: "Reversal", label: "Reversal Transactions" },
        { value: "Duplicate", label: "Duplicate Transactions" },
    ];
    // handle selection

    const handleOptionsChannelType = (value) => {
        setOptionsChannelTypeValue(value);
    };

    const handleOptionsModeType = (value) => {
        setOptionsModeTypeValue(value);
    };

    const handleOptionsTerminalType = (value) => {
        setOptionsTerminalValue(value);
    };

    const handleClientChange = (value) => {
        setSelectedChannelValue(null);
        setSelectedModeValue(null);
        setSelectedTerminalValue(null);
        setSelectedClientValue(value);
        updateReportFilter("ClientName", value.clientName);
        updateReportFilter("ClientId", value.clientID);
        updateReportFilter("ChannelId", null);
        updateReportFilter("ChannelValue", null);
        updateReportFilter("ModeId", null);
        updateReportFilter("ModeValue", null);
        updateReportFilter("TerminalId", null);
        updateReportFilter("TrnType", null);
        updateReportFilter("ReportType", "Unmatched");
        setSelectedReportTypeValue({ value: "Unmatched", label: "Unmatched Transactions" });

        if (value.clientID !== "0") {
            return MaximusAxios.get(
                "api/Common/GetChannelOptionList?ClientId=" +
                value.clientID +
                "&UserID=" +
                currentUser.user.username,
                { mode: "cors" }
            ).then((result) => {
                handleOptionsChannelType(result.data);
            });
        }
    };

    // handle selection
    const handleChannelChange = (value) => {
        setSelectedModeValue(null);
        setSelectedTerminalValue(null);
        setSelectedChannelValue(value);
        updateReportFilter("ChannelId", value.value);
        updateReportFilter("ChannelValue", value.label);
        updateReportFilter("ModeId", null);
        updateReportFilter("ModeValue", null);
        updateReportFilter("TerminalId", null);
        updateReportFilter("TrnType", null);

        if (value.value === "1") {
            setIsShowTxnType(true);
        } else {
            setIsShowTxnType(false);
        }

        if (value.value !== "0" && selectedClientValue.clientID !== "0") {
            return MaximusAxios.get(
                "api/Common/GetModeOptionList?ClientID=" +
                selectedClientValue.clientID +
                "&ChannelID=" +
                value.value +
                "&UserID=" +
                currentUser.user.username,
                { mode: "cors" }
            ).then((result) => {
                handleOptionsModeType(result.data);
            });
        }
    };

    const handleModeChange = (value) => {
        if (currentUser !== null && currentUser.user !== null) {
            setSelectedTerminalValue(null);
            setSelectedTxnTypeValue(null);
            setSelectedModeValue(value);
            updateReportFilter("ModeId", value.value);
            updateReportFilter("ModeValue", value.label);
            updateReportFilter("TerminalId", null);
            updateReportFilter("TrnType", null);

            if (value.value === "1" || value.value === "2") {
                setIsShowTerminal(true);
            } else {
                setIsShowTerminal(false);
            }

            if (
                value.value !== "0" &&
                selectedClientValue.clientID !== "0" &&
                selectedChannelValue.value
            ) {
                return MaximusAxios.get(
                    "api/Common/GetTerminalOptionList?ClientID=" +
                    selectedClientValue.clientID +
                    "&ChannelID=" +
                    selectedChannelValue.value +
                    "&UserName=" +
                    currentUser.user.username,
                    { mode: "cors" }
                ).then((result) => {
                    var resData = result.data;

                    var myObj = { ID: "0", TERMINALID: "All" };

                    resData.push(myObj);

                    handleOptionsTerminalType(resData);
                });
            }
        } else {
            alert("Session Timeout");
        }
    };

    const handleTxnTypeChange = (value) => {
        //   setSelectedTerminalValue(null);
        setSelectedTxnTypeValue(value);
        updateReportFilter("TrnType", value.label);
    };

    const handleTerminalChange = (value) => {
        setSelectedTerminalValue(value);
        updateReportFilter("TerminalId", value.value);
        setSelectedTxnTypeValue(null);
    };

    const handleReportTypeChange = (value) => {
        setSelectedReportTypeValue(value);
        updateReportFilter("ReportType", value.value);
    };

    //   Date Calendar
    const [selectedStartDate, setStartDate] = useState(new Date());
    //   Date Calendar
    const [selectedEndDate, setEndDate] = useState(new Date());

    const setStartDateValue = (value) => {
        setStartDate(value);
        setEndDate(value);
        updateReportFilter("StartDate", value);
        updateReportFilter("EndDate", value);
    };

    const setEndDateValue = (value) => {
        if (selectedStartDate === null) {
            setEndDate(null);
            alert("Please enter From date first");
        } else {
            if (selectedStartDate > value) {
                alert("To date must be greater than From date ");
                setEndDate(null);
            } else {
                setEndDate(value);
                updateReportFilter("EndDate", value);
            }
        }
    };

    const onReset = (e) => {
        e.preventDefault();
        // window.location.reload(false);
        setStartDate(null);
        setEndDate(null);
        setSelectedModeValue(null);
        setSelectedChannelValue(null);
        setSelectedClientValue(null);
        updateReportFilter(null);
        setSelectedTxnTypeValue(null);
        setIsShowTerminal(false);
        //    setUnmatchedTxnsReport(null);
        //    setFileList(null);
        //    setConfirmEntry(null);
        //    setPageNumber(null);
        //    setEJTxnList(null);
        //    setGLTxnList(null);
        //    setNWTxnList(null);
        //    setSWTxnList(null);
    };

    const handleShow = (e) => {
        onSubmit();
    };

    return (
        <div className="accordion" id="unsuccessfulFilters">
            <div className="accordion-item">
                <div
                    className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                    id="unsuccessfulFiltersHeading"
                >
                    <h6 className="fontWeight-600 colorBlack">Filters</h6>
                    <button
                        className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#unsuccessfulFiltersCollapse"
                        aria-expanded="true"
                        aria-controls="unsuccessfulFiltersCollapse"
                    >
                        <span className="icon-Hide"></span>
                        <span className="ms-1 fontSize12-m colorBlack">Show / Hide</span>
                    </button>
                </div>
                <div
                    id="unsuccessfulFiltersCollapse"
                    className="accordion-collapse collapse show"
                    aria-labelledby="unsuccessfulFiltersHeading"
                    data-bs-parent="#unsuccessfulFilters"
                >
                    <div className="accordion-body">
                        <div className="hrGreyLine"></div>
                        <div className="configSelectBoxTop row">
                            <div className="clientNameSelect col">
                                <label htmlFor="clientName">Client Name</label>
                                <span className="text-danger font-size13">*</span>
                                <AsyncSelect
                                    cacheOptions
                                    defaultOptions
                                    value={selectedClientValue}
                                    getOptionLabel={(e) => e.clientName}
                                    getOptionValue={(e) => e.clientID}
                                    loadOptions={fetchClientData}
                                    onInputChange={handleInputChange}
                                    onChange={handleClientChange}
                                    id="ddlClient"
                                />
                            </div>
                            <div className="clientNameSelect col">
                                <label htmlFor="ddlChannel">Channel Type</label>
                                <span className="text-danger font-size13">*</span>
                                <Select
                                    id="ddlChannel"
                                    classNamePrefix="reactSelectBox"
                                    value={selectedChannelValue}
                                    options={optionsChannelType.map((x) => ({
                                        value: x.channelID,
                                        label: x.channelName,
                                    }))}
                                    onChange={handleChannelChange}
                                />
                            </div>
                            <div className="clientNameSelect col">
                                <label htmlFor="ddlMode">Mode Type</label>
                                <span className="text-danger font-size13">*</span>
                                <Select
                                    id="ddlMode"
                                    classNamePrefix="reactSelectBox"
                                    value={selectedModeValue}
                                    options={optionsModeType.map(x => (
                                        {
                                            value: x.modeID,
                                            label: x.modeName
                                        }
                                    ))}
                                    onChange={handleModeChange}
                                />
                            </div>
                            {isShowTerminal && (
                                <div className="clientNameSelect col">
                                    <label htmlFor="logType">Terminal</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlTerminal"
                                        classNamePrefix="reactSelectBox"
                                        value={selectedTerminalValue}
                                        options={optionsTerminalType.map((x) => ({
                                            value: x.ID,
                                            label: x.TERMINALID,
                                        }))}
                                        onChange={handleTerminalChange}
                                    />
                                </div>
                            )}
                            {isShowTxnType && (
                                <div className="clientNameSelect col" id="dvTxnType">
                                    <label htmlFor="ddlTxnType">Txn Type</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        value={selectedTxnTypeValue}
                                        options={optionsTxnType}
                                        id="ddlTxnType"
                                        onChange={handleTxnTypeChange}
                                        classNamePrefix="reactSelectBox"
                                    />
                                </div>
                            )}
                            <div className="clientNameSelect col">
                                <label htmlFor="selectedStartDate">From Date</label>
                                <span className="text-danger font-size13">*</span>
                                <DatePicker
                                    renderCustomHeader={({
                                        date,
                                        changeYear,
                                        changeMonth,
                                        decreaseMonth,
                                        increaseMonth,
                                        prevMonthButtonDisabled,
                                        nextMonthButtonDisabled,
                                    }) => (
                                        <div
                                            style={{
                                                margin: 1,
                                                display: "flex",
                                                justifyContent: "center",
                                            }}
                                        >
                                            <button
                                                onClick={decreaseMonth}
                                                disabled={prevMonthButtonDisabled}
                                            >
                                                <span
                                                    className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                                                    style={{ top: -11, left: -10 }}
                                                ></span>
                                            </button>
                                            <select
                                                value={getYear(date)}
                                                onChange={({ target: { value } }) => changeYear(value)}
                                            >
                                                {years.map((option) => (
                                                    <option key={option} value={option}>
                                                        {option}
                                                    </option>
                                                ))}
                                            </select>

                                            <select
                                                value={months[getMonth(date)]}
                                                onChange={({ target: { value } }) =>
                                                    changeMonth(months.indexOf(value))
                                                }
                                            >
                                                {months.map((option) => (
                                                    <option key={option} value={option}>
                                                        {option}
                                                    </option>
                                                ))}
                                            </select>

                                            <button
                                                onClick={increaseMonth}
                                                disabled={nextMonthButtonDisabled}
                                            >
                                                <span
                                                    className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                                                    style={{ top: -11, left: 10 }}
                                                ></span>
                                            </button>
                                        </div>
                                    )}
                                    selected={selectedStartDate}
                                    dateFormat="dd/MM/yyyy"
                                    onChange={(date) => setStartDateValue(date)}
                                    className="reportDate"
                                    maxDate={new Date()}
                                />
                            </div>
                            <div className="clientNameSelect col">
                                <label htmlFor="ToDate">To Date</label>
                                <span className="text-danger font-size13">*</span>
                                <DatePicker
                                    renderCustomHeader={({
                                        date,
                                        changeYear,
                                        changeMonth,
                                        decreaseMonth,
                                        increaseMonth,
                                        prevMonthButtonDisabled,
                                        nextMonthButtonDisabled,
                                    }) => (
                                        <div
                                            style={{
                                                margin: 1,
                                                display: "flex",
                                                justifyContent: "center",
                                            }}
                                        >
                                            <button
                                                onClick={decreaseMonth}
                                                disabled={prevMonthButtonDisabled}
                                            >
                                                <span
                                                    className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                                                    style={{ top: -11, left: -10 }}
                                                ></span>
                                            </button>
                                            <select
                                                value={getYear(date)}
                                                onChange={({ target: { value } }) => changeYear(value)}
                                            >
                                                {years.map((option) => (
                                                    <option key={option} value={option}>
                                                        {option}
                                                    </option>
                                                ))}
                                            </select>

                                            <select
                                                value={months[getMonth(date)]}
                                                onChange={({ target: { value } }) =>
                                                    changeMonth(months.indexOf(value))
                                                }
                                            >
                                                {months.map((option) => (
                                                    <option key={option} value={option}>
                                                        {option}
                                                    </option>
                                                ))}
                                            </select>

                                            <button
                                                onClick={increaseMonth}
                                                disabled={nextMonthButtonDisabled}
                                            >
                                                <span
                                                    className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                                                    style={{ top: -11, left: 10 }}
                                                ></span>
                                            </button>
                                        </div>
                                    )}
                                    selected={selectedEndDate}
                                    dateFormat="dd/MM/yyyy"
                                    onChange={(date) => setEndDateValue(date)}
                                    className="reportDate"
                                    maxDate={new Date()}
                                />
                            </div>
                            <div className="clientNameSelect col">
                                <label htmlFor="ddlReportType">Report Type</label>
                                <span className="text-danger font-size13">*</span>
                                <Select
                                    value={selectedReportTypeValue}
                                    options={optionsReportType}
                                    id="ddlReportType"
                                    onChange={handleReportTypeChange}
                                    classNamePrefix="reactSelectBox"
                                />
                            </div>
                        </div>

                        <div className="text-center btnsBtm">
                            <button
                                type="button"
                                className="btnPrimaryOutline"
                                onClick={(e) => onReset(e)}
                            >
                                Reset
                            </button>
                            <button
                                type="button"
                                className="btnPrimary ms-2"
                                onClick={handleShow}
                            >
                                Show
                            </button>
                            <button
                                type="button"
                                className="btnPrimary ms-2"
                                onClick={ExportToExcelKS}
                            >
                                Export to Excel
                            </button>
                            <button
                                type="button"
                                className="btnPrimary ms-2"
                                onClick={ExportToCsvKS}
                            >
                                Export to CSV
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ReconReportFilters;
