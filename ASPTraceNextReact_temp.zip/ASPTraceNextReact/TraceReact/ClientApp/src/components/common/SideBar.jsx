import React, { useEffect, useState } from "react";
import { Link, useLocation, matchPath, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import MaximusAxios from "./apiURL";



const SideBar = (props) => {
    let path = useLocation().pathname;

    let navigate = useNavigate();

    const currentUser = useSelector((state) => state.authReducer);

    const [firstLoad, setfirstLoad] = useState(true);

    const [ParentMenuList, setParentMenuList] = useState([]);

    const [SubMenuList, setSubMenuList] = useState([]);

    useEffect(() => {
        fetchMenuList();
    }, [firstLoad]);

    const fetchMenuList = () => {
        if (!currentUser) {
            setParentMenuList([]);
        }
        else if (currentUser.user === undefined || currentUser.user === null) {
            setParentMenuList([]);
        }
        else {
MaximusAxios.get('api/Common/GetMenuList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(resultParent => {//currentUser.user.username, {  mode: 'cors' })
                if (resultParent.data !== null && resultParent.data.length > 0) {
                    //console.log(resultParent.data);
                    let filterPerentMenu = [];
                    let filterChildMenu = [];

                    for (let cntrow = 0; cntrow < resultParent.data.length; cntrow++) {
                        if (resultParent.data[cntrow].parentMenuID === '0') {
                            var arrP = { "menuName": resultParent.data[cntrow].menuName, "menuID": resultParent.data[cntrow].menuID, "filePath": resultParent.data[cntrow].filePath, "parentMenuID": resultParent.data[cntrow].parentMenuID, "sequenceNo": resultParent.data[cntrow].sequenceNo, "menuClassName": resultParent.data[cntrow].menuClassName, "hasChildMenu": resultParent.data[cntrow].hasChildMenu }
                            filterPerentMenu.push(arrP);
                        }
                        else {
                            var arrC = { "menuName": resultParent.data[cntrow].menuName, "menuID": resultParent.data[cntrow].menuID, "filePath": resultParent.data[cntrow].filePath, "parentMenuID": resultParent.data[cntrow].parentMenuID, "sequenceNo": resultParent.data[cntrow].sequenceNo, "menuClassName": resultParent.data[cntrow].menuClassName, "hasChildMenu": resultParent.data[cntrow].hasChildMenu }
                            filterChildMenu.push(arrC);
                        }
                    }
                    //console.log(filterPerentMenu);
                    //console.log(filterChildMenu);
                    setParentMenuList(filterPerentMenu);
                    setSubMenuList(filterChildMenu);
                }
            }).catch((error)=>{
                console.log(error);
            });
        }
    }


    // client-management Path
    let clientManagementPath = matchPath("/client-management/*", path);
    if (clientManagementPath) {
        clientManagementPath = clientManagementPath.pathnameBase;
    }

    // user-management Path
    let userManagementPath = matchPath("/user-management/*", path);
    if (userManagementPath) {
        userManagementPath = userManagementPath.pathnameBase;
    }

    // dailyReport Path
    let dailyReportPath = matchPath("/daily-report/*", path);
    if (dailyReportPath) {
        dailyReportPath = dailyReportPath.pathnameBase;
    }

    // misReport Path
    let misReportPath = matchPath("/mis-reports/*", path);
    if (misReportPath) {
        misReportPath = misReportPath.pathnameBase;
    }

    // auditReport Path
    let auditReportPath = matchPath("/audit-reports/*", path);
    if (auditReportPath) {
        auditReportPath = auditReportPath.pathnameBase;
    }

    // /configuration Path
    let configurationPath = matchPath("/configuration/*", path);
    if (configurationPath) {
        configurationPath = configurationPath.pathnameBase;
    }
    // cbr Path
    let cbrPath = matchPath("/cbr/*", path);
    if (cbrPath) {
        cbrPath = cbrPath.pathnameBase;
    }

    // fraudReport Path
    let fraudReportPath = matchPath("/fraud-reports/*", path);
    if (fraudReportPath) {
        fraudReportPath = fraudReportPath.pathnameBase;
    }

    // search-rrn Path
    let searchPath = matchPath("/search/*", path);
    if (searchPath) {
        searchPath = searchPath.pathnameBase;
    }

    let importlogsPath = matchPath("/import-logs/*", path);
    if (importlogsPath) {
        importlogsPath = importlogsPath.pathnameBase;
    }

    // LogReport Path
    let logReportPath = matchPath("/logger/*", path);
    if (logReportPath) {
        logReportPath = logReportPath.pathnameBase;
    }

    // dashboard Path
    let dashboardPath = matchPath("/dash-board/*", path);
    if (dashboardPath) {
        dashboardPath = dashboardPath.pathnameBase;
    }

    // dispute-management Path
    let disputePath = matchPath("/dispute-management/*", path);
    if (disputePath) {
        disputePath = disputePath.pathnameBase;
    }

    // downloadsPath Path
    let downloadsPath = matchPath("/downloads/*", path);
    if (downloadsPath) {
        downloadsPath = downloadsPath.pathnameBase;
    }

    // exception-report Path
    let exceptionPath = matchPath("/exception-report/*", path);
    if (exceptionPath) {
        exceptionPath = exceptionPath.pathnameBase;
    }


    // path redirects
    useEffect(() => {
        if (path === "/") {
            navigate("/Home");
        }
    });

    const activeLink = (arr) => {
        if (arr === path) {
            return "activeTab";
        }
        else {
            return "";
        }
    };

    const activeBtnClass = (arr) => {
        if (arr === path) {
            return "accordion-button";
        }
        else if (arr === clientManagementPath) {
            return "accordion-button";
        }
        else if (arr === userManagementPath) {
            return "accordion-button";
        }
        else if (arr === dailyReportPath) {
            return "accordion-button";
        }
        else if (arr === misReportPath) {
            return "accordion-button";
        }
        else if (arr === auditReportPath) {
            return "accordion-button";
        }
        else if (arr === configurationPath) {
            return "accordion-button";
        }
        else if (arr === cbrPath) {
            return "accordion-button";
        }
        else if (arr === fraudReportPath) {
            return "accordion-button";
        }
        else if (arr === searchPath) {
            return "accordion-button";
        }
        else if (arr === importlogsPath) {
            return "accordion-button";
        }
        else if (arr === logReportPath) {
            return "accordion-button";
        }
        else if (arr === disputePath) {
            return "accordion-button";
        }
        else if (arr === downloadsPath) {
            return "accordion-button";
        }
        else if (arr === exceptionPath) {
            return "accordion-button";
        }
        else {
            return "accordion-button collapsed";
        }
    };
    const activeAriaExpand = (arr = []) => {
        if (arr === path) {
            return "true";
        }
        else if (arr === clientManagementPath) {
            return "true";
        }
        else if (arr === userManagementPath) {
            return "true";
        }
        else if (arr === dailyReportPath) {
            return "true";
        }
        else if (arr === misReportPath) {
            return "true";
        }
        else if (arr === auditReportPath) {
            return "true";
        }
        else if (arr === configurationPath) {
            return "true";
        }
        else if (arr === cbrPath) {
            return "true";
        }
        else if (arr === fraudReportPath) {
            return "true";
        }
        else if (arr === searchPath) {
            return "true";
        }
        else if (arr === importlogsPath) {
            return "true";
        }
        else if (arr === dashboardPath) {
            return "true";
        }
        else if (arr === downloadsPath) {
            return "true";
        }
        else if (arr === disputePath) {
            return "true";
        }
        else if (arr === exceptionPath) {
            return "true";
        }
        else {
            return "false";
        }
    };
    const activeAccordionBodyClass = (arr) => {
        if (arr === path) {
            return "accordion-collapse collapse show";
        }
        else if (arr === clientManagementPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === userManagementPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === dailyReportPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === misReportPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === auditReportPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === configurationPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === cbrPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === fraudReportPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === searchPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === importlogsPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === logReportPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === dashboardPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === downloadsPath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === disputePath) {
            return "accordion-collapse collapse show";
        }
        else if (arr === exceptionPath) {
            return "accordion-collapse collapse show";
        }
        else {
            return "accordion-collapse collapse ";
        }
    };

    return (
        <div>
            {(ParentMenuList != null && ParentMenuList.length > 0) ? (
                <div className="sideBar">
                    <div className="accordion" id="accordionExample">
                        {/* Home */}
                        <div className="accordion-item">
                            <h2 className="accordion-header hideArrowIcon" id="headingHome">
                                <button className="accordion-button collapsed" type="button">
                                    <Link to="/Home" className={activeLink("/Home")}>
                                        <span className="icon-Icon-NameHome sidebarIconSize"></span>
                                        <span className="fontSize14 ms-2">Home</span>
                                    </Link>
                                </button>
                            </h2>
                        </div>

                        {
                            ParentMenuList.map((parent, x) => {
                                return (
                                    <div key={x}>
                                        {(parent.hasChildMenu === 'Yes') ? (
                                            <div className="accordion-item">
                                                <h2 className="accordion-header" id={"heading" + parent.sequenceNo}>
                                                    <button
                                                        className={activeBtnClass(parent.filePath)}
                                                        type="button"
                                                        data-bs-toggle="collapse"
                                                        data-bs-target={"#collapse" + parent.sequenceNo}
                                                        aria-expanded={activeAriaExpand(parent.filePath)}
                                                        aria-controls={"collapse" + parent.sequenceNo}
                                                    >
                                                        <span className={parent.menuClassName}></span>
                                                        <span className="fontSize14 ms-2">{parent.menuName}</span>
                                                    </button>
                                                </h2>
                                                <div
                                                    id={"collapse" + parent.sequenceNo}
                                                    className={activeAccordionBodyClass(parent.filePath)}
                                                    aria-labelledby={"heading" + parent.sequenceNo}
                                                    data-bs-parent="#accordionExample"
                                                >
                                                    <div className="accordion-body">
                                                        <ul className="subMenu">
                                                            {
                                                                SubMenuList.filter(({ parentMenuID }) => parentMenuID === parent.menuID).map((sub, y) => {
                                                                    return (
                                                                        <li key={y}>
                                                                            <Link to={sub.filePath}
                                                                                className={activeLink(
                                                                                    sub.filePath
                                                                                )}>
                                                                                <span className="subMenuLeft">
                                                                                    <span className="icon-Icon"></span>
                                                                                </span>
                                                                                <span className="subMenuRight">{sub.menuName}</span>
                                                                            </Link>
                                                                        </li>
                                                                    )
                                                                })
                                                            }
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        ) :
                                            (
                                                <div className="accordion-item">
                                                    <h2 className="accordion-header hideArrowIcon" id={"heading" + parent.sequenceNo}>
                                                        <button className="accordion-button collapsed" type="button">
                                                            <Link
                                                                to={parent.filePath}
                                                                className={activeLink(
                                                                    parent.filePath
                                                                )}>
                                                                <span className={parent.menuClassName}></span>
                                                                <span className="fontSize14 ms-2">{parent.menuName}</span>
                                                            </Link>
                                                        </button>
                                                    </h2>
                                                </div>
                                            )
                                        }
                                    </div>
                                )
                            })
                        }



                    </div>

                    <button
                        type="button"
                        className="sidebarButton d-flex justify-content-center align-items-center"
                        onClick={props.buttonCollapse}
                    >
                        <svg
                            width="14"
                            height="14"
                            viewBox="0 0 16 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path
                                d="M9.22003 12.6667C9.12043 12.667 9.02202 12.645 8.93204 12.6024C8.84205 12.5597 8.76277 12.4974 8.70003 12.42L5.48003 8.42002C5.38197 8.30073 5.32837 8.1511 5.32837 7.99669C5.32837 7.84227 5.38197 7.69264 5.48003 7.57335L8.81336 3.57335C8.92652 3.43721 9.08913 3.35159 9.26541 3.33534C9.44169 3.31909 9.61722 3.37353 9.75336 3.48669C9.8895 3.59985 9.97512 3.76245 9.99137 3.93874C10.0076 4.11502 9.95319 4.29054 9.84003 4.42669L6.86003 8.00002L9.74003 11.5734C9.82155 11.6712 9.87333 11.7904 9.88925 11.9167C9.90517 12.0431 9.88456 12.1714 9.82986 12.2864C9.77515 12.4014 9.68865 12.4984 9.58057 12.5658C9.4725 12.6332 9.34738 12.6682 9.22003 12.6667Z"
                                fill="white"
                            />
                        </svg>
                    </button>

                </div>
            ) : null}
        </div>
    );
};

export default SideBar;
