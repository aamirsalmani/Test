import React, { useEffect, useState } from "react";
import { Link, useLocation, matchPath } from "react-router-dom";
import { Popover, OverlayTrigger } from "react-bootstrap";
import { useSelector } from "react-redux";
import MaximusAxios from "./apiURL"

const SidebarSmall = (props) => {
    const path = useLocation().pathname;

    const currentUser = useSelector((state) => state.authReducer);

    const [firstLoad, setfirstLoad] = useState(true);

    const [ParentMenuList, setParentMenuList] = useState([]);

    const [SubMenuList, setSubMenuList] = useState([]);


    useEffect(() => {
        fetchMenuList();
    },
        [firstLoad]
    );

    const fetchMenuList = () => {
        if (!currentUser) {
            setParentMenuList([]);
        }
        else if (currentUser.user === undefined || currentUser.user === null) {
            setParentMenuList([]);
        }
        else {

            MaximusAxios.get('api/Common/GetMenuList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(resultParent => {
                if (resultParent.data !== null && resultParent.data.length > 0) {
                    //console.log(resultParent.data);
                    let filterPerentMenu = [];
                    let filterChildMenu = [];

                    for (let cntrow = 0; cntrow < resultParent.data.length; cntrow++) {
                        if (resultParent.data[cntrow].parentMenuID === '0') {
                            var arrP = { "menuName": resultParent.data[cntrow].menuName, "menuID": resultParent.data[cntrow].menuID, "filePath": resultParent.data[cntrow].filePath, "parentMenuID": resultParent.data[cntrow].parentMenuID, "sequenceNo": resultParent.data[cntrow].sequenceNo, "menuClassName": resultParent.data[cntrow].menuClassName, "hasChildMenu": resultParent.data[cntrow].hasChildMenu }
                            filterPerentMenu.push(arrP);
                        }
                        else {
                            var arrC = { "menuName": resultParent.data[cntrow].menuName, "menuID": resultParent.data[cntrow].menuID, "filePath": resultParent.data[cntrow].filePath, "parentMenuID": resultParent.data[cntrow].parentMenuID, "sequenceNo": resultParent.data[cntrow].sequenceNo, "menuClassName": resultParent.data[cntrow].menuClassName, "hasChildMenu": resultParent.data[cntrow].hasChildMenu }
                            filterChildMenu.push(arrC);
                        }
                    }
                    //console.log(filterPerentMenu);
                    //console.log(filterChildMenu);
                    setParentMenuList(filterPerentMenu);
                    setSubMenuList(filterChildMenu);
                }
            });
        }
    }

    // client-management Path
    let clientManagementPath = matchPath("/client-management/*", path);
    if (clientManagementPath) {
        clientManagementPath = clientManagementPath.pathnameBase;
    }
    // user-management Path
    let userManagementPath = matchPath("/user-management/*", path);
    if (userManagementPath) {
        userManagementPath = userManagementPath.pathnameBase;
    }
    // dailyReport Path
    let dailyReportPath = matchPath("/daily-report/*", path);
    if (dailyReportPath) {
        dailyReportPath = dailyReportPath.pathnameBase;
    }

    // misReport Path
    let misReportPath = matchPath("/mis-reports/*", path);
    if (misReportPath) {
        misReportPath = misReportPath.pathnameBase;
    }

    // auditReport Path
    let auditReportPath = matchPath("/audit-reports/*", path);
    if (auditReportPath) {
        auditReportPath = auditReportPath.pathnameBase;
    }

    // /configuration Path
    let configurationPath = matchPath("/configuration/*", path);
    if (configurationPath) {
        configurationPath = configurationPath.pathnameBase;
    }
    // cbr Path
    let cbrPath = matchPath("/cbr/*", path);
    if (cbrPath) {
        cbrPath = cbrPath.pathnameBase;
    }

    let importlogsPath = matchPath("/import-logs/*", path);
    if (importlogsPath) {
        importlogsPath = importlogsPath.pathnameBase;
    }

    let logReportPath = matchPath("/logger/*", path);
    if (logReportPath) {
        logReportPath = logReportPath.pathnameBase;
    }

    let dashboardPath = matchPath("/dash-board/*", path);
    if (dashboardPath) {
        dashboardPath = dashboardPath.pathnameBase;
    }

    // dispute-management Path
    let disputePath = matchPath("/dispute-management/*", path);
    if (disputePath) {
        disputePath = disputePath.pathnameBase;
    }

    // exception-report Path
    let exceptionPath = matchPath("/exception-report/*", path);
    if (exceptionPath) {
        exceptionPath = exceptionPath.pathnameBase;
    }



    const activeLink = (arr) => {
        if (arr === path) {
            return "activeTab";
        }
        else if (arr === clientManagementPath) {
            return "activeTab";
        }
        else if (arr === userManagementPath) {
            return "activeTab";
        }
        else if (arr === dailyReportPath) {
            return "activeTab";
        }
        else if (arr === misReportPath) {
            return "activeTab";
        }
        else if (arr === auditReportPath) {
            return "activeTab";
        }
        else if (arr === configurationPath) {
            return "activeTab";
        }
        else if (arr === cbrPath) {
            return "activeTab";
        }
        else if (arr === importlogsPath) {
            return "activeTab";
        }
        else if (arr === logReportPath) {
            return "activeTab";
        }
        else if (arr === dashboardPath) {
            return "activeTab";
        }
        else if (arr === disputePath) {
            return "activeTab";
        }
        else if (arr === exceptionPath) {
            return "activeTab";
        }
        else {
            return "";
        }
    };

    const homePage = (
        <Popover id="popover-basic" className="sidebarPopover">
            <Popover.Body>
                <ul className="subMenu">
                    <li className={activeLink("/Home")}>
                        <Link
                            to="/Home"
                            className={activeLink("/Home")}
                        >
                            <span className="subMenuLeft">
                                <span className="icon-Icon"></span>
                            </span>
                            <span className="subMenuRight">Home</span>
                        </Link>
                    </li>
                </ul>
            </Popover.Body>
        </Popover>
    );

    const dynamicOverlay = (MenuData) => (
        (MenuData.hasChildMenu === 'Yes') ? (
            <Popover id="popover-basic" className="sidebarPopover">
                <Popover.Body>
                    <ul className="subMenu">
                        {
                            SubMenuList.filter(({ parentMenuID }) => parentMenuID === MenuData.menuID).map((sub, y) => {
                                return (
                                    <li key={y}
                                        className={activeLink(
                                            sub.filePath
                                        )}
                                    >
                                        <Link to={sub.filePath}>
                                            <span className="subMenuLeft">
                                                <span className="icon-Icon"></span>
                                            </span>
                                            <span className="subMenuRight">{sub.menuName}</span>
                                        </Link>
                                    </li>
                                )
                            })
                        }
                    </ul>
                </Popover.Body>
            </Popover>
        ) :
            (
                <Popover id="popover-basic" className="sidebarPopover">
                    <Popover.Body>
                        <ul className="subMenu">
                            <li className={activeLink(MenuData.filePath)}>
                                <Link
                                    to={MenuData.filePath}
                                    className={activeLink(MenuData.filePath)}
                                >
                                    <span className="subMenuLeft">
                                        <span className="icon-Icon"></span>
                                    </span>
                                    <span className="subMenuRight">{MenuData.menuName}</span>
                                </Link>
                            </li>
                        </ul>
                    </Popover.Body>
                </Popover>
            )

    );



    return (
        <div className="sidebarSmall">
            {/* Home */}
            <div className="sidebarSmallImg">
                <OverlayTrigger trigger="click" placement="right" overlay={homePage} rootClose >
                    <div className={activeLink("/Home")}>
                        <span className="icon-Icon-NameHome sidebarIconSize"></span>
                    </div>
                </OverlayTrigger>
            </div>
            {
                ParentMenuList.map((parent, x) => {
                    return (
                        <div key={x}>
                            <div className="sidebarSmallImg">
                                <OverlayTrigger
                                    trigger="click"
                                    placement="right"
                                    overlay={dynamicOverlay(parent)}
                                    rootClose
                                >
                                    <div className={activeLink(parent.filePath)}>
                                        <span className={parent.menuClassName}></span>
                                    </div>
                                </OverlayTrigger>
                            </div>

                        </div>
                    )
                })
            }

            <button
                type="button"
                className="sidebarButton d-flex justify-content-center align-items-center"
                onClick={props.buttonCollapse}
            >
                <svg
                    width="14"
                    height="14"
                    viewBox="0 0 16 16"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                >
                    <path
                        d="M6.78 3.33331C6.8796 3.33297 6.978 3.35496 7.06799 3.39764C7.15797 3.44033 7.23725 3.50263 7.3 3.57998L10.52 7.57998C10.6181 7.69927 10.6717 7.8489 10.6717 8.00331C10.6717 8.15773 10.6181 8.30736 10.52 8.42665L7.18667 12.4266C7.07351 12.5628 6.9109 12.6484 6.73462 12.6647C6.55833 12.6809 6.38281 12.6265 6.24667 12.5133C6.11052 12.4002 6.02491 12.2375 6.00865 12.0613C5.9924 11.885 6.04684 11.7095 6.16 11.5733L9.14 7.99998L6.26 4.42665C6.17848 4.32879 6.12669 4.20963 6.11077 4.08326C6.09485 3.9569 6.11546 3.82861 6.17017 3.7136C6.22487 3.59858 6.31138 3.50164 6.41945 3.43424C6.52753 3.36685 6.65264 3.33182 6.78 3.33331Z"
                        fill="white"
                    />
                </svg>
            </button>

        </div>
    );
};

export default SidebarSmall;
