import React from "react";
import { Modal } from "react-bootstrap";
import { splitCamelCase } from "./Utils";

function TransactionDetails({
  EJTxnList,
  SWTxnList,
  GLTxnList,
  NWTxnList,
  ReferenceNo,
  setReferenceNo,
}) {
  return (
    <Modal
      show={ReferenceNo}
      onHide={() => setReferenceNo(!ReferenceNo)}
      centered
      className="defaultThemeModal saveFiltersModal reportTableModal"
    >
      <Modal.Header closeButton>
        <Modal.Title className="fontSize16-sm letterSpacing-2">
          Transaction ID Details
        </Modal.Title>
      </Modal.Header>
      <Modal.Body className="text-center">
        {EJTxnList && EJTxnList.length > 0 && (
          <div className="w-100 table-responsive">
            <p className="fontWeight-600 colorBlack ModalHeading">EJ Details</p>
            <table className="table table-striped table-hover table-borderless align-middle">
              <thead>
                <tr>
                  {Object.keys(EJTxnList[0]).map((Column, i) => (
                    <th scope="col" key={i}>
                      {splitCamelCase(Column)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {EJTxnList.map((Row, index) => (
                  <tr key={index}>
                    {Object.keys(EJTxnList[index]).map((Column, colIndex) => (
                      <td key={colIndex}>{Row[Column]}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="w-100 table-responsive">
          <p className="fontWeight-600 colorBlack ModalHeading">SW Details</p>
          {SWTxnList && SWTxnList.length > 0 ? (
            <table className="table table-striped table-hover table-borderless align-middle">
              <thead>
                <tr>
                  {Object.keys(SWTxnList[0]).map((Column, i) => (
                    <th scope="col" key={i}>
                      {splitCamelCase(Column)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {SWTxnList.map((Row, index) => (
                  <tr key={index}>
                    {Object.keys(SWTxnList[index]).map((Column, colIndex) => (
                      <td key={colIndex}>{Row[Column]}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="table table-striped table-hover table-borderless align-middle">
              <thead>
                <tr>
                  <th scope="col">Txn Date & Time</th>
                  <th scope="col">Reference Number</th>
                  <th scope="col">Txn Amount</th>
                  <th scope="col">Response Code</th>
                  <th scope="col">Reversal Flag</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan="5">
                    <em>No record(s) found...</em>
                  </td>
                </tr>
              </tbody>
            </table>
          )}
        </div>

        <div className="w-100 table-responsive">
          <p className="fontWeight-600 colorBlack ModalHeading">GL Details</p>
          {GLTxnList && GLTxnList.length > 0 ? (
            <table className="table table-striped table-hover table-borderless align-middle">
              <thead>
                <tr>
                  {Object.keys(GLTxnList[0]).map((Column, i) => (
                    <th scope="col" key={i}>
                      {splitCamelCase(Column)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {GLTxnList.map((Row, index) => (
                  <tr key={index}>
                    {Object.keys(GLTxnList[index]).map((Column, colIndex) => (
                      <td key={colIndex}>{Row[Column]}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="table table-striped table-hover table-borderless align-middle">
              <thead>
                <tr>
                  <th scope="col">Txn Date & Time</th>
                  <th scope="col">Reference Number</th>
                  <th scope="col">Txn Amount</th>
                  <th scope="col">Response Code</th>
                  <th scope="col">Reversal Flag</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan="5">
                    <em>No record(s) found...</em>
                  </td>
                </tr>
              </tbody>
            </table>
          )}
        </div>

        <div className="w-100 table-responsive">
          <p className="fontWeight-600 colorBlack ModalHeading">Network Details</p>
          {NWTxnList && NWTxnList.length > 0 ? (

            <table className="table table-striped table-hover table-borderless align-middle">
              <thead>
                <tr>
                  {Object.keys(NWTxnList[0]).map((Column, i) => (
                    <th scope="col" key={i}>
                      {splitCamelCase(Column)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {NWTxnList.map((Row, index) => (
                  <tr key={index}>
                    {Object.keys(NWTxnList[index]).map((Column, colIndex) => (
                      <td key={colIndex}>{Row[Column]}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>

          ) : (
            <table className="table table-striped table-hover table-borderless align-middle">
              <thead>
                <tr>
                  <th scope="col">Txn Date & Time</th>
                  <th scope="col">Reference Number</th>
                  <th scope="col">Txn Amount</th>
                  <th scope="col">Response Code</th>
                  <th scope="col">Reversal Flag</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan="5">
                    <em>No record(s) found...</em>
                  </td>
                </tr>
              </tbody>
            </table>
          )}
        </div>

      </Modal.Body>
    </Modal>
  );
}

export default TransactionDetails;
