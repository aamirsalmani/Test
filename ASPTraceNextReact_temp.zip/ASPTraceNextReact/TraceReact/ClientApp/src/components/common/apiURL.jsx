﻿import axios from 'axios';
import { generateUUID } from './Utils';
import { LOGIN_SUCCESS, LOGIN_FAIL } from '../../pages/login/actions/types';
import store from '../../constants/store/sidebarStore';
import { useNavigate } from 'react-router-dom';

const BASE_URI = process.env.REACT_APP_API_BASE_URI;
const TOKEN_REFRESH_THRESHOLD = 280000; // 4 minutes 40 seconds
let isRefreshing = false;
let failedQueue = [];

// Create Axios instance with default config
const MaximusAxios = axios.create({
  baseURL: BASE_URI,

});

const processQueue = (error, token = null) => {
  failedQueue.forEach((promise) => {
    if (error) {
      promise.reject(error);
    } else {
      promise.resolve(token);
    }
  });

  failedQueue = [];
};


// Request interceptor to handle token expiration
MaximusAxios.interceptors.request.use(
  async (config) => {
    const user = localStorage.getItem('user');
    const token = user ? JSON.parse(user).accessToken : null;
    //console.log(token);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      config.headers['Content-Type'] = 'application/json';
      config.headers.Accept = 'application/json';
    }

    return config;
  },
  (error) => Promise.reject(error)
);


// Response interceptor to handle 401 errors and silent token refresh
MaximusAxios.interceptors.response.use(
  (response) => {
    // Return the response directly if it’s successful
    return response;
  },
  async (error) => {
    const { response } = error;

    if (response && response.status === 401) {
      // Handle the 401 error
      try {
        const newAccessToken = await refreshToken();
        console.log(error.config);

        if (newAccessToken) {
          localStorage.setItem("user", JSON.stringify(newAccessToken));
          // Dispatch to Redux store outside of React component
          store.dispatch({
            type: LOGIN_SUCCESS,
            payload: { user: newAccessToken },
          });
        }
        else {
          // Clear tokens from Redux
          store.dispatch({
            type: LOGIN_FAIL,
            payload: { user: null },
          });
          const navigate = useNavigate();
          navigate('/Login'); // Redirect to login
          return Promise.reject(error);
        }
        // Update the original request with the new access token
        error.config.headers['Authorization'] = `Bearer ${newAccessToken.accessToken}`;
        // Retry the original request with the new access token
        return MaximusAxios.request(error.config);
      } catch (refreshError) {
        // Handle token refresh failure (e.g., redirect to login)
        console.error('Error refreshing token:', refreshError);
        const navigate = useNavigate();
        navigate('/Login'); // Redirect to login        -- Sidd changed
       //window.location.href = '/Login';
        // You might want to redirect to login or show a message
      }
    }

    // If the error is not a 401 or the refresh fails, return the original error
    return Promise.reject(error);
  }
);


// Check if the token is about to expire
const isTokenExpiring = (token) => {
  const expirationTime = getTokenExpiration(token);
  const currentTime = Date.now();
  return expirationTime - currentTime <= TOKEN_REFRESH_THRESHOLD;
};

const clearTokens = (state) => {
  state.currentUser = null;
  localStorage.removeItem('user'); // Clear from localStorage 
};

// Function to refresh the access token
const refreshToken = async () => {
  try {
    //console.log('refreshToken');
    //console.log(BASE_URI);
    const response = await axios.post(
      `${BASE_URI}api/Login/RefreshToken`,
      { refreshToken: generateUUID() }, // This should ideally come from secure storage
      { headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, withCredentials: true }
    );

    if (response.data.accessToken) {
      return response.data;
    }
  } catch (error) {
    console.error('Unable to refresh token', error);
    // Handle refresh failure appropriately (e.g., force logout)
    localStorage.removeItem('user');
    window.history.go('Login');
  }

  return null;
};

// Helper function to extract JWT expiration time
const getTokenExpiration = (token) => {
  const [, payload] = token.split('.');
  const decoded = JSON.parse(atob(payload)); // Decode the JWT payload
  return decoded.exp * 1000; // Convert expiration time to milliseconds
};



export default MaximusAxios;
