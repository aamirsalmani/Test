export function splitCamelCase(str) {
    // Split the string at each capital letter
    // const words = str.split(/(?=[A-Z])/);
    const words = str.split(/(?<=[a-z])(?=[A-Z])/);
    // Capitalize the first letter of each word and join them with a space
    const result = words.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    return result;
}