import { useState, useEffect } from 'react';
import MaximusAxios from "./apiURL";
import { toast } from 'react-toastify';
import { NotificationPanel } from './Notifications/NotificationMessage';
import * as signalR from '@microsoft/signalr';
import { useDispatch, useSelector } from 'react-redux';
import { selectNotifications, setNotifications } from '../../constants/reducers/NotificationsReducer';

const notify = (data) => {
    if (data !== null && data !== undefined) {
        return data.map((item) => {
            toast.info((props) => (Msg(props, item)))
        })
    }

};
const Msg = ({ closeToast, toastProps }, dataitem) => (
    <NotificationPanel key={dataitem.id} notification={dataitem} IsToast={true} />
);

export const postNotificationFlag = async (Id, type) => {
    try {
        const response = await MaximusAxios.post(`api/Notifications/MarkNotification?notificationId=${Id}&type=${type}`, {  mode: 'cors' });

        return response.data;

    } catch (error) {
        //console.error("Error fetching notifications", error);
        return null;
    }
};
export const fetchNotifications = async () => {
    try {
        return await MaximusAxios.get("api/Notifications/GetNotifications");

        // let ToastCompleteList = Msgs.filter((item) => item.IsSent === false).map(async (notification) => {
        //     return await postNotificationFlag(notification.ID, 1);
        //     // await MaximusAxios.post(`/api/notifications/MarkNotification?notificationId=${notification.ID}&type=${1}`, {  mode: 'cors' });
        // })
        // console.log('ToastCompleteList',ToastCompleteList)

    } catch (error) {
        //console.error("Error fetching notifications", error);
    }
};

const useGetNotifications = () => {
    const dispatch = useDispatch();

    useEffect(() => {
        
        (
            async () => {
            const response = await fetchNotifications();
            if (response.data !== null) {
                let data = response.data;
                dispatch(setNotifications(data));
            }
            }
        )();


        const connection = new signalR.HubConnectionBuilder().configureLogging(signalR.LogLevel.None)
            .withUrl(`${MaximusAxios.defaults.baseURL}notificationhub`, {
                transport: signalR.HttpTransportType.WebSockets,
                skipNegotiation: true // Optional: helps if WebSockets are directly supported
            }) // URL of your SignalR hub
            .withAutomaticReconnect() // Automatically reconnect if the connection is lost
            .build();

        // Start the connection
        connection
            .start()
            .then(() => {
                //console.log('SignalR Connected.');

                // Listen for notifications from the server
                connection.on('ReceiveNotification', async (notification) => {
                    let Msgs = [notification];
                    notify(Msgs);
                    const response = await fetchNotifications();
                    let data = response.data;
                    if (data !== null) {
                        dispatch(setNotifications(data));
                    }
                    else{
                        dispatch(setNotifications(data));
                    }

                });
            })
            .catch((err) => console.error('Error while starting connection: ' + err));

        // Clean up the connection on component unmount
        return () => {
            if (connection?.state === signalR.HubConnectionState.Connected) {
                connection.stop();
            }
        };


    }, []);  // Empty dependency array to only run on component mount

    // Return notifications, loading state, and error state
    // return { notificationsArr};
};

export default useGetNotifications;
