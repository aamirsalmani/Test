// useSignalRNotifications.js
import { useEffect } from "react";
import * as signalR from "@microsoft/signalr";
import { toast } from "react-toastify";
import axios from "axios";

export const useSignalRNotifications = () => {
    useEffect(() => {
        const connection = new signalR.HubConnectionBuilder()
            .withUrl(`${axios.defaults.baseURL}notificationhub`)
            .withAutomaticReconnect()
            .configureLogging(signalR.LogLevel.Information)
            .build();

        const startConnection = async () => {
            try {
                await connection.start();
                //console.log(" SignalR Connected");
                //console.log(`${axios.defaults.baseURL}/notificationhub`);
                connection.on("ReceiveNotification", (message) => {
                    //console.log(" Notification Received:", message);
                    toast.info(message);
                });
            } catch (err) {
                //console.error(" SignalR Connection Failed:", err);
            }
        };

        startConnection();

        return () => {
            connection.stop();
        };
    }, []);
};
