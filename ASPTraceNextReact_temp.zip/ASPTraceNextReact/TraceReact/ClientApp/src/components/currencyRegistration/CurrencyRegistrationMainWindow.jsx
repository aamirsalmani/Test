﻿import React, { useState, useEffect } from "react";
import Select from "react-select"; 
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom"; 
import MaximusAxios from "../common/apiURL" ;
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";


//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"
import "datatables.net-dt/css/jquery.dataTables.min.css"
import $ from 'jquery';
import 'jquery/dist/jquery.min.js';


// Images
import Delete from "../../images/common/redDelete.svg"; 
import editRow from "../../images/common/editRow.svg"; 

import { useSelector } from "react-redux"; 

const CurrencyRegistrationMainWindow = () => {

    const currentUser = useSelector((state) => state.authReducer); 

    const [CurrencyRegistrationTableData, setCurrencyRegistrationTableData] = useState(null);
    const [CurrencyAdd, setCurrencyAdd] = useState(true); 
    const [optionsCountry, setOptionsCountryValue] = useState(null);
    const [isNewEntry, setNewEntry] = useState(false);

    const [isShow, setIsLoading] = useState(false);

    const [CurrencyOption, setCurrencyOption] = useState(true); 
    
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const fetchCurrecnyData = () => {

        setIsLoading(true);

        MaximusAxios.get('api/CurrencyReg/GetCurrencyRegList', {  mode: 'cors' }).then(result => { 
            setCurrencyRegistrationTableData(result.data); 
            setIsLoading(false);
        }).catch(function (error) {
            if (error.response) {
                console.log(error.response.data);
            }
            setIsLoading(false);
        });

    }

    const fetchOptions = () => {
        MaximusAxios.get('api/CurrencyReg/GetCountryRegList', {  mode: 'cors' }).then(result => {
            if (result.data !== null && result.data.length > 0) {
                setOptionsCountryValue(result.data);
            }
            else {
                setOptionsCountryValue([{ id: "0", country: "--Select--" }]);
            }
        }).catch(function (error) {
            if (error.response) {
                console.log(error.response.data);
            }
        });
    }

    useEffect(() => {
        fetchCurrecnyData();
    },
        [CurrencyAdd]
    );


    useEffect(() => {
        fetchOptions();
    },
        [CurrencyOption]
    );


    const [isShowCurrencyModal, setShowCurrencyModal] = useState(false); 
   
    const [buttonValue, setButtonValue] = useState('ADD'); 

    const [CurrencyCodeValue, setCurrencyCodeValue] = useState('');
    const [CurrencyDescriptionValue, setCurrencyDescriptionValue] = useState(null);
    const [selectedCountryValue, setSelectedCountryValue] = useState();
    const [NumericCodeValue, setNumericCodeValue] = useState(null);
    const [ScaleValue, setScaleValue] = useState(null);
    const [CurrencyID, setCurrencyID] = useState(0); 
     

    const onNewClick = () => {

        setShowCurrencyModal(true);
        setButtonValue('ADD');
        setCurrencyID(0);
        setCurrencyCodeValue('');
        setCurrencyDescriptionValue('');
        setNumericCodeValue('');
        setScaleValue('');
        setSelectedCountryValue(null);
        setNewEntry(true);
       
    };

    const onEditClick = (CurrencyID) => {

        if (window.confirm("Are you sure you want to edit.")) {

            setNewEntry(false);

            MaximusAxios.get('api/CurrencyReg/GetCurrencyDetails?CurrencyID=' + CurrencyID, {  mode: 'cors' }).then(CurrencyGetresult => {

                if (CurrencyGetresult.data != null) {
                    setCurrencyID(CurrencyGetresult.data.currencyID);
                    setCurrencyCodeValue(CurrencyGetresult.data.currencyCode);
                    setCurrencyDescriptionValue(CurrencyGetresult.data.currencyDescription);
                    setNumericCodeValue(CurrencyGetresult.data.numericCode);
                    setScaleValue(CurrencyGetresult.data.scale);
                    setSelectedCountryValue({ value: CurrencyGetresult.data.countryID, label: CurrencyGetresult.data.countryName });
                    setShowCurrencyModal(true);
                }

            }).catch(function (error) {
                if (error.response) {
                    console.log(error.response.data);
                }
            });

            setButtonValue('UPDATE');
        }
    };


    const onAddClick = () => {

        if (CurrencyCodeValue === null || CurrencyCodeValue.trim().length === 0) {
            alert("Please enter Currency Code!");
            return false;
        }

        if (CurrencyDescriptionValue === null || CurrencyDescriptionValue.trim().length === 0) {
            alert("Please enter Currency Description!");
            return false;
        }

        //if (selectedCountryValue === null || selectedCountryValue.value === 0) {
        //    alert("Please select Country!");
        //    return false;
        //}

        if (selectedCountryValue === null || selectedCountryValue.value === 0) {
            alert("Please select Country!");
            return false;
        }

        if (NumericCodeValue === null || NumericCodeValue.trim().length === 0) {
            alert("Please enter Numeric Code!");
            return false;
        }

        if (ScaleValue === null || ScaleValue.trim().length === 0) {
            alert("Please enter Scale!");
            return false;
        }       

        if (alert.length > 0) {
            setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alert });
            return false;
        }

        setIsLoading(true);

        MaximusAxios.post('api/CurrencyReg/CurrencyRegAddUpdate', {
            Mode: buttonValue,
            CurrencyID: buttonValue === 'ADD' ? '0' : CurrencyID,
            CurrencyCode: CurrencyCodeValue,
            CurrencyDescription: CurrencyDescriptionValue,
            CountryID: selectedCountryValue.value,
            CountryName: selectedCountryValue.label,
            NumericCode: NumericCodeValue,
            CreatedBy: currentUser.user.username,
            Scale: ScaleValue,

        }, {  mode: 'cors' })
            .then(function (response) {
                setShowCurrencyModal(false);
                setIsLoading(false);

                if (response.data === "0") {
                    alert("Currency already exists!");

                } else if (response.data === "1") {
                    if (buttonValue === 'ADD') { alert('Currency Registration added successfully!'); }
                    if (buttonValue === 'UPDATE') { alert('Currency Registration updated successfully!'); }
                    if (buttonValue === 'ADD') setCurrencyRegistrationTableData(null);                  
                } else
                {
                    alert(response.data);
                }
                setCurrencyAdd(!CurrencyAdd);
            })
            .catch(function (error) {
                if (error.response) {
                    console.log(error.response.data);   
                }
                setIsLoading(false);
            });

    };


    const onDeleteClick = (CurrencyID, CountryID) => {  
        
        if (window.confirm("Are you sure you want to delete.")) {

            MaximusAxios.post('api/CurrencyReg/DeleteCurrency', {
                Mode: 'DELETE',
                CurrencyID: CurrencyID
            }, {  mode: 'cors' })
                .then(function (response) {
                  
                    if (response.data !== null || response.data.length > 0) {
                        alert(response.data);
                        setCurrencyRegistrationTableData(null);
                        setCurrencyAdd(!CurrencyAdd);
                        
                    }
                }).catch(function (error) {
                    if (error.response) {
                        console.log(error.response.data);
                    } 
                });
        }
    };

    $(document).ready(function () {
        if (CurrencyRegistrationTableData !== null && CurrencyRegistrationTableData.length > 0) {
            $('#gvCurrencyRegistration').DataTable({
                "bDestroy": true,
                "columnDefs": [
                    { orderable: false, targets: [5] }
                ]
            });
        }
    });

    // Tooltip
    const renderTooltipAdd = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Click to add new entry
    </Tooltip>
    );




    return (
        <div className="configLeft currencyContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                     Currency Registration
                </h5>
                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12 colorPrimaryDefault">Client Management</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12">Currency Registration</p>
                </div>
            </div>
            {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {/* Table Content */}
            <div className="configLeftBottom">
                
                <div>
           
                    {/* Table */}
                    {(CurrencyRegistrationTableData !== null && CurrencyRegistrationTableData.length > 0) ? (
                        <div>
                            <div className="exportButton">
                                
                                <OverlayTrigger
                                    placement="top"
                                    delay={{ show: 150, hide: 400 }}
                                    overlay={renderTooltipAdd}
                                >
                                    <button type="button" className="iconAddButtonBox" onClick={onNewClick}>
                                        <span className="icon-Plus">+</span>
                                        <span className="ms-1 fontSize12-m colorPrimaryDefault">Add New</span>
                                    </button>
                                </OverlayTrigger>
                            </div>
                            <div className="tableBorderBox pt-3">
                                <div className="w-100 table-responsive">
                                    <div className="table-responsive tableCurrencyContentBox" >
                                        <table id="gvCurrencyRegistration" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                            <thead>
                                                <tr>
                                                    <th scope="col">Currency Code</th>
                                                    <th scope="col">Currency Description</th>
                                                    <th scope="col">Country</th>
                                                    <th scope="col">Numeric Code</th>
                                                    <th scope="col">Scale</th>
                                                    <th scope="col">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {
                                                    CurrencyRegistrationTableData.map((p, index) => {
                                                        return <tr key={index}>
                                                            <td >{p.currencyCode}</td>
                                                            <td >{p.currencyDescription}</td>
                                                            <td >{p.countryName}</td>
                                                            <td >{p.numericCode}</td>
                                                            <td >{p.scale}</td>
                                                            <td ><div className="text-center">
                                                                <button type="button" className="iconButtonBox" onClick={() => onEditClick(p.currencyID)} >                                                                    
                                                                    <img src={editRow} alt="Edit" title="Edit" />
                                                                </button>
                                                                <button type="button" className="iconButtonBox" onClick={() => onDeleteClick(p.currencyID, p.countryID)} >                                                                  
                                                                    <img src={Delete} alt="Delete" title="Delete" />
                                                                </button>
                                                            </div></td>
                                                        </tr>
                                                    })
                                                }

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
                        :
                        (
                            <div className="tableBorderBox pt-3">
                                <div className="addButton">
                                    <button
                                        className="btn p-0 d-flex justify-content-center align-items-center"
                                        type="button" onClick={onNewClick} id="addButtonCurrency"
                                    >
                                        <span className="icon-Plus">+</span>
                                        <span className="ms-1 fontSize12-m colorPrimaryDefault">Add New</span>
                                    </button>
                                </div>
                                <div className="w-100 table-responsive">
                                    <div className="table-responsive tableContentBox">
                                        <table className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }}>
                                            <thead>
                                                <tr style={{  border: "1px dashed black !important" }}>
                                                    <th scope="col">Currency Code</th>
                                                    <th scope="col">Currency Description</th>
                                                    <th scope="col">Country</th>
                                                    <th scope="col">Numeric Code</th>
                                                    <th scope="col">Scale</th>
                                                    <th scope="col">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td colSpan="6" style={{ textAlign: "left", backgroundColor: "var(--table-hover-color) !important", paddingTop : "10px" }}> No Records Found <hr /> </td> 
                                                </tr>
                                            </tbody>
                                        </table>
                                      
                                    </div>
                                </div>
                            </div>

                        )
                    }
                  
                </div>
                
            </div>
            </>
        )}
            {isShowCurrencyModal && (
                <Modal
                    show={isShowCurrencyModal}
                    onHide={() => setShowCurrencyModal(!isShowCurrencyModal)}
                    centered
                    className="currencyTableModal"
                >
                    <Modal.Header closeButton>
                        <Modal.Title className="fontSize16-sm letterSpacing-2">
                            {isNewEntry ? <span>Add</span> : <span>Update</span>} Currency
              </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="currencyControl">
                            <label htmlFor="currencycode">Currency Code</label>
                            <span className="text-danger font-size13">*</span>
                            <input
                                type="text"
                                name="currencycode"
                                id="currencycode"
                                placeholder="Enter Currency Code"
                                className="inputTextBox"
                                onChange={(e) => setCurrencyCodeValue(e.target.value)}
                                value={CurrencyCodeValue}
                                onKeyPress={(e) => !/[a-zA-Z]/.test(e.key) && e.preventDefault()}
                            />
                        </div>
                        <div className="currencyControl">
                            <label htmlFor="currencydescription">Currency Description</label>
                            <span className="text-danger font-size13">*</span>
                            <input
                                type="text"
                                name="currencydescription"
                                id="currencydescription"
                                placeholder="Enter Currency Description"
                                className="inputTextBox"
                                onChange={(e) => setCurrencyDescriptionValue(e.target.value)}
                                value={CurrencyDescriptionValue}
                                onKeyPress={(e) => !/[a-zA-Z ]/.test(e.key) && e.preventDefault()}
                            />
                        </div>
                        <div className="currencyControl">
                            <label htmlFor="ddlCountry">Country</label>
                            <span className="text-danger font-size13">*</span>
                            <Select
                                id="ddlCountry"
                                value={selectedCountryValue} 
                                options={optionsCountry.map(x => (
                                    {
                                        value: x.id,
                                        label: x.country
                                    }
                                ))}
                                onChange={setSelectedCountryValue}
                            />
                        </div>
                        <div className="currencyControl">
                            <label htmlFor="numericcode">Numeric Code</label>
                            <span className="text-danger font-size13">*</span>
                            <input
                                type="number"
                                name="numericcode"
                                id="numericcode"
                                placeholder="Enter Numeric Code"
                                className="inputTextBox"
                                onChange={(e) => setNumericCodeValue(e.target.value)}
                                value={NumericCodeValue}
                                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                            />
                        </div>
                        <div className="currencyControl">
                            <label htmlFor="scale">Scale</label>
                            <span className="text-danger font-size13">*</span>
                            <input
                                type="number"
                                name="scale"
                                id="scale"
                                placeholder="Enter Scale"
                                className="inputTextBox"
                                onChange={(e) => setScaleValue(e.target.value)}
                                value={ScaleValue}
                                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
                            />
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <button type="button" className="btnPrimary ms-2" onClick={onAddClick} >{buttonValue}</button>
                    </Modal.Footer>
                </Modal>
            )}

            <LoadingSpinner isShow={false} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default CurrencyRegistrationMainWindow;
