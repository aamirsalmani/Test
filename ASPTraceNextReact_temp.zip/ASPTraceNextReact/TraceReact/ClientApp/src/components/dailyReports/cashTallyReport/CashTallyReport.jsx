import React from "react";
import { useSelector } from "react-redux";
// CSS
// Components
import SidebarMain from "../../common/SidebarMain";
import CashTallyReportMainWindow from "./CashTallyReportMainWindow";

const CashTallyReport = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView">
        <CashTallyReportMainWindow />
    </div>
  );
};

export default CashTallyReport;
