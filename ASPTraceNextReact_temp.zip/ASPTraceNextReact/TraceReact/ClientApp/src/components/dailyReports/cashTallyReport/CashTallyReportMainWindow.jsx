import React, { useState } from "react";
import AsyncSelect from "react-select/async";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link, useLocation } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import { useSelector } from "react-redux";
import authHeader from "../../../pages/login/services/auth-header";

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import $ from "jquery";
import "jquery/dist/jquery.min.js";
import { saveAs } from "file-saver";
// Images
import ExcelIcon from "../../../images/common/excel.svg";
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";

const CashTallyReportMainWindow = () => {
  let location = useLocation();
  let capitalizedLocation = location.pathname.replace(/\b\w/g, (char) =>
    char.toUpperCase()
  );
  const currentUser = useSelector((state) => state.authReducer);
  const [referenceNo, setReferenceNo] = useState(false);
  const [UnmatchedReport, setUnmatchedReport] = useState(null);

  const [CashReportDetail, setCashReportDetail] = useState(null);

  const fetchClientData = (inputValue) => {
    setStartDate(null);
    setEndDate(null);

    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const [isShow, setIsLoading] = useState(false);

  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const formatDateForShow = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const [inputValue, setValue] = useState("0");
  const [selectedValue, setSelectedValue] = useState(null);
  const [titleDate, setTitleDateValue] = useState("");

  //   const [differenceAmount, setDifferenceAmount] = useState(null);
  //   const [terminal, setTerminal] = useState(null);
  //   const [EJTxnList, setEJTxnList] = useState(null);
  //   const [GLTxnList, setGLTxnList] = useState(null);
  //   const [NWTxnList, setNWTxnList] = useState(null);
  //   const [SWTxnList, setSWTxnList] = useState(null);

  // handle input change event
  const handleInputChange = (value) => {
    setValue(value);
  };

  const handleClientChange = (value) => {
    setCashReportDetail(null);
    setSelectedValue(value);
  };
  //   Date Calendar
  const [startDate, setStartDate] = useState(new Date());
  //   Date Calendar
  const [endDate, setEndDate] = useState(new Date());

  const setStartDateValue = (value) => {
    setStartDate(value);
    setCashReportDetail(null);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date ");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    setCashReportDetail(null);
  };

  const downloadExcel = () => {
    // setCashReportDetail(null);
    MaximusAxios.post(
      "api/Logger/InsertUserActivityReport",
      {
        UserId: currentUser.user.username,
        PageName: capitalizedLocation,
        Activity: "Download Excel",
      },
      { headers: authHeader() }
    );

    if (selectedValue === null || selectedValue.clientID === undefined) {
      alert("Please select client!");
      return false;
    }

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }
    setIsLoading(true);

    let FileName = "CashTally_Report_" + formatDate(startDate) + ".xlsx";
    setIsLoading(true);

    MaximusAxios.post(
      "api/Report/ExportCashTallyExcelReport",
      {
        ClientID: parseInt(selectedValue.clientID, 10),
        FromDateTxns: String(formatDate(startDate)),
        ToDateTxns: String(formatDate(endDate)),
      },
      { responseType: "blob" }
    )
      .then(function (response) {
        saveAs(response.data, FileName);
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        setIsLoading(false);
      });
  };

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to excel
    </Tooltip>
  );
  const renderTooltipShow = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to open window
    </Tooltip>
  );

  const formatDate = (date) => {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

  const onReset = (e) => {
    e.preventDefault();
   // window.location.reload(false);
   setCashReportDetail(null);
   setUnmatchedReport(null);
    setSelectedValue(null);
    setStartDate(null);
    setValue(null);
    setEndDate(null);
  };
  const getColumnHeaders = () => {
    if (CashReportDetail.length === 0) return [];
    return Object.keys(CashReportDetail[0]);
  };
  const getColumnHeadersForUnmatched = () => {
    if (UnmatchedReport.length === 0) return [];
    return Object.keys(UnmatchedReport[0]);
  };

  const onSubmit = () => {
    setUnmatchedReport(null);
    setCashReportDetail(null);
    // console.log(selectedValue.clientID);
    // console.log(formatDate(startDate));
    // console.log(formatDate(endDate));
    setCashReportDetail(null);

    if (selectedValue === null || selectedValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }
    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    setIsLoading(true);

    MaximusAxios.post(
      "api/Report/GetCashTallyReportList",
      {
        ClientID: parseInt(selectedValue.clientID, 10),
        FromDateTxns: String(formatDate(startDate)),
        ToDateTxns: String(formatDate(endDate)),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setCashReportDetail(response.data);
        // console.log(response.data);
        setTitleDateValue(
          "Report Date : " +
            formatDate(startDate) +
            " To " +
            formatDate(endDate)
        );
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "No records found",
          });
        }
      })
      .catch(function (error) {
        setTitleDateValue("");
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };
  const onUnSettledAmountClick = (FromDate4, ToDate4, TERMINALID4) => {
    setUnmatchedReport(null);

    // console.log(FromDate4);
    // console.log(ToDate4);
    // console.log(TERMINALID4);

    setIsLoading(true);
    MaximusAxios.post(
      "api/Report/GetCashTallyUnmatchedReportList",
      {
        ClientID: selectedValue.clientID,
        ChannelID: "0",
        ModeID: "0",
        TERMINALID: TERMINALID4,
        Type: "3",
        FromDateTxns: formatDate(FromDate4),
        ToDateTxns: formatDate(ToDate4),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setUnmatchedReport(response.data);
        // console.log(response.data);
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Info",
            alertMessage: "No Record Found",
          });
        }
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  //   const onReferenceNumberClick = (ReferenceNumber, TerminalID) => {
  //     setIsLoading(true);

  //     setReferenceNo(ReferenceNumber);

  //     MaximusAxios
  //       .post(
  //         "api/Report/GetDispenseUnmatchedReportByReferenceNumberClickList",
  //         {
  //           ClientID: selectedValue.clientID,
  //           ChannelID: "0",
  //           ModeID: "0",
  //           TERMINALID: TerminalID,
  //           ReferenceNumber: ReferenceNumber,
  //         },
  //         {  mode: 'cors' }
  //       )
  //       .then(function (response) {
  //         setEJTxnList(response.data.ejTxnDetails);
  //         setGLTxnList(response.data.glTxnDetails);
  //         setNWTxnList(response.data.nwTxnDetails);
  //         setSWTxnList(response.data.swTxnDetails);
  //         setIsLoading(false);
  //       })
  //       .catch(function (error) {
  //         if (error.response) {
  //           setShowMessageBox({
  //             isShow: true,
  //             alertVariant: "danger",
  //             alertTitle: "Error",
  //             alertMessage: "Error occurred while processing your request",
  //           });
  //         }
  //         setIsLoading(false);
  //       });
  //   };

  //   const FindAmountDifference = (terminalID) => {
  //     setTerminal(terminalID);
  //     setIsLoading(true);

  //     let TerminalValue = "0";

  //     if (terminalID === undefined || terminalID === null) {
  //       TerminalValue = "0";
  //     } else {
  //       TerminalValue = terminalID;
  //     }

  //     MaximusAxios
  //       .post(
  //         "api/Report/GetUnmatchedTxnByReferenceNumberList",
  //         {
  //           ClientID: selectedValue.clientID,
  //           TERMINALID: TerminalValue,
  //           FromDateTxns: String(formatDate(startDate)),
  //           ToDateTxns: String(formatDate(endDate)),
  //         },
  //         {  mode: 'cors' }
  //       )
  //       .then(function (response) {
  //         setEJTxnList(response.data.ejTxnDetails);
  //         setGLTxnList(response.data.glTxnDetails);
  //         setNWTxnList(response.data.nwTxnDetails);
  //         setSWTxnList(response.data.swTxnDetails);
  //         setIsLoading(false);
  //       })
  //       .catch(function (error) {
  //         if (error.response) {
  //           setShowMessageBox({
  //             isShow: true,
  //             alertVariant: "danger",
  //             alertTitle: "Error",
  //             alertMessage: "Error occurred while processing your request",
  //           });
  //         }
  //         setIsLoading(false);
  //       });
  //   };

  $(document).ready(function () {
    if ($.fn.DataTable.isDataTable("#gvDuplicateTxnsReportPDF")) {
      $("#gvDuplicateTxnsReportPDF").DataTable().destroy();
    }

    if (CashReportDetail !== null && CashReportDetail.length > 0) {
      $("#gvDuplicateTxnsReportPDF").DataTable({
        ordering: true,
        order: [[5, "asc"]],
      });
    }
  });
  $(document).ready(function () {
    if (UnmatchedReport !== null && UnmatchedReport.length > 0) {
      $("#gvUnmatchedReportPDF").DataTable();
    }
  });

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Cash Tally Transactions
        </h5>

        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Daily Reports</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Cash Tally Transactions</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="duplicateFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="duplicateFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#duplicateFiltersCollapse"
                aria-expanded="true"
                aria-controls="duplicateFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="duplicateFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="duplicateFiltersHeading"
              data-bs-parent="#duplicateFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onSubmit}
                    disabled={isShow}
                  >
                    Show
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Content */}
      <div className="configLeftTop">
        {(CashReportDetail === null || CashReportDetail.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        {/* Table */}
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
        {CashReportDetail !== null && CashReportDetail.length > 0 ? (
          <div>
            <div className="exportButton">
              <OverlayTrigger
                placement="top"
                delay={{ show: 150, hide: 400 }}
                overlay={renderTooltipExcel}
              >
                <button
                  type="button"
                  className="iconButtonBox"
                  onClick={downloadExcel}
                >
                  <img src={ExcelIcon} alt="Excel" />
                </button>
              </OverlayTrigger>
            </div>
            <div className="tableBorderBox pt-3">
              <div className="w-100 table-responsive">
                <div className="table-responsive tableContentBox">
                  <table
                    id="gvDuplicateTxnsReportPDF"
                    className="table table-striped table-hover table-borderless align-middle"
                    style={{ width: "100%" }}
                  >
                    <thead>
                      <tr>
                        {getColumnHeaders().map((header, index) => (
                          <th key={index} scope="col">
                            {header}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {CashReportDetail.map((row, rowIndex) => (
                        <tr key={rowIndex}>
                          {getColumnHeaders().map((header, colIndex) => (
                            <td key={colIndex}>
                              {header === "DIff" ? (
                                <OverlayTrigger
                                  placement="top"
                                  delay={{ show: 250, hide: 400 }}
                                  overlay={renderTooltipShow}
                                >
                                  <button
                                    className="editBox"
                                    onClick={() =>
                                      onUnSettledAmountClick(
                                        formatDate(startDate),
                                        formatDate(endDate),
                                        row["ATM ID"]
                                      )
                                    }
                                  >
                                    <u>{row[header]}</u>
                                  </button>
                                </OverlayTrigger>
                              ) : header === "DATE" ? (
                                formatDateForShow(row[header])
                              ) : (
                                row[header]
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        ) : null}
        </>
      )}
        {/* Bottom Content2 */}
        <div className="configLeftTop">
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
          {UnmatchedReport !== null && UnmatchedReport.length > 0 ? (
            <div>
              <div className="exportButton">
                <OverlayTrigger
                  placement="top"
                  delay={{ show: 150, hide: 400 }}
                  overlay={renderTooltipExcel}
                >
                  <button
                    type="button"
                    className="iconButtonBox"
                    onClick={downloadExcel}
                  >
                    <img src={ExcelIcon} alt="Excel" />
                  </button>
                </OverlayTrigger>
              </div>
              <div className="tableBorderBox pt-3">
                <div className="w-100 table-responsive">
                  <div className="table-responsive tableContentBox">
                    <table
                      id="gvUnmatchedReportPDF"
                      className="table table-striped table-hover table-borderless align-middle"
                      style={{ width: "100%" }}
                    >
                      <thead>
                        <tr>
                          {getColumnHeadersForUnmatched().map(
                            (header, index) => (
                              <th key={index} scope="col">
                                {header}
                              </th>
                            )
                          )}
                        </tr>
                      </thead>
                      <tbody>
                        {UnmatchedReport.map((row, rowIndex) => (
                          <tr key={rowIndex}>
                            {getColumnHeadersForUnmatched().map(
                              (header, colIndex) => (
                                <td key={colIndex}>
                                  {header === "TxnsDateTime"
                                    ? formatDateForShow(row[header])
                                    : row[header]}
                                </td>
                              )
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          ) : null}
          </>)}
        </div>
      </div>
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default CashTallyReportMainWindow;
