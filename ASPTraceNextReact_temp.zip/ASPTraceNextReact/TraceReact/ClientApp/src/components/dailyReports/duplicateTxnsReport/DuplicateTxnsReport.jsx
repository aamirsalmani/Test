import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import DuplicateTxnsReportMainWindow from "./DuplicateTxnsReportMainWindow";

const DuplicateTxnsReportReport = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView">
        <DuplicateTxnsReportMainWindow />
    </div>
  );
};

export default DuplicateTxnsReportReport;
