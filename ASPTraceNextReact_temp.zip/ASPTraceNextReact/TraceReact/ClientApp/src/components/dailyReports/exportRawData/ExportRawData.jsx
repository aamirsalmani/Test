﻿import React from "react";
import { useSelector } from "react-redux"; 
// Components
import SidebarMain from "../../common/SidebarMain";
import ExportRawDataMainWindow from "../exportRawData/ExportRawDataMainWindow";


const ExportRawData = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <ExportRawDataMainWindow />
        </div>
    );
};

export default ExportRawData;
