﻿import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from "react-select/async";
import { Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import authHeader from "../../../pages/login/services/auth-header";
import { useSelector } from "react-redux";

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import $ from "jquery";
import "jquery/dist/jquery.min.js";

import ExcelJS from "exceljs";
import { saveAs } from "file-saver";

// Images
import Pdf from "../../../images/common/pdf.svg";
import ExcelIcon from "../../../images/common/excel.svg";
import CsvIcon from "../../../images/common/csv.svg";

import jsPDF from "jspdf";
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";

//const optionsFileType = [
//    { value: "1", label: "EJ" },
//    { value: "2", label: "CBS" },
//    { value: "3", label: "SWITCH" },
//    { value: "4", label: "NETWORK" },
//    { value: "5", label: "SETTLEMENT" },
//    { value: "6", label: "ADJUSTMENT" },
//];

const ExportRawDataMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const onReset = (e) => {
    e.preventDefault();
    //window.location.reload(false);
    setOptionsChannelTypeValue([]);
    setSelectedLogValue(null);
    setTitleDateValue(null);
    setValue(null);
    setSelectedClientValue(null);
    setSelectedChannelValue(null);
    setOptionsModeTypeValue([]);
    setIsShowTerminal(false);
    setSelectedModeValue(null);
    setSelectedLogFileType(null);
    setExportRawData(null);
    setShowDataReports(null);
    setOptionsTerminalValue([]);
    setStartDate(null);
    setEndDate(null);
  };

  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const fetchClientData = (inputValue) => {
    setStartDate(null);
    setEndDate(null);

    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  const [inputValue, setValue] = useState("0");
  const [selectedClientValue, setSelectedClientValue] = useState(null);
  const [titleDate, setTitleDateValue] = useState("");

  const [selectedLogValue, setSelectedLogValue] = useState(null);

  const [optionsChannelType, setOptionsChannelTypeValue] = useState([
    { channelID: "0", channelName: "--Select--" },
  ]);

  const [selectedChannelValue, setSelectedChannelValue] = useState(null);

  const [optionsModeType, setOptionsModeTypeValue] = useState([
    { modeID: "0", modeName: "All" },
  ]);

  const [selectedModeValue, setSelectedModeValue] = useState(null);

  const [selectedTxnTypeValue, setSelectedTxnTypeValue] = useState(null);

  const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

  const [isShowTerminal, setIsShowTerminal] = useState(false);

  const [isShowTxnType, setIsShowTxnType] = useState(false);

  const [isShowChannelType, setIsShowChannelType] = useState(false);

  const [ExportRawData, setExportRawData] = useState(null);

  const [ShowDataReports, setShowDataReports] = useState(null);

  const [isShowModeType, setIsShowModeType] = useState(false);

  const [optionsTerminalType, setOptionsTerminalValue] = useState([
    { ID: "0", TERMINALID: "All" },
  ]);

  const [OptionsFileType, setOptionsFileTypeValue] = useState([
    { ID: "0", LogType: "--Select--" },
  ]);

  const [SelectedLogFileType, setSelectedLogFileType] = useState();

  // handle input change event
  const handleInputChange = (value) => {
    setValue(value);
  };

  const handleOptionsChannelType = (value) => {
    setOptionsChannelTypeValue(value);
  };

  const handleOptionsModeType = (value) => {
    setOptionsModeTypeValue(value);
  };

  const handleOptionsTerminalType = (value) => {
    setOptionsTerminalValue(value);
  };

  const handleOptionsLogFileType = (value) => {
    setSelectedLogFileType(value);
  };

  const handleClientChange = (value) => {
    setSelectedClientValue(value);
    setExportRawData(null);
    setSelectedLogValue(null);
    setSelectedChannelValue(null);
    setSelectedModeValue(null);
    //setStartDate(null);
    //setEndDate(null);
    if (value.value !== "0" && value.clientID !== "0") {
      return MaximusAxios.get(
        "api/Common/GetChannelOptionList?ClientID=" +
          value.clientID +
          "&UserID=" +
          currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsChannelType(result.data);
      });
    }
  };

  const handleChannelChange = (value) => {
    setExportRawData(null);
    setSelectedModeValue(null);
    setSelectedLogValue(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedChannelValue(value);

    if (value.value !== "0" && selectedClientValue.clientID !== "0") {
      MaximusAxios.get(
        "/api/Common/GetModeOptionList?ClientID=" +
          selectedClientValue.clientID +
          "&ChannelID=" +
          value.value +
          "&UserID=" +
          currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsModeType(result.data);
      });
    }

    if (value.value !== "0" && selectedClientValue.clientID !== "0") {
      MaximusAxios.get(
        `/api/AuditReport/GetLogFileList?ChannelID=${value.value}`,
        { mode: "cors" }
      )
        .then((result) => {
          setOptionsFileTypeValue(result.data);
        })
        .catch((error) => {
          console.error(
            "There was an error fetching the log file list:",
            error
          );
          if (error.response && error.response.status === 400) {
            console.error(
              "Bad Request: Check the parameters being sent to the API."
            );
          }
        });
    }
  };

  const handleLogTypeChange = (value) => {
    setExportRawData(null);
    setSelectedModeValue(null);
    //setStartDate(null);
    //setEndDate(null);
    if (
      value.value !== "0" &&
      selectedClientValue.clientID !== "0" &&
      selectedChannelValue.value != null
    ) {
      return MaximusAxios.get("api/AuditReport/GetLogFileList", {
        mode: "cors",
      })
        .then((result) => {
          setOptionsFileTypeValue(result.data);
        })
        .catch((error) => {
          console.error("Error fetching terminal options:", error);
          // Handle error state if needed
        });
    } else {
    }
  };

  const handleModeChange = (value) => {
    if (currentUser !== null && currentUser.user !== null) {
      setExportRawData(null);

      //setStartDate(null);
      //setEndDate(null);
      setSelectedModeValue(value);

      if (value.value === "1" || value.value === "2") {
        setIsShowTerminal(true);
      } else {
        setIsShowTerminal(false);
      }

      if (
        value.value !== "0" &&
        selectedClientValue.clientID !== "0" &&
        selectedChannelValue.value
      ) {
        return MaximusAxios.get(
          "api/Common/GetTerminalOptionList?ClientID=" +
            selectedClientValue.clientID +
            "&ChannelID=" +
            selectedChannelValue.value +
            "&UserName=" +
            currentUser.user.username,
          { mode: "cors" }
        ).then((result) => {
          var resData = result.data;

          var myObj = { ID: "0", TERMINALID: "All" };

          resData.push(myObj);

          handleOptionsTerminalType(resData);
        });
      }
    } else {
      alert("Session Timeout");
    }
  };

  //const handleChannelChange = value => {
  //    setExportRawData(null);
  //    //setStartDate(null);
  //    //setEndDate(null);
  //    setSelectedChannelValue(value);
  //}
  // handle selection

  //   Date Calendar
  const [startDate, setStartDate] = useState(new Date());
  //   Date Calendar
  const [endDate, setEndDate] = useState(new Date());

  const chkU = () => {
    return currentUser?.user?.username.includes("demo.user1");
  };

  const setStartDateValue = (value) => {
    setStartDate(value);
    setExportRawData(null);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    setExportRawData(null);
  };

  ///////////////////////////////////////////////////////////////////////////advaitss///////////////////////////////////////////////////////////

  const ExportToExcelKS = (item) => {
    if (selectedClientValue === null || selectedClientValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (
      selectedLogValue !== undefined &&
      selectedLogValue !== null &&
      selectedLogValue.value === "4" &&
      (selectedChannelValue === undefined || selectedChannelValue === null)
    ) {
      alert("Please select Channel!");
      return false;
    }

    if (SelectedLogFileType === undefined || SelectedLogFileType === null) {
      alert("Please select FileType!");
      return false;
    }

    if (
      (selectedLogValue === undefined || selectedLogValue === null) &&
      (selectedModeValue === undefined || selectedModeValue === null)
    ) {
      alert("Please select mode Type!");
      return false;
    }

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let FileType = "0";

    if (SelectedLogFileType === undefined || SelectedLogFileType === null) {
      FileType = "0";
    } else {
      FileType = SelectedLogFileType.value;
    }

    let ChannelId = "0";

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      ChannelId = "0";
    } else {
      ChannelId = selectedChannelValue.value;
    }

    let ModeId = "0";

    if (selectedModeValue === undefined || selectedModeValue === null) {
      ModeId = "0";
    } else {
      ModeId = selectedModeValue.value;
    }

    let FileLogName = "0";

    if (item.FileName === undefined || item.FileName === null) {
      FileLogName = "0";
    } else {
      FileLogName = item.FileName;
    }

    let FileName = "ExportRawDataReport_";

    if (selectedChannelValue && selectedChannelValue.label) {
      FileName += selectedChannelValue.label + "_";
    } else {
      console.error(
        "selectedChannelValue or selectedChannelValue.label is null"
      );
      // Handle the error or assign a default value
      FileName += "DefaultChannel_";
    }

    if (SelectedLogFileType && SelectedLogFileType.label) {
      FileName += SelectedLogFileType.label + "_";
    } else {
      console.error("selectedLogValue or selectedLogValue.label is null");
      // Handle the error or assign a default value
      FileName += "DefaultLog_";
    }

    FileName += formatDate(startDate) + ".xlsx";

    console.log(FileName); // Output the filename to check if it's correct

    // let FileName = 'ExportRawDataReport_' + selectedChannelValue.label + '_' + selectedLogValue.label + '_' + formatDate(startDate) + '.xlsx'

    setIsLoading(true);

    MaximusAxios.post(
      "api/AuditReport/ExportExcelReportKS",
      {
        ClientID: selectedClientValue.clientID,
        ChannelID: ChannelId,
        ModeId: ModeId,
        FileType: FileType,
        FileLogName: FileLogName,
        TR_POSTDATE: formatDate(startDate),
        TR_ENDDATE: formatDate(endDate),
      },
      { responseType: "blob" }
    )
      .then(function (response) {
        saveAs(response.data, FileName);
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        setIsLoading(false);
      });
  };

  const ExportToCsvKS = (item) => {
    console.log(item);
    if (selectedClientValue === null || selectedClientValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (
      selectedLogValue !== undefined &&
      selectedLogValue !== null &&
      selectedLogValue.value === "4" &&
      (selectedChannelValue === undefined || selectedChannelValue === null)
    ) {
      alert("Please select Channel!");
      return false;
    }

    if (SelectedLogFileType === undefined || SelectedLogFileType === null) {
      alert("Please select FileType!");
      return false;
    }

    if (
      (selectedLogValue === undefined || selectedLogValue === null) &&
      (selectedModeValue === undefined || selectedModeValue === null)
    ) {
      alert("Please select mode Type!");
      return false;
    }

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let FileLogName = 0;

    if (item.fileName === undefined || item.fileName === null) {
      FileLogName = 0;
    } else {
      FileLogName = item.fileName;
    }

    let FileType = 0;

    if (SelectedLogFileType === undefined || SelectedLogFileType === null) {
      FileType = 0;
    } else {
      FileType = SelectedLogFileType.value;
    }

    let ChannelId = 0;

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      ChannelId = 0;
    } else {
      ChannelId = selectedChannelValue.value;
    }
    let ModeId = 0;

    if (selectedModeValue === undefined || selectedModeValue === null) {
      ModeId = 0;
    } else {
      ModeId = selectedModeValue.value;
    }

    let FileName = "ExportRawDataReport_";

    if (selectedChannelValue && selectedChannelValue.label) {
      FileName += selectedChannelValue.label + "_";
    } else {
      console.error(
        "selectedChannelValue or selectedChannelValue.label is null"
      );
      // Handle the error or assign a default value
      FileName += "DefaultChannel_";
    }

    if (SelectedLogFileType && SelectedLogFileType.label) {
      FileName += SelectedLogFileType.label + "_";
    } else {
      console.error("selectedLogValue or selectedLogValue.label is null");
      // Handle the error or assign a default value
      FileName += "DefaultLog_";
    }

    FileName += formatDate(startDate) + ".csv";

    console.log(FileName); // Output the filename to check if it's correct

    //let FileName = 'ExportRawDataReport_' + selectedChannelValue.label + '_' + selectedLogValue.label + '_' + formatDate(startDate) +'.csv'

    setIsLoading(true);

    MaximusAxios.post(
      "api/AuditReport/ExportCsvReportKS",
      {
        ClientID: selectedClientValue.clientID,
        ChannelID: ChannelId,
        ModeId: ModeId,
        FileType: FileType,
        FileLogName: FileLogName,
        TR_POSTDATE: formatDate(startDate),
        TR_ENDDATE: formatDate(endDate),
      },
      { responseType: "blob" }
    )
      .then(function (response) {
        saveAs(response.data, FileName);
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        setIsLoading(false);
      });
  };

  ///////////////////////////////////////////////////////////////////////////advaitee///////////////////////////////////////////////////////////

  const downloadPDF = () => {
    if (ExportRawData !== null) {
      if (ExportRawData.length > 0) {
        MaximusAxios.get(
          "api/Common/GetClientLogoImage?ClientId=" +
            selectedClientValue.clientID,
          { mode: "cors" }
        ).then((result) => {
          const title = "File Status Report";
          const headers = [
            ["FileDate", "FileName", "TxnsCount", "CREATEDON", "CreatedBy"],
          ];

          var dataPDF = $("#gvExportRawDataPDF")
            .dataTable()
            ._("tr", { filter: "applied" });
          let filterDataPDF = [];
          let cntrow = 0;
          //console.log(dataPDF);
          for (let i = 0; i < dataPDF.length; i++) {
            var arr = [
              dataPDF[cntrow][0],
              dataPDF[cntrow][1],
              dataPDF[cntrow][2],
              dataPDF[cntrow][3],
              dataPDF[cntrow][4],
            ];
            filterDataPDF.push(arr);
            cntrow++;
          }
          //console.log(filterDataPDF);

          const unit = "pt";
          const size = "LEGAL"; // Use A1, A2, A3 or A4
          const orientation = "landscape"; // portrait or landscape

          const doc = new jsPDF(orientation, unit, size);

          //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
          var pageWidth =
            doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

          //console.log(result);

          doc.addImage(result.data.clientLogo, "PNG", 20, 20, 150, 50);

          doc.addImage(
            result.data.traceLogo,
            "PNG",
            pageWidth - 170,
            20,
            150,
            50
          );

          //doc.setTextColor(100);

          doc.setFontSize(24);

          doc.text(title, pageWidth / 2, 40, { align: "center" });

          doc.setFontSize(20);

          doc.text(titleDate, pageWidth / 2, 65, { align: "center" });

          let content = {
            startY: 80,
            head: headers,
            body: filterDataPDF,
          };

          doc.setFontSize(10);
          doc.autoTable(content);
          doc.save("Raw Data .pdf");
        });
      } else {
        alert("No Record Found");
      }
    } else {
      alert("No Record Found");
    }
  };

  // Tooltip
  const renderTooltip = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to pdf
    </Tooltip>
  );

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to Excel
    </Tooltip>
  );

  const renderTooltipCsv = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to Csv
    </Tooltip>
  );

  const formatDate = (date) => {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

  const onSubmit = () => {
    setExportRawData(null);

    if (selectedClientValue === null || selectedClientValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (
      selectedLogValue !== undefined &&
      selectedLogValue !== null &&
      selectedLogValue.value === "4" &&
      (selectedChannelValue === undefined || selectedChannelValue === null)
    ) {
      alert("Please select Channel!");
      return false;
    }

    if (SelectedLogFileType === undefined || SelectedLogFileType === null) {
      alert("Please select FileType!");
      return false;
    }

    if (
      (selectedLogValue === undefined || selectedLogValue === null) &&
      (selectedModeValue === undefined || selectedModeValue === null)
    ) {
      alert("Please select mode Type!");
      return false;
    }

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let FileType = 0;

    if (SelectedLogFileType === undefined || SelectedLogFileType === null) {
      FileType = 0;
    } else {
      FileType = SelectedLogFileType.value;
    }

    let ChannelId = 0;

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      ChannelId = 0;
    } else {
      ChannelId = selectedChannelValue.value;
    }

    let ModeId = 0;

    if (selectedModeValue === undefined || selectedModeValue === null) {
      ModeId = 0;
    } else {
      ModeId = selectedModeValue.value;
    }

    setIsLoading(true);

    MaximusAxios.post(
      "api/AuditReport/GetExportRawDataDetailsList",
      {
        ClientID: selectedClientValue.clientID,
        ChannelID: ChannelId,
        ModeID: ModeId,
        FileType: FileType,
        TR_POSTDATE: formatDate(startDate),
        TR_ENDDATE: formatDate(endDate),
      },
      { mode: "cors" }
    )

      .then(function (response) {
        console.log("API Response:", response.data);
        console.log("API Response:", SelectedLogFileType.label);

        const modifiedData = response.data.map((item) => ({
          ...item,
          fileType: SelectedLogFileType.label, // Add the selected FileType as a new column
        }));
        console.log("API Response:", modifiedData);
        setShowDataReports(modifiedData);
        // Log the API response

        // setTitleDateValue(`Report Date : ${formatDate(startDate)} To ${formatDate(endDate)}`);
        setIsLoading(false);

        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "No records found",
          });
        }
      })
      .catch(function (error) {
        setTitleDateValue("");
        console.log(error.response.data);
        setIsLoading(false);
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
      });
  };

  $(document).ready(function () {
    if (ExportRawData !== null && ExportRawData.length > 0) {
      $("#gvExportRawDataPDF").DataTable();
    }
  });

  const ExportToExcel = async () => {
    const workbook = new ExcelJS.Workbook();

    try {
      setIsLoading(true);

      var data = $("#gvExportRawDataPDF")
        .dataTable()
        ._("tr", { filter: "applied" });
      let filterDataExcel = [];
      let cntrow = 0;

      for (let i = 0; i < data.length; i++) {
        var arr = {
          FileDate: data[cntrow][0],
          FileName: data[cntrow][1],
          TxnsCount: data[cntrow][2],
          CREATEDON: data[cntrow][3],
          CreatedBy: data[cntrow][4],
        };
        filterDataExcel.push(arr);
        cntrow++;
      }

      // Create Excel workbook and worksheet
      const worksheet = workbook.addWorksheet("FileStatus");

      // Define columns in the worksheet, these columns are identified using a key.

      worksheet.columns = [
        { header: "FileDate", key: "FileDate" },
        { header: "FileName", key: "FileName" },
        { header: "TxnsCount", key: "TxnsCount" },
        { header: "CREATEDON", key: "CREATEDON" },
        { header: "CreatedBy", key: "CreatedBy" },
      ];

      worksheet.columns = [
        { width: 15 },
        { width: 20 },
        { width: 15 },
        { width: 15 },
        { width: 15 },
      ];

      // loop through all of the columns and set the alignment with width.
      worksheet.columns.forEach((column) => {
        column.alignment = { horizontal: "center" };
      });

      // updated the font for first row.
      worksheet.getRow(1).font = { bold: true, color: { argb: "ffffff" } };

      // loop through data and add each one to worksheet
      filterDataExcel.forEach((singleData) => {
        worksheet.addRow(singleData);
      });

      // Add auto-filter on each column
      //worksheet.autoFilter = 'A1:D1';

      // Process each row for calculations and beautification
      worksheet.eachRow((row, rowNumber) => {
        row.eachCell((cell, colNumber) => {
          if (rowNumber == 1) {
            // First set the background of header row
            cell.fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "df5015" },
            };
          }
          // Set border of each cell
          cell.border = {
            top: { style: "thin" },
            left: { style: "thin" },
            bottom: { style: "thin" },
            right: { style: "thin" },
          };
        });
        //Commit the changed row to the stream
        row.commit();
      });

      //console.log(filterDataExcel);

      var today = new Date();
      var dateHeading =
        today.getDate() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getFullYear() +
        " " +
        today.getHours() +
        "_" +
        today.getMinutes() +
        "_" +
        today.getSeconds();
      // write the content using writeBuffer
      const buf = await workbook.xlsx.writeBuffer();

      // download the processed file
      saveAs(new Blob([buf]), "Raw Data Report " + dateHeading + ".xlsx");

      setIsLoading(false);
    } catch (error) {
      console.error("<<<ERRROR>>>", error);
      console.error("Something Went Wrong", error.message);
    } finally {
      // removing worksheet's instance to create new one
      workbook.removeWorksheet("FileStatus");
    }
  };

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Export Raw Data
        </h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Audit Reports</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Export Raw Data</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="filestatusreportFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="filestatusreportFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#filestatusreportFiltersCollapse"
                aria-expanded="true"
                aria-controls="filestatusreportFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="filestatusreportFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="filestatusreportFiltersHeading"
              data-bs-parent="#filestatusreportFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedClientValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      onChange={handleChannelChange}
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="ddlMode">Mode Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlMode"
                      value={selectedModeValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsModeType.map((x) => ({
                        value: x.modeID,
                        label: x.modeName,
                      }))}
                      onChange={handleModeChange}
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="ddllog">File Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlMode"
                      value={SelectedLogFileType}
                      classNamePrefix="reactSelectBox"
                      options={OptionsFileType.map((x) => ({
                        value: x.id,
                        label: x.logFileName,
                      }))}
                      onChange={handleOptionsLogFileType}
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onSubmit}
                  >
                    Show
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Content */}
      <div className="configLeftBottom">
        {(ShowDataReports === null || ShowDataReports.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        {/* Table */}
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {ShowDataReports !== null && ShowDataReports.length > 0 ? (
              <div>
                <div className="exportButton">
                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltipExcel}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={ExportToExcel}
                    >
                      <img src={ExcelIcon} alt="Excel" />
                    </button>
                  </OverlayTrigger>

                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltip}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={downloadPDF}
                    >
                      <img src={Pdf} alt="Pdf" />
                    </button>
                  </OverlayTrigger>
                </div>
                <div className="tableBorderBox pt-3">
                  <div className="w-100 table-responsive">
                    <div className="table-responsive tableContentBox">
                      <table
                        id="gvFileStatusReportPDF"
                        className="table table-striped table-hover table-borderless align-middle"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th>ID</th>
                            <th scope="col">ChannelID</th>
                            <th scope="col">File type</th>
                            <th scope="col">File Name</th>
                            <th scope="col">Transaction Count</th>
                            <th scope="col">Download</th>
                          </tr>
                        </thead>
                        <tbody>
                          {ShowDataReports.map((p, index) => (
                            <tr key={index}>
                              <td>{index + 1}</td>
                              <td>{p.channelID}</td>
                              <td>{p.fileType}</td>
                              <td>{p.FileName}</td>
                              <td>{p.transactionCount}</td>
                              {chkU() && (
                                <OverlayTrigger
                                  placement="top"
                                  delay={{ show: 150, hide: 400 }}
                                  overlay={renderTooltipExcel}
                                >
                                  <button
                                    type="button"
                                    className="iconButtonBox"
                                    onClick={() => ExportToExcelKS(p)}
                                  >
                                    <img src={ExcelIcon} alt="Excel" />
                                  </button>
                                </OverlayTrigger>
                              )}
                              {chkU() && (
                                <OverlayTrigger
                                  placement="top"
                                  delay={{ show: 150, hide: 400 }}
                                  overlay={renderTooltipCsv}
                                >
                                  <button
                                    type="button"
                                    className="iconButtonBox"
                                    onClick={() => ExportToCsvKS(p)}
                                  >
                                    <img src={CsvIcon} alt="Csv" />
                                  </button>
                                </OverlayTrigger>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        )}
      </div>
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default ExportRawDataMainWindow;
