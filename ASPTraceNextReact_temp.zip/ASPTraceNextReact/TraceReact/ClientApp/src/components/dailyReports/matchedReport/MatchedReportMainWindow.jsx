﻿import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from "react-select/async";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link, useLocation } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import { useSelector } from "react-redux";
import authHeader from "../../../pages/login/services/auth-header";
import { debounce } from "lodash";
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";

import $ from "jquery";
import "jquery/dist/jquery.min.js";

import ExcelJS from "exceljs";
import { saveAs } from "file-saver";

// Images
import Pdf from "../../../images/common/pdf.svg";
import ExcelIcon from "../../../images/common/excel.svg";
import CsvIcon from "../../../images/common/csv.svg";
import jsPDF from "jspdf";
import "jspdf-autotable";

import ReportFilters from "../../common/ReportFilters";
import { formatDate, splitCamelCase } from "../../common/Utils";
import { parse } from "date-fns";
import TransactionDetails from "../../common/TransactionDetails";

const MatchedReportMainWindow = () => {
  let location = useLocation();
  let capitalizedLocation = location.pathname.replace(/\b\w/g, (char) =>
    char.toUpperCase()
  );
  const currentUser = useSelector((state) => state.authReducer);

  const [ReportFilter, setFilters] = useState({
    ClientId: null,
    ChannelId: null,
    ChannelValue: null,
    ModeId: null,
    ModeValue: null,
    TerminalId: null,
    TrnType: null,
    StartDate: null,
    EndDate: null,
  });

  const fetchClientData = (inputValue) => {
    setStartDate(null);
    setEndDate(null);
    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [inputValue, setValue] = useState("0");
  const [selectedValue, setSelectedValue] = useState(null);
  const [titleDate, setTitleDateValue] = useState("");

  const [isShowCardNo, setIsShowCardNo] = useState(false);
  const [isShowTerminalId, setIsShowTerminald] = useState(false);
  const [isShowPStatus, setShowPStatus] = useState(false);

  // handle input change event
  const handleInputChange = (value) => {
    setValue(value);
  };

  const [optionsChannelType, setOptionsChannelTypeValue] = useState([
    { channelID: "0", channelName: "--Select--" },
  ]);

  const [selectedChannelValue, setSelectedChannelValue] = useState(null);

  const [selectedChannelId, setSelectedChannelId] = useState(null);

  const [optionsModeType, setOptionsModeTypeValue] = useState([
    { modeID: "0", modeName: "--Select--" },
  ]);

  const [selectedModeValue, setSelectedModeValue] = useState(null);

  const [optionsTerminalType, setOptionsTerminalValue] = useState([
    { ID: "0", TERMINALID: "All" },
  ]);

  const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

  const [selectedTxnTypeValue, setSelectedTxnTypeValue] = useState(null);

  const [isShowTxnType, setIsShowTxnType] = useState(false);

  const [isShowTerminal, setIsShowTerminal] = useState(false);
  // handle selection
  const [optionsTxnType, setOptionsTxnType] = useState([
    { value: "1", label: "Withdrawal" },
    { value: "2", label: "Deposit" },
  ]);

  const PageSizeOptions = [10, 25, 50, 100];
  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalRecords, setTotalRecords] = useState(0);
  const [Searchbar, setSearchbar] = useState("");

  const handleOptionsChannelType = (value) => {
    setOptionsChannelTypeValue(value);
  };

  const handleOptionsModeType = (value) => {
    setOptionsModeTypeValue(value);
  };

  const handleOptionsTerminalType = (value) => {
    setOptionsTerminalValue(value);
  };

  const handleClientChange = (value) => {
    setMatchedTxnsReport(null);
    setSelectedChannelValue(null);
    setSelectedModeValue(null);
    setSelectedTxnTypeValue(null);
    setSelectedTerminalValue(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedValue(value);

    if (value.clientID !== "0") {
      return MaximusAxios.get(
        "api/Common/GetChannelOptionList?ClientId=" +
          value.clientID +
          "&UserID=" +
          currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsChannelType(result.data);
      });
    }
  };

  // handle selection
  const handleChannelChange = (value) => {
    setMatchedTxnsReport(null);
    setSelectedModeValue(null);
    setSelectedTxnTypeValue(null);
    setSelectedTerminalValue(null);
    setOptionsTxnType(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedChannelValue(value);

    if (value.value === "1") {
      setIsShowTxnType(true);
    } else {
      setIsShowTxnType(false);
    }
    if (value.value === "4" || value.value === "7") {
      setIsShowCardNo(false);
    } else {
      setIsShowCardNo(true);
    }
    if (value.value === "7") {
      setIsShowTerminald(false);
    } else {
      setIsShowTerminald(true);
    }
    if (value.value === "1" || value.value === "4" || value.value === "7") {
      setShowPStatus(false);
    }
    if (
      value.value === "2" ||
      (value.value === "3" && selectedValue.value === "45")
    ) {
      setShowPStatus(true);
    }
    if (
      value.value === "2" ||
      (value.value === "3" && selectedValue.value !== "45")
    ) {
      setShowPStatus(false);
    }

    if (value.value !== "0" && selectedValue.clientID !== "0") {
      return MaximusAxios.get(
        "api/Common/GetModeOptionList?ClientID=" +
          selectedValue.clientID +
          "&ChannelID=" +
          value.value +
          "&UserID=" +
          currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsModeType(result.data);
      });
    }
  };

  const handleModeChange = (value) => {
    if (currentUser !== null && currentUser.user !== null) {
      setMatchedTxnsReport(null);
      setSelectedTxnTypeValue(null);
      setSelectedTerminalValue(null);
      setOptionsTxnType(null);
      //setStartDate(null);
      //setEndDate(null);
      setSelectedModeValue(value);

      if (value.value === "1" || value.value === "2") {
        setIsShowTerminal(true);
        setOptionsTxnType([
          { value: "1", label: "Withdrawal" },
          { value: "2", label: "Deposit" },
        ]);
      } else if (value.value === "3") {
        setIsShowTerminal(true);
        setOptionsTxnType([{ value: "1", label: "Withdrawal" }]);
      } else {
        setIsShowTerminal(false);
        setOptionsTxnType(null);
      }

      if (
        value.value !== "0" &&
        selectedValue.clientID !== "0" &&
        selectedChannelValue.value
      ) {
        return MaximusAxios.get(
          "api/Common/GetTerminalOptionList?ClientID=" +
            selectedValue.clientID +
            "&ChannelID=" +
            selectedChannelValue.value +
            "&UserName=" +
            currentUser.user.username,
          { mode: "cors" }
        ).then((result) => {
          var resData = result.data;

          var myObj = { ID: "0", TERMINALID: "All" };

          resData.push(myObj);

          handleOptionsTerminalType(resData);
        });
      }
    } else {
      alert("Session Timeout");
    }
  };

  const handleTxnTypeChange = (value) => {
    setMatchedTxnsReport(null);
    setSelectedTerminalValue(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedTxnTypeValue(value);
  };

  const handleTerminalChange = (value) => {
    setMatchedTxnsReport(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedTerminalValue(value);
  };

  //   Date Calendar
  const [startDate, setStartDate] = useState(new Date());
  //   Date Calendar
  const [endDate, setEndDate] = useState(new Date());

  const setStartDateValue = (value) => {
    setStartDate(value);
    setMatchedTxnsReport(null);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date ");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    setMatchedTxnsReport(null);
  };

  // Modals

  const [referenceNo, setReferenceNo] = useState(false);

  const [MatchedTxnsReport, setMatchedTxnsReport] = useState(null);

  const [EJTxnList, setEJTxnList] = useState(null);
  const [GLTxnList, setGLTxnList] = useState(null);
  const [NWTxnList, setNWTxnList] = useState(null);
  const [SWTxnList, setSWTxnList] = useState(null);

  const downloadPDF = () => {
    MaximusAxios.post(
      "api/Logger/InsertUserActivityReport",
      {
        UserId: currentUser.user.username,
        PageName: capitalizedLocation,
        Activity: "Download PDF",
      },
      { headers: authHeader() }
    );
    if (MatchedTxnsReport !== null) {
      if (MatchedTxnsReport.length > 0) {
        const title = "Matched Txns Report";

        MaximusAxios.get(
          "api/Common/GetClientLogoImage?ClientId=" + ReportFilter.ClientId,
          { mode: "cors" }
        ).then((result) => {
          const headers = [
            [
              "Channel",
              "Mode",
              "Terminal Id",
              "Txn DateTime",
              "Reference Number",
              "Card Number",
              "Account No",
              "Txn Amount",
              "EJ Status",
              "Switch Status",
              "Network Status",
              "GL Status",
              "Txns Type",
            ],
          ];
          const headers1 = [
            [
              "Channel",
              "Mode",
              "Terminal Id",
              "Txn DateTime",
              "Reference Number",
              "Account No",
              "Txn Amount",
              "EJ Status",
              "Switch Status",
              "Network Status",
              "GL Status",
              "Txns Type",
            ],
          ];
          const headers2 = [
            [
              "Channel",
              "Mode",
              "Txn DateTime",
              "Reference Number",
              "Account No",
              "Txn Amount",
              "EJ Status",
              "Switch Status",
              "Network Status",
              "GL Status",
              "Txns Type",
            ],
          ];

          var dataPDF = $("#gvMatchedTxnsReportPDF")
            .dataTable()
            ._("tr", { filter: "applied" });
          let filterDataPDF = [];
          let cntrow = 0;
          let RefNum = "";
          let cardNumber = "";
          //console.log(dataPDF);
          if (selectedChannelId === "4") {
            for (let i = 0; i < dataPDF.length; i++) {
              RefNum = dataPDF[cntrow][4];
              RefNum = RefNum.replace('<button class="editBox"><u>', "");
              RefNum = RefNum.replace("</u></button>", "");

              var arr = [
                dataPDF[cntrow][0],
                dataPDF[cntrow][1],
                dataPDF[cntrow][2],
                dataPDF[cntrow][3],
                RefNum,
                dataPDF[cntrow][5],
                dataPDF[cntrow][6],
                dataPDF[cntrow][7],
                dataPDF[cntrow][8],
                dataPDF[cntrow][9],
                dataPDF[cntrow][10],
                dataPDF[cntrow][11],
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          } else if (selectedChannelId === "7") {
            for (let i = 0; i < dataPDF.length; i++) {
              RefNum = dataPDF[cntrow][3];
              RefNum = RefNum.replace('<button class="editBox"><u>', "");
              RefNum = RefNum.replace("</u></button>", "");

              var arr = [
                dataPDF[cntrow][0],
                dataPDF[cntrow][1],
                dataPDF[cntrow][2],
                RefNum,
                dataPDF[cntrow][5],
                dataPDF[cntrow][6],
                dataPDF[cntrow][7],
                dataPDF[cntrow][8],
                dataPDF[cntrow][9],
                dataPDF[cntrow][10],
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          } else {
            for (let i = 0; i < dataPDF.length; i++) {
              RefNum = dataPDF[cntrow][4];
              RefNum = RefNum.replace('<button class="editBox"><u>', "");
              RefNum = RefNum.replace("</u></button>", "");

              cardNumber = dataPDF[cntrow][5];
              cardNumber = cardNumber.replace('<p class="tableTextInner">', "");
              cardNumber = cardNumber.replace("</p>", "");

              var arr = [
                dataPDF[cntrow][0],
                dataPDF[cntrow][1],
                dataPDF[cntrow][2],
                dataPDF[cntrow][3],
                RefNum,
                cardNumber,
                dataPDF[cntrow][6],
                dataPDF[cntrow][7],
                dataPDF[cntrow][8],
                dataPDF[cntrow][9],
                dataPDF[cntrow][10],
                dataPDF[cntrow][11],
                dataPDF[cntrow][12],
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          }
          //console.log(filterDataPDF);

          const unit = "pt";
          const size = "LEGAL"; // Use A1, A2, A3 or A4
          const orientation = "landscape"; // portrait or landscape

          const doc = new jsPDF(orientation, unit, size);

          //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
          var pageWidth =
            doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

          //console.log(result);

          doc.addImage(result.data.clientLogo, "PNG", 20, 20, 150, 50);

          doc.addImage(
            result.data.traceLogo,
            "PNG",
            pageWidth - 170,
            20,
            150,
            50
          );

          //doc.setTextColor(100);

          doc.setFontSize(24);

          doc.text(title, pageWidth / 2, 40, { align: "center" });

          doc.setFontSize(20);

          doc.text(titleDate, pageWidth / 2, 65, { align: "center" });
          if (selectedChannelId === "4") {
            let content = {
              startY: 80,
              head: headers1,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          } else if (selectedChannelId === "7") {
            let content = {
              startY: 80,
              head: headers2,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          } else {
            let content = {
              startY: 80,
              head: headers,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          }
          doc.setFontSize(10);
          //doc.autoTable(content);
          doc.save("Matched Txns Report.pdf");
        });
      } else {
        alert("No Record Found");
      }
    } else {
      alert("No Record Found");
    }
  };

  // Tooltip
  const renderTooltip = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to pdf
    </Tooltip>
  );
  const renderTooltipSearch = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Search here
    </Tooltip>
  );

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to excel
    </Tooltip>
  );

  const renderTooltipShow = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to open window
    </Tooltip>
  );

  const onReset = (e) => {
    e.preventDefault();
    window.location.reload(false);
  };
  const updateFilters = (newFilters) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      ...newFilters,
    }));
  };

  const updateReportFilter = (key, value) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      [key]: value,
    }));
    //console.log('fire' + key);
    setMatchedTxnsReport(null);
  };

  const handleSearchChange = debounce((event) => {
    let searchText = event.target.value;
    let Page = 1;
    if (
      searchText !== undefined &&
      searchText !== null &&
      searchText.trim().length !== 0
    ) {
      // alert("Page number")
      setPageNumber(Page);
    } else {
      Page = pageNumber;
    }
    setSearchbar(searchText);
    pagination(Page, searchText);
  }, 3000);

  const handlePageChange = (newPageNumber) => {
    setPageNumber(newPageNumber);
    pagination(newPageNumber, "");
  };

  const totalPages = Math.ceil(totalRecords / pageSize);

  const pagination = (pageNumber, searchText) => {
    setMatchedTxnsReport(null);
    setIsLoading(true);
    MaximusAxios
      .post(
        `api/Report/GetMatchedTxnsList?pageNumber=${pageNumber}&pageSize=${pageSize}`,
        {
          ClientID: String(ReportFilter.ClientId),
          ChannelID: String(ReportFilter.ChannelId),
          ModeID: String(ReportFilter.ModeId),
          TerminalID: String(ReportFilter.TerminalId),
          TxnType: String(ReportFilter.TrnType),
          FromDate: formatDate(ReportFilter.StartDate),
          ToDate: formatDate(ReportFilter.EndDate),
          search: String(searchText),
        },
        {  mode: 'cors' }
      )
      .then((response) => {
        setMatchedTxnsReport(response.data.data);
        console.log(response.data.totalRecords);
        // if (parseInt(response.data.totalRecords , 10) < parseInt(pageSize, 10)) {
        //     //alert("Page size is greater then records");
        //     setPageSize(parseInt(response.data.totalRecords, 10));
        // }
        setTotalRecords(response.data.totalRecords);
        setIsLoading(false);
        if (response.data.Data === "undefined" || response.data.Data === null) {
          alert("No records found");
          setIsLoading(false);
        }
      })
      .catch((error) => {
        console.error("There was an error!", error);
        alert(error);
        setIsLoading(false);
      });
  };

  const Refresh = (pageSize) => {
    alert("refresh "+ pageSize)
    setIsLoading(true);
    MaximusAxios
      .post(
        `api/Report/GetMatchedTxnsList?pageNumber=${pageNumber}&pageSize=${pageSize}`,
        {
          ClientID: String(ReportFilter.ClientId),
          ChannelID: String(ReportFilter.ChannelId),
          ModeID: String(ReportFilter.ModeId),
          TerminalID: String(ReportFilter.TerminalId),
          TxnType: String(ReportFilter.TrnType),
          FromDate: formatDate(ReportFilter.StartDate),
          ToDate: formatDate(ReportFilter.EndDate),
          search: String(Searchbar),
        },
        {  mode: 'cors' }
      )
      .then(function (response) {
        setMatchedTxnsReport (response.data.data);
        setTotalRecords(response.data.totalRecords);
        setTitleDateValue(
          "Report Date : " +
            formatDate(ReportFilter.StartDate) +
            " To " +
            formatDate(endDate)
        );
        setIsLoading(false);
        if (response.data.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "No records found",
          });
        }
      })
      .catch(function (error) {
        setTitleDateValue("");
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        setIsLoading(false);
      });
  };
  
  const handleSelectPageSizeChange = (event) => {
    setPageSize(event.target.value);
    Refresh(event.target.value);
  };
  const onSubmit = () => {
    setSearchbar("");
    setMatchedTxnsReport(null);
   // console.log(ReportFilter);

    if (ReportFilter.ClientId === null || ReportFilter.ClientId === undefined) {
      alert("Please select client!");
      return false;
    }

    if (
      ReportFilter.ChannelId === undefined ||
      ReportFilter.ChannelId === null
    ) {
      alert("Please select Channel!");
      return false;
    }

    if (ReportFilter.ModeId === undefined || ReportFilter.ModeId === null) {
      alert("Please select mode Type!");
      return false;
    }

    let TerminalValue = "0";

    if (ReportFilter.ChannelId === "7") {
      TerminalValue = "0";
    } else {
      if (ReportFilter.ModeId === "1" || ReportFilter.ModeId === "2") {
        if (ReportFilter.TerminalId === undefined || ReportFilter.TerminalId === null) {
          alert("Please select Terminal!");
          return false;
        }
      } else {
        TerminalValue = "0" ;
      }
    }

    let TxnType = "0";

    if (ReportFilter.ChannelId === "1") {
      if (ReportFilter.TrnType === undefined || ReportFilter.TrnType === null) {
        alert("Please select Txn Type!");
        return false;
      }
    } else {
      TxnType = "0";
    }

    if (
      ReportFilter.StartDate === undefined ||
      ReportFilter.StartDate === null
    ) {
      alert("Please enter From Date!");
      return false;
    }

    if (ReportFilter.EndDate === undefined || ReportFilter.EndDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    setIsLoading(true);

    MaximusAxios.post(
      `api/Report/GetMatchedTxnsList?pageNumber=${pageNumber}&pageSize=${pageSize}`,
      {
          ClientID: String(ReportFilter.ClientId),
          ChannelID: String(ReportFilter.ChannelId),
          ModeID: String(ReportFilter.ModeId),
          TerminalID: String(ReportFilter.TerminalId ?? "0"),
          TxnType: String(ReportFilter.TrnType),
          FromDate: formatDate(ReportFilter.StartDate),
          ToDate: formatDate(ReportFilter.EndDate),
          search: String(Searchbar),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setMatchedTxnsReport(response.data.data);
        setTotalRecords(response.data.totalRecords);
        console.log(MatchedTxnsReport)
        setTitleDateValue(
          "Report Date : " +
            formatDate(ReportFilter.StartDate) +
            " To " +
            formatDate(ReportFilter.EndDate)
        );
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "No records found",
          });
        }
      })
      .catch(function (error) {
        setTitleDateValue("");
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        setIsLoading(false);
      });
  };

  const onReferenceNumberClick = (ReferenceNumber, Terminal, TrnDate) => {
    setReferenceNo(true);

  //  setIsLoading(true);

    let TerminalValue = "0";

    if (Terminal === undefined || Terminal === null) {
      TerminalValue = "0";
    } else {
      TerminalValue = Terminal;
    }

    MaximusAxios.post(
      "api/Report/GetMatchedTxnByReferenceNumberList",
      {
        ClientID: ReportFilter.ClientId,
        ChannelID: ReportFilter.ChannelValue,
        ModeID: ReportFilter.ModeValue,
        TerminalID: TerminalValue,
        ReferenceNumber: ReferenceNumber,
        TxnsDateTime: formatDate(
          parse(TrnDate, "dd-MM-yyyy HH:mm:ss", new Date())
        ),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setEJTxnList(response.data.ejTxnDetails);
        setGLTxnList(response.data.glTxnDetails);
        setNWTxnList(response.data.nwTxnDetails);
        setSWTxnList(response.data.swTxnDetails);
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };
  $(document).ready(function () {
    if (
      MatchedTxnsReport !== null &&
      MatchedTxnsReport.length > 0 &&
      !$.fn.DataTable.isDataTable("#gvMatchedTxnsReportPDF")
    ) {
      $("#gvMatchedTxnsReportPDF").DataTable({
        paging: false,
        searching: false,
        ordering: true,
        info: false,
        lengthChange: false,
      });
    }
  });

  // ----------BY KUNDAN

  const ExportToExcelKS = () => {
    MaximusAxios.post(
      "api/Logger/InsertUserActivityReport",
      {
        UserId: currentUser.user.username,
        PageName: capitalizedLocation,
        Activity: "Download Excel",
      },
      { headers: authHeader() }
    );
    if (ReportFilter.ClientId === null || ReportFilter.ClientId === undefined) {
      alert("Please select client!");
      return false;
    }

    if (
      ReportFilter.ChannelId === undefined ||
      ReportFilter.ChannelId === null
    ) {
      alert("Please select Channel!");
      return false;
    }

    if (ReportFilter.ModeId === undefined || ReportFilter.ModeId === null) {
      alert("Please select mode Type!");
      return false;
    }

    let TerminalValue = "0";

    if (ReportFilter.ChannelId === "7") {
      TerminalValue = "0";
    } else {
      if (ReportFilter.ModeId === "1" || ReportFilter.ModeId === "2") {
        if (
          ReportFilter.TerminalId === undefined ||
          ReportFilter.TerminalId === null
        ) {
          alert("Please select Terminal!");
          return false;
        }
      } else {
        TerminalValue = "0";
      }
    }

    let TxnType = "0";

    if (ReportFilter.ChannelId === "1") {
      if (ReportFilter.TrnType === undefined || ReportFilter.TrnType === null) {
        alert("Please select Txn Type!");
        return false;
      }
    } else {
      TxnType = "0";
    }

    if (
      ReportFilter.StartDate === undefined ||
      ReportFilter.StartDate === null
    ) {
      alert("Please enter From Date!");
      return false;
    }

    if (ReportFilter.EndDate === undefined || ReportFilter.EndDate === null) {
      alert("Please enter To Date!");
      return false;
    }
    let FileName =
      "MatchedTxnsReport_" +
      ReportFilter.ChannelValue +
      "_" +
      ReportFilter.ModeValue +
      "_" +
      formatDate(ReportFilter.StartDate) +
      ".xlsx";
    // setIsLoading(true);

    MaximusAxios.post(
      `api/Excel/ExportExcelMatchedTxns?searchText=` + Searchbar,
      {
        ClientID: ReportFilter.ClientId,
        ChannelID: ReportFilter.ChannelId,
        ModeID: ReportFilter.ModeId,
        TerminalID: TerminalValue,
        TxnType: String(ReportFilter.TrnType),
        FromDate: formatDate(ReportFilter.StartDate),
        ToDate: formatDate(ReportFilter.EndDate),
        ChannelName: ReportFilter.ChannelValue,
        ModeName: ReportFilter.ModeValue,
        UserID: currentUser.user.username,
      },
      { responseType: "blob" }
    )
      .then(function (response) {
        saveAs(response.data, FileName);
        // setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        //setIsLoading(false);
      });
  };

  const ExportToCsvKS = () => {
    MaximusAxios.post(
      "api/Logger/InsertUserActivityReport",
      {
        UserId: currentUser.user.username,
        PageName: capitalizedLocation,
        Activity: "Download CSV",
      },
      { headers: authHeader() }
    );
    if (ReportFilter.ClientId === null || ReportFilter.ClientId === undefined) {
      alert("Please select client!");
      return false;
    }

    if (
      ReportFilter.ChannelId === undefined ||
      ReportFilter.ChannelId === null
    ) {
      alert("Please select Channel!");
      return false;
    }

    if (ReportFilter.ModeId === undefined || ReportFilter.ModeId === null) {
      alert("Please select mode Type!");
      return false;
    }

    let TerminalValue = "0";

    if (ReportFilter.ChannelId === "7") {
      TerminalValue = "0";
    } else {
      if (ReportFilter.ModeId === "1" || ReportFilter.ModeId === "2") {
        if (
          ReportFilter.TerminalId === undefined ||
          ReportFilter.TerminalId === null
        ) {
          alert("Please select Terminal!");
          return false;
        }
      } else {
        TerminalValue = "0";
      }
    }

    let TxnType = "0";

    if (ReportFilter.ChannelId === "1") {
      if (ReportFilter.TrnType === undefined || ReportFilter.TrnType === null) {
        alert("Please select Txn Type!");
        return false;
      }
    } else {
      TxnType = "0";
    }

    if (
      ReportFilter.StartDate === undefined ||
      ReportFilter.StartDate === null
    ) {
      alert("Please enter From Date!");
      return false;
    }

    if (ReportFilter.EndDate === undefined || ReportFilter.EndDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let FileName =
      "MatchedTxnsReport_" +
      ReportFilter.ChannelValue +
      "_" +
      ReportFilter.ModeValue +
      "_" +
      formatDate(ReportFilter.StartDate) +
      ".csv";

    //setIsLoading(true);

    MaximusAxios.post(
      `api/Excel/ExportCsvMatchedTxns?searchText=` + Searchbar,
      {
        ClientID: ReportFilter.ClientId,
        ChannelID: ReportFilter.ChannelId,
        ModeID: ReportFilter.ModeId,
        TerminalID: TerminalValue,
        TxnType: String(ReportFilter.TrnType),
        FromDate: formatDate(ReportFilter.StartDate),
        ToDate: formatDate(ReportFilter.EndDate),
        ChannelName: ReportFilter.ChannelValue,
        ModeName: ReportFilter.ModeValue,
        UserID: currentUser.user.username,
      },
      { responseType: "blob" }
    )
      .then(function (response) {
        saveAs(response.data, FileName);
        // setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        // setIsLoading(false);
      });
  };

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Matched Transactions
        </h5>

        <div className="d-flex align-items-center">
          <p className="fontSize12 colorPrimaryDefault">Home</p>

          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Daily Reports</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Matched Transactions</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <ReportFilters
          updateReportFilter={updateReportFilter}
          onSubmit={onSubmit}
          ExportToCsvKS={ExportToCsvKS}
          ExportToExcelKS={ExportToExcelKS}
        />
      </div>

      {/* Bottom Content */}
      <div className="configLeftBottom">
        {(MatchedTxnsReport === null || MatchedTxnsReport.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {/* Table */}
            {MatchedTxnsReport !== null && MatchedTxnsReport.length > 0 ? (
              <div>
              <div
                  className="exportButtonUnmatched"
                  style={{ paddingBottom: "0.3rem" }}
                >
                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltipSearch}
                  >
                    <input
                      type="text"
                      className="ReportSearchBar"
                      placeholder="search"
                      defaultValue={Searchbar}
                      onChange={handleSearchChange}
                    />
                  </OverlayTrigger>

                  {/* <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltipExcel}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={ExportToExcelKS}
                    >
                      <img src={ExcelIcon} alt="Excel" />
                    </button>
                  </OverlayTrigger>

                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltip}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={ExportToCsvKS}
                    >
                      <img src={CsvIcon} alt="csv" />
                    </button>
                  </OverlayTrigger> */}
                </div>
                <div className="tableBorderBox pt-3">
                  <p className="pagesize">Show <select
                    className="pagesize"
                    name="options"
                    id="options"
                    value={pageSize} // Use pageSize here
                    onChange={handleSelectPageSizeChange}
                  >  
                    {PageSizeOptions.map((option, index) => (
                      <option key={index} value={option}>
                        {option}
                      </option>
                    ))}
                  </select> entries</p>
                  <div className="w-100 table-responsive">
                    <div className="table-responsive tableContentBox">
                      <table
                        id="gvMatchedTxnsReportPDF"
                        className="table table-striped table-hover table-borderless align-middle"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            {MatchedTxnsReport.length > 0 &&
                              Object.keys(MatchedTxnsReport[0]).map(
                                (Column) => {
                                  return (
                                    <th scope="col" key={Column}>
                                      {splitCamelCase(Column)}
                                    </th>
                                  );
                                }
                              )}
                          </tr>
                        </thead>
                        <tbody>
                          {MatchedTxnsReport.map((Row, index) => (
                            <tr key={index}>
                              {Object.keys(MatchedTxnsReport[index]).map(
                                (Column) => {
                                  if (Column === "ReferenceNumber") {
                                    return (
                                      <td key={Column}>
                                        <button
                                          className="editBox colorBlack"
                                          onClick={() =>
                                            onReferenceNumberClick(
                                              Row.ReferenceNumber,
                                              Row.TerminalId,
                                              Row.TxnsDateTime
                                            )
                                          }
                                        >
                                          <u>{Row.ReferenceNumber}</u>
                                        </button>
                                      </td>
                                    );
                                  } else {
                                    return <td key={Column}>{Row[Column]}</td>;
                                  }
                                }
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    <div className="pagination-controls">
                      <button
                        className="previousBtn"
                        disabled={pageNumber === 1}
                        onClick={() => handlePageChange(pageNumber - 1)}
                        onMouseEnter={(e) => {
                          e.target.style.transform = "scale(1.05)";
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.transform = "scale(1)";
                        }}
                      >
                        Previous
                      </button>

                      <span className="pageInfo">
                        Page {pageNumber} of {totalPages}
                      </span>

                      <button
                        className="nextBtn"
                        disabled={pageNumber === totalPages}
                        onClick={() => handlePageChange(pageNumber + 1)}
                        onMouseEnter={(e) => {
                          e.target.style.transform = "scale(1.05)";
                        }}
                        onMouseLeave={(e) => {
                          e.target.style.transform = "scale(1)";
                        }}
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        )}
        {/* Save Filters */}
        {referenceNo && (
          <TransactionDetails
            EJTxnList={EJTxnList}
            SWTxnList={SWTxnList}
            GLTxnList={GLTxnList}
            NWTxnList={NWTxnList}
            ReferenceNo={referenceNo}
            setReferenceNo={setReferenceNo}
          />
        )}
      </div>

      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default MatchedReportMainWindow;
