﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import NPCIBulkUploadMainWindow from "./NPCIBulkUploadMainWindow";


const NPCIBulkUpload = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <NPCIBulkUploadMainWindow />
        </div>
    );
};

export default NPCIBulkUpload;
