﻿import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from 'react-select/async';
import { Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL" ;
import * as XLSX from "xlsx";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import { useSelector } from "react-redux";
import authHeader from "../../../pages/login/services/auth-header";


//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

// Images
import Excel from "../../../images/common/excel.svg";
import CsvIcon from "../../../images/common/csv_small.svg";

import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";
import { splitCamelCase } from "../../common/Utils";


const optionsTxnType = [
    { value: "1", label: "Withdrawal" },
    { value: "2", label: "Deposit" },
];

const optionsNPCIBulkUploadType = [
    { value: "0", label: "ALL" },
    { value: "1", label: "TCC" },
    { value: "2", label: "RET" },
];

const NPCIBulkUploadMainWindow = () => {

    const currentUser = useSelector((state) => state.authReducer);

    const fetchClientData = (inputValue) => {

        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];

    //const Show Loader
    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const [inputValue, setValue] = useState('0');

    const [selectedValue, setSelectedValue] = useState(null);

    // handle input change event
    const handleInputChange = value => {
        setValue(value);
    };


    const [optionsChannelType, setOptionsChannelTypeValue] = useState([{ channelID: "0", channelName: "--Select--" }]);

    const [selectedChannelValue, setSelectedChannelValue] = useState(null);

    const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "--Select--" }]);

    const [selectedModeValue, setSelectedModeValue] = useState(null);

    const [optionsTerminalType, setOptionsTerminalValue] = useState([{ ID: "0", TERMINALID: "All" }]);

    const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

    const [selectedTxnTypeValue, setSelectedTxnTypeValue] = useState(null);

    const [selectedNPCIBulkUploadValue, setSelectedNPCIBulkUploadValue] = useState(null);

    const [isShowTxnType, setIsShowTxnType] = useState(false);

    const [isShowTerminal, setIsShowTerminal] = useState(false);
    // handle selection
    const onReset = (e) => {
        e.preventDefault();
       // window.location.reload(false);
       setNPCIBulkUpload(null);
        setSelectedChannelValue(null);
        setSelectedModeValue(null);
        setSelectedTxnTypeValue(null);
        setSelectedTerminalValue(null);
        setSelectedNPCIBulkUploadValue(null);
        setSelectedValue(null);
        setEndDate(null);
        setStartDate(null);
    }
    const handleOptionsChannelType = value => {
        setOptionsChannelTypeValue(value);
    };

    const handleOptionsModeType = value => {
        setOptionsModeTypeValue(value);
    };

    const handleOptionsTerminalType = value => {
        setOptionsTerminalValue(value);
    };


    const handleClientChange = value => {
        setNPCIBulkUpload(null);
        setSelectedChannelValue(null);
        setSelectedModeValue(null);
        setSelectedTxnTypeValue(null);
        setSelectedTerminalValue(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedNPCIBulkUploadValue(null);
        setSelectedValue(value);


        if (value.clientID !== '0') {
            return MaximusAxios.get('api/Common/GetChannelOptionList?ClientId=' + value.clientID + '&UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
                handleOptionsChannelType(result.data);
            });
        }

    }

    // handle selection
    const handleChannelChange = value => {
        setNPCIBulkUpload(null);
        setSelectedModeValue(null);
        setSelectedTxnTypeValue(null);
        setSelectedTerminalValue(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedNPCIBulkUploadValue(null);
        setSelectedChannelValue(value);

        if (value.value === '1') { setIsShowTxnType(true); } else { setIsShowTxnType(false); }

        if (value.value !== '0' && selectedValue.clientID !== '0') {
            return MaximusAxios.get('/api/Common/GetModeOptionList?ClientID=' + selectedValue.clientID + '&ChannelID=' + value.value + '&UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
                handleOptionsModeType(result.data);
            });
        }

    }

    const handleModeChange = value => {

        if (currentUser !== null && currentUser.user !== null) {

            setNPCIBulkUpload(null);
            setSelectedTxnTypeValue(null);
            setSelectedTerminalValue(null);
            //setStartDate(null);
            //setEndDate(null);
            setSelectedNPCIBulkUploadValue(null);
            setSelectedModeValue(value);

            if (value.value === '1' || value.value === '2') { setIsShowTerminal(true); } else { setIsShowTerminal(false); }

            if (value.value !== '0' && selectedValue.clientID !== '0' && selectedChannelValue.value) {
                return MaximusAxios.get('api/Common/GetTerminalOptionList?ClientID=' + selectedValue.clientID + '&ChannelID=' + selectedChannelValue.value + '&UserName=' + currentUser.user.username, {  mode: 'cors' }).then(result => {

                    var resData = result.data;

                    var myObj = { "ID": "0", "TERMINALID": "All" };

                    resData.push(myObj);

                    handleOptionsTerminalType(resData);
                });
            }
        } else {

            alert('Session Timeout');
        }

    }


    const handleTxnTypeChange = value => {

        setSelectedTxnTypeValue(value);
        setNPCIBulkUpload(null);
        setSelectedTerminalValue(null);
        setSelectedNPCIBulkUploadValue(null);

    }


    const handleTerminalChange = value => {
        setNPCIBulkUpload(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedNPCIBulkUploadValue(null);
        setSelectedTerminalValue(value);
    }

    const handleNPCIBulkUploadChange = value => {
        setNPCIBulkUpload(null);
        setSelectedNPCIBulkUploadValue(value);

    }

    //   Date Calendar
    const [startDate, setStartDate] = useState(new Date());
    //   Date Calendar
    const [endDate, setEndDate] = useState(new Date());



    const setStartDateValue = value => {
        setStartDate(value);
        setNPCIBulkUpload(null);
    }

    const setEndDateValue = value => {

        if (startDate === null) {
            setEndDate(null);
            alert('Please enter From date first');
        }
        else {
            if (startDate > value) {
                alert('To date must be greater than From date ');
                setEndDate(null);
            }
            else {
                setEndDate(value);
            }
        }
        setNPCIBulkUpload(null);
    }


    const [NPCIBulkUpload, setNPCIBulkUpload] = useState(null);

    const onSubmit = () => {
        setNPCIBulkUpload(null);

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            alert("Please select Channel!");
            return false;
        }

        if (selectedModeValue === undefined || selectedModeValue === null) {
            alert("Please select mode Type!");
            return false;
        }

        if ((selectedChannelValue !== undefined && selectedChannelValue !== null && selectedChannelValue.value === '1') && (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null)) {
            alert("Please select Txn Type!");
            return false;
        }


        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }


        let ChannelId = '0';

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = '0';
        }
        else {
            ChannelId = selectedChannelValue.value;
        }

        let ModeId = '0';

        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = '0';
        }
        else {
            ModeId = selectedModeValue.value;
        }

        let TxnType = '0';

        if (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null) {
            TxnType = '0';
        }
        else {
            TxnType = selectedTxnTypeValue.label;
        }

        let TerminalValue = '0';

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            TerminalValue = '0';
        }
        else {
            TerminalValue = selectedTerminalValue.value;
        }
        let TxnTypeValue = '';

        if (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null) {
            TxnTypeValue = '';
        }
        else {
            TxnTypeValue = selectedNPCIBulkUploadValue.label;
        }

        let NPCIBulkUploadType = '';

        if (selectedNPCIBulkUploadValue === undefined || selectedNPCIBulkUploadValue === null) {
            NPCIBulkUploadType = '';
        }
        else {
            NPCIBulkUploadType = selectedNPCIBulkUploadValue.value;
        }

        setIsLoading(true);

        MaximusAxios.post('api/AuditReport/GetNPCIBulkUploadDetailsList', {
            ClientID: selectedValue.clientID,
            ChannelID: ChannelId,
            ModeID: ModeId,
            TERMINALID: TerminalValue,
            FromDateTxns: formatDate(startDate),
            ToDateTxns: formatDate(endDate),
            TxnType: TxnTypeValue,
            ReportType: NPCIBulkUploadType

        }, {  mode: 'cors' })
            .then(function (response) {
                setNPCIBulkUpload(response.data);
                setIsLoading(false);
                if (response.data === null || response.data.length === 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'No records found' }); }
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setIsLoading(false);
            });

    };
    const downloadExcel = () => {


        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            alert("Please select Channel!");
            return false;
        }

        if (selectedModeValue === undefined || selectedModeValue === null) {
            alert("Please select mode Type!");
            return false;
        }

        if ((selectedChannelValue !== undefined && selectedChannelValue !== null && selectedChannelValue.value === '1') && (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null)) {
            alert("Please select Txn Type!");
            return false;
        }

        //if ((selectedChannelValue !== undefined && selectedChannelValue !== null && selectedChannelValue.value == '1 ') && (selectedTerminalValue === undefined || selectedTerminalValue === null)) {
        //    alert("Please select Terminal Value!");
        //    return false;
        //}


        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        if (selectedNPCIBulkUploadValue === undefined || selectedNPCIBulkUploadValue === null) {
            alert("Please enter NPCI Bulk Upload!");
            return false;
        }

        let ChannelId = '0';

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = '0';
        }
        else {
            ChannelId = selectedChannelValue.value;
        }

        let ModeId = '0';

        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = '0';
        }
        else {
            ModeId = selectedModeValue.value;
        }

        let TxnTypeValue = '';

        if (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null) {
            TxnTypeValue = '';
        }
        else {
            TxnTypeValue = selectedNPCIBulkUploadValue.label;
        }

        let TerminalValue = '0';

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            TerminalValue = '0';
        }
        else {
            TerminalValue = selectedTerminalValue.value;
        }

        let NPCIBulkUploadType = '';

        if (selectedNPCIBulkUploadValue === undefined || selectedNPCIBulkUploadValue === null) {
            NPCIBulkUploadType = '';
        }
        else {
            NPCIBulkUploadType = selectedNPCIBulkUploadValue.value;
        }

        setIsLoading(true);

        MaximusAxios.post('api/AuditReport/GetNPCIBulkUploadDetailsList', {
            ClientID: selectedValue.clientID,
            ChannelID: ChannelId,
            ModeID: ModeId,
            TERMINALID: TerminalValue,
            FromDateTxns: formatDate(startDate),
            ToDateTxns: formatDate(endDate),
            TxnType: TxnTypeValue,
            ReportType: NPCIBulkUploadType

        }, {  mode: 'cors' })
            .then(function (response) {
                //setNPCIBulkUpload(response.data);
                setIsLoading(false);
                if (response.data === null || response.data.length === 0) {
                    setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: '', alertMessage: 'No records found' });
                }
                else {
                    var data = $("#gvNPCIBulkUploadPDF").dataTable()._('tr', { "filter": "applied" });
                    let filterDataExcel = [];
                    let cntrow = 0;

                    for (let i = 0; i < data.length; i++) {
                        var arr = { "BankAdjRef": data[cntrow][0], "Flag": data[cntrow][1], "ShtDat": data[cntrow][2], "AdjAmt": data[cntrow][3], "ShSer": data[cntrow][4], "ShCrd": data[cntrow][5], "FileName": data[cntrow][6], "Reason": data[cntrow][7], "SpecifyOther": data[cntrow][8] }
                        filterDataExcel.push(arr);
                        cntrow++;
                    }
                    var wb = XLSX.utils.book_new();
                    var ws = XLSX.utils.json_to_sheet(filterDataExcel);
                    XLSX.utils.book_append_sheet(wb, ws);
                    if (NPCIBulkUpload === 'RET' && ChannelId === 'IMPS') {
                        XLSX.writeFile(wb, "IMPSCSV" + startDate.replace("/", "") + ".xlsx");
                    }
                    else if (NPCIBulkUpload === 'TCC' && ChannelId === 'UPI') {
                        XLSX.writeFile(wb, "UPITCC_" + startDate.replace("/", "") + ".xlsx");
                    }
                    else {
                        XLSX.writeFile(wb, "NPCI BulkUpload.xlsx");
                    }

                }
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                console.log(error.response.data);
                setIsLoading(false);
            });

    };


    const ExportToCSV = () => {



        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            alert("Please select Channel!");
            return false;
        }

        if (selectedModeValue === undefined || selectedModeValue === null) {
            alert("Please select mode Type!");
            return false;
        }

        if ((selectedChannelValue !== undefined && selectedChannelValue !== null && selectedChannelValue.value === '1') && (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null)) {
            alert("Please select Txn Type!");
            return false;
        }

        //if ((selectedChannelValue !== undefined && selectedChannelValue !== null && selectedChannelValue.value == '1 ') && (selectedTerminalValue === undefined || selectedTerminalValue === null)) {
        //    alert("Please select Terminal Value!");
        //    return false;
        //}


        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }

        if (selectedNPCIBulkUploadValue === undefined || selectedNPCIBulkUploadValue === null) {
            alert("Please enter NPCI Bulk Upload!");
            return false;
        }

        let ChannelId = '0';

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = '0';
        }
        else {
            ChannelId = selectedChannelValue.value;
        }

        let ModeId = '0';

        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = '0';
        }
        else {
            ModeId = selectedModeValue.value;
        }

        let TxnTypeValue = '';

        if (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null) {
            TxnTypeValue = '';
        }
        else {
            TxnTypeValue = selectedTxnTypeValue.label;
        }

        let TerminalValue = '0';

        if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
            TerminalValue = '0';
        }
        else {
            TerminalValue = selectedTerminalValue.value;
        }

        let NPCIBulkUploadType = '';

        if (selectedNPCIBulkUploadValue === undefined || selectedNPCIBulkUploadValue === null) {
            NPCIBulkUploadType = '';
        }
        else {
            NPCIBulkUploadType = selectedNPCIBulkUploadValue.value;
        }

        //console.log(NPCIBulkUpload);
        //console.log(ChannelId);

        setIsLoading(true);

        MaximusAxios.post('api/AuditReport/GetNPCIBulkUploadDetailsList', {
            ClientID: selectedValue.clientID,
            ChannelID: ChannelId,
            ModeID: ModeId,
            TERMINALID: TerminalValue,
            FromDateTxns: formatDate(startDate),
            ToDateTxns: formatDate(endDate),
            TxnType: TxnTypeValue,
            ReportType: NPCIBulkUploadType

        }, {  mode: 'cors' })
            .then(function (response) {
                //setNPCIBulkUpload(response.data);
                setIsLoading(false);
                if (response.data === null || response.data.length === 0) {
                    setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: '', alertMessage: 'No records found' });
                }
                else {


                    // Convert JSON to worksheet
                    const worksheet = XLSX.utils.json_to_sheet(response.data);

                    // Create a new workbook
                    const workbook = XLSX.utils.book_new();

                    // Append worksheet to workbook
                    XLSX.utils.book_append_sheet(workbook, worksheet, "NPCI");

                    // Generate buffer
                    const csvBuffer = XLSX.write(workbook, { bookType: 'csv', type: 'array' });

                    // Create a blob from the buffer
                    const blob = new Blob([csvBuffer], { type: 'text/csv' });

                    // Create a link element
                    const link = document.createElement('a');

                    if (NPCIBulkUpload === '2' && ChannelId === '4') {
                        link.download = "IMPSCSV" + formatDate(startDate) + ".csv";
                    }
                    else if (NPCIBulkUpload === '1' && ChannelId === '7') {
                        link.download = "UPITCC_" + formatDate(startDate) + ".csv";
                    }
                    else if (NPCIBulkUpload === '2' && ChannelId === '7') {
                        link.download = "UPIRET_" + formatDate(startDate) + ".csv";
                    }
                    else {
                        link.download = "NPCI BulkUpload.csv";
                    }

                    // Create a URL for the blob and set it as the href attribute
                    link.href = URL.createObjectURL(blob);

                    // Append the link to the body
                    document.body.appendChild(link);

                    // Programmatically click the link to trigger the download
                    link.click();

                    // Remove the link from the document
                    document.body.removeChild(link);

                }
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                console.log(error.response.data);
                setIsLoading(false);
            });

    };


    // Tooltip

    const renderTooltipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to excel
        </Tooltip>
    );


    const renderTooltipCSV = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to CSV
        </Tooltip>
    );


    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }



    $(document).ready(function () {

        if (NPCIBulkUpload !== null && NPCIBulkUpload.length > 0) {
            $('#gvNPCIBulkUploadPDF').DataTable();
        }
    });

    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    NPCI Bulk Upload
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Audit Reports</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">NPCI Bulk Upload</p>
                </div>
            </div>

            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="npcibulkuploadFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="npcibulkuploadFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>
                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#npcibulkuploadFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="npcibulkuploadFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="npcibulkuploadFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="npcibulkuploadFiltersHeading"
                            data-bs-parent="#npcibulkuploadFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedChannelValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            onChange={handleChannelChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedModeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.modeName
                                                }
                                            ))}
                                            onChange={handleModeChange}
                                        />
                                    </div>

                                    {isShowTxnType && (
                                        <div className="clientNameSelect col" id="dvTxnType">
                                            <label htmlFor="logType">Txn Type</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                defaultValue={selectedTxnTypeValue}
                                                options={optionsTxnType}
                                                id="ddlTxnType"
                                                onChange={handleTxnTypeChange}
                                                classNamePrefix="reactSelectBox"
                                            />
                                        </div>)}
                                    {isShowTerminal && (
                                        <div className="clientNameSelect col">
                                            <label htmlFor="logType">Terminal</label>
                                            <Select
                                                id="ddlTerminal"
                                                value={selectedTerminalValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsTerminalType.map(x => (
                                                    {
                                                        value: x.ID,
                                                        label: x.TERMINALID
                                                    }
                                                ))}
                                                onChange={handleTerminalChange}
                                            />
                                        </div>)}
                                    <div className="clientNameSelect col">
                                        <label htmlFor="StartDate">From Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                <div
                                                    style={{
                                                        margin: 1,
                                                        display: "flex",
                                                        justifyContent: "center",
                                                    }}
                                                >
                                                    <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                    </button>
                                                    <select
                                                        value={getYear(date)}
                                                        onChange={({ target: { value } }) => changeYear(value)}
                                                    >
                                                        {years.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <select
                                                        value={months[getMonth(date)]}
                                                        onChange={({ target: { value } }) =>
                                                            changeMonth(months.indexOf(value))
                                                        }
                                                    >
                                                        {months.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                    </button>
                                                </div>
                                            )}
                                            selected={startDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setStartDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ToDate">To Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                <div
                                                    style={{
                                                        margin: 1,
                                                        display: "flex",
                                                        justifyContent: "center",
                                                    }}
                                                >
                                                    <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                    </button>
                                                    <select
                                                        value={getYear(date)}
                                                        onChange={({ target: { value } }) => changeYear(value)}
                                                    >
                                                        {years.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <select
                                                        value={months[getMonth(date)]}
                                                        onChange={({ target: { value } }) =>
                                                            changeMonth(months.indexOf(value))
                                                        }
                                                    >
                                                        {months.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                    </button>
                                                </div>
                                            )}
                                            selected={endDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setEndDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>

                                    <div className="clientNameSelect col" id="dvTxnType">
                                        <label htmlFor="npcibulkupload">NPCI Bulk Upload</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            value={selectedNPCIBulkUploadValue}
                                            options={optionsNPCIBulkUploadType}
                                            id="ddlnpcibulkupload"
                                            onChange={handleNPCIBulkUploadChange}
                                            classNamePrefix="reactSelectBox"
                                        />
                                    </div>
                                  

                                    <div className="clientNameSelect col">
                                        <OverlayTrigger
                                            placement="top"
                                            delay={{ show: 150, hide: 400 }}
                                            overlay={renderTooltipExcel}
                                        >
                                            <button type="button" className="iconButtonNPCIBox" onClick={downloadExcel}>
                                                <img src={Excel} alt="Excel" />
                                            </button>
                                        </OverlayTrigger>
                                        <OverlayTrigger
                                            placement="top"
                                            delay={{ show: 150, hide: 400 }}
                                            overlay={renderTooltipCSV}
                                        >
                                            <button type="button" className="iconButtonNPCIBox" onClick={ExportToCSV} >
                                                <img src={CsvIcon} alt="csv" />
                                            </button>
                                        </OverlayTrigger>
                                    </div>
                                </div>
                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onSubmit}
                                        disabled={isShow}
                                    >Show
                                    </button>
                                </div>
                                <div className="text-center">
                                    &nbsp;
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Bottom Content */}
            <div className="configLeftBottom">
                {(NPCIBulkUpload === null || NPCIBulkUpload.length === 0) &&
                    <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div>
                }
                {/* Table */}
                {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
                {(NPCIBulkUpload !== null && NPCIBulkUpload.length > 0) ? (
                    <div>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvNPCIBulkUploadPDF" className="table table-striped table-hover table-borderless align-middle"  >
                                        <thead>
                                            <tr>
                                                {
                                                    Object.keys(NPCIBulkUpload[0]).map((Column) => {
                                                        return (<>
                                                            <th scope="col">{splitCamelCase(Column)}</th>
                                                        </>)
                                                    })
                                                }
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                NPCIBulkUpload.map((Row, index) => {
                                                    return (<tr key={index}>
                                                        {
                                                            Object.keys(NPCIBulkUpload[index]).map((Column) => {
                                                                return (<>
                                                                    <td>{Row[Column]}</td>
                                                                </>)
                                                            })
                                                        }
                                                    </tr>)
                                                })


                                            }
                                        </tbody>
                                        
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
</>
)}
            </div>
            <LoadingSpinner isShow={false} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default NPCIBulkUploadMainWindow;
