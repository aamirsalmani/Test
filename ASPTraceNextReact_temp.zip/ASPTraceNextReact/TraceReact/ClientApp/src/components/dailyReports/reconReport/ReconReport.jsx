import React from "react";
import { useSelector } from "react-redux";
// CSS
import "../../common/traceReport.css";
// Components
import SidebarMain from "../../common/SidebarMain";
import ReconMainWindow from "./ReconMainWindow";
import "../unmatchedReport/UnmatchedReport.css";

const ReconReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            <ReconMainWindow />
        </div>
    );
};

export default ReconReport;
