import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import ReportCheckerMainWindow from "./ReportCheckerMainWindow";


const ReportChecker = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <ReportCheckerMainWindow />
        </div>
    );
};

export default ReportChecker;