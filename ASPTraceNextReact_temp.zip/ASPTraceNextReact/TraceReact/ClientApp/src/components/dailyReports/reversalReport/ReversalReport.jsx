﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import ReversalReportMainWindow from "./ReversalReportMainWindow";

const ReversalReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <ReversalReportMainWindow />
        </div>
    );
};

export default ReversalReport;
