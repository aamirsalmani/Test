﻿import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from "react-select/async";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import { useSelector } from "react-redux";
import authHeader from "../../../pages/login/services/auth-header";

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";

import $ from "jquery";
import "jquery/dist/jquery.min.js";

import ExcelJS from "exceljs";
import { saveAs } from "file-saver";

import { getYear, getMonth } from "date-fns";

// Images
import Pdf from "../../../images/common/pdf.svg";
import ExcelIcon from "../../../images/common/excel.svg";

import jsPDF from "jspdf";
import "jspdf-autotable";

import ReportFilters from "../../common/ReportFilters";
import { formatDate, splitCamelCase } from "../../common/Utils";
import { parse } from "date-fns";
import TransactionDetails from "../../common/TransactionDetails";

const ReversalReportMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const fetchClientData = (inputValue) => {
    setStartDate(null);
    setEndDate(null);
    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { headers: authHeader(), mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [inputValue, setValue] = useState("0");
  const [selectedValue, setSelectedValue] = useState(null);
  const [titleDate, setTitleDateValue] = useState("");

  const [isShowCardNo, setIsShowCardNo] = useState(false);
  const [isShowTerminalId, setIsShowTerminald] = useState(false);

  // handle input change event
  const handleInputChange = (value) => {
    setValue(value);
  };

  const [optionsChannelType, setOptionsChannelTypeValue] = useState([
    { channelID: "0", channelName: "--Select--" },
  ]);

  const [selectedChannelValue, setSelectedChannelValue] = useState(null);

  const [selectedChannelId, setSelectedChannelId] = useState(null);

  const [optionsModeType, setOptionsModeTypeValue] = useState([
    { modeID: "0", modeName: "--Select--" },
  ]);

  const [selectedModeValue, setSelectedModeValue] = useState(null);

  const [optionsTerminalType, setOptionsTerminalValue] = useState([
    { ID: "0", TERMINALID: "All" },
  ]);

  const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

  const [selectedTxnTypeValue, setSelectedTxnTypeValue] = useState(null);

  const [isShowTxnType, setIsShowTxnType] = useState(false);

  const [isShowTerminal, setIsShowTerminal] = useState(false);
  // handle selection

  const [optionsTxnType, setOptionsTxnType] = useState([
    { value: "1", label: "Withdrawal" },
    { value: "2", label: "Deposit" },
  ]);

  const handleOptionsChannelType = (value) => {
    setOptionsChannelTypeValue(value);
  };

  const handleOptionsModeType = (value) => {
    setOptionsModeTypeValue(value);
  };

  const handleOptionsTerminalType = (value) => {
    setOptionsTerminalValue(value);
  };

  const handleClientChange = (value) => {
    setReversalTxnsReport(null);
    setSelectedChannelValue(null);
    setSelectedModeValue(null);
    setSelectedTxnTypeValue(null);
    setSelectedTerminalValue(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedValue(value);

    if (value.clientID !== "0") {
      return MaximusAxios.get(
        "api/Common/GetChannelOptionList?ClientId=" +
          value.clientID +
          "&UserID=" +
          currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsChannelType(result.data);
      });
    }
  };

  // handle selection
  const handleChannelChange = (value) => {
    setReversalTxnsReport(null);
    setSelectedModeValue(null);
    setSelectedTxnTypeValue(null);
    setSelectedTerminalValue(null);
    setOptionsTxnType(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedChannelValue(value);

    if (value.value === "1") {
      setIsShowTxnType(true);
    } else {
      setIsShowTxnType(false);
    }

    if (value.value === "4" || value.value === "7") {
      setIsShowCardNo(false);
    } else {
      setIsShowCardNo(true);
    }
    if (value.value === "7") {
      setIsShowTerminald(false);
    } else {
      setIsShowTerminald(true);
    }

    if (value.value !== "0" && selectedValue.clientID !== "0") {
      return MaximusAxios.get(
        "api/Common/GetModeOptionList?ClientID=" +
          selectedValue.clientID +
          "&ChannelID=" +
          value.value +
          "&UserID=" +
          currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsModeType(result.data);
      });
    }
  };

  const handleModeChange = (value) => {
    if (currentUser !== null && currentUser.user !== null) {
      setReversalTxnsReport(null);
      setSelectedTxnTypeValue(null);
      setSelectedTerminalValue(null);
      setOptionsTxnType(null);
      //setStartDate(null);
      //setEndDate(null);
      setSelectedModeValue(value);

      if (value.value === "1" || value.value === "2") {
        setIsShowTerminal(true);
        setOptionsTxnType([
          { value: "1", label: "Withdrawal" },
          { value: "2", label: "Deposit" },
        ]);
      } else if (value.value === "3") {
        setIsShowTerminal(true);
        setOptionsTxnType([{ value: "1", label: "Withdrawal" }]);
      } else {
        setIsShowTerminal(false);
        setOptionsTxnType(null);
      }

      if (
        value.value !== "0" &&
        selectedValue.clientID !== "0" &&
        selectedChannelValue.value
      ) {
        return MaximusAxios.get(
          "api/Common/GetTerminalOptionList?ClientID=" +
            selectedValue.clientID +
            "&ChannelID=" +
            selectedChannelValue.value +
            "&UserName=" +
            currentUser.user.username,
          { mode: "cors" }
        ).then((result) => {
          var resData = result.data;

          var myObj = { ID: "0", TERMINALID: "All" };

          resData.push(myObj);

          handleOptionsTerminalType(resData);
        });
      }
    } else {
      alert("Session Timeout");
    }
  };

  const handleTxnTypeChange = (value) => {
    setReversalTxnsReport(null);
    setSelectedTerminalValue(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedTxnTypeValue(value);
  };

  const handleTerminalChange = (value) => {
    setReversalTxnsReport(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedTerminalValue(value);
  };
  //   Date Calendar
  const [startDate, setStartDate] = useState(new Date());
  //   Date Calendar
  const [endDate, setEndDate] = useState(new Date());

  const setStartDateValue = (value) => {
    setStartDate(value);
    setReversalTxnsReport(null);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date ");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    setReversalTxnsReport(null);
  };

  const [ReportFilter, setFilters] = useState({
    ClientId: null,
    ChannelId: null,
    ChannelValue: null,
    ModeId: null,
    ModeValue: null,
    TerminalId: null,
    TrnType: null,
    StartDate: null,
    EndDate: null,
  });

  // Modals

  const [referenceNo, setReferenceNo] = useState(false);

  const [ReversalTxnsReport, setReversalTxnsReport] = useState(null);

  let searchValue = "";

  const [EJTxnList, setEJTxnList] = useState(null);
  const [GLTxnList, setGLTxnList] = useState(null);
  const [NWTxnList, setNWTxnList] = useState(null);
  const [SWTxnList, setSWTxnList] = useState(null);

  const downloadPDF = () => {
    if (ReversalTxnsReport !== null) {
      if (ReversalTxnsReport.length > 0) {
        MaximusAxios.get(
          "api/Common/GetClientLogoImage?ClientId=" + selectedValue.clientID,
          { mode: "cors" }
        ).then((result) => {
          const title = "Reversal Txns Report";
          const headers = [
            [
              "Channel",
              "Mode",
              "Terminal Id",
              "Txn DateTime",
              "Reference Number",
              "Card Number",
              "Account No",
              "Txn Amount",
              "EJ Status",
              "Switch Status",
              "Network Status",
              "GL Status",
              "Txns Type",
            ],
          ];
          const headers1 = [
            [
              "Channel",
              "Mode",
              "Terminal Id",
              "Txn DateTime",
              "Reference Number",
              "Account No",
              "Txn Amount",
              "EJ Status",
              "Switch Status",
              "Network Status",
              "GL Status",
              "Txns Type",
            ],
          ];
          const headers2 = [
            [
              "Channel",
              "Mode",
              "Txn DateTime",
              "Reference Number",
              "Account No",
              "Txn Amount",
              "EJ Status",
              "Switch Status",
              "Network Status",
              "GL Status",
              "Txns Type",
            ],
          ];

          var dataPDF = $("#gvReversalTxnsReportPDF")
            .dataTable()
            ._("tr", { filter: "applied" });
          let filterDataPDF = [];
          let cntrow = 0;
          let RefNum = "";
          let cardNumber = "";
          //console.log(dataPDF);

          if (selectedChannelId === "4") {
            for (let i = 0; i < dataPDF.length; i++) {
              RefNum = dataPDF[cntrow][4];
              RefNum = RefNum.replace('<button class="editBox"><u>', "");
              RefNum = RefNum.replace("</u></button>", "");

              var arr = [
                dataPDF[cntrow][0],
                dataPDF[cntrow][1],
                dataPDF[cntrow][2],
                dataPDF[cntrow][3],
                RefNum,
                dataPDF[cntrow][5],
                dataPDF[cntrow][6],
                dataPDF[cntrow][7],
                dataPDF[cntrow][8],
                dataPDF[cntrow][9],
                dataPDF[cntrow][10],
                dataPDF[cntrow][11],
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          } else if (selectedChannelId === "7") {
            for (let i = 0; i < dataPDF.length; i++) {
              RefNum = dataPDF[cntrow][3];
              RefNum = RefNum.replace('<button class="editBox"><u>', "");
              RefNum = RefNum.replace("</u></button>", "");

              var arr = [
                dataPDF[cntrow][0],
                dataPDF[cntrow][1],
                dataPDF[cntrow][2],
                RefNum,
                dataPDF[cntrow][4],
                dataPDF[cntrow][5],
                dataPDF[cntrow][6],
                dataPDF[cntrow][7],
                dataPDF[cntrow][8],
                dataPDF[cntrow][9],
                dataPDF[cntrow][10],
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          } else {
            for (let i = 0; i < dataPDF.length; i++) {
              RefNum = dataPDF[cntrow][4];
              RefNum = RefNum.replace('<button class="editBox"><u>', "");
              RefNum = RefNum.replace("</u></button>", "");

              cardNumber = dataPDF[cntrow][5];
              cardNumber = cardNumber.replace('<p class="tableTextInner">', "");
              cardNumber = cardNumber.replace("</p>", "");

              var arr = [
                dataPDF[cntrow][0],
                dataPDF[cntrow][1],
                dataPDF[cntrow][2],
                dataPDF[cntrow][3],
                RefNum,
                cardNumber,
                dataPDF[cntrow][6],
                dataPDF[cntrow][7],
                dataPDF[cntrow][8],
                dataPDF[cntrow][9],
                dataPDF[cntrow][10],
                dataPDF[cntrow][11],
                dataPDF[cntrow][12],
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          }

          const unit = "pt";
          const size = "LEGAL"; // Use A1, A2, A3 or A4
          const orientation = "landscape"; // portrait or landscape

          const doc = new jsPDF(orientation, unit, size);

          //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
          var pageWidth =
            doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

          //console.log(result);

          doc.addImage(result.data.clientLogo, "PNG", 20, 20, 150, 50);

          doc.addImage(
            result.data.traceLogo,
            "PNG",
            pageWidth - 170,
            20,
            150,
            50
          );

          //doc.setTextColor(100);

          doc.setFontSize(24);

          doc.text(title, pageWidth / 2, 40, { align: "center" });

          doc.setFontSize(20);

          doc.text(titleDate, pageWidth / 2, 65, { align: "center" });

          if (selectedChannelId === "4") {
            let content = {
              startY: 80,
              head: headers1,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          } else if (selectedChannelId === "7") {
            let content = {
              startY: 80,
              head: headers2,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          } else {
            let content = {
              startY: 80,
              head: headers,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          }

          doc.setFontSize(10);
          //doc.autoTable(content);
          doc.save("Reversal Txns Report.pdf");
        });
      } else {
        alert("No Record Found");
      }
    } else {
      alert("No Record Found");
    }
  };

  // Tooltip
  const renderTooltip = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to pdf
    </Tooltip>
  );

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to excel
    </Tooltip>
  );

  const renderTooltipShow = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to open window
    </Tooltip>
  );

  const onReset = (e) => {
    e.preventDefault();
    window.location.reload(false);
  };
  const updateFilters = (newFilters) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      ...newFilters,
    }));
  };

  const updateReportFilter = (key, value) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      [key]: value,
    }));
    //console.log('fire' + key);
    setReversalTxnsReport(null);
  };

  const onSubmit = () => {
    setReversalTxnsReport(null);

    console.log(ReportFilter);

    if (ReportFilter.ClientId === null || ReportFilter.ClientId === undefined) {
      alert("Please select client!");
      return false;
    }

    if (
      ReportFilter.ChannelId === undefined ||
      ReportFilter.ChannelId === null
    ) {
      alert("Please select Channel!");
      return false;
    }

    if (ReportFilter.ModeId === undefined || ReportFilter.ModeId === null) {
      alert("Please select mode Type!");
      return false;
    }

    let TerminalValue = "0";

    if (ReportFilter.ChannelId === "7") {
      TerminalValue = "0";
    } else {
      if (ReportFilter.ModeId === "1" || ReportFilter.ModeId === "2") {
        if (
          ReportFilter.TerminalId === undefined ||
          ReportFilter.TerminalId === null
        ) {
          alert("Please select Terminal!");
          return false;
        }
      } else {
        TerminalValue = "0";
      }
    }

    let TxnType = "0";

    if (ReportFilter.ChannelId === "1") {
      if (ReportFilter.TrnType === undefined || ReportFilter.TrnType === null) {
        alert("Please select Txn Type!");
        return false;
      }
    } else {
      TxnType = "0";
    }

    if (
      ReportFilter.StartDate === undefined ||
      ReportFilter.StartDate === null
    ) {
      alert("Please enter From Date!");
      return false;
    }

    if (ReportFilter.EndDate === undefined || ReportFilter.EndDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    setIsLoading(true);
    setSelectedChannelId(ReportFilter.ChannelId);

    MaximusAxios.post(
      "api/Report/GetReversalTxnsList",
      {
        ClientID: ReportFilter.ClientId,
        ChannelID: ReportFilter.ChannelId,
        ModeID: ReportFilter.ModeId,
        TerminalID: TerminalValue,
        FromDate: formatDate(ReportFilter.StartDate),
        ToDate: formatDate(ReportFilter.EndDate),
        TxnType: String(ReportFilter.TrnType),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setReversalTxnsReport(response.data);
        setTitleDateValue(
          "Report Date : " +
            formatDate(ReportFilter.StartDate) +
            " To " +
            formatDate(ReportFilter.EndDate)
        );
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "No records found",
          });
        }
      })
      .catch(function (error) {
        setTitleDateValue("");
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  const onReferenceNumberClick = (ReferenceNumber, Terminal, TrnDate) => {
    setReferenceNo(true);

    setIsLoading(true);

    let TerminalValue = "0";

    if (Terminal === undefined || Terminal === null) {
      TerminalValue = "0";
    } else {
      TerminalValue = Terminal;
    }

    MaximusAxios.post(
      "api/Report/GetUnmatchedTxnByReferenceNumberList",
      {
        ClientID: ReportFilter.selectedClientValue.clientID,
        ChannelID: ReportFilter.ChannelValue,
        ModeID: ReportFilter.ModeValue,
        TerminalID: TerminalValue,
        ReferenceNumber: ReferenceNumber,
        TxnsDateTime: formatDate(
          parse(TrnDate, "dd-MM-yyyy HH:mm:ss", new Date())
        ),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setEJTxnList(response.data.ejTxnDetails);
        setGLTxnList(response.data.glTxnDetails);
        setNWTxnList(response.data.nwTxnDetails);
        setSWTxnList(response.data.swTxnDetails);
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  $(document).ready(function () {
    if (ReversalTxnsReport !== null && ReversalTxnsReport.length > 0) {
      $("#gvReversalTxnsReportPDF").DataTable();
    }
  });

  const ExportToExcel = async () => {
    const workbook = new ExcelJS.Workbook();

    try {
      setIsLoading(true);

      var data = $("#gvReversalTxnsReportPDF")
        .dataTable()
        ._("tr", { filter: "applied" });
      let filterDataExcel = [];
      let cntrow = 0;
      let RefNum = "";
      let cardNumber = "";

      if (selectedChannelId === "4") {
        for (let i = 0; i < data.length; i++) {
          RefNum = data[cntrow][4];
          RefNum = RefNum.replace('<button class="editBox"><u>', "");
          RefNum = RefNum.replace("</u></button>", "");

          var arr = {
            Channel: data[cntrow][0],
            Mode: data[cntrow][1],
            TerminalId: data[cntrow][2],
            TxnDateTime: data[cntrow][3],
            ReferenceNumber: RefNum,
            AccountNo: data[cntrow][5],
            TxnAmount: data[cntrow][6],
            EJStatus: data[cntrow][7],
            SwitchStatus: data[cntrow][8],
            NetworkStatus: data[cntrow][9],
            GLStatus: data[cntrow][10],
            TxnsType: data[cntrow][11],
          };
          filterDataExcel.push(arr);
          cntrow++;
        }
      } else if (selectedChannelId === "7") {
        for (let i = 0; i < data.length; i++) {
          RefNum = data[cntrow][3];
          RefNum = RefNum.replace('<button class="editBox"><u>', "");
          RefNum = RefNum.replace("</u></button>", "");

          var arr = {
            Channel: data[cntrow][0],
            Mode: data[cntrow][1],
            TxnDateTime: data[cntrow][2],
            ReferenceNumber: RefNum,
            AccountNo: data[cntrow][4],
            TxnAmount: data[cntrow][5],
            EJStatus: data[cntrow][6],
            SwitchStatus: data[cntrow][7],
            NetworkStatus: data[cntrow][8],
            GLStatus: data[cntrow][9],
            TxnsType: data[cntrow][10],
          };
          filterDataExcel.push(arr);
          cntrow++;
        }
      } else {
        for (let i = 0; i < data.length; i++) {
          RefNum = data[cntrow][4];
          RefNum = RefNum.replace('<button class="editBox"><u>', "");
          RefNum = RefNum.replace("</u></button>", "");

          cardNumber = data[cntrow][5];
          cardNumber = cardNumber.replace('<p class="tableTextInner">', "");
          cardNumber = cardNumber.replace("</p>", "");

          var arr = {
            Channel: data[cntrow][0],
            Mode: data[cntrow][1],
            TerminalId: data[cntrow][2],
            TxnDateTime: data[cntrow][3],
            ReferenceNumber: RefNum,
            CardNumber: cardNumber,
            AccountNo: data[cntrow][6],
            TxnAmount: data[cntrow][7],
            EJStatus: data[cntrow][8],
            SwitchStatus: data[cntrow][9],
            NetworkStatus: data[cntrow][10],
            GLStatus: data[cntrow][11],
            TxnsType: data[cntrow][12],
          };
          filterDataExcel.push(arr);
          cntrow++;
        }
      }

      // Create Excel workbook and worksheet
      const worksheet = workbook.addWorksheet("Reversal");

      // Define columns in the worksheet, these columns are identified using a key.
      if (selectedChannelId === "4") {
        worksheet.columns = [
          { header: "Channel", key: "Channel" },
          { header: "Mode", key: "Mode" },
          { header: "Terminal Id", key: "TerminalId" },
          { header: "Date & Time", key: "TxnDateTime" },
          { header: "Reference No.", key: "ReferenceNumber" },
          { header: "Account No.", key: "AccountNo" },
          { header: "Txn Amount", key: "TxnAmount" },
          { header: "EJ Status", key: "EJStatus" },
          { header: "Switch Status", key: "SwitchStatus" },
          { header: "Network Status", key: "NetworkStatus" },
          { header: "GL Status", key: "GLStatus" },
          { header: "Txns Type", key: "TxnsType" },
        ];

        worksheet.columns = [
          { width: 10 },
          { width: 10 },
          { width: 15 },
          { width: 22 },
          { width: 20 },
          { width: 25 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
        ];
      } else if (selectedChannelId === "7") {
        worksheet.columns = [
          { header: "Channel", key: "Channel" },
          { header: "Mode", key: "Mode" },
          { header: "Date & Time", key: "TxnDateTime" },
          { header: "Reference No.", key: "ReferenceNumber" },
          { header: "Account No.", key: "AccountNo" },
          { header: "Txn Amount", key: "TxnAmount" },
          { header: "EJ Status", key: "EJStatus" },
          { header: "Switch Status", key: "SwitchStatus" },
          { header: "Network Status", key: "NetworkStatus" },
          { header: "GL Status", key: "GLStatus" },
          { header: "Txns Type", key: "TxnsType" },
        ];

        worksheet.columns = [
          { width: 10 },
          { width: 10 },
          { width: 15 },
          { width: 22 },
          { width: 25 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
        ];
      } else {
        worksheet.columns = [
          { header: "Channel", key: "Channel" },
          { header: "Mode", key: "Mode" },
          { header: "Terminal Id", key: "TerminalId" },
          { header: "Date & Time", key: "TxnDateTime" },
          { header: "Reference No.", key: "ReferenceNumber" },
          { header: "Card No.", key: "CardNumber" },
          { header: "Account No.", key: "AccountNo" },
          { header: "Txn Amount", key: "TxnAmount" },
          { header: "EJ Status", key: "EJStatus" },
          { header: "Switch Status", key: "SwitchStatus" },
          { header: "Network Status", key: "NetworkStatus" },
          { header: "GL Status", key: "GLStatus" },
          { header: "Txns Type", key: "TxnsType" },
        ];

        worksheet.columns = [
          { width: 10 },
          { width: 10 },
          { width: 15 },
          { width: 22 },
          { width: 20 },
          { width: 20 },
          { width: 25 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
        ];
      }

      // loop through all of the columns and set the alignment with width.
      worksheet.columns.forEach((column) => {
        column.alignment = { horizontal: "center" };
      });

      worksheet.columns.forEach((column) => {
        if (selectedChannelId === "4") {
          if (column._number === 7) {
            column.alignment = { horizontal: "right" };
          }
        } else if (selectedChannelId === "7") {
          if (column._number === 6) {
            column.alignment = { horizontal: "right" };
          }
        } else {
          if (column._number === 8) {
            column.alignment = { horizontal: "right" };
          }
        }
      });

      // updated the font for first row.
      worksheet.getRow(1).font = { bold: true, color: { argb: "ffffff" } };

      // loop through data and add each one to worksheet
      filterDataExcel.forEach((singleData) => {
        worksheet.addRow(singleData);
      });

      // Add auto-filter on each column
      //worksheet.autoFilter = 'A1:D1';

      // Process each row for calculations and beautification
      worksheet.eachRow((row, rowNumber) => {
        row.eachCell((cell, colNumber) => {
          if (rowNumber === 1) {
            // First set the background of header row
            cell.fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "df5015" },
            };
          }
          // Set border of each cell
          cell.border = {
            top: { style: "thin" },
            left: { style: "thin" },
            bottom: { style: "thin" },
            right: { style: "thin" },
          };
        });
        //Commit the changed row to the stream
        row.commit();
      });

      //console.log(filterDataExcel);

      var today = new Date();
      var dateHeading =
        today.getDate() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getFullYear() +
        " " +
        today.getHours() +
        "_" +
        today.getMinutes() +
        "_" +
        today.getSeconds();
      // write the content using writeBuffer
      const buf = await workbook.xlsx.writeBuffer();

      // download the processed file
      saveAs(
        new Blob([buf]),
        "Reversal Transaction Report " + dateHeading + ".xlsx"
      );

      setIsLoading(false);
    } catch (error) {
      console.error("<<<ERRROR>>>", error);
      console.error("Something Went Wrong", error.message);
    } finally {
      // removing worksheet's instance to create new one
      workbook.removeWorksheet("Reversal");
    }
  };

  // ----------BY KUNDAN
  const ExportToExcelKS = () => {
    if (ReportFilter.ClientId === null || ReportFilter.ClientId === undefined) {
      alert("Please select client!");
      return false;
    }

    if (
      ReportFilter.ChannelId === undefined ||
      ReportFilter.ChannelId === null
    ) {
      alert("Please select Channel!");
      return false;
    }

    if (ReportFilter.ModeId === undefined || ReportFilter.ModeId === null) {
      alert("Please select mode Type!");
      return false;
    }

    let TerminalValue = "0";

    if (ReportFilter.ChannelId === "7") {
      TerminalValue = "0";
    } else {
      if (ReportFilter.ModeId === "1" || ReportFilter.ModeId === "2") {
        if (
          ReportFilter.TerminalId === undefined ||
          ReportFilter.TerminalId === null
        ) {
          alert("Please select Terminal!");
          return false;
        }
      } else {
        TerminalValue = "0";
      }
    }

    let TxnType = "0";

    if (ReportFilter.ChannelId === "1") {
      if (ReportFilter.TrnType === undefined || ReportFilter.TrnType === null) {
        alert("Please select Txn Type!");
        return false;
      }
    } else {
      TxnType = "0";
    }

    if (
      ReportFilter.StartDate === undefined ||
      ReportFilter.StartDate === null
    ) {
      alert("Please enter From Date!");
      return false;
    }

    if (ReportFilter.EndDate === undefined || ReportFilter.EndDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let FileName =
      "ReversalTxnsReport_" +
      ReportFilter.ChannelValue +
      "_" +
      ReportFilter.ModeValue +
      "_" +
      formatDate(ReportFilter.StartDate) +
      ".xlsx";
    // setIsLoading(true);

    MaximusAxios.post(
      "api/Excel/ExportExcelReversalTxns",
      {
        ClientID: ReportFilter.ClientId,
        ChannelID: ReportFilter.ChannelId,
        ModeID: ReportFilter.ModeId,
        TerminalID: TerminalValue,
        TxnType: String(ReportFilter.TrnType),
        FromDate: formatDate(ReportFilter.StartDate),
        ToDate: formatDate(ReportFilter.EndDate),
        ChannelName: ReportFilter.ChannelValue,
        ModeName: ReportFilter.ModeValue,
        UserID: currentUser.user.username,
      },
      { responseType: "blob" }
    )
      .then(function (response) {
        saveAs(response.data, FileName);
        // setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        // setIsLoading(false);
      });
  };

  const ExportToCsvKS = () => {
    if (ReportFilter.ClientId === null || ReportFilter.ClientId === undefined) {
      alert("Please select client!");
      return false;
    }

    if (
      ReportFilter.ChannelId === undefined ||
      ReportFilter.ChannelId === null
    ) {
      alert("Please select Channel!");
      return false;
    }

    if (ReportFilter.ModeId === undefined || ReportFilter.ModeId === null) {
      alert("Please select mode Type!");
      return false;
    }

    let TerminalValue = "0";

    if (ReportFilter.ChannelId === "7") {
      TerminalValue = "0";
    } else {
      if (ReportFilter.ModeId === "1" || ReportFilter.ModeId === "2") {
        if (
          ReportFilter.TerminalId === undefined ||
          ReportFilter.TerminalId === null
        ) {
          alert("Please select Terminal!");
          return false;
        }
      } else {
        TerminalValue = "0";
      }
    }

    let TxnType = "0";

    if (ReportFilter.ChannelId === "1") {
      if (ReportFilter.TrnType === undefined || ReportFilter.TrnType === null) {
        alert("Please select Txn Type!");
        return false;
      }
    } else {
      TxnType = "0";
    }

    if (
      ReportFilter.StartDate === undefined ||
      ReportFilter.StartDate === null
    ) {
      alert("Please enter From Date!");
      return false;
    }

    if (ReportFilter.EndDate === undefined || ReportFilter.EndDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let FileName =
      "ReversalTxnsReport_" +
      ReportFilter.ChannelValue +
      "_" +
      ReportFilter.ModeValue +
      "_" +
      formatDate(ReportFilter.StartDate) +
      ".csv";
    // setIsLoading(true);

    MaximusAxios.post(
      "api/Excel/ExportCsvReversalTxns",
      {
        ClientID: ReportFilter.ClientId,
        ChannelID: ReportFilter.ChannelId,
        ModeID: ReportFilter.ModeId,
        TerminalID: TerminalValue,
        TxnType: String(ReportFilter.TrnType),
        FromDate: formatDate(ReportFilter.StartDate),
        ToDate: formatDate(ReportFilter.EndDate),
        ChannelName: ReportFilter.ChannelValue,
        ModeName: ReportFilter.ModeValue,
        UserID: currentUser.user.username,
      },
      { responseType: "blob" }
    )
      .then(function (response) {
        saveAs(response.data, FileName);
        //setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        //setIsLoading(false);
      });
  };

  // ----------BY KUNDAN

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Reversal Transactions
        </h5>

        <div className="d-flex align-items-center">
          <p className="fontSize12 colorPrimaryDefault">Home</p>

          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Daily Reports</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Reversal Transactions</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <ReportFilters
          updateReportFilter={updateReportFilter}
          onSubmit={onSubmit}
          ExportToCsvKS={ExportToCsvKS}
          ExportToExcelKS={ExportToExcelKS}
        />
      </div>

      {/* Bottom Content */}
      <div className="configLeftBottom">
        {(ReversalTxnsReport === null || ReversalTxnsReport.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {/* Table */}
            {ReversalTxnsReport !== null && ReversalTxnsReport.length > 0 ? (
              <div>
                <div className="exportButton">
                  {/* <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltipExcel}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={ExportToExcel}
                    >
                      <img src={ExcelIcon} alt="Excel" />
                    </button>
                  </OverlayTrigger>

                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltip}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={downloadPDF}
                    >
                      <img src={Pdf} alt="Pdf" />
                    </button>
                  </OverlayTrigger> */}
                </div>
                <div className="tableBorderBox pt-3">
                  <div className="w-100 table-responsive">
                    <div className="table-responsive tableContentBox">
                      <table
                        id="gvReversalTxnsReportPDF"
                        className="table table-striped table-hover table-borderless align-middle"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            {Object.keys(ReversalTxnsReport[0]).map(
                              (Column) => {
                                return (
                                  <>
                                    <th scope="col">
                                      {splitCamelCase(Column)}
                                    </th>
                                  </>
                                );
                              }
                            )}
                          </tr>
                        </thead>
                        <tbody>
                          {ReversalTxnsReport.map((Row, index) => {
                            return (
                              <tr key={index}>
                                {Object.keys(ReversalTxnsReport[index]).map(
                                  (Column) => {
                                    if (Column === "ReferenceNumber") {
                                      return (
                                        <td>
                                          <OverlayTrigger
                                            placement="top"
                                            delay={{ show: 250, hide: 400 }}
                                            overlay={renderTooltipShow}
                                          >
                                            <button
                                              className="editBox"
                                              onClick={() =>
                                                onReferenceNumberClick(
                                                  Row.ReferenceNumber,
                                                  Row.TerminalValueerminalId
                                                )
                                              }
                                            >
                                              <u>{Row.ReferenceNumber}</u>
                                            </button>
                                          </OverlayTrigger>
                                        </td>
                                      );
                                    } else {
                                      return (
                                        <>
                                          <td scope="col">{Row[Column]}</td>
                                        </>
                                      );
                                    }
                                  }
                                )}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        )}
        {/* Save Filters */}
        {/* Save Filters */}
        {referenceNo && (
          <TransactionDetails
            EJTxnList={EJTxnList}
            SWTxnList={SWTxnList}
            GLTxnList={GLTxnList}
            NWTxnList={NWTxnList}
            ReferenceNo={referenceNo}
            setReferenceNo={setReferenceNo}
          />
        )}
      </div>

      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default ReversalReportMainWindow;
