﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import SuccessfulAmountCountReportMainwindow from "./SuccessfulAmountCountReportMainwindow";

const SuccessfulAmountCountReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <SuccessfulAmountCountReportMainwindow />
        </div>
    );
};

export default SuccessfulAmountCountReport;
