import React from "react";
import { useSelector } from "react-redux";
// CSS
import "../../common/traceReport.css"; 
// Components
import SidebarMain from "../../common/SidebarMain";
import UnmatchedMainWindow from "./UnmatchedMainWindow";

const UnmatchedReport = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView">
        <UnmatchedMainWindow />
    </div>
  );
};

export default UnmatchedReport;
