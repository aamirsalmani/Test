import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import UnsuccessfulTxnsReportMainWindow from "./UnsuccessfulTxnsReportMainWindow";

const UnsuccessfulTxnsReport = () => {

  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView">
              <UnsuccessfulTxnsReportMainWindow />
    </div>
  );
};

export default UnsuccessfulTxnsReport;
