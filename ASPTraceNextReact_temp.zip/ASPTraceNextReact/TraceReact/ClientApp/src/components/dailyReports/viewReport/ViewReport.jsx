import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import ViewReportMainWindow from "./ViewReportMainWindow";


const ViewReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <ViewReportMainWindow />
        </div>
    );
};

export default ViewReport;