import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from "react-select/async";
import { Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL";
import * as XLSX from "xlsx";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import { useSelector } from "react-redux";
import authHeader from "../../../pages/login/services/auth-header";
import { saveAs } from "file-saver";

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";

import $ from "jquery";
import "jquery/dist/jquery.min.js";

// Images
import ExcelIcon from "../../../images/common/excel.svg";
import CsvIcon from "../../../images/common/csv_small.svg";
import magnifyIcon from "../../../images/common/magnify.svg";

import "jspdf-autotable";
import { getYear, getMonth, parse } from "date-fns";
import { formatDate, splitCamelCase } from "../../common/Utils";

const optionsType = [
  { value: "1", label: "Maker Pending" },
  { value: "2", label: "Maker Rejected" },
  { value: "3", label: "Maker Confirmed" },
  { value: "4", label: "Checker Rejected" },
  { value: "5", label: "Checker Approved" },
];

const ViewReportMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const fetchClientData = (inputValue) => {
    setStartDate(null);
    setEndDate(null);

    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  //const Show Loader
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [inputValue, setValue] = useState("0");

  const [selectedValue, setSelectedValue] = useState(null);

  const [PostParameter, setPostParameter] = useState(null);

  const [CheckerStatus, setCheckerStatus] = useState(null);

  // handle input change event
  const handleInputChange = (value) => {
    setValue(value);
  };

  const [optionsChannelType, setOptionsChannelTypeValue] = useState([
    { channelID: "0", channelName: "--Select--" },
  ]);

  const [OptionsReportType, setOptionsReportTypeValue] = useState([
    { value: "0", label: "--Select--" },
  ]);

  const [selectedChannelValue, setSelectedChannelValue] = useState(null);

  const [selectedNPCIBulkUploadValue, setSelectedNPCIBulkUploadValue] =
    useState(null);

  const [selectedStatusTypeValue, setSelectedStatusTypeValue] = useState({
    value: "5",
    label: "Checker Approved"
  });

  // handle selection
  const onReset = (e) => {
    e.preventDefault();
    // window.location.reload(false);
    setSelectedValue(null);
    setOptionsChannelTypeValue([]);
    setOptionsReportTypeValue([]);
    setTtumReportData(null);
    setSelectedChannelValue(null);
    setSelectedNPCIBulkUploadValue(null);
    setSelectedStatusTypeValue(null);
    setStartDate(null);
    setEndDate(null);
  };

  const handleOptionsChannelType = (value) => {
    setOptionsChannelTypeValue(value);
  };

  const handleOptionsReportType = (value) => {
    setOptionsReportTypeValue(value);
  };

  const handleClientChange = (value) => {
    setTtumReportData(null);
    setSelectedChannelValue(null);
    setSelectedNPCIBulkUploadValue(null);
    setSelectedValue(value);

    if (value.clientID !== "0") {
      return MaximusAxios.get(
        "api/Common/GetChannelOptionList?ClientId=" +
        value.clientID +
        "&UserID=" +
        currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsChannelType(result.data);
      });
    }
  };

  // handle selection
  const handleChannelChange = (value) => {
    setTtumReportData(null);
    setSelectedNPCIBulkUploadValue(null);
    setSelectedChannelValue(value);

    if (value.value !== "0" && selectedValue.clientID !== "0") {
      return MaximusAxios.get(
        "/api/Common/GetNPCIReportTypeList?ClientID=" +
        selectedValue.clientID +
        "&ChannelID=" +
        value.value +
        "&UserID=" +
        currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsReportType(result.data);
      });
    }
  };

  const handleNPCIBulkUploadChange = (value) => {
    setTtumReportData(null);
    setSelectedNPCIBulkUploadValue(value);
  };

  //   Date Calendar
  const [startDate, setStartDate] = useState(new Date());
  //   Date Calendar
  const [endDate, setEndDate] = useState(new Date());

  const setStartDateValue = (value) => {
    setStartDate(value);
    setEndDate(value);
    setTtumReportData(null);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date ");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    setTtumReportData(null);
  };

  const handleStatusTypeChange = (value) => {
    setSelectedStatusTypeValue(value);
  };

  const [TtumReportData, setTtumReportData] = useState(null);

  const onSubmit = () => {
    setTtumReportData(null);

    if (selectedValue === null || selectedValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      alert("Please select Channel!");
      return false;
    }

    if (
      selectedNPCIBulkUploadValue === undefined ||
      selectedNPCIBulkUploadValue === null
    ) {
      alert("Please select Report Type!");
      return false;
    }

    if (
      selectedStatusTypeValue === undefined ||
      selectedStatusTypeValue === null
    ) {
      alert("Please select Status!");
      return false;
    }

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let ChannelId = "0";

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      ChannelId = "0";
    } else {
      ChannelId = selectedChannelValue.value;
    }

    let NPCIBulkUploadType = "";

    if (
      selectedNPCIBulkUploadValue === undefined ||
      selectedNPCIBulkUploadValue === null
    ) {
      NPCIBulkUploadType = "";
    } else {
      NPCIBulkUploadType = selectedNPCIBulkUploadValue.label;
    }

    let selectedStatus = "";

    if (
      selectedStatusTypeValue === undefined ||
      selectedStatusTypeValue === null
    ) {
      selectedStatus = "";
    } else {
      selectedStatus = selectedStatusTypeValue.value;
    }

    setIsLoading(true);

    const tempParameter = {
      ClientID: selectedValue.clientID,
      ChannelID: ChannelId,
      ReportType: NPCIBulkUploadType,
      FromDateTxns: formatDate(startDate),
      ToDateTxns: formatDate(endDate),
      UserName: currentUser.user.username,
      Remark: selectedStatus,
    };

    setPostParameter(tempParameter);

    MaximusAxios.post("api/RunReconProcess/GetTtumReportList", tempParameter, {
      mode: "cors",
    })
      .then(function (response) {
        setTtumReportData(response.data);
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "No records found",
          });
        }

        MaximusAxios.post(
          "api/RunReconProcess/GetCheckerMakerStatus",
          tempParameter,
          { mode: "cors" }
        ).then((Status) => {
          setCheckerStatus(Status.data);
        });
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  const ExportToExcel = () => {
    setIsLoading(true);
    let FileName = "";

    if (selectedChannelValue.label === "IMPS" && selectedNPCIBulkUploadValue.label === "RET") {
      FileName =
        "IMPSCSV" + IMPSBulkUploadFiledate(formatDate(startDate)) + ".xlsx";
    } else if (selectedValue.clientID === "82" && selectedChannelValue.label === "POS" && selectedNPCIBulkUploadValue.label === "DISPUTE") {
      FileName =
        "POS RefundCashbackTTUM Report_" + POSRefundFiledate(formatDate(startDate)) + ".xlsx";
    } else if (selectedValue.clientID === "82" && selectedChannelValue.label === "POS" && selectedNPCIBulkUploadValue.label === "FAILED") {
      FileName =
        "POS Issuer Failed txn TTUM_RECON_" + IMPSBulkUploadFiledate(formatDate(startDate)) + ".xlsx";
    } else {
      FileName =
        selectedNPCIBulkUploadValue.label +
        "_" +
        selectedChannelValue.label +
        "_" +
        formatDate(startDate) +
        ".xlsx";
    }

    MaximusAxios.post("api/RunReconProcess/ExportExcelReport", PostParameter, {
      mode: "cors",
      responseType: "blob",
    })
      .then(function (response) {
        saveAs(response.data, FileName);
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        setIsLoading(false);
      });
  };

  function IMPSBulkUploadFiledate(inputDate) {
    // Convert the string to a Date object
    const date = new Date(inputDate);
    const day = String(date.getDate()).padStart(2, "0"); // Ensure two digits
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Month is zero-indexed
    const year = String(date.getFullYear() % 100).padStart(2, "0");
    return `${day}${month}${year}`;
  }


  function POSRefundFiledate(inputDate) {
    const date = new Date(inputDate);

    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0"); // zero-based month
    const year = date.getFullYear(); // full year

    return `${day}-${month}-${year}`;
  }


  const ExportToCSV = () => {
    let FileName = "";
    setIsLoading(true);
    if (selectedChannelValue.label === "IMPS" && selectedNPCIBulkUploadValue.label === "RET") {
      FileName =
        "IMPSCSV" + IMPSBulkUploadFiledate(formatDate(startDate)) + ".csv";
    } else if (selectedValue.clientID === "82" && selectedChannelValue.label === "POS" && selectedNPCIBulkUploadValue.label === "DISPUTE") {
      FileName =
        "POS RefundCashbackTTUM Report_" + POSRefundFiledate(formatDate(startDate)) + ".csv";
    } else if (selectedValue.clientID === "82" && selectedChannelValue.label === "POS" && selectedNPCIBulkUploadValue.label === "FAILED") {
      FileName =
        "POS Issuer Failed txn TTUM_RECON_" + IMPSBulkUploadFiledate(formatDate(startDate)) + ".csv";
    } else {
      FileName =
        selectedNPCIBulkUploadValue.label +
        "_" +
        selectedChannelValue.label +
        "_" +
        formatDate(startDate) +
        ".csv";
    }

    MaximusAxios.post("api/RunReconProcess/ExportCsvReport", PostParameter, {
      mode: "cors",
      responseType: "blob",
    })
      .then(function (response) {
        saveAs(response.data, FileName);
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        setIsLoading(false);
      });
  };

  // Tooltip

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to excel
    </Tooltip>
  );

  const renderTooltipCSV = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to CSV
    </Tooltip>
  );

  $(document).ready(function () {
    if (TtumReportData !== null && TtumReportData.length > 0) {
      $("#gvTtumReport").DataTable();
    }
  });

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          View Report
        </h5>

        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Daily Reports</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">View Report</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="npcibulkuploadFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="npcibulkuploadFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#npcibulkuploadFiltersCollapse"
                aria-expanded="true"
                aria-controls="npcibulkuploadFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="npcibulkuploadFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="npcibulkuploadFiltersHeading"
              data-bs-parent="#npcibulkuploadFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      onChange={handleChannelChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ReportData">Report Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      value={selectedNPCIBulkUploadValue}
                      options={OptionsReportType}
                      id="ddlnpcibulkupload"
                      onChange={handleNPCIBulkUploadChange}
                      classNamePrefix="reactSelectBox"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="logType">Status</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      value={selectedStatusTypeValue}
                      options={optionsType}
                      id="ddlTxnType"
                      onChange={handleStatusTypeChange}
                      classNamePrefix="reactSelectBox"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                      readOnly={true}
                    />
                  </div>
                </div>
                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onSubmit}
                    disabled={isShow}
                  >
                    Show
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Content */}

      <div className="configLeftBottom">
        {(TtumReportData === null || TtumReportData.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {TtumReportData !== null && TtumReportData.length > 0 ? (
              <div>
                <div className="exportButton">
                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltipExcel}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={ExportToExcel}
                    >
                      <img src={ExcelIcon} alt="Excel" />
                    </button>
                  </OverlayTrigger>

                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltipCSV}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={ExportToCSV}
                    >
                      <img src={CsvIcon} alt="csv" />
                    </button>
                  </OverlayTrigger>
                </div>
                <div className="tableBorderBox pt-3">
                  <div className="w-100 table-responsive">
                    <div className="table-responsive tableContentBox">
                      <table
                        id="gvTtumReport"
                        className="table table-striped table-hover table-borderless align-middle"
                      >
                        <thead>
                          <tr>
                            {Object.keys(TtumReportData[0]).map(
                              (Column, ColIndex) => {
                                return (
                                  <th scope="col" key={ColIndex}>
                                    {splitCamelCase(Column)}
                                  </th>
                                );
                              }
                            )}
                          </tr>
                        </thead>
                        <tbody>
                          {TtumReportData.map((Row, rowIndex) => (
                            <tr key={rowIndex}>
                              {Object.keys(Row).map((Column, columnIndex) => {
                                return <td key={columnIndex}>{Row[Column]}</td>;
                              })}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        )}
      </div>
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default ViewReportMainWindow;
