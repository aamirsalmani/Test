import React from "react";
import { useSelector } from "react-redux";

// Components
import AcquirerFeeDashboardMainWindow from "./AcquirerFeeDashboardMainWindow";

const AcquirerFeeDashboard = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* <SidebarMain /> */}
            {/* <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                < AcquirerFeeDashboardMainWindow/>
            {/* </div> */}
        </div>
    );
};

export default AcquirerFeeDashboard;

