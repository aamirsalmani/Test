import React from "react";
import { useSelector } from "react-redux";

// Components
import AcquirerIssuerFeeDashboardMainWindow from "./AcquirerIssuerFeeDashboardMainWindow";

const AcquirerFeeDashboard = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* <SidebarMain /> */}
            {/* <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                < AcquirerIssuerFeeDashboardMainWindow/>
            {/* </div> */}
        </div>
    );
};

export default AcquirerFeeDashboard;

