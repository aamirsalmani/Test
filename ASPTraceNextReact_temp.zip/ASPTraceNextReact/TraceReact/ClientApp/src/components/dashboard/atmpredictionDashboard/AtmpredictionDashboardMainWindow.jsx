import React, { useEffect, useState } from "react"; 

const AtmpredictionDashboardMainWindow = () => { 

    const PowerBIURL = "https://app.powerbi.com/view?r=eyJrIjoiNTlmYzUyY2ItMjJkZC00NjU5LWE0YTYtYjg1NDE0ZDIwNGFhIiwidCI6ImUzZTY1YTY3LTA3MTgtNDM4MS04ZTY2LWU5NjliMTJjOWRiYSJ9";

   return ( 
        <div className="configLeft reportContainer">
            <div className="configLeftTop">
                <iframe width="95%" height="700" src={PowerBIURL} style={{ position: "relative", clip: "rect(0px,1400px,700px,0px)", bottom: "-10px" }}  ></iframe>
            </div>
        </div>
    );
};




export default AtmpredictionDashboardMainWindow;
