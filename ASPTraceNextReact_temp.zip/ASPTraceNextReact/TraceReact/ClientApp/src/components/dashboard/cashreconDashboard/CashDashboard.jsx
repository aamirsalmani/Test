﻿

import React from "react";
import { useSelector } from "react-redux";

// Components
import SidebarMain from "../../common/SidebarMain";
import CashDashboardMainWindow from "./CashDashboardMainWindow";

const CashDashboard = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* <SidebarMain /> */}
            {/* <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                < CashDashboardMainWindow/>
            {/* </div> */}
        </div>
    );
};

export default CashDashboard;

