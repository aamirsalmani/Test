﻿import React, { useEffect, useState } from "react"; 

const CashDashboardMainWindow = () => { 

    const PowerBIURL = "https://app.powerbi.com/view?r=eyJrIjoiNTQ5NzQ1OTAtYTQ1OC00NjQwLWFiODAtZTUwNDlhODljZjc5IiwidCI6ImUzZTY1YTY3LTA3MTgtNDM4MS04ZTY2LWU5NjliMTJjOWRiYSJ9";

   return ( 
        <div className="configLeft reportContainer">
            <div className="configLeftTop">
                <iframe width="95%" height="700" src={PowerBIURL} style={{ position: "relative", clip: "rect(0px,1400px,700px,0px)", bottom: "-10px" }}  ></iframe>
            </div>
        </div>
    );
};




export default CashDashboardMainWindow;
