import React from "react";
import { useSelector } from "react-redux";

// Components
import DailyMISReportMainWindow from "./DailyMISReportMainWindow";

const DailyMISReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* <SidebarMain /> */}
            {/* <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                < DailyMISReportMainWindow/>
            {/* </div> */}
        </div>
    );
};

export default DailyMISReport;

