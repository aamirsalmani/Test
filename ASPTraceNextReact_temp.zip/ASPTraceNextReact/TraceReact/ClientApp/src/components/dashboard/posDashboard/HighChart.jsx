﻿import React from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';

const HighChart = ({ success, unsuccess }) => {

    const formatDate = (dateString) => {
        const [month, day, year] = dateString.split(' ')[0].split('/');
        return `${day}/${month}/${year}`;
    };

    const formattedSuccess = success.map(d => ({ ...d, date: formatDate(d.date) }));
    const formattedUnsuccess = unsuccess.map(d => ({ ...d, date: formatDate(d.date) }));
    const categories = [...new Set([...formattedSuccess, ...formattedUnsuccess].map(d => d.date))];
    const successSeries = categories.map(date => {
        const dataPoint = formattedSuccess.find(d => d.date === date);
        return dataPoint ? parseInt(dataPoint.successful, 10) : 0;
    });
    const unsuccessSeries = categories.map(date => {
        const dataPoint = formattedUnsuccess.find(d => d.date === date);
        return dataPoint ? parseInt(dataPoint.unsuccessful, 10) : 0;
    });


    const getGradient = (id, startColor, endColor) => ({
        linearGradient: { x1: 0, y1: 1, x2: 0, y2: 0 },
        stops: [
            [0, startColor],
            [1, endColor]
        ]
    });

    const options = {
        chart: {
            type: 'area',
            height: 300,
            width: 700,
            marginTop: 50,
            marginRight: 250,
            marginBottom: 50,
            marginLeft: 65,
            animation: {
                duration: 1000
            }
        },
        title: {
            text: 'POS Successful-UnMatched Count',
            style: {
                fontSize: '16px', 
                color: getGradient('gradientSwitch', 'lightblue', 'steelblue') 
            },
            x: -35, 
            y: 13 
        },  
        xAxis: {
    categories,     
    crosshair: true,
    labels: {
      style: {
        fontSize: '7px' 
      }
    }
  },
  yAxis: {
    min: 0,
    title: {
      text: 'Records'
    },
    labels: {
      style: {
        fontSize: '12px'
      },
      formatter: function() {
        if (this.value >= 1000) {
          return (this.value / 1000) + 'K'; 
        } else {
          return this.value; 
        }
      }
    }
  },
       plotOptions: {
            column: {
                grouping: true,
                pointPadding: 0,
                groupPadding: 0.1, 
                borderWidth: 0,
                dataLabels: {
                    enabled: true
                }
            }
        },
        tooltip:{
            backgroundColor: '#ffffff',  
            borderColor: '#cccccc',    
            borderRadius: 5,             
            borderWidth: 1,             
            style: {
              color: '#333333',       
              fontSize: '8px',         
              fontFamily: 'Arial, sans-serif' 
            },
            formatter: function() {
              return `<b>${this.x}</b><br/>${this.series.name}: ${this.y}`;
            }
          },
        series: [
            {
                name: 'Successful Count',
                data:successSeries,
                color: {
                    linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                    stops: [
                        [0, '#4a56f0'], 
                        [1, '#c9ccf2']  
                    ]
                },
                dataLabels: {
                enabled: true,
                style: {
                    marginLeft:'-10px',
              fontSize: '6px'  
            }
      }
                
            },
            {
                name: 'UnMatched Count',
                data:unsuccessSeries,
                color: {
                    linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                    stops: [
                        [0, '#4df0ea'],
                        [1, '#b6f2f0'] 
                    ]
                }
            }
        ],
        legend: {
            layout: 'horizontal',
            align: 'left', 
            verticalAlign: 'top',
            y: 10,        
            x: 180,          
            floating: true,
            itemStyle: {
                marginTop:'10px',
                fontSize: '12px' 
            }
            
        },
        credits: {
            enabled: false
        },
        accessibility: {
             enabled: false 
        }
    };


    return (
        <div>
            <HighchartsReact highcharts={Highcharts} options={options} />
        </div>
    );
};


export default HighChart;
