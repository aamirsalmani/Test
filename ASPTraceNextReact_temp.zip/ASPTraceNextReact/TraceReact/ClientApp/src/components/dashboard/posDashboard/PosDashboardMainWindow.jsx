﻿import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
// Components
import MaximusAxios from "../../common/apiURL";
import HighChart from './HighChart';
import Atm_lineChart from './Atm_lineChart';
import Atm_Chart from "./Atm_Chart";


const PosDashboardMainWindow = () => {

    const navigate = useNavigate();

    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    const currentUser = useSelector((state) => state.authReducer);

    const [isPostBack, setIsPostBack] = useState(null);

    const [PowerBIURL, setPowerBIURL] = useState(null);
    const [chartdata, setChartData] = useState([]);
    const [AtmChartData, setAtmChartData] = useState([]);
    const [AtmData, setAtmData] = useState([]);



    useEffect(() => {
        Charts()
    },
        [isPostBack]
    );




    const Charts = () => {

        let Username = '';
        if (currentUser !== null && currentUser.user !== null) {
            Username = currentUser.user.username;
        }

        MaximusAxios.get('api/Home/CheckUserLogin?UserID=' + Username, { mode: 'cors' }).then(resultLogin => {

            if (resultLogin.data !== null) {

                if (resultLogin.data === "FirstLogin") {
                    navigate('/user-management/change-password');
                }
                else {

                    MaximusAxios.get('api/Home/GetDashBoardData?UserID=' + Username, { mode: 'cors' }).then(result => {
                        setChartData(result.data);
                    }).catch(function (error) {

                        if ([401, 403].includes(error.response.status)) {
                            localStorage.removeItem('user');
                            window.history.go('Login');
                        }

                    });

                    MaximusAxios.get('api/Home/GetATMSuUnDashBoardData?UserID=' + Username, { mode: 'cors' }).then(result => {
                        setAtmData(result.data);
                    }).catch(function (error) {

                        if ([401, 403].includes(error.response.status)) {
                            localStorage.removeItem('user');
                            window.history.go('Login');
                        }

                    });

                    MaximusAxios.post('/api/Home/GetATMDashBoardData',
                        {
                            UserID: String(Username),
                            ChannelID: 1
                        },
                        { mode: 'cors' })
                        .then(result => {
                            setAtmChartData(result.data);
                        })
                        .catch(function (error) {
                            if ([401, 403].includes(error.response.status)) {
                                localStorage.removeItem('user');
                                window.history.go('Login');
                            }
                        });
                }
            }
        }).catch(function (error) {
            if ([401, 403].includes(error.response.status)) {
                localStorage.removeItem('user');
                window.history.go('Login');
            }
        });
    }


    return (
        <div className="d-flex justify-content-center mt-3 MainDiv">
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
                <div className="configLeft reportContainer">
                    <div className="configLeftTop d-flex">
                        <div className="card card-custom m-2 p-3">
                            <HighChart success={chartdata} unsuccess={chartdata} />
                        </div>
                        <div className="card card-custom m-2 p-3">
                            <Atm_Chart success={AtmData} unsuccess={AtmData} />
                        </div>
                    </div>
                    <div className="card card-custom m-2 p-3">
                        <Atm_lineChart success={AtmChartData} unsuccess={AtmChartData} />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PosDashboardMainWindow;
