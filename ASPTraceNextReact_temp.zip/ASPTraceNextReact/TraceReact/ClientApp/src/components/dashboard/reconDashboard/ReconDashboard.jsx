﻿import React from "react";
import { useSelector } from "react-redux";

// Components
import SidebarMain from "../../common/SidebarMain";
import ReconDashboardMainWindow from "./ReconDashboardMainWindow ";


const ReconDashboard = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* <SidebarMain /> */}
            {/* <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                < ReconDashboardMainWindow/>
            {/* </div> */}
        </div>
    );
};

export default ReconDashboard;

