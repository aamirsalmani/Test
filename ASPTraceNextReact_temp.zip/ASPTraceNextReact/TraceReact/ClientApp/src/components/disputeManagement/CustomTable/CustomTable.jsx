import * as React from "react"
import './CustomTable.css'
import './NewStyle.css'

const Table = React.forwardRef
(({ className='',style, ...props }, ref) => (
  <div className={`custom-Table-container`} style={style} >
    <table ref={ref}
      className={`custom-Table ${className}` }
      {...props}
    />
  </div>
))
Table.displayName = "Table"

const TableHeader = React.forwardRef(({className='', ...props }, ref) => (
  <thead ref={ref} className={`custom-Table headerGroup ${className}` } {...props} />
))
TableHeader.displayName = "TableHeader"

const TableBody = React.forwardRef(({className='', ...props }, ref) => (
  <tbody
    ref={ref}
    className={`${className}` }
    {...props}
  />
))
TableBody.displayName = "TableBody"

const TableFooter = React.forwardRef(({className='', ...props }, ref) => (
  <tfoot
    ref={ref}
    className={`${className}` }
    {...props}
  />
))
TableFooter.displayName = "TableFooter"

const TableRow = React.forwardRef(({className='', ...props }, ref) => (
  <tr
    ref={ref}
    className={`${className} custom-Table Row ` }
    {...props}
  />
))
TableRow.displayName = "TableRow"

const TableHead = React.forwardRef(({className='', ...props }, ref) => (
  <th
    ref={ref} 
    className={` ${className} custom-Table head` }
    {...props}
  />
))
TableHead.displayName = "TableHead"

const TableCell = React.forwardRef(({className='', ...props }, ref) => {
  return(
  <td
    ref={ref}
    className={` ${className} custom-Table cell` }
    {...props}
  />
)
}
)
TableCell.displayName = "TableCell"

const TableCaption = React.forwardRef(({className='', ...props }, ref) => (
  <caption
    ref={ref}
    className={`${className}` }
    {...props}
  />
))
TableCaption.displayName = "TableCaption"

export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableHead,
  TableRow,
  TableCell,
  TableCaption,
}
