﻿import React, { useRef, useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import Select from "react-select";
import { Modal, Button, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import MaximusAxios from "../../common/apiURL" ;
import AsyncSelect from 'react-select/async';
import authHeader from "../../../pages/login/services/auth-header"; 
import MessageBox from "../../common/MessageBox";
import "datatables.net-dt/js/dataTables.dataTables"
import "datatables.net-dt/css/jquery.dataTables.min.css"
import 'jquery/dist/jquery.min.js';
import { useSelector } from "react-redux";
import Delete from "../../../images/common/redDelete.svg";
import editRow from "../../../images/common/editRow.svg";
import ExcelIcon from "../../../images/common/excel_small.svg";
import fileupload from "../../../images/common/fileuploadicon.svg";
import * as XLSX from 'xlsx';
import postHeader from "../../../pages/login/services/post-header";
import LoadingSpinner from "../../common/LoadingSpinner";

const DisputeTypeConfigMainWindow = () => {

    const [Show, setShow] = useState(false);
    const fileInputRef = useRef(null);

    const triggerFileInput = () => {
        fileInputRef.current.click();
    };
    const handleReasonCodeChange = (e) => {
        const value = e.target.value;
        // Regular expression to allow only numbers
        if (/^\d*$/.test(value))
        {
            setReasonCode(value);
        }
    };
    const handledisputeOrderChange = (e) => {
        const value = e.target.value;
    if (/^\d*$/.test(value)) {
        setDisputeOrder(value);
    }
};

    const [showModal, setShowModal] = useState(false);
    const [ShowModalForNew, setShowModalForNew] = useState(false);
    const [ShowGrid, setShowGrid] = useState(false);
    const currentUser = useSelector((state) => state.authReducer);
    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });
    const [Change, setChange] = useState(true);
    const [selectedClientValue, setSelectedClientValue] = useState(null);

    const [inputValue, setValue] = useState('0');
    const [optionsChannelType, setOptionsChannelType] = useState([{ channelID: "0", channelName: "ALL" }]);
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);
    const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "ALL" }]);

    const [optionsNetworkType, setoptionsNetworkType] = useState

        ([
            { NetworkID: '0', NetworkName: 'ALL' },
            { NetworkID: '1', NetworkName: 'NPCI' },
            { NetworkID: '2', NetworkName: 'VISA' },
            { NetworkID: '3', NetworkName: 'MASTER' },

        ]);

    const [selectedModeValue, setSelectedModeValue] = useState(null);
    const [selectedNetworkValue, setselectedNetworkValue ] = useState(null);
    
    const [selectedadjustmentType, setSelectedadjustmentType] = useState(null);
   
    const [AdjType, setAdjType] = useState(null); 
 
    const [flag, setFlag] = useState();
    const [reasonCode, setReasonCode] = useState(null);
    const [TAT, setTAT] = useState(null);
    const [disputeOrder, setDisputeOrder] = useState(null);
    

    const [NewEntry, setNewEntry] = useState(false);
    const [AddEntry, setAddEntry] = useState(false);
    const [EditEntry, setEditEntry] = useState(false);
     
    const [Selectedflag, setSelectedflag] = useState(null);
    const [selectedreasonCode, setSelectedreasonCode] = useState(null);
    const [selectedTAT, setSelectedTAT] = useState(null);
    const [selecteddisputeOrder, setSelecteddisputeOrder] = useState(null);
    const [selectedAction, setSelectedAction] = useState(null);
    const [selectedSettledRemark, setSelectedSettledRemark] = useState(null);

    const [SeparatedData, setSeparatedData] = useState([]);

    

    


    const onShowClick = () => {

        setShowGrid(false);
        let alertMessages = "";

        if (selectedClientValue === null || selectedClientValue === undefined) {
            alertMessages += "Please select client. \n";
        }
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            alertMessages += "Please select Channel. \n";
        }
        else if (selectedModeValue === undefined || selectedModeValue === null) {
            alertMessages += "Please select mode Type. \n";
        }
        if (alertMessages.length > 0) {
            setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
            return false;
        }
        CheckSelectedValues();
        MaximusAxios.post('api/DisputeTypeConfig/GetDisputeTypeconfigData', {
            ClientID: selectedClientValue.clientID,
            ChannelID: selectedChannelValue.value,
            ModeID: selectedModeValue.value,
     
        }, {
                headers: authHeader()
            })
            .then(response => {
                setSeparatedData(response.data);
                console.log(response.data)
                setShowGrid(true);
                setIsLoading(false);
            })
            .catch(function (error) {
                console.log(error.response);
                setIsLoading(false);
            });
    };

    const handleInputChange = value => {
        setValue(value);
    };

    const fetchClientData = (inputValue) => {
        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    const handleClientChange = value => {
        setShow(false);
        setSelectedClientValue(value);
        setSelectedChannelValue(null);
        setSelectedModeValue(null);

        try {

            setIsLoading(true);

            if (value.clientID !== '0') {

                MaximusAxios.get('api/DynamicFileConfig/GetChannelOptionList?ClientID=' + value.clientID + '&UserID=' + currentUser.user.username, {  mode: 'cors' }).then(resultChannel => {

                    setOptionsChannelType(resultChannel.data);


                    setIsLoading(false);
                });
            }
        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }
    }
    const handleChannelChange = value => {
        setShow(false);
        setSelectedChannelValue(value);
        setSelectedModeValue(null);

        let ChannelId = 0;
        if (value === undefined || value === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = value.value;
        }
        setIsLoading(true);
        MaximusAxios.get('api/DynamicFileConfig/GetDynamicModeOptionList?ClientID=' + selectedClientValue.clientID + '&ChannelID=' + ChannelId + '&UserID=' + currentUser.user.username, {  mode: 'cors' }).then(resultMode => {
            setOptionsModeTypeValue(resultMode.data);
        });
        setIsLoading(false);
    }
    const handleModeChange = value => {
        setShow(false);
        setSelectedModeValue(value);
    }

    const handleNetworkChange  = value => {
        setShow(false);
        setselectedNetworkValue(value);
    }
   


    const onDeleteClick = (item) => {
        if (window.confirm("Are you sure you want to delete.")) {
            MaximusAxios.post('api/DisputeTypeConfig/DeleteDisputeTypeConfigData', {
                ClientID: selectedClientValue.clientID,
                ChannelID: selectedChannelValue.value,
                ModeID: selectedModeValue.value,
                AdjustmentType: item.adjustmentType,
                flag: item.flag,
                ReasonCode: item.reasonCode,
                TAT: item.tat,
                DisputeOrder: item.disputeOrder,
                IsAquirerAction: item.isAquirerAction
            }, {  mode: 'cors' })
                .then(response => {
                    if (response.data === "" || response.data.length > 0) {
                        alert('Configuration deleted successfully!');
                        onShowClick();
                    }
                })
                .catch(error => {
                    if (error.response) {
                        console.log(error.response.data);
                        alert('Configuration deleted failed!');
                        onShowClick();
                    }
                });
        }
    };

    const onEditClick = (item) => {

        try {         
            console.log(item)
            setAdjType(item.adjustmentType);
            setSelectedflag(item.flag);
            setSelectedreasonCode(item.reasonCode);
            setSelectedTAT(item.tat);
            setSelecteddisputeOrder(item.disputeOrder);
            setSelectedAction(item.isAquirerAction);
            setEditEntry(true);
            setShowModal(true);

            if (window.confirm("Are you sure you want to Update.")) {
                let alertMessages = "";


                if (selectedChannelValue === '0' || selectedChannelValue === null) {
                    alertMessages += "You cannot add configuration to all Channel. \n";
                }
                if (selectedModeValue === '0' || selectedModeValue === 'ALL') {
                    alertMessages += "You cannot add configuration to all  modes. \n";
                }
               

                if (alertMessages.length > 0) {
                    setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                    return false;
                }
            }
        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }
    }
    const onSubmit = () => {
        try {
            MaximusAxios.post('api/DisputeTypeConfig/EditDisputeTypeconfigData', {
                ClientID: selectedClientValue.clientID,
                ChannelID: selectedChannelValue.value,
                ModeID: selectedModeValue.value,
                AdjustmentType: AdjType,
                flag: Selectedflag,
                reasonCode: selectedreasonCode,
                TAT: selectedTAT,
                disputeOrder: selecteddisputeOrder,
                IsAquirerAction: selectedAction
              
            }, {  mode: 'cors' })
                .then(response => {
                    if (response.data !== "" || response.data.length > 0) {
                        alert('Configuration  updated successfully');
                        setEditEntry(false);
                        setShowModal(false);
                        onShowClick();
                    }
                    else if (response.data === "" || response.data.length == 0) {
                        alert('Updation failed');
                        setEditEntry(false);
                        setShowModal(false);
                        onShowClick();
                    }
                })
                .catch(error => {
                    if (error.response) {
                        console.log(error.response.data);
                    }
                });
        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }

    }

    const onNewClick = () => {
        setAddEntry(false);
        setShowModalForNew(false);
        try {
            let alertMessages = "";
            if (selectedClientValue === null || selectedClientValue === undefined) {
                alertMessages += "Please select client. \n";
            }
            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                alertMessages += "Please select Channel. \n";
            }
             if (selectedModeValue === undefined || selectedModeValue === null) {
                alertMessages += "Please select mode Type. \n";
            }
             if (selectedNetworkValue === undefined || selectedNetworkValue === null) {
                alertMessages += "Please select Network Type. \n";
            }
            if (alertMessages.length > 0) {
                setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                return false;
            }
            else {
               setAddEntry(true);
               setShowModalForNew(true);
               alert("Are you sure you want to Add.")
            } 
        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }
    }

    const onSubmitClick = () => {
        try {
            MaximusAxios.post('api/DisputeTypeConfig/AddNewDisputeTypeconfigData', {
                ClientID: selectedClientValue.clientID,
                ChannelID: selectedChannelValue.value,
                ModeID: selectedModeValue.value,
                AdjustmentType: AdjType,
                flag: Selectedflag,
                reasonCode: selectedreasonCode,
                TAT: selectedTAT,
                disputeOrder: selecteddisputeOrder,
                IsAquirerAction: selectedAction

            }, {  mode: 'cors' })
                .then(response => {
                    if (response.data !== "" || response.data.length > 0) {
                        alert('Configuration  Added successfully');
                        setEditEntry(false);
                        setShowModal(false);
                        onShowClick();
                    }
                    else if (response.data === "" || response.data.length == 0) {
                        alert('Configuration failed');
                        setEditEntry(false);
                        setShowModal(false);
                        onShowClick();
                    }
                })
                .catch(error => {
                    if (error.response) {
                        console.log(error.response.data);
                    }
                });
        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }

    }
   






    const onProceed = () => {
        try {
            let alertMessages = "";

          
                if (alertMessages.length > 0) {
                    setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                    return false;
                }
                else {
                    MaximusAxios.post('api/DisputeTypeConfig/GetDisputeTypeconfigData', {
                        ClientID: selectedClientValue.clientID,
                        ChannelID: selectedChannelValue.value,
                        ModeID: selectedModeValue.value,
                        AdjustmentType: selectedadjustmentType.value,
                        flag: flag.value,
                        reasonCode: reasonCode.value,
                        TAT: TAT.value,
                        disputeOrder: disputeOrder.value,
                        UserName: currentUser.user.username,
                    }, {  mode: 'cors' })
                        .then(response => {
                            if (response.data === 1 || response.data.length > 0) {
                                alert('Configuration already exists');
                                setNewEntry(false);
                                setShowModal(false);
                                setChange(!Change);
                            }
                            else if (response.data === "" || response.data.length > 0) {
                                alert('New Configuration configured successfully!');
                                setNewEntry(false);
                                setShowModal(false);
                                setChange(!Change);
                            }
                        })
                        .catch(error => {
                            if (error.response) {
                                console.log(error.response.data);
                            }
                        });
                }
            }
        catch (ex) {
                console.log(ex);
                setIsLoading(false);
          
        }
        
    }

    const onCancelClick = () => {

        setChange(!Change);
        setNewEntry(false);
        setShowModal(false);
    };

    const CheckSelectedValues = () => {
        let Count = 0;
        if (selectedClientValue === null || selectedClientValue === undefined) {
            Count++;
        }
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            Count++;
        }
        else if (selectedChannelValue.value === 0 || selectedChannelValue.label === 'ALL') {
            Count++;
        }
        else if (selectedModeValue === undefined || selectedModeValue === null) {
            Count++;
        }
        else if (selectedModeValue.value === 0 || selectedModeValue.label === 'ALL') {
            Count++;
        }
       
        
        if (Count === 0) {
            setShow(true);
        }
        else {
            setShow(false);
        }
    };

    const onReset = (e) => {
        e.preventDefault();
      //  window.location.reload(false);
      setSelectedClientValue(null);
      setSelectedChannelValue(null);
      setSelectedModeValue(null);
      setselectedNetworkValue(null);
      setSeparatedData([]);
    }
   const onResetModelData=(e)=>{
    setSelectedflag("");
    setSelectedreasonCode("");
    setSelectedTAT("");
    setSelecteddisputeOrder("");
    setSelectedAction("");
    setAdjType("")
   }
    

    return (
        <div className="configLeft dynamicContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Dispute Type Configuration
                </h5>
                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Dispute Management</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Dispute Type Configuration</p>
                </div>
            </div>
            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="unmatchedFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="unmatchedFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>




                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#unmatchedFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="unmatchedFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="unmatchedFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="unmatchedFiltersHeading"
                            data-bs-parent="#unmatchedFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedClientValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Network </label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlNetwork"
                                            value={selectedNetworkValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsNetworkType.map(x => (
                                                {
                                                    value: x.NetworkID,
                                                    label: x.NetworkName
                                                }
                                            ))}
                                            onChange={handleNetworkChange}
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedChannelValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            onChange={handleChannelChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedModeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.modeName
                                                }
                                            ))}
                                            onChange={handleModeChange}
                                        />
                                    </div>

                                    
                                </div>

                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onShowClick}
                                        disabled={isShow}
                                    >Show
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onNewClick}
                                        disabled={isShow}
                                    >Add New
                                    </button>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div className="configLeftBottomStatus">
            {(SeparatedData === null || SeparatedData.length === 0) &&( 
                <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div> )}
            </div>
            {/* Data Grid*/}
            <div className="configLeftBottom">
                <div>
                {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
                    {(SeparatedData !== null && SeparatedData.length !== 0) ? 
                    (<>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvMatchingList" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                        <thead>
                                                <tr>

                                                <th scope="col">ID</th>
                                                <th scope="col">Client</th>
                                                <th scope="col">Channel</th>
                                                <th scope="col">Mode</th>                                                                                                
                                                <th scope="col">Adjustment Type</th>
                                                <th scope="col">Flag</th>
                                                <th scope="col">Reason Code</th>                                              
                                                    <th scope="col">TAT</th>
                                                    <th scope="col">Dispute Order</th>
                                                    <th scope="col">Action</th>

                                                    <th>EDIT</th>

                                            </tr>
                                        </thead>
                                            <tbody>
                                                 {SeparatedData.map((item, index) => (
                                                <tr key={index}>
                                                    <td>{index + 1}</td>
                                                    <td>{item.clientName}</td>
                                                        <td>{item.channelName}</td>
                                                        <td>{item.TransactionMode}</td>
                                                        <td>{item.adjustmentType}</td>
                                                        <td>{item.flag}</td>
                                                        <td>{item.reasonCode}</td>
                                                        <td>{item.tat}</td>
                                                        <td>{item.disputeOrder}</td>
                                                        <td>{item.isAquirerAction}</td>
                                                   
                                                    <td>
                                                        <div className="text-center">
                                                            <button type="button" className="iconButtonBox" onClick={() => { onEditClick(item); }}>
                                                                <img src={editRow} alt="Edit" title="Edit" />
                                                            </button>
                                                            <button type="button" className="iconButtonBox" onClick={() => onDeleteClick(item)}>
                                                                <img src={Delete} alt="Delete" title="Delete" />
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </>
                        ):null}
                        </>
                    )}
                </div>
            </div>
            {/* Edit Modal Popup*/}
             <div>
                <Modal
                    centered
                    className="AddNewTableModal"
                    size='xl'
                    show={showModal && EditEntry}
                    onHide={() => setShowModal(false)}>
                    <Modal.Header closeButton>
                        <Modal.Title>EditDisputeType</Modal.Title>
                    </Modal.Header>
                    <Modal.Body size='xl'>
                        <div
                            id="unmatchedFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="unmatchedFiltersHeading"
                            data-bs-parent="#unmatchedFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedClientValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                            isDisabled={true}
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedChannelValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedModeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.modeName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="flagInput">Adjustment Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="flagInput"
                                            className="form-control"
                                            onChange={(e) => setAdjType(e.target.value)}
                                            value={AdjType}
                                            placeholder="Adjustment Type"
                                            disabled
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="flagInput">Flag</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="flagInput"
                                            className="form-control"
                                            onChange={(e) => setSelectedflag(e.target.value)}
                                            value={Selectedflag}
                                            placeholder="Flag"
                                        />
                                    </div>
                                    
                                    <div className="clientNameSelect col">
                                            <label htmlFor="ddlMode">Reason Code</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="reasonCodeInput"
                                            className="form-control"
                                            onChange={(e) => setSelectedreasonCode(e.target.value)}
                                            value={selectedreasonCode}
                                            placeholder="Reason Code"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                            <label htmlFor="ddlMode">TAT</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="TATInput"
                                            className="form-control"
                                            onChange={(e) => setSelectedTAT(e.target.value)}
                                            value={selectedTAT}
                                            placeholder="TAT"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                            <label htmlFor="ddlMode">Dispute Order</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="disputeOrderInput"
                                            className="form-control"
                                            onChange={(e) => setSelecteddisputeOrder(e.target.value)}
                                            value={selecteddisputeOrder}
                                            placeholder="Dispute Order"
                                        />
                                    </div>

                                </div>
                               
                                    <div className="configSelectBoxTop row">
                                        <div className="clientNameSelect col">
                                            <label htmlFor="ddlMode">Action</label>
                                            <span className="text-danger font-size13">*</span>
                                            <input
                                                type="text"
                                            id="ActionkInput"
                                            className="form-control"
                                            onChange={(e) => setSelectedAction(e.target.value)}
                                          
                                                value={selectedAction}
                                                placeholder="Action"
                                    />
                                        </div>
                                    </div>
                                </div>
                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onSubmit}
                                        disabled={isShow}
                                    >Submit
                                    </button>
                                </div>

                            </div>                     
                    
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant="secondary" onClick={onCancelClick}>Cancel</Button>
                    </Modal.Footer>
                </Modal>
            </div> 
            {/* New Modal Popup*/}
             <div>
                <Modal
                    centered
                    className="AddNewTableModal"
                    size='xl'
                    show={ShowModalForNew && AddEntry}
                    onHide={() => setShowModalForNew(false)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Add New Item</Modal.Title>
                    </Modal.Header>
                    <Modal.Body size='xl'>
                        <div
                            id="unmatchedFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="unmatchedFiltersHeading"
                            data-bs-parent="#unmatchedFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedClientValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                            isDisabled={true}
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedChannelValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedModeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.modeName
                                                }
                                            ))}
                                            isDisabled={true}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="flagInput">Adjustment Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="flagInput"
                                            className="form-control"
                                            onChange={(e) => setAdjType(e.target.value)}
                                            value={AdjType}
                                            placeholder="Adjustment Type"

                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="flagInput">Flag</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="flagInput"
                                            className="form-control"
                                            onChange={(e) => setSelectedflag(e.target.value)}
                                            value={Selectedflag}
                                            placeholder="Flag"
                                        />
                                    </div>

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Reason Code</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="reasonCodeInput"
                                            className="form-control"
                                            onChange={(e) => setSelectedreasonCode(e.target.value)}
                                            value={selectedreasonCode}
                                            placeholder="Reason Code"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">TAT</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="TATInput"
                                            className="form-control"
                                            onChange={(e) => setSelectedTAT(e.target.value)}
                                            value={selectedTAT}
                                            placeholder="TAT"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Dispute Order</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="disputeOrderInput"
                                            className="form-control"
                                            onChange={(e) => setSelecteddisputeOrder(e.target.value)}
                                            value={selecteddisputeOrder}
                                            placeholder="Dispute Order"
                                        />
                                    </div>

                                </div>

                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Action</label>
                                        <span className="text-danger font-size13">*</span>
                                        <input
                                            type="text"
                                            id="ActionkInput"
                                            className="form-control"
                                            onChange={(e) => setSelectedAction(e.target.value)}

                                            value={selectedAction}
                                            placeholder="Action"
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="text-center btnsBtm">
                                <button
                                    type="button"
                                    className="btnPrimaryOutline"
                                    onClick={(e) => onResetModelData(e)}
                                >
                                    Reset
                                    </button>
                                <button
                                    type="button"
                                    className="btnPrimary ms-2"
                                    onClick={onSubmitClick}
                                    disabled={isShow}
                                >Submit
                                    </button>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>
            </div> 
            <LoadingSpinner isShow={false} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div >

    );
};

export default DisputeTypeConfigMainWindow;
