import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Select from "react-select";
import { Modal, Button, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import MaximusAxios from "../../common/apiURL";
import AsyncSelect from "react-select/async";
import authHeader from "../../../pages/login/services/auth-header";
import MessageBox from "../../common/MessageBox";
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import "jquery/dist/jquery.min.js";
import { useSelector } from "react-redux";
import Delete from "../../../images/common/redDelete.svg";
import editRow from "../../../images/common/editRow.svg";
import DatePicker from "react-datepicker";
import { getYear, getMonth } from "date-fns";
import configuration from "../../../images/common/configuration.svg";
import AttachmentsIcon from "../../../images/common/editRow.svg";
import { FileUploader } from "react-drag-drop-files";
import postHeader from "../../../pages/login/services/post-header";
import DownloadIcon from "../../../images/common/cloud-240.svg";
import axios from "axios";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import DeleteIcon from "../../../images/common/cancelIcon.svg";
import { splitCamelCase } from "../../common/functionsList";
import LoadingSpinner from "../../common/LoadingSpinner";

const DisputeRaise = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const [IsUserChecker, setIsUserChecker] = useState(false);
  const [checkboxValues, setCheckboxValues] = useState([]);

  const [isShow, setIsLoading] = useState(false);
  const [isShowCardNo, setIsShowCardNo] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });
  const [selectedClientValue, setSelectedClientValue] = useState(null);
  const [referenceNumber, setReferenceNumber] = useState(null); 
  const [fromAccount, setFromAccount] = useState(null);
  const [inputValue, setValue] = useState("0");
  const [selectedValue, setSelectedValue] = useState(null);
  const [optionsChannelType, setOptionsChannelType] = useState([
    { channelID: null, channelName: "ALL" },
  ]);
  const [selectedChannelValue, setSelectedChannelValue] = useState(null);
  const [optionsModeType, setOptionsModeTypeValue] = useState([
    { modeID: null, modeName: "ALL" },
  ]);
  const [selectedModeValue, setSelectedModeValue] = useState(null);

  const [importFile, setImportFile] = useState(null);
  const [fileName, setFileName] = useState(null);
  const [fileTypes, setFileTypes] = useState([
    "pdf",
    "xls",
    "xlsx",
    "doc",
    "docx",
    "txt",
    "jpg",
    "jpeg",
    "png",
  ]);

  const [ShowAttachments, setShowAttachments] = useState(false);
  const [AttachmentsTable, setAttachmentsTable] = useState([]);
  const [SeparatedData, setSeparatedData] = useState([]);
  const [disputeAttachmentModal, setDisputeAttachmentModal] = useState(false);
  const [disputeRowData, setDisputeRowData] = useState(null);
  const [disputeformData, setDisputeformData] = useState({
    DisputeID: "",
    ReferenceNumber: "",
    TxnsDateTime: "",
  });

  const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

  const [selectedNetworkValue, setNetworkTypeValue] = useState(null);

  const [isShowTxnType, setIsShowTxnType] = useState(false);

  const [SelectedTxnTypeValue, setSelectedTxnTypeValue] = useState(false);

  const [IsShowTerminald, setIsShowTerminald] = useState(false);

  const [Items, setItems] = useState(false);

  const [typeOptions, settypeOptions] = useState(false);

  const [AdjTypeOptions, setAdjTypeOptions] = useState([]);
  const [ReasonCodeOptions, setReasonCodeOptions] = useState([{value:"0",label:"Select"}]);

  const fetchClientData = (inputValue) => {
    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  const handleOptionsModeType = (value) => {
    setOptionsModeTypeValue(value);
  };

  const handleChannelChange = (value) => {
    setSelectedChannelValue(value);
    setSelectedModeValue(null);

    let ChannelId = 0;
    if (value === undefined || value === null) {
      ChannelId = 0;
    } else {
      ChannelId = value.value;
    }
    setIsLoading(true);
    MaximusAxios.get(
      "api/DynamicFileConfig/GetDynamicModeOptionList?ClientID=" +
        selectedClientValue.clientID +
        "&ChannelID=" +
        ChannelId,
      { mode: "cors" }
    ).then((resultMode) => {
      setOptionsModeTypeValue(resultMode.data);
    });  

    MaximusAxios.get(
      "api/DMSReport/GetAdjTypeOptionList?ClientID=" +
        selectedClientValue.clientID +
        "&ChannelID=" +
        ChannelId,
      { mode: "cors" }
    ).then((resultMode) => {
      setAdjTypeOptions(resultMode.data);
    });

    setIsLoading(false);

    setUnmatchedTxnsReport(null);
    setSelectedModeValue(null);
    setSelectedTxnTypeValue("0");
    setSelectedTerminalValue(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedChannelValue(value);

    if (value.value === "1") {
      setIsShowTxnType(true);
    } else {
      setIsShowTxnType(false);
    }
    if (value.value === "4" || value.value === "7") {
      setIsShowCardNo(false);
    } else {
      setIsShowCardNo(true);
    }
    if (value.value === "7") {
      setIsShowTerminald(false);
    } else {
      setIsShowTerminald(true);
    }

    if (value.value !== "0" && selectedClientValue.clientID !== "0") {
      return MaximusAxios.get(
        "api/Common/GetModeOptionList?ClientID=" +
          selectedClientValue.clientID +
          "&ChannelID=" +
          value.value,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsModeType(result.data);
      });
    }
  };

  const DeleteAttachment = async (AttachmentDetails) => {
    await MaximusAxios.post(
      "api/DMSReport/DeleteAttachmentFile",
      AttachmentDetails,
      { mode: "cors" }
    )
      .then(function (response) {
        setIsLoading(false);
        OnShowAttachments();
        //setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Delete Status', alertMessage: response.data });

        setShowAttachments(true);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Delete Status",
            alertMessage: "No Record Found",
          });
        }

        setShowAttachments(false);
        setIsLoading(false);
      });
  };

  const DownloadAttachment = async (AttachmentDetails) => {
    await MaximusAxios.post(
      "api/DMSReport/GetAttachmentFile",
      AttachmentDetails,
      { responseType: "blob" }
    )
      .then(function (response) {
        setIsLoading(false);
        saveAs(response.data, AttachmentDetails.fileName);

        setShowAttachments(true);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }

        setShowAttachments(false);
        setIsLoading(false);
      });
  };

  const OnShowAttachments = async (row, index) => {
    let ReferenceNumber =
      row !== undefined ? row.referenceNumber : disputeformData.ReferenceNumber;
    let TxnsDateTime =
      row !== undefined ? row.txnsDateTime : disputeformData.TxnsDateTime;
    let DisputeID =
      row !== undefined ? row.disputeID : disputeformData.DisputeID;

    if (row !== undefined) {
      setDisputeformData({
        DisputeID: DisputeID,
        ReferenceNumber: ReferenceNumber,
        TxnsDateTime: formatDate(TxnsDateTime),
      });
    }

    await MaximusAxios.post(
      "api/DMSReport/GetAttachmentsData",
      {
        DisputeID: DisputeID,
        TxnDateTime: formatDate(TxnsDateTime),
        ReferenceNumber: ReferenceNumber,
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setIsLoading(false);
        let DataTable = [];
        if (
          response.data === null ||
          response.data === undefined ||
          response.data.length === 0
        ) {
          //setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'No Attachments Present' });
          //return false;
        } else {
          DataTable = response.data;
        }
        setAttachmentsTable(DataTable);
        setShowAttachments(true);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }

        setShowAttachments(false);
        setIsLoading(false);
        return false;
      });
  };



  const handleClientChange = (value) => {
    setSelectedClientValue(value);
    setSelectedChannelValue(null);
    setSelectedModeValue(null);

    try {
      setIsLoading(true);

      if (value.clientID !== "0") {
        MaximusAxios.get(
          "api/DynamicFileConfig/GetChannelOptionList?ClientID=" +
            value.clientID +
            "&UserID=" +
            currentUser.user.username,
          { mode: "cors" }
        ).then((resultChannel) => {
          setOptionsChannelType(resultChannel.data);

          setIsLoading(false);
        });
      }
    } catch (ex) {
      console.log(ex);
      setIsLoading(false);
    }
  };

  const handleModeChange = (value) => {
    setSelectedModeValue(value);
  };

  const onActionClick = (ReferenceNumber, TxnsDateTime, disputeID) => {
    setIsLoading(true);

    setDisputeformData({
      DisputeID: disputeID,
      ReferenceNumber: ReferenceNumber,
      TxnsDateTime: formatDate(TxnsDateTime),
    });

    MaximusAxios.post(
      "api/DMSReport/GetDisputeByReferenceNumber",
      {
        ClientID: selectedClientValue.clientID,
        ChannelID: selectedChannelValue.value,
        ModeID: selectedModeValue.value,
        NetworkType: "1",
        //FromDateTxns:,
        //ToDateTxns:,
        TxnDateTime: formatDate(TxnsDateTime),
        ReferenceNumber: ReferenceNumber,
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setIsLoading(false);
        setDisputeAttachmentModal(true);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  const btnStatusSubmit = () => {
    BulkRaiseDispute();
  };
  const BulkRaiseDispute = async () => {
    let data = UnmatchedTxnsReport.filter(
      (item) => item.isChecked === true
    ).map((rowItem) => {
      return {
        DisputeID: rowItem.disputeID,
        TxnID: rowItem.txnID.toString(),
        ClientID: rowItem.clientID, // Add these fields if they exist
        ChannelID: rowItem.channelID,
        ModeID: rowItem.modeID,
        TerminalID: rowItem.terminalID,
        ReferenceNumber: rowItem.referenceNumber,
        CardNumber: rowItem.cardNumber,
        CardType: rowItem.cardType,
        TxnsType: rowItem.txnsType,
        FromAccount: rowItem.fromAccount,
        TxnsDateTime: formatDate(rowItem.txnsDateTime), // Convert to ISO string
        TxnsAmount: rowItem.txnsAmount,
        ResponseCode: rowItem.responseCode,
        Status: rowItem.status,
        ReasonCode: rowItem.reasonCode,
        AdjType: rowItem.adjType,
        DisputeAmount: rowItem.disputeAmount,
        ContactNo: rowItem.contactNo,
        DisputeDate: formatDate(rowItem.disputeDate),
        UserID: rowItem.userID,
        IsChecker: rowItem.isChecker, // Ensure this property is included
      };
    });
    try {
      await MaximusAxios.post("api/DMSReport/BulkRaiseDispute", data, {
        mode: "cors",
      });
      onSubmit();
      setIsLoading(false);
      setShowMessageBox({
        isShow: true,
        alertVariant: "info",
        alertTitle: "Status Submit",
        alertMessage: "Dispute Updated Successfully",
      });
      setDisputeAttachmentModal(false);
    } catch (error) {
      if (error.response) {
        setShowMessageBox({
          isShow: true,
          alertVariant: "danger",
          alertTitle: "Error",
          alertMessage: "Error occurred while processing your request",
        });
      }
      setDisputeAttachmentModal(false);
      setIsLoading(false);
    }
  };

  const OnSelectAll = (e) => {
    const Checked = e.target.checked;

    let Values = UnmatchedTxnsReport.map((item) => {
      return {
        ...item,
        isChecked: Checked,
        userID: currentUser.user.username,
        isChecker: IsUserChecker,
      };
    });
    setUnmatchedTxnsReport(Values);
  };

  const OnChangeCheckBoxValues = (e, row) => {
    const Checked = e.target.checked;

    let Values = UnmatchedTxnsReport.map((item) => {
      if (item.txnID === row.txnID) {
        return {
          ...item,
          isChecked: Checked,
          userID: currentUser.user.username,
          isChecker: IsUserChecker,
        };
      }
      return {
        ...item,
        userID: currentUser.user.username,
        isChecker: IsUserChecker,
      };
    });

    setUnmatchedTxnsReport(Values);
  };

  const handleDisputeTypeChange = (type, prop, rowindex, row) => {
    if (type === "checker") {
      let Value = prop.label;
      let Values = UnmatchedTxnsReport.map((item) => {
        if (item.txnID === row.txnID) {
          return {
            ...item,
            ...row,
            adjType: Value,
            isChecked: true,
            userID: currentUser.user.username,
            isChecker: IsUserChecker,
          };
        }
        return {
          ...item,
          userID: currentUser.user.username,
          isChecker: IsUserChecker,
        };
      });

      setUnmatchedTxnsReport(Values);
    } else if (type === "maker") {
      let Value = prop.label;
      let Values = UnmatchedTxnsReport.map((item) => {
        if (item.txnID === row.txnID) {
          return {
            ...item,
            ...row,
            adjType: Value,
            isChecked: true,
            userID: currentUser.user.username,
            isChecker: IsUserChecker,
          };
        }
        return {
          ...item,
          userID: currentUser.user.username,
          isChecker: IsUserChecker,
        };
      });

      setUnmatchedTxnsReport(Values);
    }

      MaximusAxios.get(
      "api/DMSReport/GetReasonCodeOptionList?ClientID=" +
        selectedClientValue.clientID +
        "&ChannelID=" +
        selectedChannelValue.value +
        "&AdjType=" +
        prop.label,
      { mode: "cors" }
    ).then((resultMode) => {
      setReasonCodeOptions(resultMode.data);
    });

  };

  const handleReasonCodeChange = (type, prop, rowindex, row) => {
    if (type === "checker") {
      let Value = prop.value;
      let Values = UnmatchedTxnsReport.map((item) => {
        if (item.txnID === row.txnID) {
          return {
            ...item,
            ...row,
            reasonCode: Value,
            isChecked: true,
            userID: currentUser.user.username,
            isChecker: IsUserChecker,
          };
        }
        return {
          ...item,
          userID: currentUser.user.username,
          isChecker: IsUserChecker,
        };
      });

      setUnmatchedTxnsReport(Values);
    } else if (type === "maker") {
      let Value = prop.value;
      let Values = UnmatchedTxnsReport.map((item) => {
        if (item.txnID === row.txnID) {
          return {
            ...item,
            ...row,
            reasonCode: Value,
            isChecked: true,
            userID: currentUser.user.username,
            isChecker: IsUserChecker,
          };
        }
        return {
          ...item,
          userID: currentUser.user.username,
          isChecker: IsUserChecker,
        };
      });

      setUnmatchedTxnsReport(Values);
    }
  };

  const onCheckboxChange = ({ items }) => {};

  const onSubmit = async () => {
    console.log(formatDate(startDate) + " " + formatDate(endDate));

    if (selectedClientValue === null || selectedClientValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      alert("Please select Channel!");
      return false;
    }

    if (selectedModeValue === undefined || selectedModeValue === null) {
      alert("Please select mode Type!");
      return false;
    }

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

     
    let ChannelId = 0;

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      ChannelId = 0;
    } else {
      ChannelId = selectedChannelValue.value;
    }

    let ModeId = 0;

    if (selectedModeValue === undefined || selectedModeValue === null) {
      ModeId = 0;
    } else {
      ModeId = selectedModeValue.value;
    }

    let referenceNumberValue = 0;

    if (referenceNumber === undefined || referenceNumber === null) {
      referenceNumberValue = null;
    } else {
      referenceNumberValue = referenceNumber.value;
    }

    let amountValue = "0"; 

    let fromAccountValue = "0";

    if (fromAccount === undefined || fromAccount === null) {
      fromAccountValue = null;
    } else {
      fromAccountValue = fromAccount.value;
    }

    setIsLoading(true);

    MaximusAxios.post(
      "api/DMSReport/GetDisputeRaiseData",
      {
        ClientID: selectedClientValue.clientID,
        ChannelID: ChannelId,
        ModeID: ModeId,
        FromDate: formatDate(startDate),
        ToDate: formatDate(endDate),
        referenceNumber: referenceNumberValue,
        TxnsAmount: amountValue,
        fromAccount: fromAccountValue,
      },
      { mode: "cors" }
    )
      .then(function (response) {

        let Values = response.data.map((item, i) => ({
          ...item,
          isChecked: false,
          userID: currentUser.user.username,
          isChecker: IsUserChecker,
        }));

        console.log(Values);

        setUnmatchedTxnsReport(Values);
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "No records found",
          });
        }
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        setIsLoading(false);
      });
  };

  //const onSubmit = () => {

  // };
  const handleDisputeAmtChange = (row, type, value) => {
    if (parseFloat(row.txnsAmount) < parseFloat(value)) {
      setUnmatchedTxnsReport((p) =>
        p.map((item) => {
          if (item.txnID === row.txnID) {
            return { ...item, disputeAmount: row.txnsAmount, isChecked: true };
          } else return item;
        })
      );
    } else {
      setUnmatchedTxnsReport((p) =>
        p.map((item) => {
          if (item.txnID === row.txnID) {
            return { ...item, disputeAmount: parseFloat(value) };
          } else return item;
        })
      );
    }
  };
  const handleContactChange = (row, type, value) => {
    if (value.length > 0) {
      setUnmatchedTxnsReport((p) =>
        p.map((item) => {
          if (item.txnID === row.txnID) {
            return { ...item, contactNo: value, isChecked: true };
          } else return item;
        })
      );
    } else {
    }
  };

  const handleDisputeDateChange = (row, type, value) => {
    if (value !== null) {
      setUnmatchedTxnsReport((p) =>
        p.map((item) => {
          if (item.txnID === row.txnID) {
            return { ...item, disputeDate: formatDate(value), isChecked: true };
          } else return item;
        })
      );
    } else {
    }
  };

  const handleInputChange = (value) => {
    setValue(value);
  };

  const [UnmatchedTxnsReport, setUnmatchedTxnsReport] = useState(null);
  //   Date Calendar
  const [startDate, setStartDate] = useState(new Date());
  //   Date Calendar
  const [endDate, setEndDate] = useState(new Date());

  const setStartDateValue = (value) => {
    setStartDate(value);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date ");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    setUnmatchedTxnsReport(null);
  };

  const formatDate = (date) => {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const onReset = (e) => {
    e.preventDefault();
    // window.location.reload(false);
    setSelectedClientValue(null);
    setReferenceNumber(""); 
    setFromAccount("");
    setUnmatchedTxnsReport(null);
    setSelectedChannelValue(null);
    setSelectedModeValue(null);
    setStartDate(null);
    setEndDate(null);
  };

  const OnFileUpload = async () => {
    if (currentUser !== null && currentUser.user !== null) {
      try {
        let alertMessages = "";

        if (importFile === null || importFile === undefined) {
          alertMessages += "Please select File. \n";
        } else if (importFile.length === 0) {
          alertMessages += "Please select File. \n";
        }

        if (alertMessages.length > 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Mandatory Field",
            alertMessage: alertMessages,
          });
          return false;
        }

        var arr = [];
        for (var i = 0; i < importFile.length; i++) {
          arr.push(importFile[i]);
        }

        if (arr.length > 0) {
          setIsLoading(true);

          const posts = await Promise.all(
            arr.map(async (file) => {
              const data = new FormData();
              data.append("DisputeID", disputeformData.DisputeID);
              data.append("ReferenceNumber", disputeformData.ReferenceNumber);
              data.append("TxnsDateTime", disputeformData.TxnsDateTime);
              data.append("Attachment", file);

              //console.log(data);

              return await axios
                .post("api/DMSReport/UploadDisputeAttachments", data, {
                  headers: postHeader(),
                  mode: "cors",
                })
                .then(
                  (res) => {
                    return res.data;
                  },
                  (error) => {
                    return `${error}`;
                  }
                );
            })
          );

          if (posts !== null && posts.length > 0) {
            posts.forEach((post) => {
              alertMessages += `${post} \n`;
            });
          }
          if (alertMessages.length > 0) {
            setShowMessageBox({
              isShow: true,
              alertVariant: "info",
              alertTitle: "File Upload Status",
              alertMessage: alertMessages,
            });
          }
          setImportFile(null);
          OnShowAttachments();
          setIsLoading(false);
        }
      } catch (ex) {
        console.log(ex);
        setIsLoading(false);
      }
    } else {
      alert("Session Timeout");
    }
  };
  const handleuploadFile = async (files) => {
    setImportFile(files);
    var FileNames = "";
    for (var i = 0; i < files.length; i++) {
      FileNames = FileNames + files[i].name + ", ";
    }
    if (files.length === 0) {
      setFileName("No File Found");
    } else if (files.length > 1) setFileName(`Files Count ${files.length}`);
    else setFileName(FileNames);
  };

  return (
    <div className="configLeft dynamicContainer">
      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="unmatchedFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="unmatchedFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#unmatchedFiltersCollapse"
                aria-expanded="true"
                aria-controls="unmatchedFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="unmatchedFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="unmatchedFiltersHeading"
              data-bs-parent="#unmatchedFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedClientValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      onChange={handleChannelChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlMode">Mode Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlMode"
                      value={selectedModeValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsModeType.map((x) => ({
                        value: x.modeID,
                        label: x.modeName,
                      }))}
                      onChange={handleModeChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: "-10px", right: "10px" }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: "-10px", left: "10px" }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="referenceNumber">Reference Number</label>
                    <input
                      type="text"
                      id="referenceNumber"
                      placeholder="Enter Reference Number"
                      value={referenceNumber}
                      className="inputTextBox"
                      onChange={(e) => setReferenceNumber(e.target.value)}
                    />
                  </div> 

                  <div className="clientNameSelect col">
                    <label htmlFor="fromAccount">From Account</label>
                    <input
                      type="text"
                      id="fromAccount"
                      placeholder="Enter From Account"
                      value={fromAccount}
                      onChange={(e) => setFromAccount(e.target.value)}
                      className="inputTextBox"
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onSubmit}
                    disabled={isShow}
                  >
                    Show
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Data Grid*/}
      <div className="configLeftBottom">
        <div>
          {(UnmatchedTxnsReport === null ||
            UnmatchedTxnsReport.length === 0) && (
            <div className="tableBorderBox pb-3 pt-3">
              <div className="clientNameSelect configFormatEntities">
                <p className="text-danger font-size12">No Records </p>
              </div>
            </div>
          )}

          {/* Table */}
          {UnmatchedTxnsReport !== null && UnmatchedTxnsReport.length > 0 ? (
            <div className="tableBorderBox pt-3">
              <div className="w-100 table-responsive">
                <div className="table-responsive tableContentBox">
                  <table
                    id="gvMatchingList"
                    className="table table-striped table-hover table-borderless align-middle"
                    style={{ width: "100%" }}
                  >
                    <thead>
                      <tr>
                        <>
                          {Object.keys(UnmatchedTxnsReport[0]).map((item) => {
                            if (item === "disputeID" || item === "isChecked") {
                              return <></>;
                            }
                            if (item === "isChecked") {
                              return (
                                <>
                                  <th key={item} scope="col">
                                    <div
                                      style={{
                                        padding: "10px 0",
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        flexDirection: "row",
                                        gap: "5px",
                                      }}
                                    >
                                      {`Select All`}
                                      <input
                                        type="checkbox"
                                        onChange={OnSelectAll}
                                      />
                                    </div>
                                  </th>
                                  <th>Upload File</th>
                                </>
                              );
                            } else {
                              return (
                                <th key={item} scope="col">
                                  {splitCamelCase(item)}
                                </th>
                              );
                              // return (<th key={item} scope="col">{splitCamelCase(item)}</th>);
                            }
                          })}
                        </>
                      </tr>
                    </thead>
                    <tbody>
                      {UnmatchedTxnsReport.map((row, rowindex) => (
                        <tr key={rowindex}>
                          {Object.keys(row).map((column, colindex) => {
                            if (
                              column === "disputeID" ||
                              column === "isChecked"
                            ) {
                              return <></>;
                            } else if (column === "isChecked") {
                              return (
                                <>
                                  <td key={`${rowindex}${colindex}`}>
                                    <input
                                      type="checkbox"
                                      onChange={(e) =>
                                        OnChangeCheckBoxValues(e, row)
                                      }
                                      checked={
                                        UnmatchedTxnsReport.length === 0
                                          ? false
                                          : UnmatchedTxnsReport[rowindex]
                                              .isChecked
                                      }
                                    />
                                  </td>
                                  <td>
                                    <div className="clientNameSelect col">
                                      <span>
                                        <button
                                          type="button"
                                          className="iconButtonBox"
                                          onClick={() =>
                                            OnShowAttachments(row, rowindex)
                                          }
                                        >
                                          <img
                                            style={{
                                              width: "24px",
                                              height: "24px",
                                            }}
                                            src={AttachmentsIcon}
                                            alt="Attachments"
                                          />
                                        </button>
                                      </span>
                                    </div>
                                  </td>
                                </>
                              );
                            } else if (column === "disputeAmount") {
                              return (
                                <>
                                  <td>
                                    <div
                                      className="clientNameSelect col"
                                      style={{ width: "150px" }}
                                    >
                                      <input
                                        id="maker"
                                        value={parseFloat(row.disputeAmount)}
                                        disabled={IsUserChecker}
                                        onChange={(e) =>
                                          handleDisputeAmtChange(
                                            row,
                                            "disputeAmount",
                                            e.target.value
                                          )
                                        }
                                        type="text"
                                        className="form-control"
                                        style={{ padding: "0.2rem" }}
                                      />
                                    </div>
                                  </td>
                                </>
                              );
                            } else if (column === "adjType") {
                              return (
                                <>
                                  <td>
                                    <div
                                      className="clientNameSelect col"
                                      style={{ width: "150px" }}
                                    >
                                      <Select
                                        value={{
                                          value:
                                            row.adjType.length > 0
                                              ? row.adjType
                                              : `0`,
                                          label:
                                            row.adjType.length > 0
                                              ? row.adjType
                                              : `Select`,
                                        }}
                                        options={AdjTypeOptions.map(
                                          (option) => ({
                                            value: option.value,
                                            label: option.label,
                                          })
                                        )}
                                        id="ddlAdjType"
                                        onChange={(e) =>
                                          handleDisputeTypeChange(
                                            "maker",
                                            e,
                                            rowindex,
                                            row
                                          )
                                        }
                                        classNamePrefix="reactSelectBox"
                                      />
                                    </div>
                                  </td>
                                </>
                              );
                            } else if (column === "contactNo") {
                              return (
                                <>
                                  <td>
                                    <div
                                      className="clientNameSelect col"
                                      style={{ width: "150px" }}
                                    >
                                      <input
                                        id="maker"
                                        value={row.contactNo}
                                        disabled={IsUserChecker}
                                        onChange={(e) =>
                                          handleContactChange(
                                            row,
                                            "contactNumber",
                                            e.target.value
                                          )
                                        }
                                        type="text"
                                        className="form-control"
                                        style={{ padding: "0.2rem" }}
                                      />
                                    </div>
                                  </td>
                                </>
                              );
                            } else if (column === "disputeDate") {
                              return (
                                <>
                                  <td>
                                    <div
                                      className="clientNameSelect col"
                                      style={{ width: "150px" }}
                                    >
                                      <DatePicker
                                        renderCustomHeader={({
                                          date,
                                          changeYear,
                                          changeMonth,
                                          decreaseMonth,
                                          increaseMonth,
                                          prevMonthButtonDisabled,
                                          nextMonthButtonDisabled,
                                        }) => (
                                          <div
                                            style={{
                                              margin: 1,
                                              display: "flex",
                                              justifyContent: "center",
                                            }}
                                          >
                                            <button
                                              onClick={decreaseMonth}
                                              disabled={prevMonthButtonDisabled}
                                            >
                                              <span
                                                className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                                                style={{
                                                  top: "-10px",
                                                  right: "10px",
                                                }}
                                              ></span>
                                            </button>
                                            <select
                                              value={getYear(date)}
                                              onChange={({
                                                target: { value },
                                              }) => changeYear(value)}
                                            >
                                              {years.map((option) => (
                                                <option
                                                  key={option}
                                                  value={option}
                                                >
                                                  {option}
                                                </option>
                                              ))}
                                            </select>

                                            <select
                                              value={months[getMonth(date)]}
                                              onChange={({
                                                target: { value },
                                              }) =>
                                                changeMonth(
                                                  months.indexOf(value)
                                                )
                                              }
                                            >
                                              {months.map((option) => (
                                                <option
                                                  key={option}
                                                  value={option}
                                                >
                                                  {option}
                                                </option>
                                              ))}
                                            </select>

                                            <button
                                              onClick={increaseMonth}
                                              disabled={nextMonthButtonDisabled}
                                            >
                                              <span
                                                className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                                                style={{
                                                  top: "-10px",
                                                  left: "10px",
                                                }}
                                              ></span>
                                            </button>
                                          </div>
                                        )}
                                        selected={
                                          row.disputeDate === ""
                                            ? null
                                            : new Date(row.disputeDate)
                                        }
                                        dateFormat="dd/MM/yyyy"
                                        onChange={(date) =>
                                          handleDisputeDateChange(
                                            row,
                                            "disputeDate",
                                            date
                                          )
                                        }
                                        className="reportDate"
                                        maxDate={new Date()}
                                      />
                                    </div>
                                  </td>
                                </>
                              );
                            } else if (column === "ReasonCode") {
                              return (
                                <>
                                  <td>
                                    <div
                                      className="clientNameSelect col"
                                      style={{ width: "100px" }}
                                    >
                                      <Select
                                        value={{
                                          value:
                                            row.reasonCode.length > 0
                                              ? row.reasonCode
                                              : `0`,
                                          label:
                                            row.reasonCode.length > 0
                                              ? row.reasonCode
                                              : `Select`,
                                        }}
                                        options={ReasonCodeOptions.map(
                                          (option) => ({
                                            value: option.value,
                                            label: option.label,
                                          })
                                        )}
                                        id="ddlReasonCode"
                                        onChange={(e) =>
                                          handleReasonCodeChange(
                                            "maker",
                                            e,
                                            rowindex,
                                            row
                                          )
                                        }
                                        classNamePrefix="reactSelectBox"
                                      />
                                    </div>
                                  </td>
                                </>
                              );
                            } else {
                              return (
                                <td key={`${rowindex}${colindex}`}>
                                  {row[column]}
                                </td>
                              );
                            }
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <Modal.Footer>
                <button
                  type="button"
                  className="btnPrimary ms-2"
                  onClick={() => {
                    btnStatusSubmit();
                  }}
                >
                  Submit
                </button>
              </Modal.Footer>
            </div>
          ) : null}
          {isShow ? (
            <div className="spinner-container">
              <div className="loading-spinner"></div>
            </div>
          ) : (
            <>
              {/* Show Attachments */}
              {ShowAttachments && (
                <Modal
                  show={ShowAttachments}
                  onHide={() => setShowAttachments(!ShowAttachments)}
                  centered
                  className="defaultThemeModal saveFiltersModal reportTableModal"
                >
                  <Modal.Header closeButton>
                    <Modal.Title className="fontSize16-sm letterSpacing-2">
                      Attachments Details
                    </Modal.Title>
                  </Modal.Header>
                  <Modal.Body className="text-center">
                    <div className="w-100 table-responsive">
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          margin: "20px 0",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            flexDirection: "row",
                            margin: "20px 0",
                          }}
                        >
                          <div className="FileWhiteBox">
                            <p
                              className="fontSize14 fontWeight-500 letterSpacing-2 mb-1"
                              id="selectheading"
                            >
                              Select File{" "}
                              <span className="text-danger font-size13">*</span>
                            </p>
                            <div className="d-flex align-items-center">
                              <div className="d-flex align-items-center">
                                <div className="lightWhiteBox text-center">
                                  <div className="UploadPanel">
                                    <p className="fontSize14 fontWeight-500 colorPrimaryDefault browseFileText">
                                      Browse File
                                    </p>
                                    <FileUploader
                                      handleChange={handleuploadFile}
                                      name="file"
                                      types={fileTypes}
                                      multiple
                                    />
                                    <p className="fontSize14 dropFileColor">
                                      {importFile
                                        ? "File name: " + fileName
                                        : ""}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <div className="text-center btnsBtm">
                                <button
                                  type="button"
                                  className="btnPrimary ms-2"
                                  onClick={() => OnFileUpload()}
                                >
                                  Upload Files
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                        {AttachmentsTable.length > 0 ? (
                          <table className="table table-striped table-hover table-borderless align-middle">
                            <thead>
                              <tr>
                                {Object.keys(AttachmentsTable[0]).map(
                                  (item) => {
                                    if (item === "attachment") {
                                      return (
                                        <th key={item} scope="col">
                                          {"Action"}
                                        </th>
                                      );
                                    } else if (
                                      item === "contentType" ||
                                      item === "fileType"
                                    ) {
                                      return <></>;
                                    } else
                                      return (
                                        <th key={item} scope="col">
                                          {item}
                                        </th>
                                      );
                                  }
                                )}
                              </tr>
                            </thead>
                            <tbody>
                              {AttachmentsTable.map((row, rowindex) => (
                                <tr key={rowindex}>
                                  {Object.keys(row).map((column, colindex) => {
                                    if (column === "attachment") {
                                      return (
                                        <td key={`${rowindex}${colindex}`}>
                                          <div style={{ display: "flex" }}>
                                            <button
                                              type="button"
                                              className="iconButtonBox"
                                              onClick={() =>
                                                DownloadAttachment(row)
                                              }
                                            >
                                              <img
                                                style={{
                                                  width: "24px",
                                                  height: "24px",
                                                }}
                                                src={DownloadIcon}
                                                alt="Download"
                                              />
                                            </button>
                                            <button
                                              type="button"
                                              className="iconButtonBox"
                                              onClick={() =>
                                                DeleteAttachment(row)
                                              }
                                            >
                                              <img
                                                style={{
                                                  width: "16px",
                                                  height: "16px",
                                                }}
                                                src={DeleteIcon}
                                                alt="Delete"
                                              />
                                            </button>
                                          </div>
                                        </td>
                                      );
                                    } else if (
                                      column === "contentType" ||
                                      column === "fileType"
                                    ) {
                                      return <></>;
                                    } else {
                                      return (
                                        <td key={`${rowindex}${colindex}`}>
                                          {row[column]}
                                        </td>
                                      );
                                    }
                                  })}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        ) : (
                          <></>
                        )}
                      </div>
                    </div>
                  </Modal.Body>
                </Modal>
              )}
            </>
          )}
        </div>
      </div>
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default DisputeRaise;
