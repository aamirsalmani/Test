import React, { useState } from "react";
import { Link, Navigate, Route, Routes, useLocation } from "react-router-dom";

import '../disputeStyle.css';
import DisputeRaise from "./DisputeRaise";
import DisputeTracking from "./DisputeTracking";

const TabsList = ({ data }) => {

    const loc = useLocation();
    const visibleTab = loc.pathname.split('/').pop();

    return (data.map((item) =>
        <Link to={item.path} style={{ position: "relative" }}>
            <div  key={item.name} className={visibleTab === item.path ? "tab-title tab-title--active" : "tab-title"}>
                {item.name}
            </div>
        </Link>
    ));
};

const pathData= [{id:0,path:'1',name:"Dispute Tracking"}, {id:1,path:'2',name:"Dispute Raise"}]

const DisputeRaiseTrackingMain = () => {
    const [visibleTab, setVisibleTab] = useState("Dispute Tracking");

    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Dispute Raise and Tracking
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Dispute Management</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Dispute Raise and Tracking</p>
                </div>
            </div>
            {/* Config Tabs */}
            <div className="d-flex justify-content-between align-items-center ">
                <div className="tabs-titles">
                    <TabsList data={pathData} />
                </div>
            </div>
            <Routes>
                <Route path='1' element={<DisputeTracking />} />
                <Route path='2' element={<DisputeRaise />} />
                <Route index element={<Navigate to='1' />} />
            </Routes>
        </div>
    )

}

export default DisputeRaiseTrackingMain;