import React from "react";
import { useSelector } from "react-redux";
// CSS
import "../../common/traceReport.css"; 
// Components
import SidebarMain from "../../common/SidebarMain";
import DisputeRaiseTrackingMain from "./DisputeRaiseTrackingMain";

const DisputeRaiseTrackingReport = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView">
        <DisputeRaiseTrackingMain />
    </div>
  );
};

export default DisputeRaiseTrackingReport;
