﻿import React, { useState, useEffect, Fragment } from "react";
import './downloadsReport.css';
import Select from "react-select";
import AsyncSelect from 'react-select/async';
import { Modal, Button, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../common/apiURL" ;
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { useSelector } from "react-redux";

import { saveAs } from "file-saver";
//Images
// import btnPending from '../../images/common/pending-icon.svg';
import btnPending from '../../images/common/system-pending.svg';
import btnCompleted from '../../images/common/cloud-240.svg';
import btnError from '../../images/common/error.svg'
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
import { getYear, getMonth } from "date-fns";

import "jspdf-autotable";
import { splitCamelCase } from "../common/Utils";
import postHeader from "../../pages/login/services/post-header";



const DownloadsReportMainWindow = () => {
    const [startDate, setStartDate] = useState(new Date());
    const [endDate, setEndDate] = useState(new Date());
    const [inputValue, setValue] = useState('0');
    const [selectedClientValue, setSelectedClientValue] = useState(null);
    const [optionsChannelType, setOptionsChannelTypeValue] = useState([{ channelID: "0", channelName: "--Select--" }]);
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);
    const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "--Select--" }]);
    const [selectedModeValue, setSelectedModeValue] = useState(null);
    const [RunRecon, setRunRecon] = useState(null);
    const [FileStatus, setFileStatus] = useState(false);
    const [FileList, setFileList] = useState(null);
    const currentUser = useSelector((state) => state.authReducer);
    const [ClientChange, setClientChange] = useState(false);



    useEffect(() => {
        if (selectedClientValue) {
            setshowModal(false);
            setRunRecon(null);
            handleClientChange(selectedClientValue);
        }
    }, [ClientChange]);

    const onStatus = (item) => {
        setFileList(null);
        setIsLoading(true);
        setFileStatus(false);
        setConfirmEntry(false);
        setshowModal(false);
        MaximusAxios.post('api/RunReconProcess/GetRunReconFileStatusList', {
            ClientID: (item.clientID),
            ChannelID: (item.channelID),
            ModeID: (item.modeID),
            Fromdate: formatDateNew(item.fromdate),
            Todate: formatDateNew(item.todate),
            CreatedDate: item.createdDate

        }, {  mode: 'cors' })
            .then(function (response) {
                setFileList(response.data);
                setFileStatus(true);
                setIsLoading(false);
                setConfirmEntry(true);
                setshowModal(true);
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: error.response.data });
                }
                setIsLoading(false);
            });
    }


    const onReset = (e) => {
        e.preventDefault();
        setStartDate(null);
        setRunRecon(null);
        setEndDate(null);
        setSelectedClientValue(null)
       // window.location.reload(false);
    }

    const [ConfirmEntry, setConfirmEntry] = useState(false);
    const [showModal, setshowModal] = useState(false);
    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const fetchClientData = (inputValue) => {
        setStartDate(null);
        setRunRecon(null);
        setEndDate(null);
        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }
    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }
    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];
    const setStartDateValue = value => {
        setStartDate(value);
    }
    const setEndDateValue = value => {

        if (startDate === null) {
            setEndDate(null);
            alert('Please enter From date first');
        }
        else {
            if (startDate > value) {
                alert('To date must be greater than From date ');
                setEndDate(null);
            }
            else {
                setEndDate(value);
            }
        }

    }

    
    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }
    const formatDateNew = (inputDate) => {
        const parts = inputDate.split('/');

        const day = parts[0];
        const month = parts[1];
        const year = parts[2];

        const date = new Date(`${year}-${month}-${day}`);

        const formattedDate = [
            date.getFullYear(),
            ('0' + (date.getMonth() + 1)).slice(-2),
            ('0' + date.getDate()).slice(-2)
        ].join('-');

        return formattedDate;
    };

    const handleInputChange = value => {
        setValue(value);
    };

    const downloadReport = async (request) => {
        try {
            const response = await MaximusAxios.post('api/DownloadReport/GetReport', {
                UserID: request.UserID,
                DownloadStatus: request.DownloadStatus,
                StartDate: request.StartDate,
                EndDate: request.EndDate
            }, {  mode: 'cors' }
            );
            setRunRecon(response.data);
        } catch (error) {
            console.error('Error fetching download report:', error);
            // Handle error as needed
        }
    };



    const handleClientChange = value => {

        setSelectedClientValue(value);
        setSelectedChannelValue(null);
        setSelectedModeValue(null);
        setStartDate(null);
        setEndDate(null);
        setRunRecon(null);

        if (value.clientID !== '0' || selectedClientValue !== null) {

            MaximusAxios.get('api/RunReconProcess/GetChannelRunReconProcessList?ClientId=' + value.clientID + '&ChannelID=' + value.channelID, {  mode: 'cors' }).then(result => {
                setOptionsChannelTypeValue(result.data);
            });


        }

    }
    const handleChannelChange = value => {
        setSelectedChannelValue(value);
        setSelectedModeValue(null);
        setStartDate(null);
        setEndDate(null);


        if (value.value !== '0' && selectedClientValue.clientID !== '0') {
            return MaximusAxios.get('api/RunReconProcess/GetModeRunReconProcessList?ClientID=' + selectedClientValue.clientID + '&ChannelID=' + value.value, {  mode: 'cors' }).then(result => {
                setOptionsModeTypeValue(result.data);

            });
        }

    }
    const handleModeChange = value => {
        setSelectedModeValue(value);
        setStartDate(null);
        setEndDate(null);

    }


    $(document).ready(function () {

        if (RunRecon !== null && RunRecon.length > 0) {
            $('#gvRunRecon').DataTable();
        }
    });

    const handleSubmit = () => {

        if (currentUser !== null && currentUser.user !== null) {

            if (selectedClientValue === null || selectedClientValue.clientID === 0) {
                alert("Please select client!");
                return false;
            }

            if (startDate === undefined || startDate === null) {
                alert("Please enter From Date!");
                return false;
            }

            if (endDate === undefined || endDate === null) {
                alert("Please enter To Date!");
                return false;
            }

            setIsLoading(true);

            const request = {
                UserID: currentUser.user.username,
                DownloadStatus: "1",
                StartDate: formatDate(startDate),
                EndDate: formatDate(endDate)
            };

            downloadReport(request);
            setIsLoading(false);
        } else {
            alert('Session Timeout');
        }
    };



    const DownloadStatusButton = ({ SourceSVG, name, status }) => {


        return (

            <button className={`btnStatusOutline`} style={{ display: 'flex', padding: '5px 10px', gap: '10px', width: '100%', maxWidth: '120px' }}
            >
                <span style={{ width: '20px', boxSizing: 'border-box' }}><img src={SourceSVG} style={{ width: '20px' }} /></span>
                <span >{name}</span>
            </button>

        )
    }

    const DownloadFile = async (details) => {

        return await MaximusAxios
            .post(`api/DownloadReport/DownloadFile`, details,
                {  responseType: "blob" }
            )
            .then(function (response) {
                const contentDisposition = response.headers['content-disposition'];
                let fileName = 'downloadedFile';
                if (contentDisposition) {
                    const fileNameMatch = contentDisposition.match(/filename[^;=\n]*=([^;\n]*)/);
                    if (fileNameMatch.length > 1) {
                        fileName = fileNameMatch[1];
                    }
                }
                saveAs(response.data, fileName);
                // setIsLoading(false);
            })
            .catch(function (error) {
                if (error.response.status === 404) {
                    setShowMessageBox({
                        isShow: true,
                        alertVariant: "danger",
                        alertTitle: "Error",
                        alertMessage: "File Not Found",
                    });
                }
                // console.log(error.response);
                // setIsLoading(false);
            });


    };

    const buttonSVG = (status, row) => {

        const onClick = async (event) => {
            const details = {
                userID: row.UserID,         // Replace with actual user ID
                downloadStatus: "1",     // Example status, update accordingly
                startDate: formatDate(row.DownloadDate),         // Replace with actual start date
                endDate: formatDate(row.DownloadDate),           // Replace with actual end date
                id: row.ID                          // Replace with the actual ID
            };

            await DownloadFile(details);
        }


        const ButtonType = () => {
            switch (status) {
                case 0:
                    return (<DownloadStatusButton SourceSVG={btnPending} name={'InProgress'} status={status} />);
                case 1:
                    return (<DownloadStatusButton SourceSVG={btnCompleted} name={'Download'} status={status} />);
                case 2:
                    return (<DownloadStatusButton SourceSVG={btnError} name={'Not Found'} status={status} />);
                default:
                    return (<DownloadStatusButton SourceSVG={btnPending} name={'Pending'} status={status} />);
            }
        }

        return (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }} onClick={(event) => (onClick(event))}>
                <ButtonType />
            </div>
        )
    };

    const buttonClass = (status) => {
        switch (status) {
            case 0:
                return 'btnAwaiting';
            case 1:
                return 'btnCompleted';
            case 2:
                return 'btnFailed';
            default:
                return 'btnDefault';
        }
    };


    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Downloads Report
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Downloads</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorBlack">Downloads Report</p>
                </div>
            </div>

            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="runreconFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="runreconFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>
                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#runreconFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="runreconFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="runreconFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="runreconFiltersHeading"
                            data-bs-parent="#runreconFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedClientValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>
                                    {/*
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedChannelValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            onChange={handleChannelChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedModeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.modeName
                                                }
                                            ))}
                                            onChange={handleModeChange}
                                        />
                                    </div>
                                    */}
                                    <div className="clientNameSelect col">
                                        <label htmlFor="StartDate">From Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                <div
                                                    style={{
                                                        margin: 1,
                                                        display: "flex",
                                                        justifyContent: "center",
                                                    }}
                                                >
                                                    <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                    </button>
                                                    <select
                                                        value={getYear(date)}
                                                        onChange={({ target: { value } }) => changeYear(value)}
                                                    >
                                                        {years.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <select
                                                        value={months[getMonth(date)]}
                                                        onChange={({ target: { value } }) =>
                                                            changeMonth(months.indexOf(value))
                                                        }
                                                    >
                                                        {months.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                    </button>
                                                </div>
                                            )}
                                            selected={startDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setStartDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ToDate">To Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                <div
                                                    style={{
                                                        margin: 1,
                                                        display: "flex",
                                                        justifyContent: "center",
                                                    }}
                                                >
                                                    <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                    </button>
                                                    <select
                                                        value={getYear(date)}
                                                        onChange={({ target: { value } }) => changeYear(value)}
                                                    >
                                                        {years.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <select
                                                        value={months[getMonth(date)]}
                                                        onChange={({ target: { value } }) =>
                                                            changeMonth(months.indexOf(value))
                                                        }
                                                    >
                                                        {months.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                    </button>
                                                </div>
                                            )}
                                            selected={endDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setEndDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                </div>

                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={handleSubmit}
                                    >
                                        Show
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>



            {/* Config Left Bottom */}
            <div className="configLeftBottom">
                {(RunRecon === null || RunRecon.length === 0) &&
                    <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div>
                }
                {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
                {/* Table */}
                {(RunRecon !== null && RunRecon.length > 0) ? (
                    <div>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvRunRecon" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                        <thead>
                                            <tr>
                                                {/* Dynamically generate headers based on the keys of the first object */}
                                                {RunRecon.length > 0 && Object.keys(RunRecon[0]).map((key, index) => {
                                                    if (key === "FilePath") {
                                                        return (<Fragment key={index}></Fragment>);
                                                    }
                                                    else {
                                                        return (<th scope="col" key={index}>{splitCamelCase(key)}</th>)
                                                    }
                                                })}
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {RunRecon.map((row, rowIndex) => (
                                                <tr key={rowIndex}>
                                                    {/* Dynamically generate row data based on the object values */}
                                                    {Object.keys(row).map((col, colIndex) => {
                                                        if (col === "status") {
                                                            return (<td key={colIndex}>
                                                                <button
                                                                    type="button"
                                                                    className={`btnStatusOutline ${buttonClass(row[col])}`}
                                                                    onClick={() => onStatus(row)}
                                                                >
                                                                    {row[col]}
                                                                </button>

                                                            </td>);
                                                        }
                                                        else if (col === "FilePath") {
                                                            return (<></>);
                                                        }
                                                        else if (col === "FileStatus") {
                                                            return (<td key={colIndex}>
                                                                {buttonSVG(row[col], row)}
                                                            </td>);
                                                        }
                                                        else {
                                                            return (<td key={colIndex}>{row[col]}</td>);
                                                        }
                                                    }
                                                    )}

                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
        </>)}
            </div>

            <LoadingSpinner isShow={false} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default DownloadsReportMainWindow;
