import React from "react";
import { useSelector } from "react-redux";
// Components
import "../dynamicFileConfiguration/dynamicFileConfiguration.css";
import SidebarMain from "../common/SidebarMain";
import DynamicChannelConfigMainWindow from "./DynamicChannelConfigMainWindow";

const DynamicChannelConfig = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <DynamicChannelConfigMainWindow />
        </div>
    );
};

export default DynamicChannelConfig;
