﻿import React from "react";
import { useSelector } from "react-redux"; 
// Components
import "./dynamicFileConfiguration.css"; 
import SidebarMain from "../common/SidebarMain";
import DynamicFileConfigurationMainWindow from "./DynamicFileConfigurationMainWindow";

const DynamicFileConfiguration = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <DynamicFileConfigurationMainWindow />
        </div>
    );
};

export default DynamicFileConfiguration;
