﻿import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Select from "react-select";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import { FileUploader } from "react-drag-drop-files";
import MaximusAxios from "../common/apiURL";
import AsyncSelect from "react-select/async";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import authHeader from "../../pages/login/services/auth-header";
import postHeader from "../../pages/login/services/post-header";
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import $ from "jquery";
import "jquery/dist/jquery.min.js";
import ConfigImage from "../../images/common/configuration.svg";
import SettingdateImage from "../../images/common/settingdateicon.svg";
import { useSelector } from "react-redux";
import DeleteIcon from "../../images/common/redDelete.svg";
import FileuploadIcon from "../../images/common/fileupload.svg";
import axios from "axios";

const optionsDateTime = [
  { value: "TxnDateTime", label: "TxnDateTime" },
  { value: "TxnValueDateTime", label: "TxnValueDateTime" },
  { value: "TxnPostDateTime", label: "TxnPostDateTime" },
  { value: "FileDate", label: "FileDate" },
];

const SeparatorTypeOptions = [
  { value: "|", label: "|" },
  { value: "||", label: "||" },
  { value: "@", label: "@" },
  { value: "%", label: "%" },
  { value: ",", label: "," },
  { value: ":", label: ":" },
  { value: "!", label: "!" },
];

class DateTimeClass {
  constructor(Id, FormateValue, DateTimeType) {
    this.Id = Id;
    this.FormateValue = FormateValue;
    this.DateTimeType = DateTimeType;
  }
}

const DynamicFileConfigurationMainWindow = () => {
  const navigate = useNavigate();

  const currentUser = useSelector((state) => state.authReducer);
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [FileConfigList, setFileConfigList] = useState([]);

  const [inputValue, setValue] = useState("0");
  const fetchClientData = (inputValue) => {
    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  const handleInputChange = (value) => {
    setValue(value);
  };

  const [selectedClientValue, setSelectedValue] = useState(null);

  const [optionsNetworkType, setOptionsNetworkType] = useState([
    { channelID: "0", channelName: "ALL" },
  ]);
  const [selectedNetworkValue, setSelectedNetworkValue] = useState(null);

  const [optionsLogType, setOptionsLogType] = useState([]);
  const [selectedLogValue, setSelectedLogValue] = useState(null);

  const [optionsChannelType, setOptionsChannelType] = useState([
    { channelID: "0", channelName: "ALL" },
  ]);
  const [selectedChannelValue, setSelectedChannelValue] = useState(null);

  const [optionsModeType, setOptionsModeTypeValue] = useState([
    { modeID: "0", modeName: "ALL" },
  ]);
  const [selectedModeValue, setSelectedModeValue] = useState(null);

  const [optionsVendor, setOptionsVendorValue] = useState([
    { vendorID: "0", vendorName: "--Select--" },
  ]);
  const [selectedVendorValue, setSelectedVendorValue] = useState(null);

  const [selectedVendorId, setSelectedVendorId] = useState(null);

  const [isShowSeparator, setIsShowSeparator] = useState(false);

  const [isShowFileConfigModal, setShowFileConfigModal] = useState(false);
  const [ClientConfigOptions, setClientConfigOptions] = useState(false);
  const [selectedClientToCopy, setSelectedClientToCopy] = useState(null);

  //Added by Kaif 
const [FileNameText, setFileNameText] = useState(""); // From DB
const [selectionStart, setSelectionStart] = useState(null);
const [selectionEnd, setSelectionEnd] = useState(null);

 const handleTextSelection = () => {
    const selection = window.getSelection();
    const selectedText = selection.toString();
    if (!selectedText) return;

    const start = FileNameText.indexOf(selectedText);
    const end = start + selectedText.length;

    setSelectionStart(start);
    setSelectionEnd(end);
  };

  //

  const handleClientToCopyChange = value => {
    setSelectedClientToCopy(value);
  }

  const handleClientChange = (value) => {
    setSelectedValue(value);

    setSelectedLogValue(null);
    setSelectedVendorValue(null);
    setSelectedChannelValue(null);
    setSelectedModeValue(null);

    try {
      setIsLoading(true);

      if (value.clientID !== "0") {
        MaximusAxios.get(
          "api/DynamicFileConfig/GetLogTypeOptionList?ClientId=" +
          value.clientID,
          { mode: "cors" }
        ).then((result) => {
          setOptionsLogType(result.data);

          MaximusAxios.get(
            "api/DynamicFileConfig/GetChannelOptionList?ClientID=" +
            value.clientID,
            { mode: "cors" }
          ).then((resultChannel) => {
            setOptionsChannelType(resultChannel.data);
            setIsLoading(false);
          });

          MaximusAxios.get(
            "api/DynamicFileConfig/GetNetworkTypeOptionList?ClientID=" +
            value.clientID,
            { mode: "cors" }
          ).then((resultNetwork) => {
            setOptionsNetworkType(resultNetwork.data);
            //console.log(resultNetwork.data);
          });
        });

        MaximusAxios.get("/api/Common/GetReactFileTypeList", {
          mode: "cors",
        }).then((result1) => {
          setFileTypes(JSON.parse(result1.data));
        });
      }
    } catch (ex) {
      console.log(ex);
      setIsLoading(false);
    }
  };

  const handleNetworkChange = (value) => {
    setSelectedNetworkValue(value);
    setDateTimeFormatList([]);
    setShowDateTimeGrid(false);
  };

  const handleLogTypeChange = (value) => {
    setSelectedLogValue(value);

    setSelectedVendorValue(null);
    setSelectedChannelValue(null);
    setSelectedModeValue(null);
    setDateTimeFormatList([]);
    setShowDateTimeGrid(false);


    try {
      setIsLoading(true);

      if (value.value !== "0" && selectedClientValue.clientID !== "0") {
        return MaximusAxios.get(
          "api/DynamicFileConfig/GetVendorOptionList?ClientID=" +
          selectedClientValue.clientID +
          "&VendorType=" +
          value.value,
          { mode: "cors" }
        ).then((result) => {
          setOptionsVendorValue(result.data);

          MaximusAxios.get(
            "api/DynamicFileConfig/GetFileConfigList?ClientID=" +
            selectedClientValue.clientID +
            "&NetworkType=" +
            selectedNetworkValue.label +
            "&LogTypeID=" +
            value.value +
            "&ChannelID=0",
            { mode: "cors" }
          ).then((grid) => {
            setFileConfigList(grid.data);
            setIsLoading(false);
          });
        });
      }
    } catch (ex) {
      console.log(ex);
      setIsLoading(false);
    }
  };

  const handleVendorChange = (value) => {
    setSelectedVendorValue(value);
    setDateTimeFormatList([]);
    setShowDateTimeGrid(false);
  };

  const handleChannelChange = (value) => {
    setSelectedChannelValue(value);
    setSelectedModeValue(null);
    setDateTimeFormatList([]);
    setShowDateTimeGrid(false);

    let ChannelId = 0;
    if (value === undefined || value === null) {
      ChannelId = 0;
    } else {
      ChannelId = value.value;
    }

    MaximusAxios.get(
      "api/DynamicFileConfig/GetDynamicModeOptionList?ClientID=" +
      selectedClientValue.clientID +
      "&ChannelID=" +
      ChannelId,
      { mode: "cors" }
    ).then((resultMode) => {
      setOptionsModeTypeValue(resultMode.data);
      if (selectedLogValue !== undefined || selectedLogValue !== null) {
        MaximusAxios.get(
          "api/DynamicFileConfig/GetFileConfigList?ClientID=" +
          selectedClientValue.clientID +
          "&NetworkType=" +
          selectedNetworkValue.label +
          "&LogTypeID=" +
          selectedLogValue.value +
          "&ChannelID=" +
          ChannelId,
          { mode: "cors" }
        ).then((grid) => {
          setFileConfigList(grid.data);
        });
      }

      setIsLoading(false);
    });
  };

  const handleModeChange = (value) => {
    setSelectedModeValue(value);
    setDateTimeFormatList([]);
    setShowDateTimeGrid(false);
  };

  const onReset = (e) => {
    e.preventDefault();
    window.location.reload(false);
  };

  const Validate = () => {

    let alertMessages = "";

    if (selectedClientValue === null || selectedClientValue.clientID === 0) {
      alertMessages += "Please select client. \n";
    }

    if (selectedNetworkValue === undefined || selectedNetworkValue === null) {
      alertMessages += "Please select Network Type. \n";
    }

    if (selectedLogValue === undefined || selectedLogValue === null) {
      alertMessages += "Please select log Type. \n";
    }

    if (selectedVendorValue === undefined || selectedVendorValue === null) {
      alertMessages += "Please select vendor Type. \n";
    }

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      alertMessages += "Please select Channel. \n";
    }

    if (selectedModeValue === undefined || selectedModeValue === null) {
      alertMessages += "Please select mode Type. \n";
    }

    return alertMessages;
  };


  const onSubmit = () => {

    try {

      let alertMsg = Validate();

      if (alertMsg.length > 0) {
        setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMsg });
        return false;
      }
      else {
        setIsLoading(true);
        setFileConfigList(null);

        if (currentUser !== null && currentUser.user !== null) {

          MaximusAxios.post('api/DynamicFileConfig/GetClientList', {
            ClientID: selectedClientValue.clientID,
            NetworkType: selectedNetworkValue.label,
            LogTypeID: selectedLogValue.value,
            VendorID: selectedVendorValue.value,
            ChannelID: selectedChannelValue.value,
            ModeID: selectedModeValue.value,
            UserName: currentUser.user.username,
          }, { mode: 'cors' })
            .then(function (response) {

              setIsLoading(false);
              setClientConfigOptions(response.data);
              if (response.data !== null && response.data.length > 0) {
                setShowFileConfigModal(true);
              }
              else {
                MaximusAxios.post('api/DynamicFileConfig/AddUpdateDynamicFileConfig', {
                  ClientID: selectedClientValue.clientID,
                  NetworkType: selectedNetworkValue.label,
                  LogTypeID: selectedLogValue.value,
                  VendorID: selectedVendorValue.value,
                  ChannelID: selectedChannelValue.value,
                  ModeID: selectedModeValue.value,
                  UserName: currentUser.user.username,
                }, { mode: 'cors' })
                  .then(function (response) {

                    alert(response.data);

                    MaximusAxios.get('api/DynamicFileConfig/GetFileConfigList?ClientID=' + selectedClientValue.clientID + '&NetworkType=' + selectedNetworkValue.label + '&LogTypeID=' + selectedLogValue.value, { mode: 'cors' }).then(grid => {
                      setFileConfigList(grid.data);
                    });
                  })
                  .catch(function (error) {
                    console.log(error.response);
                    setIsLoading(false);
                  });

              }
            })
            .catch(function (error) {
              console.log(error.response);
              setIsLoading(false);
            });

        }
      }

    }
    catch (ex) {
      console.log(ex);
      setIsLoading(false);
    }

  }

  const onNewEntryClick = () => {

    try {

      let alertMsg = Validate();

      if (alertMsg.length > 0) {
        setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMsg });
        return false;
      }
      else {
        setIsLoading(true);
        setFileConfigList(null);

        if (currentUser !== null && currentUser.user !== null) {

          MaximusAxios.post('api/DynamicFileConfig/AddUpdateDynamicFileConfig', {
            ClientID: selectedClientValue.clientID,
            NetworkType: selectedNetworkValue.label,
            LogTypeID: selectedLogValue.value,
            VendorID: selectedVendorValue.value,
            ChannelID: selectedChannelValue.value,
            ModeID: selectedModeValue.value,
            UserName: currentUser.user.username,
          }, { mode: 'cors' })
            .then(function (response) {

              setIsLoading(false);
              setShowFileConfigModal(false);
              alert(response.data);

              MaximusAxios.get('api/DynamicFileConfig/GetFileConfigList?ClientID=' + selectedClientValue.clientID + '&NetworkType=' + selectedNetworkValue.label + '&LogTypeID=' + selectedLogValue.value, { mode: 'cors' }).then(grid => {
                setFileConfigList(grid.data);
              });
            })
            .catch(function (error) {
              console.log(error.response);
              setIsLoading(false);
            });


        }
      }

    }
    catch (ex) {
      console.log(ex);
      setIsLoading(false);
    }

  }

  const onExistingClick = () => {
    try {

      let alertMsg = Validate();

      if (selectedClientToCopy === null || selectedClientToCopy === undefined) {
        alertMsg += "Please select client to copy. \n";
      }

      if (alertMsg.length > 0) {
        alert(alertMsg);
        return false;
      }
      else {
        setIsLoading(true);
        setFileConfigList(null);

        if (currentUser !== null && currentUser.user !== null) {

          MaximusAxios.post('api/DynamicFileConfig/CopyExistingDynamicFileConfig', {
            ClientID: selectedClientValue.clientID,
            NetworkType: selectedNetworkValue.label,
            LogTypeID: selectedLogValue.value,
            VendorID: selectedVendorValue.value,
            ChannelID: selectedChannelValue.value,
            ModeID: selectedModeValue.value,
            UserName: currentUser.user.username,
            ClientIDToCopy: selectedClientToCopy.value,
          }, { mode: 'cors' })
            .then(function (response) {
              setSelectedClientToCopy(null);
              setIsLoading(false);
              setShowFileConfigModal(false);
              alert(response.data);

              MaximusAxios.get('api/DynamicFileConfig/GetFileConfigList?ClientID=' + selectedClientValue.clientID + '&NetworkType=' + selectedNetworkValue.label + '&LogTypeID=' + selectedLogValue.value, { mode: 'cors' }).then(grid => {
                setFileConfigList(grid.data);
              });
            })
            .catch(function (error) {
              console.log(error.response);
              setIsLoading(false);
            });


        }
      }
    }
    catch (ex) {
      console.log(ex);
      setIsLoading(false);
    }
  }


  const [isShowFileUploadModal, setShowFileUploadModal] = useState(false);
  const [selectedTable, setSelectedTable] = useState(null);
  const [selectedConfigID, setSelectedConfigID] = useState(null);
  const [isShowDateSettingModal, setShowDateSettingModal] = useState(false);
  const [isShowDateTimeGrid, setShowDateTimeGrid] = useState(false);

  const ShortCut = () => {
    navigate("/plaintextSplitter", { state: { id: 2 } });
  };

  const renderTooltipDelete = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to Remove
    </Tooltip>
  );

  const [fileName, setFileName] = useState();
  const [importFile, setImportFile] = useState();

  const [fileTypes, setFileTypes] = useState([
    "xlsx",
    "xls",
    "csv",
    "txt",
    "rc",
  ]);

  const [selectedFileTypeValue, setSelectedFileTypeValue] = useState(null);
  const [selectedFileSeparatorValue, setSelectedFileSeparatorValue] =
    useState(null);

  const [FileTypeOptions, setFileTypeOptions] = useState([]);

  const handleuploadFile = async (file) => {
    setImportFile(file);
    setSelectedFileTypeValue(null);

    if (file !== null) {
      setFileName(file.name);
      console.log(file);

      let FileExtension = file.name.slice(
        ((file.name.lastIndexOf(".") - 1) >>> 0) + 2
      );

      return MaximusAxios.get(
        "api/DynamicFileConfig/GetFileTypeList?FileExtension=" + FileExtension,
        { headers: authHeader(), mode: "cors" }
      )
        .then((result) => {
          setFileTypeOptions(result.data);
        })
        .catch(function (error) {
          console.log(error.response);
        });
    } else {
      setFileName("");
    }
  };

  const handleFileTypeChange = (value) => {
    console.log(value);
    setSelectedFileTypeValue(value);
    setIsShowSeparator(false);
    if (value.label === "Plaintext With Separator") {
      setIsShowSeparator(true);
    }
    else if (value.label === "CSV file with header" || value.label === "CSV file without header") {
      setIsShowSeparator(true);
      setSelectedFileSeparatorValue({ value: ",", label: "," });
    }
  };

  const handleFileSeparatorChange = (value) => {
    setSelectedFileSeparatorValue(value);
  };

  const onClickUpload = (LogType, ConfigID, VendorID) => {
    setShowFileUploadModal(true);
    setSelectedConfigID(ConfigID);
    setImportFile(null);
    setSelectedTable(LogType);
    setSelectedVendorId();
    setSelectedVendorId(VendorID);
    setFileTypeOptions([]);
    setSelectedFileTypeValue(null);
    setIsShowSeparator(false);
  };

  const onUploadClick = () => {
    console.log(selectedFileTypeValue);
    if (currentUser !== null && currentUser.user !== null) {
      try {
        let alertMessages = "";

        if (selectedConfigID === undefined || selectedConfigID === null) {
          alertMessages += "Please select Row. \n";
        }

        if (importFile === null || importFile.length === 0) {
          alertMessages += "Please select File. \n";
        }

        if (
          selectedFileTypeValue === null ||
          selectedFileTypeValue === undefined
        ) {
          alertMessages += "Please select File Type. \n";
        } else {
          if (selectedFileTypeValue.label === "Plaintext With Separator" || selectedFileTypeValue.label === "CSV file with header" || selectedFileTypeValue.label === "CSV file without header") {
            if (
              selectedFileSeparatorValue === null ||
              selectedFileSeparatorValue === undefined
            ) {
              alertMessages += "Please select Separator Type. \n";
            }
          }
        }

        if (alertMessages.length > 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Mandatory Field",
            alertMessage: alertMessages,
          });
          return false;
        }

        let SeparatorValue = "";
        if (selectedFileTypeValue.label === "Plaintext With Separator" || selectedFileTypeValue.label === "CSV file with header" || selectedFileTypeValue.label === "CSV file without header") {
          if (
            selectedFileSeparatorValue !== null &&
            selectedFileSeparatorValue !== undefined
          ) {
            SeparatorValue = selectedFileSeparatorValue.value;
          }
        }

        const data = new FormData();

        data.append("ConfigID", selectedConfigID);
        data.append("TableName", selectedTable);
        data.append("FileType", selectedFileTypeValue.value);
        data.append("Separator", SeparatorValue);
        data.append("ImportFile", importFile);
        data.append("UserName", currentUser.user.username);

        axios
          .post("api/DynamicFileConfig/UploadFile", data, {
            headers: postHeader(),
            mode: "cors",
          })
          .then(
            (res) => {
              // then print response status
              setIsLoading(false);
              //console.log(res.data);
              setShowFileUploadModal(false);
              if (res.data !== undefined && res.data !== null) {
                if (res.data.msg === "Success") {
                  if (
                    res.data.type === "Excel" ||
                    res.data.type === "CSV" ||
                    res.data.type === "Delimiter"
                  ) {
                    navigate("/spreadsheetSplitter", {
                      state: { id: res.data.fileConfigID },
                    });
                  }
                  if (res.data.type === "PlaintextWithoutSeparator") {
                    navigate("/plaintextSplitter", {
                      state: { id: res.data.fileConfigID },
                    });
                  }
                } else {
                  alert(res.data.msg);
                }
              }
            },
            (error) => {
              setIsLoading(false);
              console.log(error);
              setShowFileUploadModal(false);
            }
          );
      } catch (ex) {
        console.log(ex);
        setIsLoading(false);
      }
    } else {
      alert("Session Timeout");
    }
  };

  const onClickDate = (TableName, ConfigID) => {
    setIsLoading(true);
    setSelectionStart(null);
    setSelectionEnd(null);
     setFileNameText(""); 
    setSelectedTable(TableName);
    setSelectedConfigID(ConfigID);

    setDateTimeFormatList([]);
    setShowDateTimeGrid(false);

    MaximusAxios.get(
      "/api/DynamicFileConfig/GetDateTimeFormate?FileConfigID=" +
      ConfigID +
      "&TableName=" +
      TableName,
      { mode: "cors" }
    )
      .then((ConfigDateData) => {
        console.log(ConfigDateData);
        if (ConfigDateData.data !== null && ConfigDateData.data !== undefined) {
          //console.log(ConfigDateData.data);
          setIsLoading(false);

          if (
            ConfigDateData.data.fileConfigID !== null &&
            ConfigDateData.data.fileConfigID !== undefined
          ) {
            setFormateValue({
              TxnDateTimeDateFormat: ConfigDateData.data.txnDateTimeDateFormat,
              TxnValueDateTimeDateFormat:
                ConfigDateData.data.txnValueDateTimeDateFormat,
              TxnPostDateTimeDateFormat:
                ConfigDateData.data.txnPostDateTimeDateFormat,
              FileDateFormat: ConfigDateData.data.fileDateFormat,
            });

            // let maxId = 1;

            // if (ConfigDateData.data.txnDateTimeDateFormat !== undefined && ConfigDateData.data.txnDateTimeDateFormat !== null) {

            //     const txnDateTimeArray = ConfigDateData.data.txnDateTimeDateFormat.split(',');

            //     for (let i = 0; i < txnDateTimeArray.length; i++) {
            //         if (txnDateTimeArray[i].length > 0) {
            //             setDateTimeFormatList(prevArray => [...prevArray, new DateTimeClass(maxId, txnDateTimeArray[i], 'TxnDateTime')]);
            //             maxId = maxId + 1;
            //         }
            //     }
            // }
            let maxId = 1;

            if (ConfigDateData.data.txnDateTimeDateFormat) {
              const txnDateTimeArray =
                ConfigDateData.data.txnDateTimeDateFormat.split(",");
              txnDateTimeArray.forEach((format) => {
                if (format.length > 0) {
                  setDateTimeFormatList((prevArray) => [
                    ...prevArray,
                    new DateTimeClass(maxId++, format, "TxnDateTime"),
                  ]);
                }
              });
            }

            if (
              ConfigDateData.data.txnValueDateTimeDateFormat !== undefined &&
              ConfigDateData.data.txnValueDateTimeDateFormat !== null
            ) {
              const txnValueDateTimeArray =
                ConfigDateData.data.txnValueDateTimeDateFormat.split(",");

              for (let j = 0; j < txnValueDateTimeArray.length; j++) {
                if (txnValueDateTimeArray[j].length > 0) {
                  setDateTimeFormatList((prevArray) => [
                    ...prevArray,
                    new DateTimeClass(
                      maxId,
                      txnValueDateTimeArray[j],
                      "TxnValueDateTime"
                    ),
                  ]);
                  maxId = maxId + 1;
                }
              }
            }

            if (
              ConfigDateData.data.txnPostDateTimeDateFormat !== undefined &&
              ConfigDateData.data.txnPostDateTimeDateFormat !== null
            ) {
              const txnPostDateTimeArray =
                ConfigDateData.data.txnPostDateTimeDateFormat.split(",");

              for (let k = 0; k < txnPostDateTimeArray.length; k++) {
                if (txnPostDateTimeArray[k].length > 0) {
                  setDateTimeFormatList((prevArray) => [
                    ...prevArray,
                    new DateTimeClass(
                      maxId,
                      txnPostDateTimeArray[k],
                      "TxnPostDateTime"
                    ),
                  ]);
                  maxId = maxId + 1;
                }
              }
            }

            if (
              ConfigDateData.data.fileDateFormat !== undefined &&
              ConfigDateData.data.fileDateFormat !== null
            ) {
              const fileDateTimeArray =
                ConfigDateData.data.fileDateFormat.split(",");

              for (let k = 0; k < fileDateTimeArray.length; k++) {
                if (fileDateTimeArray[k].length > 0) {
                  setDateTimeFormatList((prevArray) => [
                    ...prevArray,
                    new DateTimeClass(maxId, fileDateTimeArray[k], "FileDate"),
                  ]);
                  maxId = maxId + 1;
                }
              }
            }

            setDecimalNumberValue(ConfigDateData.data.decimalNumber);
            setFileNameContainsValue(ConfigDateData.data.fileNameContains);
            setAllowedExtensionsValue(ConfigDateData.data.allowedExtensions);
            setSFTPorServerFilePath(ConfigDateData.data.sftpPath);
            setFileNameText(ConfigDateData.data.fileName);
            setSelectionStart(ConfigDateData.data.startPosition);
            setSelectionEnd(ConfigDateData.data.endPosition);

            setShowDateTimeGrid(true);
          } else {
            //console.log("f");
            setIsLoading(false);
            alert("Please configure file upload or file type is not found.");
          }
          //   setFilterDateTimeFormatList(
          //     DateTimeFormatList.filter(
          //       (item, i) => item.DateTimeType === "TxnDateTime"
          //     )
          //   );
          //console.log(maxId);
          //console.log(DateTimeFormatList);
        } else {
          setIsLoading(false);
          alert("Please configure file upload or file type is not found.");
        }
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });
  };

  const [selectedDateTimeType, setSelectedDateTimeType] = useState(null);

  const [FormateValue, setFormateValue] = useState(null);

  const [DatatimeFormatValue, setDatatimeFormatValue] = useState(null);

  const [DateTimeFormatList, setDateTimeFormatList] = useState([]);

  const [FilterDateTimeFormatList, setFilterDateTimeFormatList] = useState([]);

  const [DecimalNumberValue, setDecimalNumberValue] = useState('');

  const [AllowedExtensionsValue, setAllowedExtensionsValue] = useState('');

  const [SFTPorServerFilePath, setSFTPorServerFilePath] = useState('');

  const [FileNameContainsValue, setFileNameContainsValue] = useState('');

  const onClickConfig = (fileConfigIDValue) => {
    //console.log(fileConfigIDValue);
    setIsLoading(true);

    MaximusAxios.get(
      "/api/DynamicFileConfig/GetFileConfigData?FileConfigID=" +
      fileConfigIDValue,
      { mode: "cors" }
    )
      .then((FileConfigData) => {
        if (FileConfigData.data !== null && FileConfigData.data !== undefined) {
          setIsLoading(false);

          if (
            FileConfigData.data.fileType !== null &&
            FileConfigData.data.fileType !== undefined
          ) {
            let FileTypeValue = FileConfigData.data.fileType;

            if (FileTypeValue.includes("Excel")) {
              navigate("/spreadsheetSplitter", {
                state: { id: fileConfigIDValue },
              });
            } else if (FileTypeValue.toLowerCase().includes("csv")) {
              navigate("/spreadsheetSplitter", {
                state: { id: fileConfigIDValue },
              });
            } else if (FileTypeValue === "Plaintext Without Separator") {
              navigate("/plaintextSplitter", {
                state: { id: fileConfigIDValue },
              });
            } else if (FileTypeValue === "Plaintext With Separator") {
              navigate("/spreadsheetSplitter", {
                state: { id: fileConfigIDValue },
              });
            } else if (FileTypeValue === "null") {
              alert("Please configure file upload or file type is not found.");
            } else {
              alert("Please configure file upload or file type is not found.");
            }
          } else {
            //console.log("f");
            alert("Please configure file upload or file type is not found.");
          }
        } else {
          setIsLoading(false);
          alert("Please configure file upload or file type is not found.");
        }
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });
  };

  const onNewClick = () => {
    //console.log(selectedDateTimeType);
    //console.log(DateTimeFormatList);
    setShowDateSettingModal(true);

    setSelectedDateTimeType({ value: "TxnDateTime", label: "TxnDateTime" });
    // setFilterDateTimeFormatList(DateTimeFormatList.filter((item, i) => item.DateTimeType === selectedDateTimeType.value));

    //console.log("Date : "+FilterDateTimeFormatList);
  };

  const handleDateTimeTypeChange = (value) => {
    setSelectedDateTimeType(value);
    // setFilterDateTimeFormatList(
    //   DateTimeFormatList.filter((item, i) => item.DateTimeType === value.value)
    // );
  };

  const onSubmitDateTimeClick = () => {
    const maxId = DateTimeFormatList.reduce(
      (max, obj) => (obj.Id > max ? obj.Id : max),
      0
    );
    const newId = maxId + 1;

    const newObj = new DateTimeClass(
      newId,
      DatatimeFormatValue,
      selectedDateTimeType.value
    );
    setDateTimeFormatList([...DateTimeFormatList, newObj]);
    setShowDateSettingModal(false);
  };


  const handleDecimalNumber = (event) => {
    setDecimalNumberValue(event.target.value);
  };

  const handleAllowedExtensions = (event) => {
    setAllowedExtensionsValue(event.target.value);
  };

const handleSFTPPath = (event) => {
    setSFTPorServerFilePath(event.target.value);
  };


  const handleFileNameContains = (event) => {
    setFileNameContainsValue(event.target.value);
  };

  const onSaveDateTimeClick = () => {
    let TxnDateTimeDateFormatValue = DateTimeFormatList.filter(
      (item, i) =>
        item.DateTimeType === "TxnDateTime" && item.FormateValue.length > 0
    )
      .map((item) => item["FormateValue"])
      .join(",");
    let TxnValueDateTimeDateFormatValue = DateTimeFormatList.filter(
      (item, i) =>
        item.DateTimeType === "TxnValueDateTime" && item.FormateValue.length > 0
    )
      .map((item) => item["FormateValue"])
      .join(",");
    let TxnPostDateTimeDateFormatValue = DateTimeFormatList.filter(
      (item, i) =>
        item.DateTimeType === "TxnPostDateTime" && item.FormateValue.length > 0
    )
      .map((item) => item["FormateValue"])
      .join(",");
    let FileDateFormatValue = DateTimeFormatList.filter(
      (item, i) =>
        item.DateTimeType === "FileDate" && item.FormateValue.length > 0
    )
      .map((item) => item["FormateValue"])
      .join(",");

    let TxnAmountIsDecimal = "";
    // console.log(TxnDateTimeDateFormatValue);
    if (DecimalNumberValue === undefined || DecimalNumberValue === null || DecimalNumberValue.length === 0) {
      TxnAmountIsDecimal = "0";
    }
    else {
      TxnAmountIsDecimal = DecimalNumberValue;
    }
    // console.log(TxnValueDateTimeDateFormatValue); 

    const data = new FormData();

    data.append("FileConfigID", selectedConfigID);
    data.append("TableName", selectedTable);
    data.append("TxnDateTimeDateFormat", TxnDateTimeDateFormatValue);
    data.append("TxnValueDateTimeDateFormat", TxnValueDateTimeDateFormatValue);
    data.append("TxnPostDateTimeDateFormat", TxnPostDateTimeDateFormatValue);
    data.append("FileDateFormat", FileDateFormatValue);
    data.append("DecimalNumber", TxnAmountIsDecimal);
    data.append("AllowedExtensions", AllowedExtensionsValue);
    data.append("FileNameContains", FileNameContainsValue);
    data.append("SFTPPath", SFTPorServerFilePath);
    data.append("StartPosition", selectionStart ?? ""); // send empty if null
    data.append("EndPosition", selectionEnd ?? "");


    setIsLoading(true);
    MaximusAxios.post("api/DynamicFileConfig/UpdateDateTimeFormate", data, {
      headers: authHeader(),
      mode: "cors",
    })
      .then((response) => {
        // then print response status
        setIsLoading(false);
        //console.log(res.data);
        alert(response.data);
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
        alert("Error occurred");
      });

    setDateTimeFormatList([]);
    setShowDateTimeGrid(false);
    setShowDateSettingModal(false);
  };

  const onDeleteClick = (index) => {
    const newArray = DateTimeFormatList.filter((_, i) => i !== index);
    setDateTimeFormatList(newArray);
  };

  // const onDeleteClick = (rowID) => {
  //     if (rowID !== null && rowID !== undefined) {
  //         // Filter out the item with the matching Id
  //         const newArray = DateTimeFormatList.filter((obj) => obj.Id !== rowID);
  //         setDateTimeFormatList(newArray);
  //         console.log("DateTimeFormatList after deletion:", JSON.stringify(newArray, null, 2));
  //         onSaveDateTimeClick();
  //     }
  // }

  return (
    <div className="configLeft dynamicContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Dynamic File Configuration
        </h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">File Configuration</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Dynamic File Configuration</p>
        </div>
      </div>
      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="unmatchedFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="unmatchedFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#unmatchedFiltersCollapse"
                aria-expanded="true"
                aria-controls="unmatchedFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="unmatchedFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="unmatchedFiltersHeading"
              data-bs-parent="#unmatchedFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedClientValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlNetworkType">Network Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlNetworkType"
                      value={selectedNetworkValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsNetworkType.map((x) => ({
                        value: x.typeId,
                        label: x.networkName,
                      }))}
                      onChange={handleNetworkChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddllogType">Import Log Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddllogType"
                      value={selectedLogValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsLogType.map((x) => ({
                        value: x.id,
                        label: x.logType,
                      }))}
                      onChange={handleLogTypeChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      onChange={handleChannelChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlVendor">Vendor</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlVendor"
                      value={selectedVendorValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsVendor.map((x) => ({
                        value: x.vendorID,
                        label: x.vendorName,
                      }))}
                      onChange={handleVendorChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlMode">Mode Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlMode"
                      value={selectedModeValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsModeType.map((x) => ({
                        value: x.modeID,
                        label: x.modeName,
                      }))}
                      onChange={handleModeChange}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onSubmit}
                    disabled={isShow}
                  >
                    Proceed
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="configLeftBottom">
        <div>
          {FileConfigList && (
            <div className="tableBorderBox pt-3">
              <div className="w-100 table-responsive">
                <div className="table-responsive tableContentBox">
                  <table
                    id="gvMatchingList"
                    className="table table-striped table-hover table-borderless align-middle"
                    style={{ width: "100%" }}
                  >
                    <thead>
                      <tr>
                        <th scope="col">Client Name</th>
                        <th scope="col">Network Type</th>
                        <th scope="col">Log Type</th>
                        <th scope="col">Vendor Name</th>
                        <th scope="col">Channel</th>
                        <th scope="col">Mode Name</th>

                        <th scope="col">Upload File</th>
                        <th scope="col">Configure</th>
                        <th scope="col">Configure Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {FileConfigList.map((p, i) => {
                        return (
                          <tr key={i}>
                            <td>{p.clientName} </td>
                            <td>{p.networkType} </td>
                            <td>{p.logType} </td>
                            <td>{p.vendorName} </td>
                            <td>{p.channelName} </td>
                            <td>{p.transactionMode} </td>

                            <td>
                              <button
                                className="iconButtonBox"
                                onClick={() =>
                                  onClickUpload(
                                    p.logType,
                                    p.configID,
                                    p.vendorID
                                  )
                                }
                              >
                                <img
                                  src={FileuploadIcon}
                                  alt="Upload File"
                                  title="Upload File"
                                />
                              </button>
                            </td>
                            <td>
                              <button
                                className="iconButtonBox"
                                onClick={() => onClickConfig(p.configID)}
                              >
                                <img
                                  src={ConfigImage}
                                  alt="Data Configuration"
                                  title="Data Configuration"
                                />
                              </button>
                            </td>
                            <td>
                              <button
                                className="iconButtonBox"
                                onClick={() =>
                                  onClickDate(p.logType, p.configID)
                                }
                              >
                                <img
                                  src={SettingdateImage}
                                  alt="Date Configuration"
                                  title="Date Configuration"
                                />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
        <div>
          {isShowDateTimeGrid ? (
            <div className="pt-3">
              <h5 className="fontWeight-600 fontSize14 colorBlack ">
                DateTime Format Mapping{" "}
              </h5>
              <div className="hrGreyLine"></div>
              <div className="tableBorderBox pt-3">
                <div>
                  <button
                    type="button"
                    className="iconAddNew"
                    onClick={onNewClick}
                  >
                    <span className="icon-Plus">+</span>
                    <span className="ms-1 fontSize12-m colorPrimaryDefault">
                      Add New
                    </span>
                  </button>
                  <div className="w-100 table-responsive">
                    <div className="table-responsive tableContentBox">
                      <table
                        id="gvDateTimeList"
                        className="table table-striped table-hover table-borderless align-middle"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th scope="col" style={{ width: "105px" }}>
                              Sr. No.
                            </th>
                            <th scope="col" style={{ width: "195px" }}>
                              DateTime Type
                            </th>
                            <th scope="col">Format</th>
                            <th scope="col" style={{ width: "195px" }}>
                              Action
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {DateTimeFormatList.map((x, i) => (
                            <tr key={i}>
                              <td>{i + 1}</td>
                              <td>{x.DateTimeType}</td>
                              <td>{x.FormateValue}</td>
                              <td>
                                <OverlayTrigger
                                  placement="top"
                                  delay={{ show: 250, hide: 400 }}
                                  overlay={renderTooltipDelete}
                                >
                                  <button
                                    className="iconButtonBox"
                                    onClick={() => onDeleteClick(i)}
                                  >
                                    <img
                                      src={DeleteIcon}
                                      alt="Remove"
                                      title="Remove"
                                    />
                                  </button>
                                </OverlayTrigger>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                {/* Filename Splitter - Added by Kaif */}
<div className="w-100 table-responsive">
  <div className="table-responsive tableContentBox">
    <table
      className="table table-striped table-hover table-borderless align-middle"
      style={{ width: "100%" }}
    >
      <thead>
        <tr>
          <th style={{ width: "100%" }}>Filename Splitter</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>
            <pre
              className="txtSelectionField"
              style={{
                cursor: "text",
                backgroundColor: "#f9f9f9",
                border: "1px solid #ddd",
                borderRadius: "6px",
                padding: "10px",
                userSelect: "text",
                fontFamily: "monospace",
                fontSize: "13px",
                lineHeight: "1.4em",
                display: "inline-block",
                width: "100%",
                overflowX: "auto",
                margin: 0,
              }}
              onMouseUp={handleTextSelection}
            >
              {FileNameText || "No file selected"}
            </pre>
          </td>
        </tr>
        <tr>
          <td>
            <div className="configSelectBoxTop row mt-3">
              <div className="clientNameSelect col">
                <label>Start Position</label>
                <input
                  type="text"
                  value={selectionStart ?? ""}
                  readOnly
                  className="inputTextBox"
                  style={{
                    backgroundColor: "#f0f0f0",
                    cursor: "not-allowed",
                  }}
                />
              </div>

              <div className="clientNameSelect col">
                <label>End Position</label>
                <input
                  type="text"
                  value={selectionEnd ?? ""}
                  readOnly
                  className="inputTextBox"
                  style={{
                    backgroundColor: "#f0f0f0",
                    cursor: "not-allowed",
                  }}
                />
              </div>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>


                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="txtTxnAmountIsDecimal">TxnsAmount's Decimal</label>
                    <input
                      type="number"
                      name="txtTxnAmountIsDecimal"
                      id="txtTxnAmountIsDecimal"
                      placeholder="Enter Transaction Amount Decimal"
                      className="inputTextBox"
                      value={DecimalNumberValue}
                      onChange={handleDecimalNumber}

                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="txtAllowedExtensions">Allowed Extensions</label>
                    <input
                      type="text"
                      name="txtAllowedExtensions"
                      id="txtAllowedExtensions"
                      placeholder="Enter Allowed Extensions for Files"
                      className="inputTextBox"
                      value={AllowedExtensionsValue}
                      onChange={handleAllowedExtensions}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="txtFileNameContains">File Name Contains</label>
                    <input
                      type="text"
                      name="txtFileNameContains"
                      id="txtFileNameContains"
                      placeholder="Enter File Name Contains"
                      className="inputTextBox"
                      value={FileNameContainsValue}
                      onChange={handleFileNameContains}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="txtFileNameContains">SFTP/Server File Path</label>
                    <input
                      type="text"
                      name="txtFileNameContains"
                      id="txtFileNameContains"
                      placeholder="Enter File Name Contains"
                      className="inputTextBox"
                      value={SFTPorServerFilePath}
                      onChange={handleSFTPPath}
                    />
                  </div>
                </div>
                
                {DateTimeFormatList !== null &&
                  DateTimeFormatList.length > 0 && (
                    <div>
                      <div className="btnsBtm btnright">
                        {" "}
                        <button
                          type="button"
                          className="btnPrimary ms-2"
                          onClick={onSaveDateTimeClick}
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  )}
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {isShowFileUploadModal && (
        <Modal
          show={isShowFileUploadModal}
          onHide={() => setShowFileUploadModal(!isShowFileUploadModal)}
          centered
          className="dynamicTableModal"
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              File Upload (<span>Table Name : {selectedTable}</span>)
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="dynamicControl">
              <div className="FileWhiteBox">
                <p
                  className="fontSize14 fontWeight-500 letterSpacing-2 mb-1"
                  id="selectheading"
                >
                  Select File <span className="text-danger font-size13">*</span>
                </p>
                <div className="d-flex align-items-center">
                  <div className="lightWhiteBox text-center">
                    <div>
                      <p className="fontSize14 fontWeight-500 colorPrimaryDefault browseFileText">
                        Browse File
                      </p>
                      <FileUploader
                        handleChange={handleuploadFile}
                        name="file"
                        types={fileTypes}
                      />
                      <p className="fontSize14 dropFileColor">
                        {importFile ? "File name: " + fileName : ""}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="clientNameSelect col">
                <label htmlFor="ddlFileType">File Type</label>
                <span className="text-danger font-size13">*</span>
                <Select
                  id="ddlFileType"
                  value={selectedFileTypeValue}
                  classNamePrefix="reactSelectBox"
                  options={FileTypeOptions}
                  onChange={handleFileTypeChange}
                />
              </div>
              {isShowSeparator && (
                <div className="clientNameSelect col">
                  <label htmlFor="ddlFileSeparator">Separator Type</label>
                  <span className="text-danger font-size13">*</span>
                  <Select
                    id="ddlFileSeparator"
                    value={selectedFileSeparatorValue}
                    classNamePrefix="reactSelectBox"
                    options={SeparatorTypeOptions}
                    onChange={handleFileSeparatorChange}
                  />
                </div>
              )}
            </div>
          </Modal.Body>
          <Modal.Footer>
            <button
              type="button"
              className="btnPrimary ms-2"
              onClick={onUploadClick}
            >
              Upload
            </button>
          </Modal.Footer>
        </Modal>
      )}

      {isShowDateSettingModal && (
        <Modal
          show={isShowDateSettingModal}
          onHide={() => setShowDateSettingModal(!isShowDateSettingModal)}
          centered
          className="DateFormatModal"
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              Date Time Format (<span>Table Name : {selectedTable}</span>)
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="currencyControl clientNameSelect">
              <label htmlFor="ddlDateTime">Datatime Type</label>
              <span className="text-danger font-size13">*</span>
              <Select
                id="ddlDateTime"
                value={selectedDateTimeType}
                classNamePrefix="reactSelectBox"
                options={optionsDateTime}
                onChange={handleDateTimeTypeChange}
              />
            </div>
            <div className="currencyControl">
              <label htmlFor="txtDateFormat">Datatime Formate</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="txtDateFormat"
                id="txtDateFormat"
                placeholder="Enter Datatime Formate"
                className="inputTextBox"
                onChange={(e) => setDatatimeFormatValue(e.target.value)}
                onKeyPress={(e) =>
                  !/^[a-zA-Z/ \-\.:]*$/.test(e.key) && e.preventDefault()
                }
              />
            </div>
          </Modal.Body>
          <Modal.Footer>
            <button
              type="button"
              className="btnPrimary ms-2"
              onClick={onSubmitDateTimeClick}
            >
              Submit
            </button>
          </Modal.Footer>
        </Modal>
      )}

      {isShowFileConfigModal && (
        <Modal
          show={isShowFileConfigModal}
          onHide={() => setShowFileConfigModal(!isShowFileConfigModal)}
          centered
          className="dynamicTableModal"
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              Copy File Configuration
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="dynamicControl">
              <div className="clientNameSelect col">
                <label htmlFor="ddlClientConfig">Client</label>
                <span className="text-danger font-size13">*</span>
                <Select
                  id="ddlClientConfig"
                  value={selectedClientToCopy}
                  classNamePrefix="reactSelectBox"
                  options={ClientConfigOptions.map(x => (
                    {
                      value: x.clientID,
                      label: x.clientName
                    }
                  ))}
                  onChange={handleClientToCopyChange}
                />
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <button type="button" className="btnPrimary ms-2" onClick={onExistingClick} >Copy Existing Configuration</button>
            <button type="button" className="btnPrimary ms-2" onClick={onNewEntryClick} >New Entry</button>
          </Modal.Footer>
        </Modal>
      )}

      <LoadingSpinner isShow={isShow} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default DynamicFileConfigurationMainWindow;
