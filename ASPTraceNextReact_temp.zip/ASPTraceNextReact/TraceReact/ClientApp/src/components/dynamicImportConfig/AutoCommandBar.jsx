import React, { useState, useContext, useEffect } from 'react';
import './Autocomplete.css';
import ErrorMessage from './ErrorMessage';
import { PageContext } from './PageState';


const AutocompleteTextBox = ({ ClassN,Enableheader, EnableError, suggestions, setCommand, columnText, isClear }) => {
    const [filteredSuggestions, setFilteredSuggestions] = useState([]);
    const [inputValue, setInputValue] = useState('');
    const [selectedSuggestionIndex, setSelectedSuggestionIndex] = useState(-1);
    const { state, setState, handleUpdateData, handleAddData } = useContext(PageContext);

    useEffect(() => {

        if (isClear === true )
        {
            setInputValue('');
            let Filtered = state.st2_StatusConditions.filter((o, i) => (o.IsClear === false));
            handleUpdateData(0, { st2_StatusConditions: Filtered });
        }

        

    }, [isClear])
    



    const handleInputChange = (event) => {
        const input = event.target.value;
        const lastWord = input.trim().split(' ').pop();
        let sorted = suggestions.filter((suggestion) =>
            suggestion.toLowerCase().startsWith(lastWord.toLowerCase())
        );

        const filtered = sorted.sort((a, b) => a.length - b.length);

        setFilteredSuggestions(filtered);
        setInputValue(input);
        setSelectedSuggestionIndex(-1); // reset selected suggestion index
    };

    const handleSelection = (suggestion) => {
        const words = inputValue.trim().split(' ');
        const lastWord = words.pop();
        const prefix = words.join(' ');
        const selectedValue = suggestion.trim();
        if (filteredSuggestions.includes(lastWord)) {
            let str = prefix === '' ? lastWord : `${prefix} ${lastWord}`
            setInputValue(`${str} `);
        }
        else if (prefix !== "" || lastWord !== "") {
            setInputValue(`${prefix} ${selectedValue} `);
        }
        setFilteredSuggestions([]);
        setSelectedSuggestionIndex(-1); // reset selected suggestion index
    };

    useEffect(() => {

        //if (true)
        if (inputValue != "")
        {
            setCommand(inputValue)

        }

    }, [inputValue]);

    useEffect(() => {

        if (columnText != '' && columnText != null) {

            let input = columnText;
            setInputValue(`${inputValue} ${input} `)

        }

    }, [columnText]);


    const handleKeyDown = (event) => {
        let keyPress = null;
        if (event.key === undefined) {
            keyPress = " ";
        }
        else {
            keyPress = event.key;
        }

        switch (keyPress) {
            case 'ArrowUp':
                setSelectedSuggestionIndex((prevIndex) =>
                    prevIndex > 0 ? prevIndex - 1 : filteredSuggestions.length - 1
                );
                break;
            case 'ArrowDown':
                setSelectedSuggestionIndex((prevIndex) =>
                    prevIndex < filteredSuggestions.length - 1 ? prevIndex + 1 : 0
                );
                break;
            case 'Enter':
            case ' ':
                if (selectedSuggestionIndex >= 0) {
                    handleSelection(filteredSuggestions[selectedSuggestionIndex]);
                }
                else if (filteredSuggestions.length > 0) {

                    handleSelection(filteredSuggestions[0]);
                } else {
                    const inputValueWords = inputValue.trim().split(' ');
                    const lastWord = inputValueWords.pop();
                    const prefix = inputValueWords.join(' ');
                    const inputIsValid =
                        lastWord === '' || suggestions.some((suggestion) => suggestion.toLowerCase() === lastWord.toLowerCase());
                    if (!inputIsValid) {
                        event.preventDefault();
                        const newInputValue = prefix.trim();
                        if (lastWord.includes(`'`) || lastWord.includes(`]`)) {
                            let final = `${newInputValue} ${lastWord} `
                            setInputValue(final);
                        }
                        else
                            setInputValue(newInputValue);
                    } else {
                        setFilteredSuggestions(suggestions);
                        setSelectedSuggestionIndex(-1);
                    }
                }
                break;
            default:
                setSelectedSuggestionIndex(-1); // reset selected suggestion index
                break;
        }
    };

    const handleInputBlur = (event) => {
        setFilteredSuggestions([]);
        setSelectedSuggestionIndex(-1);
        if (event.target.value !="")
            handleKeyDown(event);
    };

    return (
        <div className="autocomplete-wrapper">
            <div className="d-flex justify-content-between">
                {
                    Enableheader &&
                    <span>
                        <label htmlFor="ColumnVal" style={{ fontSize: "0.8rem", paddingRight: "5px" }}>CommandBar</label>
                    </span>
                }
                {
                    EnableError && <span>
                        <ErrorMessage message={inputValue} />
                    </span>
                }

            </div>
            <input
                className={ClassN === "" ? "" : "inputTextBox"}
                type="text"
                value={inputValue}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                onBlur={handleInputBlur}
                placeholder={'Add Column value or case conditions'}
            />
            <div className="suggestions">
                {filteredSuggestions.length === 0 && (
                    <div className="autocomplete-dropdown-empty">No suggestions</div>
                )}
                {filteredSuggestions.map((suggestion, index) => (
                    <div
                        key={suggestion}
                        className={`autocomplete-dropdown-item ${
                            index === selectedSuggestionIndex ? 'selected' : ''
                            }`}
                        onClick={() => handleSelection(suggestion)}
                    >
                        {suggestion}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AutocompleteTextBox;
