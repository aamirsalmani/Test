import React, { useState, useEffect } from "react";
import Select from "react-select";
import { Link } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import AsyncSelect from 'react-select/async';
import MaximusAxios from "../common/apiURL" ;
import $ from 'jquery';
import 'jquery/dist/jquery.min.js';


const Autocomplete = (props) => {


    let UserIP = "";
    const [state, setState] = useState({
        activeSuggestion: 0,
        filteredSuggestions: [],
        showSuggestions: true,
        userInput: ""
    });


    if (props.columnText != "" && state.userInput == "") {
        UserIP = props.columnText;
        

    }
    else if (props.columnText != "" && state.userInput != "") {
        UserIP = state.userInput + props.columnText;
        
    }

    useEffect(() => {

        if (state.userInput != "")
        {
            props.setCommand(state.userInput)

        }
        
    }, [state]);

    useEffect(() => {

        if (UserIP != "") {
            setState({
                activeSuggestion: state.activeSuggestion,
                filteredSuggestions: state.filteredSuggestions,
                showSuggestions: false,
                userInput: UserIP
            });

            UserIP = "";            
        }
    }, [props.columnText]);



const onChange = (e) => {
    const { suggestions } = props;
    let arr = e.currentTarget.value.split(" ");
    let LastInput = arr.pop();
    let previousInput = arr.length == 0 ? "" : arr.join(" ");
    console.log(LastInput);
    let userInput = LastInput == null || LastInput == "" ? e.currentTarget.value : LastInput;

    // Filter our suggestions that don't contain the user's input
    let Sorted = suggestions.filter(
        (suggestion) =>
            suggestion.toLowerCase().indexOf(userInput.trim().toLowerCase()) > -1
    );
    const filteredSuggestions = Sorted.sort((a, b) => a.length - b.length);

    setState({
        activeSuggestion: 0,
        filteredSuggestions,
        showSuggestions: true,
        userInput: e.currentTarget.value
    });
};

const onClick = (e) => {
    setState({
        activeSuggestion: 0,
        filteredSuggestions: [],
        showSuggestions: false,
        userInput: e.currentTarget.innerText
    });
};

    const onKeyDown = (e) => {
        const { activeSuggestion, filteredSuggestions, userInput } = state;


    // User pressed the enter key
    if (e.keyCode === 32) {

    }
    if (e.keyCode === 13) {

        let arr = e.currentTarget.value.split(" ");
        let LastWord = arr.pop();
        if (LastWord == "") {
            LastWord = arr.pop();
        }
        let Joined = arr.length == 0 ? "" : arr.join(" ");
        let suggestion = filteredSuggestions[activeSuggestion];
        suggestion = suggestion == null ? "" : suggestion;
        let LastInput = Joined != "" ? Joined + " " + suggestion : suggestion;
        console.log(filteredSuggestions[activeSuggestion]);

        setState({
            activeSuggestion: 0,
            filteredSuggestions: [],
            showSuggestions: false,
            userInput: LastInput
        });


    }
    // User pressed the up arrow
    else if (e.keyCode === 38) {
        if (activeSuggestion === 0) {
            return;
        }

        setState({
            activeSuggestion: activeSuggestion - 1,
            filteredSuggestions: filteredSuggestions,
            showSuggestions: true,
            userInput: userInput
        });
    }
    // User pressed the down arrow
    else if (e.keyCode === 40) {
        if (activeSuggestion - 1 === filteredSuggestions.length) {
            return;
        }
        setState({
            activeSuggestion: activeSuggestion + 1,
            filteredSuggestions: filteredSuggestions,
            showSuggestions: true,
            userInput: userInput
        });
    }
};

let suggestionsListComponent;

if ((UserIP != "" && state.userInput) || (state.showSuggestions && state.userInput)) {
    if (state.filteredSuggestions.length) {
        suggestionsListComponent = (
            <ul class="suggestions">
                {state.filteredSuggestions.map((suggestion, index) => {
                    let className;

                    // Flag the active suggestion with a class
                    if (index === state.activeSuggestion) 
                    {
                        className = "suggestion-active";
                    }
                    if (index <= 2)
                        return (
                            <li className={className} key={suggestion} onClick={onClick}>
                                {suggestion}
                            </li>
                        );
                })}
            </ul>
        );
    } else {
        suggestionsListComponent = (
            <div class="no-suggestions">
                <em>No suggestions, you're on your own!</em>
            </div>
        );
    }
}


return (
    <>
        <input className="inputTextBox"
            type="text"
            onChange={onChange}
            onKeyDown={onKeyDown}
            value={state.userInput}
        />
        {suggestionsListComponent}
    </>
);
};

export default Autocomplete;