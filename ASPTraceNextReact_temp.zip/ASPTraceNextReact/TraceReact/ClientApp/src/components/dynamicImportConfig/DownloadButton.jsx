import React from "react";
import { useSelector } from "react-redux";
import "./reconConfig.css";
import { PageProvider } from './PageState';
import DownloadIcon from "../../images/common/cloud-240.svg";



const DownloadButton = ({ DataQuery }) => {
    let Data = DataQuery === null ? "" : DataQuery;
    
    const handleDownload = () => {
        
        const sqlContent = Data;
        const blob = new Blob([sqlContent], { type: 'text/sql' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'ReconStoredProcedure.sql';
        a.click();
        window.URL.revokeObjectURL(url);
    };

    return (
        <div>
            <button className="DownloadBox"
                onClick={handleDownload} >
                <img src={DownloadIcon} alt="DownloadFile" />
                </button>
        </div>
    );
};

export default DownloadButton;

