import React, { useState, useEffect }  from 'react';



function FormatSqlCaseStatement(sqlCaseStatement) {
    // Check if input is a valid string
    if (typeof sqlCaseStatement !== 'string') {
        throw new Error('Invalid input - input must be a string');
    }

    // Remove any leading or trailing whitespace from the input
    const trimmedSqlCaseStatement = sqlCaseStatement.trim();

    // Check if the input is an empty string
    if (!trimmedSqlCaseStatement) {
        throw new Error('Invalid input - input cannot be empty');
    }

    // Count the number of 'case', 'when', 'then', 'else', and 'end' keywords
    const numCaseKeywords = (trimmedSqlCaseStatement.match(/\bcase\b/gi) || []).length;
    const numWhenKeywords = (trimmedSqlCaseStatement.match(/\bwhen\b/gi) || []).length;
    const numThenKeywords = (trimmedSqlCaseStatement.match(/\bthen\b/gi) || []).length;
    const numElseKeywords = (trimmedSqlCaseStatement.match(/\belse\b/gi) || []).length;
    const numEndKeywords = (trimmedSqlCaseStatement.match(/\bend\b/gi) || []).length;

    //// Check if there is at least one 'case' keyword
    //if (numCaseKeywords === 0) {
    //    throw new Error('Invalid input - input must contain at least one "case" keyword');
    //}

    // Check if the number of 'when' and 'then' keywords match
    if (numWhenKeywords !== numThenKeywords) {
        throw new Error('Invalid input - number of "when" keywords must match number of "then" keywords');
    }

    // Check if the number of 'else' and 'end' keywords match
    if (numElseKeywords !== numEndKeywords) {
        throw new Error('Invalid input - number of "else" keywords must match number of "end" keywords');
    }

    // Check if there are no 'when' or 'then' keywords before the first 'case' keyword
    if (numCaseKeywords > 0) {
        const firstCaseIndex = trimmedSqlCaseStatement.toLowerCase().indexOf('case');
        const beforeFirstCase = trimmedSqlCaseStatement.substring(0, firstCaseIndex).toLowerCase();
        if (beforeFirstCase.includes('when') || beforeFirstCase.includes('then')) {
            throw new Error('Invalid input - input cannot have any "when" or "then" keywords before the first "case" keyword');
        }
    }

    // Check if there are no 'when' keywords after the last 'end' keyword
    if (numEndKeywords > 0) {
        const lastEndIndex = trimmedSqlCaseStatement.toLowerCase().lastIndexOf('end');
        const afterLastEnd = trimmedSqlCaseStatement.substring(lastEndIndex + 3).toLowerCase();
        if (afterLastEnd.includes('when')) {
            throw new Error('Invalid input - input cannot have any "when" keywords after the last "end" keyword');
        }
    }

    // Check if every 'when' keyword has a 'then' keyword before it, and every 'else' keyword has a 'then' keyword before it
    let hasThenKeyword = false;
    let formattedSqlCaseStatement = '';
    for (const line of trimmedSqlCaseStatement.split('\n')) {
        const trimmedLine = line.trim();
        if (trimmedLine.toLowerCase().startsWith('when')) {
            if (!hasThenKeyword) {
                throw new Error('Invalid input - every "when" keyword must have a "then" keyword before it');
            }
            formattedSqlCaseStatement += `\n${trimmedLine}`;
        } else if (trimmedLine.toLowerCase().startsWith('then')) {
            hasThenKeyword = true;
            formattedSqlCaseStatement += `\n${trimmedLine}`;
        } else if (trimmedLine.toLowerCase().startsWith('else')) {
            if (!hasThenKeyword) {
                throw new Error('Invalid input - every "else" keyword must have a "then" keyword before it');
            }
            formattedSqlCaseStatement += `\n${trimmedLine}`;
        } else if (trimmedLine.toLowerCase().startsWith('end')) {
            if (!hasThenKeyword) {
                throw new Error('Invalid input - input must contain at least one "then" keyword before the first "end" keyword');
            }
            hasThenKeyword = false;
            formattedSqlCaseStatement += `\n${trimmedLine}`;
        } else {
            formattedSqlCaseStatement += ` ${trimmedLine}`;
        }
    }

    // Check if there are no 'when' or 'else' keywords without a corresponding 'then' keyword
    if (hasThenKeyword) {
        throw new Error('Invalid input - input must have a "then" keyword for every "when" or "else" keyword');
    }

    // Add missing 'when', 'then', 'else', and 'end' keywords
    if (numCaseKeywords > numEndKeywords) {
        formattedSqlCaseStatement += '\nend';
    }
    if (numWhenKeywords > numThenKeywords) {
        formattedSqlCaseStatement += '\nthen <value>';
    }
    if (numWhenKeywords < numThenKeywords) {
        formattedSqlCaseStatement += '\nwhen <condition> then <value>';
    }
    if (numElseKeywords === 0 && numEndKeywords > 0) {
        formattedSqlCaseStatement += '\nelse <value>\nend';
    }

    return formattedSqlCaseStatement.trim();
}



function ErrorMessage({ message }) {

    const [sqlStatement, setSqlStatement] = useState('');
    const [formattedSqlStatement, setFormattedSqlStatement] = useState('');

    const handleFormatClick = () => {
    try {
        const formattedStatement = FormatSqlCaseStatement(sqlStatement);
        //setFormattedSqlStatement(formattedStatement);
        setFormattedSqlStatement('');
    } catch (error) {
        setFormattedSqlStatement(`Error: ${error.message}`);
    }
};



    useEffect(() => {

        if (message != "") {
            setSqlStatement(message)

        }

    }, [message]);

    useEffect(() => {

        if (sqlStatement != "") {

            handleFormatClick()

        }

    }, [sqlStatement]);

    return (
        <label style={{ color: 'red', fontSize:'0.8rem' }}>{formattedSqlStatement}</label>
    );
}

export default ErrorMessage;
