﻿import React, { useState } from 'react';

const MarkerComponent = () => {
  const [text, setText] = useState('61891725010920230700988460732702718659802090302000000429324407009884 1500.00 N P 00');
  const [markers, setMarkers] = useState([{ start: 0, end: 0, name: '' }]);
  const [newMarker, setNewMarker] = useState({ start: 0, end: 0, name: '' });

  const handleTextChange = (event) => {
    const newText = event.target.value;
    setText(newText);
  };

  const handleAddMarker = () => {
    setMarkers([...markers, newMarker]);
    setNewMarker({ start: 0, end: 0, name: '' });
  };

  const handleMarkerChange = (event, index) => {
    const { name, value } = event.target;
    const updatedMarkers = [...markers];
    updatedMarkers[index][name] = value;
    setMarkers(updatedMarkers);
  };

  return (
    <div>
      <textarea
        value={text}
        onChange={handleTextChange}
        rows="4"
        cols="50"
        readOnly
      />
      <button onClick={handleAddMarker}>Add Marker</button>
      {markers.map((marker, index) => (
        <div key={index}>
          <input
            type="number"
            name="start"
            value={marker.start}
            onChange={(e) => handleMarkerChange(e, index)}
          />
          <input
            type="number"
            name="end"
            value={marker.end}
            onChange={(e) => handleMarkerChange(e, index)}
          />
          <input
            type="text"
            name="name"
            value={marker.name}
            onChange={(e) => handleMarkerChange(e, index)}
          />
          <div>
            {text.substring(marker.start, marker.end)}
          </div>
        </div>
      ))}
    </div>
  );
};

export default MarkerComponent;
