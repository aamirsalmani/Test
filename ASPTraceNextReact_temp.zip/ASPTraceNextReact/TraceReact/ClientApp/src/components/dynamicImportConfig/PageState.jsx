// PageContext.js
import React, { createContext, useState } from 'react';

const initialState = {
    // Initial state for HomePage
    isShow: false
    , alertJson: { isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' }
    , proceed: null
    , inputValue: 0
    , selectedValue: null
    , tempQ: null
    , tempTable: []
    , optionsReconType: []
    , selectedReconType: "9"
    , selectedTablesCount: 0
    , optionsChannelType: []
    , selectedChannelValue: null
    , optionsModeType: []
    , selectedModeValue: null
    , optionsTablesList: []
    , optionsColumnsList: []
    , optionsOperationList: []
    , optionsParamList: []
    , currentStage: 0
    , optionsCommandsList: []
    , aliasColumnsList: []
    , formData: []
    , columnText: []
    , columnValuesList: []
    , whereList: []
    , selectedColumns: {}
    , selectedAliasValue: null
    , selectedWhereValue: null
    , inputTextValue: null
    , inputWhereTextValue: null
    , hasSeperatorPosition: null
    , selectedTableValue1: { value: 0, label: "All", isCompleted: 0 }
    , selectedTableValue2: { value: 0, label: "All", isCompleted: 0 }
    , selectedTableValue3: { value: 0, label: "All", isCompleted: 0 }
    , selectedTableValue4: { value: 0, label: "All", isCompleted: 0 }
    , selectedTableValue5: { value: 0, label: "All", isCompleted: 0 }
    , optionsConfigTablesList: []
    , selectedConfigTable: null
    , st2_Tables: []
    , st2_selectedTable: { value: 0, label: "All", isCompleted: 0 }
    , st2_optionsConfigTablesList:[]
    , st2_statusGrid:
        [
              { value: 1, label: "1" }
            , { value: 2, label: "2" }
            , { value: 3, label: "3" }
            , { value: 4, label: "4" }
            , { value: 5, label: "5" }
            , { value: 6, label: "6" }
            , { value: 7, label: "7" }
            , { value: 8, label: "8" }
            , { value: 9, label: "9" }
            , { value: 10, label: "10" }
        ]
    , st2_StatusConditions: []
    , st2_selectedStatus: { value: 0, label: "All" }
    , st2_selectedStatusCondition: { Table: { TableNo: 0, TableName: "All" }, status: { value: 0, label: "All" }, statusCondition: "", IsClear: false }
    ,ColumnUpdateID:null
};





const PageContext = createContext();

const PageProvider = ({ children }) => {
    const [state, setState] = useState(initialState);


    const handleAddData = (index, AddedData) => {

        let { Addkey, Addvalue } = AddedData;

        const updatedArray = [...state[Addkey], Addvalue];
        //console.log("updatedArray");
        //console.log(updatedArray);

        setState(prevState => {
            return { ...prevState, [Addkey]: [...prevState[Addkey], Addvalue] };
        });
        //setNewItem({ title: '', description: '' }); // Clear the input fields
    };

    // Update state (Update Existing Data)
    const handleUpdateData = (index, updatedData) => {

        let { Updatekey, Updatevalue } = updatedData;
        //console.log(updatedData);
        setState(prevState => {
            return { ...prevState, ...updatedData };
        });



    };

    return (
        <PageContext.Provider value={{ state, setState, handleUpdateData, handleAddData}}>
            {children}
        </PageContext.Provider>
    );
};

export { PageContext, PageProvider };
