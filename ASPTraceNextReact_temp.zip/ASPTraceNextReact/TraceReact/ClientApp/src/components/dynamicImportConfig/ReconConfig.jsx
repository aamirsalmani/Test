import React from "react";
import { useSelector } from "react-redux";
// CSS
import "./reconConfig.css";
// Components
import SidebarMain from "../common/SidebarMain";
 import ReconConfigMainWindow from "./ReconConfigMainWindow";
//import ReconConfigMainWindow from "../reconConfigStage2/ReconConfigMain";
import { PageProvider } from './PageState';
//<ReconConfigMainWindow />  Replace below component with this when required   <DynamicImportMainWindow/>


const ReconConfig = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView">
              <PageProvider>
                  <ReconConfigMainWindow />
              </PageProvider>
    </div>
  );
};

export default ReconConfig;
