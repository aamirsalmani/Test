import React, { useState, useRef, useEffect, useContext } from 'react';
import './StyledTable.css';
import { bool } from 'prop-types';
import Select from "react-select";
import { PageContext } from './PageState';

const Table = ({ data, optionsColumnsList, UpdateFn }) => {

    const { state, setState, handleUpdateData, handleAddData } = useContext(PageContext);
    const [isRename, setIsRename] = useState(false);
    const [hasCheckBox, sethasChechBox] = useState(true);
    const [columns, setColumns] = useState([]);



    useEffect(() => {

        UpdateFn(columns);

    }, [columns]);

    useEffect(() => {
        if (data !== null && data !== undefined) {
            setColumns(Object.keys(data[0]).map((item, index) => {
                return {
                    label: item, isChecked: true, renamed: '', dataValue: data[0][item], position: index + 1
                }
            }));
        }

    }, [data]);


    if (!data || data.length == 0) {
        return null;
        {/*<div>No data to display.</div>;*/ }
    }

    


    const fnRename = (column, Renamed) => {

        let tempColumns = [...columns].map((item, i) => {

            if (item.label === column.label) {
                item.renamed = Renamed.label;
                item.position = Renamed.value;
                return item;
            }
            else {
                return item;
            }

        });

        setColumns(tempColumns);
    }
    const fnCheckbox = (column, index) => {

        let tempColumns = [...columns].map((item, i) => {
            var isChecked = item.isChecked !== null ? item.isChecked : false;
            if (item.label === column.label) {
                item.isChecked = !isChecked;
                return item;
            }
            else {
                return item;
            }

        });

        setColumns(tempColumns);
    }

    const enableCheckbox = () => {

        let check = true;

        let allComplete = columns.filter((o, i) => (o.isChecked == false));

        if (allComplete.length === 0) check = false;


        let tempColumns = columns.map((item) => ({
            ...item,
            isChecked: check
        }));


        setColumns(tempColumns);
        //sethasChechBox(!hasCheckBox);
    }

    const enableRename = () => {

        setIsRename(!isRename);
    }


    return (
        <table className="w-100 table table-striped table-hover table-borderless align-middle overflow-auto">
            <thead>
                <tr>
                    <th >
                        <div >Edit</div>

                    </th>
                    {columns.map((column, index) => (
                        <th key={index}>
                            <div className="headerColumn">
                                <ColumnCell key={index} Column={column} hasCheckBox={hasCheckBox} fnCheckbox={() => { fnCheckbox(column, index) }} />
                            </div>
                        </th>
                    ))}
                </tr>


                <tr>
                    <th>
                        <ModifyCell ColumnLabel="Edit" fnRename={enableRename} fnCheckbox={enableCheckbox} />
                    </th>
                    {
                        columns.map((column, index) => (
                            <th >
                                <div key={index} className="HeaderUtility">
                                    {
                                        hasCheckBox &&
                                        <input type="checkbox" checked={column.isChecked} onChange={() => { fnCheckbox(column) }} />

                                    }
                                    {
                                        //isRename &&
                                        <div className="clientNameSelect w-100">
                                            <Select
                                                id="ddlColumns"
                                                //{ value: p.status.value, label: p.status.label }
                                                value={column.renamed != "" ? { value: column.position, label: column.renamed } : { value: 0, label: 'select' }}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsColumnsList.map(x => (
                                                    {
                                                        value: x.columnID,
                                                        label: x.aliasColumn
                                                    }
                                                ))}
                                                onChange={(value) => fnRename(column, { value: index + 1, label:value.label })}
                                            />
                                        </div>

                                    }
                                    {/*
                                        <input
                                        type="text"
                                        value={column.renamed}
                                        onChange={(e) => fnRename(column, e.target.value)}
                                        />
                                     */
                                    }
                                </div>
                            </th>
                        ))
                    }
                </tr>

            </thead>
            <tbody>
                {data.map((row, index) => (
                    <tr key={index}>
                        <td key={index}></td>
                        {

                            columns.map((column, index) => (
                                <td key={index}>{row[column.label]}</td>
                            ))

                        }
                    </tr>
                ))}
            </tbody>
        </table>
    );
};



const ModifyCell = ({ ColumnLabel, fnRename, fnCheckbox }) => {
    if (ColumnLabel !== null || ColumnLabel !== undefined) {

        return (
            <div className="HeaderUtility">
                <div className="EditCell">
                    {/*<span>
                        <input type="button" defaultValue="Rename" onClick={fnRename} />
                    </span>
                    */}
                    <span>
                        <input type="button" defaultValue="Select All" onClick={fnCheckbox} />
                    </span>
                </div>
            </div>

        );
    }


}

const ColumnCell = ({ Column, hasCheckBox, fnCheckbox }) => {

    return (
        <div className="HeaderUtility">
            <div>
                {Column.label}
            </div>

        </div>

    );



}

export default Table;
