import React, { useState, useRef, useEffect, useContext } from 'react';
import { PageContext } from './PageState';
import Select from "react-select";


const TextSelectionComponent = ({ Tabledata, UpdateFn, headerText, InputText }) => {

    const { state, setState, handleUpdateData, handleAddData } = useContext(PageContext);

    const UpdatePosition = (value) => {

        let val = Tabledata.filter((item, i) => item.aliasColumn === DataColumn.label);

        let Temp = [...Tabledata].map((item) => {
            if (item.columnID === val[0].columnID) {
                //item.dataColumn = val.aliasColumn;
                item.startPosition = selectionStart;
                item.txtlength = selectionLength;
                return item;
                //console.log({ ...item, columnValue });
                //return { ...item, columnValue };
            } else {
                return item;
            }
        })

        UpdateFn(Temp);
        //setEdit(!edit);
    };

    const colorStyles = {
        option: (styles, { data }) => {
            let id = 0;
            if (data.value != null)
                id = data.value;
            let filteredAlias = Tabledata.filter((o, i) => (o.columnID == id));
            //if (filteredAlias[0].columnValue != null)
            return {
                ...styles,
                backgroundColor: filteredAlias[0].txtlength >0 ? "#8ec77b" : "#fff"
            };
        }
    };

    const [selectedText, setSelectedText] = useState('');
    const [selectionStart, setSelectionStart] = useState(0);
    const [selectionEnd, setSelectionEnd] = useState(0); 
    const [DataColumn, setDataColumn] = useState({ value: 0, label: 'select' });


    const handleTextSelection = () => {
        const text = window.getSelection().toString();
        const selection = window.getSelection();
        if (text) {
            setSelectedText(text);
            setSelectionStart(selection.anchorOffset);
            setSelectionEnd(selection.focusOffset);
        }
    };

    const ChangeLength = (event) => {

        const Length = event.target.value == "" ? 0 : parseInt(event.target.value, 10);
        const End = parseInt(selectionStart == null ? 0 : selectionStart) + Length;

        setSelectionEnd(End);

    }

    const selectionLength =  Math.abs(selectionEnd - selectionStart);

    return (
        <div>
            <pre className="txtHeaderField " >
                {headerText}
            </pre>
            <pre className="txtSelectionField" onMouseUp={handleTextSelection}>
                {InputText}
            </pre>
            <div className="PositionContainer">
                <div className="PositionField">
                    <div className="StartPositionField">
                        <label>Start Position </label>
                        <input
                            type="number"
                            value={selectionStart !== null ? selectionStart : 0}
                            onChange={(event) =>
                            { 
                                const num = event.target.value == "" ? 0 : parseInt(event.target.value, 10);
                                setSelectionStart(num)
                            }}
                        />
                    </div>
                    <br />
                    <div className="StartPositionField">
                        <label>Length</label>
                        <input
                            type="number"
                            value={selectionLength !== null ? selectionLength : 0}
                            onChange={ChangeLength}
                        />
                    </div>
                    <br />
                    <div className="StartPositionField">
                        <label>End Position </label>
                        <input
                            type="number"
                            value={selectionEnd !== null ? selectionEnd : 0}
                            onChange={(event) => {
                                const num = event.target.value == "" ? 0 : parseInt(event.target.value, 10);
                                setSelectionEnd(num)
                            }}
                        />
                    </div>
                </div>
                <div className="PositionFieldAction">
                    <div className="ActionField clientNameSelect">
                        <Select
                            id="ddlAliasColumns"
                            value={DataColumn}
                            classNamePrefix="reactSelectBox"
                            options={Tabledata.map(x => (
                                {
                                    value: x.columnID,
                                    label: x.aliasColumn
                                }
                            ))}
                            onChange={(value) => (setDataColumn(value))}
                            styles={colorStyles}
                        />
                    </div>
                    <div className="ActionSubmitSection">
                        <input onClick={UpdatePosition}
                            type="button" className="StyledRow_Action_Update" defaultValue="Update" />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TextSelectionComponent;
