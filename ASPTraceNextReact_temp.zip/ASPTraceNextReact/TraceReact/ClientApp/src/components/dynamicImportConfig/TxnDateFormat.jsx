import React, { useState, useRef, useEffect } from 'react';
import Select from 'react-select';
import './TxnDateFormat.css';
import MaximusAxios from "../common/apiURL" ;

import postHeader from "../../pages/login/services/post-header";


const dateColumns = [
    { value: 'TxnDateTime', label: 'TxnDateTime' },
    { value: 'TxnValueDateTime', label: 'TxnValueDateTime' },
    { value: 'TxnPostDateTime', label: 'TxnPostDateTime' },
];

const dateFormats = [
    { value: 'dd-MM-yyyy HH:mm:ss', label: 'dd-MM-yyyy HH:mm:ss' },
    { value: 'dd-MM-yyyy', label: 'dd-MM-yyyy' },
    { value: 'dd/MM/yyyy HH:mm:ss', label: 'dd/MM/yyyy HH:mm:ss' },
    { value: 'MM-dd-yyyy', label: 'MM-dd-yyyy' },
    { value: 'MM/dd/yyyy HH:mm:ss', label: 'MM/dd/yyyy HH:mm:ss' },
    { value: 'dMMyyyy', label: 'dMMyyyy' },
    { value: 'ddMyyyy', label: 'ddMyyyy' },
    { value: 'd-MM-yyyy', label: 'd-MM-yyyy' },
    { value: 'dd-M-yyyy', label: 'dd-M-yyyy' },
];




function MultiSelectDropdown({ options, selectedOptions, setSelectedOptions }) {




    const [isOpen, setIsOpen] = useState(false); 
    //const [selectedOptions, setSelectedOptions] = useState([]);
    const newRef = useRef(null);
    

    useEffect(() => {
        if (isOpen)
        {
        document.addEventListener("mousedown", handleOutsideClick);
        return () => {
            document.removeEventListener("mousedown", handleOutsideClick);
        };
        }
    });
    const handleOutsideClick = (e) => {
        if (newRef.current && !newRef.current.contains(e.target)) {
            if (isOpen)
                toggleDropdown();
        }
    };

    const toggleDropdown = () => {
        setIsOpen(prev => !prev);
    };

    const handleOptionChange = (option) => {
        const updatedOptions = [...selectedOptions];
        if (updatedOptions.includes(option)) {
            updatedOptions.splice(updatedOptions.indexOf(option), 1);
        } else {
            updatedOptions.push(option);
        }
        setSelectedOptions(updatedOptions);
    };

    return (
        <div className="multi-select-dropdown" ref={newRef}>
            <button className="multi-select-dropdown__button" onClick={toggleDropdown}>
                {selectedOptions.length > 0 ?
                    selectedOptions.length > 2 ?
                        <div className="multi-select-dropdown__selected-option">{selectedOptions.length} items selected</div>
                        :
                        <div className="multi-select-dropdown__selected-group">
                            {
                                selectedOptions.map((option) => (
                                    <span key={option} className="multi-select-dropdown__selected-option">
                                        {option}
                                    </span>
                                    ))
                            }
                        </div>    
                    : <span>Select</span>
                }
                <span>
                    <svg height="20" width="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false" class="css-tj5bde-Svg">
                        <path d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 
                        3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 
                        0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 
                        0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z">
                        </path>
                     </svg>
                </span>
            </button>
            {isOpen && (
                <div className="multi-select-dropdown__dropdown-options">
                    {options.map((option) => (
                        <label className="multi-select-dropdown__label" key={option.value}>
                            <input
                                type="checkbox"
                                value={option.value}
                                onChange={() => handleOptionChange(option.value)}
                                checked={selectedOptions.includes(option.value)}
                            />
                            {option.label}
                        </label>
                    ))}
                </div>
            )}
           
        </div>
    );
}


const TxnDateFormat = ({ setFieldDateArray}) => {
    const [selectedDateColumn, setSelectedDateColumn] = useState(null);
    const [selectedOptions, setSelectedOptions] = useState([]);

    const [dateFormatsList, setdateFormatsList] = useState(false);

    useEffect(() => {
        MaximusAxios.get('api/ReconConfig/GetDateFormats', {  mode: 'cors' }).then(result1 => {
            //?ChannelID=' + selectedChannelValue.value + '&ModeID=' + selectedModeValue.value + '&VendorType=' + selectedConfigTable.value + '&Type=' + "2"
            let DTX = result1.data.map((item) => ({ value: item.value, label: item.value }));
            setdateFormatsList(DTX);
        }).catch(error => {
            console.log('An error occurred:', error);
        });

    }, [])

    const handleSubmit = () => {
        const selectedValues = {
            DateColumn: selectedDateColumn ? selectedDateColumn.value : null,
            DateFormat: selectedOptions.map(format => format),
        };

        //console.log(selectedValues); 
        setFieldDateArray(prev =>
            ( [...prev, selectedValues])
            );
    };

    const handleDateColumnChange = (selectedOption) => {
        setSelectedDateColumn(selectedOption);
        setSelectedOptions([]);
    };

    //Flex-row
    return (
        <div className="PositionFieldAction">   
            <div className="DropDnBox">
                <div className="clientNameSelect w-100" >
                    <label>Select Date Column:</label>
                    <Select
                        value={selectedDateColumn}
                        onChange={handleDateColumnChange}
                        options={dateColumns}
                    />
                </div>

                <div className="clientNameSelect  w-100" >
                    <label>Select Date Formats:</label>
                    
                    <MultiSelectDropdown options={dateFormatsList}
                        selectedOptions={selectedOptions}
                        setSelectedOptions={setSelectedOptions}
                    />
                </div>
            </div>
            <div className="ActionSubmitSection align-button">
                <button className="StyledRow_Action_Update" onClick={handleSubmit}>Submit</button>
            </div>
        </div>
    );
};

export default TxnDateFormat;
