﻿import React, { useState, useRef, useEffect, useContext } from 'react';
import './StyledCaseComponent.css';
import Select from "react-select";
import { PageContext } from '../PageState';
import MaximusAxios from "../common/apiURL" ;
import AutocompleteTextBox from "../AutoCommandBar";

const FunctionComponent = ({ FunctionType }) => {

    if (FunctionType === "SUBSTRING")
    {
        return (
            <>
               
            </>
        );
    }

};


const LEFT = () => { };
const RIGHT = () => { };
const SUBSTRING = () => { };
const DateType = () => { };

