﻿import React, { useState } from 'react';
import Checkmark from './checkmarkComponent';
import ArrowDown from './ArrowDown';
import './StartupPanel.css'
import Select from "react-select";


const StartupPanel = () => {
    const FormatExists = true;
    let Data = FormatExists ? [

        {
            isChecked: false,
            showDropdown: false,
            Notification: "It seems format is already configured!",
            label: "Use Existing Format",
        },
        {
            isChecked: false,
            showDropdown: true,
            Notification: null,
            label: "Use Other Banks Format",
        }
        ,
        {
            isChecked: false,
            showDropdown: false,
            Notification: "",
            label: "Create New Format",
        }
    ] : [{
        isChecked: false,
        showDropdown: false,
        Notification: null,
        label: "Create New Format",
    },
    {
        isChecked: false,
        showDropdown: true,
        Notification: null,
        label: "Use Other Banks Format",
    }];


    const [checkboxData, setCheckboxData] = useState(Data);



    const handleToggleCheckbox = (index) => {



        const updatedData = checkboxData.map((data, dataIndex) => {
            if (dataIndex === index) {
                // Toggle the clicked checkbox
                return {
                    ...data, isChecked: !data.isChecked,
                };
            }
            else {

                return {
                    ...data, isChecked: false,
                };
            }
        });

        setCheckboxData(updatedData);
    };

    return (
        <div className="StartupPanel">
            <div className="OptionsPanel">
                <h5>Configure Data</h5>
            </div>
            <div className="OptionsPanel">
                {checkboxData.map((data, index) => (
                    <div className={`checkbox-card-container ${data.Notification ? 'Notification' : ''}`} key={index}>
                        {data.Notification &&
                            <div className="Extra_Data">
                                <div className="Badge-Notification">{data.Notification}</div>
                            </div>
                        }
                        <div className={`checkbox-card ${data.isChecked ? 'checked' : ''}`} onClick={() => handleToggleCheckbox(index)}>                           
                            <div className={`checkbox-card-main`}>
                                <span className="DataMain">
                                    <Checkmark
                                        width="50" height="50" color={data.isChecked ? '#80b8f4' : '#acacac'} padding="10px"
                                    />
                                    <span className="DataLabel">
                                        <span >{data.label}</span>
                                        {data.Notification &&
                                            <span className="Badge">New</span>
                                        }
                                    </span>
                                </span>                                
                            </div>
                            <div className={`checkbox-card-action`}>
                                {
                                    data.showDropdown &&
                                    <ArrowDown
                                        width="15" height="15" color={data.isChecked ? '#80b8f4' : '#acacac'}
                                    />
                                }
                            </div>
                        </div>
                        {data.isChecked && data.showDropdown && (
                            <>
                                <hr style={{ height: "1px", width: "98%", margin: "0" }} />
                                <div className={`checkbox-card-dropdown ${data.isChecked ? 'expand' : ''}`}>
                                    <div className="clientNameSelect w-100">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlColumns"
                                            //{ value: p.status.value, label: p.status.label }
                                            value={{ value: 0, label: 'select' }}
                                            classNamePrefix="reactSelectBox"
                                            options={null}
                                            onChange={() => { }}
                                        />
                                    </div>
                                </div>
                            </>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default StartupPanel;
