import React, { useState, useContext ,useEffect } from "react";
import Select from "react-select";
import { Link } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import AsyncSelect from 'react-select/async';
import MaximusAxios from "../common/apiURL" ;
import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
//import Autocomplete from "./AutoComplete";
//import Autocomplete from "./AutoCompleteFunction";
import matchArrays from "../matchArrays";
import AutocompleteTextBox from "../AutoCommandBar";
import Table from '../Table';
import StageTracker from "../StageTracker";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import { useSelector } from "react-redux";
import editRow from "../../../images/common/editRow.svg";
import Stage2Box from "../Stage2Box";
import Stage3Box from "../Stage3Box";
import Stage4Box from "../Stage4Box";
import { PageContext } from '../PageState';
import StyledTable from "../StyledTable"
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import  StatusComponent  from "../StatusComponent";
import authHeader from "../../../pages/login/services/auth-header";


const DynamicImportMainWindow = () => {

    /* Page State*/

    const { state, setState } = useContext(PageContext);
    let State_selectedReconType = state.selectedReconType;
    //console.log(State_selectedReconType);
    const [isShowModal, setShowModal] = useState(false);

    const btnStatusSubmit = () => {

        let temp = [...state.st2_StatusConditions];        
        let StatusCond = "case ";

        const concatenatedStatusConditions = temp.reduce((accumulator, currentValue) => {
            return accumulator + currentValue.statusCondition + " "+ currentValue.status.label + " ";
        }, "");

        StatusCond = "case " + concatenatedStatusConditions + " end ";

        //console.log('StatusCond');

        console.log(StatusCond);
        if (StatusCond !== undefined && StatusCond !== null)
        {
            setAliasColumnsList(
                aliasColumnsList.map((item) => {
                    if (item.aliasColumn.toLowerCase() === "status") {
                        item.columnValue = StatusCond;
                        return item;
                        //console.log({ ...item, columnValue });
                        //return { ...item, columnValue };
                    } else {
                        return item;
                    }
                })
            );
        }

        setShowModal(false);
        
    };

    const handleAddData = (index, AddedData) => {

        let { Addkey, Addvalue } = AddedData;
        
        const updatedArray = [...state[Addkey],  Addvalue ];
        //console.log("updatedArray");
        //console.log(updatedArray);

        setState(prevState => {
            return { ...prevState, [Addkey]: [...prevState[Addkey], Addvalue ]};
        });
        //setNewItem({ title: '', description: '' }); // Clear the input fields
    };

    // Update state (Update Existing Data)
    const handleUpdateData = (index, updatedData) => {

        let { Updatekey, Updatevalue } = updatedData;
        //console.log(updatedData);
        setState(prevState => {            
            return { ...prevState, ...updatedData };
        });
        


    };






    const currentUser = useSelector((state) => state.authReducer);
    


    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const [proceed, setProceed] = useState(null); //done

    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);
    const [tempQ, setTempQ] = useState(null); //done
    const [tempTable, setTempTable] = useState([]); //done

    const [optionsReconType, setOptionsReconTypeValue] = useState([]); //done
    const [selectedReconType, setselectedReconType] = useState(null); //done
    const [selectedTablesCount, setselectedTablesCount] = useState(0); //done

    const [optionsChannelType, setOptionsChannelTypeValue] = useState([]); //done
    const [selectedChannelValue, setSelectedChannelValue] = useState(null); //done

    const [optionsModeType, setOptionsModeTypeValue] = useState([]); //done
    const [selectedModeValue, setSelectedModeValue] = useState(null); //done

    const [optionsTablesList, setOptionsTablesList] = useState([]); //done


    //-----------Command List ---------------

    const [currentStage, SetcurrentStage] = useState(0); //done



    const [aliasColumnsList, setAliasColumnsList] = useState([]); //done
    const [formData, setFormData] = useState([]); //done






    const [selectedTableValue1, setselectedTableValue1] = useState(null); //done
    const [selectedTableValue2, setselectedTableValue2] = useState(null); //done
    const [selectedTableValue3, setselectedTableValue3] = useState(null); //done
    const [selectedTableValue4, setselectedTableValue4] = useState(null); //done
    const [selectedTableValue5, setselectedTableValue5] = useState(null);

    const [optionsConfigTablesList, setoptionsConfigTablesList] = useState([]);  //done
    const [selectedConfigTable, setselectedConfigTable] = useState(null); //done


    
function SvgButton({label, color, cornerRadius, width, height }) {
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  const fillColor = isHovered ? color.hover : color.default;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <defs>
        <linearGradient id="blue-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stop-color="#69b6fa"/>
                  <stop offset="100%" stop-color="#69b6fa"/>
        </linearGradient>
        <filter id="glassmorphism">
          <feGaussianBlur stdDeviation="5" result="blur"/>
          <feColorMatrix 
            in="blur" 
            mode="matrix" 
            values="1 0 0 0 0
                    0 1 0 0 0
                    0 0 1 0 0
                    0 0 0 15 -7"/>
          <feBlend in2="SourceGraphic" mode="multiply"/>
        </filter>
      </defs>
      <rect
        x="5"
        y="5"
        width={width - 10}
        height={height - 10}
        rx={cornerRadius}
        ry={cornerRadius}
        fill="#fff"
        filter="url(#glassmorphism)"
      />
      <rect
        x="5"
        y="5"
        width={width - 10}
        height={height - 10}
        rx={cornerRadius}
        ry={cornerRadius}
        fill={fillColor}
      />
      <text
        x="50%"
        y="50%"
        dominant-baseline="middle"
        text-anchor="middle"
        font-size="10px"
        fill="#fff"
      >
              {label}
      </text>
    </svg>
  );
}


    const AddParameter = ({ ParType, label }) => {



        return (
            <>
                <span>
                    {/*
                    <svg xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        class="bi bi-plus-circle"
                        viewBox="0 0 16 16">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                        <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                    </svg>
                    */}
                    

                </span>
                <span className="clientNameSelect col">
                    <label htmlFor="ConfigTable"><button onClick={(value) => onConditionAdd(ParType, value)}>
                        {/*label*/}
                        <SvgButton
                            label={label}
                            color={
                                {
                                    default: 'url(#blue-gradient)',
                                    hover: '#1976d2'
                                }
                      }
                            cornerRadius={10}
                            width={90}
                            height={33}
       />
                    </button></label>
                </span>
            </>
        );

    }

    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }

    useEffect(() => {
        //console.log("Proceed Changed");
        if (optionsConfigTablesList.length != selectedTablesCount && selectedTablesCount>0) {
            let alertMessages = "Please Select Remaining Raw Tables";
            if (alertMessages.length > 0) {
                setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                return false;
            }

        }

    }, [proceed])

    useEffect(() => {

        if (optionsConfigTablesList.length === selectedTablesCount && selectedTablesCount > 0) {
            handleUpdateData(0, { Proceed: true });
            setProceed(true);

            let st2_ConfigTablesList = state.optionsConfigTablesList.map((item) => {
                return { ...item, value: item.value, label: item.label, isCompleted: 0 };
            });

            handleUpdateData(0, { st2_optionsConfigTablesList: st2_ConfigTablesList });

        }
        else if (selectedTablesCount > 0)
        {
            handleUpdateData(0, { Proceed: false });
            setProceed(false);

        }

    }, [optionsConfigTablesList])




    const onProceed = (e) => {
        e.preventDefault();
        //console.log(optionsConfigTablesList);
        if (selectedChannelValue.value === "0" || selectedReconType.value === "0" || selectedModeValue.value === "0" ) {
            let alertMessages = "";
            if (selectedReconType.value == "0") {
                let alertMessages = "";

                if (selectedReconType.value == null || selectedReconType.value == "0") {
                    alertMessages += "Please select ReconType. \n";
                }
            }
            else if (selectedChannelValue.value == "0") {

                if (selectedChannelValue.value === null || selectedChannelValue.value === "0") {
                    alertMessages += "Please select ChannelType. \n";
                }
            }
            else {

                if (selectedModeValue.value === null || selectedModeValue.value === "0") {
                    alertMessages += "Please select ModeType. \n";
                }
            }


            if (alertMessages.length > 0) {
                setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                return false;
            }

        }
        else {

            setoptionsConfigTablesList([]);
            if (selectedTableValue1.value != 0)
            {
                handleAddData(0, { Addkey: "optionsConfigTablesList", Addvalue: selectedTableValue1})
                setoptionsConfigTablesList((prev) => [...prev, selectedTableValue1]);
            }
            if (selectedTableValue2.value != 0)
            {
                handleAddData(0, { Addkey: "optionsConfigTablesList", Addvalue: selectedTableValue2 })
                setoptionsConfigTablesList((prev) => [...prev, selectedTableValue2]);
            }
            if (selectedTableValue3.value != 0)
            {
                handleAddData(0, { Addkey: "optionsConfigTablesList", Addvalue: selectedTableValue3 })
                setoptionsConfigTablesList((prev) => [...prev, selectedTableValue3]);
            }
            if (selectedTableValue4.value != 0)
            {
                handleAddData(0, { Addkey: "optionsConfigTablesList", Addvalue: selectedTableValue4 })
                setoptionsConfigTablesList((prev) => [...prev, selectedTableValue4]);
            }

            
        }
    }

    const [optionsReversalEntry, setOptionsReversalEntryValue] = useState([]);

    const [optionsAmountDecimal, setAmountDecimalOptions] = useState([]);

    const [FormatNo, setFormatNoValue] = useState('');



    const handleOptionsReconType = value => {
        handleUpdateData(0, { optionsReconType: value });
        setOptionsReconTypeValue(value);
    };

    const handleOptionsChannelType = value => {
        handleUpdateData(0, { optionsChannelType: value });
        setOptionsChannelTypeValue(value);
    };

    const handleOptionsModeType = value => {
        handleUpdateData(0, { optionsModeType: value });
        setOptionsModeTypeValue(value);
    };

    const handleOptionsTablesList = value => {
        handleUpdateData(0, { optionsTablesList: value });
        setOptionsTablesList(value);
    };







    const handleOptionsConfigTable = value => {
        setselectedConfigTable(value);
        handleUpdateData(0, { selectedConfigTable: value });


       

    };



    const fetchClientData = (inputValue) => {

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    const handleInputChange = value => {
        setValue(value);
    };

    const handleClientChange = value => {
        handleUpdateData(0, { selectedValue: value });
        setSelectedValue(value);



        if (value.clientID !== '0') {

            MaximusAxios.get('api/ReconConfig/GetReconType', {  mode: 'cors' }).then(result1 => {
                handleOptionsReconType(result1.data);
                //console.log(result1.data);
                if (result1.data !== null || result1.data.length > 0) {
                    handleUpdateData(0, { selectedReconType: { value: "0", label: "All" } });
                    setselectedReconType({ value: "0", label: "All" });
                }
            });

            MaximusAxios.get('api/ReconConfig/GetChannelFieldList?ClientID=' + value.clientID, {  mode: 'cors' }).then(result2 => {
                handleOptionsChannelType(result2.data);
                //console.log(result2.data);
                if (result2.data !== null || result2.data.length > 0) {
                    handleUpdateData(0, { selectedChannelValue: { value: "0", label: "All" } });
                    setSelectedChannelValue({ value: "0", label: "All" });
                }
            });

            MaximusAxios.get('api/ReconConfig/GetModeFieldList?ClientID=' + value.clientID + '&ChannelID=0', {  mode: 'cors' }).then(resultMode => {
                handleOptionsModeType(resultMode.data);
                if (resultMode.data !== null || resultMode.data.length > 0) {
                    handleUpdateData(0, { selectedModeValue: { value: "0", label: "All" } });
                    setSelectedModeValue({ value: "0", label: "All" });
                }
            });


        }
        ClearData();
        //setoptionsConfigTablesList({ value: "0", label: "All" });
        setOptionsReversalEntryValue([{ value: "1", label: "1" }, { value: "2", label: "2" }]);
        setAmountDecimalOptions([{ value: "1", label: "True" }, { value: "2", label: "False" }]);
        //console.log("optionsReconType");
        //console.log(optionsReconType);
        //console.log("optionsChannelType");
        //console.log(optionsChannelType);
    }

    const ClearData = () => {
        $('#ConfigTable').val('');
        setFormatNoValue('');
    }

    const fillData = (ClientID, ReconID, ChannelID, ModeID) => {

        MaximusAxios.get('api/ReconConfig/GetFormatIdFieldList?ClientID=' + ClientID + '&ReconID=' + ReconID + '&ChannelID=' + ChannelID + '&ModeID=' + ModeID, {  mode: 'cors' }).then(result => {

            if (result.data !== null && result.data.length > 0) {

                $('#hdnformatno').val(result.data[0].formatID);

                setFormatNoValue(result.data[0].formatID);

                MaximusAxios.get('api/ReconConfig/GetFieldIdentificationDetailsList?ClientID=' + ClientID + '&ReconID=' + ReconID + '&ChannelID=' + ChannelID + '&ModeID=' + ModeID + '&FormatID=' + result.data[0].formatID, {  mode: 'cors' }).then(FieldResult => {

                    //console.log(FieldResult.data);

                    if (FieldResult.data !== null && FieldResult.data.length > 0) {


                        $('#RevType').val(FieldResult.data[0].revType);
                        if (FieldResult.data[0].revEntryLeg === "1") { setReversalEntryValue({ value: '1', label: '1' }) };
                        if (FieldResult.data[0].revEntryLeg === "2") { setReversalEntryValue({ value: '2', label: '2' }) };


                    }
                    else {
                        MaximusAxios.get('api/ReconConfig/GetFieldIdentificationVendorDetailsList?ClientID=' + ClientID + '&ReconID=' + ReconID + '&ChannelID=' + ChannelID, {  mode: 'cors' }).then(FieldResult => {


                            $('#RevType').val(FieldResult.data[0].revType);
                            if (FieldResult.data[0].revEntryLeg === "1") { setReversalEntryValue({ value: '1', label: '1' }) };
                            if (FieldResult.data[0].revEntryLeg === "2") { setReversalEntryValue({ value: '2', label: '2' }) };


                        });

                    }

                });
            }

        });


    }

    const handleReconTypeChange = value => {

        handleUpdateData(0,{ selectedReconType: value.value });
        setselectedReconType(value);
        handleUpdateData(0, { selectedTablesCount: value.value });
        setselectedTablesCount(value.value);
        //console.log(value.value);
        ClearData();

        let ReconID = 0;
        if (value === undefined || value === null) {
            ReconID = 0;
        }
        else {
            ReconID = value.value;
        }

        let ChannelId = 0;
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }
        //console.log(selectedReconType);

        MaximusAxios.get('api/ReconConfig/GetReconTables', {  mode: 'cors' }).then(result1 => {
            handleOptionsTablesList(result1.data);
            //console.log(result1.data);
            if (result1.data !== null || result1.data.length > 0) {
                setselectedTableValue1({ value: 0, label: "All",isCompleted:0 });
                setselectedTableValue2({ value: 0, label: "All",isCompleted:0 });
                setselectedTableValue3({ value: 0, label: "All",isCompleted:0 });
                setselectedTableValue4({ value: 0, label: "All",isCompleted:0 });
            }
        });
        let ModeId = 0;
        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }

        if (selectedValue.clientID !== '0') {

            //fillData(selectedValue.clientID, ReconID, ChannelId, ModeId);
        }

    }

    const handleChannelChange = value => {
        handleUpdateData(0, { selectedChannelValue: value });
        setSelectedChannelValue(value);

        ClearData();

        let ReconID = 0;
        if (selectedReconType === undefined || selectedReconType === null) {
            ReconID = 0;
        }
        else {
            ReconID = selectedReconType.value;
        }

        let ChannelId = 0;
        if (value === undefined || value === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = value.value;
        }

        MaximusAxios.get('api/ReconConfig/GetModeFieldList?ClientID=' + selectedValue.clientID + '&ChannelID=' + ChannelId, {  mode: 'cors' }).then(resultMode => {
            handleOptionsModeType(resultMode.data);
            if (resultMode.data !== null || resultMode.data.length > 0) {
                handleUpdateData(0, { selectedModeValue: { value: "0", label: "All" } });
                setSelectedModeValue({ value: "0", label: "All" });
            }
        });


        let ModeId = 0;
        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }


        if (selectedValue.clientID !== '0') {

            //fillData(selectedValue.clientID, ReconID, ChannelId, ModeId);   
        }


    }

    const handleModeChange = value => {
        handleUpdateData(0, { selectedModeValue: value });
        setSelectedModeValue(value);

        ClearData();

        let ReconID = 0;
        if (selectedReconType === undefined || selectedReconType === null) {
            ReconID = 0;
        }
        else {
            ReconID = selectedReconType.value;
        }

        let ChannelId = 0;
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }

        let ModeId = 0;
        if (value === undefined || value === null) {
            ModeId = 0;
        }
        else {
            ModeId = value.value;
        }

        if (selectedValue.clientID !== '0') {

            //fillData(selectedValue.clientID, ReconID, ChannelId, ModeId);
        }

    }

    const handleTableChange = (ID, data) => {
        let value = { value: ID, label: data.label, isCompleted:0 };
        //console.log(data.label);

        if (ID == 1) {
            handleUpdateData(0, { selectedTableValue1: value });
            setselectedTableValue1(value);
        }
        else if (ID == 2) {
            handleUpdateData(0, { selectedTableValue2: value });
            setselectedTableValue2(value);
        }
        else if (ID == 3) {
            handleUpdateData(0, { selectedTableValue3: value });
            setselectedTableValue3(value);
        }
        else if (ID == 4)
        {
            handleUpdateData(0, { selectedTableValue4: value });
            setselectedTableValue4(value);
        }
        ClearData();

        let ReconID = 0;
        if (selectedReconType === undefined || selectedReconType === null) {
            ReconID = 0;
        }
        else {
            ReconID = selectedReconType.value;
        }

        let ChannelId = 0;
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }


    }

    const colorStyles = {
        option: (styles, { data }) => {
            let id = 0;
            if (data.value != null)
                id = data.value;
            let filteredAlias = aliasColumnsList.filter((o, i) => (o.columnID == id));
            //if (filteredAlias[0].columnValue != null)
            return {
                ...styles,
                backgroundColor: filteredAlias[0].columnValue ? "#8ec77b" : "#fff"
            };
        }
    };

    const colorStylesTables = {
        option: (styles, { data }) => {
            let id = 0;
            if (data.value != null)
                id = data.value;
            let filteredAlias = optionsConfigTablesList.filter((o, i) => (o.value == id));
            //if (filteredAlias[0].columnValue != null)
            return {
                ...styles,
                backgroundColor: filteredAlias[0].isCompleted==1  ? "#8ec77b" : "#fff"
            };
        }
    };


    useEffect(() => {

       
        //console.log(tempTable);
        if (tempTable.length > 0)
        {
        setoptionsConfigTablesList(
            optionsConfigTablesList.map((item) => {
                if (item.label === selectedConfigTable.label) {
                    item.isCompleted = 1;
                    return item;
                    //console.log({ ...item, columnValue });
                    //return { ...item, columnValue };
                } else {
                    return item;
                }
            })
            
        )
        }

    }, [tempTable])



    useEffect(() => {


        console.log(formData);
        if (formData.length>0) {
            setIsLoading(true);

            MaximusAxios.post('api/ReconConfig/AddRawTableFields', formData, {  mode: 'cors' })
                .then(function (response) {
                    setIsLoading(false);
                    if (response.data != null || response.data.length > 0) {
                        let myObject = response.data;
                        let { QueryString, DataTable } = JSON.parse(myObject);
                        handleUpdateData(0, { tempQ: QueryString });
                        setTempQ(QueryString);
                        handleUpdateData(0, { tempTable: DataTable});
                        setTempTable(DataTable);
                        console.log(response.data);
                        //setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: response.data });
                    }
                    else
                    {
                        setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'Error occurred while processing your request' });
                    }
                })
                .catch(function (error) {
                    if (error.response) {
                        console.log(error.response.data);
                    }
                    setIsLoading(false);
                });
            //handleUpdateData(0, { formData: [] });
            //setFormData([]);
        }

    }, [formData])



    const btnSubmitClick = () => {

        try {

            let alertMessages = "";

            if (selectedValue === null || selectedValue.clientID === 0) {
                alertMessages += "Please select client. \n";
            }

            if (selectedReconType === undefined || selectedReconType === null) {
                alertMessages += "Please select ReconType. \n";
            }

            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                alertMessages += "Please select Channel. \n";
            }

            if (selectedModeValue === undefined || selectedModeValue === null) {
                alertMessages += "Please select mode Type. \n";
            }

            if (alertMessages.length > 0) {
                setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                return false;
            }

            let ReconID = 0;

            if (selectedReconType === undefined || selectedReconType === null) {
                ReconID = 0;
            }
            else {
                ReconID = selectedReconType.value;
            }

            let ChannelId = 0;

            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                ChannelId = 0;
            }
            else {
                ChannelId = selectedChannelValue.value;
            }

            let ModeId = 0;

            if (selectedModeValue === undefined || selectedModeValue === null) {
                ModeId = 0;
            }
            else {
                ModeId = selectedModeValue.value;
            }

            let revEntryLeg = 0;
            if (ReversalEntry === undefined || ReversalEntry === null) {
                revEntryLeg = 0;
            }
            else {
                revEntryLeg = ReversalEntry.value;
            }

            let TxnAmountIsDecimal = 0;
            if (TxnAmount === undefined || TxnAmount === null) {
                TxnAmountIsDecimal = 0;
            }
            else {
                TxnAmountIsDecimal = TxnAmount.value;
            }

            const allHaveMatchingAge = optionsConfigTablesList.every(item => item.isCompleted === 1);

            
            if (allHaveMatchingAge) {
                handleUpdateData(0, { currentStage: state.currentStage+1});
                SetcurrentStage(currentStage + 1)
            }
            else
            {
            setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'Please fill details for all tables' });
            }

        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }
    };




    return (
        <div className="configLeft identificationContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Dynamic Reconciliation Configuration
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Configuration</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Dynamic Reconciliation Config</p>
                </div>
            </div>

            {/* Top Content */}
            <div className="accordion" id="unmatchedFilters">
                <div className="accordion-item">
                    <div
                        className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                        id="unmatchedFiltersHeading"
                    >
                        <h6 className="fontWeight-600 colorBlack">Filters</h6>
                        <button
                            className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#unmatchedFiltersCollapse"
                            aria-expanded="true"
                            aria-controls="unmatchedFiltersCollapse"
                        >
                            <span className="icon-Hide"></span>
                            <span className="ms-1 fontSize12-m colorBlack">
                                Show / Hide
                            </span>
                        </button>
                    </div>
                    <div
                        id="unmatchedFiltersCollapse"
                        className="accordion-collapse collapse show"
                        aria-labelledby="unmatchedFiltersHeading"
                        data-bs-parent="#unmatchedFilters"
                    >
                        <div className="accordion-body">
                            <div className="hrGreyLine"></div>
                            <div className="configSelectBoxTop row">
                                <div className="clientNameSelect col">
                                    <label htmlFor="clientName">Client Name</label>
                                    <span className="text-danger font-size13">*</span>
                                    <AsyncSelect
                                        cacheOptions
                                        defaultOptions
                                        value={selectedValue}
                                        getOptionLabel={e => e.clientName}
                                        getOptionValue={e => e.clientID}
                                        loadOptions={fetchClientData}
                                        onInputChange={handleInputChange}
                                        onChange={handleClientChange}
                                        id="ddlClient"
                                    />
                                </div>

                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlReconType">ReconType</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlReconType"
                                        value={selectedReconType}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsReconType.map(x => (
                                            {
                                                value: x.id,
                                                label: x.reconType
                                            }
                                        ))}
                                        onChange={handleReconTypeChange}
                                    />
                                </div>

                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlChannel">Channel Type</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlChannel"
                                        value={selectedChannelValue}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsChannelType.map(x => (
                                            {
                                                value: x.channelID,
                                                label: x.channelName
                                            }
                                        ))}
                                        onChange={handleChannelChange}
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlMode">Mode Type</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlMode"
                                        value={selectedModeValue}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsModeType.map(x => (
                                            {
                                                value: x.modeID,
                                                label: x.transactionMode
                                            }
                                        ))}
                                        onChange={handleModeChange}
                                    />
                                </div>
                            </div>
                            {
                                selectedTablesCount >= 2 &&
                                <div>
                                    <h6 className="fontWeight-600 colorBlack ReconTables">Raw Data Tables</h6>

                                    <div className="hrGreyLine"></div>
                                </div>
                            }

                            <div className="configSelectBoxTop row">
                                {
                                    selectedTablesCount >= 1 &&

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Table 1</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedTableValue1}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTablesList.map(x => (
                                                {
                                                    value: x.tableID,
                                                    label: x.tableName
                                                }
                                            ))}
                                            onChange={(value) => handleTableChange(1, value)}
                                        />
                                    </div>
                                }
                                {
                                    selectedTablesCount >= 2 &&
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Table 2</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedTableValue2}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTablesList.map(x => (
                                                {
                                                    value: x.tableID,
                                                    label: x.tableName
                                                }
                                            ))}
                                            onChange={(value) => handleTableChange(2, value)}
                                        />
                                    </div>
                                }
                                {
                                    selectedTablesCount >= 3 &&
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Table 3</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedTableValue3}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTablesList.map(x => (
                                                {
                                                    value: x.tableID,
                                                    label: x.tableName
                                                }
                                            ))}
                                            onChange={(value) => handleTableChange(3, value)}
                                        />
                                    </div>
                                }
                                {
                                    selectedTablesCount >= 4 &&
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Table 4</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedTableValue4}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTablesList.map(x => (
                                                {
                                                    value: x.tableID,
                                                    label: x.tableName
                                                }
                                            ))}
                                            onChange={(value) => handleTableChange(4, value)}
                                        />
                                    </div>
                                }

                            </div>

                            {
                                selectedTablesCount >= 2 &&
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <button
                                            type="button"
                                            className="btnPrimaryOutline"
                                            onClick={(e) => onProceed(e)}
                                        >Proceed</button>
                                    </div>
                                </div>
                            }
                        </div>
                    </div>
                </div>
            </div>
            {proceed &&
                <div className="BottomPanel">
                    {/* Bottom Content */}
                    {/* ProgressBar  */}
                    <div>
                        
                        <div className="progress-stages">
                            <StageTracker currentStage={currentStage} />
                        </div>
                    </div>
                    {/* ProgressBar */}
                    <div id="MiddleSection">
                        {/* TempTable */}
                        {
                            currentStage == 0 &&

                            <div id='TempTable' className="configLeftBottom">

                                <div className="tableBorderBox">
                                    <div className="configSelectBoxTop row">


                                        <div className="clientNameSelect col">
                                            <label htmlFor="ConfigTable">Table Name</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlTable"
                                                value={selectedConfigTable}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsConfigTablesList.map(x => (
                                                    {
                                                        value: x.value,
                                                        label: x.label
                                                    }
                                                ))}
                                                onChange={handleOptionsConfigTable}
                                                styles={colorStylesTables}
                                            />
                                        </div>

                                    </div>
                                    {/*----GRID-------*/}
                                    {selectedConfigTable != null &&
                                        <div className="tableBorderBox mt-2 pt-3">                                       

                                           

                                        </div>
                                    }
                                   

                                </div>
                            </div>
                        }
                        {/* TempTable */}
                        {/* Stage2 */}
                        {
                            currentStage == 1 &&
                            <div id='TempTable' className="row tableBorderBox">
                                <Stage2Box />
                            </div>
                        }
                        {/* Stage3 */}
                        {
                            currentStage == 2 &&
                            <div id='TempTable' className="row tableBorderBox">
                                <Stage3Box />
                            </div>
                        }
                        {/* Stage4 */}
                        {
                            currentStage == 3 &&
                        <div id='TempTable' className="row tableBorderBox">
                            <Stage4Box FormData={formData} />
                            </div>
                        }

                </div>

                    <div className="mt-50 text-center btnsBtm">
                    {currentStage <= 2 &&
                        <button
                            type="button"
                            className="btnPrimary ms-2"
                            onClick={btnSubmitClick}
                                >
                                    Continue
                        </button>
                    }
                    
                        <button
                                    type="button"
                                    className="btnPrimaryOutline"
                        onClick={() => {
                            handleUpdateData(0, { currentStage: state.currentStage - 1 })
                            SetcurrentStage(currentStage - 1)
                        }}
                                >
                                    Back
                         </button>

                    </div>
                    {/* Bottom Content */}
                </div>
            }
            {isShowModal && (
                <Modal
                    show={isShowModal}
                    onHide={() => setShowModal(!isShowModal)}
                    centered
                    size= "xl"                    
                    className="StatusModal"
                >
                    <Modal.Header closeButton>
                        <Modal.Title className="fontSize16-sm letterSpacing-2">
                             <span>Status Column Properties</span>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="statusControl">
                            <StatusComponent
                                Table={state.selectedConfigTable}
                                Tabledata={aliasColumnsList}
                                UpdateFn={handleAliasColumnsList}
                            />
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <button type="button" className="btnPrimary ms-2" onClick={() => { btnStatusSubmit() }} >Submit</button>
                    </Modal.Footer>
                </Modal>
            )}
            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default DynamicImportMainWindow;


