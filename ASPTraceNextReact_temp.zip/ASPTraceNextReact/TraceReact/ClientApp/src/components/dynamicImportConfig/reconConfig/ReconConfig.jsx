import React from "react";
import { useSelector } from "react-redux";
// CSS
import "./reconConfig.css";
// Components
import SidebarMain from "../common/SidebarMain";
import ReconConfigMainWindow from "./ReconConfigMainWindow";
import { PageProvider } from './PageState';
//<ReconConfigMainWindow />  Replace below component with this when required   <DynamicImportMainWindow/>


const ReconConfig = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView d-flex">
      <SidebarMain />
          <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
              <PageProvider>
                  <ReconConfigMainWindow />
              </PageProvider>
      </div>
    </div>
  );
};

export default ReconConfig;
