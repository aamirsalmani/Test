import React, { useState, useContext ,useEffect } from "react";
import Select from "react-select";
import { Link } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import AsyncSelect from 'react-select/async';
import MaximusAxios from "../common/apiURL" ;
import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
//import Autocomplete from "./AutoComplete";
//import Autocomplete from "./AutoCompleteFunction";
import matchArrays from "./matchArrays";
import AutocompleteTextBox from "./AutoCommandBar";
import Table from './Table';
import StageTracker from "./StageTracker";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { useSelector } from "react-redux";
import editRow from "../../images/common/editRow.svg";
import Stage2Box from "./Stage2Box";
import Stage3Box from "./Stage3Box";
import Stage4Box from "./Stage4Box";
import { PageContext } from './PageState';
import StyledTable from "./StyledTable"
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import  StatusComponent  from "./StatusComponent";
import axios from 'axios';
import { FileUploader } from "react-drag-drop-files"; 
import postHeader from "../../pages/login/services/post-header";
import { formatXML } from './UtilityFunction';
import { MarkerComponent } from './MarkerComponent';
import TextSelectionComponent from "./TextSelectionComponent";

const ReconConfigMainWindow = () => {

    /* Page State*/

    const { state, setState } = useContext(PageContext);
    let State_selectedReconType = state.selectedReconType;
    //console.log(State_selectedReconType);
    const [isShowModal, setShowModal] = useState(false);
    const [UploadedTable, setUploadedTable] = useState();
    const [submitTable, setSubmitTable] = useState([]);
    const [txtFileFound, setTxtFileFound] = useState(false);
    const [selectedtableNo, setSelectedtableNo] = useState(0);
    const [headerText, setHeaderText] = useState('');
    const [txtBoxData, setTxtBoxData] = useState('');
    const [separatorOption, setSeparatorOption] = useState('None');
    const [separator, setSeparator] = useState('');
    const [isShowSeperatorModal, setShowSeperatorModal] = useState(false);

    const [isTextBox, setIsTextBox] = useState(false);

    const handleSeperatorChange = (e) => {
        setSeparatorOption(e.target.value);

        // Clear the separator input when "None" is selected
        if (e.target.value === 'None') {
            setSeparator('');
        }
    };

    const btnStatusSubmit = () => {

        let temp = [...state.st2_StatusConditions];        
        let StatusCond = "case ";

        const concatenatedStatusConditions = temp.reduce((accumulator, currentValue) => {
            return accumulator + currentValue.statusCondition + " "+ currentValue.status.label + " ";
        }, "");

        StatusCond = "case " + concatenatedStatusConditions + " end ";

        //console.log('StatusCond');

        console.log(StatusCond);
        if (StatusCond !== undefined && StatusCond !== null)
        {
            setAliasColumnsList(
                aliasColumnsList.map((item) => {
                    if (item.aliasColumn.toLowerCase() === "status") {
                        item.columnValue = StatusCond;
                        return item;
                        //console.log({ ...item, columnValue });
                        //return { ...item, columnValue };
                    } else {
                        return item;
                    }
                })
            );
        }

        setShowModal(false);
        
    };

        //Upload Config

    const TableUpdateFn = (Table) => {

        let arr = [...Table]
            .filter(item => item.isChecked === true)
            .map((item, index) => {
                return { id: index, columnName: item.renamed !== '' ? item.renamed : item.label, position: item.position, dataType: "string", dataValue: item.dataValue }
            });
        arr.unshift({ id: arr.length, columnName: 'select', position:0, dataType: "string", dataValue: '' });
        console.log(arr);
        setSubmitTable(arr);
        

    }; 

    const [toggleGrid, setToggleGrid] = useState(false);

    const onsubmit = () => {

        handleOptionsColumnsList(submitTable);
        setToggleGrid(true);

    }

    const SubmitFileConfig = () => {


        if (currentUser !== null && currentUser.user !== null) {

            try {
                if (aliasColumnsList.length > 0) {

                    setIsLoading(true);

                    const data = new FormData();
                    data.append("ClientID", selectedValue.clientID);
                    data.append("ChannelID", selectedChannelValue.value);
                    data.append("ModeID", selectedModeValue.value);
                    data.append("VendorID", selectedVendorValue.value);
                    data.append("ReconType", selectedReconType.value);
                    data.append("Table.TableNo", selectedConfigTable.value);
                    data.append("Table.TableName", selectedConfigTable.label);
                    data.append("ConfigData", aliasColumnsList);
                    data.append("UserName", currentUser.user.username);

                    let hasPositionFilter = aliasColumnsList.filter((item, i) => ( item.txtlength >0 ) )

                    let xmlString = "";

                    if (hasPositionFilter.length > 0) {

                        let XMLDataTable = aliasColumnsList.map((item) => ({ [item.aliasColumn]: { StartPosition: item.startPosition, Length: item.txtlength } }));
                        xmlString = formatXML(XMLDataTable,"Position");

                    }
                    else
                    {
                        let XMLDataTable = aliasColumnsList.map((item) => ({ [item.aliasColumn]: item.position }));
                        xmlString = formatXML(XMLDataTable,"none");
                    }
                    


                     

                    data.append("FormatXML", xmlString);


                    
                    axios.post("api/ReconConfig/FileConfig", data, { headers: postHeader(), mode: 'cors' })
                        .then((res) => {

                            console.log("Uploaded FileConfig");
                            console.log(res);
                            
                        }, error => {
                            console.log(error);
                        });

                     
                    setIsLoading(false);

                    
                    

                }
            }
            catch (ex) {
                console.log(ex);
                setIsLoading(false);
            }

            let alertMessages = "";
            alertMessages += 'Configuration Saved Successfully.';


            if (alertMessages.length > 0) {
                setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Process Status", alertMessage: alertMessages });

            }
        }
    }


    const onUpload = () => {

        if (currentUser !== null && currentUser.user !== null) {

            try {

                let alertMessages = "";

                if (selectedValue === null || selectedValue.clientID === "0") {
                    alertMessages += 'Please select Client. \n';
                }
               
                if (importFile === null || importFile.length === 0) {
                    alertMessages += 'Please select File. \n';
                }

                if (alertMessages.length > 0) {
                    setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                    return false;
                }

                var arr = [];
                
                    arr.push(importFile);
                

                if (arr.length > 0) {

                    setIsLoading(true);

                    let Sepr = separator.length > 0 && separator.trim().length == 0 ? "space" : separator;
                    const data = new FormData();
                    data.append("ClientID", selectedValue.clientID);
                    data.append("ImportFile", importFile);
                    data.append("Seperator", Sepr);
                    data.append("UserName", currentUser.user.username);

                    axios.post("api/ReconConfig", data, { headers: postHeader(), mode: 'cors' })
                        .then((res) => {

                            console.log("Uploaded Data");
                            console.log(res);
                            let { DataTable } = res.data;
                            
                            

                            if (separator.length === 0 && importFile.type == 'text/plain') {
                                console.log(DataTable[0].Data);
                                setHeaderText(DataTable[0].Data);
                                setTxtBoxData(DataTable[1].Data);
                                setToggleGrid(true);
                                setIsTextBox(true);
                                handleUpdateData(0, { hasSeperatorPosition: true });
                            }
                            else {

                                setUploadedTable(DataTable);
                                setIsTextBox(false);
                                handleUpdateData(0, { hasSeperatorPosition: false });
                            }
                         }, error => {
                             console.log(error);
                        });
                    

                    setIsLoading(false);
                    
                }
            }
            catch (ex) {
                console.log(ex);
                setIsLoading(false);
            }
        }
        else {
            alert('Session Timeout');
        }
    };

    //Upload Config

    const handleuploadFile = async (file) => {

        setImportFile(file);
        let FileNames = '';
        
        FileNames = FileNames + file.name ;        
        setFileName(FileNames);

        if (file.type === "text/plain") {
            setSeparator("");
            setShowSeperatorModal(true);
        }
        else if (file.type === "text/csv")
        {
            setSeparator(",");

        }

    };

    // Drop File
    const [fileName, setFileName] = useState();
    const [importFile, setImportFile] = useState();

    const [fileTypes, setFileTypes] = useState(["xlsx", "xls", "csv", "txt"]);

    const handleAddData = (index, AddedData) => {

        let { Addkey, Addvalue } = AddedData;
        
        const updatedArray = [...state[Addkey],  Addvalue ];
        //console.log("updatedArray");
        //console.log(updatedArray);

        setState(prevState => {
            return { ...prevState, [Addkey]: [...prevState[Addkey], Addvalue ]};
        });
        //setNewItem({ title: '', description: '' }); // Clear the input fields
    };

    // Update state (Update Existing Data)
    const handleUpdateData = (index, updatedData) => {

        let { Updatekey, Updatevalue } = updatedData;
        //console.log(updatedData);
        setState(prevState => {            
            return { ...prevState, ...updatedData };
        });
        


    };

    useEffect(() => {
        //console.log("UpdatedData");
        //console.log(state);

    }, [state])



    //console.log(Friends);
    /* Page State*/


    const currentUser = useSelector((state) => state.authReducer);
    


    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const [proceed, setProceed] = useState(null); //done

    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);
    const [tempQ, setTempQ] = useState(null); //done
    const [tempTable, setTempTable] = useState([]); //done

    const [optionsReconType, setOptionsReconTypeValue] = useState([]); //done
    const [selectedReconType, setselectedReconType] = useState(null); //done
    const [selectedTablesCount, setselectedTablesCount] = useState(0); //done

    const [optionsChannelType, setOptionsChannelTypeValue] = useState([]); //done
    const [selectedChannelValue, setSelectedChannelValue] = useState(null); //done

    const [optionsModeType, setOptionsModeTypeValue] = useState([]); //done
    const [selectedModeValue, setSelectedModeValue] = useState(null); //done

    const [optionsTablesList, setOptionsTablesList] = useState([]); //done

    const [optionsColumnsList, setOptionsColumnsList] = useState([]);  //done
    const [optionsOperationList, setOptionsOperationList] = useState([]);  //done
    const [optionsParamList, setOptionsParamList] = useState([]);  //done

    //-----------Command List ---------------

    const [currentStage, SetcurrentStage] = useState(0); //done

    const [optionsCommandsList, setOptionsCommandsList] = useState([]); //done

    const [aliasColumnsList, setAliasColumnsList] = useState([]); //done
    const [formData, setFormData] = useState([]); //done

    const [columnText, setColumnText] = useState([]); //done
    const [columnValuesList, setColumnValuesList] = useState([]); //done
    const [whereList, setwhereList] = useState([]); //done

    const [selectedColumns, setselectedColumns] = useState({});  //done
    const [selectedAliasValue, setselectedAliasValue] = useState(null); //done
    const [selectedWhereValue, setselectedWhereValue] = useState(null); //done
    const [inputTextValue, setInputTextValue] = useState(null);   //done
    const [inputWhereTextValue, setInputWhereTextValue] = useState(null); //done


    const [selectedTableValue1, setselectedTableValue1] = useState(null); //done
    const [selectedTableValue2, setselectedTableValue2] = useState(null); //done
    const [selectedTableValue3, setselectedTableValue3] = useState(null); //done
    const [selectedTableValue4, setselectedTableValue4] = useState(null); //done
    const [selectedTableValue5, setselectedTableValue5] = useState(null);

    const [optionsConfigTablesList, setoptionsConfigTablesList] = useState([]);  //done
    const [selectedConfigTable, setselectedConfigTable] = useState(null); //done


    const [optionsVendor, setOptionsVendorValue] = useState([{ vendorID: "0", vendorName: "--Select--" }]);
    const [selectedVendorValue, setSelectedVendorValue] = useState(null);

    
function SvgButton({label, color, cornerRadius, width, height }) {
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
  };

  const fillColor = isHovered ? color.hover : color.default;

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      <defs>
        <linearGradient id="blue-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stop-color="#69b6fa"/>
                  <stop offset="100%" stop-color="#69b6fa"/>
        </linearGradient>
        <filter id="glassmorphism">
          <feGaussianBlur stdDeviation="5" result="blur"/>
          <feColorMatrix 
            in="blur" 
            mode="matrix" 
            values="1 0 0 0 0
                    0 1 0 0 0
                    0 0 1 0 0
                    0 0 0 15 -7"/>
          <feBlend in2="SourceGraphic" mode="multiply"/>
        </filter>
      </defs>
      <rect
        x="5"
        y="5"
        width={width - 10}
        height={height - 10}
        rx={cornerRadius}
        ry={cornerRadius}
        fill="#fff"
        filter="url(#glassmorphism)"
      />
      <rect
        x="5"
        y="5"
        width={width - 10}
        height={height - 10}
        rx={cornerRadius}
        ry={cornerRadius}
        fill={fillColor}
      />
      <text
        x="50%"
        y="50%"
        dominant-baseline="middle"
        text-anchor="middle"
        font-size="10px"
        fill="#fff"
      >
              {label}
      </text>
    </svg>
  );
}


    const AddParameter = ({ ParType, label }) => {



        return (
            <>
                <span>
                    {/*
                    <svg xmlns="http://www.w3.org/2000/svg"
                        width="16"
                        height="16"
                        fill="currentColor"
                        class="bi bi-plus-circle"
                        viewBox="0 0 16 16">
                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                        <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z" />
                    </svg>
                    */}
                    

                </span>
                <span className="clientNameSelect col">
                    <label htmlFor="ConfigTable"><button onClick={(value) => onConditionAdd(ParType, value)}>
                        {/*label*/}
                        <SvgButton
                            label={label}
                            color={
                                {
                                    default: 'url(#blue-gradient)',
                                    hover: '#1976d2'
                                }
                      }
                            cornerRadius={10}
                            width={90}
                            height={33}
       />
                    </button></label>
                </span>
            </>
        );

    }

    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }

    useEffect(() => {
        //console.log("Proceed Changed");
        if (optionsConfigTablesList.length != selectedTablesCount && selectedTablesCount>0) {
            let alertMessages = "Please Select Remaining Raw Tables";
            if (alertMessages.length > 0) {
                setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                return false;
            }

        }

    }, [proceed])

    useEffect(() => {

        if (optionsConfigTablesList.length === selectedTablesCount && selectedTablesCount > 0) {
            handleUpdateData(0, { Proceed: true });
            setProceed(true);

            let st2_ConfigTablesList = state.optionsConfigTablesList.map((item) => {
                return { ...item, value: item.value, label: item.label, isCompleted: 0 };
            });

            handleUpdateData(0, { st2_optionsConfigTablesList: st2_ConfigTablesList });

        }
        else if (selectedTablesCount > 0)
        {
            handleUpdateData(0, { Proceed: false });
            setProceed(false);

        }

    }, [optionsConfigTablesList])




    const onProceed = (e) => {
        e.preventDefault();
        //console.log(optionsConfigTablesList);
        if (selectedChannelValue.value === "0" || selectedReconType.value === "0" || selectedModeValue.value === "0" ) {
            let alertMessages = "";
            if (selectedReconType.value == "0") { 

                if (selectedReconType.value == null || selectedReconType.value == "0") {
                    alertMessages += "Please select ReconType. \n";
                }
            }
            else if (selectedChannelValue.value == "0") {

                if (selectedChannelValue.value === null || selectedChannelValue.value === "0") {
                    alertMessages += "Please select ChannelType. \n";
                }
            }
            else {

                if (selectedModeValue.value === null || selectedModeValue.value === "0") {
                    alertMessages += "Please select ModeType. \n";
                }
            }


            if (alertMessages.length > 0) {
                setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                return false;
            }

        }
        else {

            setoptionsConfigTablesList([]);
            if (selectedTableValue1.value != 0)
            {
                handleAddData(0, { Addkey: "optionsConfigTablesList", Addvalue: selectedTableValue1})
                setoptionsConfigTablesList((prev) => [...prev, selectedTableValue1]);
            }
            if (selectedTableValue2.value != 0)
            {
                handleAddData(0, { Addkey: "optionsConfigTablesList", Addvalue: selectedTableValue2 })
                setoptionsConfigTablesList((prev) => [...prev, selectedTableValue2]);
            }
            if (selectedTableValue3.value != 0)
            {
                handleAddData(0, { Addkey: "optionsConfigTablesList", Addvalue: selectedTableValue3 })
                setoptionsConfigTablesList((prev) => [...prev, selectedTableValue3]);
            }
            if (selectedTableValue4.value != 0)
            {
                handleAddData(0, { Addkey: "optionsConfigTablesList", Addvalue: selectedTableValue4 })
                setoptionsConfigTablesList((prev) => [...prev, selectedTableValue4]);
            }

            
        }
    }

    const [optionsReversalEntry, setOptionsReversalEntryValue] = useState([]);

    const [optionsAmountDecimal, setAmountDecimalOptions] = useState([]);

    const [FormatNo, setFormatNoValue] = useState('');

    const [ReversalEntry, setReversalEntryValue] = useState(null);

    const [TxnAmount, setTxnAmountValue] = useState(null);

    const handleOptionsReconType = value => {
        handleUpdateData(0, { optionsReconType: value });
        setOptionsReconTypeValue(value);
    };

  

    const handleOptionsChannelType = value => {
        handleUpdateData(0, { optionsChannelType: value });
        setOptionsChannelTypeValue(value);
    };

    const handleOptionsModeType = value => {
        handleUpdateData(0, { optionsModeType: value });
        setOptionsModeTypeValue(value);
    };

    const handleOptionsTablesList = value => {
        handleUpdateData(0, { optionsTablesList: value });
        setOptionsTablesList(value);
    };
    const handleOptionsColumnsList = value => {
        handleUpdateData(0, { optionsColumnsList: value });
        setOptionsColumnsList(value);
    };

    const handleAliasColumnsList = value => {
        handleUpdateData(0, { aliasColumnsList: value });
        setAliasColumnsList(value);
    };

    const handleOperationsList = value => {
        handleUpdateData(0, { optionsOperationList: value });
        setOptionsOperationList(value);
    };

    const handleParametersList = value => {
        handleUpdateData(0, { optionsParamList: value });
        setOptionsParamList(value);
    };
    const InitialValues = {
        'AliasColumn': { value: 0, label: "select" },
        'ColumnName': { value: 0, label: "select" },
        'Where': { value: 0, label: "select" }
    }

    const handleVendorChange = value => {

        setSelectedVendorValue(value);
        
        MaximusAxios.get('api/ReconConfig/GetReconAliasColumns?ChannelID=' + selectedChannelValue.value + '&ModeID=' + selectedModeValue.value + '&VendorType=' + selectedConfigTable.value, {  mode: 'cors' }).then(result1 => {
            //handleAliasColumnsList(result1.data);
            setAliasColumnsList(result1.data);
            console.log(result1.data);
        }).catch(error => {
            // Handle the error here
            console.log('An error occurred:', error);
            console.log('VendorChange Input:', value);
        });
    }


    const onConditionAdd = (id, value) => {
        //arr.push({ id, username: name });
        //if (!ColumnValuesList.includes({ ColumnName: "case when " }))
        switch (id) {
            case "AddElse": return handleAliasColumnChange("ColumnName", " else ");
            case "AddCase": return handleAliasColumnChange("ColumnName", " case when ");
            case "AddWhen": return handleAliasColumnChange("ColumnName", " when ");
            case "AddThen": return handleAliasColumnChange("ColumnName", " then ");
            case "AddAND": return handleAliasColumnChange("ColumnName", " and ");
            case "AddOR": return handleAliasColumnChange("ColumnName", " or ");
            case "AddEND": return handleAliasColumnChange("ColumnName", " END ");
            case "WhereElse": return handleAliasColumnChange("Where", " else ");
            case "WhereCase": return handleAliasColumnChange("Where", " case when ");
            case "WhereWhen": return handleAliasColumnChange("Where", " when ");
            case "WhereThen": return handleAliasColumnChange("Where", " then ");
            case "WhereAND": return handleAliasColumnChange("Where", " and ");
            case "WhereOR": return handleAliasColumnChange("Where", " or ");
            case "WhereEND": return handleAliasColumnChange("ColumnName", " END ");
        }

        //if (id == "AddElse") {
        //    handleAliasColumnChange("ColumnName", " else ");
        //}
        //else if (id == "AddCondition") {
        //    let found = columnValuesList.some(el => el.ColumnName === "case when ");
        //    if (!found)
        //        handleAliasColumnChange("ColumnName", "case when ");
        //    else {
        //        found = columnValuesList.some(el => el.ColumnName === " then ");
        //        //if (columnValuesList.includes(' then '))
        //        if (found)
        //            handleAliasColumnChange("ColumnName", " when ");
        //        else
        //            handleAliasColumnChange("ColumnName", " then ");
        //    }
        //}

    }

    const handleMatchArrays = () => {

        const [newArray] = matchArrays(
            aliasColumnsList,
            optionsColumnsList
        );
        handleUpdateData(0, { aliasColumnsList: newArray });
        setAliasColumnsList(newArray);
    };

    const handleOptionsConfigTable = value => {
        setselectedConfigTable(value);
        handleUpdateData(0, { selectedConfigTable: value });

        const index = optionsConfigTablesList.findIndex(item => item.value === value.value);

        if (index !== -1) {
            setSelectedtableNo(index); 
        }
        else
        {
            console.log(`Element not found !`);
        }
        
        //MaximusAxios.get('api/ReconConfig/GetReconColumns?Tablename=' + value.label, {  mode: 'cors' }).then(result1 => {
        //    handleOptionsColumnsList(result1.data);
        //    //console.log(result1.data);
        //});

        if (value.value !== '0' && selectedValue.clientID !== '0') {
            MaximusAxios.get('api/FileConfig/GetVendorFileConfigList?ClientID=' + selectedValue.clientID + '&VendorType=' + value.value, {  mode: 'cors' }).then(result => {
                setOptionsVendorValue(result.data);
            });
        }

        MaximusAxios.get('/api/Common/GetReactFileTypeList', {  mode: 'cors' }).then(result1 => {
            setFileTypes(JSON.parse(result1.data));
        });

        //MaximusAxios.get('api/ReconConfig/GetReconAliasColumns?ChannelID=' + selectedChannelValue.value + '&ModeID=' + selectedModeValue.value + '&VendorType=' + value.value, {  mode: 'cors' }).then(result1 => {
        //    handleAliasColumnsList(result1.data);
        //    console.log(result1.data);
        //}).catch(error => {
        //    // Handle the error here
        //    console.error('An error occurred:', error);
        //});

        MaximusAxios.get('api/ReconConfig/GetOperations', {  mode: 'cors' }).then(result1 => {
            handleOperationsList(result1.data);
            //console.log(result1.data);
        });

        MaximusAxios.get('api/ReconConfig/GetParameters', {  mode: 'cors' }).then(result1 => {
            handleParametersList(result1.data);
            //console.log(result1.data);
        });
        if (whereList.length > 0) {
            //console.log("ResetWhereValue");
            handleUpdateData(0, { whereList: [] });
            setwhereList([]);
            handleUpdateData(0, { inputTextValue: null });
            setInputTextValue(null);
            handleUpdateData(0, { inputWhereTextValue:null});
            setInputWhereTextValue(null)
        }
        
        handleUpdateData(0, { selectedColumns: InitialValues });
        setselectedColumns(InitialValues);

    };


    const handleReversalEntry = value => {
        setReversalEntryValue(value);
    };

    const handleTxnAmount = value => {
        setTxnAmountValue(value);
    };

    const fetchClientData = (inputValue) => {

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    const handleInputChange = value => {
        setValue(value);
    };

    const handleClientChange = value => {
        handleUpdateData(0, { selectedValue: value });
        setSelectedValue(value);



        if (value.clientID !== '0') {

            MaximusAxios.get('api/ReconConfig/GetReconType', {  mode: 'cors' }).then(result1 => {
                handleOptionsReconType(result1.data);
                //console.log(result1.data);
                if (result1.data !== null || result1.data.length > 0) {
                    handleUpdateData(0, { selectedReconType: { value: "0", label: "All" } });
                    setselectedReconType({ value: "0", label: "All" });
                }
            });

            MaximusAxios.get('api/ReconConfig/GetChannelFieldList?ClientID=' + value.clientID, {  mode: 'cors' }).then(result2 => {
                handleOptionsChannelType(result2.data);
                //console.log(result2.data);
                if (result2.data !== null || result2.data.length > 0) {
                    handleUpdateData(0, { selectedChannelValue: { value: "0", label: "All" } });
                    setSelectedChannelValue({ value: "0", label: "All" });
                }
            });

            MaximusAxios.get('api/ReconConfig/GetModeFieldList?ClientID=' + value.clientID + '&ChannelID=0', {  mode: 'cors' }).then(resultMode => {
                handleOptionsModeType(resultMode.data);
                if (resultMode.data !== null || resultMode.data.length > 0) {
                    handleUpdateData(0, { selectedModeValue: { value: "0", label: "All" } });
                    setSelectedModeValue({ value: "0", label: "All" });
                }
            });


        }
        ClearData();
        //setoptionsConfigTablesList({ value: "0", label: "All" });
        setOptionsReversalEntryValue([{ value: "1", label: "1" }, { value: "2", label: "2" }]);
        setAmountDecimalOptions([{ value: "1", label: "True" }, { value: "2", label: "False" }]);
        //console.log("optionsReconType");
        //console.log(optionsReconType);
        //console.log("optionsChannelType");
        //console.log(optionsChannelType);
    }

    const ClearData = () => {
        $('#ConfigTable').val('');
        setFormatNoValue('');
    }

    const fillData = (ClientID, ReconID, ChannelID, ModeID) => {

        MaximusAxios.get('api/ReconConfig/GetFormatIdFieldList?ClientID=' + ClientID + '&ReconID=' + ReconID + '&ChannelID=' + ChannelID + '&ModeID=' + ModeID, {  mode: 'cors' }).then(result => {

            if (result.data !== null && result.data.length > 0) {

                $('#hdnformatno').val(result.data[0].formatID);

                setFormatNoValue(result.data[0].formatID);

                MaximusAxios.get('api/ReconConfig/GetFieldIdentificationDetailsList?ClientID=' + ClientID + '&ReconID=' + ReconID + '&ChannelID=' + ChannelID + '&ModeID=' + ModeID + '&FormatID=' + result.data[0].formatID, {  mode: 'cors' }).then(FieldResult => {

                    //console.log(FieldResult.data);

                    if (FieldResult.data !== null && FieldResult.data.length > 0) {


                        $('#RevType').val(FieldResult.data[0].revType);
                        if (FieldResult.data[0].revEntryLeg === "1") { setReversalEntryValue({ value: '1', label: '1' }) };
                        if (FieldResult.data[0].revEntryLeg === "2") { setReversalEntryValue({ value: '2', label: '2' }) };


                    }
                    else {
                        MaximusAxios.get('api/ReconConfig/GetFieldIdentificationVendorDetailsList?ClientID=' + ClientID + '&ReconID=' + ReconID + '&ChannelID=' + ChannelID, {  mode: 'cors' }).then(FieldResult => {


                            $('#RevType').val(FieldResult.data[0].revType);
                            if (FieldResult.data[0].revEntryLeg === "1") { setReversalEntryValue({ value: '1', label: '1' }) };
                            if (FieldResult.data[0].revEntryLeg === "2") { setReversalEntryValue({ value: '2', label: '2' }) };


                        });

                    }

                });
            }

        });


    }

    const handleReconTypeChange = value => {

        handleUpdateData(0,{ selectedReconType: value.value });
        setselectedReconType(value);
        handleUpdateData(0, { selectedTablesCount: value.value });
        setselectedTablesCount(value.value);
        //console.log(value.value);
        ClearData();

        let ReconID = 0;
        if (value === undefined || value === null) {
            ReconID = 0;
        }
        else {
            ReconID = value.value;
        }

        let ChannelId = 0;
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }
        //console.log(selectedReconType);

        MaximusAxios.get('api/ReconConfig/GetReconTables', {  mode: 'cors' }).then(result1 => {
            handleOptionsTablesList(result1.data);
            //console.log(result1.data);
            if (result1.data !== null || result1.data.length > 0) {
                setselectedTableValue1({ value: 0, label: "All",isCompleted:0 });
                setselectedTableValue2({ value: 0, label: "All",isCompleted:0 });
                setselectedTableValue3({ value: 0, label: "All",isCompleted:0 });
                setselectedTableValue4({ value: 0, label: "All",isCompleted:0 });
            }
        });
        let ModeId = 0;
        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }

        if (selectedValue.clientID !== '0') {

            //fillData(selectedValue.clientID, ReconID, ChannelId, ModeId);
        }

    }

    const handleChannelChange = value => {
        handleUpdateData(0, { selectedChannelValue: value });
        setSelectedChannelValue(value);

        ClearData();

        let ReconID = 0;
        if (selectedReconType === undefined || selectedReconType === null) {
            ReconID = 0;
        }
        else {
            ReconID = selectedReconType.value;
        }

        let ChannelId = 0;
        if (value === undefined || value === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = value.value;
        }

        MaximusAxios.get('api/ReconConfig/GetModeFieldList?ClientID=' + selectedValue.clientID + '&ChannelID=' + ChannelId, {  mode: 'cors' }).then(resultMode => {
            handleOptionsModeType(resultMode.data);
            if (resultMode.data !== null || resultMode.data.length > 0) {
                handleUpdateData(0, { selectedModeValue: { value: "0", label: "All" } });
                setSelectedModeValue({ value: "0", label: "All" });
            }
        });


        let ModeId = 0;
        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }


        if (selectedValue.clientID !== '0') {

            //fillData(selectedValue.clientID, ReconID, ChannelId, ModeId);   
        }


    }

    const handleModeChange = value => {
        handleUpdateData(0, { selectedModeValue: value });
        setSelectedModeValue(value);

        ClearData();

        let ReconID = 0;
        if (selectedReconType === undefined || selectedReconType === null) {
            ReconID = 0;
        }
        else {
            ReconID = selectedReconType.value;
        }

        let ChannelId = 0;
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }

        let ModeId = 0;
        if (value === undefined || value === null) {
            ModeId = 0;
        }
        else {
            ModeId = value.value;
        }

        if (selectedValue.clientID !== '0') {

            //fillData(selectedValue.clientID, ReconID, ChannelId, ModeId);
        }

    }

    const handleTableChange = (ID, data) => {
        let value = { value: data.value, label: data.label, isCompleted:0 };
        //console.log(data.label);

        if (ID == 1) {
            handleUpdateData(0, { selectedTableValue1: value });
            setselectedTableValue1(value);
        }
        else if (ID == 2) {
            handleUpdateData(0, { selectedTableValue2: value });
            setselectedTableValue2(value);
        }
        else if (ID == 3) {
            handleUpdateData(0, { selectedTableValue3: value });
            setselectedTableValue3(value);
        }
        else if (ID == 4)
        {
            handleUpdateData(0, { selectedTableValue4: value });
            setselectedTableValue4(value);
        }
        ClearData();

        let ReconID = 0;
        if (selectedReconType === undefined || selectedReconType === null) {
            ReconID = 0;
        }
        else {
            ReconID = selectedReconType.value;
        }

        let ChannelId = 0;
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }


    }

    //const handleColumnChange = (ID, data) => {
    //    let value = { value: ID, label: data.label };
    //    console.log(data.label);

    //    switch (ID) {
    //        case 1: return setselectedColumn1(value);

    //        case 2: return setselectedColumn2(value);

    //    }

    //    


    //}
    const colorStyles = {
        option: (styles, { data }) => {
            let id = 0;
            if (data.value != null)
                id = data.value;
            let filteredAlias = aliasColumnsList.filter((o, i) => (o.columnID == id));
            //if (filteredAlias[0].columnValue != null)
            return {
                ...styles,
                backgroundColor: filteredAlias[0].columnValue ? "#8ec77b" : "#fff"
            };
        }
    };

    const colorStylesTables = {
        option: (styles, { data }) => {
            let id = 0;
            if (data.value != null)
                id = data.value;
            let filteredAlias = optionsConfigTablesList.filter((o, i) => (o.value == id));
            //if (filteredAlias[0].columnValue != null)
            return {
                ...styles,
                backgroundColor: filteredAlias[0].isCompleted==1  ? "#8ec77b" : "#fff"
            };
        }
    };

    const handleAliasColumnChange = (id, value) => {

        //setColumnText(value);
        handleUpdateData(0, { columnText: [...state.columnText, { [id]: value }] });
        setColumnText({ ...columnText, [id]: value });
        if (id == "Where") {
            handleUpdateData(0, { whereList: [...state.whereList, { [id]: value }] });
            setwhereList((whereList) => [...whereList, { [id]: value }]);
        }
        else {
            handleUpdateData(0, { columnValuesList: [...state.columnValuesList, { [id]: value }] });
            setColumnValuesList((columnValuesList) => [...columnValuesList, { [id]: value }]);
        }


    }
    useEffect(() => {
        if (optionsColumnsList.length > 0 && optionsOperationList.length > 0 && optionsParamList.length > 0) {

            //console.log("All Values");
            //console.log(OptionsColumnsList);
            //console.log(OptionsOperationList);
            //console.log(OptionsParamList);
            let arr = optionsColumnsList.map((item, index) => {

                {

                    //return { value: index, label: item.columnName };
                    return item.columnName;
                }
            });
            let CommandList = arr;

            arr = optionsOperationList.map((item, index) => {

                {

                    //return { value: index, label: item.value };
                    return item.value;
                }
            });
            CommandList.push.apply(CommandList, arr);

            arr = optionsParamList.map((item, index) => {

                {

                    //return { value: index, label: item.value };
                    return item.value;
                }
            });
            CommandList.push.apply(CommandList, arr);

            console.log(CommandList);
            handleUpdateData(0, { optionsCommandsList: CommandList });
            setOptionsCommandsList(CommandList);
            //console.log("All Values END");
        }

    }, [optionsParamList, optionsOperationList, optionsColumnsList])


    useEffect(() => {

        let Joined = columnValuesList.map(e => e.ColumnName).join(' ');
        handleUpdateData(0, { selectedAliasValue: Joined });
        setselectedAliasValue(Joined);
        //console.log(Joined);

    }, [columnValuesList])

    useEffect(() => {

        let Joined = whereList.map(e => e.Where).join(' ');
        setselectedWhereValue(Joined);
        handleUpdateData(0, { selectedWhereValue: Joined});
        //console.log(Joined);

    }, [whereList])

    useEffect(() => {

       
        //console.log(tempTable);
        if (tempTable.length > 0)
        {
        setoptionsConfigTablesList(
            optionsConfigTablesList.map((item) => {
                if (item.label === selectedConfigTable.label) {
                    item.isCompleted = 1;
                    return item;
                    //console.log({ ...item, columnValue });
                    //return { ...item, columnValue };
                } else {
                    return item;
                }
            })
            
        )
        }

    }, [tempTable])

    const handleWhereQueryChange = (id, value) => {
        //console.log(value);
        let LastElement = whereList.length - 1;
        handleUpdateData(0, {
            whereList: state.whereList.filter((o, i) => (i != LastElement))
        });
        setwhereList(
            (whereList) => (
                whereList.filter((o, i) => (i != LastElement)))
        );


    }
    const handleQueryChange = (id, value) => {
        //console.log(value);
        let LastElement = columnValuesList.length - 1;
        handleUpdateData(0, {
            columnValuesList: state.columnValuesList.filter((o, i) => (i != LastElement))
        });
        setColumnValuesList(
            (columnValuesList) => (
                columnValuesList.filter((o, i) => (i != LastElement)))
        );


    }

    const handleWhereChange = (id, value) => {

        //console.log(inputWhereTextValue);
        if (id == "TextValue") {
            if (value.key == 'Enter') {
                handleUpdateData(0, { "inputWhereTextValue": inputWhereTextValue });
                handleAliasColumnChange("Where", "'" + inputWhereTextValue + "'");
            }
            else {

            }

        }
        else if (id == "Query") {
            if (value.key == 'Backspace') {

                handleWhereQueryChange("Query", "Backspace");
            }
        }
        //if (id == "ColumnName" || id == "AliasColumn") 
        else {
            //console.log(value.label);
            if (id != "AliasColumn")
                handleAliasColumnChange("Where", value.label);
            else {
                //console.log("ResetColumnValue");
                //console.log(selectedWhereValue);
                handleUpdateData(0, { whereList: [] });
                setwhereList([]);
                handleUpdateData(0, { inputTextValue: null });
                setInputTextValue(null);
                handleUpdateData(0, { inputWhereTextValue: null });
                setInputWhereTextValue(null);
            }
            handleUpdateData(0, { selectedColumns: { ...state.selectedColumns, [id]: value } });
            setselectedColumns({ ...selectedColumns, [id]: value });

        }

    }

    const handleColumnChange = (id, value) => {

        //console.log(InputTextValue);
        if (id == "TextValue") {
            if (value.key == 'Enter') {
                handleUpdateData(0, { "InputTextValue": inputTextValue });
                handleAliasColumnChange("ColumnName", "'" + inputTextValue + "'");
            }
            else {

            }

        }
        else if (id == "Query") {
            if (value.key == 'Backspace') {

                handleQueryChange("Query", "Backspace");
            }
        }
        else if (id == "Parameters") {
            if (value.key == 'Backspace') {

                handleQueryChange("Query", "Backspace");
            }
        }
        //if (id == "ColumnName" || id == "AliasColumn") 
        else {
            //console.log(value.label);
            if (id != "AliasColumn")
                if (id == "Where") {
                    handleAliasColumnChange("Where", value.label);
                }
                else {
                    handleAliasColumnChange("ColumnName", value.label);
                }
            else {
                //console.log("ResetColumnValue");
                //console.log(selectedAliasValue);
                handleUpdateData(0, { columnValuesList: [] });
                setColumnValuesList([]);
                handleUpdateData(0, { inputTextValue: null });
                setInputTextValue(null);
                handleUpdateData(0, { inputWhereTextValue: null });
                setInputWhereTextValue(null);

            }
            handleUpdateData(0, { selectedColumns: { ...state.selectedColumns, [id]: value } });
            setselectedColumns({ ...selectedColumns, [id]: value });

        }
        //else if (id == "TextValue")
        //{
        //    if (value.key == 'Enter')
        //    {

        //        handleAliasColumnChange("ColumnName", InputTextValue);
        //    }
        //    else
        //    {

        //    }

        //}

    }

    useEffect(() => {


        console.log(formData);
        if (formData.length>0) {
            setIsLoading(true);

            MaximusAxios.post('api/ReconConfig/AddRawTableFields', formData, {  mode: 'cors' })
                .then(function (response) {
                    setIsLoading(false);
                    if (response.data != null || response.data.length > 0) {
                        let myObject = response.data;
                        let { QueryString, DataTable } = JSON.parse(myObject);
                        handleUpdateData(0, { tempQ: QueryString });
                        setTempQ(QueryString);
                        handleUpdateData(0, { tempTable: DataTable});
                        setTempTable(DataTable);
                        console.log(response.data);
                        //setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: response.data });
                    }
                    else
                    {
                        setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'Error occurred while processing your request' });
                    }
                })
                .catch(function (error) {
                    if (error.response) {
                        console.log(error.response.data);
                    }
                    setIsLoading(false);
                });
            //handleUpdateData(0, { formData: [] });
            //setFormData([]);
        }

    }, [formData])

    const btnColumnSubmitClick = (Parameter, value) => {
        let selectedTableID = selectedConfigTable.value;
        let selectedTableName = selectedConfigTable.label;
        let ReconID = 0
        let ReversalFlag = 0;
        let ReversalCode = ""
        if (selectedReconType === undefined || selectedReconType === null) {
            ReconID = 0;
        }
        else {
            ReconID = selectedReconType.value;
        }
        let Clientid = 0;

        if (selectedValue.clientID === undefined || selectedValue.clientID === null) {
            Clientid = 0;
        }
        else {
            Clientid = selectedValue.clientID;
        }
        let ChannelId = 0;

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }
        ReconID = ReconID.toString();
        ChannelId = ChannelId.toString();
        let ModeId = 0;

        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }
        console.log("aliasColumnsList");
        console.log(aliasColumnsList);

        if (Parameter == "Where") {

            let id = selectedColumns.Where.value;
            ReversalFlag = $('#ReversalCheck').is(":checked") == true ? '1' : '0';
            let arr = aliasColumnsList.map((item) => {

                {

                    return { ClientID: Clientid, ChannelID: ChannelId, ModeID: ModeId, ReconType: ReconID, TableNo: selectedTableID.toString(), TableName: selectedTableName, ColumnID: item.columnID.toString(), AliasColumn: item.aliasColumn, ColumnValue: item.columnValue, Reversal: '', ReversalCode: '' };
                }
            });

            let arr2 = state.aliasColumnsList.map((item) => {

                {

                    return { ClientID: Clientid, ChannelID: ChannelId, ModeID: ModeId, ReconType: ReconID, TableNo: selectedTableID.toString(), TableName: selectedTableName, ColumnID: item.columnID.toString(), AliasColumn: item.aliasColumn, ColumnValue: item.columnValue, Reversal: '', ReversalCode: '' };
                }
            });

            console.log({ ClientID: Clientid, ChannelID: ChannelId, ModeID: ModeId, ReconType: ReconID, TableNo: selectedTableID.toString(), TableName: selectedTableName, ColumnID: id.toString(), AliasColumn: "Where", ColumnValue: selectedWhereValue });
            //console.log({ ClientID: Clientid, ChannelID: ChannelId, ModeID: ModeId, ReconType: ReconID, TableNo: selectedTableID, columnID: id, aliasColumn: "Where", columnValue: selectedWhereValue });
            if (selectedWhereValue != null)
            { 
                handleUpdateData(0, { formData: [...arr2, { ClientID: Clientid, ChannelID: ChannelId, ModeID: ModeId, ReconType: ReconID, TableNo: selectedTableID.toString(), TableName: selectedTableName, ColumnID: id.toString(), AliasColumn: "Where", ColumnValue: selectedWhereValue, Reversal: ReversalFlag, ReversalCode: ReversalCode }] });
                setFormData([...arr, { ClientID: Clientid, ChannelID: ChannelId, ModeID: ModeId, ReconType: ReconID, TableNo: selectedTableID.toString(), TableName: selectedTableName, ColumnID: id.toString(), AliasColumn: "Where", ColumnValue: selectedWhereValue, Reversal: ReversalFlag, ReversalCode: ReversalCode }]);

            }
            //setFormData([...FormData, { ClientID: Clientid, ChannelID: ChannelId, ModeID: ModeId, ReconType: ReconID, TableNo: selectedTableID, columnID: id, aliasColumn: "Where", columnValue: selectedWhereValue }]);
        }
        else {

            let id = selectedColumns.AliasColumn.value;
            let columnValue = selectedAliasValue;
            if (selectedAliasValue != null) {
                handleUpdateData(0, {
                    formData:
                        state.aliasColumnsList.map((item) => {
                            if (item.columnID === id) {
                                item.columnValue = columnValue;
                                return item;
                                //console.log({ ...item, columnValue });
                                //return { ...item, columnValue };
                            } else {
                                return item;
                            }
                        })
                
                });
                setAliasColumnsList(
                    aliasColumnsList.map((item) => {
                        if (item.columnID === id) {
                            item.columnValue = columnValue;
                            return item;
                            //console.log({ ...item, columnValue });
                            //return { ...item, columnValue };
                        } else {
                            return item;
                        }
                    })
                );


            }
        }
        //console.log(aliasColumnsList);
        //console.log(selectedColumns);
    }

    const deleteAliasCoumn = (index) => {
        if (aliasColumnsList !== null && aliasColumnsList !== undefined) {
            let id = selectedColumns.AliasColumn.value;
            let columnValue = selectedAliasValue;
            if (selectedAliasValue != null) {
                handleUpdateData(0, {
                    formData:
                        state.aliasColumnsList.map((item) => {
                            if (item.columnID === id) {
                                item.columnValue = "";
                                return item;
                                //console.log({ ...item, columnValue });
                                //return { ...item, columnValue };
                            } else {
                                return item;
                            }
                        })

                });
                setAliasColumnsList(
                    aliasColumnsList.map((item) => {
                        if (item.columnID === id) {
                            item.columnValue = "";
                            return item;
                            //console.log({ ...item, columnValue });
                            //return { ...item, columnValue };
                        } else {
                            return item;
                        }
                    })
                );


            }
        }
    }


    const btnSubmitClick = () => {

        try {

            let alertMessages = "";

            if (selectedValue === null || selectedValue.clientID === 0) {
                alertMessages += "Please select client. \n";
            }

            if (selectedReconType === undefined || selectedReconType === null) {
                alertMessages += "Please select ReconType. \n";
            }

            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                alertMessages += "Please select Channel. \n";
            }

            if (selectedModeValue === undefined || selectedModeValue === null) {
                alertMessages += "Please select mode Type. \n";
            }

            if (alertMessages.length > 0) {
                setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                return false;
            }

            let ReconID = 0;

            if (selectedReconType === undefined || selectedReconType === null) {
                ReconID = 0;
            }
            else {
                ReconID = selectedReconType.value;
            }

            let ChannelId = 0;

            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                ChannelId = 0;
            }
            else {
                ChannelId = selectedChannelValue.value;
            }

            let ModeId = 0;

            if (selectedModeValue === undefined || selectedModeValue === null) {
                ModeId = 0;
            }
            else {
                ModeId = selectedModeValue.value;
            }

            let revEntryLeg = 0;
            if (ReversalEntry === undefined || ReversalEntry === null) {
                revEntryLeg = 0;
            }
            else {
                revEntryLeg = ReversalEntry.value;
            }

            let TxnAmountIsDecimal = 0;
            if (TxnAmount === undefined || TxnAmount === null) {
                TxnAmountIsDecimal = 0;
            }
            else {
                TxnAmountIsDecimal = TxnAmount.value;
            }

            const allHaveMatchingAge = optionsConfigTablesList.every(item => item.isCompleted === 1);

            
            if (allHaveMatchingAge) {
                handleUpdateData(0, { currentStage: state.currentStage+1});
                SetcurrentStage(currentStage + 1)
            }
            else
            {
            setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'Please fill details for all tables' });
            }

        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }
    };




    return (
        <div className="configLeft identificationContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Dynamic Reconciliation Configuration
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Configuration</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Dynamic Reconciliation Config</p>
                </div>
            </div>

            {/* Top Content */}
            <div className="accordion" id="unmatchedFilters">
                <div className="accordion-item">
                    <div
                        className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                        id="unmatchedFiltersHeading"
                    >
                        <h6 className="fontWeight-600 colorBlack">Filters</h6>
                        <button
                            className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#unmatchedFiltersCollapse"
                            aria-expanded="true"
                            aria-controls="unmatchedFiltersCollapse"
                        >
                            <span className="icon-Hide"></span>
                            <span className="ms-1 fontSize12-m colorBlack">
                                Show / Hide
                            </span>
                        </button>
                    </div>
                    <div
                        id="unmatchedFiltersCollapse"
                        className="accordion-collapse collapse show"
                        aria-labelledby="unmatchedFiltersHeading"
                        data-bs-parent="#unmatchedFilters"
                    >
                        <div className="accordion-body">
                            <div className="hrGreyLine"></div>
                            <div className="configSelectBoxTop row">
                                <div className="clientNameSelect col">
                                    <label htmlFor="clientName">Client Name</label>
                                    <span className="text-danger font-size13">*</span>
                                    <AsyncSelect
                                        cacheOptions
                                        defaultOptions
                                        value={selectedValue}
                                        getOptionLabel={e => e.clientName}
                                        getOptionValue={e => e.clientID}
                                        loadOptions={fetchClientData}
                                        onInputChange={handleInputChange}
                                        onChange={handleClientChange}
                                        id="ddlClient"
                                    />
                                </div>

                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlReconType">ReconType</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlReconType"
                                        value={selectedReconType}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsReconType.map(x => (
                                            {
                                                value: x.id,
                                                label: x.reconType
                                            }
                                        ))}
                                        onChange={handleReconTypeChange}
                                    />
                                </div>

                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlChannel">Channel Type</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlChannel"
                                        value={selectedChannelValue}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsChannelType.map(x => (
                                            {
                                                value: x.channelID,
                                                label: x.channelName
                                            }
                                        ))}
                                        onChange={handleChannelChange}
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlMode">Mode Type</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlMode"
                                        value={selectedModeValue}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsModeType.map(x => (
                                            {
                                                value: x.modeID,
                                                label: x.transactionMode
                                            }
                                        ))}
                                        onChange={handleModeChange}
                                    />
                                </div>
                            </div>
                            <div className="configSelectBoxTop row">

                            </div>
                            {
                                selectedTablesCount >= 2 &&
                                <div>
                                    <h6 className="fontWeight-600 colorBlack ReconTables">Raw Data Tables</h6>

                                    <div className="hrGreyLine"></div>
                                </div>
                            }

                            <div className="configSelectBoxTop row">
                                {
                                    selectedTablesCount >= 1 &&

                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Table 1</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedTableValue1}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTablesList.map(x => (
                                                {
                                                    value: x.tableID,
                                                    label: x.tableName
                                                }
                                            ))}
                                            onChange={(value) => handleTableChange(1, value)}
                                        />
                                    </div>
                                }
                                {
                                    selectedTablesCount >= 2 &&
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Table 2</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedTableValue2}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTablesList.map(x => (
                                                {
                                                    value: x.tableID,
                                                    label: x.tableName
                                                }
                                            ))}
                                            onChange={(value) => handleTableChange(2, value)}
                                        />
                                    </div>
                                }
                                {
                                    selectedTablesCount >= 3 &&
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Table 3</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedTableValue3}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTablesList.map(x => (
                                                {
                                                    value: x.tableID,
                                                    label: x.tableName
                                                }
                                            ))}
                                            onChange={(value) => handleTableChange(3, value)}
                                        />
                                    </div>
                                }
                                {
                                    selectedTablesCount >= 4 &&
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Table 4</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedTableValue4}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTablesList.map(x => (
                                                {
                                                    value: x.tableID,
                                                    label: x.tableName
                                                }
                                            ))}
                                            onChange={(value) => handleTableChange(4, value)}
                                        />
                                    </div>
                                }

                            </div>

                            {
                                selectedTablesCount >= 2 &&
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <button
                                            type="button"
                                            className="btnPrimaryOutline"
                                            onClick={(e) => onProceed(e)}
                                        >Proceed</button>
                                    </div>
                                </div>
                            }
                        </div>
                    </div>
                </div>
            </div>
            {proceed &&
                <div className="BottomPanel">
                    {/* Bottom Content */}
                    {/* ProgressBar 
                     <div className="configLeftBottom"><label>Recon Configuration:</label> <label><b>{FormatNo}</b></label>
                            <input type="hidden" id="hdnformatno" name="hdnformatno" value="0" />
                            <input type="hidden" id="hdnfieldid" name="hdnfieldid" value="0" />
                        </div>
                     */}
                    <div>
                        
                    <div className="progress-stages">
                        <StageTracker TotalStages={selectedReconType.value || 4} currentStage={selectedtableNo || 0} />
                        </div>
                    </div>
                    {/* ProgressBar */}
                    <div id="MiddleSection">
                        {/* TempTable */}
                        {
                            currentStage == 0 &&

                            <div id='TempTable' className="configLeftBottom">

                                <div className="tableBorderBox">
                                    <div className="configSelectBoxTop">


                                        <div className="clientNameSelect col">
                                            <label htmlFor="ConfigTable">Table Name</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlTable"
                                                value={selectedConfigTable}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsConfigTablesList.map(x => (
                                                    {
                                                        value: x.value,
                                                        label: x.label
                                                    }
                                                ))}
                                                onChange={handleOptionsConfigTable}
                                                styles={colorStylesTables}
                                            />
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="ddlVendor">Vendor</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlVendor"
                                                value={selectedVendorValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsVendor.map(x => (
                                                    {
                                                        value: x.vendorID,
                                                        label: x.vendorName
                                                    }
                                                ))}
                                                onChange={handleVendorChange}
                                            />
                                        </div>
                                        <div className="PageWhiteBox">
                                            <p className="fontSize14 fontWeight-500 letterSpacing-2 mb-1">
                                                Select File
                                                <span className="text-danger font-size13">*</span>

                                            </p>
                                            <div className="d-flex align-items-center">
                                                <div className="d-flex align-items-center">
                                                    <div className="lightBlueBox text-center">
                                                        <div>
                                                            <p className="fontSize14 fontWeight-500 colorPrimaryDefault browseFileText">Browse File</p>
                                                            <FileUploader
                                                                handleChange={handleuploadFile}
                                                                name="file"
                                                                types={fileTypes}
                                                        
                                                            />
                                                            <p className="fontSize14 dropFileColor uploadFileText">{importFile ? "File name: " + fileName : ""}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="SubmitButton">
                                                    <div className="text-center BtnBox">
                                                        <button className="btnPrimary ms-2" onClick={onUpload} > Upload</button>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                    {
                                        isTextBox ?
                                            <div className="TextBoxView">   
                                                {/*}
                                                <pre>
                                                    {txtBoxData}
                                                </pre>
                                                */}
                                                <TextSelectionComponent Tabledata={aliasColumnsList || []} UpdateFn={handleAliasColumnsList} headerText={headerText} InputText={txtBoxData} />
                                            </div>
                                            :
                                    <div className="TableView">
                                    {
                                        //UploadedTable &&
                                        <>
                                            
                                            <div className="table-responsive tableContentBox " >
                                                <Table data={UploadedTable} UpdateFn={TableUpdateFn} />
                                            </div>
                                            <div className="SubmitButton">
                                                <div className="text-center BtnBox">
                                                    <button className="btnPrimary ms-2" onClick={onsubmit} > Submit</button>
                                                </div>
                                                </div>
                                           
                                        </>
                                    }
                                    </div>
                                    }


                                    </div>
                                    {/*----GRID-------*/}
                                    {selectedConfigTable != null &&
                                        <div className="tableBorderBox mt-2 pt-3">                                       

                                            <StyledTable Tabledata={aliasColumnsList || []} UpdateFn={handleAliasColumnsList} Toggle={toggleGrid}/>

                                        </div>
                                }
                                {
                                    <div>
                                    <div className="button-grid">
                                        <button type="button" className="MatchColumns" onClick={() => handleMatchArrays()} >
                                            <img src={editRow} alt="Add Matching Columns" title="Edit" />
                                            <span>Auto Add</span>
                                        </button>
                                        <button type="button" className="MatchColumns" onClick={() => setShowModal(!isShowModal)} >
                                            <img src={editRow} alt="Add Status Column" title="Status" />
                                            <span>Add Status</span>
                                        </button>

                                    </div>
                                        <div className="SubmitButton">
                                            <div className="text-center BtnBox">
                                                <button className="btnPrimary ms-2" onClick={SubmitFileConfig} > Submit</button>
                                            </div>
                                        </div>
                                    </div>

                                }
                                {/*

                                    <div className="configSelectBoxTop row">
                                        <div className="clientNameSelect col">
                                            <label htmlFor="Reconcolumn">Alias Column</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlCardNumber"
                                                value={selectedColumns.AliasColumn || { value: 0, label: 'select' }}
                                                classNamePrefix="reactSelectBox"
                                                options={aliasColumnsList.map(x => (
                                                    {
                                                        value: x.columnID,
                                                        label: x.aliasColumn
                                                    }
                                                ))}
                                                onChange={(value) => handleColumnChange("AliasColumn", value)}
                                                styles={colorStyles}
                                            />
                                        </div>
                                        <div className="button-grid">
                                            <button type="button" className="MatchColumns" onClick={() => handleMatchArrays()} >
                                                <img src={editRow} alt="Add Matching Columns" title="Edit" />
                                                <span>Auto Add</span>
                                            </button>
                                            <button type="button" className="MatchColumns" onClick={() => setShowModal(!isShowModal)} >
                                                <img src={editRow} alt="Add Status Column" title="Status" />
                                                <span>Add Status</span>
                                            </button>
                                            
                                        </div>
                                        <div className="row">
                                            <div className="clientNameSelect col">
                                                <label htmlFor="ColumnVal">Text Value</label>
                                            <input
                                                
                                                    type="text"
                                                    name="ColumnValname"
                                                    id="ColVal"
                                                    placeholder="Enter Text Value"
                                                    className="inputTextBox"
                                                    onChange={(e) => setInputTextValue(e.target.value)}
                                                    onKeyDown={(value) => handleColumnChange("TextValue", value)}
                                                />
                                            </div>
                                            <div className="clientNameSelect col-9">
                                            <AutocompleteTextBox  
                                                ClassN={null}
                                                Enableheader={true}
                                                EnableError={true}
                                                    suggestions={optionsCommandsList}
                                                    setCommand={(value) => setselectedAliasValue(value)}
                                                    columnText={columnText.ColumnName}
                                                />
                                                
                                            </div>
                                        </div>
                                        

                                    </div>
                                    <div className="configSelectBoxTop row" >                                        
                                        <div className="configSelectBoxTop row">
                                            <div className="clientNameSelect col align-items-center">
                                                <button className="bg-success rounded-pill mt-4"
                                                    onClick={(value) => btnColumnSubmitClick("Columns", value)}
                                                >
                                                    <svg
                                                        width="24"
                                                        height="24"
                                                        viewBox="0 0 64 64"
                                                        fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <circle cx="32" cy="32" r="28" fill="#109D49" />
                                                        <path fillRule="evenodd" clipRule="evenodd" d="M45.7678 23.7322C46.7441 24.7085 46.7441 26.2915 45.7678 27.2678L30.2678 42.7678C29.2915 43.7441 27.7085 43.7441 26.7322 42.7678L19.2322 35.2678C18.2559 34.2915 18.2559 32.7085 19.2322 31.7322C20.2085 30.7559 21.7915 30.7559 22.7678 31.7322L28.5 37.4645L42.2322 23.7322C43.2085 22.7559 44.7915 22.7559 45.7678 23.7322Z" fill="white" />
                                                    </svg>
                                                    <span className="ms-1 p-1 fontSize12-m text-white">
                                                        Submit Column
                                </span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="Spacing-margin">
                                        <div>
                                            <h6 className="fontWeight-600 colorBlack ReconTables">Data Filters</h6>

                                            <div className="hrGreyLine"></div>
                                        </div>
                                        <div className="row">
                                            <div className="clientNameSelect col mt-3">
                                                <label htmlFor="ColumnVal">Text Value</label>
                                                <input
                                                    type="text"
                                                    name="ColumnValname"
                                                    id="ColVal"
                                                    placeholder="Enter Text Value"
                                                className="inputTextBox"
                                                    //onChange={(e) => { handleUpdateData(0, { inputWhereTextValue: e.target.value });}}
                                                    onChange={(e) => setInputWhereTextValue(e.target.value)}
                                                    onKeyDown={(value) => handleWhereChange("TextValue", value)}
                                                />
                                            </div>
                                            <div className="clientNameSelect col-9">
                                            <AutocompleteTextBox
                                                ClassN={null}
                                                    header={true}
                                                    EnableError={true}
                                                    suggestions={optionsCommandsList}
                                                    setCommand={(value) => setselectedWhereValue(value)}
                                                    columnText={columnText.Where}
                                                />
                                            </div>

                                            
                                        </div>
                                        
                                        <div className="configSelectBoxTop row">
                                            <div className="clientNameSelect col">
                                                <label htmlFor="ConfigTable">Column Name</label>
                                                <span className="text-danger font-size13">*</span>
                                                <Select
                                                    id="ddlReferenceNumber"
                                                    value={selectedColumns.Where || { value: 0, label: 'select' }}
                                                    classNamePrefix="reactSelectBox"
                                                    options={optionsColumnsList.map(x => (
                                                        {
                                                            value: x.id,
                                                            label: x.columnName
                                                        }
                                                    ))}
                                                    onChange={(value) => handleWhereChange("Where", value)}
                                                />
                                            </div>

                                            <div className="clientNameSelect col">
                                                <label htmlFor="ConfigTable">Operations</label>
                                                <span className="text-danger font-size13">*</span>
                                                <Select
                                                    id="ddlOperations"
                                                    value={selectedColumns.Operation || { value: 0, label: 'select' }}
                                                    classNamePrefix="reactSelectBox"
                                                    options={optionsOperationList.map(x => (
                                                        {
                                                            value: x.id,
                                                            label: x.value
                                                        }
                                                    ))}
                                                    onChange={(value) => handleWhereChange("Operation", value)}
                                                />
                                            </div>
                                            <div className="clientNameSelect col">
                                                <label htmlFor="ConfigTable">Parameters</label>
                                                <span className="text-danger font-size13">*</span>
                                                <Select
                                                    id="ddlParameters"
                                                    value={selectedColumns.Parameters || { value: 0, label: 'select' }}
                                                    classNamePrefix="reactSelectBox"
                                                    options={optionsParamList.map(x => (
                                                        {
                                                            value: x.id,
                                                            label: x.value
                                                        }
                                                    ))}
                                                    onChange={(value) => handleWhereChange("Parameters", value)}
                                                />
                                            </div>
                                            <div className="clientNameSelect col">
                                                <button
                                                    type="button"
                                                    id="btnPrimaryOutline"

                                                >
                                                    <span className="m-1">Reversal</span>
                                                    <input type="checkbox"
                                                        name="Reversal"
                                                        id="ReversalCheck"
                                                        className="inputCheckBox" />
                                                </button>
                                            </div>
                                            <div className="configSelectBoxTop row">
                                                <div className="clientNameSelect col align-items-center">
                                                    <button className="bg-success rounded-pill mt-4"
                                                        onClick={(value) => btnColumnSubmitClick("Where", value)}
                                                    >
                                                        <svg
                                                            width="24"
                                                            height="24"
                                                            viewBox="0 0 64 64"
                                                            fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <circle cx="32" cy="32" r="28" fill="#109D49" />
                                                            <path fillRule="evenodd" clipRule="evenodd" d="M45.7678 23.7322C46.7441 24.7085 46.7441 26.2915 45.7678 27.2678L30.2678 42.7678C29.2915 43.7441 27.7085 43.7441 26.7322 42.7678L19.2322 35.2678C18.2559 34.2915 18.2559 32.7085 19.2322 31.7322C20.2085 30.7559 21.7915 30.7559 22.7678 31.7322L28.5 37.4645L42.2322 23.7322C43.2085 22.7559 44.7915 22.7559 45.7678 23.7322Z" fill="white" />
                                                        </svg>
                                                        <span className="ms-1 p-1 fontSize12-m text-white">
                                                            Submit Filters
                                </span>
                                                    </button>
                                                </div>
                                            </div>
                                            <div className='row' >
                                                <textarea className='tableBorderBox QueryBox'
                                                    value={tempQ || ''}
                                                />
                                                <div className="table-responsive tableContentBox " >
                                                    <Table data={tempTable || []} />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                */
                                }

                                </div>
                            </div>
                        }
                        {/* TempTable */}
                        {/* Stage2 
                        {
                            currentStage == 1 &&
                            <div id='TempTable' className="row tableBorderBox">
                                <Stage2Box />
                            </div>
                        }
                        */}
                        {/* Stage3
                        {
                            currentStage == 2 &&
                            <div id='TempTable' className="row tableBorderBox">
                                <Stage3Box />
                            </div>
                        }
                         */}
                        {/* Stage4 
                        {
                            currentStage == 3 &&
                        <div id='TempTable' className="row tableBorderBox">
                            <Stage4Box FormData={formData} />
                            </div>
                        }
                        */}

                </div>

                    <div className="mt-50 text-center btnsBtm">
                    {currentStage <= 2 &&
                        <button
                            type="button"
                            className="btnPrimary ms-2"
                            onClick={btnSubmitClick}
                                >
                                    Continue
                        </button>
                    }
                    
                        <button
                                    type="button"
                                    className="btnPrimaryOutline"
                        onClick={() => {
                            handleUpdateData(0, { currentStage: state.currentStage - 1 })
                            SetcurrentStage(currentStage - 1)
                        }}
                                >
                                    Back
                         </button>

                    </div>
                    {/* Bottom Content */}
                </div>
            }
            {
                isShowSeperatorModal &&
                (
                    <Modal
                        show={isShowSeperatorModal}
                        onHide={() => setShowSeperatorModal(!isShowSeperatorModal)}
                        centered
                        size="sm"
                        className="StatusModal"
                    >
                        <Modal.Header closeButton>
                            <Modal.Title className="fontSize16-sm letterSpacing-2">
                                <span>Text File Seperator Configuration</span>
                            </Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <div className="SeperatorControl">
                                <h5>Please Specify Seperator For txt File</h5>
                                <div className="SeperatorConfig">
                                    <select value={separatorOption} onChange={handleSeperatorChange}>
                                            <option value="None">None</option>
                                            <option value="Separator">Separator</option>
                                        </select>
                                    {separatorOption === 'Separator' && (
                                            <input
                                                type="text"
                                                placeholder="Enter Separator"
                                                value={separator}
                                                onChange={(e) => setSeparator(e.target.value)}
                                            />
                                        )}
                                </div>
                            </div>
                        </Modal.Body>
                        <Modal.Footer>
                            <button type="button"
                                className="btnPrimary ms-2"
                                onClick={() => { setShowSeperatorModal(!isShowSeperatorModal) }}
                            >Submit</button>
                        </Modal.Footer>
                    </Modal>
                )

            }
            {isShowModal && (
                <Modal
                    show={isShowModal}
                    onHide={() => setShowModal(!isShowModal)}
                    centered
                    size= "xl"                    
                    className="StatusModal"
                >
                    <Modal.Header closeButton>
                        <Modal.Title className="fontSize16-sm letterSpacing-2">
                             <span>Status Column Properties</span>
                        </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="statusControl">
                            <StatusComponent
                                Table={state.selectedConfigTable}
                                Tabledata={aliasColumnsList}
                                UpdateFn={handleAliasColumnsList}
                            />
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <button type="button" className="btnPrimary ms-2" onClick={() => { btnStatusSubmit() }} >Submit</button>
                    </Modal.Footer>
                </Modal>
            )}
            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default ReconConfigMainWindow;


