import React from 'react';
import SyntaxHighlighter from 'react-syntax-highlighter';
import { darcula, xcode, github } from 'react-syntax-highlighter/dist/esm/styles/hljs';

const SQLTextArea = ({ SQL }) => {
    const sqlString = SQL;

    return (
        sqlString!="" &&
        <SyntaxHighlighter language="sql" style={github}>
            {sqlString}
        </SyntaxHighlighter>
    );
};

export default SQLTextArea;
