import React, { useState, useContext, useEffect } from "react";
import { PageContext } from './PageState';
import Select from "react-select";
import MaximusAxios from "../common/apiURL" ;
import AutocompleteTextBox from "./AutoCommandBar";

const Stage2Box = () => {

    const { state, setState, handleUpdateData, handleAddData } = useContext(PageContext);
    const [query, setQuery] = useState(null);
    const [ Clear, setClear ] = useState(false);
    const [ finalStatus, setFinalStatus ] = useState([]);
    const handleOptionsConfigTable = value => {
        handleUpdateData(0, { st2_selectedTable: value });
        if (state.st2_StatusConditions.length === 0)
            handleAdd(0, value);
    }

    const handleStatusChange = (index, value) => {

        let tblStatusConditions = [...state.st2_StatusConditions];

        tblStatusConditions = tblStatusConditions.map((item, i) => {
            if (index === i) {
                item.status = value;
                return item;
                //console.log({ ...item, columnValue });
                //return { ...item, columnValue };
            } else {
                return item;
            }
        });


        handleUpdateData(0, {
            st2_StatusConditions: tblStatusConditions


        });

    }

    //console.log('st2_StatusConditions');
    //console.log(state.st2_StatusConditions);
    

    const handleCurrentStatus = (index, statusCondition,status) => {
        let tblStatusConditions = [...state.st2_StatusConditions];

        tblStatusConditions = tblStatusConditions.map((item, i) => {
            if (index === i) {
                item.statusCondition = " when "+statusCondition + " then " + status;
                return item;
                //console.log({ ...item, columnValue });
                //return { ...item, columnValue };
            } else {
                return item;
            }
        });


        handleUpdateData(0, {
            st2_StatusConditions: tblStatusConditions


        });
    }

    const handleAdd = (val, Table) => {
        let index = val;
        let { value, label } = Table;

        let TableNo = value;
        let TableName = label;

        handleUpdateData(0, { st2_StatusConditions: [...state.st2_StatusConditions, { Table: { TableNo: TableNo, TableName: TableName },status: { value: 0, label: "All" }, statusCondition: "", IsClear: false }] });

    }
    const handleRemove = (value, Table) => {
        let tblStatusConditions = [...state.st2_StatusConditions];

       

        let id = value;

        if (id != 0 && id != null) {
            handleUpdateData(0, {
                st2_StatusConditions:
                    tblStatusConditions.map((item, i) => {
                        if (i === id && item.Table.TableName === Table.TableName) {
                            item.IsClear = true;
                            return item;
                            //console.log({ ...item, columnValue });
                            //return { ...item, columnValue };
                        } else {
                            return item;
                        }
                    })

            });



        }

        

    }


    const ClearState = (index) => {

        let id = index;

        
        

    }

    const handleStatusSubmit = (index) => {

        let id = state.st2_selectedStatus.status;
        let statusCondition = state.st2_selectedStatus.statusCondition;

        if (index != id) {

        }
        else {

            if (id != 0 && id != null && statusCondition != undefined) {
                handleUpdateData(0, {
                    st2_statusGrid:
                        state.st2_statusGrid.map((item) => {
                            if (item.status === id) {
                                item.statusCondition = statusCondition;
                                return item;
                                //console.log({ ...item, columnValue });
                                //return { ...item, columnValue };
                            } else {
                                return item;
                            }
                        })

                });



            }
        }

    };

    const btnStatusSubmit = () => {
        
        let temp = [...state.st2_StatusConditions];
        let tempFinalStatus = temp.map((status) => {
            return { ClientID: state.selectedValue.clientID, ChannelID: state.selectedChannelValue.value, ModeID: state.selectedModeValue.value, ReconType: state.selectedReconType, Table: status.Table, Status: status.status.label, statusCondition: status.statusCondition }
        });

        let Final = finalStatus.concat(tempFinalStatus);
        setFinalStatus(Final);

        let TablesList = state.st2_optionsConfigTablesList.map((item) => {
            if (item.label === state.st2_selectedTable.label) {
                item.isCompleted = 1;
                return item;
                //console.log({ ...item, columnValue });
                //return { ...item, columnValue };
            } else {
                return item;
            }
        });

        

        handleUpdateData(0, { st2_StatusConditions: [] });

        handleUpdateData(0, { st2_optionsConfigTablesList: TablesList });
    };

    useEffect(() => {

        console.log("Status Table Value Changed");
        console.log(state.st2_statusGrid);
        console.log("FinalStatus Value Changed");
        console.log(state.finalStatus);
    }, [state.st2_statusGrid, state.finalStatus]);
    

    useEffect(() => { 

        let allComplete = state.st2_optionsConfigTablesList.filter((o, i) => (o.isCompleted == 0));
        console.log(allComplete);

        if (allComplete.length === 0)
        {


            MaximusAxios.post('api/ReconConfig/StatusConditions', finalStatus
            )
                .then(response => {
                    if (response.data != null || response.data.length > 0) {
                        let myObject = response.data;
                        let { QueryString } = myObject;
                        //console.log(QueryString);
                        setQuery(QueryString);
                        //setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: response.data });
                    }
                    else {
                        console.log('Error occurred while processing your request');
                    }
                })
                .catch(error => {
                    if (error.response) {
                        console.log(error.response.data);
                    }
                });
        }
    }, [finalStatus]);




    const colorStylesTables = {
        option: (styles, { data }) => {
            let id = 0;
            if (data.value != null)
                id = data.value;
            let filteredAlias = state.st2_optionsConfigTablesList.filter((o, i) => (o.value == id));
            //if (filteredAlias[0].columnValue != null)
            return {
                ...styles,
                backgroundColor: filteredAlias[0].isCompleted == 1 ? "#8ec77b" : "#fff"
            };
        }
    };

    return (
        <div className="Stage-box">
            <div className="stage_container">

                <div class="Stage_Header">
                    <h5 class="text-danger">Status Remarks</h5>

                </div>
                <div className="hrGreyLine"></div>
                {
                    //enabled && className="d-flex flex-row p-5"
                    <div className="col-3">

                        <div className="configSelectBoxTop row">
                            <div className="clientNameSelect col">
                                <div>
                                    <label htmlFor="ConfigTable">Table Name</label>
                                    <span className="text-danger font-size13">*</span>
                                </div>
                                <Select
                                    id="ddlTable"
                                    value={state.st2_selectedTable}
                                    classNamePrefix="reactSelectBox"
                                    options={state.st2_optionsConfigTablesList.map(x => (
                                        {
                                            value: x.value,
                                            label: x.label
                                        }
                                    ))}
                                    onChange={handleOptionsConfigTable}
                                    styles={colorStylesTables}
                                />
                            </div>
                        </div>


                    </div>
                }
                {
                    state.st2_selectedTable.value!==0 &&
                    <div className="tableBorderBox mt-2 pt-3">
                        <div className="table-responsive overflow-suggestions">
                            <div className="tableContentBox " >
                                <table id="gvStatusConf" className="w-100 table table-striped table-hover table-borderless align-middle"  >
                                    <thead>
                                        <tr>
                                            <th colSpan="5" scope="col">Case Statement</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            state.st2_StatusConditions.map((p, index) => {
                                                //if (p.status != "")
                                                {
                                                    return <tr key={index}>
                                                        <td >when</td>
                                                        <td colSpan="2">{
                                                            <AutocompleteTextBox
                                                                header={false}
                                                                EnableError={false}
                                                                suggestions={state.optionsCommandsList}
                                                                setCommand={(value) => { handleCurrentStatus(index, value,p.status.label) }}
                                                                columnText={null}
                                                                isClear={p.IsClear}
                                                            />
                                                        }</td>
                                                        <td >then</td>
                                                        <td >
                                                            <div className="configSelectBoxTop row">
                                                                <div className="clientNameSelect col">
                                                                    {
                                                                    <Select
                                                                            id="ddlTable"
                                                                            //{ value: p.status.value, label: p.status.label }
                                                                            value={p.status}
                                                                        classNamePrefix="reactSelectBox"
                                                                        options={state.st2_statusGrid.map(x => (
                                                                            {
                                                                                value: x.value,
                                                                                label: x.label
                                                                            }
                                                                        ))}
                                                                        onChange={(value) => handleStatusChange(index, value)}
                                                                    />
                                                                    }
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="ButtonGroup">
                                                                <button className="btn btn-light" onClick={() => (handleAdd(index, state.st2_selectedTable))}>Add</button>
                                                                <button className="btn btn-danger" onClick={() => (handleRemove(index, state.st2_selectedTable))}>delete</button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                }
                                            })
                                        }
                                    </tbody>
                                </table>
                            </div>

                        </div>

                    </div>
                }
            </div>
            {
                state.st2_selectedTable.value !== 0 &&
                <div className="d-flex justify-content-end">
                    <button
                        type="button"
                        className="btnPrimaryOutline"
                        onClick={() => { btnStatusSubmit() }}
                    >
                        Submit
                 </button>
                </div>
            }
        </div>
    );
};

export default Stage2Box;
