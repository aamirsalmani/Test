import React, { useState, useEffect } from "react";



const Stage3Box = () => {
    return (
        <div className="Stage-box">

        </div>
  );
};

export default Stage3Box;
