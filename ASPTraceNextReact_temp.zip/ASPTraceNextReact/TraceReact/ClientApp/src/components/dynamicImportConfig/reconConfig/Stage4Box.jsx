import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL" ;
import SQLTextArea from './SQLTextArea'
import DownloadIcon from "../../images/common/cloud-240.svg";
import { Tooltip, OverlayTrigger } from "react-bootstrap";
import DownloadButton from "./DownloadButton";


const Stage4Box = ({ FormData }) => {

    const [allComplete, setAllComplete] = useState(1);
    const [query, setQuery] = useState(null);
    let Data = FormData;
    let ClientID = Data[0].ClientID
    let ChannelID = Data[0].ChannelID
    let ModeID = Data[0].ModeID
    let ReconType = Data[0].ReconType

    const btnGenerate = () => {
        if (allComplete ==1 ) {

            
            MaximusAxios.post('api/ReconConfig/GenerateRecon', {
                ClientID: ClientID,
                ChannelID: ChannelID,
                ModeID: ModeID,
                ReconType: ReconType
            }
                , {  mode: 'cors' })
                .then(response => {
                    if (response.data != null || response.data.length > 0) {
                        let myObject = response.data;
                        let { QueryString } = JSON.parse(myObject);
                        //console.log(QueryString);
                        setQuery(QueryString);
                        //setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: response.data });
                    }
                    else {
                        console.log('Error occurred while processing your request');
                    }
                })
                .catch(error => {
                    if (error.response) {
                        console.log(error.response.data);
                    }
                });
        }
    }
    const renderTooltipBranch = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Download File
    </Tooltip>
    );

    return (
        <div className="Stage-box">

            {
                query &&
                <DownloadButton DataQuery={query || ""} />
            }
            {
                /* 
                 * <div >
                <OverlayTrigger
                    placement="top"
                    delay={{ show: 250, hide: 400 }}
                    overlay={renderTooltipBranch}
                >
                    <Link to="/TemplateFile/BranchMaster.xls" target="_blank" className="DownloadBox" download>
                        <img src={DownloadIcon} alt="DownloadFile" />
                    </Link>
                </OverlayTrigger>
            </div>
                 */
            }

            <div className="tableBorderBox QueryDoc">
                <SQLTextArea SQL={query || ""}/>
            </div>
            {/*
            <textarea className='tableBorderBox QueryDoc'
                value={query || ''}
            />
            */}
            <button
                type="button"
                className="btnPrimaryOutline"
                onClick={() => { btnGenerate() }}
            >
                Generate Recon
                 </button>
        </div>
  );
};

export default Stage4Box;
