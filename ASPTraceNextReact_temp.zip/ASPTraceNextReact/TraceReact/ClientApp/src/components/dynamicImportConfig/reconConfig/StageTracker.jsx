import React from "react";





const StageTracker = ({ TotalStages, currentStage }) => {

    function createNumberArray(count) {
        const result = [];

        for (let i = 1; i <= count; i++) {
            result.push(i);
        }

        return result;
    }

    const stages = createNumberArray(TotalStages);




  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      {stages.map((stage, index) => (
        <React.Fragment key={index}>
          {index !== 0 && (
            <div
              style={{
                width: "50px",
                height: "2px",
                backgroundColor:
                  index <= currentStage ? "green" : "gray",
                marginLeft: "10px",
                marginRight: "10px"
              }}
            />
          )}
          <div
            style={{
              width: "30px",
              height: "30px",
              borderRadius: "50%",
              backgroundColor:
                index <= currentStage ? "green" : "gray",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "white",
              fontWeight: "bold"
            }}
          >
            {index + 1}
          </div>
        </React.Fragment>
      ))}
    </div>
  );
};

export default StageTracker;
