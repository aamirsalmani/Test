import React, { useState, useRef, useEffect, useContext } from 'react';
import { Popover, Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import './StyledTable.css';
import Select from "react-select";
import { PageContext } from './PageState';
import MaximusAxios from "../common/apiURL" ;
import AutocompleteTextBox from "./AutoCommandBar";


const StyledTable = ({ Tabledata, UpdateFn, Toggle }) => {

    const { state, setState, handleUpdateData, handleAddData } = useContext(PageContext);

    {/*
    const Rawdata = [
        {
            id: 1, ColumnName: "ClientID",
            caseStatement: 'ClientID',
            Status: ""
        },
        {
            id: 2, ColumnName: "ChannelID",
            caseStatement: "case when MERCHANTCODE = '6012' THEN 5 ELSE 1 END",
            Status: ""
        },
        {
            id: 3, ColumnName: "ModeID",
            caseStatement: 'ModeID',
            Status: ""
        },
        // Add more sample data here if needed
    ];

    const [data, setData] = useState(Rawdata);
    const [txtPosition, setTxtPosition] = useState([...Tabledata].map((item, index) => ({ ID: item.columnID, startPosition: 0, length: 0 })));
    */}


    const [edit, setEdit] = useState([]);
    const [toggleGrid, setToggleGrid] = useState(false);

    const [sepPosition, setSepPosition] = useState(state.hasSeperatorPosition);

    useEffect(() => {

        if (state.hasSeperatorPosition !== null && state.hasSeperatorPosition !== undefined) {
            setSepPosition(state.hasSeperatorPosition);
        }

    }, [state.hasSeperatorPosition]);

    useEffect(() => {


        if (Toggle === false) {
            setToggleGrid(false);
        }
        else {
            setToggleGrid(true);
            console.log(Tabledata);
            setEdit([...Tabledata].map((item, index) => ({ ID: item.columnID, value: false })));

        }


    }, [Toggle])

    const ChangeDataColumn = (ID, value) => {

        let val = state.optionsColumnsList.filter((item, i) => item.columnName === value.label);

        let Temp = [...Tabledata].map((item) => {
            if (item.columnID === ID) {
                item.dataColumn = val[0].columnName;
                item.dataValue = val[0].dataValue;
                item.position = val[0].position;
                return item;
                //console.log({ ...item, columnValue });
                //return { ...item, columnValue };
            } else {
                return item;
            }
        })

        UpdateFn(Temp);
        //setEdit(!edit);
    };

    const ChangetextPosition = (propType, value, ID) => {

        let val = value.trim() === "" ? "0" : value;

        let Temp = [...Tabledata].map((item) => {
            if (propType === "StartPosition") {
                if (item.columnID === ID) {
                    item.startPosition = val;
                    return item;
                } else {
                    return item;
                }
            }
            else if (propType === "Length") {
                if (item.columnID === ID) {
                    item.txtlength = val;
                    return item;
                } else {
                    return item;
                }
            }
        })

        UpdateFn(Temp);
        //setEdit(!edit);
    };

    const addOrUpdateEdit = (id) => {

        setEdit(
            edit.map((item, index) =>
                item.ID === id ? { ...item, value: !item.value } : item
            )
        );

    };

    const ChangeData = (ID, CaseStatement) => {



        let Temp = [...Tabledata].map((item) => {
            if (item.columnID === ID) {
                item.columnValue = CaseStatement;
                return item;
                //console.log({ ...item, columnValue });
                //return { ...item, columnValue };
            } else {
                return item;
            }
        })

        //console.log(Temp);
        UpdateFn(Temp);
        //setData(Temp);

        addOrUpdateEdit(ID);
    };


    const RowElement = ({ changeData, value }) => {

        const casetextRef = useRef([...Tabledata].map((item, index) => ({ ID: item.columnID, value: "" })));


        let { ID, ColumnName, CaseCondition, Status, DataValue, DataColumn, DataType, textStartPosition, textLength } = value;

        const itemIndex = edit.findIndex((item, index) => item.ID === ID);

        if (edit[itemIndex] === null || edit[itemIndex] === undefined) {
            console.log(itemIndex);
        }

        const handleUpdateClick = (ID) => {
            try {
                //const conditionTextValue = document.getElementById('ConditionText').value;
                //console.log(conditionTextValue);
                let textVal = "";

                const indexToUpdate = casetextRef.current.findIndex(item => item.ID === ID);
                if (indexToUpdate !== -1) {
                    textVal = casetextRef.current[indexToUpdate].value;
                }

                changeData(ID, textVal);
            }
            catch(e)
            {
                console.log('handleUpdateClick');
                console.log(e);

            }

        };
        const handleDeleteClick = (ID) => {
            try {
                const conditionTextValue = "";
                changeData(ID, conditionTextValue);
            }
            catch (e) {
                console.log('handleDeleteClick');
                console.log(e);

            }

        };
        const popover = () => {

            if (CaseCondition !== null && CaseCondition !== undefined) {
                return <Popover id="popover-basic">
                    <Popover.Header as="h3">Comment</Popover.Header>
                    <Popover.Body>
                        {CaseCondition}
                    </Popover.Body>
                </Popover>
            }
            else {
                return <Popover id="popover-basic">
                    <Popover.Header as="h3">No Comment</Popover.Header>
                    <Popover.Body>
                    </Popover.Body>
                </Popover>

            }
        };

        const handleInputCase = (ID, value) => {
            try {
            const indexToUpdate = casetextRef.current.findIndex(item => item.ID === ID);
            if (indexToUpdate !== -1) {
                casetextRef.current[indexToUpdate].value = value;
            }
            }
            catch (e) {
                console.log('handleInputCase');
                console.log(e);

            }

        }

        const textareaStyle = {
            border: 'none', // Set your desired border style and color
            borderRadius: '5px', // Optionally, add border radius for rounded corners
            padding: '8px', // Add some padding for better appearance
            width: '100%',
            boxSizing: 'border-box', // Ensure padding and border are included in the width
            backgroundColor: '#ffffff'
        };

        const [startPosition, setStartPosition] = useState(textStartPosition);
        const [length, setLength] = useState(textLength);

        const handlePositionKeyDown = (event,ID) => {
            let input = event.target.value;

            let keyPress = null;
            if (event.key === undefined) {

            }
            else {
                keyPress = event.key;
            }

            if (keyPress === 'Enter') {
                ChangetextPosition("StartPosition", input, ID);
            }

        }

        const handleLengthKeyDown = (event,ID) => {
            let input = event.target.value;

            let keyPress = null;
            if (event.key === undefined) {

            }
            else {
                keyPress = event.key;
            }

            if (keyPress === 'Enter') {
                ChangetextPosition("Length", input, ID);
            }

        }

        const handleStartPositionChange = (event, ID) => {

            let input = event.target.value;

            if (/^\d*$/.test(input)) {
                setStartPosition(input);

            }

        };

        const handleLengthChange = (event, ID) => {
            const input = event.target.value;
            
            if (/^\d*$/.test(input)) {
                setLength(input);

            }
        };


        return (
            <>
                <tr className="StyledRow">
                    <td className="BoxElement">{ColumnName}</td>
                    <td className="BoxElement"><span >
                        <div className="configSelectBoxTop row">
                            <div className="PositionBoxContainer">
                                {
                                    sepPosition === true ?
                                        <div className="SeperationPosition">
                                            <div className="positionBox">
                                                <label>Start Position</label>
                                                <input
                                                    type="text"
                                                    value={startPosition}
                                                    onChange={(event) => { handleStartPositionChange(event, ID) }}
                                                    onKeyDown={(event) => { handlePositionKeyDown(event, ID) } }
                                                    placeholder="Numeric Value"
                                                />
                                            </div>
                                            <div className="positionBox">
                                                <label>Length</label>
                                                <input
                                                    type="text"
                                                    value={length}
                                                    onChange={(event) => { handleLengthChange(event, ID) }}
                                                    onKeyDown={(event) => { handleLengthKeyDown(event, ID) }}
                                                    placeholder="Numeric Value"
                                                />
                                            </div>
                                        </div>
                                        :
                                        <div className="clientNameSelect">
                                        <Select
                                            id="ddlColumns"
                                            //{ value: p.status.value, label: p.status.label }
                                            value={DataColumn != "" ? { value: DataValue, label: DataColumn } : { value: 0, label: 'select' }}
                                            classNamePrefix="reactSelectBox"
                                            options={state.optionsColumnsList.map(x => (
                                                {
                                                    value: x.dataValue,
                                                    label: x.columnName
                                                }
                                            ))}
                                            onChange={(value) => ChangeDataColumn(ID, value)}
                                            />
                                        </div>
                                }
                            </div>
                        </div>
                    </span></td>
                    <td className="BoxElement" colSpan="2"><span >
                        <span className="d-flex justify-content-center"> {DataValue}</span>
                    </span></td>
                    <td className="BoxElement" colSpan="3"><span >
                        {<span className="CaseCondition">
                            <textarea
                                rows={2}
                                cols={1}
                                value={CaseCondition}
                                placeholder=""
                                disabled
                                style={textareaStyle}
                            />
                        </span>
                        }
                    </span></td>
                    {/*<span className="BoxElement">{Status}</span> */}
                    <td className="BoxElement"><span >
                        <div className="StyledRow_Action">
                            <div className="StyledRow_Button">
                                <input type="button" onClick={() => { addOrUpdateEdit(ID) }} className="StyledRow_Action_Update Button-Green" defaultValue="Edit" />
                            </div>
                            {/*
                                <div className="StyledRow_Button">
                                    <input type="button" onClick={() => { handleDeleteClick(ID) }} className="StyledRow_Action_Update Button-Red" defaultValue="Delete" />
                                </div>

                                    replace with AutocompleteTextBox when textbox needed
                                        <input id="ConditionText" type="text" placeholder="Enter text here" />
                                */}
                        </div>
                    </span></td>
                </tr>
                {
                    edit[itemIndex].value &&

                    <tr>
                        <td colspan="8">
                            <div className="UpdatePanel">
                                <div className="StyledRow_Action">
                                    <div className="StyledRow_TextBox">
                                        <AutocompleteTextBox
                                            ClassN={""}
                                            header={false}
                                            EnableError={false}
                                            suggestions={state.optionsCommandsList}
                                            setCommand={(value) => { handleInputCase(ID, value) }}
                                            columnText={null}
                                            isClear={false}
                                        />

                                    </div>
                                </div>
                                <div className="StyledRow_FinalAction">

                                    <div className="StyledRow_Button">
                                        <input onClick={() => { handleUpdateClick(ID) }}
                                            type="button" className="StyledRow_Action_Update" defaultValue="Update" />
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                }

            </>
        );
    };

    return (
        <>
            {
                Tabledata.length>0 && toggleGrid ?
                    <div className="StyledTable">

                        <table className="w-100">

                            <thead className="TableHeader">
                                <tr>
                                    <th >
                                        <div className="headerElement">Alias Column</div>
                                    </th >
                                    <th >
                                        <div className="headerElement">Data Column</div>
                                    </th >
                                    <th colSpan="2">
                                        <div className="headerElement">Data</div>
                                    </th >
                                    <th colSpan="3">
                                        <div className="headerElement">Case Statement</div>
                                    </th >
                                    <th >
                                        <div className="headerElement">Actions</div>
                                    </th >
                                </tr>
                            </thead>
                            <tbody className="GridData">
                                {
                                    Tabledata.map((item, index) => (


                                        <RowElement
                                            key={item.columnID}
                                            value={
                                                {
                                                    ID: item.columnID,
                                                    ColumnName: item.aliasColumn,
                                                    CaseCondition: item.columnValue,
                                                    Status: '',
                                                    DataValue: item.dataValue,
                                                    DataColumn: item.dataColumn,
                                                    DataType: item.dataType,
                                                    textStartPosition: item.startPosition,
                                                    textLength: item.txtlength
                                                }
                                            }
                                            changeData={ChangeData}
                                        />




                                    ))
                                }
                            </tbody>
                        </table>
                    </div>
                    : <div className="StyledTable">
                        <h6 className="Emptytext">...Please add columns to continue</h6>
                    </div>
            }

        </>
    );

};

export default StyledTable;
