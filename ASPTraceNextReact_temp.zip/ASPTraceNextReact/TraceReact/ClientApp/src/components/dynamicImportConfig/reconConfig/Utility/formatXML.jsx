﻿import React from "react";
import { useSelector } from "react-redux";
import { PageProvider } from '../PageState';



    const formatXML = (dataTable,type) => {
        const xmlHeader = '<?xml version="1.0" encoding="utf-16"?>';
        let xmlContent = '<FileFormat>';

        const sanitizeXMLTagName = (tagName) => {
            // Remove any characters that are not allowed in XML element names
            return tagName.replace(/[^a-zA-Z0-9_]/g, '');
        };

        let hasPosition = type === "Position" ? true:false;

        dataTable.forEach((row, rowIndex) => {
            //xmlContent += '<Row>';
            if (hasPosition === false) {
                for (const columnName in row) {

                    const sanitizedColumnName = sanitizeXMLTagName(columnName);

                    xmlContent += `<${sanitizedColumnName}>${row[columnName]}</${sanitizedColumnName}>`;
                }

            }
            else
            {
                for (const columnName in row) {

                    const sanitizedColumnName = sanitizeXMLTagName(columnName);
                    let { StartPosition, Length } = row[columnName];

                    xmlContent += `<${sanitizedColumnName}><StartPosition>${StartPosition}</StartPosition><Length>${Length}</Length></${sanitizedColumnName}>`;
                }
            }
            
            //xmlContent += '</Row>';
        });

        xmlContent += '</FileFormat>';

        console.log(xmlHeader + xmlContent);
        return xmlHeader + xmlContent;
    };

    



export default formatXML;
