import { useState } from "react";

function matchArrays(firstArray, otherArray) {

    

    // Loop through the first array otherArray[3].columnName
    const newArray = firstArray.map((item) => {
        // Check if the aliasColumn value exists in the other array
        const match = otherArray.find((element) => element.columnName === item.aliasColumn);
        // If there's a match, assign the matching ColumnValue to the aliasColumn
        if (match) {
            return { ...item, columnValue: match.columnName };
        }
        return item;
    });

    return [newArray];
}


export default matchArrays;