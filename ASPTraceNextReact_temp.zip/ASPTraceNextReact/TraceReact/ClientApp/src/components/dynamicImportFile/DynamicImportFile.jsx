import React from "react";
import { useSelector } from "react-redux";
import SidebarMain from "../common/SidebarMain";
import DynamicImportFileMainWindow from "./DynamicImportFileMainWindow";

const DynamicImportFile = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <DynamicImportFileMainWindow />
        </div>
    );
};

export default DynamicImportFile;