import React, { useState } from "react";
import Select from "react-select";
import { Link } from "react-router-dom";
import { FileUploader } from "react-drag-drop-files";
import MaximusAxios from "../common/apiURL";
import AsyncSelect from 'react-select/async';
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { useSelector } from "react-redux";
import axios from 'axios';
import postHeader from "../../pages/login/services/post-header";


const DynamicImportFileMainWindow = () => {

    const onReset = (e) => {
        e.preventDefault();
        setUploadFilesReport([]);
        setSelectedValue(null)
        setselectedFileTypeValue(null);
        setOptionsFileTypeValue([]);
       // window.location.reload(false);
    }

    const currentUser = useSelector((state) => state.authReducer);

    const [selectedValue, setSelectedValue] = useState(null);

    const [selectedFileTypeValue, setselectedFileTypeValue] = useState(null);

    const [optionsFileType, setOptionsFileTypeValue] = useState([]);

    //const Show Loader
    const [isShow, setIsLoading] = useState(false);

    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    // const fileTypes = ["xlsx", "xls", "csv", "txt", "mCCC", "mMTS", "rc", "dat", "mSVS", "mVSM", "mPLH","mPLB","mNSB","pgp","mSYG","RC","mSMC","mRLY","mREC","mGUJ"];


    const [fileTypes, setFileTypes] = useState(["xlsx", "xls", "csv", "txt"]);

    const fetchClientData = (inputValue) => {
        return MaximusAxios.get('api/DynamicImportFile/GetClientOptionList?UserID=' + currentUser.user.username, { mode: 'cors' }).then(result => {

            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    // Drop File
    const [fileName, setFileName] = useState();
    const [importFile, setImportFile] = useState();

    const handleuploadFile = async (files) => {
        //console.log(files);
        setImportFile(files);
        var FileNames = '';
        for (var i = 0; i < files.length; i++) {
            FileNames = FileNames + files[i].name + ", ";
        }
        setFileName(FileNames);
    };


    const handleClientChange = value => {
        setImportFile(null);
        setSelectedValue(value);
        setUploadFilesReport([]);

        if (value.clientID !== '0') {
            setIsLoading(true);
            MaximusAxios.get('/api/DynamicImportFile/GetFileTypeOptionList?ClientId=' + value.clientID, { mode: 'cors' }).then(result => {
                setOptionsFileTypeValue(result.data);
                setselectedFileTypeValue(null);
                setIsLoading(false);
            });

            MaximusAxios.get('/api/Common/GetReactFileTypeList', { mode: 'cors' }).then(result1 => {
                //console.log(result1.data);
                setFileTypes(JSON.parse(result1.data));
            });
        }
        else {
            setOptionsFileTypeValue([]);
            setselectedFileTypeValue(null);
            setFileTypes(["xlsx", "xls", "csv", "txt"]);
        }
    }

    const handleFileTypeChange = value => {
        console.log(value);
        setselectedFileTypeValue(value);
        setUploadFilesReport([]);

        if (value.label === 'EJ_ATM_ALL' && selectedValue.clientID === '71') {
            setFileTypes(["20230622"]);
        }
        else if (value.label === 'EJ_ATM_ALL' && selectedValue.clientID === '56') {
            setFileTypes([]);
        }
        else if (value.label === 'MASTER_MASTER_ALL_MASTER' && selectedValue.clientID === '71') {
            setFileTypes(["2024"]);
        }
        else if (value.label === 'POS_POS_MasterACQUIRERCHBK_MASTER' && selectedValue.clientID === '71') {
            setFileTypes(["1", "2", "3", "4"]);
        }
    }

    const [UploadFilesReport, setUploadFilesReport] = useState([]);

    const onSubmit = () => {

        if (currentUser !== null && currentUser.user !== null) {

            try {

                let alertMessages = "";

                if (selectedValue === null || selectedValue.clientID === "0") {
                    alertMessages += 'Please select Client. \n';
                }

                if (selectedFileTypeValue === null || selectedFileTypeValue.value === "0") {
                    alertMessages += 'Please select File Type. \n';
                }

                if (importFile === null || importFile === undefined) {
                    alertMessages += 'Please select File. \n';
                }
                else if (importFile.length === 0) {
                    alertMessages += 'Please select File. \n';
                }

                if (alertMessages.length > 0) {
                    setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                    return false;
                }

                var arr = [];
                for (var i = 0; i < importFile.length; i++) {
                    arr.push(importFile[i]);
                }

                if (arr.length > 0) {

                    setIsLoading(true);

                    const posts = arr.map(async function (file) {

                        const data = new FormData();
                        data.append("ClientID", selectedValue.clientID);
                        data.append("ImportFile", file);
                        data.append("FileFormatId", selectedFileTypeValue.value);
                        data.append("FileFormatText", selectedFileTypeValue.label);
                        data.append("UserName", currentUser.user.username);

                        //console.log(data);

                        return await axios.post("api/DynamicImportFile", data, { headers: postHeader(), mode: 'cors' })
                            .then((res) => {
                                return res.data.status;
                            }, error => {
                                console.log(error);
                                return error;
                            });
                    });

                    let z = 1, arrayCount = importFile.length;
                    if (posts !== null && posts.length > 0) {

                        posts.map(function (item) {

                            item.then(value => {


                                const myArray = value.split("<br/>");

                                var arr = { "ID": z, "ClientName": selectedValue.clientName, "FileType": selectedFileTypeValue.label, "FileName": myArray[0], "FileStatus": myArray[1], "Insert": myArray[2], "Failed": myArray[3] }

                                UploadFilesReport.push(arr);

                                if (arrayCount === z) {
                                    setIsLoading(false);
                                    setImportFile(null);
                                    setFileName('');
                                    setselectedFileTypeValue(null);
                                }

                                z++;

                            }).catch(err => {
                                console.log(err);

                                if (arrayCount === z) {
                                    setIsLoading(false);
                                    setImportFile(null);
                                    setFileName('');

                                    setselectedFileTypeValue(null);
                                }

                                z++;

                            });


                        });
                    }
                }
            }
            catch (ex) {
                console.log(ex);
                setIsLoading(false);
            }
        }
        else {
            alert('Session Timeout');
        }
    };



    return (
        <div>
            <div className="PageContainer">
                <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                    <h5 className="fontWeight-600 fileConfigHead colorBlack">
                        Dynamic Import File
                    </h5>

                    {/* BreadCrumb */}
                    <div className="d-flex align-items-center">
                        <Link to="/">
                            <p className="fontSize12 colorPrimaryDefault">Home</p>
                        </Link>
                        <span>
                            <svg
                                width="8"
                                height="100%"
                                viewBox="0 0 10 16"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                className="mx-1"
                            >
                                <path
                                    d="M3 4L7 8L3 12"
                                    stroke="black"
                                    strokeWidth="1.5"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    className="breadcrumbIcon"
                                />
                            </svg>
                        </span>
                        <p className="fontSize12 colorPrimaryDefault">Import Logs</p>
                        <span>
                            <svg
                                width="8"
                                height="100%"
                                viewBox="0 0 10 16"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                className="mx-1"
                            >
                                <path
                                    d="M3 4L7 8L3 12"
                                    stroke="black"
                                    strokeWidth="1.5"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    className="breadcrumbIcon"
                                />
                            </svg>
                        </span>
                        <p className="fontSize12">Import File</p>
                    </div>
                </div>

                <div className="tableBorderBox PageWhiteBox PageWhiteBox2 d-flex justify-content-center w-100">
                    <div className="PageSmallBox">
                        <div className="clientNameSelect">
                            <label htmlFor="ddlClient">Client Name</label>
                            <span className="text-danger font-size13">*</span>
                            <AsyncSelect
                                cacheOptions
                                defaultOptions
                                value={selectedValue}
                                getOptionLabel={e => e.clientName}
                                getOptionValue={e => e.clientID}
                                loadOptions={fetchClientData}
                                onChange={handleClientChange}
                                id="ddlClient"
                            />

                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="ddlFileType">File Type</label>
                            <span className="text-danger font-size13">*</span>
                            <Select
                                id="ddlFileType"
                                value={selectedFileTypeValue}
                                classNamePrefix="reactSelectBox"
                                options={optionsFileType.map(x => (
                                    {
                                        value: x.fileTypeID,
                                        label: x.fileTypeName
                                    }
                                ))}
                                onChange={handleFileTypeChange}
                            />
                        </div>

                        <div className="UploadFileBox">
                            <p className="fontSize14 fontWeight-500 letterSpacing-2 mb-1">
                                Select File
                                <span className="text-danger font-size13">*</span>

                            </p>
                            <div className="d-flex align-items-center" >
                                <div className="lightBlueBox text-center">
                                    <div>
                                        <p className="fontSize14 fontWeight-500 colorPrimaryDefault browseFileText">Browse File</p>
                                        {(fileTypes !== null && fileTypes.length > 0) ?
                                            (<FileUploader
                                                handleChange={handleuploadFile}
                                                name="importFileESAF"
                                                types={fileTypes}
                                                multiple
                                            />
                                            ) : <FileUploader
                                                handleChange={handleuploadFile}
                                                name="importFileESAF"
                                                multiple
                                            />}
                                        <p className="fontSize14 dropFileColor uploadFileText">{importFile ? "File name: " + fileName : ""}</p>
                                    </div>
                                </div>
                            </div>
                        </div>



                        {/* Buttons */}
                        <div className="text-center BtnBox">
                            <button className="btnPrimaryOutline" onClick={(e) => onReset(e)} >Reset</button>
                            <button className="btnPrimary ms-2" onClick={onSubmit} > Submit</button>
                        </div>


                    </div>
                </div>
                <LoadingSpinner isShow={false} />
                <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
            </div>
            <p>&nbsp;</p>
            {(setUploadFilesReport === null || setUploadFilesReport.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
            {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {(UploadFilesReport !== null && UploadFilesReport.length > 0) ? (
                <div className="PageContainer">
                    <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                        <h5 className="fontWeight-600 fileConfigHead colorBlack">Import File upload status</h5>
                    </div>
                    <div className="tableBorderBox PageWhiteBox PageWhiteBox2 d-flex justify-content-center w-100">
                        <div className="table-responsive tableContentBox" >
                            <table id="gvUnmatchedTxnsReportPDF" className="table table-striped table-hover table-borderless align-middle"  >
                                <thead>
                                    <tr>
                                        <th scope="col">Sr. No.</th>
                                        <th scope="col">Client Name</th>
                                        <th scope="col">File Type</th>
                                        <th scope="col">File Name</th>
                                        <th scope="col">File Status</th>
                                        <th scope="col">Insert rows count</th>
                                        <th scope="col">Failed rows count</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        UploadFilesReport.map((p, ID) => {
                                            return <tr key={ID}>
                                                <td >{p.ID} </td>
                                                <td >{p.ClientName} </td>
                                                <td >{p.FileType} </td>
                                                <td >{p.FileName} </td>
                                                <td >{p.FileStatus}</td>
                                                <td >{p.Insert}</td>
                                                <td >{p.Failed}</td>
                                            </tr>
                                        })
                                    }

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            ) : null}
            </>)}
        </div>
    );
};

export default DynamicImportFileMainWindow;
