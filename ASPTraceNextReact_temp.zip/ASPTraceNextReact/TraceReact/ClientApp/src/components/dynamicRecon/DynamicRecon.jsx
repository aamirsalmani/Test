﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
import "../common/traceReport.css";
// Components
import SidebarMain from "../common/SidebarMain";
import DynamicReconMainWindow from "./DynamicReconMainWindow";

const DynamicRecon = () => {

    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView d-flex">
            <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
                <DynamicReconMainWindow />
            </div>
        </div>
    );
};

export default DynamicRecon;