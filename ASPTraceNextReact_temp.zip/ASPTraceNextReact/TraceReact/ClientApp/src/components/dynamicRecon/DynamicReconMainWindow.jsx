﻿import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from 'react-select/async';
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../common/apiURL" ;
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { useSelector } from "react-redux";


//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
import { getYear, getMonth } from "date-fns";

import "jspdf-autotable";



const DynamicReconMainWindow = () => {

    const currentUser = useSelector((state) => state.authReducer);

    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }

    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const fetchClientData = (inputValue) => {

        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }


    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];


    //   Date Calendar
    const [startDate, setStartDate] = useState(new Date());
    //   Date Calendar
    const [endDate, setEndDate] = useState(new Date());

    const [inputValue, setValue] = useState('0');
    const [selectedClientValue, setSelectedClientValue] = useState(null);

    const [optionsChannelType, setOptionsChannelTypeValue] = useState([{ channelID: "0", channelName: "--Select--" }]);
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);

    const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "--Select--" }]);
    const [selectedModeValue, setSelectedModeValue] = useState(null);

    const [DynamicRunRecon, setDynamicRunRecon] = useState(null);

    const setStartDateValue = value => {
        setStartDate(value);

    }

    const setEndDateValue = value => {

        if (startDate === null) {
            setEndDate(null);
            alert('Please enter From date first');
        }
        else {
            if (startDate > value) {
                alert('To date must be greater than From date ');
                setEndDate(null);
            }
            else {
                setEndDate(value);
            }
        }

    }

    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }

    const handleInputChange = value => {
        setValue(value);
    };


    const handleClientChange = value => {

        setSelectedClientValue(value);
        setSelectedChannelValue(null);
        setSelectedModeValue(null);
        //setClientOptions([]);

        if (value.clientID !== '0') {

            MaximusAxios.get('api/DynamicRecon/GetDynamicReconList?ClientID=' + value.clientID, {  mode: 'cors' }).then(result => {
                setOptionsChannelTypeValue(result.data);
            });

            return MaximusAxios.get('api/DynamicRecon/GetRunReconHistoryDynamicReconList?ClientID=' + value.clientID, {  mode: 'cors' }).then(result => {
                setDynamicRunRecon(result.data);
            });
        }

    }



    const handleChannelChange = value => {
        setSelectedChannelValue(value);
        setSelectedModeValue(null);

        if (value.value !== '0' && selectedClientValue.clientID !== '0') {
            return MaximusAxios.get('api/DynamicRecon/GetModeDynamicReconList?ClientID=' + selectedClientValue.clientID + '&ChannelID=' + value.value, {  mode: 'cors' }).then(result => {
                setOptionsModeTypeValue(result.data);

            });
        }

    }

    const handleModeChange = value => {
        setSelectedModeValue(value);
    }


    $(document).ready(function () {

        if (DynamicRunRecon !== null && DynamicRunRecon.length > 0) {
            $('#gvDynamicRunRecon').DataTable();
        }
    });

    const handleSubmit = () => {

        if (currentUser !== null && currentUser.user !== null) {

            if (selectedClientValue === null || selectedClientValue.clientID === 0) {
                alert("Please select client!");
                return false;
            }

            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                alert("Please select Channel!");
                return false;
            }

            if (selectedModeValue === undefined || selectedModeValue === null) {
                alert("Please select mode Type!");
                return false;
            }

            if (startDate === undefined || startDate === null) {
                alert("Please enter From Date!");
                return false;
            }

            if (endDate === undefined || endDate === null) {
                alert("Please enter To Date!");
                return false;
            }


            let ChannelId = 0;

            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                ChannelId = 0;
            }
            else {
                ChannelId = selectedChannelValue.value;
            }

            let ModeId = 0;

            if (selectedModeValue === undefined || selectedModeValue === null) {
                ModeId = 0;
            }
            else {
                ModeId = selectedModeValue.value;
            }


            setIsLoading(true);

            MaximusAxios.post('api/DynamicRecon/GetRunReconAddDynamicReconList', {
                FromDate: formatDate(startDate),
                ToDate: formatDate(endDate),
                ClientID: selectedClientValue.clientID,
                ChannelID: ChannelId,
                Mode: ModeId,
                User: currentUser.user.username,

            }, {  mode: 'cors' })
                .then(function (response) {
                    setDynamicRunRecon(response.data);
                    setIsLoading(false);


                    MaximusAxios.get('api/DynamicRecon/GetRunReconHistoryDynamicReconList?ClientID=' + selectedClientValue.clientID, {  mode: 'cors' }).then(result => {
                        setDynamicRunRecon(result.data);
                    });

                    if (response.data === null || response.data.length === 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: '', alertMessage: 'Run recon added successfully' }); }
                })
                .catch(function (error) {
                    if (error.response) {
                        setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: error.response.data });
                    }
                    setIsLoading(false);

                    MaximusAxios.get('api/DynamicRecon/GetRunReconHistoryDynamicReconList?ClientID=' + selectedClientValue.clientID, {  mode: 'cors' }).then(result => {
                        setDynamicRunRecon(result.data);
                    });
                });
        } else {
            alert('Session Timeout');
        }
    };

    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                   Dynamic Run Recon
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Dynamic Run Recon</p>
                </div>
            </div>

            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="runreconFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="runreconFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>
                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#runreconFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="runreconFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="runreconFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="runreconFiltersHeading"
                            data-bs-parent="#runreconFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedClientValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedChannelValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            onChange={handleChannelChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedModeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.modeName
                                                }
                                            ))}
                                            onChange={handleModeChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="StartDate">From Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                            selected={startDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setStartDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ToDate">To Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                            selected={endDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setEndDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                </div>

                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={handleSubmit}
                                    >
                                        RunRecon
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>



            {/* Config Left Bottom */}
            <div className="configLeftBottom">
                {(DynamicRunRecon === null || DynamicRunRecon.length === 0) &&
                    <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div>
                }
                {/* Table */}
                {(DynamicRunRecon != null && DynamicRunRecon.length > 0) ? (
                    <div>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvDynamicRunRecon" className="table table-striped table-hover table-borderless align-middle"  >

                                        <thead>
                                            <tr>
                                                <th scope="col">Client Name</th>
                                                <th scope="col">From Date</th>
                                                <th scope="col">To Date</th>
                                                <th scope="col">Channel</th>
                                                <th scope="col">Mode</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Created by</th>
                                                <th scope="col">Created Date</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                DynamicRunRecon.map((p, I) => {
                                                    return <tr key={I}>
                                                        <td >{p.clientName}</td>
                                                        <td >{p.fromdate}</td>
                                                        <td >{p.todate}</td>
                                                        <td >{p.channel}</td>
                                                        <td >{p.mode}</td>
                                                        <td >{p.status}</td>
                                                        <td >{p.createdby}</td>
                                                        <td >{p.createdDate}</td>

                                                    </tr>
                                                })
                                            }
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
            </div>
            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default DynamicReconMainWindow;
