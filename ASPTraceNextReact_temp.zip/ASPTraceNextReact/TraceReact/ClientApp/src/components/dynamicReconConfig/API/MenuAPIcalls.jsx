import React, { useState, useContext, useEffect } from "react";
import MaximusAxios from "../../common/apiURL";
import { useDispatch, useSelector } from "react-redux";
import authHeader from "../../../pages/login/services/auth-header";
import postHeader from "../../../pages/login/services/post-header";
import axios from 'axios';

export const fetchClientData = async (inputValue, currentUser) => {

    return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser, { mode: 'cors' })
        .then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
}


export const postCaseTableAPI = async (caseTable) => {



    // console.log('caseTable',caseTable);

    const data = await axios.post('api/DynamicReconConfig/PostCaseTable', caseTable, { headers: postHeader() })
        .then(result => {

            return result.data;

        }).catch(function (error) {
            console.log(error.response);
        });

    return data;
}

export const GetAPI = async (Url, Params) => {

    if (Url.length === 0)
        return null;


    const fetchData = async (path) => {


        return MaximusAxios.get(path, { mode: 'cors' }).then((res) => {
            if (res.data !== null || res.data.length > 0) {
                let JsonData = JSON.parse(res.data);
                return JsonData
            }
            else {
                return null;
            }


        }).catch((error) => {

            console.log(error);
            return null;
        })

    }

    const ParamsJSON = Object.keys(Params).length > 0 ? Params : null;
    if (ParamsJSON !== null) {

        let ParamsString = Object.keys(ParamsJSON)
            .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(ParamsJSON[key])}`)
            .join('&');


        let pathUrl = ParamsString === '' ? `${Url}` : `${Url}` + `?${ParamsString}`;

        if (pathUrl !== null) {

            return fetchData(pathUrl);

        }
        else
            return null
    }



}


export const FetchColumns = async (TableName) => {
    let Columns = await MaximusAxios.get('api/ReconConfig/GetReconColumns?TableName=' + TableName, { mode: 'cors' }).then(result1 => {

        if (result1.data !== null || result1.data.length > 0) {
            let dt = result1.data;
            return dt.map((item) => { return { value: item.id, label: item.columnName } })

        }
    }).catch(error => {
        // Handle the error here
        console.log('An error occurred:', error);
        return [];

    });
    return Columns;



}

