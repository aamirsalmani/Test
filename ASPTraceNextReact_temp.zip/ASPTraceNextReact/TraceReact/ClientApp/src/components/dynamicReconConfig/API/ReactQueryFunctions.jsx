import React from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import MaximusAxios from "../../common/apiURL";

const fetchData = async (url, params) => {
  const response = await MaximusAxios.get(url, { params });
  return response.data;
};

const postData = async (url, data) => {
  const response = await MaximusAxios.post(url, data);
  return response.data;
};

export const useGetQuery = (apiUrl, params) => {
  return useQuery(['getData', apiUrl, params], () => fetchData(apiUrl, params));
};

export const usePostMutation = () => {
  const queryClient = useQueryClient();

  return useMutation((payload) => postData(payload.apiUrl, payload.data), {
    onSuccess: () => {
      queryClient.invalidateQueries('getData');
    },
  });
};

export const GetRequestComponent = ({ apiUrl, initialParams }) => {
  const getQuery = useGetQuery(apiUrl, initialParams);

  return getQuery;

  //return (
  //   <div>
  //     {getQuery.isLoading && <p>Loading...</p>}
  //     {getQuery.isError && <p>Error: {getQuery.error.message}</p>}
  //     {getQuery.isSuccess && (
  //       <pre>{JSON.stringify({ data: getQuery.data, status: getQuery.status }, null, 2)}</pre>
  //     )}
  //   </div>
  //);
};

export const PostRequestComponent = ({ apiUrl, data }) => {
  const postMutation = usePostMutation();

  const handlePost = async (apiUrl, data) => {
    await postMutation.mutateAsync({ apiUrl, data });
  };
  return handlePost(apiUrl, data);

  // return (
  //   <div>
  //     <button onClick={() => handlePost({ exampleData: 'someData' })}>Post Data</button>
  //     {postMutation.isLoading && <p>Posting...</p>}
  //     {postMutation.isError && <p>Error: {postMutation.error.message}</p>}
  //     {postMutation.isSuccess && <p>Data posted successfully!</p>}
  //   </div>
  // );
};
