﻿export { pushValueNTimes }

function pushValueNTimes({ array: arr,ElementValue: value,count: n }) {
    for (let i = 0; i < n; i++) {
        arr.push(value);
    }
    return arr;
}