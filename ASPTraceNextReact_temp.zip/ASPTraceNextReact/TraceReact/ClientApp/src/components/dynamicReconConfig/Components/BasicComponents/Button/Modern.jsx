import React, { forwardRef } from 'react';
import './buttonStyles.css'

const switchTheme = (theme) =>{
    switch (theme) {
        case 'blue': return 'button-modern-blue';
        case 'green': return 'button-modern-green';
        default: return '';
    }
}

const Modern = forwardRef(({theme='',...props}, ref) => {
    
    return (
        <button ref={ref} {...props}  className={`button-modern-white ${switchTheme(theme)}`}>
            {props.children}
        </button>
    )
})

export default Modern