import React, { forwardRef } from 'react';
import './buttonStyles.css'

const switchTheme = (theme) =>{
    switch (theme) {
        case 'blue': return 'button-modern-blue';
        case 'green': return 'button-modern-green';
        case 'red': return 'button-modern-red';
        case 'slate': return 'button-modern-slate';
        default: return '';
    }
}

const Primary = forwardRef(({theme='blue',...props}, ref) => {
    
    return (
        <button ref={ref} {...props}  className={`button-modern ${switchTheme(theme)}`}>
            {props.children}
        </button>
    )
})

export default Primary