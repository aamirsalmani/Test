import Primary from "./Primary";
import Modern from './Modern'



export {Primary,Modern};