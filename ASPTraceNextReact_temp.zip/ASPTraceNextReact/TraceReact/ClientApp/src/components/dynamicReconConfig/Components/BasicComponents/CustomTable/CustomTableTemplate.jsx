import React, { Fragment, useEffect, useMemo, useState } from 'react'
import * as CT from './CustomTable'
import './NewStyle.css'
import { IconEdit, IconRemove, ConfigureIcon, UpdateIcon } from '../../../Utility/assets/Icons/iconsIndex'
import { setClickedRow } from '../../../Redux/Reducers/WizardReducer'
import { useDispatch } from 'react-redux'
import SearchBar from '../Search/SearchBar'
import { Modern, Primary } from '../Button/index'
import Tags from '../Tag/Tags'
import { setModal } from '../../../Redux/Reducers/ModalReducer'
import usePostForm from '../../../hooks/usePostForm'
import useAutoMatch from '../../../hooks/useAutoMatch'
import useOptionsData from '../../../hooks/useOptionsData'
import MatchIcon from '../../../Utility/assets/Icons/MatchIcon'



const DynamicCell = ({ ColumnType, CellData, ddlOptions, setSelectedOption, onRedirect }) => {

    const [EditColor, setEditColor] = useState('#518f54');

    if (ColumnType === 'CaseStatement') {

        return (
            <div className='case-statement'>
                <span style={{ fontSize: '0.72rem', fontWeight: 400 }}>{CellData}</span>
            </div>);
    }
    else {
        return (<>{CellData}</>);
    }
}


const Searchfilter = (type, searchText, Data, ColumnToSearch) => {
    if (type === 1) {
        const newData = Data.filter(item => item[ColumnToSearch] === '');

        if (newData.length > 0) {


            return newData
        }
        else
            return Data;
    }
    else if (type === 2) {
        const newData = Data.filter(item => item[ColumnToSearch] !== '');

        if (newData.length > 0) {


            return newData
        }
        else
            return Data;
    }
    else if (type === -1) {

        if (searchText !== '') {
            const newData = Data.filter(item =>
                item[ColumnToSearch].toLowerCase().includes(searchText.toLowerCase()));

            if (newData.length > 0) {


                return newData
            }
            else
                return Data;
        }
        else {
            return Data;
        }

    }
    else
        return Data;
}

const SearchfilterPanel = ({ AutoMatchColumns, onChange, Data = [] }) => {

    const OnClick = (prop) => {
        onChange(prop)
    }
    const SelectedTag = ({ tagType, content }) => {
        switch (tagType) {
            case 1: return (<Tags backgroundColor="#fdfab0" AccentColor="#b3ad1b">{`${content} Pending`}</Tags>);
            case 2: return (<Tags backgroundColor="#c9f7c3" AccentColor="#21b118">{`${content} completed`}</Tags>);
            case 3: return (<Tags backgroundColor="#cbefca" AccentColor="#518f54">{`${content} completed`}</Tags>);
            case 4: return (<Tags backgroundColor="#e1ecff" AccentColor="#699BF7">{`${content} completed`}</Tags>);
            case 5: return (<Tags backgroundColor="#f3f3f3" AccentColor="#8f8f8f">{`${content} Pending`}</Tags>);
            default: return (<></>);

        }
    }
    return (<div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
        <div className="filter-info" >
            {
                Object.keys(Data).map((item,i) => {
                    let type = item.replace('Type', '') === "" ? 1 : parseInt(item.replace('Type', ''));
                    return (
                        <button key={i} style={{ margin: '10px 0' }} onClick={() => (OnClick(type))} >
                            <SelectedTag tagType={type} content={Data[item]} />
                        </button>
                    );
                })
            }

        </div>
        <div className="filter-info" >
            <Modern onClick={() => { AutoMatchColumns(); }} >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '5px' }}>
                    <span><MatchIcon color='#0f0f0f' height='20px' width='20px' /></span>
                    <span>Auto Match</span>
                </div>
            </Modern>
            <Modern onClick={() => (OnClick(0))}>Clear Filters</Modern>
        </div>
    </div>)
}

const ActionsComponent = () => {
    const dispatch = useDispatch();
    const { SubmitForm } = usePostForm();
    return (<>
        <div className="ActionsPanel">
            <Primary theme={'green'} onClick={() => { SubmitForm() }} >
                Save
            </Primary>
            <Primary onClick={() => { dispatch(setModal({ ActiveModal: 'FilterConditionsModal', IsVisible: true })) }} >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '5px' }}>
                    <span><ConfigureIcon color='#fff' height='20px' width='20px' /></span>
                    <span>Filter Conditions</span>
                </div>
            </Primary>
            {/* <Primary theme={'slate'} onClick={() => { dispatch(setModal({ ActiveModal: 'UpdateConditionsModal', IsVisible: true })) }} >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '5px' }}>
                    <span><UpdateIcon color='#fff' height='20px' width='20px' /></span>
                    <span>Update Conditions</span>
                </div>
            </Primary> */}
        </div>
    </>);
}

const TableTemplate = ({ TableData, JoinTable, setIsModalVisible, GetOutputTable }) => {

    const [search, setSearch] = useState('');
    const localheaders = Object.keys(TableData[0]);
    const setLocalTable = GetOutputTable;
    const [filterType, setFilterType] = useState(0);
    const dispatch = useDispatch();
    const FilteredData = Searchfilter(filterType, search, TableData, 'CaseStatement');
    const localTable = Searchfilter(-1, search, FilteredData, 'AliasColumn');
    const { columns } = useOptionsData();
    let columnsOptions = useMemo(() => { return columns.map((item) => item.label) }, [columns])
    const { getAutoMatch } = useAutoMatch(columnsOptions, TableData, 'AliasColumn', 'CaseStatement');

    const AutoMatchColumns = () => {

        let dt = getAutoMatch();
        setLocalTable(dt);
    }

    const TagData = [...TableData].map((item) => {
        if (item.CaseStatement !== '') {
            return { tagType: 2 };
        }
        else return { tagType: 1 };
    });

    const TagTypeCounts = TagData.reduce((counts, currentValue) => {
        const { tagType } = currentValue;
        counts[`Type${tagType}`] = (counts[`Type${tagType}`] || 0) + 1;
        return counts;
    }, {});


    const DeleteButtonClick = ({ AliasColumn, RowIndex }) => {
        let dt = [...localTable].map((item, i) => {

            if (item.AliasColumn === AliasColumn)
                return { ...item, CaseStatement: '' }
            else
                return { ...item };
        })


        setLocalTable(dt);

    }

    const EditButtonClick = ({ AliasColumn, RowIndex }) => {

        setIsModalVisible(true);
        dispatch(setClickedRow({ AliasColumn: AliasColumn, RowIndex: RowIndex, Action: 'Edit', OtherData: { caseTable: localTable, JoinTables: JoinTable } }));

    }


    return (
        <div style={{ margin: '1px' }}>
            <div className="Table-Filters">
                <div className="Table-Filters-Search">
                    <SearchBar onChange={(prop) => { setSearch(prop) }} />
                    <ActionsComponent />
                </div>
                <div className="Table-Filters-Actions">
                    <SearchfilterPanel AutoMatchColumns={AutoMatchColumns} onChange={setFilterType} Data={TagTypeCounts} />
                </div>
                <CT.Table >
                    <CT.TableHeader>
                        <CT.TableRow >
                            {localheaders.map((item, i) => {
                                if (item === 'ID') { return (<Fragment key={`${item}`}></Fragment>) }
                                else {
                                    return (
                                        <>
                                            <CT.TableCell key={`${item}`} style={{ width: i === localheaders.length - 1 ? `100%` : `150px` }}>
                                                <div style={{ fontSize: '0.9rem', fontWeight: '600' }}>{item}</div>
                                            </CT.TableCell>
                                        </>
                                    )
                                }
                            }
                            )}
                            <CT.TableCell style={{ width: `150px` }}>
                                <div style={{ fontSize: '0.9rem', fontWeight: '600' }}>{`Actions`}</div>
                            </CT.TableCell>
                        </CT.TableRow>
                    </CT.TableHeader>
                </CT.Table>
            </div>
            <CT.Table style={{ overflow: 'auto', maxHeight: '500px' }}>
                <CT.TableBody>
                    {
                        localTable.map((tr, i) => (
                            <>
                                <CT.TableRow>
                                    {localheaders.map((tc, j) => {
                                        if (tc === 'ID') { return (<Fragment key={`${tc}${j}`}></Fragment>) }
                                        else {
                                            return (
                                                <>
                                                    <CT.TableCell key={`${tc}${j}`} style={{ width: tc === 'CaseStatement' ? `100%` : `150px` }}>
                                                        {<DynamicCell CellData={tr[tc]} ColumnType={tc} />}
                                                    </CT.TableCell>

                                                </>
                                            )
                                        }
                                    })}
                                    <CT.TableCell style={{ width: `150px` }}>
                                        <div className='custom-Actions-Menu'>
                                            <button type='button' className='custom-edit-button'
                                                onClick={() => { EditButtonClick({ AliasColumn: tr.AliasColumn, RowIndex: tr.ID }) }}
                                            >
                                                <IconEdit />

                                            </button>
                                            <button type='button' className='custom-edit-button'
                                                onClick={() => { DeleteButtonClick({ AliasColumn: tr.AliasColumn, RowIndex: tr.ID }) }}
                                            >
                                                <IconRemove />
                                            </button>
                                        </div>
                                    </CT.TableCell>
                                </CT.TableRow>
                            </>
                        ))
                    }
                </CT.TableBody>
            </CT.Table>
        </div>
    )
}


const CustomTable = ({ TableData, JoinTable, setIsModalVisible, GetOutputTable }) => {

    if (TableData?.length === 0 || TableData === undefined) {
        return (<></>);
    }


    return (
        <>
            <TableTemplate TableData={TableData} setIsModalVisible={setIsModalVisible} JoinTable={JoinTable} GetOutputTable={GetOutputTable} />
        </>
    );
}

export default CustomTable