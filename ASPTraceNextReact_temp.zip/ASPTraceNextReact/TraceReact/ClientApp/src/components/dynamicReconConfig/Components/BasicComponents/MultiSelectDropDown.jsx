import React, { useEffect, useRef, useState } from 'react'
import './SelectDropDown.css'


const MultiSelectDropDown = ({ options = null, selectedOptions=[{value:'0',label:'Select'}], setSelectedOptions, isMultiSelect = false ,title='',customClassButton='',customClassTextBlock=''}) => {

    const DefaultOptions = ['option 1','option 2','option 3','option 4',].map((item,i) => ({value:`${i}`,label:item}));
    
    const [ddloptions,setOptions] = useState([]);
    const [isOpen, setIsOpen] = useState(false);
    //const [selectedOptions, setSelectedOptions] = useState([]);
    const newRef = useRef(null);

    useEffect(()=>{
        if(options === null)
            setOptions(DefaultOptions);
        else
            setOptions(options);

    },[options]);

    useEffect(() => {
        if (isOpen) {
            document.addEventListener("mousedown", handleOutsideClick);
            return () => {
                document.removeEventListener("mousedown", handleOutsideClick);
            };
        }
    });
    const handleOutsideClick = (e) => {
        if (newRef.current && !newRef.current.contains(e.target)) {
            if (isOpen)
                toggleDropdown();
        }
    };

    const toggleDropdown = () => {
        setIsOpen(prev => !prev);
        // console.log(selectedOptions);
    };

    const handleOptionChange = (option) => {
        if (isMultiSelect) {

            const updatedOptions = [...selectedOptions];
            if (updatedOptions.includes(option)) {
                updatedOptions.splice(updatedOptions.indexOf(option), 1);
            } else {
                updatedOptions.push(option);
            }
            setSelectedOptions(updatedOptions);
        }
        else
            setSelectedOptions([option]);
    };

    return (
        <>        
        {
            title !=='' ? 
            <div className="DropDownHeader">
                {title}
            </div>
            :<></>
        }        
        <div className={isMultiSelect ? `multi-select-dropdown ${customClassButton}` : `dropdown ${customClassButton}`} ref={newRef}>
            <button className={isMultiSelect ? `multi-select-dropdown__button ${customClassTextBlock}` : `text-wrapper ${customClassTextBlock}`} onClick={toggleDropdown}>
                {selectedOptions.length > 0 ?
                    <>{!isMultiSelect ?
                        <div
                        //  className="multi-select-dropdown__selected-group"
                        >
                            {
                                <span
                                // className="multi-select-dropdown__selected-option"
                                >
                                    {selectedOptions[0].label}
                                </span>
                            }
                        </div>
                        :
                        <>{

                            selectedOptions.length > 2 ?
                                <div className="multi-select-dropdown__selected-option">{selectedOptions.length} items selected</div>
                                :
                                <div className="multi-select-dropdown__selected-group">
                                    {
                                        selectedOptions.map((option) => (
                                            <span key={option} className="multi-select-dropdown__selected-option">
                                                {option.label}
                                            </span>
                                        ))
                                    }
                                </div>
                        }
                        </>
                    }
                    </>
                    : <span>Select</span>
                }
                <span>
                    <svg height="20" width="20" viewBox="0 0 20 20" aria-hidden="true" focusable="false" className="css-tj5bde-Svg">
                        <path d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 
                        3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 
                        0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 
                        0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z">
                        </path>
                    </svg>
                </span>
            </button>
            {isOpen && (
                <div className={isMultiSelect ? `multi-select-dropdown__dropdown-options` :`dropdown-options`}>
                    {ddloptions.length > 0 ? ddloptions.map((option) => (
                        <label className="multi-select-dropdown__label" key={option.label}
                            onClick={() => {
                                handleOptionChange(option);
                                if (isOpen) toggleDropdown();
                            }}>
                            {isMultiSelect ? <input
                                type="checkbox"
                                value={option.label}
                                // onChange={() => handleOptionChange(option.label)}
                                checked={selectedOptions.includes(option)}
                            /> : <></>}
                            {option.label}
                        </label>
                    ))
                    :
                    <div className="EmptyDropDown">
                        No Options
                    </div>

                }
                </div>
            )
            }

        </div >
        </>
    );
}

export default MultiSelectDropDown