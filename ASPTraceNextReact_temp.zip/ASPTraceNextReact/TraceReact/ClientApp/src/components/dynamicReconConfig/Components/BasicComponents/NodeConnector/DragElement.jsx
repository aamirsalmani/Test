import React, { useEffect, useState } from 'react';

// Custom draggable component
const DragElement = ({ children, onPositionChange, }) => {
    const [isDragging, setIsDragging] = useState(false);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

    const GetPositions = (rect) => {

        const Positions = {
            TopLeft: { x: rect.x, y: rect.y }
           ,TopRight:{ x: rect.right, y: rect.y }
           ,TopCenter:{ x: rect.x+ rect.width / 2, y: rect.y}
           ,CenterLeft:{ x: rect.x, y: rect.y+ rect.height / 2}
           ,CenterRight:{ x: rect.right, y: rect.y+ rect.height / 2}
           ,BottomLeft: { x: rect.x, y: rect.y +rect.height}
           ,BottomRight:{ x: rect.right, y: rect.y +rect.height}
           ,BottomCenter:{ x: rect.x+ rect.width / 2, y: rect.y+rect.height}
        }

        return Positions;

    }

    const handleMouseDown = (e) => {
        setIsDragging(true);
        setDragStart({
            x: e.clientX - position.x,
            y: e.clientY - position.y,
        });
    };

    const handleMouseMove = (e) => {
        if (!isDragging) return;

        const element = e.target;
        const rect = element.getBoundingClientRect();

        setPosition({
            x: e.clientX - dragStart.x,
            y: e.clientY - dragStart.y,
        });

        let Positions = GetPositions(rect);
        onPositionChange(Positions);
    };

    const handleMouseUp = () => {
        setIsDragging(false);
    };

    const CustomStyle = {
        position: 'absolute',
        left: position.x,
        top: position.y,
        cursor: isDragging ? 'grabbing' : 'grab',
    }

    return (<>
        <div className='drag-element'
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            style={CustomStyle}>
            {children}
        </div>
    </>);

};

export default DragElement;
