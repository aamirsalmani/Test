
const DragExample = () => {
    // Example start and end points
    const [element1Position, setElement1Position] = useState(null);
    const [element2Position, setElement2Position] = useState(null);

    // Function to handle position change
    const handlePositionChange = (index, Positions) => {

        const position = Positions

        if (index === 1)
            setElement1Position(position);
        if (index === 2)
            setElement2Position(position);
    };

    return (
        <div style={{ width: '500px', height: '500px', border: '1px solid black' }}>
            <DragElement onPositionChange={(prop) => (handlePositionChange(1, prop))}>
                <div><span><IconEdit /></span><span>Element 1</span></div>
            </DragElement>
            <DragElement onPositionChange={(prop) => (handlePositionChange(2, prop))}>
                <div><span><IconEdit /></span><span>Element 2</span></div>
            </DragElement>
        </div>
    );
};
