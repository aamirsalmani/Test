import React from 'react';

// Custom hook to calculate SVG path data
const useNodeConnector = ({start, end}) => {
    

    // // Calculate the control point for the curve to make the connector a bit more visually appealing
    // const controlPointX = (start.x  + end.x) / 2;
    // const controlPointY = start.y - 50; // Adjust this value to control the curvature

    // // Define the SVG path data string
    // const pathData = `M ${start.x} ${start.y} Q ${controlPointX} ${controlPointY} ${end.x} ${end.y}`;

    const midX = (start.x + end.x) / 2;
    const midY = (start.y + end.y) / 2;

    // Define the SVG path data string
    const pathData = `
        M ${start.x } ${start.y}
        L ${midX} ${start.y}
        L ${midX} ${end.y}
        L ${end.x} ${end.y}
    `;

    return pathData;

};

// Reusable SVGConnector component
const NodeConnector = ({ start, end }) => {
    const pathData = useNodeConnector({start,end});

    return (
        <svg style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
            <path
                d={pathData}
                fill="none"
                stroke="black"
                strokeWidth="2"
                markerEnd="url(#dot)"
            />
            {/* Define an arrowhead marker */}
            <defs>
                <marker id="dot" viewBox="0 0 10 10" markerWidth="10" markerHeight="10" refX="5" refY="5" orient="auto" markerUnits="strokeWidth">
                    <circle cx="5" cy="5" r="5" fill="#FFFFFF" stroke="#008000" stroke-width="2" />
                </marker>
            </defs>
        </svg>
    );
};

export { useNodeConnector, NodeConnector };
