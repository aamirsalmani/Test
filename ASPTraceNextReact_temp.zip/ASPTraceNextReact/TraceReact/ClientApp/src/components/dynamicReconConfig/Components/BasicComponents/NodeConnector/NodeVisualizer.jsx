import { memo } from "react";
import { NodeConnector } from "./NodeConnector";


const removeDuplicates = (array) => {
    const uniqueElements = [];
    const seen = new Set();

    array.forEach(({ parent, child }) => {
        const key = `${parent}-${child}`;
        if (!seen.has(key)) {
            seen.add(key);
            uniqueElements.push({ parent, child });
        }
    });

    return uniqueElements;
};


const getNodePositions = (parentRect, childRect) => {
    // Get coordinates of parent and child nodes
    const parent = {x:parentRect.left ,y : parentRect.top+ parentRect.height/2};
    const child  = {x:childRect.left  ,y : childRect.top + childRect.height/2}; 
    


    return { start:parent, end:child};
};


const NodeVisualizer = memo(({ elements = null }) => {
    // Remove duplicates from the array
    if (elements === null || elements === undefined) {
        return (<></>);
    }
    else if (elements.length === 0) {
        return (<></>);
    }

    

    const uniqueElements = removeDuplicates(elements);

    

    const renderConnectors = () => {
        return uniqueElements.map(({ parent, child }, index) => {
            // Get bounding rectangles of parent and child elements
            const parentRect = document.getElementById(parent).getBoundingClientRect();
            const childRect = document.getElementById(child).getBoundingClientRect();
            // Get node positions based on rules
            const { start,end } = getNodePositions(parentRect, childRect);


            return <NodeConnector key={index} start={start} end={end} />;
        });
    };

    return <>{renderConnectors()}</>;
});

export default NodeVisualizer;
