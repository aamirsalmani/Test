
const getQuadrant = (x, y) => {
    if (x >= 0 && y >= 0) {
        return 1;
    } else if (x < 0 && y >= 0) {
        return 2;
    } else if (x < 0 && y < 0) {
        return 3;
    } else {
        return 4;
    }
};

// Function to determine parent and child node positions based on quadrant and vertical distance
export const getNodePositionsByQuadrant = (parentRect, childRect) => {
    // Calculate center coordinates of parent and child nodes
    const parentCenterX = parentRect.left + parentRect.width / 2;
    const parentCenterY = parentRect.top + parentRect.height / 2;
    const childCenterX = childRect.left + childRect.width / 2;
    const childCenterY = childRect.top + childRect.height / 2;

    // Calculate quadrant
    const quadrant = getQuadrant(childCenterX - parentCenterX, childCenterY - parentCenterY);

    // Calculate minimum vertical distance between parent and child
    const minVerticalDistance = Math.abs(parentCenterY - childCenterY);

    // Calculate connection points based on quadrant and minimum vertical distance
    let startX, startY, endX, endY;

    if (minVerticalDistance < parentRect.height) {
        // If min vertical distance is less than parent height, connect on side
        switch (quadrant) {
            case 1:
                startX = parentRect.right;
                startY = parentCenterY;
                endX = childRect.left;
                endY = childCenterY;
                break;
            case 2:
                startX = parentRect.left;
                startY = parentCenterY;
                endX = childRect.right;
                endY = childCenterY;
                break;
            case 3:
                startX = parentRect.left;
                startY = parentCenterY;
                endX = childRect.right;
                endY = childCenterY;
                break;
            case 4:
                startX = parentRect.right;
                startY = parentCenterY;
                endX = childRect.left;
                endY = childCenterY;
                break;
            default:
                // Default to connecting through centers
                startX = parentCenterX;
                startY = parentCenterY;
                endX = childCenterX;
                endY = childCenterY;
                break;
        }
    } else {
        // Otherwise, connect through centers
        startX = parentCenterX;
        startY = parentCenterY;
        endX = childCenterX;
        endY = childCenterY;
    }

    return { startX, startY, endX, endY };
};
