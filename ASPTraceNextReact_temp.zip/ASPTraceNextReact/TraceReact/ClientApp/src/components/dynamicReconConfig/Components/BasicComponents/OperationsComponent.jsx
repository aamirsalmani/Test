import MaximusAxios from "../../../common/apiURL";
import React, { useEffect, useState } from 'react'
import postHeader from '../../../../pages/login/services/post-header';
import MultiSelectDropDown from './MultiSelectDropDown';
import { useQuery, QueryClient } from 'react-query';
import axios from 'axios';
import './OperationComp.css'
import SelectComponent from './SelectComponent';

const APIGetOperations = async () => {
    try {
        let { data } = await axios.get('api/DynamicReconConfig/GetOperations?Type=1', { headers: postHeader(), mode: 'cors' });

        return data;
    }
    catch (error) {
        console.log(error);
        return null;
    };

}
const OperationValue = ({ TableAlias, Operationtext, TextValue, setOutput }) => {
    const [inputText, setInputtext] = useState('');

    return (
        <>
            <div className='DropDownHeader'>Value</div>
            <input className='OperationType-textBox' type='text' placeholder='Enter Text here' value={inputText} onChange={(e) => {
                let label = e.target.value;
                setInputtext(label);
                if (Operationtext === 'VALUE')
                    setOutput(`'${label}'`)
                else if (Operationtext === 'CASE')
                    setOutput(`${label}`)
            }} />

        </>
    );
}

const OperationLeftRight = ({ TableAlias, Operationtext, TextValue, setOutput }) => {
    const [inputText, setInputtext] = useState(0);

    return (
        <>
            <div className='DropDownHeader'>Position</div>
            <input className='OperationType-textBox' type='number' min={0} value={inputText} onChange={(e) => {
                let label = e.target.value;
                if (label === '') {
                    setInputtext(0);
                }
                else {
                    let number = parseInt(label);
                    if (number >= 0) {

                        setInputtext(number);
                        if (Operationtext === 'LEFT')
                            setOutput(`LEFT(T${TableAlias}.${TextValue},${number})`)
                        else if (Operationtext === 'RIGHT')
                            setOutput(`RIGHT(T${TableAlias}.${TextValue},${number})`)
                    }
                    else {
                        setInputtext(0);
                    }
                }
            }} />

        </>
    );
}
const OperationREPLACE = ({ TableAlias, Operationtext, TextValue, setOutput }) => {
    const [findtext, setFindtext] = useState('');
    const [ReplaceText, setReplaceText] = useState('');

    return (
        <>
            <div className="OperationType-Substring-Box">

                <div className='DropDownHeader'>Search Text</div>
                <input className='OperationType-textBox' type='text' value={findtext} onChange={(e) => {
                    let label = e.target.value;
                    if (label === '') {

                    }
                    else {
                        setFindtext(label);
                        setOutput(`REPLACE(T${TableAlias}.${TextValue},${label},${ReplaceText})`)

                    }
                }} />

            </div>
            <div className="OperationType-Substring-Box">
                <div className='DropDownHeader'>Replace text</div>
                <input className='OperationType-textBox' type='text' value={ReplaceText} onChange={(e) => {
                    let label = e.target.value;
                    if (label === '') {

                    }
                    else {

                        setReplaceText(label);
                        setOutput(`REPLACE(T${TableAlias}.${TextValue},${findtext},${label})`)

                    }
                }} />
            </div>
        </>
    );
}

const OperationSUBSTRING = ({ TableAlias, Operationtext, TextValue, setOutput }) => {
    const [StartPosition, setStartPosition] = useState(0);
    const [Length, setLength] = useState(0);

    return (
        <>
            <div className="OperationType-Substring-Box">

                <div className='DropDownHeader'>Start Position</div>
                <input className='OperationType-textBox' type='number' min={0} value={StartPosition} onChange={(e) => {
                    let label = e.target.value;
                    if (label === '') {
                        setStartPosition(0);
                    }
                    else {
                        let number = parseInt(label);
                        if (number >= 0) {

                            setStartPosition(number);
                            setOutput(`SUBSTRING(T${TableAlias}.${TextValue},${number},${Length})`)
                        }
                        else {
                            setStartPosition(0);
                        }
                    }
                }} />

            </div>
            <div className="OperationType-Substring-Box">
                <div className='DropDownHeader'>Length</div>
                <input className='OperationType-textBox' type='number' min={0} value={Length} onChange={(e) => {
                    let label = e.target.value;
                    if (label === '') {
                        setLength(0);
                    }
                    else {
                        let length = parseInt(label);
                        if (length >= 0) {

                            setLength(length);
                            setOutput(`SUBSTRING(T${TableAlias}.${TextValue},${StartPosition},${length})`)
                        }
                        else {
                            setLength(0);
                        }
                    }
                }} />
            </div>
        </>
    );
}

const OperationType = ({ TableAlias, Operation, TextValue, setOutput }) => {

    const Operationtext = Operation.label;

    const init = { operation: '', value: '' }

    const [paramters, setParamters] = useState(init);

    const [inputText, setInputtext] = useState(0);

    const paramtersFn = () => {


    }

    if (Operationtext === 'LEFT' || Operationtext === 'RIGHT') {
        return (
            <><OperationLeftRight TableAlias={TableAlias} Operationtext={Operationtext} TextValue={TextValue} setOutput={setOutput} /></>
        );
    }
    else if (Operationtext === 'SUBSTRING') {
        return (
            <><OperationSUBSTRING TableAlias={TableAlias} Operationtext={Operationtext} TextValue={TextValue} setOutput={setOutput} /></>
        );
    }
    else if (Operationtext === 'VALUE' || Operationtext === 'CASE') {

        return (
            <><OperationValue TableAlias={TableAlias} Operationtext={Operationtext} TextValue={TextValue} setOutput={setOutput} /></>
        );
    }
    else if (Operationtext === 'REPLACE') {
        return (
            <><OperationREPLACE TableAlias={TableAlias} Operationtext={Operationtext} TextValue={TextValue} setOutput={setOutput} /></>
        );
    }
    else {
        return (
            <></>
        );
    }


}

const OperationsComponent = ({ TableAlias, SelectedTextValue, setOutput }) => {

    let selected = SelectedTextValue === undefined ? '' : SelectedTextValue;

    const TextValue = selected !== '' ? selected.label : '';
    const [OperationsList, setOperationsList] = useState([]);
    const [selectedOperation, setselectedOperation] = useState({ value: '0', label: 'Select' });

    const GetOperations = useQuery(['spGetOperations'], APIGetOperations, {
        /*enabled:false,*/
        onSuccess: (data) => {
            if (data !== null || data.length > 0) {
                // console.log(data);
                setOperationsList(data);
            }
        },
        onerror: (error) => {
            console.log('spGetOperations', error);
        }
    });

    useEffect(() => {

        GetOperations.refetch();

    }, [])


    if (OperationsList.length > 0 && typeof (TextValue) === 'string') {

        return (
            <>
                <div className="CaseModal-Basic-operations-group-DropDown">
                    <SelectComponent
                        label={'Operations'}
                        value={selectedOperation}
                        options={OperationsList.map(x => (
                            {
                                value: x.value,
                                label: x.label
                            }
                        ))}
                        onChange={setselectedOperation}
                    />
                </div>
                <div className="CaseModal-Basic-operations-group-DropDown">
                    <OperationType TableAlias={TableAlias} Operation={selectedOperation} setOutput={setOutput} TextValue={TextValue} />
                </div>
            </>
        )
    }
    else {

        return null
    }
};

export default OperationsComponent