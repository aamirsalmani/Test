import React, { useEffect, useRef, useState } from 'react'
import SearchIcon from '../../../Utility/assets/Icons/SearchIcon'
import './Search.css'

const useDebouncedValue = (inputValue, delay) => {
    const [debouncedValue, setDebouncedValue] = useState(inputValue);

    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedValue(inputValue);
        }, delay);

        return () => {
            clearTimeout(handler);
        };
    }, [inputValue, delay]);

    return debouncedValue;
};

const SearchBar = ({onChange}) => {
    const [value, setValue] = useState('');
    const [isFocus,setisFocus] = useState(false);
    const debouncedSearchTerm = useDebouncedValue(value, 500);
    useEffect(()=>{
        onChange(debouncedSearchTerm);
    },[debouncedSearchTerm])

    return (
        <div className='SearchBar' onFocus={()=>(setisFocus(true))} onBlur={()=>(setisFocus(false))}>
            <span>
                <SearchIcon color={isFocus ? `#5da9f0`:`#dfdfdf`} height='20px' width='20px' />
            </span>
            <input className='SearchInput' type='search' placeholder='Searchbar'  
                onChange={(e)=>{setValue(e.target.value);}}
            />
        </div>
    )
}

export default SearchBar