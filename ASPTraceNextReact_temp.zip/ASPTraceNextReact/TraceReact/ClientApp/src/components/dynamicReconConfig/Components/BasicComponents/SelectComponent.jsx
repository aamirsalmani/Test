﻿import React from 'react';
import Select from 'react-select';

const SelectComponent = React.memo(({
    label = null,
    id,
    value,
    options,
    onChange,
    classNamePrefix = 'reactSelectBox',
}) => {
    if (label === null) {
        return (
            <>
                <div className="clientNameSelect col">
                    <Select
                        id={id}
                        value={value}
                        classNamePrefix={classNamePrefix}
                        options={options.map((x) => ({
                            value: x.value,
                            label: x.label,
                        }))}
                        onChange={onChange}
                    />
                </div>
            </>
        )
    }
    return (
        <div className="clientNameSelect col">
            <label htmlFor={id}>{label}</label>
            <span className="text-danger font-size13">*</span>
            <Select
                id={id}
                value={value}
                classNamePrefix={classNamePrefix}
                options={options.map((x) => ({
                    value: parseInt(x.value, 10),
                    label: x.label,
                }))}
                onChange={onChange}
            />
        </div>
    );
});

export default SelectComponent;
