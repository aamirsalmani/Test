import React, { forwardRef } from 'react'
import './Tags.css'

//backgroundColor="#cdcdcd",AccentColor="#8f8f8f"
const Tags = forwardRef(({backgroundColor,AccentColor,className,...props},ref) => {
    return (
        <span {...props} className={className ? className :'styled-tag-grey' }
        style={backgroundColor===undefined || AccentColor ===undefined ? {}:{backgroundColor:backgroundColor,color:AccentColor}}
        >
        {props.children}
        </span>
    )
})

export default Tags