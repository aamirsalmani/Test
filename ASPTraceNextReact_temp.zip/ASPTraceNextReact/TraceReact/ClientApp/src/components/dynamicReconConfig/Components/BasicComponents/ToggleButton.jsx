import PropTypes from "prop-types";
import React, { useState } from "react";
import "./ToggleStyle.css";

export const ToggleButton = ({ title='Multiple Tables',toggle,setToggle, className, frameClassName }) => {
    

    const handleClick = () => {
        setToggle(!toggle);
    };

    return (
        <>
            <div className="toggle-container">
                <div className="toggle-title">
                    {title}
                </div>
                <button
                    className={`toggle-button toggle-${toggle} ${className}`}
                    onClick={handleClick}
                >
                    <div className={`frame ${frameClassName}`}>
                    </div>
                </button>
            </div>
        </>
    );
};

ToggleButton.propTypes = {
    toggle: PropTypes.bool,
    className: PropTypes.string,
    frameClassName: PropTypes.string,
    ellipseClassName: PropTypes.string,
};
