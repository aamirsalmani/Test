// Filename: ./components/ToggleSwitch.js

import React, { forwardRef, useEffect, useRef, useState } from "react";
import "./ToggleSwitch.css";
import { useFormContext } from "react-hook-form";


const ToggleSwitch = ({ label,onValueChange, SwitchDefault,props }):any => {
	const ref = useRef<any>();
	const isChecked = ref.current ? ref.current.checked ? true:false:SwitchDefault;


	return (
		<div className="toggle-container">
			<div className="toggle-title">
				{label}
			</div>
			<div>
				<label style={{ cursor: 'pointer' }} htmlFor={'check'}
					>
					{isChecked ?
						<SwitchON sizeX={0.7} />
						: <SwitchOFF sizeX={0.7} />
					}
				</label>
				<input id={'check'} ref={ref} type="checkbox" defaultChecked={SwitchDefault} 
				style={{display:'none'}} onChange={onValueChange}
				{...props}/>
			</div>
		</div>
	);
};



const SwitchON = ({ width = 62, height = 37, sizeX = 1 }):any => (
	< >
		<svg width={`${width * sizeX}`} height={`${height * sizeX}`} viewBox="0 0 62 37" fill="none" xmlns="http://www.w3.org/2000/svg">
			<rect x="1.13889" y="1.63895" width="59.2222" height="34.1667" rx="17.0833" fill="#73C96B" />
			<rect x="1.13889" y="1.63895" width="59.2222" height="34.1667" rx="17.0833" stroke="#CECECE" stroke-width="2.27778" />
			<circle cx="43.2778" cy="18.7223" r="15.9444" fill="white" />
		</svg>

	</>
)


const SwitchOFF = ({ width = 62, height = 37, sizeX = 1 }):any => {
	return (<>
		<svg width={`${width * sizeX}`} height={`${height * sizeX}`} viewBox="0 0 62 37" fill="none" xmlns="http://www.w3.org/2000/svg">
			<rect x="1.13889" y="1.63895" width="59.2222" height="34.1667" rx="17.0833" fill="#CECECE" />
			<rect x="1.13889" y="1.63895" width="59.2222" height="34.1667" rx="17.0833" stroke="#CECECE" stroke-width="2.27778" />
			<circle cx="18.2222" cy="18.7223" r="15.9444" fill="white" />
		</svg>

	</>);
}
export default ToggleSwitch;
