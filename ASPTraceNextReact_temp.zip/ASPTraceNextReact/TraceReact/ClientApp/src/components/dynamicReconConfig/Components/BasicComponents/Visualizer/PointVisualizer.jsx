import React from 'react'
import { extractCoordinates } from '../../../Functions/ExtractCoordinates';


const Dot = ({ x, y }) => {
    return <circle cx={x} cy={y} r="5" fill="red" />;
};




const PointVisualizer = ({ positions }) => {
    const coordinates = extractCoordinates(positions);

    return (
        <>
            {/* <div>{JSON.stringify(positions)}</div> */}
            <svg style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
                {coordinates.map((pos, index) => (
                    <Dot key={index} x={pos.x} y={pos.y} />
                ))}
            </svg>
        </>
    );
};

export default PointVisualizer