import React, { useState } from 'react';
import './Base.css'; // Import CSS file for styling
import * as CT from '../../../BasicComponents/CustomTable/CustomTable'
import SelectComponent from '../../../BasicComponents/SelectComponent';
import { useDispatch, useSelector } from 'react-redux';
import { UpdateMergeTable, selectActiveTab, selectActiveTabColumns, selectUnmatchedTable, updateUnmatchTable } from '../../../../Redux/Reducers/FormReducer';
import CustomTable from '../../../BasicComponents/CustomTable/CustomTableTemplate';
import { setModal } from '../../../../Redux/Reducers/ModalReducer';
import usePostForm from '../../../../hooks/usePostForm';

// Sample data
const table1Data = [
    { Alias: 'ClientID', Option: { value: 0, label: 'select' } }
    , { Alias: 'ChannelID', Option: { value: 0, label: 'select' } }
    , { Alias: 'ModeID', Option: { value: 0, label: 'select' } }
    , { Alias: 'TerminalId', Option: { value: 0, label: 'select' } }
    , { Alias: 'ReferenceNumber', Option: { value: 0, label: 'select' } }
    , { Alias: 'CardNumber', Option: { value: 0, label: 'select' } }
    , { Alias: 'CardType', Option: { value: 0, label: 'select' } }
    , { Alias: 'TxnsValueDateTime', Option: { value: 0, label: 'select' } }
    , { Alias: 'TxnsDateTime', Option: { value: 0, label: 'select' } }
    , { Alias: 'TxnsAmount', Option: { value: 0, label: 'select' } }
    , { Alias: 'ActualTxnsAmount', Option: { value: 0, label: 'select' } }
]

const DynamicCell = ({ ColumnType, CellData, ddlOptions, setSelectedOption, onRedirect }) => {

    const [EditColor, setEditColor] = useState('#518f54');

    if (ColumnType === 'Option' && ddlOptions.length > 0) {
        return (
            <>
                <SelectComponent
                    id={`ddl${ColumnType}`}
                    value={CellData}
                    options={ddlOptions.map(x => (
                        {
                            value: x.value,
                            label: x.label
                        }
                    ))}
                    onChange={setSelectedOption}
                />
            </>
        );
    }
    else {
        return (<>{CellData}</>);
    }
}


const Base = () => {
    
    const TableName = useSelector(selectActiveTab);
    const TableData = useSelector(selectUnmatchedTable);
    const ddlOptions = useSelector(selectActiveTabColumns);
    const dispatch = useDispatch();
    const [isLoading, setIsLoading] = useState(true);
    const { SubmitForm } = usePostForm(); 

    const setTableData = (prop) =>{   
        dispatch(UpdateMergeTable({ TableName:TableName, Value:prop }));
    }


    const handleColumnSelect = (Option, matchValue) => {
        const newColumns = [...TableData].map((item) => {
            if (item.Alias === matchValue) {
                return { ...item, Option: Option }
            }
            else
                return { ...item };
        })
        setTableData(newColumns);
    };

    if (ddlOptions.length === 0) {
        return (<>
                <div className="local-loading-spinner">
                </div>
        </>);
    }
    else if(ddlOptions.length>0){
        return(
        <CustomTable TableData={TableData} JoinTable={null}  GetOutputTable={setTableData} setIsModalVisible={()=>{
            dispatch(setModal({ActiveModal: 'CaseModal', IsVisible: true}))
        }} />
        );
    }
    else
    return (
        <CT.Table>
            <CT.TableHeader>
                <CT.TableRow>
                    {Object.keys(TableData[0]).map((column, index) => (
                        <CT.TableHead key={index}>{column}</CT.TableHead>
                    ))}
                    <CT.TableHead >{`Data`}</CT.TableHead>
                </CT.TableRow>
            </CT.TableHeader>
            <CT.TableBody>
                {
                    TableData.map((row, index) => (
                        <CT.TableRow>
                            {
                                Object.keys(row).map((column) => (
                                    <CT.TableCell>
                                        <DynamicCell CellData={row[column]}
                                            ColumnType={column}
                                            ddlOptions={ddlOptions}
                                            setSelectedOption={(prop) => (handleColumnSelect(prop, row.Alias))}
                                        />
                                    </CT.TableCell>
                                ))
                            }
                            <CT.TableCell>
                                {row.Option.value}
                            </CT.TableCell>
                        </CT.TableRow>
                    ))
                }
            </CT.TableBody>

        </CT.Table>
    );
};

export default Base;
