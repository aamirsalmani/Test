import React from 'react'
import Base from './Base'

const MergeConfigurationPanel = () => {
    return (
        <>
        <div style={{display:'flex',alignItems:'center',flexDirection:'column'}}>
        <Base />
        </div>
        </>
    )
}

export default MergeConfigurationPanel