import React from 'react';
import './ConfigurationGroup/ConfigurationPanel.css';
import MergeConfigurationPanel from './ConfigurationGroup/MergeConfigurationPanel';
import { useEffect } from 'react';
import { UpdateMergeTable, selectActiveTab, selectIsConfigVisible, selectJoinForm, updateActiveTabColumns, updateUnmatchTable } from '../../../Redux/Reducers/FormReducer';
import UseGetAPI from '../../../hooks/useGetAPI';
import { useDispatch, useSelector } from 'react-redux';
import { setJoinTables } from '../../../Redux/Reducers/WizardReducer';
import { selectChannelID } from '../../../Redux/Reducers/MenuBarReducer';

const ConfiurationPanel = () => {
    const TableName = useSelector(selectActiveTab);
    const ChannelID = useSelector(selectChannelID);
    const JoinForm = useSelector(selectJoinForm);
    const IsConfigVisible = useSelector(selectIsConfigVisible);
    const dispatch = useDispatch();
    useEffect(() => {
        (async () => {

            if (TableName) {

                const data = await UseGetAPI('api/DynamicReconConfig/GetTablesColumns', { TableName: TableName });
                if (data.length > 0) {
                    // let ListData = data.map((item) => ({value:`${item.value}`,label:item.label}));
                    dispatch(updateActiveTabColumns(data));
                    let dt = [{ TableName: { value: 1, label: TableName }, Options: data }]
                    dispatch(setJoinTables(dt));
                }

                const JSONData = await UseGetAPI('api/DynamicReconConfig/GetUnmatchedAllColumns', { ChannelID: ChannelID?.value });

                const UnmatchedData = JSON.parse(JSONData);

                if (UnmatchedData !== null) {
                    const HasMergeTable = [...JoinForm].filter((item) => (item.TableName?.label === TableName && Object.keys(item).includes('MergeTable')));
                    const Table = HasMergeTable.length > 0 ? HasMergeTable[0].MergeTable : UnmatchedData.map((item) => ({ ...item, CaseStatement: item.CaseStatement }));
                    let Final = [...Table].map((item) => ({ ...item }));

                    dispatch(UpdateMergeTable({ TableName: TableName, Value: Final }));
                }
            }

        })()
    }, [TableName])

    if (TableName === undefined || TableName === null || !IsConfigVisible) {
        return (<></>);
    }

    return (
        <>
            <div className='ReconConfig-MainContainer'>
                <div className='Panel-Container'>
                    <div className="Panel-Container-Header">
                        Configuration Panel
                    </div>
                    <div className="Panel-Container-Body">
                        <div className="Configuration-panel">
                            <MergeConfigurationPanel />
                        </div>
                    </div>
                    <div className="Panel-Container-Footer">

                    </div>
                </div>
            </div>
        </>
    )
}

export default ConfiurationPanel