import React, { useEffect, useState } from 'react'
import FinalQuery from './QueryGroup/FinalQuery'
import FooterPanel from './FooterPanel'
import UseGetAPI from '../../../hooks/useGetAPI';
import { useDispatch, useSelector } from 'react-redux';
import { selectMenuParams } from '../../../Redux/Reducers/MenuBarReducer';
import { setAlertMessageBox } from '../../../Redux/Reducers/AlertMessageReducer';

const FinalQueryPanel = () => {
    const ReconParams = useSelector(selectMenuParams);
    const [isLoading, setIsLoading] = useState(true);
    const [QueryData, setQueryData] = useState('');
    const dispatch = useDispatch();
    useEffect(() => {
        (async () => {
            const Data = await UseGetAPI('api/DynamicReconConfig/GenerateReconQuery', ReconParams);
            if (Data !== null) {
                setQueryData(Data);
                setIsLoading(false);
            }
        })()
    }, [])


    if (isLoading) {
        return (<></>);
    }
    return (
        <>
            <FinalQuery QueryData={QueryData} />
            <FooterPanel />
        </>
    )
}

export default FinalQueryPanel