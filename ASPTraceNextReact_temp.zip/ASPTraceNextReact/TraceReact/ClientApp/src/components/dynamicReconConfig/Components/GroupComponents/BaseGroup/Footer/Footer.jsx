import React from 'react'
import { Modern, Primary } from '../../../BasicComponents/Button';
import { useDispatch, useSelector } from 'react-redux';
import { selectJoinForm } from '../../../../Redux/Reducers/FormReducer';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight1 } from '../../../../Utility/assets/Icons/iconsIndex';
import { selectIsWizardVisible } from '../../../../Redux/Reducers/WizardReducer';
import UseGetAPI from '../../../../hooks/useGetAPI';
import { selectMenuParams } from '../../../../Redux/Reducers/MenuBarReducer';
import { setModal } from '../../../../Redux/Reducers/ModalReducer';
import { setAlertMessageBox } from '../../../../Redux/Reducers/AlertMessageReducer';

const IsComplete = (Table) => {
    try {
        const localTable = [...Table].filter((item) => (item.Status.IsComplete === false))
        const isComplete = localTable.length === 0 ? true : false;

        return isComplete;
    }
    catch (error) {
        return false;
    }
}

const Footer = () => {
    const Table = useSelector(selectJoinForm);
    const isVisible = useSelector(selectIsWizardVisible);
    const ReconParams = useSelector(selectMenuParams);
    const { id } = useParams();
    const nav = useNavigate();
    const dispatch = useDispatch();

    const onSubmit = async() => {
        let isComplete = IsComplete(Table);
        if (isComplete) {
            const Data = await UseGetAPI('api/DynamicReconConfig/GenerateReconQuery', ReconParams);
            if (Data.includes('Error')) {
                let alertMessages = Data;
                dispatch(setAlertMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages }))

            }
            else{

                dispatch(setModal({ActiveModal: 'SuccessModal', IsVisible: true}))
            }
            
        }
    }

    //const onSubmit = (step) => {
    //    let isComplete = IsComplete(Table);
    //    if (isComplete) {
    //        let NextPage = parseInt(id) + parseInt(step);
    //        if (NextPage > 0 && NextPage < 3)
    //            nav(`../${NextPage}`);
    //    }
    //}

    if (!isVisible) {
        return (<></>);
    }
    if (isVisible) {
        return (
            <div className='Footer'>
                <Modern onClick={() => (onSubmit(1))} >
                    <span>Submit</span>
                </Modern>
            </div>
        );
    }
    else
        return (
            <div className='Footer'>
                {
                    id <= 1 ? <></> :
                        <Modern onClick={() => (onSubmit(-1))} >
                            <span><ArrowLeft /></span>
                            <span>Back</span>
                        </Modern>
                }
                {
                    id === '2' ?
                        <Modern onClick={() => (onSubmit(1))} >
                            <span>Submit</span>
                            {/* <span><ArrowRight1 /></span> */}
                        </Modern>
                        :
                        <Modern onClick={() => (onSubmit(1))} >
                            <span>Next</span>
                            <span><ArrowRight1 /></span>
                        </Modern>
                }
            </div>
        )
}

export default Footer