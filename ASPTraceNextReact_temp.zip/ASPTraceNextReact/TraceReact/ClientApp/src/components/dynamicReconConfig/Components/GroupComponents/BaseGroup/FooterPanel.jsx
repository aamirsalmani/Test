import React from 'react'
import Footer from './Footer/Footer'
import './Footer/Footer.css'

const FooterPanel = () => {
  return (
    <div className='FooterPanel'>
      <Footer />
    </div>
  )
}

export default FooterPanel