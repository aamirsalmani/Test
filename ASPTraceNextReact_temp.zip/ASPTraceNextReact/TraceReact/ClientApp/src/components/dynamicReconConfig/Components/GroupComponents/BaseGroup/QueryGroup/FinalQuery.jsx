import React, { useState } from 'react'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import * as themes from 'react-syntax-highlighter/dist/esm/styles/prism';
import SelectComponent from '../../../BasicComponents/SelectComponent';

const styles = {
    maxWidth: '1300px',
    overflowX: 'auto',
    fontSize: '0.8rem'
};

const ThemeOption = ({ label, selected, onChange }) => {
    console.log('themes', Object.keys(themes));

    return (<div className="ThemePanel" style={{ display: 'flex', maxWidth:'15rem' }} >
        <SelectComponent
            label={label}
            id={`ddl${'Theme'}`}
            value={selected}
            options={Object.keys(themes).map((x, i) => (
                {
                    value: i,
                    label: x
                }
            ))}
            onChange={onChange}
        />
    </div>)
}

const Panel = ({ QueryData, theme }) => {

    return (<div className="Panel">

        <SyntaxHighlighter wrapLines={true} wrapLongLines={true} customStyle={styles}
            language="sql" style={themes[theme]}>
            {QueryData}
        </SyntaxHighlighter>
    </div>)
}

const FinalQuery = ({ QueryData }) => {

    const [selected, setSelected] = useState({ value: 0, label: 'select' });

    return (
        <div className='ReconConfig-MainContainer'>
            <div className='Panel-Container'>
                <div className="Panel-Container-Header">
                    Query Panel
                </div>
                <div className="Panel-Container-Body">
                    <ThemeOption label={'Theme'} selected={selected} onChange={setSelected} />
                    <Panel QueryData={QueryData} theme={selected.label} />
                </div>
                <div className="Panel-Container-Footer">

                </div>
            </div>
        </div>
    )
}

export default FinalQuery