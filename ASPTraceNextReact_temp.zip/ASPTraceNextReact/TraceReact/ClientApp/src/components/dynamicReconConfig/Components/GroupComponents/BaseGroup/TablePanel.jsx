import React, { Children, useEffect, useState } from 'react'
import Base from './TablesGroup/Base';
import { Outlet } from 'react-router-dom';
import { GetAPI } from '../../../API/MenuAPIcalls';
import { useDispatch, useSelector } from 'react-redux';
import { selectJoinForm, updateJoinForm } from '../../../Redux/Reducers/FormReducer';
const data = [
  { TableName: { value: 0, label: 'Select' }, JoinColumns: 'Add Join Columns here' }
]

const TablePanel = () => {
  const [isLoading, setIsLoading] = useState(true);
  const TableData = useSelector(selectJoinForm)
  const dispatch = useDispatch();

  const setTableData = (prop) =>{
    dispatch(updateJoinForm(prop));
  }

  useEffect(()=>{
    if(TableData !== undefined){
      setIsLoading(false);
    }
  },[])
  
  

  if (isLoading) {
    return (<></>);
  }
  else
    return (
      <>
        <div className='ReconConfig-MainContainer'>
          <div className='Panel-Container'>
            <div className="Panel-Container-Header">
              Table Configuration
            </div>
            <div className="Panel-Container-Body">
              <Base
                TableData={TableData} setTableData={setTableData}/>
            </div>
            <div className="Panel-Container-Footer">

            </div>
          </div>
        </div>
      </>
    )
}

export default TablePanel