import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import * as CT from '../../../BasicComponents/CustomTable/CustomTable'
import { IconEdit, AddIcon, RemoveIcon, CheckCircleIcon } from '../../../../Utility/assets/Icons/iconsIndex';
import SelectComponent from '../../../BasicComponents/SelectComponent';
import './DynamicCell.css'
import { useNavigate, useParams } from 'react-router-dom';
import { setModal } from '../../../../Redux/Reducers/ModalReducer';
import { InitialJoinForm, selectActiveTab, selectFormData, updateActiveJoin, updateActiveTab, updateConfigVisibility, updateJoinForm } from '../../../../Redux/Reducers/FormReducer';
import PostForm from '../../../../hooks/PostForm';
import { selectMenuState } from '../../../../Redux/Reducers/MenuBarReducer';
import usePostForm from '../../../../hooks/usePostForm';
import Tags from '../../../BasicComponents/Tag/Tags';
import { selectRawTablesList } from '../../../../Redux/Reducers/CommonReducer';

// const options = [{ value: 1, label: 'EJData' }, { value: 2, label: 'GLData' }, { value: 3, label: 'SwitchData' }]

const DynamicCell = ({ ColumnType, CellData, ddlOptions, setSelectedOption, onRedirect }) => {

    const [EditColor, setEditColor] = useState('#518f54');

    if ((ColumnType === 'TableName' || ColumnType === 'OrderNo') && ddlOptions.length > 0) {

        return (
            <>
                <SelectComponent
                    id={`ddl${ColumnType}`}
                    value={CellData}
                    options={ddlOptions.map(x => (
                        {
                            value: x.value,
                            label: x.label
                        }
                    ))}
                    onChange={(prop) => (setSelectedOption(ColumnType,prop))}
                />
            </>
        );
    }
    else if (ColumnType === 'JoinColumns') {
        return (<div className='JoinColumns'>
            <span>{CellData}</span>
            <span onClick={onRedirect}
                // onMouseEnter={() =>(setEditColor('#FFF'))}  onMouseLeave={()=>(setEditColor('#518f54'))}
                className='JoinColumns-Modal-link'>
                <IconEdit color={EditColor} />
            </span>
        </div>);
    }
    else if (ColumnType === 'Status') {
        const { IsActive, IsComplete } = CellData;
        const Tagprops = { backgroundColor: IsActive ? `#E1FDEC` : `#f6f8fa`, AccentColor: IsActive ? `#40724f` : `#8f8f8f` };
        const IconProps = { backgroundColor: IsComplete ? `#95e194` : `#cfcfcf`, foregroundColor: IsComplete ? `#40724f` : `#8f8f8f` }
        return (
            <Tags {...Tagprops}>
                <span >{`Active`}</span>
                <span style={{ marginLeft: '5px' }}>
                    <CheckCircleIcon {...IconProps} />
                </span>
            </Tags>
        );
    }
    else {
        return (<>{CellData}</>);
    }
}


const Base = ({ TableData ,setTableData}) => {
    const dispatch = useDispatch();
    const TableName = useSelector(selectActiveTab);
    const MenuState = useSelector(selectMenuState);
    const defaultData = InitialJoinForm;
    const [localheaders, setLocalheaders] = useState(Object.keys(TableData[0]));
    const Tableoptions = useSelector(selectRawTablesList)
    const { SubmitForm } = usePostForm();
    
    
    const localTable = TableData;
    const setLocalTable = (data) =>{
        setTableData(data); 
    }

    const GetOptions = (ColumnName) => {
        if (ColumnName === 'TableName') {
            return Tableoptions;
        }
        else if (ColumnName === 'OrderNo') {
            let Temp = localTable.filter((item) => item.TableName.label !== 'Select');
            let OrderOptions = Array(Temp.length).fill().map((_, index) => ({ value: index + 1, label: `${index + 1}` }));

            return OrderOptions.length > 0 ? OrderOptions : [{ value: 0, label: 'No Options' }];
        }
        else {

            return [{ value: 0, label: 'No Options' }];
        }
    }

    useEffect(() => {
        setLocalTable(TableData);
    }, [TableData])

    const ChangeStatus = (row, status) => {
        let dt = localTable.map((item, r) => {
            if (r === row) {
                return { ...item, Status: { ...item.Status, ...status } }
            }
            else {
                return { ...item, Status: { ...item.Status, IsActive: false } }
            }
        })

        setLocalTable(dt)

    }

    const ChangeDataColumn = (ColumnType,row, data) => {

        let dt = localTable.map((item, r) => {
            if (r === row) {
                let obj = JSON.parse(`{"${ColumnType}":${JSON.stringify(data)}}`);
                return { ...item, ...obj }
            }
            else {
                return { ...item }
            }
        })

        setLocalTable(dt)

    }
    const AddButtonClick = (index) => {
        let Val = { ...defaultData[0] };
        let dt = [...localTable]
        dt.splice(index + 1, 0, Val);
        setLocalTable(dt);
        dispatch(updateConfigVisibility(false));
    }
    const DeleteButtonClick = (value) => {
        let dt = [...localTable].filter((item, i) => i !== value);
        if (dt.length === 0) {
            setLocalTable(TableData);

        }
        else
            setLocalTable(dt)

    }

    const EditButtonClick = async ({ value, index }) => {

        if (value !== 'Select' && value !== null) {
           
            ChangeStatus(index, { IsActive: true })
            dispatch(updateActiveTab(value));
            dispatch(updateConfigVisibility(true));
        }
        else {

        }

    }

    if (localTable.length === 0) {
        return (<></>)
    }
    else
        return (
            <>
                <CT.Table >
                    <CT.TableHeader>
                        <CT.TableRow >
                            {localheaders.map((item, i) => {
                                if (item === 'MergeTable' || item === 'conditions' || item === 'MergeConditions' ) {
                                    return (<></>);
                                }
                                else
                                    return (
                                        <>
                                            <CT.TableHead key={`${i}`} style={{ width: item === 'JoinColumns' ? `100%` : `200px` }}>
                                                <div style={{ fontSize: '0.9rem', fontWeight: '600' }}>{item}</div>
                                            </CT.TableHead>
                                        </>
                                    )
                            }
                            )}
                            <CT.TableHead style={{ width: `200px` }}>
                                <div style={{ fontSize: '0.9rem', fontWeight: '600' }}>{`Actions`}</div>
                            </CT.TableHead>
                        </CT.TableRow>
                    </CT.TableHeader>
                    <CT.TableBody>
                        {
                            localTable.map((tr, i) => (
                                <>
                                    <CT.TableRow key={`${i}`}>
                                        {localheaders.map((tc, j) => {
                                            if (tc === 'MergeTable' || tc === 'conditions'|| tc === 'MergeConditions' ) {
                                                return (<></>);
                                            }
                                            else
                                                return (
                                                    <>
                                                        <CT.TableCell key={`${i}${j}`}>
                                                            {
                                                                <div className={tc === 'JoinColumns' ? `case-statement` : ``}
                                                                    style={{ fontSize: '0.8rem', fontWeight: '400' }}
                                                                >
                                                                    <DynamicCell CellData={tr[tc]} ColumnType={tc} onRedirect={() => {
                                                                        dispatch(updateActiveJoin(tr[tc]))
                                                                        dispatch(updateJoinForm(localTable));
                                                                        dispatch(updateActiveTab(tr.TableName?.label));
                                                                        dispatch(setModal({ ActiveModal: 'TableColumnsModal', IsVisible: true }))
                                                                    }}
                                                                        ddlOptions={GetOptions(tc)} setSelectedOption={(ColumnType,data) => 
                                                                            {ChangeDataColumn(ColumnType,i, data);}
                                                                        }
                                                                    />
                                                                </div>
                                                            }
                                                        </CT.TableCell>

                                                    </>
                                                )
                                        })}
                                        <CT.TableCell >
                                            <div className='custom-Actions-Menu'>
                                                <button type='button' className='custom-edit-button'
                                                    onClick={() => { EditButtonClick({ value: tr.TableName?.label, index: i }) }}
                                                >
                                                    <IconEdit />

                                                </button>
                                                <button type='button' className='custom-edit-button'
                                                    onClick={() => { AddButtonClick(i) }}
                                                >
                                                    <AddIcon />
                                                </button>
                                                <button type='button' className='custom-edit-button'
                                                    onClick={() => { DeleteButtonClick(i) }}
                                                >
                                                    <RemoveIcon />
                                                </button>
                                            </div>
                                        </CT.TableCell>
                                    </CT.TableRow>
                                </>
                            ))
                        }
                    </CT.TableBody>
                </CT.Table>
            </>
        )
}

export default Base