import React, { Children, useEffect } from 'react'
import './MainContainer.css'
import { useSelector } from 'react-redux'
import { selectIsWizardVisible } from '../../../Redux/Reducers/WizardReducer'
import TablePanel from '../BaseGroup/TablePanel'
import ConfigurationPanel from '../BaseGroup/ConfigurationPanel'
import FooterPanel from '../BaseGroup/FooterPanel'


const MainContainer = ({onToggleMenu}) => {

    const isVisible = useSelector(selectIsWizardVisible);

    useEffect(()=>{
        if(isVisible === true)
        onToggleMenu();
    },[isVisible])

    if (!isVisible) {
        return (<></>);
    }
    return (
        <>
            <TablePanel />
            <ConfigurationPanel />       
            <FooterPanel />   
        </>
    )
}

export default MainContainer