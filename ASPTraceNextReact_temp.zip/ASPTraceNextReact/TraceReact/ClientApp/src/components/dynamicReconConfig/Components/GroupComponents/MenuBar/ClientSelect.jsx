import React, { useState } from "react";
import AsyncSelect from 'react-select/async';
import { useDispatch, useSelector } from "react-redux";
import { fetchClientData } from '../../../API/MenuAPIcalls';
import {selectClientID,setChannel,setClient,setMode, setNetworkType, setOptionsChannelType,
    setOptionsModeType, setOptionsNetworkType, setOptionsReconType, setReconType
} from '../../../Redux/Reducers/MenuBarReducer'
import UseGetAPI from "../../../hooks/useGetAPI";




const ClientSelect = () => {
    const dispatch = useDispatch();
    const currentUser = useSelector((state) => state.authReducer);
    const clientID = useSelector(selectClientID);
    const user = currentUser?.user?.username
    const [InputValue,setInputValue] = useState('');
    const handleInputChange = value => {
        setInputValue(value);
    };

    const handleClientChange = async (value) => {
        try {
            if (value.clientID !== '0') {
                console.log(value.clientID);
                dispatch(setClient(value))

                const reconTypesData = await UseGetAPI('api/ReconConfig/GetReconType', {});
                const channelFieldListData = await UseGetAPI('api/ReconConfig/GetChannelFieldList', {ClientID:value.clientID});
                const modeFieldListData = await UseGetAPI('api/ReconConfig/GetModeFieldList', {ClientID:value.clientID,ChannelID:0});                
                const data = await UseGetAPI('api/DynamicReconConfig/GetNetworkList', {ClientID: value.clientID});
        
                if (data !== null || data.length > 0) {
                    dispatch(setOptionsNetworkType(data))
                    dispatch(setNetworkType({ value: "0", label: "All" }));
                }

                if (reconTypesData !== null || reconTypesData.length > 0) {
                    dispatch(setOptionsReconType(reconTypesData));
                    dispatch(setReconType({ value: "0", label: "All" }));
                }
                if (channelFieldListData !== null || channelFieldListData.length > 0) {
                    dispatch(setOptionsChannelType(channelFieldListData));
                    dispatch(setChannel({ value: "0", label: "All" }));

                }
                if (modeFieldListData !== null || modeFieldListData.length > 0) {
                    dispatch(setOptionsModeType(modeFieldListData));
                    dispatch(setMode({ value: "0", label: "All" }));

                }
            }
        } catch (error) {
            console.error(error);
        }
    };

    return (
        <div className="clientNameSelect col">
            <label htmlFor="clientName">Client Name</label>
            <span className="text-danger font-size13">*</span>
            <AsyncSelect
                cacheOptions
                defaultOptions
                value={clientID}
                getOptionLabel={e => e.clientName}
                getOptionValue={e => e.clientID}
                loadOptions={(i) => (fetchClientData(i, user))}
                onInputChange={handleInputChange}
                onChange={handleClientChange}
                id="ddlClient"
            />
        </div>
    );
};

export default ClientSelect;
