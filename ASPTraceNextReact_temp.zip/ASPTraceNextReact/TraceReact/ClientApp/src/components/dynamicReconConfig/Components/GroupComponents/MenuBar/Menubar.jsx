//Imports
// Library 

import { Link, useNavigate } from "react-router-dom";
import Select from "react-select";

import React, { useState, useContext, useEffect, useRef, forwardRef } from "react";
import { error } from 'jquery';

// AUTH 
import { useDispatch, useSelector } from "react-redux";

//redux
import {
    selectChannelID, selectClientID, selectModeID, selectOptionsChannelType, selectOptionsModeType, selectOptionsReconType
    , selectReconType, setChannel, setMode, setOptionsModeType, setReconType, setSelectedTables, selectedTables, selectOptionsNetworkType, selectNetworkType, setNetworkType, setOptionsNetworkType, setInitializeValues,
    setHasPreset,
    setMenuParams
} from '../../../Redux/Reducers/MenuBarReducer'

//components
import { useGetQuery, usePostMutation } from '../../../API/ReactQueryFunctions';
import ClientSelect from './ClientSelect'

//Data and API
import { ArrowDown, CloseButton, RightArrow } from '../../../Utility/assets/Icons/iconsIndex';
import SelectComponent from '../../BasicComponents/SelectComponent';

//Functions

import { pushValueNTimes } from '../../../API/UtilityFunctions';
import { setAlertMessageBox, setIsLoadingSpinner } from '../../../Redux/Reducers/AlertMessageReducer';
import { setIsWizardVisible, setTabData } from '../../../Redux/Reducers/WizardReducer';
import { setColumnsList, setJoinList, setRawTablesList } from '../../../Redux/Reducers/CommonReducer';
import { setFormDataDefault, updateForm, updateUnmatchTable } from '../../../Redux/Reducers/FormReducer';
import { GetTableJoinArray } from '../../../Functions/UtilityFunctions';
import UseGetAPI from '../../../hooks/useGetAPI';
import { setModal } from '../../../Redux/Reducers/ModalReducer';

//Imports

const JoinsList = [{ ID: 1, JoinName: 'LEFT JOIN' }, { ID: 2, JoinName: 'RIGHT JOIN' }, { ID: 3, JoinName: 'FULL JOIN' }, { ID: 4, JoinName: 'INNER JOIN' }];

const Menubar = forwardRef((props, ref) => {
    const dispatch = useDispatch();
    const [inputValue, setInputValue] = useState('0');
    const clientID = useSelector(selectClientID);
    const NetworkType = useSelector(selectNetworkType);
    const OptionsNetworkType = useSelector(selectOptionsNetworkType);
    const selectedChannelValue = useSelector(selectChannelID);
    const selectedModeValue = useSelector(selectModeID);
    const OptionsChannelType = useSelector(selectOptionsChannelType);
    const optionsModeType = useSelector(selectOptionsModeType);
    const [optionsTablesList, setOptionsTablesList] = useState([]);
    const [selectedTables, setSelectedTablesList] = useState([]);
    const currentUser = useSelector((state) => state.authReducer);
    const [toggleTables, setToggleTables] = useState(false);
    const nav = useNavigate();
    const RefMenuBar = useRef();


    const GetReconTables = async (ModeValue) => {
        const Params = {
            ChannelID: selectedChannelValue.value,
            ModeID: ModeValue.value
        }
        const data = await UseGetAPI('api/ReconConfig/GetReconTables', Params);

        if (data !== null) { setOptionsTablesList(data); }
    }

    const handleNetworkChange = async (value) => {
        dispatch(setNetworkType(value));

    }

    const handleModeChange = async (value) => {
        dispatch(setMode(value));
        // await GetReconTables(value);
        // setToggleTables(true);

    }

    const handleChannelChange = async (value) => {
        const Params = {
            ClientID: clientID.clientID,
            ChannelID: value.value
        }
        const data = await UseGetAPI('api/ReconConfig/GetModeFieldList', Params);

        if (data !== null || data.length > 0) {
            dispatch(setOptionsModeType(data))
            dispatch(setMode({ value: "0", label: "All" }));
        }
        if (value) {
            dispatch(setChannel(value));
        }
    }

    const onReset = async (e) => {
        dispatch(setIsWizardVisible(false));
        dispatch(setInitializeValues());
        dispatch(setFormDataDefault());
        nav('/configuration/dynamic-Reconciliation-config');
    }

    const onProceed = async (e) => {
        e.preventDefault();
        dispatch(setIsWizardVisible(false));
        dispatch(setIsLoadingSpinner(true));

        const Params = {
            ClientID: clientID?.clientID,
            NetworkType: NetworkType?.value,
            ChannelID: selectedChannelValue?.value,
            ModeID: selectedModeValue?.value,
        }

        dispatch(setMenuParams(Params));

        if (Object.keys(Params).map((item) => (Params[item] === '0' || Params[item] === undefined)).some(item => item === true)) {
            let alertMessages = "Please fill all the required fields";
            dispatch(setAlertMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages }))

            dispatch(setIsLoadingSpinner(false));
            return null;
        }

        const ReconParams = {
            ChannelID: selectedChannelValue.value,
            ModeID: selectedModeValue.value,
            Type: 'Recon'
        }
        const ReconTables = await UseGetAPI('api/ReconConfig/GetReconTables', ReconParams);
        if (ReconTables !== null || ReconTables.length > 0) {
            let Tables = ReconTables.map((item) => ({ value: item.tableID, label: item.rawTableName }))
            dispatch(setRawTablesList(Tables))
        }


        const data = await UseGetAPI('api/DynamicReconConfig/GetPreset', Params);
        if (data !== null && data.length > 0) {
            let ParsedData = JSON.parse(data);
            dispatch(updateForm(ParsedData));
            dispatch(setHasPreset(true));

            dispatch(setModal({ ActiveModal: 'StartupModal', IsVisible: true }));
        }
        else {
            dispatch(setModal({ ActiveModal: 'StartupModal', IsVisible: true }));

            // dispatch(setFormDataDefault());

            // const UnmatchedData = await UseGetAPI('api/DynamicReconConfig/GetUnmatchedColumns', { ChannelID: selectedChannelValue?.value });
            // if (UnmatchedData.length > 0) {
            //     // let ListData = data.map((item) => ({value:`${item.value}`,label:item.label}));
            //     let JsonObj = JSON.parse(UnmatchedData);

            //     dispatch(updateUnmatchTable(JsonObj));
            //     dispatch(setIsWizardVisible(true));
            // }
        }
        //set JOINS
        dispatch(setJoinList(JoinsList));
        dispatch(setIsLoadingSpinner(false));

        nav('/configuration/dynamic-Reconciliation-config');


    }



    return (
        <>
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Dynamic Reconciliation Configuration
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <RightArrow />
                    <p className="fontSize12 colorPrimaryDefault">Configuration</p>
                    <RightArrow />
                    <p className="fontSize12">Dynamic Reconciliation Config</p>
                </div>
            </div>
            <div className="accordion" id="unmatchedFilters">
                <div className="accordion-item">
                    <div
                        className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                        id="unmatchedFiltersHeading"
                    >
                        <h6 className="fontWeight-600 colorBlack">Filters</h6>
                        <button ref={ref}
                            className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#unmatchedFiltersCollapse"
                            aria-expanded="true"
                            aria-controls="unmatchedFiltersCollapse"
                        >
                            <span className="icon-Hide"></span>
                            <span className="ms-1 fontSize12-m colorBlack">
                                Show / Hide
                            </span>
                        </button>
                    </div>
                    <div
                        id="unmatchedFiltersCollapse"
                        className="accordion-collapse collapse show"
                        aria-labelledby="unmatchedFiltersHeading"
                        data-bs-parent="#unmatchedFilters"
                    >
                        <div className="accordion-body">
                            <div className="hrGreyLine"></div>
                            <div className="configSelectBoxTop row">
                                <ClientSelect />
                                <SelectComponent
                                    label="Network Type"
                                    id="ddlMode"
                                    value={NetworkType}
                                    options={OptionsNetworkType.map(x => (
                                        {
                                            value: x.vendorID,
                                            label: x.vendorName
                                        }
                                    ))}
                                    onChange={handleNetworkChange}
                                />
                                <SelectComponent
                                    label="Channel Type"
                                    id="ddlChannel"
                                    value={selectedChannelValue}
                                    options={OptionsChannelType.map(x => (
                                        {
                                            value: x.channelID,
                                            label: x.channelName
                                        }
                                    ))}
                                    onChange={handleChannelChange}
                                />
                                <SelectComponent
                                    label="Mode Type"
                                    id="ddlMode"
                                    value={selectedModeValue}
                                    options={optionsModeType.map(x => (
                                        {
                                            value: x.modeID,
                                            label: x.transactionMode
                                        }
                                    ))}
                                    onChange={handleModeChange}
                                />

                            </div>
                            <div className="configSelectBoxTop row">

                            </div>
                            <div className="configSelectBoxTop row" style={{ display: 'flex', flexDirection: 'row' }}>
                                <span className="clientNameSelect" style={{ width: 'unset' }}>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={(e) => onProceed(e)}
                                    >Proceed</button>
                                </span>
                                <span className="clientNameSelect" style={{ width: 'unset' }}>
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >Reset</button>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
})

export default Menubar