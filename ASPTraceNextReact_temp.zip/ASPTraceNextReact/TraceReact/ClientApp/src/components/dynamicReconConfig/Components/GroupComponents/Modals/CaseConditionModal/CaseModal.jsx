import React, { useEffect, useState } from 'react'
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import StartupPanel from '../StartupPanel/StartupPanel';
import { CloseButton } from '../../../../Utility/assets/Icons/iconsIndex'
import { useDispatch, useSelector } from 'react-redux';
import { setIsModalVisible } from '../../../../Redux/Reducers/ModalReducer';
import ReconCaseComponent from '../../../BasicComponents/ReconCaseComponent';
import { selectCaseTableData, selectClickedRow, selectJoinTables, setCaseTableData } from '../../../../Redux/Reducers/WizardReducer';
import { ToggleButton } from '../../../BasicComponents/ToggleButton';
import MultiSelectDropDown from '../../../BasicComponents/MultiSelectDropDown';
import { TableAliasList } from '../../../../Functions/functions';
import OperationsComponent from '../../../BasicComponents/OperationsComponent';
import { selectJoinForm, selectUnmatchedTable, updateJoinForm, updateUnmatchTable } from '../../../../Redux/Reducers/FormReducer';
import './CaseTable.css'
import SelectComponent from '../../../BasicComponents/SelectComponent';
import { setAlertMessageBox } from '../../../../Redux/Reducers/AlertMessageReducer';

const Basic = ({ isVisible, AliasColumn, UpdateColumnID, UpdateColumnIDFn }) => {

    const JoinTables = useSelector(selectJoinTables);

    const TableAlias = TableAliasList(JoinTables);

    const [selectedTable, setselectedTable] = useState({ value: '0', label: 'Select' });

    const [selectedOptions, setSelectedOptions] = useState({ value: '0', label: 'Select' });


    const [ddlOptions, setddlOptions] = useState([{ value: '0', label: 'No Options' }]);



    const [finalCondition, setfinalCondition] = useState('case condition will appear here');

    useEffect(() => {
        setselectedTable(TableAlias[0]);
        setColumnOptions(TableAlias[0]);
    }, [isVisible])


    const setColumnOptions = (prop) => {
        setselectedTable(prop);

        let selectedTableData = JoinTables.filter((item, i) => item.TableName.value === prop.value);
        let ddl = selectedTableData.length > 0 ? selectedTableData[0].Options : null;
        setddlOptions(ddl);
    }

    const SubmitBasic = (Table, value) => {
        if (Table) {
            let condition = `T${Table}.${value}`
            setfinalCondition(condition);
            UpdateColumnIDFn({ ID: UpdateColumnID.ID, CaseCondition: condition });
        }
        else {
            let condition = `${value}`
            setfinalCondition(condition);
            UpdateColumnIDFn({ ID: UpdateColumnID.ID, CaseCondition: condition });
        }
    }

    return (<>
        <div className="CaseModal-Basic">
            <h5>{AliasColumn}</h5>
            <div className="CaseModal-Basic-Basic-Output-Window">
                <textarea className="CaseConditionTextArea" placeholder="case condition will appear here"
                    value={finalCondition || ''}
                    readOnly
                />
            </div>
            <div className="CaseModal-Basic-Columns-group">
                <div className="CaseModal-Basic-Columns-group-DropDown">
                    <SelectComponent
                        label={'Table Name'}
                        value={selectedTable}
                        options={TableAlias.map(x => (
                            {
                                value: x.value,
                                label: x.label
                            }
                        ))}
                        onChange={(value) => {
                            setColumnOptions(value)
                            if (value && selectedOptions.value !== '0')
                                SubmitBasic(value.value, selectedOptions.label);
                        }}
                    />

                </div>
                <div className="CaseModal-Basic-Columns-group-DropDown">
                    <SelectComponent
                        label={'Column Name'}
                        value={selectedOptions}
                        options={ddlOptions.map(x => (
                            {
                                value: x.value,
                                label: x.label
                            }
                        ))}
                        onChange={(value) => {
                            setSelectedOptions(value);
                            if (value && selectedTable.value !== '0')
                                SubmitBasic(selectedTable.value, value.label);
                        }}
                    />
                </div>
            </div>
            <div className="CaseModal-Basic-operations-group">
                <OperationsComponent TableAlias={`${selectedTable.value}`} SelectedTextValue={selectedOptions} setOutput={(value) => {
                    SubmitBasic(null, value);
                }} />
            </div>
        </div>
    </>);
}

const CaseModal = ({ visible = true, setShowModal }) => {
    const [CloseOpacity, setCloseOpacity] = useState(null);
    const dispatch = useDispatch();
    const isCaseModal = visible;
    const setisCaseModal = setShowModal
    const { AliasColumn, RowIndex, Action } = useSelector(selectClickedRow);
    const TableName = useSelector((state) => state.dynamicRootReducer.ReconForm.ActiveTab);
    const JoinForm = useSelector(selectJoinForm);


    const TableData = useSelector(selectUnmatchedTable);

    const SelectedRow = TableData.filter((item, i) => item.ID === RowIndex);

    const [isAdvanced, setisAdvanced] = useState(false);

    const ModalSize = isAdvanced ? 'xl' : 'lg';

    // console.log('SelectedRow', SelectedRow, 'TableData', TableData);

    const { CaseStatement, ID } = SelectedRow[0];

    const [ColumnEditID, setColumnEditID] = useState({ ID: ID, CaseCondition: CaseStatement });

    useEffect(() => {
        setisAdvanced(false);
    }, [AliasColumn])

    useEffect(() => {
        if (ID) {

            setColumnEditID({ ID: ID, CaseCondition: CaseStatement });
        }
    }, [ID])

    let DataTable = [...TableData].map((item, i) => (
        { aliasColumn: item.AliasColumn, columnID: item.ID }));

    const ModalSubmit = (ColumnData) => {
        console.log('ColumnData', ColumnData);
        let dt = [...TableData].map((item, i) => {
            if (item.ID === ColumnData.ID)
                return { ...item, CaseStatement: ColumnData.CaseCondition }
            else
                return { ...item };
        });

        let JoinDt = [...JoinForm].map((item) => {
            if (item.TableName?.label === TableName) {
                return { ...item, MergeTable: dt }
            }
            else
                return { ...item };
        })

        let Serialized = JSON.stringify(JoinDt);

        let forbiddenKeywords = ["DROP", "TRUNCATE", "ALTER", "MASTER"];
        let WhitelistKeywords = ["MASTERCARD"];

        if (forbiddenKeywords.filter(keyword => Serialized.toLowerCase().includes(keyword.toLowerCase())).length > 0) {
            let keywords = forbiddenKeywords.filter(keyword => Serialized.toLowerCase().includes(keyword.toLowerCase()))

            let alertMessages = "";
            if (WhitelistKeywords.filter(keyword => Serialized.toLowerCase().includes(keyword.toLowerCase())).length > 0) {

            }
            else {
                alertMessages = `Error: The input contains forbidden SQL keywords like ${keywords.join(',')}`;

                dispatch(setAlertMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages }));
                setisCaseModal(!isCaseModal);
                return alertMessages;
            }


        }

        dispatch(updateJoinForm(JoinDt));
        dispatch(updateUnmatchTable(dt));
        setisCaseModal(!isCaseModal);

    }

    const Controls = ({ isAdvanced, setisAdvanced }) => {


        return (<>
            <div className="CaseModal-Controls">
                <ToggleButton
                    title="Advanced Case"
                    toggle={isAdvanced} setToggle={setisAdvanced} className="JoinTable-custom-class" frameClassName="custom-frame"
                />
            </div>
        </>);
    }

    return (
        <Modal
            show={isCaseModal}
            onHide={() => setisCaseModal(!isCaseModal)}
            centered
            size={ModalSize} //"xl"
            className="CaseConditionModal"
        >
            {/*
        <Modal.Header closeButton >
            <Modal.Title className="fontSize16-sm letterSpacing-2">
                <span>Startup Panel</span>
            </Modal.Title>
        </Modal.Header>

        onMouseEnter={() => setCloseOpacity(false)}
        onMouseLeave={() => setCloseOpacity(true)} 
        */}
            <Modal.Body>
                <div className="ActionPanel" >
                    <button onClick={() => setisCaseModal(!isCaseModal)}

                    >
                        <CloseButton
                            width="30" height="30" color={'#9d9d9d'} opacity={CloseOpacity ? '0' : '0.1'}
                        />
                    </button>
                </div>
                <Controls isAdvanced={isAdvanced} setisAdvanced={setisAdvanced} />
                {
                    isAdvanced ?
                        <div className="CaseConditionControl">
                            {

                                DataTable == null ? <div> Data not available !!</div> :
                                    <ReconCaseComponent
                                        MainData={DataTable}
                                        Options={null}
                                        UpdateColumnID={ColumnEditID}
                                        UpdateColumnIDFn={setColumnEditID}

                                    />
                            }

                        </div>
                        :
                        <Basic
                            isVisible={isCaseModal}
                            AliasColumn={AliasColumn}
                            UpdateColumnID={ColumnEditID}
                            UpdateColumnIDFn={setColumnEditID}
                        />
                }
            </Modal.Body>
            <Modal.Footer>
                <button type="button" className="btnPrimary ms-2" onClick={() => { ModalSubmit(ColumnEditID) }} >Continue</button>
            </Modal.Footer>
        </Modal>
    )
}

export default CaseModal;