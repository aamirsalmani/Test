import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import FilterConditionsPanel from './FilterConditionsPanel';
import { CloseButton } from '../../../../Utility/assets/Icons/iconsIndex';
import usePostForm from '../../../../hooks/usePostForm';
import QueryComponent from './QueryPanel/QueryComponent';

const FilterConditionsModal = ({ visible = true, setShowModal }) => {
    const dispatch = useDispatch();
    const setvisible = setShowModal;
    const [Type, setType] = useState(0);
    const { SubmitForm } = usePostForm();

    const ModalSubmit = () => {
        if (Type === 0) {
            SubmitForm();
            setvisible(!visible)
        }
    }

    const onSelect = (value) => {
        setType(value);
    }

    return (
        <Modal
            show={visible}
            onHide={() => setvisible(!visible)}
            centered
            size="xl"
            className="CaseConditionModal"
        >
            <Modal.Body className='modal-content '>
                <div className="ActionPanel" >
                    <button onClick={() => setvisible(!visible)}>
                        <CloseButton
                            width="30" height="30" color={'#e22828'}
                        />
                    </button>
                </div>
                <div className="CaseConditionControl">
                    <FilterConditionsPanel>
                        <QueryComponent />
                    </FilterConditionsPanel>
                </div>
            </Modal.Body>
            <Modal.Footer>
                <button type="button" className="btnPrimary ms-2" onClick={() => { ModalSubmit() }} >Continue</button>
            </Modal.Footer>
        </Modal>
    )
}

export default FilterConditionsModal