import React, { Children } from 'react'
import QueryComponent from './QueryPanel/QueryComponent';
import useGetQueryData from '../../../../hooks/useGetQueryData';




const FilterConditionsPanel = ({ children }) => {
    const FinalQuery = useGetQueryData();

    return (
        <>
            <div>Filter Conditions Panel</div>
            <div className="QueryPanel-Code">
                <textarea className="CaseConditionTextArea" placeholder="case condition will appear here"
                    value={FinalQuery} readOnly
                />
            </div>
            <div className="Stage-box">
                {children}
            </div>
        </>
    )
}

export default FilterConditionsPanel