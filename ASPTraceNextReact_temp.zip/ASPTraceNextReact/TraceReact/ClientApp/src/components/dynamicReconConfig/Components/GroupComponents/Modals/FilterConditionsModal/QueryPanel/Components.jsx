import React, { Fragment, forwardRef, useEffect, useRef, useState } from 'react';
import TextInput from 'react-autocomplete-input';
import 'react-autocomplete-input/dist/bundle.css';
import { Modal } from "react-bootstrap";
import { useDispatch, useSelector } from 'react-redux';
import { InitialConditionData, UpdateFilterConditions, selectActiveTab, selectFilterConditions } from '../../../../../Redux/Reducers/FormReducer';
import { AddIcon, CloseButton, IconEdit, RemoveIcon } from '../../../../../Utility/assets/Icons/iconsIndex';
import SelectComponent from '../../../../BasicComponents/SelectComponent';
import useOptionsData from '../../../../../hooks/useOptionsData';





const Actions = ({ onChange }) => {
    return (
        <>
            <span className='Query-Action-Elements'>
                <button className='custom-edit-button' tabIndex={0} onClick={() => (onChange('add'))}><AddIcon /></button>
                <button className='custom-edit-button' tabIndex={0} onClick={() => (onChange('remove'))}><RemoveIcon /></button>
            </span>
        </>);
}


const GetOptions = (type) => {
    const { columns: columnsOptions, operations: operationsOptions, conditions: conditionsOptions, values: valuesOptions } = useOptionsData();


    switch (type) {
        case 'Column': return columnsOptions;
        case 'Operation': return operationsOptions;
        case 'Condition': return conditionsOptions;
        case 'Value': return valuesOptions;
        default: return null;
    }

}

const getOperationValue = (type, Values, Data) => {
    const selected = Data['Column']?.label;
    let value = '';
    if (Values === undefined) {
        if (Data['Operation']?.OperationText !== "")
            return Data['Operation'] ? Data['Operation'].OperationValue : "";
        else
            return value;
    }
    if (type === 'NULL' || type === 'NOT NULL') {
        let tempValue = Values.input1 === undefined ? "" : Values.input1;
        value = `${selected} IS ${type}`;
    }
    if (type === 'IN') {
        let tempValue = Values.input1 === undefined ? "" : Values.input1;
        value = `${selected} ${type} (${tempValue})`;
    }
    else if (type === 'CAST') {
        let tempValue = Values.input1 === undefined ? "" : Values.input1;
        value = `${type}(${selected} as ${tempValue})`;
    }
    else if (type === 'FORMAT') {
        let tempValue = Values.input1 === undefined ? "" : Values.input1;
        value = `${type}(${selected},'${tempValue}')`;
    }
    else if (type === 'LEFT' || type === 'RIGHT') {
        let tempValue = Values.input1 === "" ? 0 : parseInt(Values.input1);
        value = `${type}(${selected},${tempValue})`;
    }
    else if (type === 'SUBSTRING') {
        let tempValue1 = Values.input1 === "" ? 0 : parseInt(Values.input1);
        let tempValue2 = Values.input2 === "" ? 0 : parseInt(Values.input2);
        value = `${type}(${selected},${tempValue1},${tempValue2})`;
    }
    else if (type === 'REPLACE') {
        let tempValue1 = Values.input1 === undefined ? "" : Values.input1;
        let tempValue2 = Values.input2 === undefined ? "" : Values.input2;
        value = `${type}(${selected},'${tempValue1}','${tempValue2}')`;
    }
    else
        value = "";
    return value;
}

const LowerPanel = ({ type, state, setState }) => {

    const onChange = (isText, name, value) => {
        let obj;
        if (isText) {
            obj = JSON.parse(`{"${name}":"${value}"}`);
        }
        else {
            let number = value === "" ? 0 : parseInt(value);
            obj = JSON.parse(`{"${name}":${number}}`);
        }
        let prop = { ...state, ...obj };
        console.log(prop);
        setState(prop);
    }

    if (type == 'REPLACE') {
        return (<>
            <div className='StartPositionField'>
                <input type={'text'} name='input1' onChange={(e) => onChange(true, e.target.name, e.target.value)} />
            </div>
            <div className='StartPositionField'>
                <input type='text' name='input2' onChange={(e) => onChange(true, e.target.name, e.target.value)} />
            </div>
        </>)
    }
    else if (type == 'IN' || type == 'CAST' || type == 'FORMAT') {
        return (<>
            <div className='StartPositionField'>
                <input type={'text'} name='input1' onChange={(e) => onChange(true, e.target.name, e.target.value)} />
            </div>
        </>)
    }
    else {
        return (
            <>
                <div className='StartPositionField'>
                    <input type={'number'} defaultValue={0} name='input1' onChange={(e) => onChange(false, e.target.name, e.target.value)} />
                </div>
                {
                    type === 'SUBSTRING' ?
                        <>
                            <div className='StartPositionField'>
                                <input type='number' defaultValue={0} name='input2' onChange={(e) => onChange(false, e.target.name, e.target.value)} />
                            </div>
                        </> : <></>
                }
            </>
        )
    }
}

const OperationPanel = forwardRef(({ children, type, Data }, ref) => {
    const [state, setState] = useState();
    const OperationText = getOperationValue(type, state, Data);


    return (
        <>
            <div className="CaseModal-Basic-Basic-Output-Window">
                <textarea className="CaseConditionTextArea" placeholder="case condition will appear here"
                    value={OperationText || ''} ref={ref}
                    readOnly
                />
            </div>
            {children}
            <LowerPanel type={type} setState={setState} state={state} />
        </>
    );

})

const OperationActionModal = ({ Data, value, onChange, ModalActive, setModalActive, Options }) => {
    const [selectedValue, setValue] = useState(value.Option);
    const [operation, setOperation] = useState(value.OperationValue);
    const RefValue = useRef(null);


    useEffect(() => {
        setValue(value.Option);
        setOperation(value.OperationValue);
    }, [value]);

    if (ModalActive === false || value === undefined) {
        return (<></>);
    }

    const ModalSubmit = () => {

        const FinalValue = RefValue.current?.defaultValue;

        const prop = { Option: selectedValue, OperationValue: FinalValue }
        onChange(prop);

        setModalActive(false);
    }

    return (
        <Modal
            show={ModalActive}
            onHide={() => setModalActive(false)}
            centered
            size="sm"
            className="CaseConditionModal"
        >
            <Modal.Body>
                <div className="ActionPanel" >
                    <button onClick={() => setModalActive(false)}>
                        <CloseButton
                            width="30" height="30" color={'#e22828'}
                        />
                    </button>
                </div>
                <div className="OperationModal">
                    <OperationPanel type={selectedValue?.label} Data={Data} ref={RefValue} >
                        <SelectComponent
                            value={selectedValue}
                            onChange={(prop) => { setValue(prop) }}
                            options={Options}
                        />
                    </OperationPanel>
                </div>
            </Modal.Body>
            <Modal.Footer>
                <button type="button" tabIndex={0} className="btnPrimary ms-2" onClick={() => (ModalSubmit())}>Continue</button>
            </Modal.Footer>
        </Modal>)

}

const OperationAction = ({ Data, isModalActive, value, onChange, Options }) => {
    const [ModalActive, setModalActive] = useState(isModalActive);
    useEffect(() => {
        if (ModalActive !== isModalActive)
            setModalActive(isModalActive);
    }, [isModalActive])

    return (<>
        <button className='custom-edit-button' tabIndex={0} onClick={() => (setModalActive(true))}><IconEdit /></button>
        <OperationActionModal
            Data={Data}
            value={value}
            onChange={onChange}
            ModalActive={ModalActive}
            setModalActive={setModalActive}
            Options={Options}
        />
    </>)
}

const OperationCell = ({ Data, value, onChange, Options }) => {
    const { Option, OperationValue } = value;
    const [ModalActive, setModalActive] = useState(false);

    const setFinalvalue = (prop) => {

        onChange(prop);
    }

    return (
        <div >
            {/* <div style={{ width: '100%' }}>
                <SelectComponent
                    value={Option}
                    onChange={(prop) => { setFinalvalue({ Option: prop, OperationValue: '' }); setModalActive(true); }}
                    options={Options}
                />
            </div> */}
            <div style={{ maxWidth: 'fit-content' }}>
                <OperationAction
                    Data={Data}
                    isModalActive={ModalActive}
                    value={value}
                    onChange={setFinalvalue}
                    Options={Options}
                />
            </div>
        </div>);
}
const InputCell = ({ value, onChange }) => {
    const [textvalue, setTextValue] = useState(value);

    const SubmitInput = (e) => {
        let NewValue = '';

       
            if (textvalue.toLowerCase().includes('case when')) {
                NewValue = textvalue;
            }
            else if (textvalue.includes('@')) {
                NewValue = textvalue.split(' ')[0];
            }
            else if (textvalue.includes('(') && textvalue.includes(')')) {
                NewValue = textvalue.split(' ')[0];
            }
            else {
                NewValue = `'${textvalue}'`;
            }
            onChange(NewValue);
        

    }



    return (<>
        <div className='StartPositionField' >
            <input type='text' defaultValue={value} list={'Parameters'} onChange={(e) => (setTextValue(e.target.value))} onBlur={SubmitInput} />
            <datalist id="Parameters">
                <option value="@ClientID" />
                <option value="@ChannelID" />
                <option value="@ModeID" />
                <option value="@FromDate" />
                <option value="@ToDate" />
            </datalist>

        </div>
    </>)
}

const DynamicCell = ({ Data, value, onChange, type }) => {
    const Options = GetOptions(type);


    if (type === 'OperationValue' || type === 'boolean') {
        return (<></>);
    }
    else if (type === 'Value') {

        return (
            <InputCell
                value={value}
                onChange={onChange}
            />
        )
    }
    else if (type === 'Operation') {

        return (
            <OperationCell
                Data={Data}
                value={value}
                onChange={onChange}
                Options={Options}
            />
        )
    }
    else {

        return (
            <SelectComponent
                value={value}
                onChange={onChange}
                options={Options}
            />
        )
    }
}

const Rule = ({ index, Data, onChange, isLast }) => {


    const OnValueChange = (type, value) => {
        if (type === 'Action') {
            const prop = { type: type, value: value };
            onChange(prop);
        }
        else {

            const prop = { type: type, value: value };
            onChange(prop);
        }
    }



    return (
        <>
            <div className="Query-Rule" >
                {
                    Object.keys(Data).map((type) => {
                        if (type === 'id') {
                            return (<></>);
                        }
                        else {

                            return (
                                <Fragment key={index}>
                                    <DynamicCell Data={Data} value={Data[type]} type={type} onChange={(prop) => (OnValueChange(type, prop))} />
                                    {
                                        isLast === true ? <></> :
                                            type === 'boolean' ?
                                                <div className='cell-boolean' >
                                                    <SelectComponent
                                                        value={Data['boolean']}
                                                        onChange={(prop) => (OnValueChange('boolean', prop))}
                                                        options={['select','AND', 'OR'].map((item) => ({ value: `${item}`, label: `${item}` }))}
                                                    />
                                                </div> : <></>
                                    }
                                </Fragment>
                            )

                        }
                    }
                    )

                }
                <Actions onChange={(prop) => (OnValueChange('Action', prop))} />
            </div >
        </>
    );
}



const Components = () => {
    const dispatch = useDispatch();
    const TableName = useSelector(selectActiveTab);
    const FilteredData = useSelector(selectFilterConditions(TableName));
    const InitData = InitialConditionData;

    const Data = FilteredData?.conditions;

    const AddData = (index) => {
        let NewData = { ...InitData[0], id: new Date().getTime() + index };
        let dt = [...Data];
        dt.splice(index + 1, 0, NewData);

        dispatch(UpdateFilterConditions({ TableName: TableName, Value: dt }));

    }
    const RemoveData = (index) => {
        let dt = [...Data].filter((item, i) => i !== index);
        if (dt.length === 0) {
            dispatch(UpdateFilterConditions({ TableName: TableName, Value: [...InitData] }));

        }
        else
            dispatch(UpdateFilterConditions({ TableName: TableName, Value: dt }));

    }

    const UpdateData = (prop, id) => {
        const { type, value } = prop;
        if (value === 'add') {
            AddData(id)
        }
        else if (value === 'remove') {
            RemoveData(id)
        }
        else {


            let dt = [...Data].map((item, i) => {
                if (i === id) {
                    let obj = JSON.parse(`{"${type}":${JSON.stringify(value)}}`);
                    if (type === 'Column') {
                        let newValue = { ...item.Operation, OperationValue: value.label };
                        let obj2 = JSON.parse(`{"${`Operation`}":${JSON.stringify(newValue)}}`);
                        return { ...item, ...obj, ...obj2 }
                    }
                    return { ...item, ...obj };
                }
                else
                    return { ...item };
            })

            dispatch(UpdateFilterConditions({ TableName: TableName, Value: dt }));
        }

    }


    return (
        <>{
            Data.map((item, i) => {
                return (
                    <Fragment key={item.id}>
                        <Rule index={item.id} isLast={Data.length - 1 === i}  Data={item} onChange={(prop) => (
                            UpdateData(prop, i))} />
                    </Fragment>
                )
            })
        }
        </>
    )
}

export default Components