import React, { useEffect, useState } from 'react';
import SelectComponent from '../../../../BasicComponents/SelectComponent';
import { AddIcon, IconEdit, RemoveIcon } from '../../../../../Utility/assets/Icons/iconsIndex';
import { NodeConnector } from '../../../../BasicComponents/NodeConnector/NodeConnector';
import DragElement from '../../../../BasicComponents/NodeConnector/DragElement';
import PointVisualizer from '../../../../BasicComponents/Visualizer/PointVisualizer';
import { useDispatch, useSelector } from 'react-redux';
import { InitialConditionData, UpdateFilterConditions, selectActiveTab, selectFilterConditions, selectNodaRelationData, setNodaRelationData, updateFilterConditions } from '../../../../../Redux/Reducers/FormReducer';





const columnsOptions = [
    { label: 'Column1', value: 'column1' },
    { label: 'Column2', value: 'column2' },
    { label: 'Column3', value: 'column3' }
];

const operationsOptions = [
    { label: 'LEFT', value: 'left' },
    { label: 'RIGHT', value: 'right' },
    { label: 'REPLACE', value: 'replace' }
];

const conditionsOptions = [
    { label: '<', value: '<' },
    { label: '>', value: '>' },
    { label: '>=', value: '>=' },
    { label: '=', value: '=' },
    { label: 'LIKE', value: 'like' },
    { label: 'SUBSTRING', value: 'substring' },
    { label: 'FORMAT', value: 'format' }
];

const valuesOptions = [
    { label: 'Value1', value: 'value1' },
    { label: 'Value2', value: 'value2' },
    { label: 'Value3', value: 'value3' }
];




const Actions = ({ onChange }) => {
    return (
        <>
            <span className='Query-Action-Elements'>
                <button className='custom-edit-button' onClick={() => (onChange('add'))}><AddIcon /></button>
                <button className='custom-edit-button' onClick={() => (onChange('remove'))}><RemoveIcon /></button>
            </span>
        </>);
}

const DynamicCell = ({ onChange,type, value, Data }) => {

    const onValueChange = (Value) => {
        const prop = { type: type, value: Value };
        onChange(prop)
    }

    const getOptions = (type) => {
        switch (type) {
            case 'Column': return columnsOptions;
            case 'Operation': return operationsOptions;
            case 'Condition': return conditionsOptions;
            case 'Value': return valuesOptions;
        }
    }

    const GetOperationCell = ({value}) => {
        if (value === 'LEFT' || value === 'RIGHT' || value === '') {
            return (<span className="StartPositionField"><input type='text' /></span>);
        }
        else if (value === 'SUBSTRING' || value === 'REPLACE') {
            return (
                <>
                    <span className="StartPositionField">
                        <input type='text' />
                    </span>
                    <span className="StartPositionField">
                        <input type='text' />
                    </span>
                </>
            );
        }
        return (<></>);
    }


    return (<div style={{display:'flex'}}>
        <SelectComponent
            value={value}
            onChange={onValueChange}
            options={getOptions(type)}
        />{
            type === 'Operation' &&
            <GetOperationCell value={value.label} />
        }
    </div>);
}

const Rule = ({ index, Data, onChange }) => {

    const onActionClick = (type) => {
        const prop = { type: type, value: null };
        onChange(prop);
    }


    return (
        <>
            <div className="Query-Rule" key={index}>
                {Object.keys(Data).map((type, i) => (
                    <DynamicCell onChange={onChange} type={type} value={Data[type]} Data={Data} />
                ))}
                <Actions onChange={onActionClick} />
            </div>
        </>
    );
}



const Components = () => {
    const dispatch = useDispatch();
    const TableName = useSelector(selectActiveTab);
    const FilteredData = useSelector(selectFilterConditions(TableName));
    const InitData = InitialConditionData;

    const Data = FilteredData?.conditions;

    const AddData = (index) => {
        let NewData = { ...InitData[0] };
        let dt = [...Data];
        dt.splice(index + 1, 0, NewData);

        dispatch(UpdateFilterConditions({ TableName: TableName, Value: dt }));

    }
    const RemoveData = (index) => {
        let dt = [...Data].filter((item, i) => i !== index);
        if (dt.length === 0) {
            dispatch(UpdateFilterConditions({ TableName: TableName, Value: [...InitData] }));

        }
        else
            dispatch(UpdateFilterConditions({ TableName: TableName, Value: dt }));

    }

    const UpdateData = (prop, id) => {
        const { type, value } = prop;
        if (type === 'add') {
            AddData(id)
        }
        else if (type === 'remove') {
            RemoveData(id)
        }
        else {


            let dt = [...Data].map((item, i) => {
                if (i === id) {
                    let obj = JSON.parse(`{"${type}":${JSON.stringify(value)}}`);
                    return { ...item, ...obj };
                }
                else
                    return { ...item };
            })

            dispatch(UpdateFilterConditions({ TableName: TableName, Value: dt }));
        }

    }


    return (
        <>{
            Data.map((item, i) => {
                return (<Rule key={i} index={i} Data={item} onChange={(prop) => (
                    UpdateData(prop, i))} />)
            })
        }
        </>
    )
}

export default Components