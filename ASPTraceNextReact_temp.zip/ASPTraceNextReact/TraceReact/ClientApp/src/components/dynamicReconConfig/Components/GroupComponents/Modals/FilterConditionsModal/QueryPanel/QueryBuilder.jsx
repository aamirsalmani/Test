import React from 'react'

const QueryBuilder = () => {
    return (
        <div>QueryBuilder</div>
    )
}

export default QueryBuilder