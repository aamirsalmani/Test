import React from 'react'
import './Query.css'
import Components from './Components'
import QueryBuilder from './QueryBuilder'
import NodeVisualizer from '../../../../BasicComponents/NodeConnector/NodeVisualizer'
import { useSelector } from 'react-redux';
import { selectNodaRelationData } from '../../../../../Redux/Reducers/FormReducer'

const NodePanel = () =>{
    const NodeData = useSelector(selectNodaRelationData)

    return(<NodeVisualizer elements={NodeData} />)
}

const QueryComponent = () => {
    return (
        <>
            <div className='Query-Panel'>
                <Components/>
            </div>
        </>
    )
}

export default QueryComponent