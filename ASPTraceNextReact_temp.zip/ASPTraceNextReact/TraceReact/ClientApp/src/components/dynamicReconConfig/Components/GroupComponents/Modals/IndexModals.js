import StartupModal from './StartupPanel/StartupModal'
import CaseModal from './CaseConditionModal/CaseModal'
import TableColumnsModal from './TableColumnsModal/TableColumnsModal'
import FilterConditionsModal from './FilterConditionsModal/FilterConditionsModal';
import SuccessModal from './SuccessModal/SuccessModal';
import UpdateConditionsModal from './UpdateConditionsModal/UpdateConditionsModal';
import WarningModal from './WarningModal/WarningModal';

const ModalArray = [
    {id:1,ModalName:'StartupModal',ModalElement:StartupModal},
    { id: 2, ModalName: 'CaseModal', ModalElement: CaseModal},
    { id: 3, ModalName: 'TableColumnsModal', ModalElement: TableColumnsModal},
    { id: 4, ModalName: 'FilterConditionsModal', ModalElement: FilterConditionsModal},
    { id: 5, ModalName: 'SuccessModal', ModalElement: SuccessModal},
    { id: 6, ModalName: 'UpdateConditionsModal', ModalElement: UpdateConditionsModal},
    { id: 7, ModalName: 'WarningModal', ModalElement: WarningModal}
];
export default ModalArray 