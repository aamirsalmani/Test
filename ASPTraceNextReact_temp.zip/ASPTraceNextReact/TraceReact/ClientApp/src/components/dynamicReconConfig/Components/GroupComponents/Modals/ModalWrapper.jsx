import React from 'react'
import ModalArray from './IndexModals'
const ModalWrapper = ({ ModalName, visible, setShowModal }) => {

    const Modal = ModalArray.filter((item)=> item.ModalName ===ModalName);

    const ModalItem = Modal[0] ? Modal[0].ModalElement : null;

    //  console.log(ModalName,ModalArray,Modal,ModalItem);

  return (
    <>
          {
              ModalItem ?
                  <ModalItem key={''} visible={visible} setShowModal={setShowModal } />:null
    }
    </>
  )
}

export default ModalWrapper