import React, { useState } from 'react'
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import StartupPanel from './StartupPanel';
import { CloseButton } from '../../../../Utility/assets/Icons/iconsIndex'
import { useDispatch, useSelector } from 'react-redux';
import { selectChannelID, selectHasPreset } from '../../../../Redux/Reducers/MenuBarReducer';
import { setFormDataDefault, updateUnmatchTable } from '../../../../Redux/Reducers/FormReducer';
import { setIsWizardVisible } from '../../../../Redux/Reducers/WizardReducer';
import UseGetAPI from '../../../../hooks/useGetAPI';
import { setModal } from '../../../../Redux/Reducers/ModalReducer';

const StartupModal = ({ visible = true, setShowModal }) => {
    const dispatch = useDispatch();
    const isStartupModal = visible;
    const setisStartupModal = setShowModal;
    const hasPreset = useSelector(selectHasPreset);
    const selectedChannelValue = useSelector(selectChannelID);
    const [Type, setType] = useState(1);

    const ModalSubmit = async () => {
        if (Type === 1 || Type === 2) {
            setisStartupModal(!isStartupModal)
            const UnmatchedData = await UseGetAPI('api/DynamicReconConfig/GetUnmatchedColumns', { ChannelID: selectedChannelValue?.value });
            if (UnmatchedData.length > 0) {
                // let ListData = data.map((item) => ({value:`${item.value}`,label:item.label}));
                let JsonObj = JSON.parse(UnmatchedData);

                dispatch(updateUnmatchTable(JsonObj));
                dispatch(setIsWizardVisible(true));
            }
        }
        else if (Type === 3) {
            dispatch(setModal({ ActiveModal: 'WarningModal', IsVisible: true }));
            // dispatch(setFormDataDefault());
            // setisStartupModal(!isStartupModal);
        }
        else {
            return null;
        }

    }

    const onSelect = (value) => {
        setType(value);
    }

    return (
        <Modal
            show={isStartupModal}
            onHide={() => setisStartupModal(!isStartupModal)}
            centered
            size="md"
            className="CaseConditionModal"
        >
            {/*
        <Modal.Header closeButton >
            <Modal.Title className="fontSize16-sm letterSpacing-2">
                <span>Startup Panel</span>
            </Modal.Title>
        </Modal.Header>
        */}
            <Modal.Body>
                <div className="ActionPanel" >
                    <button onClick={() => setisStartupModal(!isStartupModal)}>
                        <CloseButton
                            width="30" height="30" color={'#e22828'}
                        />
                    </button>
                </div>
                <div className="CaseConditionControl">
                    <StartupPanel FormatExists={hasPreset} onSelect={onSelect} />
                </div>
            </Modal.Body>
            <Modal.Footer>
                <button type="button" className="btnPrimary ms-2" onClick={() => { ModalSubmit() }} >Continue</button>
            </Modal.Footer>
        </Modal>
    )
}

export default StartupModal