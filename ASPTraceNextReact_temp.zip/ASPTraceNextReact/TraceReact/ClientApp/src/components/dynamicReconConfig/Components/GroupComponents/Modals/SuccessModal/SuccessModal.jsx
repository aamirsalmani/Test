import React, { useState } from 'react'
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { CloseButton } from '../../../../Utility/assets/Icons/iconsIndex'
import { useDispatch, useSelector } from 'react-redux';
import SuccessPanel from './SuccessPanel';

const SuccessModal = ({ visible = true, setShowModal }) => {
    const dispatch = useDispatch();
    const IsVisible = visible;
    const setIsVisible = setShowModal;

    const ModalSubmit = async () => {

        setIsVisible(!IsVisible)


    }

    

    return (
        <Modal style={{border:'none',background:'transparent'}}
            show={IsVisible}
            onHide={() => setIsVisible(!IsVisible)}
            centered
            size="md"
            className="CaseConditionModal"
        >
            <SuccessPanel ModalSubmit={ModalSubmit}/>            
        </Modal>
    )
}

export default SuccessModal