import React from 'react';
import './SuccessPanel.css'
import CloseButton from '../../../../Utility/assets/Icons/CloseButton';

const SuccessPanel = ({ ModalSubmit }) => {
  return (
    <div className='SuccessPanel'>
      <div className="SuccessPanel-Header">
        <button onClick={ModalSubmit} className='SuccessPanel-Header-Button'>
          <CloseButton 
            width="30" height="30" color={'#fff'}
          />
        </button>
      </div>
      <div className="SuccessPanel-Body">
        <div className="SuccessPanel-Title">
          <h5>Recon Configuration Successful</h5>
        </div>
        <div className="SuccessPanel-Message">
          <p>Please check Configuration changes and Query generated through Recon Query Report</p>
        </div>
      </div>
      <div className="SuccessPanel-Action-Panel"></div>
    </div>
  )
}

export default SuccessPanel