import React, { forwardRef, useEffect, useRef, useState } from 'react';
import * as CT from '../../../BasicComponents/CustomTable/CustomTable'
import './Panel.css'; // Import the CSS file
import UseGetAPI from '../../../../hooks/useGetAPI';
import { useSelector } from 'react-redux';
import { selectChannelID } from '../../../../Redux/Reducers/MenuBarReducer';
import { selectActiveJoin, selectActiveTab } from '../../../../Redux/Reducers/FormReducer';

const Panel = ({ getOutput, title = 'Join Configuration' }, ref) => {
  const [selectedItems, setSelectedItems] = useState([]);
  const childref = useRef();
  const [dataList, setDataList] = useState([]);
  const ChannelID = useSelector(selectChannelID);
  const ActiveJoin = useSelector(selectActiveJoin);
  useEffect(() => {
    (async () => {

      const data = await UseGetAPI('api/DynamicReconConfig/GetUnmatchedColumns', { ChannelID: ChannelID?.value });
      if (data.length > 0) {
        let JsonObj = JSON.parse(data);
        let ListData = JsonObj.map((item) => ({ isChecked: ActiveJoin.includes(item.AliasColumn), AliasColumn: item.AliasColumn }));
        setDataList(ListData);
        let CheckedData = ListData.filter((item) => item.isChecked === true);
        setSelectedItems(CheckedData.map((item) => (item.AliasColumn)));
        childref.current = CheckedData.map((item) => (item.AliasColumn));
      }
    })()
  }, [])

  // const dataList = [
  //   'ClientID',
  //   'ChannelID',
  //   'ModeID',
  //   'TerminalId',
  //   'ReferenceNumber',
  //   'CardNumber',
  //   'CardType',
  //   'TxnsValueDateTime',
  //   'TxnsDateTime',
  //   'TxnsAmount',
  //   'ActualTxnsAmount'
  // ];

  const handleCheckboxChange = (event, item) => {
    if (event.target.checked) {
      setSelectedItems([...selectedItems, item.AliasColumn]);
      childref.current = [...selectedItems, item.AliasColumn];

    } else {
      setSelectedItems(selectedItems.filter(selectedItem => selectedItem !== item.AliasColumn));
      childref.current = selectedItems.filter(selectedItem => selectedItem !== item.AliasColumn);
    }
  };

  getOutput(childref);

  return (
    <>
      <div className="Panel-Container-Header">
        {title}
      </div>
      <div className="Panel-Container-Body">
        <div className="ColumnsPanel">
          <CT.Table>
            <CT.TableHeader>
              <CT.TableRow>
                <CT.TableHead>Action</CT.TableHead>
                <CT.TableHead>Column Name</CT.TableHead>
              </CT.TableRow>
            </CT.TableHeader>
            <CT.TableBody>
              {dataList.map((item, index) => (
                <CT.TableRow key={index}>
                  <CT.TableCell>
                    <input
                      type="checkbox"
                      id={item.AliasColumn}
                      value={item.isChecked}
                      defaultChecked={item.isChecked}
                      onChange={(event) => handleCheckboxChange(event, item)}
                    />
                  </CT.TableCell>
                  <CT.TableCell>
                    <label htmlFor={item}>{item.AliasColumn}</label>
                  </CT.TableCell>
                </CT.TableRow>
              ))}
            </CT.TableBody>
          </CT.Table>
        </div>
      </div>
    </>
  );
};

export default forwardRef(Panel);
