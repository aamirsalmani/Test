import React, { useRef, useState } from 'react'
import Panel from './Panel';
import { Modal } from 'react-bootstrap';
import { CloseButton } from '../../../../Utility/assets/Icons/iconsIndex'
import { useDispatch, useSelector } from 'react-redux';
import { selectJoinForm, updateJoinForm } from '../../../../Redux/Reducers/FormReducer';
import { useParams } from 'react-router-dom';

const TableColumnsModal = ({ visible = true, setShowModal }) => {
    const isVisible = visible;
    const setIsVisible = setShowModal
    const ColumnsRef = useRef();
    const TableData = useSelector(selectJoinForm);
    const TableName = useSelector((state)=> state.dynamicRootReducer.ReconForm.ActiveTab);
    const dispatch = useDispatch();

    const getOutput = (childref) => {
        ColumnsRef.current = childref.current;
        
    }

    const ModalSubmit = () => {
        const selectedString = ColumnsRef.current.map((item)=>(item)).join(', ');
        if(TableData){
            let dt = [...TableData].map((item,i)=>{
                if(item.TableName?.label === TableName){
                    return {...item,JoinColumns:selectedString}
                }
                else{
                    return {...item}
                }
            });
            dispatch(updateJoinForm(dt));
        }
        setIsVisible(!isVisible);
    }

    return (
        <Modal
            show={isVisible}
            onHide={() => setIsVisible(!isVisible)}
            centered
            size="md"
            className="CaseConditionModal"
        >
            <Modal.Body>
                <div className="ActionPanel" >
                    <button type='button' onClick={() => setIsVisible(!isVisible)}>
                        <CloseButton
                            width="30" height="30" color={'#e22828'}
                        />
                    </button>
                </div>
                <Panel getOutput={getOutput} />
            </Modal.Body>
            <Modal.Footer>
                <button onClick={ModalSubmit} className="btnPrimary ms-2" >Continue</button>
            </Modal.Footer>
        </Modal>
    )
}

export default TableColumnsModal