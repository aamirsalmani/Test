import React, { useState } from 'react'
import Components from './Components';


const TablePanel = () =>{

    return(<>
      <Components />
    </>);
}

const Base = () => {
    const [FinalQuery,setFinalQuery ] = useState();
    return (
        <>
            <div className="QueryPanel-Code">
                <textarea className="CaseConditionTextArea" placeholder="case condition will appear here"
                    defaultValue={FinalQuery} readOnly
                />
            </div>
            <div className="Stage-box">
            <div className='Query-Panel'>
              <TablePanel />
            </div>
            </div>
        </>
    )
}

export default Base