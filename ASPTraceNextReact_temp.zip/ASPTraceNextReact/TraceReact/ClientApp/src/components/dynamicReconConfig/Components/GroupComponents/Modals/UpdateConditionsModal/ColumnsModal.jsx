import React, { useRef, useState } from 'react'
import { Modal } from 'react-bootstrap';
import { CloseButton } from '../../../../Utility/assets/Icons/iconsIndex'
import { useDispatch, useSelector } from 'react-redux';
import { selectJoinForm, updateJoinForm } from '../../../../Redux/Reducers/FormReducer';
import Primary from '../../../BasicComponents/Button/Primary';
import Panel from '../TableColumnsModal/Panel';


const ColumnsModal = ({ OnModalSubmit, visible = true, setShowModal }) => {
  const isVisible = visible;
  const setIsVisible = setShowModal
  const ColumnsRef = useRef();
  const TableData = useSelector(selectJoinForm);
  const TableName = useSelector((state) => state.dynamicRootReducer.ReconForm.ActiveTab);
  const dispatch = useDispatch();

  const getOutput = (childref) => {
    ColumnsRef.current = childref.current;

  }

  const OnSubmit = () => {
    const selectedString = ColumnsRef.current.join(', ');
    OnModalSubmit(selectedString)
    setIsVisible(!isVisible);
  }

  return (
    <Modal
      show={isVisible}
      onHide={() => setIsVisible(!isVisible)}
      centered
      size="md"
      className="CaseConditionModal"
    >
      <Modal.Body>
        <div className="ActionPanel" >
          <button type='button' onClick={() => setIsVisible(!isVisible)}>
            <CloseButton
              width="30" height="30" color={'#e22828'}
            />
          </button>
        </div>
        <Panel getOutput={getOutput} title='Column Selection' />
      </Modal.Body>
      <Modal.Footer>
        <button onClick={OnSubmit} className="btnPrimary ms-2" >Continue</button>
      </Modal.Footer>
    </Modal>
  )
}

const ModalPanel = ({getOutput}) => {
  const [visible, setvisible] = useState(false);
  
  const onSubmit = (data) =>{
    const columns = data.split(',').map(column => column.trim());
    const formattedColumns = columns.map((column, index) => {
        return {
            id: new Date().getTime() + index,
            Column: { value: index, label: column },
            CaseValue: ``
        };
    });

    getOutput(formattedColumns);
  }


  return (
    <>
      <Primary onClick={() => (setvisible(true))}>Select Columns</Primary>
      <ColumnsModal OnModalSubmit={onSubmit} setShowModal={setvisible} visible={visible} />
    </>
  );
};



export default ModalPanel;