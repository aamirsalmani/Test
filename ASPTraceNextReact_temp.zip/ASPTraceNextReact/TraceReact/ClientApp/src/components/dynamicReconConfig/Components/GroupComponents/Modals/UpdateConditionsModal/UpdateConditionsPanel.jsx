import { useState } from "react";
import Base from "./Base";
import ModalPanel from "./ColumnsModal"


const UpdateConditionsPanel = ({ ModalSubmit }) => {
  

  return (
    <div className='UpdateConditionsModal'>
      <div className='Panel-Container'>
        <div className="Panel-Container-Header">
          Update Conditions Configuration
        </div>
        <div className="Panel-Container-Body">
          <div className="Configuration-panel">       
              <Base />
          </div>
        </div>
        <div className="Panel-Container-Footer">

        </div>
      </div>
    </div>

  )
}

export default UpdateConditionsPanel