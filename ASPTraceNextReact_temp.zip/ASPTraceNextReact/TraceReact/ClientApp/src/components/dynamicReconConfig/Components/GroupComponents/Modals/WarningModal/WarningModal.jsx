import React, { useState } from 'react'
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { CloseButton } from '../../../../Utility/assets/Icons/iconsIndex'
import { useDispatch, useSelector } from 'react-redux';
import WarningPanel from './WarningPanel';
import { setFormDataDefault, updateUnmatchTable } from '../../../../Redux/Reducers/FormReducer';
import { setIsWizardVisible } from '../../../../Redux/Reducers/WizardReducer';
import { selectChannelID } from '../../../../Redux/Reducers/MenuBarReducer';
import UseGetAPI from '../../../../hooks/useGetAPI';

const WarningModal = ({ visible = true, setShowModal }) => {
    const dispatch = useDispatch();
    const IsVisible = visible;
    const setIsVisible = setShowModal;
    const selectedChannelValue = useSelector(selectChannelID);
    
    const ModalSubmit = async (value) => {



        if (value === true) {
            dispatch(setFormDataDefault());
        }
        setIsVisible(!IsVisible);
        dispatch(setIsWizardVisible(true));
        // const UnmatchedData = await UseGetAPI('api/DynamicReconConfig/GetUnmatchedColumns', { ChannelID: selectedChannelValue?.value });
        // if (UnmatchedData.length > 0) {
        //     // let ListData = data.map((item) => ({value:`${item.value}`,label:item.label}));
        //     let JsonObj = JSON.parse(UnmatchedData);

        //     dispatch(updateUnmatchTable(JsonObj));
        //     dispatch(setIsWizardVisible(true));
        // }
    }



    return (
        <Modal
            show={IsVisible}
            onHide={() => setIsVisible(!IsVisible)}
            centered
            size="md"
            className="centeredModal alertModal msgModal"
        >
            <Modal.Header closeButton >
                <Modal.Title className="fontSize16-sm letterSpacing-2">
                    {`Action Confirmation`}
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <WarningPanel ModalSubmit={ModalSubmit}  />
            </Modal.Body>
        </Modal>
    )
}

export default WarningModal