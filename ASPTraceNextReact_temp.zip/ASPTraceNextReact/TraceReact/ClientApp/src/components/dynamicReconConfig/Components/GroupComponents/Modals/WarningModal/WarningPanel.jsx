import React from 'react';
import './SuccessPanel.css'
import CloseButton from '../../../../Utility/assets/Icons/CloseButton';

const WarningPanel = ({ ModalSubmit }) => {

  const OnClick = (option) =>{
    ModalSubmit(option);
  }

  return (
    <div className="SuccessPanel-Body">
      <div className="SuccessPanel-Title">
        <h6>Are you sure you want to create new Configuration?</h6>
      </div>
      <div>
        <div className="configSelectBoxTop row" style={{ display: 'flex', flexDirection: 'row' ,marginTop:'50px'}}>          
          <span className="clientNameSelect" style={{ width: 'unset' }}>
            <button
              type="button"
              className="btnPrimaryOutline"
              onClick={(e) => OnClick(false)}
            >Cancel</button>
          </span>
          <span className="clientNameSelect" style={{ width: 'unset' }}>
            <button
              type="button"
              className="btnPrimary ms-2"
              onClick={(e) => OnClick(true)}
            >Proceed</button>
          </span>
        </div>
      </div>
    </div>
  )
}

export default WarningPanel