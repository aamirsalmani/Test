import React, { useEffect, useState } from 'react'
import './StageComponent.css'
import {Progressbar} from '../../../Utility/assets/Icons/iconsIndex'

const StageComponent = () => {

  const [progress,setProgress] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setProgress(prevProgress => {
        const newProgress = (prevProgress % 100) + 1; // Increment progress and reset to 1 when it reaches 100
        return newProgress;
      });
    }, 400);

    // Clear the interval when the component unmounts
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className='ReconConfig-StageComponent'>
      <div className="ReconConfig-Progress" >
      <Progressbar percentage={progress}/>
      </div>
    </div>
  )
}

export default StageComponent