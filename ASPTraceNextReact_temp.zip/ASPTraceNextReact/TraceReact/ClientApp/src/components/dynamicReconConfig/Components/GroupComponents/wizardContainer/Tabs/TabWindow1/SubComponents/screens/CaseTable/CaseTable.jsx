import React from 'react'
import './CaseTable.css'

const TableData = [
    {
        "Alias Column": "ReferenceNumber",
        "Table Column": "Advanced",
        "Case Statement": "case when GL.ReferenceNumber = '' then SW.ReferenceNumber else GL.ReferenceNumber end",
        "Actions Menu": {
            "Edit": true,
            "Delete": true
        }
    },
    {
        "Alias Column": "CardNumber",
        "Table Column": "Basic",
        "Case Statement": "case when merchantcode = 6012 then 5 else 1 end",
        "Actions Menu": {
            "Edit": true,
            "Delete": true
        }
    },
    {
        "Alias Column": "AuthCode",
        "Table Column": "Basic",
        "Case Statement": "case when merchantcode = 6012 then 5 else 1 end",
        "Actions Menu": {
            "Edit": true,
            "Delete": true
        }
    },
];

const DynamicCell = (ColumnType, CellData) => {
    console.log(CellData);

    if (ColumnType === 'Case StatementD') {

        return (<CaseStatement textValue={CellData} />);
    }
    else {
        return (<div>{CellData}</div>);
    }
}

const CaseStatement = (textValue) => (
    <>
        <div className="case-statement">
            {textValue}
        </div>

    </>)

const Table = () => {
    // Get the keys from the first object in the data array to use as headers
    const headers = Object.keys(TableData[0]);

    return (
        <table className="custom-table">
            <thead>
                <tr className='custom-table-headerRow'>
                    {headers.map((header, index) => (
                        <th key={index} className='custom-table-headerCell'>{header}</th>
                    ))}
                </tr>
            </thead>
            <tbody>
                {TableData.map((row, rowIndex) => (
                    <tr key={rowIndex} className={rowIndex % 1 === 0 ? 'even-row' : 'odd-row'}>
                        {headers.map((header, index) => (
                            <td key={index} className={header.replace(' ', '-').toLowerCase()}>
                                {header === 'Actions Menu' ? (
                                    <>
                                        {row[header]['Edit'] && <button className="edit-button">Edit</button>}
                                        {row[header]['Delete'] && <button className="delete-button">Delete</button>}
                                    </>
                                ) : (
                                    // <DynamicCell ColumnType={'Case Statement'} CellData={row[header]} />

                                    <>{row[header]}</>
                                )}
                            </td>
                        ))}
                    </tr>
                ))}
            </tbody>
        </table>
    );
};




const CaseTable = () => {
    return (
        <>
            <div className="CaseTable-Container">
                <div className="CaseTable-Title">Case Configuration</div>
                <div className="CaseTable-Container-DataTable">
                    <div className="joinTable-Container" >
                        <Table />
                    </div>
                </div>
            </div>

        </>
    )
}

export default CaseTable