import { useSelector } from "react-redux";
import MultiSelectDropDown from "../../../../../../../BasicComponents/MultiSelectDropDown";
import React, { useEffect, useState } from "react";
import { selectChannelID, selectOptionsChannelType } from "../../../../../../../../Redux/Reducers/MenuBarReducer";
import { ArrowRight1 } from "../../../../../../../../Utility/assets/Icons/ArrowRight1";
import { selectJoinsList, selectRawTablesList } from "../../../../../../../../Redux/Reducers/CommonReducer";
import { pushValueNTimes } from "../../../../../../../../Functions/UtilityFunctions";
import MaximusAxios from "../common/apiURL" ;
import authHeader from "../../../../../../../../../../pages/login/services/auth-header";


// Define the columns of the table

const ColumnTypes = {
    Actions: { value: "Actions", type: "AddRemove", }, Select: { value: "Select", type: "DropDown", }
    , Join: { value: "select", type: "JOIN", }
}



// Define a custom component for rendering the table cells
const Cell = ({ ColumnType, value, keyID, ddlOptions, selectedOptions, setSelectedOptions }) => {

    

    if (ColumnType === 'AddRemove')
        return (
            <td key={keyID}>
                <div className="JoinTable-actions">
                    <button >
                        <span className="JoinTable-actions-Button actions-Add">+</span>
                    </button>
                    <button>
                        <span className="JoinTable-actions-Button actions-Remove">-</span>
                    </button>
                </div>
            </td>)
    else if (ColumnType === 'DropDown')
        return (
            <td key={keyID}>
                <MultiSelectDropDown
                    customClassButton=""
                    isMultiSelect={false}
                    options={ddlOptions.map(x => (
                        {
                            value: x.id,
                            label: x.value
                        }
                    ))}
                    selectedOptions={selectedOptions}
                    setSelectedOptions={setSelectedOptions}
                />
            </td>
        );
    else
        return (
            <td key={keyID}>
                {/* <input type="checkbox" checked={value} disabled /> */}
                {value}
            </td>
        );
};
const HeadCell = ({ keyID,type = 'DropDown', ddlTablesOptions, ddlJOINOptions, selectedOptions, setSelectedOptions, selectedJoin, setSelectedJOIN, isLast }) => {
    
    if (type === 'DropDown')
        return (
            <th colSpan={2} key={keyID}>
                <div className="JoinColumnBlock">
                    <MultiSelectDropDown
                        isMultiSelect={false}
                        options={ddlTablesOptions.map(x => (
                            {
                                value: x.tableID,
                                label: x.rawTableName
                            }
                        ))}
                        selectedOptions={selectedOptions}
                        setSelectedOptions={setSelectedOptions}
                    />
                    {!isLast &&

                        <MultiSelectDropDown
                            customClassTextBlock="customClassTextBlock"
                            customClassButton="customClassButton"
                            isMultiSelect={false}
                            options={ddlJOINOptions.map(x => (
                                {
                                    value: x.ID,
                                    label: x.JoinName
                                }
                            ))}
                            selectedOptions={selectedJoin}
                            setSelectedOptions={setSelectedJOIN}
                        />
                    }
                </div>
            </th>
        )
    else if (type === 'JOIN')
        return (
            <th key={keyID}>
                <MultiSelectDropDown
                    customClassTextBlock="customClassTextBlock"
                    customClassButton="customClassButton"
                    isMultiSelect={false}
                    options={ddlJOINOptions.map(x => (
                        {
                            value: x.id,
                            label: x.value
                        }
                    ))}
                    selectedOptions={selectedJoin}
                    setSelectedOptions={setSelectedJOIN}
                />
            </th>
        )
    else return (
        <th key={keyID}></th>
    );
};

// Define a custom component for rendering the table footer
const Footer = () => {
    return (
        <tfoot>
            <tr>
                <td colSpan="6">
                    <div className="JoinTable-Footer-actions">
                        <button className="JoinTable-Footer-actions button">Submit
                            <ArrowRight1 />
                        </button>
                    </div>
                </td>
            </tr>
        </tfoot>
    );
};
const columns = (TablesCount) => {
    console.log('columns = (TablesCount) =>', TablesCount)
    let cols = pushValueNTimes({ array: [], ElementValue: { ID: 0, SelectedTable: "Select", SelectedJoin: 'FULL JOIN',ddlOptions:null, isCompleted: 0 }, count: TablesCount })

    let Finalcols = [...cols].map((item, index) => {
        let Data = { ...item, ID: index + 1 };
        return Data;
    })

    

    return Finalcols;
}
// Define the main component for rendering the table
const RawTableComponent = ({ tablesCount }) => {

    const OptionsTables = useSelector(selectRawTablesList);
    const JoinsList = useSelector(selectJoinsList);
    const selectedChannelValue = useSelector(selectChannelID);
    const handleChannelChange = value => { };
    const [tableColumns, setTableColumns] = useState(null);
    const [tableData, setTableData] = useState(null);


    useEffect(() => {
        setTableColumns(columns(tablesCount));
        let Cols = columns(tablesCount);

        let RowData = Cols.map((item, i) => {
            return { ID: 0, ColumnID: item.ID, value: "Select", isCompleted: 0 };
        });


        
        setTableData([RowData]);



    }, [tablesCount]);




    

    const setSelectedColumns =  (rowID,column, val) => {
        
        let TableColumns = [...tableData].map((row,i) => {
                if(rowID == i)
                {
                    return row.map((rowItem,Rowindex) => {
                        if (rowItem.ColumnID === column.ColumnID) {
                            rowItem.value = val[0];
                            return rowItem;
                        }
                        else
                            return rowItem;

                    })
                }
                else 
                    return row;
           


        });
       
        setTableData(TableColumns);

    }

    const setSelectedOptions = async (column, val) => {
       
        let headerColumns = await Promise.all(
            [...tableColumns].map(async (item) => {
            if (item.ID === column.ID) {
                let opt = await FetchColumns(val);              
                item.SelectedTable = val[0];
                item.ddlOptions = opt;
                return item;
            }
            else
                return item;


        }));    
        setTableColumns(headerColumns);
        

    }
    const setSelectedJOIN = (column, val) => {        
        let headerColumns = [...tableColumns].map((item) => {
            if (item.ID === column.ID) {
                item.SelectedJoin = val;
                return item;
            }
            else
                return item;


        });

        setTableColumns(headerColumns);

    }
    const FetchColumns = async (TableName) =>{
        let Columns = await MaximusAxios.get('api/ReconConfig/GetReconColumns?TableName=' + TableName, {  mode: 'cors' }).then(result1 => {

            if (result1.data !== null || result1.data.length > 0) {
                let dt = result1.data;
                return dt.map((item) => { return { id: item.id, value: item.columnName} })
                
            }
        }).catch(error => {
            // Handle the error here
            console.log('An error occurred:', error);
            return [];

            });
            return Columns;



    }

    const ddlFindOptions = (ColumnID) =>{
        let options = tableColumns.filter((item,i) => item.ID == ColumnID);

        return options[0].ddlOptions || [];

    }

    return (
        tableColumns ?
            <table>
                <thead>
                    <tr className="JoinTable-RowStyle">
                        <th className="JoinTable-actions-header">{'Actions/Columns'}</th>
                        {tableColumns.map((column, i) => {
                            if (true) {

                                return (
                                    <HeadCell keyID={column.ID}
                                        ddlTablesOptions={OptionsTables}
                                        ddlJOINOptions={JoinsList}
                                        selectedOptions={[column.SelectedTable]}
                                        setSelectedOptions={(val) => setSelectedOptions(column, val)}
                                        selectedJoin={[column.SelectedJoin]}
                                        setSelectedJOIN={(val) => setSelectedJOIN(column, val)}
                                        isLast={i == tableColumns.length - 1 ? true : false}
                                    />
                                );
                            }
                            else {
                                return (<th key={column.key} className="JoinTable-actions-header">{column.value}</th>);
                            }
                        }
                        )}
                    </tr>
                </thead>
                <tbody>
                    {tableData.map((row, index) => (
                        <tr key={index} className="JoinTable-RowStyle">
                            <td>
                                <div className="JoinTable-actions">
                                    <button onClick={() => (setTableData(p => {
                                        let Dat = [...p];
                                        let ColsData = tableColumns.map((item, i) => {
                                            return { ID: i, ColumnID: item.ID, value: "Select", isCompleted: 0 };
                                        });
                                        Dat.splice(index+1,0,ColsData);
                                        return Dat;
                                    }))}>
                                        <span className="JoinTable-actions-Button actions-Add">+</span>
                                    </button>
                                    <button onClick={() => (setTableData(p => {                                       
                                        let Dat = [...p].filter((item,i) => i!== index);
                                        return Dat;
                                    }))}
                                    >
                                        <span className="JoinTable-actions-Button actions-Remove">-</span>
                                    </button>
                                </div>
                            </td>
                            {row.map((item, i) => {
                                if (true)
                                    return (
                                        <>
                                            <Cell ColumnType={'DropDown'} keyID={item.ID} value={item.value}
                                                selectedOptions={[item.value]} 
                                                ddlOptions={
                                                    ddlFindOptions(item.ColumnID)||[] }
                                                setSelectedOptions={(val) => setSelectedColumns(index,item, val)}
                                            />
                                            {
                                                i !== tableColumns.length - 1 ?
                                                    <td></td> : <></>
                                            }
                                        </>
                                    );
                                else //if (column.type !== "DropDown")
                                    return (<td></td>)
                            }
                            )}
                        </tr>
                    ))}
                </tbody>
                {/* <Footer /> */}
            </table>
            : <></>
    );
};



export default RawTableComponent;

