import React, { useState, useEffect } from "react";
import { ToggleButton } from "../../../../../../../BasicComponents/ToggleButton";
import SelectComponent from "../../../../../../../BasicComponents/SelectComponent";
import { useDispatch, useSelector } from "react-redux";
import { selectChannelID, selectOptionsChannelType } from "../../../../../../../../Redux/Reducers/MenuBarReducer";
import './RawTable.css'
import MultiSelectDropDown from "../../../../../../../BasicComponents/MultiSelectDropDown";
import Table from './RawTableComponent'
import { selectRawTablesList } from "../../../../../../../../Redux/Reducers/CommonReducer";
import { ArrowRight1 } from "../../../../../../../../Utility/assets/Icons/ArrowRight1";
import { selectIsJoinTableComplete, setIsJoinTableComplete } from "../../../../../../../../Redux/Reducers/WizardReducer";
import CaseTable from "../CaseTable/CaseTable";

const TableConfigPanel = () => {
  const OptionsChannelType = useSelector(selectOptionsChannelType);
  const selectedChannelValue = useSelector(selectChannelID);

  const RawTablesList = useSelector(selectRawTablesList);
  const handleChannelChange = value => { };
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [IsMulti, setIsMulti] = useState(false);
  const [tablesCount, setTablesCount] = useState([2]);
  

  useEffect(() => { setSelectedOptions([]); }, [IsMulti]);


  return (
    <>
      <div className="raw-table-config">

        <ToggleButton title="Multiple Tables"
          toggle={IsMulti} setToggle={setIsMulti} className="JoinTable-custom-class" frameClassName="custom-frame"
        />
        {
          !IsMulti ?
            <div className="JoinTable-Add-Table">
              <MultiSelectDropDown key={"Labels"}
                isMultiSelect={false}
                title="Add Table"
                options={RawTablesList.map(x => (
                  {
                    value: x.tableID,
                    label: x.rawTableName
                  }
                ))}
                selectedOptions={selectedOptions}
                setSelectedOptions={setSelectedOptions}
              />
            </div>
            : <div className="JoinTable-Add-Table">
              <MultiSelectDropDown key={"Number"}
                isMultiSelect={false}
                title="Tables Count"
                options={['2', '3', '4', '5', '6'].map(x => (
                  {
                    value: x,
                    label: x
                  }
                ))}
                selectedOptions={tablesCount}
                setSelectedOptions={setTablesCount}
              />
              {/* <label htmlFor="TablesCount" className="DropDownHeader"> Tables Count</label>
              <input id="TablesCount" className="dropdown" type="number" max={6} min={2} defaultValue={2} /> */}
            </div>

        }
      </div>

      {
        IsMulti && <JoinTable tablesCount={tablesCount[0]}/>
      }
    </>
  );
}

const Footer = () => {
  const dispatch = useDispatch();
  return (
    <div className="JoinTable-Footer-actions">
      <button className="JoinTable-Footer-actions button"
        onClick={()=>dispatch(setIsJoinTableComplete(true))}
      >Submit
        <ArrowRight1 />
      </button>
    </div>
  );
};

const JoinTable = ({tablesCount}) => {
  console.log('tablesCount',tablesCount);
  return (
    <>
      <div className="JoinTable-Window">
        {/* <div className="JoinTable-Header">Header</div> */}
        <div className="JoinTable-Body">
          <div className="joinTable-Container">
            <Table tablesCount={tablesCount}/>
          </div>
            <Footer/>
        </div>
        {/* <div className="JoinTable-Footer">Footer</div> */}
      </div>
    </>
  );
}

export const RawTableConfig = () => {
  
  const IsCaseConfig = useSelector(selectIsJoinTableComplete);

  return (
    <>
      <div className="RawTableConfig-Container">
        <TableConfigPanel />
        {
            IsCaseConfig &&
        <>
          <div >
            <CaseTable/>
          </div>
        </>
        }
      </div>
    </>
  );
};

