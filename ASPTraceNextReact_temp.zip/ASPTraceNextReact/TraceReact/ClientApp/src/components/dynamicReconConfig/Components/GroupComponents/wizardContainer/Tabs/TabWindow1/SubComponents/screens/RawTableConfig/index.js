export { RawTableConfig } from "./RawTableConfig";
