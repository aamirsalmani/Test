import React from 'react'
import {RawTableConfig} from './TabWindow1/SubComponents/index'

const TabWindowContainer = ({children}) => {

  


  return (
    <div>
        <RawTableConfig/>
        {/* {children} */}
    </div>
  )
}

export default TabWindowContainer