import React, { useState } from 'react'
import './Tabs.css'
import TabWindowContainer from './TabWindowContainer'
import { useSelector } from 'react-redux'
import { selectedTables } from '../../../../Redux/Reducers/MenuBarReducer'
import { Checkmark } from '../../../../Utility/assets/Icons/iconsIndex'


// const data = [
//   {id : '1',
//    bgcolor:'#ffccaa',
//    tabTitle: "CBS",
//    tabContent: 'Tab Content 1'
//   },
//   {id : '2',
//    bgcolor:'#ffccaa',
//    tabTitle: "SWITCH",
//    tabContent: 'Tab Content 2'
//   },
//   {id : '3',
//    bgcolor:'#ffccaa',
//    tabTitle: "NETWORK",
//    tabContent: 'Tab Content 3'
//   }
// ]

const Tabs = () => {

  const selectedTablesList = useSelector(selectedTables);
  let SelectTablesComplete =selectedTablesList.filter((i) => i.value !==0);
  
  const data = SelectTablesComplete.map((item,i) => {
    return {id:i,bgcolor:'#ffccaa',tabTitle:item.label,tabContent:'',isComplete:true};});

    const [visibleTab, setVisibleTab] = useState(data[0].id);


  // console.log(SelectTablesComplete);
  
  if(SelectTablesComplete.length>0)
  {

  
  
    const listTitles = data.map((item) => 
        <li key={item.id} onClick={() => setVisibleTab(item.id)}  className={visibleTab === item.id ? "tab-title tab-title--active" : "tab-title"}>  
        <div style={{display:'flex',justifyContent:'space-around',alignItems:'center'}}>
            <span>{item.tabTitle}</span>
            {
              item.isComplete && item.id <2 ?
              <span><Checkmark color={visibleTab === item.id ?'#fff':'#73c96b'} width={'20px'} height={'20px'} padding={'0'} key={'check'}/></span>:<></>
            }
            </div>          
            </li>
    )       
                                     
    const listContent = data.map((item) => 
        <p key={item.id} style={visibleTab === item.id ? {} : {display: 'none'}}>{item.tabContent}</p>
    )
    
    return(
        <div className="tabs">
          <ul className="tabs-titles">
            {listTitles}
          </ul>
          <div style={visibleTab !== "0" ? {borderRadius: "0 10px 10px 10px"}:{borderRadius: "10px"}} className="tab-content">
             <TabWindowContainer>
             {listContent}
             </TabWindowContainer>
          </div>
        </div>
      )
    }
    else return <></>
  }
  

export default Tabs