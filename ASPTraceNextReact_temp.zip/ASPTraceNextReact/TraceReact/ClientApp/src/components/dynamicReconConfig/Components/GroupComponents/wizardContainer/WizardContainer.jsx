import React, { useState } from 'react'
import Tabs from './Tabs/Tabs'
import './wizard.css'
import RightArrow from '../../../Utility/assets/Icons/RightArrow';

const WizardHeader = () => {
    const [activeTab, setActiveTab] = useState(0);

    const tabs = [
        'DataTables Configuration',
        'Merged Table Configuration',
        'Final Configuration'
    ];

    return (
        <div className="wizard-tab-component">
            {tabs.map((tab, index) => (
                <div className="wizard-block" key={index}>
                    {
                        index !== 0 &&
                        <div className="arrow">
                            <RightArrow width="21" height="38" color="#F0F0F0" />
                        </div>
                    }
                    <div
                        // key={index}
                        className={`wizard-tab ${activeTab === index ? 'active' : ''}`}
                        onClick={() => setActiveTab(index)}
                    >
                        <span className={`wizard-tab-number  ${activeTab === index ? 'active' : ''}`}>{index + 1}</span>
                        <div className="wizard-container-title">
                            {tab}
                        </div>
                    </div>
                </div>

            ))}
        </div>
    );
}


const WizardContainer = ({ children }) => {
    return (
        <>
            <div className="wizard-container">
                <div className="wizard-container-header">
                    <WizardHeader />
                </div>
                <div className="wizard-container-body">
                    <Tabs />
                    <div >{children}</div>
                </div>
                <div className="wizard-container-footer">

                </div>
            </div>

        </>
    )
}

export default WizardContainer