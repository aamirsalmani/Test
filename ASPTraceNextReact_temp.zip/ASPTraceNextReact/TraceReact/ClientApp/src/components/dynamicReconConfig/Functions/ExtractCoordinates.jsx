export const extractCoordinates = (input) => {
    // Initialize an empty array to store extracted coordinates
    let result = [];

    // Helper function to recursively extract coordinates
    function extract(obj) {
        // If the input is null or undefined, return
        if (obj === null || obj === undefined) {
            return;
        }

        // If the input is an array, iterate over its elements
        if (Array.isArray(obj)) {
            obj.forEach(item => extract(item));
        }
        // If the input is an object, check if it has 'x' and 'y' keys
        else if (typeof obj === 'object' && 'x' in obj && 'y' in obj) {
            // If it has 'x' and 'y' keys, push it to the result array
            result.push({ x: obj.x, y: obj.y });
        }
        // If the input is an object but doesn't have 'x' and 'y' keys,
        // recursively check its properties
        else {
            for (let key in obj) {
                extract(obj[key]);
            }
        }
    }

    // Call the helper function with the input object
    extract(input);

    // Return the flattened array of coordinates
    return result;
}

// Example usage:
const obj = {
    a: [
        { x: 10, y: 20 },
        { x: 30, y: 40 },
        {
            b: { x: 50, y: 60 },
            c: [
                { x: 70, y: 80 },
                { d: { x: 90, y: 100 } }
            ]
        }
    ]
};

const coordinates = extractCoordinates(obj);
console.log(coordinates);
