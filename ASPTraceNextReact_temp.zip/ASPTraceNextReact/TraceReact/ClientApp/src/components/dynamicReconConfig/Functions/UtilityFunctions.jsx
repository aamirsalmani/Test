﻿export { pushValueNTimes, GetTableJoinArray }

function pushValueNTimes({ array: arr, ElementValue: value, count: n }) {
  for (let i = 0; i < n; i++) {
    arr.push(value);
  }
  return arr;
}

const GetTableJoinArray = (count) => {
  let DefaultArray = Array.from({ length: count }, (_, index) => ({
    id: index + 1,
    tabTitle: `Table ${index + 1}`,
    Option: { value: "0", label: "Select" },
    Values: { value: "0", label: "Select", JOIN: "Select" }
  }));

  let ObjectArr = DefaultArray.map((item, i) => (
    `"${item.tabTitle}":{"Column":{"value":"0","label":"select"},"JOIN":{"value":"0","label":"select"},"TableName":{"value":"0","label":"select"}}`

  )).join(',');
  ObjectArr = `{${ObjectArr}}`
  let FinalObject = JSON.parse(ObjectArr);
  return FinalObject;
}


export const StageList = {
    stage1: 'DataTables-Configuration'
  , stage2: 'Merged-Table-Configuration'
  , stage2: 'Final-Configuration'

}