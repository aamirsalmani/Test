export const TableAliasList = (TableData) => {



    let ColumnNames = [];

    ColumnNames = TableData.length > 0 ? TableData.map((item) => (
        { value: item.TableName.value, label: item.TableName.label }
    )) : [{ value: 0, label: "select" }];



    return ColumnNames;
}