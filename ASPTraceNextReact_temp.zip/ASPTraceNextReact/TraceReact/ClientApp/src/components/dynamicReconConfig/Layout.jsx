import React from 'react'
import { useParams } from 'react-router-dom'
import MainContainer from './Components/GroupComponents/MainContainer/MainContainer';
import FinalQueryPanel from './Components/GroupComponents/BaseGroup/FinalQueryPanel';

const Layout = ({onToggle}) => {
    const {id} = useParams();

    switch(id){
        case '1':return(<MainContainer onToggleMenu={onToggle} />);
        case '2':return(<FinalQueryPanel />);
        default:return(<></>);
    }
  
}

export default Layout