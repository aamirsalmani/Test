﻿//#region Imports 

import React, { useRef, useState } from "react";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { Navigate, Route, Routes } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import Menubar from "./Components/GroupComponents/MenuBar/Menubar";
import { QueryClientProvider, QueryClient } from 'react-query';
import MainContainer from "./Components/GroupComponents/MainContainer/MainContainer";
import ModalWrapper from "./Components/GroupComponents/Modals/ModalWrapper";
import { selectActiveModal, selectIsModalVisible, setIsModalVisible } from './Redux/Reducers/ModalReducer';
import { setAlertMessageBox, selectAlertJSON, selectIsLoading } from "./Redux/Reducers/AlertMessageReducer";
import FinalQueryPanel from "./Components/GroupComponents/BaseGroup/FinalQueryPanel";
import FooterPanel from "./Components/GroupComponents/BaseGroup/FooterPanel";
import Layout from "./Layout";

//#endregion

const queryClient = new QueryClient({
    defaultOptions: {
        queries: {
            refetchOnMount: false,
            refetchOnWindowFocus: false,
        },
    },
});

const ReconConfigNewMainWindow = () => {
    const dispatch = useDispatch();
    const [isLoading,setLoading] = useState(true);
    const ActiveModalName = useSelector(selectActiveModal);
    const alertJson = useSelector(selectAlertJSON);
    const isShow = useSelector(selectIsLoading);
    const IsModalVisible = useSelector(selectIsModalVisible);
    const MenuRef = useRef(null);
    // console.log('ActiveModalName', ActiveModalName);
    const onToggle = () =>{
        MenuRef?.current?.click();
    }

    
    if(false){
        return(<></>);
    }
    else
    return (
        <QueryClientProvider client={queryClient}>
            <div className="configLeft identificationContainer">
                <Menubar ref={MenuRef}/>
                <div style={{ display: "flex", alignItems: 'center', flexDirection: 'column' }}>
                    <Routes>
                        <Route path=":id" element={ <Layout onToggle={onToggle} />}/>
                        <Route index element={ <Navigate to={'1'}/>}/>
                    </Routes>      
                </div>
                <ModalWrapper ModalName={ActiveModalName} visible={IsModalVisible} setShowModal={(props) => dispatch(setIsModalVisible(props))} />
                <LoadingSpinner isShow={isShow} />
                <MessageBox alertJson={alertJson} setShowMessageBox={(props) => dispatch(setAlertMessageBox(props))} />
            </div>
        </QueryClientProvider>
    );
};

export default ReconConfigNewMainWindow;
