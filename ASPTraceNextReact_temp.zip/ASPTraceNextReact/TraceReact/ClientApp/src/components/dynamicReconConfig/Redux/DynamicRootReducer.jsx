import {combineReducers} from 'redux';
import MenuBarReducer from './Reducers/MenuBarReducer'
import ModalReducer from './Reducers/ModalReducer';
import  AlertMSGReducer from './Reducers/AlertMessageReducer'
import  WizardReducer from './Reducers/WizardReducer';
import  FormReducer from './Reducers/FormReducer';
import CommonReducer from './Reducers/CommonReducer';


const rootReducer = combineReducers({
    Menubar:MenuBarReducer
    ,ModalPopUp:ModalReducer
    ,AlertModal:AlertMSGReducer
    ,MainPanel:WizardReducer
    ,ReconForm:FormReducer
    ,CommonVariables:CommonReducer
});

export default rootReducer;