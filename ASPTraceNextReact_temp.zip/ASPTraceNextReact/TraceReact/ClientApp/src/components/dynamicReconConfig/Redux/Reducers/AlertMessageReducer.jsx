// Redux Toolkit Slice (reducer)
import { createSelector, createSlice } from '@reduxjs/toolkit';

const AlertModalInitialState = { isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' };

const initialState = {
  Alert: AlertModalInitialState,
  Loading:false
};

const ModalSlice = createSlice({
  name: 'Alert',
  initialState: initialState,
  reducers: {
    setAlertMessageBox: (state, action) => {
      state.Alert = action.payload;
    },
    setIsLoadingSpinner:(state, action) => {
      console.log(action.payload);
      state.Loading = action.payload;
    },
  },
});


export const selectAlertState = (state) => {
  // console.log(state);  
  return state.dynamicRootReducer.AlertModal};

export const selectAlertJSON = createSelector([selectAlertState], (a) => a.Alert);
export const selectIsLoading = createSelector([selectAlertState], (a) => a.Loading);

export const {
  setAlertMessageBox,setIsLoadingSpinner
} = ModalSlice.actions;

export default ModalSlice.reducer;
