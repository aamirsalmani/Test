// Redux Toolkit Slice (reducer)
import { createSelector, createSlice } from '@reduxjs/toolkit';



const CommonValuesState = {
  RawTablesList: [],
  JoinsList:[],
  selectedOptionTable:[],
  ColumnsList:null
}

const initialState = {
  common:CommonValuesState,
};

const commonSlice = createSlice({
  name: 'common',
  initialState: initialState,
  reducers: {
    setRawTablesList: (state, action) => {
      state.common.RawTablesList = action.payload;
    },
    setselectedOptions: (state, action) => {
      state.common.selectedOptionTable = action.payload;
    },
    setJoinList: (state, action) => {
      state.common.JoinsList = action.payload;
    },
    setColumnsList: (state, action) => {
      state.common.ColumnsList = action.payload;
    },
  },
});

export const selectCommonState = (state) => state.dynamicRootReducer.CommonVariables.common;

export const selectRawTablesList = createSelector([selectCommonState], (a) => a.RawTablesList);
export const selectedOptionTable = createSelector([selectCommonState], (a) => a.selectedOptionTable);
export const selectJoinsList = createSelector([selectCommonState], (a) => a.JoinsList);
export const selectColumnsList = createSelector([selectCommonState], (a) => a.ColumnsList);

export const {
  setRawTablesList,setJoinList
  ,setselectedOptions,setColumnsList
} = commonSlice.actions;

export default commonSlice.reducer;
