// slice.js

import { createAsyncThunk, createSelector, createSlice } from '@reduxjs/toolkit';
import { setAlertMessageBox } from './AlertMessageReducer';

const initialState = {
    ActiveTab: null
    ,ActiveJoin: ''
    , ActiveTabColumns: []
    , formData: {
        TabsFormData: [],
        MainJoinForm: [
            {
                Status: { IsActive: false, IsComplete: false }, OrderNo: { value: 0, label: 'Select' }, TableName: { value: 0, label: 'Select' }, JoinColumns: 'Add Join Columns here', conditions: [
                    { id: new Date().getTime(), Column: { value: 0, label: 'select' }, Operation: { Option: { value: 0, label: 'select' }, OperationValue: '' }, Condition: { value: 0, label: 'select' }, Value: '', boolean: { value: 0, label: 'select' } }
                ], MergeConditions: [
                    { id: new Date().getTime(), Column: { value: 0, label: 'select' }, CaseValue: `` }
                ]
            }],
        UnmatchedTable: [],
    },
    formState: {
        IsConfigVisible: false,
        AccordianState: [
            { step: 1, sections: [{ section: 1, isActive: true, isOpen: true }, { section: 2, isActive: false, isOpen: true }, { section: 3, isActive: false, isOpen: true }] }
            , { step: 2, sections: [{ section: 1, isActive: true, isOpen: true }, { section: 2, isActive: false, isOpen: true }, { section: 3, isActive: false, isOpen: true }] }
        ]
    },
    NodaRelationData: null
};

const formSlice = createSlice({
    name: 'formSlice ',
    initialState,
    reducers: {
        updateForm: (state, action) => {
            state.formData = {
                ...state.formData,
                ...action.payload,
            };
        },
        updateformState: (state, action) => {
            state.formState = {
                ...state.formState,
                ...action.payload,
            };
        },
        updateConfigVisibility: (state, action) => {
            state.formState.IsConfigVisible = action.payload;
        },
        updateAccordianState: (state, action) => {
            state.formState.AccordianState = action.payload;
        },
        updateTabsForm: (state, action) => {
            state.formData.TabsFormData = action.payload;
        },
        updateActiveTabColumns: (state, action) => {
            state.ActiveTabColumns = action.payload;
        },
        updateActiveJoin: (state, action) => {
            state.ActiveJoin = action.payload;
        },
        updateActiveTab: (state, action) => {
            state.ActiveTab = action.payload;
        },
        updateJoinForm: (state, action) => {
            state.formData.MainJoinForm = action.payload;
        },
        updateUnmatchTable: (state, action) => {
            state.formData.UnmatchedTable = action.payload;
        },
        setNodaRelationData: (state, action) => {
            state.NodaRelationData = action.payload;
        },
        setFormDataDefault: (state) => {
            return initialState;
        },
        setFormStateDefault: (state) => {
            state.formState = initialState.formState;
        },

    },
});



export const UpdateFilterConditions = createAsyncThunk(
    'formSlice',
    async (action, thunkAPI) => {
        try {
            const { TableName, Value } = action;
            const { getState, dispatch } = thunkAPI;
            const state = getState().dynamicRootReducer.ReconForm;

            const updatedMainJoinForm = state.formData.MainJoinForm.map((item) => {
                if (item.TableName.label === TableName) {
                    return { ...item, conditions: Value };
                } else {
                    return item;
                }
            });

            // Dispatch the action to update the state
            dispatch(updateJoinForm(updatedMainJoinForm));

            // Optionally return something if needed
            return 'Filter conditions updated successfully';
        } catch (error) {
            // Handle any errors
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);

export const UpdateMergeTable = createAsyncThunk(
    'formSlice',
    async (action, thunkAPI) => {
        try {
            const { TableName, Value } = action;


            let Serialized = JSON.stringify(Value);

            let forbiddenKeywords = ["DROP",  "TRUNCATE", "ALTER", "MASTER"]
            let WhitelistKeywords = [ "MASTERCARD" ];

            if (forbiddenKeywords.filter(keyword => Serialized.toLowerCase().includes(keyword.toLowerCase())).length>0) {
                let alertMessages ="";
                if (WhitelistKeywords.filter(keyword => Serialized.toLowerCase().includes(keyword.toLowerCase())).length>0) {

                }
                else{
                    alertMessages = "Error: The input contains forbidden SQL keywords like DROP,CREATE, TRUNCATE,ALTER ";
                }
                dispatch(setAlertMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages }));
                return alertMessages;
            }


            const { getState, dispatch } = thunkAPI;
            const state = getState().dynamicRootReducer.ReconForm;

            const updatedMainJoinForm = state.formData.MainJoinForm.map((item) => {
                if (item.TableName.label === TableName) {
                    return { ...item, MergeTable: Value };
                }
                else {
                    return item;
                }

            });

            // Dispatch the action to update the state
            dispatch(updateJoinForm(updatedMainJoinForm));
            dispatch(updateUnmatchTable(Value));
            // Optionally return something if needed
            return 'Merge conditions updated successfully';
        } catch (error) {
            // Handle any errors
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);



export const UpdateMergeConditions = createAsyncThunk(
    'formSlice',
    async (action, thunkAPI) => {
        try {
            const { TableName, Value } = action;
            const { getState, dispatch } = thunkAPI;
            const state = getState().dynamicRootReducer.ReconForm;

            const updatedMainJoinForm = state.formData.MainJoinForm.map((item) => {
                if (item.TableName.label === TableName) {
                    return { ...item, MergeConditions: Value };
                } else {
                    return item;
                }
            });

            // Dispatch the action to update the state
            dispatch(updateJoinForm(updatedMainJoinForm));

            // Optionally return something if needed
            return 'Merge conditions updated successfully';
        } catch (error) {
            // Handle any errors
            return thunkAPI.rejectWithValue(error.message);
        }
    }
);


export const FormState = (state) => { return state.dynamicRootReducer.ReconForm };

export const selectActiveJoin = (state) => { return state.dynamicRootReducer.ReconForm.ActiveJoin };
export const selectActiveTab = (state) => { return state.dynamicRootReducer.ReconForm.ActiveTab };
export const selectActiveTabColumns = (state) => { return state.dynamicRootReducer.ReconForm.ActiveTabColumns };

export const InitialJoinForm = initialState.formData.MainJoinForm;
export const InitialConditionData = initialState.formData.MainJoinForm[0].conditions;
export const InitialMergeData = initialState.formData.MainJoinForm[0].MergeConditions;

export const selectNodaRelationData = createSelector([FormState], (a) => { return a.NodaRelationData });

export const selectFormData = createSelector([FormState], (a) => { return a.formData });
export const selectFormState = createSelector([FormState], (a) => { return a.formState });

export const selectAccordianState = createSelector([FormState], (a) => { return a.formState.AccordianState });
export const selectIsConfigVisible = createSelector([FormState], (a) => { return a.formState.IsConfigVisible });

export const selectTabsFormData = createSelector([FormState], (a) => { return a.formData.TabsFormData });
export const selectJoinForm = createSelector([FormState], (a) => { return a.formData.MainJoinForm });


export const selectFilterConditions = TableName => state => {
    return state.dynamicRootReducer.ReconForm.formData.MainJoinForm.find((item) => item.TableName.label === TableName)
};

export const selectUnmatchedTable = createSelector([FormState], (a) => { return a.formData.UnmatchedTable });

export const {
    updateForm, updateformState, setNodaRelationData, updateConfigVisibility
    , updateTabsForm, updateActiveJoin,updateActiveTab, updateActiveTabColumns, updateUnmatchTable
    , updateJoinForm, setFormDataDefault, setFormStateDefault
} = formSlice.actions;

export default formSlice.reducer;
