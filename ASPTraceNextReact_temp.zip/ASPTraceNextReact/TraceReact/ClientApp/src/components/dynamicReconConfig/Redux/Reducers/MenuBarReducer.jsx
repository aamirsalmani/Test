// Redux Toolkit Slice (reducer)
import { createSelector, createSlice } from '@reduxjs/toolkit';

const menubarInitialState = {
  MenuParams: null,
  client: null,
  optionsReconType: [],
  selectedReconType: null,
  optionsNetworkType: [],
  selectedNetworkType: null,
  optionsChannelType: [],
  selectedChannelValue: null,
  optionsModeType: [],
  selectedModeValue: null,
  selectedTablesCount: 0,
  selectedTables: [],
  Inputarr: [],
  HasPreset: false,
};

const initialState = {
  menu: menubarInitialState,
};

const menubarSlice = createSlice({
  name: 'menu',
  initialState: initialState,
  reducers: {
    setMenuParams: (state, action) => {
      state.menu.MenuParams = action.payload;
    },
    setClient: (state, action) => {
      state.menu.client = action.payload;
    },
    setReconType: (state, action) => {
      state.menu.selectedReconType = action.payload;
    },
    setOptionsReconType: (state, action) => {
      state.menu.optionsReconType = action.payload;
    },
    setNetworkType: (state, action) => {
      state.menu.selectedNetworkType = action.payload;
    },
    setOptionsNetworkType: (state, action) => {
      state.menu.optionsNetworkType = action.payload;
    },
    setChannel: (state, action) => {
      state.menu.selectedChannelValue = action.payload;
    },
    setOptionsChannelType: (state, action) => {
      state.menu.optionsChannelType = action.payload;
    },
    setMode: (state, action) => {
      state.menu.selectedModeValue = action.payload;
    },
    setOptionsModeType: (state, action) => {
      state.menu.optionsModeType = action.payload;
    },
    setTables: (state, action) => {
      state.menu.selectedTablesCount = action.payload;
    },
    setSelectedTables: (state, action) => {
      state.menu.selectedTables = action.payload;
    },
    setHasPreset: (state, action) => {
      state.menu.HasPreset = action.payload;
    },
    setInitializeValues: (state) => {
      state.menu = menubarInitialState;
    },
  },
});

export const selectMenuState = (state) => state.dynamicRootReducer.Menubar.menu;

export const selectHasPreset = createSelector([selectMenuState], (a) => a.HasPreset);

export const selectOptionsNetworkType = createSelector([selectMenuState], (a) => a.optionsNetworkType);
export const selectOptionsReconType = createSelector([selectMenuState], (a) => a.optionsReconType);
export const selectOptionsChannelType = createSelector([selectMenuState], (a) => a.optionsChannelType);
export const selectOptionsModeType = createSelector([selectMenuState], (a) => a.optionsModeType);

export const selectMenuParams = createSelector([selectMenuState], (a) => a.MenuParams);
export const selectClientID = createSelector([selectMenuState], (a) => a.client);
export const selectReconType = createSelector([selectMenuState], (a) => a.selectedReconType);
export const selectNetworkType = createSelector([selectMenuState], (a) => a.selectedNetworkType);
export const selectChannelID = createSelector([selectMenuState], (a) => a.selectedChannelValue);
export const selectModeID = createSelector([selectMenuState], (a) => a.selectedModeValue);
export const selectedTables = createSelector([selectMenuState], (a) => a.selectedTables);
export const selectedInputArray = createSelector([selectMenuState], (a) => a.Inputarr);

export const {
  setMenuParams,
  setClient,
  setReconType,
  setOptionsReconType,
  setNetworkType,
  setOptionsNetworkType,
  setChannel,
  setOptionsChannelType,
  setMode,
  setOptionsModeType,
  setTables,
  setSelectedTables,
  setInitializeValues,
  setHasPreset,
} = menubarSlice.actions;

export default menubarSlice.reducer;
