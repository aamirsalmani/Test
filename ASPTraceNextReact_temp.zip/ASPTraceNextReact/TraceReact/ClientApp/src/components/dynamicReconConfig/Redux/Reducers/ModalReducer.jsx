// Redux Toolkit Slice (reducer)
import { createSelector, createSlice } from '@reduxjs/toolkit';

const ModalInitialState = {
  ActiveModal: ''
  , IsVisible: true
};

const initialState = {
  Modal: ModalInitialState,
};

const ModalSlice = createSlice({
  name: 'Modal',
  initialState: initialState,
  reducers: {
    setActiveModal: (state, action) => {
      state.Modal.ActiveModal = action.payload;
    },
    setIsModalVisible: (state, action) => {
      state.Modal.IsVisible = action.payload;
    },
    setModal: (state, action) => {
      state.Modal = action.payload;
    },
  },
});


export const selectModalState = (state) => {
  // console.log(state);  
  return state.dynamicRootReducer.ModalPopUp.Modal
};

export const selectActiveModal = createSelector([selectModalState], (a) => a.ActiveModal);
export const selectIsModalVisible = createSelector([selectModalState], (a) => a.IsVisible);

export const {
  setActiveModal,
  setIsModalVisible,
  setModal,
} = ModalSlice.actions;

export default ModalSlice.reducer;
