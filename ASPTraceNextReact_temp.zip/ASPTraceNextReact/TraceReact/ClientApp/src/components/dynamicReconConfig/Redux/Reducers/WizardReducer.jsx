// Redux Toolkit Slice (reducer)
import { createSelector, createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import postHeader from '../../../../pages/login/services/post-header';


export const postJoinsAsync = createAsyncThunk('postJoins/post', async ({ ClientDetailsData, RawJoinData }) => {
    try {
        const response = await axios.post(
            'api/DynamicReconConfig/PostJoinTables',
            { ClientDetails: ClientDetailsData, JoinTables: RawJoinData },
            { headers: postHeader(), mode: 'cors' }
        );

        return response.data; // Assuming the response contains the data you want to return
    } catch (error) {
        console.error('Error in postJoinsAsync:', error);
        throw error;
    }
});



const ProgressPanelInit = {
    isVisible: false
}

const WizardInitialState = {
    isVisibleWizardContainer: false,
    WizardStages: [
        { stageNo: 1, StageName: 'DataTables Configuration', path: 'DataTables-Configuration', isCompleted: false },
        { stageNo: 2, StageName: 'Merged Table Configuration', path: 'Merged-Table-Configuration', isCompleted: false },
        { stageNo: 3, StageName: 'Final Configuration', path: 'Final-Configuration', isCompleted: false },
    ],
    Activestage: 0,

};

const ContainerData = {
    isMultiTable: false
    , TablesCount: 2
    , JoinTableComplete: false
    , CaseJoinTableComplete: false
    , RawJoinData: null
    , ActiveTable: null
    , CaseTableData: null
    , ClickedRow: null
    , JoinTables: null
    , TabData: null
}
const Tab = {
    Name: 'Select'
    , ContainerData: ContainerData
}

const InitDataTableConfig = {
    Tabs: Tab

}

const initialState = {
    ProgressPanel: ProgressPanelInit,
    Wizard: WizardInitialState,
    DataTableConfig: InitDataTableConfig
};




const ModalSlice = createSlice({
    name: 'MainPanel',
    initialState: initialState,
    reducers: {
        setIsWizardVisible: (state, action) => {
            state.Wizard.isVisibleWizardContainer = action.payload;
        },
        setWizardStages: (state, action) => {
            state.Wizard.WizardStages = action.payload;
        },
        setTabData: (state, action) => {
            state.DataTableConfig.Tabs.ContainerData.TabData = action.payload;
        },
        setCaseTableData: (state, action) => {
            state.DataTableConfig.Tabs.ContainerData.CaseTableData = action.payload;
        },
        setJoinTables: (state, action) => {
            state.DataTableConfig.Tabs.ContainerData.JoinTables = action.payload;
        },
        setClickedRow: (state, action) => {
            state.DataTableConfig.Tabs.ContainerData.ClickedRow = action.payload;
        },
        setWizardDefault: (state) => {
            state = initialState;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(postJoinsAsync.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(postJoinsAsync.fulfilled, (state, action) => {
                state.loading = false;
                state.data = action.payload;
            })
            .addCase(postJoinsAsync.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message;
            });
    },
});


export const selectDataTableConfigState = (state) => { return state.dynamicRootReducer.MainPanel.DataTableConfig };

export const selectProgressPanelState = (state) => { return state.dynamicRootReducer.MainPanel.ProgressPanel };

export const selectWizardPanelState = (state) => { return state.dynamicRootReducer.MainPanel.Wizard };


//  select Variables

export const selectIsWizardVisible = createSelector([selectWizardPanelState], (a) => { return a.isVisibleWizardContainer });

export const selectWizardStages = createSelector([selectWizardPanelState], (a) => { return a.WizardStages });

export const selectTabData = createSelector([selectDataTableConfigState], (a) => a.Tabs.ContainerData.TabData);

export const selectCaseTableData = createSelector([selectDataTableConfigState], (a) => a.Tabs.ContainerData.CaseTableData);

export const selectClickedRow = createSelector([selectDataTableConfigState], (a) => a.Tabs.ContainerData.ClickedRow);

export const selectJoinTables = createSelector([selectDataTableConfigState], (a) => a.Tabs.ContainerData.JoinTables);


export const {
    setIsWizardVisible,
    setCaseTableData,
    setClickedRow,
    setJoinTables,
    setTabData,
    setWizardStages,
} = ModalSlice.actions;

export default ModalSlice.reducer;
