import React from "react";

export const ArrowLeft = ({ className, size = "15" }) => {
    return (
        <svg class={`arrow-right-1 ${className}`}
            fill="none"
            height="15"
            viewBox="0 0 24 24"
            width="15"
            xmlns="http://www.w3.org/2000/svg"
            transform="rotate(180)">
            <path class="path" d="M5 12H19M19 12L12 5M19 12L12 19"
                stroke="#101828"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"></path>
        </svg>

    );
};
