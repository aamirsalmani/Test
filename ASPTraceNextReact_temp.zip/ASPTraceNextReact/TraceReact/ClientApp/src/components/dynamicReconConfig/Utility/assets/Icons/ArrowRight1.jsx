

import React from "react";

export const ArrowRight1 = ({ className='' ,size="15" ,color='#101828'}) => {
  return (
    <svg
      className={`arrow-right-1 ${className}`}
      fill="none"
      height={size}
      viewBox="0 0 24 24"
      width={size}
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M5 12H19M19 12L12 5M19 12L12 19"
        stroke={color}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
      />
    </svg>
  );
};
