

import React from "react";

export const ArrowRight2 = ({ height='800',width='800',className }) => {
  return (
    <svg
      className={`arrow-right-2 ${className}`}
      fill="none"
      height={height}
      viewBox="0 0 21 20"
      width={width}
      xmlns="http://www.w3.org/2000/svg"    
    >
      <path
        className="path"
        d="M4.66669 10.0001H16.3334M16.3334 10.0001L10.5 4.16675M16.3334 10.0001L10.5 15.8334"
        stroke="#16161D"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.67"
      />
    </svg>
  );
};
