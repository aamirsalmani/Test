import React from 'react';
import { CircularProgressbar } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

const ProgressBar = ({ width = '80px', height = '80px', progressColor = '#82DBB0', remainingColor = '#F5F5F5', percentage = 10, strokeWidth = 15,
  textColor = '#7B7B7B', fontSize = '1.5rem', fontWeight = 'bolder', backgroundColor = '#3e98c7'
}) => {
    

  return (


    <div style={{ width: width, height: height }}>
      <CircularProgressbar value={percentage} strokeWidth={strokeWidth} text={`${percentage}%`}
        styles={{
          // Customize the root svg element
          root: {},
          // Customize the path, i.e. the "completed progress"
          path: {
            // Path color
            stroke: `${progressColor}`,
            // Whether to use rounded or flat corners on the ends - can use 'butt' or 'round'
            strokeLinecap: 'round',
            // Customize transition animation
            transition: 'stroke-dashoffset 0.5s ease 0s',
            // Rotate the path
            transform: 'rotate(0.25turn)',
            transformOrigin: 'center center',
          },
          // Customize the circle behind the path, i.e. the "total progress"
          trail: {
            // Trail color
            stroke: `${remainingColor}`,
            // Whether to use rounded or flat corners on the ends - can use 'butt' or 'round'
            strokeLinecap: 'butt',
            // Rotate the trail
            transform: 'rotate(0.25turn)',
            transformOrigin: 'center center',
          },
          // Customize the text
          text: {
            // Text color
            fill: `${textColor}`,
            // Text size
            fontSize: `${fontSize}`,
            fontWeight: `${fontWeight}`
          },
          // Customize background - only used when the `background` prop is true
          background: {
            fill: `${backgroundColor}`,
          },
        }}

      />
    </div>

  );
};

export default ProgressBar;
