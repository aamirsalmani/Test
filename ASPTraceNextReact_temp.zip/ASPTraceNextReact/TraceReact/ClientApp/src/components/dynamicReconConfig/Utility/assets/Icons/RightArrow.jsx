const RightArrow = ({ width="10", height="10", color="#3c3c3c" }) => (<span>
    <svg xmlns="http://www.w3.org/2000/svg" width={width} height={height} viewBox="0 0 21 38" fill="none">
        <path d="M2.5 3L17.0858 17.5858C17.8668 18.3668 17.8668 19.6332 17.0858 20.4142L2.5 35" stroke={color} strokeWidth="6" />
    </svg>
</span>);

export default RightArrow;