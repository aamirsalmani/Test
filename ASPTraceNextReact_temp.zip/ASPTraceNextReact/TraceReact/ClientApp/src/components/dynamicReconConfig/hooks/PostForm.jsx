import React from 'react'
import { useSelector } from 'react-redux'
import { selectFormData } from '../Redux/Reducers/FormReducer'
import usePostAPI from './usePostAPI'

const PostForm = async (formData) => {
        
    const data = await usePostAPI('api/DynamicReconConfig/PostFormData', formData);
    if (data === null || data === ''){
        return 'error occured'
    }
    else
        return 'Form Update Successful';

}

export default PostForm