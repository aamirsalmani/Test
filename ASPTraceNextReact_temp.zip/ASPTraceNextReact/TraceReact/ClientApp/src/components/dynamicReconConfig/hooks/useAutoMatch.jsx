import React from 'react'

const useAutoMatch = (SourceData,DestData, SourceCol, DestCol) => {

    const getAutoMatch = () => {

        const NewData = DestData.map((item) => {
            let Val = SourceData.filter((Sitem) => Sitem === item[SourceCol] );
            
            if(Val.length>0){

                let obj = JSON.parse(`{"${DestCol}":"T1.${item[SourceCol]}"}`);
                return { ...item, ...obj }
            }
            else{
                return { ...item};
            }

            
        })

        return NewData;
    }


    return {getAutoMatch};
}

export default useAutoMatch