
import axios from 'axios';
import MaximusAxios from "../../common/apiURL" ; 
import authHeader from '../../../pages/login/services/auth-header';


const UseGetAPI = (baseURL, queryParams) => {

    
        const fetchData = async () => {
            try {
                
                let queryString = '';
                if (queryParams) {
                    queryString = Object.keys(queryParams)
                        .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(queryParams[key])}`)
                        .join('&');
                    queryString = `?${queryString}`;
                }
                const {data} = await MaximusAxios.get(`${baseURL}${queryString}`,{  mode: 'cors' });
                
                return data;
            } catch (error) {
                console.log('useGetAPI',error);
                return null;
            } 
        };


    return fetchData();
};

export default UseGetAPI;
