const useGetApiPromise = async (baseURL, queryParams) => {
    try {
        
        let queryString = '';
        if (queryParams) {
            queryString = Object.keys(queryParams)
                .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(queryParams[key])}`)
                .join('&');
            queryString = `?${queryString}`;
        }
        const Promise = await MaximusAxios.get(`${baseURL}${queryString}`,{  mode: 'cors' });
        
        return Promise;
    } catch (error) {
        console.log('useGetAPI',error);
        return null;
    } 
};