import React from 'react'
import { useSelector } from 'react-redux';
import { selectActiveTab, selectJoinForm } from '../Redux/Reducers/FormReducer';

const generateSQLQuery = (data) => {
    if (!data || !Array.isArray(data) || data.length === 0) {
        return '';
    }

    const queryObject = data[0];
    const { TableName, JoinColumns, conditions, MergeTable } = queryObject;
    if(MergeTable === undefined) return '';
    // Generating the SELECT part of the query
    let selectQuery = 'SELECT \n';
    const selectColumns = MergeTable.map(item => `${item.CaseStatement === ''? "''":item.CaseStatement} as ${item.AliasColumn}`).join(' , ');
    selectQuery += selectColumns;
    selectQuery += `\n FROM ${TableName.label} T1 \n`;

    // Generating the WHERE part of the query
    let whereQuery = '';
    if (conditions && conditions.length > 0) {
        whereQuery = 'WHERE ';
        whereQuery += conditions.map(condition => {
            const {  Operation , Condition, Value, boolean } = condition;
            const conditionString = `${Operation.OperationValue.replace('select','')} ${Condition.label.replace('select','')} ${Value} ${boolean.label.replace('select','')}`;
            

            return conditionString;
        }).join(' ');
    }

    return `${selectQuery}${whereQuery}`;
}

const useGetQueryData = () => {
    const Values = useSelector(selectJoinForm);
    const ActiveTable = useSelector(selectActiveTab);
    const FilteredData = Values.filter((item) => item.TableName.label === ActiveTable);
    const query = generateSQLQuery(FilteredData);

    return query
}

export default useGetQueryData