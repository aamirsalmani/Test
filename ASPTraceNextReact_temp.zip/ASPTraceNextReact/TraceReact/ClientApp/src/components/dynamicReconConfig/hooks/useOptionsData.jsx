import { useQuery } from 'react-query';
import UseGetAPI from './useGetAPI';
import { useSelector } from 'react-redux';
import { selectMenuParams } from '../Redux/Reducers/MenuBarReducer';
import { selectActiveTabColumns } from '../Redux/Reducers/FormReducer';


// if(FromDB){

//     if (MenuState === undefined) return 'Parameters not defined in MenuParams';
    
//     const Params = MenuState
//     const { data, isLoading, isError } = useQuery('options', async () => {
//         const response = await useGetApiPromise('api/DynamicReconConfig/GetOptionsList', Params);
//         if (!response.ok) {
//             throw new Error('Network response was not ok');
//         }
//         return response.json();
//     }, {
//         staleTime: Infinity
//     });
    
//     if (isLoading) {
//         return { isLoading };
//     }
    
//     if (isError) {
//         return { isError };
//     }
    
//     const {  operations, conditions } = data;

//     return { columns, operations, conditions, values };
// }
// else

const useOptionsData = (FromDB = false) => {
    const MenuState = useSelector(selectMenuParams);
    const columns = useSelector(selectActiveTabColumns);
    const values = columns;


    const operations = [
        { label: 'LEFT', value: 'left' },
        { label: 'RIGHT', value: 'right' },
        { label: 'REPLACE', value: 'replace' },
        { label: 'IN', value: 'in' },
        { label: 'SUBSTRING', value: 'substring' },
        { label: 'CAST', value: 'CAST' },
        { label: 'FORMAT', value: 'format' }
    ];

    const conditions = [
        { label: '<', value: '<' },
        { label: '>', value: '>' },
        { label: '<=', value: '<=' },
        { label: '>=', value: '>=' },
        { label: '!=', value: '!=' },
        { label: '<>', value: '<>' },
        { label: 'IN', value: 'in' },
        { label: '=', value: '=' },
        { label: 'IS NULL', value: 'IS NULL' },
        { label: 'IS NOT NULL', value: 'IS NOT NULL' },
        { label: 'LIKE', value: 'like' },
        { label: 'CASE WHEN', value: 'CASE WHEN' },
    ];

    return { columns, operations, conditions, values };




};

export default useOptionsData;
