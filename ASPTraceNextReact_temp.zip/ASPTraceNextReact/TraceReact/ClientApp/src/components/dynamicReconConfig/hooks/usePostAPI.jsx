import axios from 'axios';
import postHeader from '../../../pages/login/services/post-header';


const usePostAPI = (baseURL, postData) => {
    const postDataAsync = async () => {
        try {
            const { data } = await axios.post(baseURL, postData, { headers: postHeader() });
            return data;
        } catch (error) {
            console.error('usePostAPI', error);
            return null;
        }
    };

    return postDataAsync();
};

export default usePostAPI;
