import React from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { selectMenuState } from '../Redux/Reducers/MenuBarReducer';
import { selectActiveTab, selectFormData, selectJoinForm, updateJoinForm } from '../Redux/Reducers/FormReducer';
import PostForm from './PostForm';
import { setAlertMessageBox } from '../Redux/Reducers/AlertMessageReducer';

const usePostForm = () => {
    const dispatch = useDispatch();
    const ActiveTab = useSelector(selectActiveTab);
    const Table = useSelector(selectJoinForm);

    const MenuState = useSelector(selectMenuState);

    const FormValues = useSelector(selectFormData);
    const Serialized = JSON.stringify(FormValues);



    const SubmitForm = async () => {
        const localTable = [...Table].map((item) => {
            if (item.TableName.label === ActiveTab) {
                return { ...item, Status: { ...item.Status, IsActive: true, IsComplete: true } }
            }
            else
                return { ...item, Status: { ...item.Status, IsActive: false } }
        });
        dispatch(updateJoinForm(localTable));

        const form = new FormData();
        form.append('ClientID', MenuState.client?.clientID);
        form.append('NetworkType', MenuState.selectedNetworkType?.value);
        form.append('ChannelID', MenuState.selectedChannelValue?.value);
        form.append('ModeID', MenuState.selectedModeValue?.value);
        form.append('Form', Serialized);

        const res = await PostForm(form);
        console.log('Form Submit', res)
        return res;
    }

    return { SubmitForm };
}

export default usePostForm