﻿import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
// CSS
import "./Styles/reconConfig.css";
// Components
import SidebarMain from "../common/SidebarMain";
import ReconConfigMainWindow from "./ReconConfigMain";
import { useLocation, useMatch, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setInitializeValues } from './Redux/Reducers/MenuBarReducer';
import { setIsWizardVisible } from "./Redux/Reducers/WizardReducer";


const alertUser = (e) => {
  e.preventDefault();
  e.returnValue = "";
};

const ReconConfig = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });
  const [show, setShow] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const isConfigurationRoute = useMatch('/configuration/dynamic-Reconciliation-config');



  useEffect(() => {
    
    if (isConfigurationRoute) {
      
      dispatch(setIsWizardVisible(false));
      dispatch(setInitializeValues());
      setShow(true);
    }
    else {
      setShow(false);
    }

    if (localStorage.getItem('firstLoadDone') === null) {
      // If it's the first load, set the flag in local storage to true and reload the page
      localStorage.setItem('firstLoadDone', 1);
    }
    else{
      navigate('/configuration/dynamic-Reconciliation-config');
    }

  }, []);


  return (
    <div className="mainView">
         <ReconConfigMainWindow />
    </div>
  );
};

export default ReconConfig;
