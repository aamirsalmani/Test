﻿import React from "react";
import { useSelector } from "react-redux";
// Components
import "../dynamicFileConfiguration/dynamicFileConfiguration.css";
import SidebarMain from "../common/SidebarMain";
import DynamicReportConfigurationMainWindow from "./DynamicReportConfigurationMainWindow";

const DynamicFileConfiguration = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <DynamicReportConfigurationMainWindow />
        </div>
    );
};

export default DynamicFileConfiguration;
