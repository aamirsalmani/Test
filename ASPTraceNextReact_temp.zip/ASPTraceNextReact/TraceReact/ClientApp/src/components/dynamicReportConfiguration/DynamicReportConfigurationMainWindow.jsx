﻿import React, { useState, useEffect,useRef } from "react";
import Select, { components } from "react-select";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL";
import AsyncSelect from 'react-select/async';
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { AddIcon, RemoveIcon } from '../dynamicReconConfig/Utility/assets/Icons/iconsIndex';
import { useSelector } from "react-redux";
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"
import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
import './DynamicReportConfiguration.css';
import * as CT from '../dynamicReconConfig/Components/BasicComponents/CustomTable/CustomTable'
import editRow from "../../images/common/editRow.svg";
const DynamicReportConfigurationMainWindow = () => {
const [reportOptions, setReportOptions] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newReportName, setNewReportName] = useState('');
  const [selectedReportId, setSelectedReportId] = useState(null);
  const [optionsChannelType, setOptionsChannelType] = useState([
    { channelID: "0", channelName: "ALL" },
  ]);
  const [selectedChannelValue, setSelectedChannelValue] = useState(null);

  const [optionsModeType, setOptionsModeTypeValue] = useState([
    { modeID: "0", modeName: "ALL" },
  ]);
  const [selectedModeValue, setSelectedModeValue] = useState(null);

  const handleChannelChange = (value) => {
    setSelectedChannelValue(value);

  };
const [isEditMode, setIsEditMode] = useState(false);
  const [tableOptions, setTableOptions] = useState([]);
  const [columnOptions, setColumnOptions] = useState([]);

  const [showReportConfig, setShowReportConfig] = useState(false);
  const [showReportConfigGrid, setshowReportConfigGrid] = useState(true);

  const [showSubmitConfig, setshowSubmitConfig] = useState(false);
const [topN, setTopN] = useState("");

  const currentUser = useSelector((state) => state.authReducer);
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });
  const [selectedClientValue, setSelectedValue] = useState(null);

  const [selectedReportValue, setSelectedReportValue] = useState(null);

  const [selectedloadReportValue, setSelectedloadReportValue] = useState(null);

  const [isShowQuery, setShowQuery] = useState(false);

  const [reportColumnsList, setReportColumnsList] = useState([]);

  const [inputValue, setValue] = useState('0');
  const fetchClientData = (inputValue) => {

    return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, { mode: 'cors' }).then(result => {
      if (inputValue.length === 0) {
        return result.data;
      }
      else {
        return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
      }
    }).catch(function (error) {
      console.log(error.response);
    });
  }

  useEffect(() => {
    if (showReportConfigGrid) {
      MaximusAxios.get('/api/DynamicReport/GetReportList')
      .then(res => {
        setReportOptions(res.data);
        fetchReportGridData(0); // or just fetchReportGridData() if 0 isn't needed
      })
      .catch(err => {
        console.error("Error loading report list:", err);
      });
      
    }
  }, [showReportConfigGrid]);

  const fetchReportGridData = async (reportId) => {
  setIsLoading(true);
  try {
    const response = await MaximusAxios.get("/api/DynamicReport/GetDynamicReportGrid", {
      params: { reportId: reportId }
    });

    console.log(response.data);

    if (Array.isArray(response.data)) {
      setReportData(response.data);
    } else {
      setReportData([]);
    }
  } catch (error) {
    console.error("Error fetching report grid:", error);
    setReportData([]);
  } finally {
    setIsLoading(false);
  }
};




  const handleInputChange = value => {
    setValue(value);
  };

  const handleClientChange = (value) => {
    setSelectedValue(value);

    try {
      setIsLoading(true);

      if (value.clientID !== "0") {
        MaximusAxios.get("api/DynamicReport/GetChannelOptionList?ClientID=" +
          value.clientID,
          { mode: "cors" }
        ).then((resultChannels) => {
          setOptionsChannelType(resultChannels.data);

          MaximusAxios.get("api/DynamicReport/GetAllModeOptionList", {
            mode: "cors",
          }).then((resultModes) => {
            setOptionsModeTypeValue(resultModes.data);
          });



          setIsLoading(false);
        });
      }
    } catch (ex) {
      console.log(ex);
      setIsLoading(false);
    }
  };

  const onReset = (e) => {
    e.preventDefault();
    window.location.reload(false);
  };

  const onSubmit = () => {

    setIsLoading(true);
    setShowQuery(false);

    MaximusAxios.get('/api/DynamicReport/GetDynamicReportColumnList?ReportID=' + selectedReportValue.value, { mode: 'cors' }).then(ColumnData => {
      //console.log(ColumnData.data);
      setReportColumnsList(ColumnData.data);
      setIsLoading(false);
      setShowQuery(true);
    }).catch(function (error) {
      if (error.response) {
        console.log(error.response.data);
      }
      setIsLoading(false);
    });
  };

  const handleReportChange = value => {
    setSelectedReportValue(value);
  };



  const handleCheckboxChange = (ID, value) => {

    let TempData = reportColumnsList.map((item) => {
      if (item.columnID === ID) {
        item.isChecked = true;
        return item;
      } else {
        return item;
      }
    });

    setReportColumnsList(TempData);

    // console.log(TempData);
  };

  const handleTextboxChange = (ID, value) => {

    let TempData = reportColumnsList.map((item) => {
      if (item.columnID === ID) {
        item.aliasColumnName = value;
        return item;
      } else {
        return item;
      }
    });

    setReportColumnsList(TempData);

    //console.log(TempData);
  };





  const handleModeChange = (value) => {
    // console.log(value);
    setSelectedModes(value || []);
    setSelectedModeValue(value);

  };

  const [selectedModes, setSelectedModes] = useState([]);
  const removeMode = (modeID) => {
    setSelectedModes(selectedModes.filter((mode) => mode.value !== modeID));
  };

  const [reportName, setReportName] = useState('');
  const [tableConfigs, setTableConfigs] = useState([
    { table: null, columns: [], availableColumns: [], joinType: "", joinTable: "",  joinLeftColumn: null, joinRightColumn: null  }
  ]);

  const handleAddRow = () => {
    let alertMessages = "";

    // Validate the last row (current row before adding new one)
    const lastIndex = tableConfigs.length - 1;
    const lastConfig = tableConfigs[lastIndex];

    alertMessages = validateTableConfig(lastConfig, lastIndex);

    if (alertMessages.length > 0) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "info",
        alertTitle: "Mandatory Field",
        alertMessage: alertMessages
      });
      return;
    }

    // Add new empty row if validation passed
    setTableConfigs([
      ...tableConfigs,
      {
        table: null,
        columns: [],
        availableColumns: [],
        joinType: "",
        joinTable: "",
        joinLeftColumn: "",
        joinRightColumn: "",
        query: ""
      }
    ]);
  };

  const handleRemoveRow = (index) => {
    const newConfigs = [...tableConfigs];
    newConfigs.splice(index, 1);
    setTableConfigs(newConfigs);
  };

  const handleTableChange = async (selected, index) => {
    const updated = [...tableConfigs];
    updated[index].table = selected;
    updated[index].columns = [];
    updated[index].joinType = "";
    updated[index].joinLeftColumn = null;
  updated[index].joinRightColumn = null;
  updated[index].joinTable = "";
    // Fetch columns and update availableColumns
    const columns = await fetchColumns(selected.label);
    updated[index].availableColumns = columns;

    setTableConfigs(updated);
  };



  const handleColumnChange = (selectedColumns, index) => {
    const updated = [...tableConfigs];
    updated[index].columns = selectedColumns;
    setTableConfigs(updated);
  };



  const Validate = () => {

    let alertMessages = "";

    if (selectedClientValue === null || selectedClientValue.clientID === 0) {
      alertMessages += "Please select Client. \n";
    }

    if (selectedChannelValue === undefined || selectedChannelValue === null || selectedChannelValue.value === '0') {
      alertMessages += "Please select Channel. \n";
    }

    if (selectedModeValue === undefined || selectedModeValue === null || selectedModeValue.value === '0') {
      alertMessages += "Please select Mode. \n";
    }

    return alertMessages;
  };


  const handleAddButtonClick = async () => {
    const alertMsg = Validate();

   
    const toggleBtn = document.querySelector('[data-bs-target="#unmatchedFiltersCollapse"]');
    if (toggleBtn) {
      toggleBtn.click();  // This will trigger the collapse
    }
    await fetchTables();
    setIsEditMode(false);
    setshowReportConfigGrid(false);
    setShowReportConfig(true);
    setshowSubmitConfig(true);
  };


  const fetchTables = async () => {
    setIsLoading(true);
    try {
      const response = await MaximusAxios.get(
        `/api/DynamicReport/GetDynamicReportTableList`);

      console.log(response.data);
      setTableOptions(
        response.data.map((t) => ({ label: t.tableName, value: t.id }))
      );
    } catch (error) {
      if (error.response) {
        console.error("Table API Error:", error.response.data);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const fetchColumns = async (tableName) => {
    setIsLoading(true);
    try {
      const response = await MaximusAxios.get(
        `/api/DynamicReport/GetDynamicReportColumnListByTable?TableName=${tableName}`,
        { mode: 'cors' }
      );
      return response.data;
    } catch (error) {
      console.error("Column API Error:", error?.response?.data || error);
      return [];
    } finally {
      setIsLoading(false);
    }
  };

  const CheckboxOption = (props) => (
    <components.Option {...props}>
      <input
        type="checkbox"
        checked={props.isSelected}
        onChange={() => null} // prevents React warning
        style={{ marginRight: 8 }}
      />
      {props.label}
    </components.Option>
  );

 const generateQueryWithJoins = (configs, whereConditions = [], topN = "") => {
  if (configs.length === 0) return "";

  const baseAlias = `T1`;
  let selectClause = [];

  const topClause = topN ? `TOP ${topN} ` : "";

  let fromClause = `${configs[0].table?.label} ${baseAlias} WITH (NOLOCK)`;
  let joinClauses = [];

  configs.forEach((config, idx) => {
    const alias = `T${idx + 1}`;
    if (config.columns && config.columns.length > 0) {
      selectClause.push(...config.columns.map(col => `${alias}.${col.label}`));
    }

    if (idx > 0 && config.joinType && config.joinLeftColumn && config.joinRightColumn) {
      const aliasLeft = `T${idx}`;
      const aliasRight = `T${idx + 1}`;
      const tableName = config.table?.label;

      joinClauses.push(
        `${config.joinType} JOIN ${tableName} ${aliasRight} WITH (NOLOCK) ON ${aliasLeft}.${config.joinLeftColumn.label} = ${aliasRight}.${config.joinRightColumn.label}`
      );
    }
  });

  let whereClause = "";
  if (whereConditions.length > 0) {
    const conditions = whereConditions
      .filter(w => w.column && w.operator && w.value !== "")
      .map((w, index) => {
        const col = typeof w.column === 'object' ? w.column.label : w.column;
        const condition = `${col} ${w.operator} '${w.value}'`;

        if (index === 0) return condition;

        const operator = whereConditions[index - 1]?.operatorType || 'AND';
        return `${operator} ${condition}`;
      });

    if (conditions.length > 0) {
      whereClause = ` WHERE ${conditions.join(" ")}`;
    }
  }

  return `SELECT ${topClause}${selectClause.join(', ')} FROM ${fromClause} ${joinClauses.join(' ')}${whereClause}`;
};




  const CustomMultiValue = () => null;

  // Remove the 'x' button (clear indicator)
  const CustomClearIndicator = () => null;

  const validateTableConfig = (config, index) => {
    let msg = "";

    if (!config.table) {
      msg += `Please select a table for row ${index + 1}.\n`;
    }

    if (!config.columns || config.columns.length === 0) {
      msg += `Please select at least one column for row ${index + 1}.\n`;
    }

    if (index > 0) {
      if (!config.joinType) {
        msg += `Please select join type for row ${index + 1}.\n`;
      }
    if (index > 0 && (!config.joinLeftColumn || !config.joinRightColumn)) {
  msg += `Please select join columns for row ${index + 1}.\n`;
}
    }

    return msg;
  };

  const [whereConditions, setWhereConditions] = useState([
    { column: '', operator: '=', value: '', operatorType: 'AND' }
  ]);


  const getAllColumnOptions = () => {
    const options = [];

    tableConfigs.forEach((config, i) => {
      const tableAlias = `T${i + 1}`;
      (config.availableColumns || []).forEach(col => {
        options.push({
          value: `${tableAlias}.${col.value}`,
          label: `${tableAlias}.${col.label}`
        });
      });
    });

    return options;
  };
  const parseQuery = async (query) => {
    try {
      const response = await MaximusAxios.post(
        `/api/DynamicReport/ParseQuery`,
        query,  // ✅ Just the plain string
        {
          headers: {
            "Content-Type": "application/json"
          },
          mode: 'cors'
        }
      );
      const result = response.data;

      if (result?.success) {
        alert("✅ Query is valid!");
      } else {
        alert("❌ Invalid Query: " + (result?.message || "Unknown error"));
      }
    } catch (error) {
      console.error("Parse Query Error:", error?.response?.data || error);
      alert("❌ Server Error: " + (error?.response?.data?.message || error.message));
    }
  };

  const [customQuery, setCustomQuery] = useState(generateQueryWithJoins(tableConfigs, whereConditions));
  useEffect(() => {
  setCustomQuery(generateQueryWithJoins(tableConfigs, whereConditions, topN));
}, [tableConfigs, whereConditions, topN]);


  const handleSubmit = async () => {
    // Validation
    if (!reportName.trim()) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "warning",
        alertTitle: "Missing Field",
        alertMessage: "Please enter Report Name."
      });
      return;
    }

    if (tableConfigs.length === 0 || !tableConfigs[0].table || tableConfigs[0].columns.length === 0) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "warning",
        alertTitle: "Missing Data",
        alertMessage: "Please select at least one table and its columns."
      });
      return;
    }

    // ✅ Create comma-separated list of table names
    const tableNames = tableConfigs
      .filter(cfg => cfg.table?.label)
      .map(cfg => cfg.table.label)
      .join(",");

    // ✅ Prepare final payload
    const payload = {
      ReportName: reportName,
      TableConfigs: JSON.stringify(
        tableConfigs.map((t, index) => ({
          table: t.table,
          columns: t.columns || [],
          joinType: index > 0 ? t.joinType || '' : '',
          joinCondition:
        index > 0 && t.joinLeftColumn && t.joinRightColumn
          ? `T${index}.${t.joinLeftColumn.label} = T${index + 1}.${t.joinRightColumn.label}`
          : '',
    }))
      ),

      

      WhereConfigs: JSON.stringify(
        whereConditions.map((w, i) => ({
          column: w.column || null,
          operator: w.operator || '',
          value: w.value || '',
          operatorType: i < whereConditions.length - 1 ? (w.operatorType || 'AND') : '',
        }))
      ),
      Query: customQuery,
       TopN: topN || null,
      CreatedBy: currentUser?.user?.username
    };

    console.log("whereConditions: ", whereConditions);


    console.log("Payload: ", JSON.stringify(payload));
    try {
      const response = await MaximusAxios.post(
        `/api/DynamicReport/SaveReportConfig`,
        payload,
        {
          headers: {
            "Content-Type": "application/json"
          },
          mode: 'cors'
        }
      );

      const result = response.data;
      if (result?.success) {
        alert("✅ Report saved successfully");
      } else {
        alert("❌ Failed to save report");
      }



      // Optional reset
      setReportName("");
      setCustomQuery("");
      setTableConfigs([
        {
          table: null,
          columns: [],
          availableColumns: [],
          joinType: "",
          joinTable: "",
          joinLeftColumn: null,      // from previous table
    joinRightColumn: null, 
          query: ""
        }
      ]);
      setWhereConditions([{ column: '', operator: '=', value: '', operatorType: 'AND' }]);
      setTopN("");
      setShowReportConfig(false);
      setshowSubmitConfig(false);
      setshowReportConfigGrid(true);

      const collapseEl = document.getElementById('unmatchedFiltersCollapse');
      if (collapseEl && !collapseEl.classList.contains('show')) {
        const toggleBtn = document.querySelector('[data-bs-target="#unmatchedFiltersCollapse"]');
        toggleBtn?.click();
      }

    } catch (error) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "danger",
        alertTitle: "Error",
        alertMessage: "Failed to save report configuration."
      });
      console.error(error);
    }
  };

  const getTableIndexForColumn = (columnValue) => {
    for (let i = 0; i < tableConfigs.length; i++) {
      const config = tableConfigs[i];
      if (config.columns?.some(c => c.value === columnValue)) {
        return i; // Table index
      }
    }
    return 0; // Default fallback
  };

  const handleCancel = () => {
    // Reset or navigate away as needed
    setShowReportConfig(false);
    setshowSubmitConfig(false);
    setReportName('');
    setTopN('');
    setTableConfigs([
      {
        table: null,
        columns: [],
        joinType: '',
       joinLeftColumn: null,      // from previous table
    joinRightColumn: null, 
        availableColumns: [],
      }
    ]);
    setWhereConditions([
      { column: '', operator: '=', value: '', operatorType: 'AND' }
    ]);
    setCustomQuery('');
    const collapseEl = document.getElementById('unmatchedFiltersCollapse');
    if (collapseEl && !collapseEl.classList.contains('show')) {
      const toggleBtn = document.querySelector('[data-bs-target="#unmatchedFiltersCollapse"]');
      toggleBtn?.click();
    }
    setshowReportConfigGrid(true);
  };
  const handleAddWhereRow = () => {
    const lastIndex = whereConditions.length - 1;
    const lastCond = whereConditions[lastIndex];

    let alertMessages = "";

    // Validation logic
    if (!lastCond.column || !lastCond.column.value) {
      alertMessages += `Row ${lastIndex + 1}: Column is required.\n`;
    }
    if (!lastCond.operator) {
      alertMessages += `Row ${lastIndex + 1}: Operator is required.\n`;
    }
    if (!lastCond.value?.toString().trim()) {
      alertMessages += `Row ${lastIndex + 1}: Value is required.\n`;
    }

    if (alertMessages.length > 0) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "info",
        alertTitle: "Mandatory Field",
        alertMessage: alertMessages
      });
      return;
    }

    // Add new empty where condition row
    setWhereConditions([
      ...whereConditions,
      { column: '', operator: '=', value: '', operatorType: 'AND' }
    ]);
  };

  const [reportData, setReportData] = useState([]);
const handleEdit = async (reportId) => {
  try {
    setSelectedReportId(reportId);
    const res = await MaximusAxios.get(`/api/DynamicReport/GetReportConfigById?id=${reportId}`);
    const data = res.data;

    console.log(data);

    setReportName(data.reportName);

    setTopN(data.topN?.toString() || ""); // ✅ Set TopN
    

    // Step 1: Fetch and set table options
    await fetchTables(data.channelID, data.modeID);

    // Step 2: Parse the saved TableConfigs
    const parsedTableConfigs = JSON.parse(data.tableConfigs || '[]');

    // Step 3: Enrich configs with availableColumns and extract joinLeft/RightColumn from joinCondition
    const enrichedTableConfigs = await Promise.all(
      parsedTableConfigs.map(async (config, index) => {
        const tableName = config.table?.label;
        if (!tableName) return config;

        const availableColumns = (await fetchColumns(tableName)).map(col => ({
          label: col.label,
          value: col.value
        }));

        let joinLeftColumn = null;
        let joinRightColumn = null;

        // Parse joinCondition if applicable
        if (config.joinCondition && index > 0) {
          const match = config.joinCondition.match(/T\d+\.(\w+)\s*=\s*T\d+\.(\w+)/);
          if (match) {
            const leftLabel = match[1];
            const rightLabel = match[2];

            // Previous table's availableColumns (if available)
            const prevTableName = parsedTableConfigs[index - 1]?.table?.label;
            let prevColumns = [];
            if (prevTableName) {
              prevColumns = (await fetchColumns(prevTableName)).map(col => ({
                label: col.label,
                value: col.value
              }));
            }

            joinLeftColumn = prevColumns.find(col => col.label === leftLabel) || { label: leftLabel, value: leftLabel };
            joinRightColumn = availableColumns.find(col => col.label === rightLabel) || { label: rightLabel, value: rightLabel };
          }
        }

        return {
          ...config,
          availableColumns,
          joinLeftColumn,
          joinRightColumn
        };
      })
    );

    // Step 4: Set enriched table configs
    setTableConfigs(enrichedTableConfigs);

    // Step 5: Set WHERE conditions
    const parsedWhereConfigs = JSON.parse(data.whereConfigs || '[]');
    setWhereConditions(parsedWhereConfigs);

    // Step 6: Set generated query
    setCustomQuery(data.query);

    // Step 7: Expand report config UI
    const toggleBtn = document.querySelector('[data-bs-target="#unmatchedFiltersCollapse"]');
    if (toggleBtn) toggleBtn.click();

    setshowReportConfigGrid(false);
    setShowReportConfig(true);
    setIsEditMode(true);
    setshowSubmitConfig(true);
  } catch (err) {
    console.error("Error loading report config:", err);
  }
};


 const customQueryRef = useRef();

const handleUpdate = async () => {
  // Validation (same as handleSubmit)
  if (!reportName.trim()) {
    setShowMessageBox({
      isShow: true,
      alertVariant: "warning",
      alertTitle: "Missing Field",
      alertMessage: "Please enter Report Name."
    });
    return;
  }

  if (tableConfigs.length === 0 || !tableConfigs[0].table || tableConfigs[0].columns.length === 0) {
    setShowMessageBox({
      isShow: true,
      alertVariant: "warning",
      alertTitle: "Missing Data",
      alertMessage: "Please select at least one table and its columns."
    });
    return;
  }

 
  // Prepare payload
  const payload = {
    ID: selectedReportId, // ✅ Stored during edit
    ReportName: reportName,
    TableConfigs: JSON.stringify(
      tableConfigs.map((t, index) => ({
        table: t.table,
        columns: t.columns || [],
        joinType: index > 0 ? t.joinType || '' : '',
       joinCondition:
        index > 0 && t.joinLeftColumn && t.joinRightColumn
          ? `T${index}.${t.joinLeftColumn.label} = T${index + 1}.${t.joinRightColumn.label}`
          : '',
    }))
    ),
    WhereConfigs: JSON.stringify(
      whereConditions.map((w, i) => ({
        column: w.column || null,
        operator: w.operator || '',
        value: w.value || '',
        operatorType: i < whereConditions.length - 1 ? (w.operatorType || 'AND') : '',
      }))
    ),
    Query: customQueryRef.current?.value,
    TopN: topN || null,
    CreatedBy: currentUser?.user?.username
  };

  console.log("Update Payload:", payload);

  try {
    const response = await MaximusAxios.post(
      `/api/DynamicReport/UpdateReportConfig`,
      payload,
      {
        headers: {
          "Content-Type": "application/json"
        },
        mode: 'cors'
      }
    );

    const result = response.data;
    if (result?.success) {
      alert("✅ Report updated successfully");
    } else {
      alert("❌ Failed to update report");
    }

    // Optional: Reset everything
    setReportName("");
    setCustomQuery("");
    setTableConfigs([
      {
        table: null,
        columns: [],
        availableColumns: [],
        joinType: "",
        joinTable: "",
        joinLeftColumn: null,      // from previous table
    joinRightColumn: null, 
        query: ""
      }
    ]);
    setWhereConditions([{ column: '', operator: '=', value: '', operatorType: 'AND' }]);
    setShowReportConfig(false);
    setshowSubmitConfig(false);
    setshowReportConfigGrid(true);
    setIsEditMode(false);
    setSelectedReportId(null);

    const collapseEl = document.getElementById('unmatchedFiltersCollapse');
    if (collapseEl && !collapseEl.classList.contains('show')) {
      const toggleBtn = document.querySelector('[data-bs-target="#unmatchedFiltersCollapse"]');
      toggleBtn?.click();
    }

  } catch (error) {
    setShowMessageBox({
      isShow: true,
      alertVariant: "danger",
      alertTitle: "Error",
      alertMessage: "Failed to update report configuration."
    });
    console.error(error);
  }
};

 $(document).ready(function () {
    if (reportData !== null && reportData.length > 0) {
      $("#gvReportList").DataTable({
        bDestroy: true,
        columnDefs: [{ orderable: false, targets: [6, 7] }],
      });
    }
  });

const fetchReportData = (inputValue) => {
  if (!inputValue || inputValue.trim() === "") {
    return Promise.resolve(reportOptions); // return full list
  }

  const filtered = reportOptions.filter(r =>
    r.reportName.toLowerCase().includes(inputValue.toLowerCase())
  );
  return Promise.resolve(filtered);
};

const handleShowButtonClick = () => {
  const reportId = selectedloadReportValue?.id ?? 0; // default to 0 if null
  fetchReportGridData(reportId); // call your grid fetcher
};

  return (
    <div className="configLeft dynamicContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Dynamic Report Configuration
        </h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">File Configuration</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Dynamic Report Configuration</p>
        </div>
      </div>
      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="unmatchedFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="unmatchedFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#unmatchedFiltersCollapse"
                aria-expanded="true"
                aria-controls="unmatchedFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="unmatchedFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="unmatchedFiltersHeading"
              data-bs-parent="#unmatchedFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  {/* <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedClientValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div> */}
                                    <div className="clientNameSelect col">
                                      <label htmlFor="clientName">Report Name</label>
                                      <span className="text-danger font-size13">*</span>
                                                     <AsyncSelect
                    cacheOptions
                    defaultOptions={reportOptions} // initial load
                    loadOptions={fetchReportData} // filtered search (optional)
                    value={selectedloadReportValue}
                    onChange={setSelectedloadReportValue}
                    getOptionLabel={(e) => e.reportName}
                    getOptionValue={(e) => e.id}
                    placeholder="Select Report"
                    id="ddlReport"
                  />
                  
                  
                                    </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
<button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={handleShowButtonClick}
                  >
                    Show
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={handleAddButtonClick}
                  >
                    Add
                  </button>

                </div>
              </div>
            </div>
          </div>
        </div>

        {showReportConfigGrid && (
          <div className="configLeftBottom">
            <div>
              {(!reportData || reportData.length === 0) && (
                <div className="tableBorderBox pb-3 pt-3">
                  <div className="clientNameSelect configFormatEntities">
                    <p className="text-danger font-size12">No Records</p>
                  </div>
                </div>
              )}

              {isShow ? (
                <div className="spinner-container">
                  <div className="loading-spinner"></div>
                </div>
              ) : (
                <>
                  <div className="tableBorderBox pt-3">
                    <div className="w-100 table-responsive">
                      <div className="table-responsive tableContentBox">
                        <table
                          id="gvReportList"
                          className="table table-striped table-hover table-borderless align-middle"
                          style={{ width: "100%" }}
                        >
                          <thead>
                            <tr>
                              <th scope="col">Sr. No.</th>
                             
                              <th scope="col">Report Name</th>
                              <th scope="col">Created By</th>
                              <th scope="col" className="text-center">Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {reportData.map((item, index) => (
                              <tr key={item.id}>
                                <td>{index + 1}</td>
                                
                                <td>{item.reportName}</td>
                                <td>{item.createdby}</td>
                                <td>
                                  <div className="text-center">
                                    <button
                                      type="button"
                                      className="iconButtonBox"
                                      onClick={() => handleEdit(item.id)}
                                    >
                                      <img
                                        src={editRow}
                                        alt="Edit"
                                        title="Edit"
                                      />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        )}
        {showReportConfig && (

          <div className="accordion-item mt-2">
            <div className="accordion-header d-flex justify-content-between align-items-center">
              <h5 className="fontWeight-600 fontSize14 colorBlack mb-0">New Report Configuration</h5>
            </div>
            <div className="accordion-body px-0 pt-3">
              <div className="accordion-body">
                <div className="clientNameSelect col-md-3">
                  <label className="labelStyled">Report Name <span className="text-danger font-size13">*</span></label>
                  <input
                    type="text"
                    className="form-control txt"
                    placeholder="Enter Report Name"
                    value={reportName}
                    onChange={(e) => setReportName(e.target.value)}
                  />
                </div>
                
              </div>
   <div className="accordion-body">
              <div className="clientNameSelect col-md-3 mt-3">
  <label className="labelStyled">Enter Records</label>
  <input
  type="number"
  className="form-control txt"
  placeholder="Enter number of records"
  min="1"
  value={topN}
  onChange={(e) => {
    const value = e.target.value;
    // Only allow digits (no "-", "+", ".", or "e")
    if (/^\d*$/.test(value)) {
      setTopN(value);
    }
  }}
  onKeyDown={(e) => {
    // Prevent typing of e, +, -, .
    if (["e", "E", "+", "-", "."].includes(e.key)) {
      e.preventDefault();
    }
  }}
/>

</div>
</div>
              <div className="accordion-body mt-2">
                <div className="Panel-Container-Body bg-white">
                  <CT.Table>
                    <CT.TableHeader>
                      <CT.TableRow>
                        <CT.TableHead>Table Name</CT.TableHead>
                        <CT.TableHead>Select Columns</CT.TableHead>
                        <CT.TableHead>Join Type</CT.TableHead>
                        <CT.TableHead>Join Condition</CT.TableHead>
                        <CT.TableHead>Actions</CT.TableHead>
                      </CT.TableRow>
                    </CT.TableHeader>

                    <CT.TableBody>
                      {tableConfigs.map((config, index) => (
                        <CT.TableRow key={index} >
                          {/* Table Name */}
                          <CT.TableCell>
                            <div className="clientNameSelect ">

                              <Select
                                options={tableOptions}
                                value={config.table}
                                onChange={(selected) => handleTableChange(selected, index)}
                                placeholder="Select Table"
                              />
                            </div>
                          </CT.TableCell>

                          {/* Select Columns */}
                          <CT.TableCell>
                            <div className="clientNameSelect">

                              <Select
                                isMulti
                                closeMenuOnSelect={false}
                                hideSelectedOptions={false}
                                options={config.availableColumns || []}
                                value={config.columns}
                                onChange={(selected) => handleColumnChange(selected, index)}
                                placeholder="Select Columns"
                                components={{
                                  Option: CheckboxOption,
                                  MultiValue: CustomMultiValue,
                                  ClearIndicator: CustomClearIndicator,
                                }}
                              />
                            </div>
                          </CT.TableCell>

                          {/* Join Type */}
                          <CT.TableCell>
                            {index > 0 && (
                              <div className="clientNameSelect">

                                <Select
                                  options={[
                                    { value: 'INNER', label: 'INNER JOIN' },
                                    { value: 'LEFT', label: 'LEFT JOIN' },
                                    { value: 'RIGHT', label: 'RIGHT JOIN' },
                                  ]}
                                  value={
                                    config.joinType
                                      ? { value: config.joinType, label: config.joinType + ' JOIN' }
                                      : null
                                  }
                                  onChange={(selected) => {
                                    const updated = [...tableConfigs];
                                    updated[index].joinType = selected.value;
                                    updated[index].joinTable = config.table?.label;
                                    updated[index].query = generateQueryWithJoins(updated);
                                    setTableConfigs(updated);
                                  }}
                                  placeholder="Select Join Type"
                                />
                              </div>
                            )}
                          </CT.TableCell>

                          {/* Join Condition */}
                        {/* Join Condition */}
<CT.TableCell>
  {index > 0 && (
    <div className="d-flex gap-2 clientNameSelect">
      {/* Left Dropdown - Previous Table Columns */}
      <Select
        options={
          tableConfigs[index - 1]?.availableColumns?.map(col => ({
            value: col.value,
            label: col.label
          })) || []
        }
        value={config.joinLeftColumn}
        onChange={(selected) => {
          const updated = [...tableConfigs];
          updated[index].joinLeftColumn = selected;
          updated[index].joinTable = config.table?.label;
          updated[index].query = generateQueryWithJoins(updated);
          setTableConfigs(updated);
        }}
        placeholder="Prev Table Column"
      />

      {/* Right Dropdown - Current Table Columns */}
      <Select
        options={
          config.availableColumns?.map(col => ({
            value: col.value,
            label: col.label
          })) || []
        }
        value={config.joinRightColumn}
        onChange={(selected) => {
          const updated = [...tableConfigs];
          updated[index].joinRightColumn = selected;
          updated[index].joinTable = config.table?.label;
          updated[index].query = generateQueryWithJoins(updated);
          setTableConfigs(updated);
        }}
        placeholder="Curr Table Column"
      />
    </div>
  )}
</CT.TableCell>


                          {/* Actions */}
                          <CT.TableCell>
                            <div className="d-flex gap-1">
                              <button className="custom-edit-button" onClick={handleAddRow}>
                                <AddIcon />
                              </button>
                              {tableConfigs.length > 1 && (
                                <button
                                  className="custom-edit-button"
                                  onClick={() => handleRemoveRow(index)}
                                >
                                  <RemoveIcon />
                                </button>
                              )}
                            </div>
                          </CT.TableCell>
                        </CT.TableRow>
                      ))}
                    </CT.TableBody>
                  </CT.Table>
                </div>

              </div>
              <div className="accordion-body mt-2">
                <div className="Panel-Container-Body bg-white">

                  <CT.Table>
                    <CT.TableHeader>
                      <CT.TableRow>
                        <CT.TableHead>Column</CT.TableHead>
                        <CT.TableHead>Operator</CT.TableHead>
                        <CT.TableHead>Value</CT.TableHead>
                        <CT.TableHead>AND / OR</CT.TableHead>
                        <CT.TableHead>Actions</CT.TableHead>
                      </CT.TableRow>
                    </CT.TableHeader>

                    <CT.TableBody>
                      {whereConditions.map((cond, i) => (
                        <CT.TableRow key={i}>
                          {/* Column Select */}
                          <CT.TableCell>
                            <div className="clientNameSelect">
                              <Select
                                options={getAllColumnOptions()}
                                value={cond.column || null}
                                onChange={(selected) => {
                                  const updated = [...whereConditions];
                                  updated[i].column = selected || null;
                                  setWhereConditions(updated);
                                }}
                                placeholder="Select Column"
                              />
                            </div>
                          </CT.TableCell>

                          {/* Operator Select */}
                          <CT.TableCell>
                            <div className="clientNameSelect">
                              <Select
                                options={[
                                  { value: '=', label: '=' },
                                  { value: '!=', label: '!=' },
                                  { value: 'LIKE', label: 'LIKE' },
                                  { value: '>', label: '>' },
                                  { value: '<', label: '<' }
                                ]}
                                value={{ value: cond.operator, label: cond.operator }}
                                onChange={(selected) => {
                                  const updated = [...whereConditions];
                                  updated[i].operator = selected.value;
                                  setWhereConditions(updated);
                                }}
                                placeholder="Operator"
                              />
                            </div>
                          </CT.TableCell>

                          {/* Value Input */}
                          <CT.TableCell>
                            <div className="clientNameSelect">
                              <input
                                className="form-control txt"
                                placeholder="Enter value"
                                value={cond.value}
                                onChange={(e) => {
                                  const updated = [...whereConditions];
                                  updated[i].value = e.target.value;
                                  setWhereConditions(updated);
                                }}
                              />
                            </div>
                          </CT.TableCell>

                          {/* AND/OR Dropdown */}
                          <CT.TableCell>
                            {i < whereConditions.length - 1 ? (
                              <div className="clientNameSelect">
                                <Select
                                  options={[
                                    { value: 'AND', label: 'AND' },
                                    { value: 'OR', label: 'OR' }
                                  ]}
                                  value={{
                                    value: cond.operatorType || 'AND',
                                    label: cond.operatorType || 'AND'
                                  }}
                                  onChange={(selected) => {
                                    const updated = [...whereConditions];
                                    updated[i].operatorType = selected.value;
                                    setWhereConditions(updated);
                                  }}
                                  placeholder="AND / OR"
                                />
                              </div>
                            ) : (
                              <div style={{ height: '38px' }} /> // spacer
                            )}
                          </CT.TableCell>

                          {/* Action Buttons */}
                          <CT.TableCell>
                            <div className="d-flex gap-1">
                              <button
                                className="custom-edit-button"
                                onClick={handleAddWhereRow}
                              >
                                <AddIcon />
                              </button>


                              {whereConditions.length > 1 && (
                                <button
                                  className="custom-edit-button"
                                  onClick={() => {
                                    const updated = [...whereConditions];
                                    updated.splice(i, 1);
                                    setWhereConditions(updated);
                                  }}
                                >
                                  <RemoveIcon />
                                </button>
                              )}
                            </div>
                          </CT.TableCell>
                        </CT.TableRow>
                      ))}
                    </CT.TableBody>
                  </CT.Table>
                </div>
              </div>

              <div className="accordion-body mt-3">
                <div className="mb-3">
                  <label className="labelStyled">Generated Query</label>
                  <textarea
                    ref={customQueryRef}
                    className="form-control txt"
                    rows="5"
                    value={customQuery}
                    onChange={(e) => setCustomQuery(e.target.value)}
                  />
                </div>
              </div>
            </div>
            <div className="text-center btnsBtm">
              <button
                className="btnPrimary ms-2"
                onClick={() => parseQuery(customQuery)}
              >
                Parse Query
              </button>
            </div>
          </div>



        )}

        {showSubmitConfig && (
          <div className="accordion-item mt-2">
            <div className="accordion-body">
              <div className="text-center btnsBtm">

                <button
                  className="btnPrimaryOutline"
                  onClick={handleCancel} // Define this function
                >
                  Cancel
                </button>
                {isEditMode ? (
          <button className="btnPrimary ms-2" onClick={handleUpdate}>
            Update
          </button>
        ) : (
          <button className="btnPrimary ms-2" onClick={handleSubmit}>
            Submit
          </button>
        )}

              </div>
            </div>
          </div>
        )}



      </div>

      <LoadingSpinner isShow={isShow} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>

  );

};

export default DynamicReportConfigurationMainWindow;