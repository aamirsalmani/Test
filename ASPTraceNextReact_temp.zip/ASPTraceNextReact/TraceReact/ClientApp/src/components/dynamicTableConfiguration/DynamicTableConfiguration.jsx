import React from "react";
import { useSelector } from "react-redux";
import SidebarMain from "../common/SidebarMain";
import DynamicTableConfigurationMainWindow from "./DynamicTableConfigurationMainWindow";

const DynamicTableConfiguration = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <DynamicTableConfigurationMainWindow />
        </div>
    );
};

export default DynamicTableConfiguration;