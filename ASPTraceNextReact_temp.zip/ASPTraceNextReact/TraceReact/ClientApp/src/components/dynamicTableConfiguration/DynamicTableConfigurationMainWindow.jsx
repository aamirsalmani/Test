import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Select from "react-select";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import AsyncSelect, { useAsync } from "react-select/async";
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import $ from "jquery";
import "jquery/dist/jquery.min.js";
import { FileUploader } from "react-drag-drop-files"; // Make sure this package is installed
import "../fileConfig/ExcelFileConfigMainWindow"
import editRow from "../../images/common/editRow.svg";


import { useSelector } from "react-redux";

const DynamicTableConfigurationMainTable = () => {
    const navigate = useNavigate();
  const fileTypes = [
    "xlsx",
    "xls",
    "csv",
    "txt",
    "rc",
  ];
const fileTypeOptions = fileTypes.map((type) => ({ label: type, value: type }));
const [isShowFileUploadModal, setShowFileUploadModal] = useState(false);
  const [selectedFileType, setSelectedFileType] = useState(null);
  const [importFile, setImportFile] = useState(null);
const [tableName, setTableName] = useState("");
 const [inputValue, setValue] = useState("0");
  const currentUser = useSelector((state) => state.authReducer);
  const [selectedClientValue, setSelectedClientValue] = useState(null);
  const [selectedChannelValue, setSelectedChannelValue] = useState(null);
  const [selectedModeValue, setSelectedModeValue] = useState(null);

  const [optionsChannelType, setOptionsChannelType] = useState([
    { channelID: "0", channelName: "ALL" },
  ]);
  const [optionsModeType, setOptionsModeTypeValue] = useState([
    { modeID: "0", modeName: "ALL" },
  ]);
  
  const [dynamictabledata, setdynamictabledata] = useState([]);
 
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const fetchClientData = (inputValue) => {
    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  const onReset = (e) => {
    e.preventDefault();
    window.location.reload(false);
  };


  const handleChannelChange = (value) => {
    // setShow(false);
    setdynamictabledata(null);
    setSelectedChannelValue(value);
    setSelectedModeValue(null);

    let ChannelId = 0;
    if (value === undefined || value === null) {
      ChannelId = 0;
    } else {
      ChannelId = value.value;
    }
    setIsLoading(true);
    MaximusAxios.get(
      "api/DynamicTable/GetDynamicModeOptionList?ClientID=" +
        selectedClientValue.clientID +
        "&ChannelID=" +
        ChannelId,
      { mode: "cors" }
    ).then((resultMode) => {
      setOptionsModeTypeValue(resultMode.data);
    });
    setIsLoading(false);
    // onShowClick();
  };
const onAddClick = async () => {
  let alertMessages = "";

  if (!selectedClientValue) {
    alertMessages += "Please select client.\n";
  }
  if (!selectedChannelValue) {
    alertMessages += "Please select Channel.\n";
  } else if (!selectedModeValue) {
    alertMessages += "Please select mode Type.\n";
  }
  if (!tableName || tableName.trim() === "") {
    alertMessages += "Please enter table name.\n";
  }

  if (alertMessages.length > 0) {
    setShowMessageBox({
      isShow: true,
      alertVariant: "info",
      alertTitle: "Mandatory Field",
      alertMessage: alertMessages,
    });
    return false;
  }

  const alreadyExists = await checkTableExists(tableName);
  if (alreadyExists) {
    setShowMessageBox({
      isShow: true,
      alertVariant: "warning",
      alertTitle: "Table Exists",
      alertMessage: `Table '${tableName}' already exists in the database.`,
    });
    return;
  }

  // ✅ Proceed if no issues
  setShowFileUploadModal(true);
};

const checkTableExists = async (tableName) => {
  try {
    const response = await MaximusAxios.get(
      `api/DynamicTable/CheckTableExists?tableName=${tableName}`
    );
    return response.data.exists;
  } catch (error) {
    console.error("Error checking table name:", error);
    return false;
  }
};

const onProceedClick = () =>{
let alertMessages = "";
    if (!selectedFileType) {
      alertMessages += "Please select a file type. \n";
    }
    if (!importFile) {
      alertMessages += "Please upload a file. \n";
    }

 if (importFile && selectedFileType) {
    const fileName = importFile.name;
    const extension = fileName.split('.').pop().toLowerCase();
    const expectedExtension = selectedFileType.value.toLowerCase(); // e.g., 'xlsx'

    if (extension !== expectedExtension) {
      alertMessages += `File type mismatch. Expected .${expectedExtension} file.\n`;
    }
  }

    if (alertMessages.length > 0) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "info",
        alertTitle: "Mandatory Field",
        alertMessage: alertMessages,
      });
      return false;
    }
      if (selectedFileType.value === "xlsx") {
    // Navigate to next page
    navigate("/ExcelFilePage", {
      state: {
        isEditMode: false,
        fileName: importFile.name,
        file: importFile,
        fileType: selectedFileType.value,
        client: selectedClientValue,
        channel: selectedChannelValue,
        mode: selectedModeValue,
        tableName: tableName

      }
    });
  }
}
  const onShowClick = () => {
    let alertMessages = "";

    if (selectedClientValue === null || selectedClientValue === undefined) {
      alertMessages += "Please select client. \n";
    }
    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      alertMessages += "Please select Channel. \n";
    } else if (selectedModeValue === undefined || selectedModeValue === null) {
      alertMessages += "Please select mode Type. \n";
    }
    if (alertMessages.length > 0) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "info",
        alertTitle: "Mandatory Field",
        alertMessage: alertMessages,
      });
      return false;
    }
    //CheckSelectedValues();
    MaximusAxios.post(
      "api/LogFileTypeConfig/LogFileTypeConfigData",
      {
        ClientID: String(selectedClientValue.clientID),
        ChannelID: String(selectedChannelValue.value),
        ModeID: String(selectedModeValue.value),
      },
      {}
    )
      .then((response) => {
        setdynamictabledata(response.data);
       // console.log(response.data);
        setIsLoading(false);
      })
      .catch(function (error) {
        setIsLoading(false);
      });
  };
  const handleModeChange = (value) => {
    setdynamictabledata(null);
    setSelectedModeValue(value);
  };

  $(document).ready(function () {
    if (dynamictabledata !== null && dynamictabledata.length > 0) {
      $("#gvVendorRegistration").DataTable({
        bDestroy: true,
        columnDefs: [{ orderable: false, targets: [2] }],
      });
    }
  });

   const handleInputChange = (value) => {
    setValue(value);
  };

  const handleClientChange = (value) => {
      //setShow(false);
      setdynamictabledata(null);
      setSelectedClientValue(value);
      setSelectedChannelValue(null);
      setSelectedModeValue(null);
  
      try {
        setIsLoading(true);
  
        if (value.clientID !== "0") {
          MaximusAxios.get(
            "api/DynamicFileConfig/GetChannelOptionList?ClientID=" +
              value.clientID,
            { mode: "cors" }
          ).then((resultChannel) => {
            setOptionsChannelType(resultChannel.data);
  
            setIsLoading(false);
          });
        }
      } catch (ex) {
        console.log(ex);
        setIsLoading(false);
      }
    };

   const handleuploadFile = (file) => {
    setImportFile(file);
  };

  const handleFileTypeChange = (selectedOption) => {
    setSelectedFileType(selectedOption);
  };

  const fetchDynamicTableData = () => {
  setdynamictabledata(null); // Clear existing data

  const clientId = selectedClientValue?.clientID || 0;
  const channelId = selectedChannelValue?.value || 0;
  const modeId = selectedModeValue?.value || 0;

  setIsLoading(true);

  MaximusAxios.get(
    `api/DynamicTable/GetDynamicTableConfigList?clientID=${clientId}&channelID=${channelId}&modeID=${modeId}`,
    { mode: "cors" }
  )
    .then((res) => {
      setdynamictabledata(res.data);
    })
    .catch((err) => {
      console.error("Failed to load dynamic table data", err);
    })
    .finally(() => {
      setIsLoading(false);
    });
};


useEffect(() => {
  if (selectedClientValue || selectedChannelValue || selectedModeValue) {
    fetchDynamicTableData();
  }
}, [selectedClientValue, selectedChannelValue, selectedModeValue]);

useEffect(() => {
  fetchDynamicTableData();
}, []);
const handleEdit = async (tableConfigID) => {
  try {
    const response = await MaximusAxios.get(
      `api/DynamicTable/GetDynamicTableConfigByID?DynamicTableID=${tableConfigID}`
    );

    const config = response.data;
console.log(response.data);
    
    navigate("/ExcelFilePage", {
      state: {
        isEditMode: true,
        tableConfigID: tableConfigID,
        tableName: config.tableName,
        tableConfigs: config.tableConfigs,
        fileType: config.fileType,
        fileName: config.fileName,
        client: config.clientName,
        channel: config.channelName,
        mode: config.modeName
      },
    });
  } catch (error) {
    alert("❌ Failed to fetch configuration: " + (error.message || "Unknown error"));
    console.error(error);
  }
};

  return (
    <div className="configLeft dynamicContainer">
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Dynamic Table Configuration
        </h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Configuration</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">LogFileType Configuration</p>
        </div>
      </div>
      <div className="configLeftTop">
        <div className="accordion" id="unmatchedFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="unmatchedFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>

              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#unmatchedFiltersCollapse"
                aria-expanded="true"
                aria-controls="unmatchedFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="unmatchedFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="unmatchedFiltersHeading"
              data-bs-parent="#unmatchedFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedClientValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      defaultValue={"ADd"}
                      id="ddlClient"
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      onChange={handleChannelChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlMode">Mode Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlMode"
                      value={selectedModeValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsModeType.map((x) => ({
                        value: x.modeID,
                        label: x.modeName,
                      }))}
                      onChange={handleModeChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
  <label htmlFor="txtTableName">Table Name</label>
  <span className="text-danger font-size13">*</span>
  <input
    type="text"
    id="txtTableName"
    className="form-control txt"
    value={tableName}
    onChange={(e) => setTableName(e.target.value)}
    placeholder="Enter Table Name"
  />
</div>

                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
               
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onAddClick}
                    disabled={isShow}
                  >
                    Add
                  </button>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="configLeftBottom">
        <div>
          {(dynamictabledata === null || dynamictabledata.length === 0) && (
            <div className="tableBorderBox pb-3 pt-3">
              <div className="clientNameSelect configFormatEntities">
                <p className="text-danger font-size12">No Records</p>
              </div>
            </div>
          )}
          {isShow ? (
            <div className="spinner-container">
              <div className="loading-spinner"></div>
            </div>
          ) : (
            <>
              {/* Table */}
              {dynamictabledata != null && dynamictabledata.length > 0 && (
  <div>
    <div className="tableBorderBox pt-3">
      <div className="w-100 table-responsive">
        <div className="table-responsive tableVendorContentBox">
          <table
            id="gvVendorRegistration"
            className="table table-striped table-hover table-borderless align-middle"
            style={{ width: "100%" }}
          >
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Client</th>
                <th scope="col">Channel</th>
                <th scope="col">Mode</th>
                <th scope="col">Table Name</th>
                <th scope="col">Created By</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {dynamictabledata.map((item, index) => (
                <tr key={index}>
                  <td>{item.id}</td> {/* Use item.id for ID */}
                  <td>{item.clientName}</td> {/* Use item.clientName */}
                  <td>{item.channelName}</td> {/* Use item.channelName */}
                  <td>{item.transactionMode}</td> {/* Use item.transactionMode */}
                  <td>{item.tableName}</td> {/* Use item.tableName */}
                  <td>{item.createdBy}</td> {/* Use item.createdBy */}
                  <td>
                    {/* Add your Edit button or link here */}
                     <button
                                                          type="button"
                                                          className="iconButtonBox"
                                                          onClick={() => handleEdit(item.id)}
                                                        >
                                                          <img
                                                            src={editRow}
                                                            alt="Edit"
                                                            title="Edit"
                                                          />
                                                        </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
)}

            </>
          )}
        </div>
      </div>
   {isShowFileUploadModal && (
        <Modal
          show={isShowFileUploadModal}
          onHide={() => setShowFileUploadModal(false)}
          centered
          className="dynamicTableModal"
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              File Upload
            </Modal.Title>
          </Modal.Header>

          <Modal.Body>
            <div className="dynamicControl">
                 <div className="clientNameSelect col mt-3">
                <label htmlFor="ddlFileType">File Type</label>
                <span className="text-danger font-size13">*</span>
                <Select
                  id="ddlFileType"
                  value={selectedFileType}
                  classNamePrefix="reactSelectBox"
                  options={fileTypeOptions}
                  onChange={handleFileTypeChange}
                />
              </div>
<div className="FileWhiteBox">
  {/* Label moved outside the centered box */}
  <p className="fontSize14 fontWeight-500 letterSpacing-2 mb-1 text-start">
    Select File <span className="text-danger font-size13">*</span>
  </p>

  <div className="d-flex align-items-center">
    <div className="lightWhiteBox text-center">
      <p className="fontSize14 fontWeight-500 colorPrimaryDefault browseFileText">
        Browse File
      </p>
      <FileUploader
        handleChange={handleuploadFile}
        name="file"
        types={fileTypes}
      />
      <p className="fontSize14 dropFileColor">
        {importFile ? "File name: " + importFile.name : ""}
      </p>
    </div>
  </div>
</div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <button
              type="button"
              className="btnPrimary ms-2"
              onClick={onProceedClick}
            >
              Proceed
            </button>
          </Modal.Footer>
        </Modal>
      )}
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default DynamicTableConfigurationMainTable;
