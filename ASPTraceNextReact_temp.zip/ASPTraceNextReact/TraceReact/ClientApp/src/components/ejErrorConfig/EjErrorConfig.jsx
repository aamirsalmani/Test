﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
//import './ejErrorConfig/ejErrorConfig.css';
import "../currencyRegistration/currencyRegistration.css"



// Components
import SidebarMain from "../common/SidebarMain";
import EjErrorConfigMainWindow from "./EjErrorConfigMainWindow";


const EjErrorConfig = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                < EjErrorConfigMainWindow/>
        </div>
    );
};

export default EjErrorConfig;
