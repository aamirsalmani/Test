﻿import React, { useState, useEffect } from "react";
import Select from "react-select";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL" ;
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";

import { useSelector } from "react-redux";
import $ from 'jquery';

// Images
import Delete from "../../images/common/redDelete.svg";
import editRow from "../../images/common/editRow.svg";

const EjErrorConfigMainWindow = () => {
    const currentUser = useSelector((state) => state.authReducer);
    const [EjErrorConfigurationTableData, setEjErrorConfigurationTableData] = useState(null);
    const [isChange, setisChange] = useState(false);
    const [isShow, setIsLoading] = useState(false);
    const [isNewEntry, setNewEntry] = useState(true);
    const [errorCode, setErrorCode] = useState('');
    const [errorDescription, setErrorDescription] = useState('');
    const [atmMake, setAtmMake] = useState('');
    const [srNo, setsrNo] = useState('0');
    const [buttonValue, setButtonValue] = useState(null);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });
    const [isShowEjErrorConfigModel, setShowEjErrorConfigModel] = useState(false);

    // Fetch data function
    const fetchEJerrorData = () => {
        setIsLoading(true);
        MaximusAxios.get('api/EjErrorConfig/GetEjErrorList', {  mode: 'cors' })
            .then(result => {
                setEjErrorConfigurationTableData(result.data);
                setIsLoading(false);
            })
            .catch(error => {
                console.error('Error fetching data:', error.response ? error.response.data : error);
                setIsLoading(false);
            });
    };

    // Effect to initialize DataTable
    useEffect(() => {
        fetchEJerrorData();
    }, [isChange]);

    useEffect(() => {
       
        if (EjErrorConfigurationTableData !== null && EjErrorConfigurationTableData.length > 0) {
            $(document).ready(function () {
                $('#gvCurrencyRegistration').DataTable({
                    "bDestroy": true,
                    "columnDefs": [{ orderable: false, targets: [4] }]
                });
            });
        }
    }, [EjErrorConfigurationTableData]);

    const onNewClick = () => {

        window.confirm("Are you sure you want to Add");
            setShowEjErrorConfigModel(true);
            setButtonValue('ADD');
            setErrorCode('');
            setErrorDescription('');
            setAtmMake('');
            setNewEntry(true);
        };

    //const onEditClick = (SrNo) => {
    //    if (window.confirm("Are you sure you want to edit?")) {
    //        setNewEntry(false);

    //        MaximusAxios.post(`api/EjErrorConfig/EJErroraddupdate`, { id: SrNo }, {  mode: 'cors' })
    //            .then(response => {
    //                const data = response.data;
    //                if (data) {
    //                    setErrorCode(data.errorCode || '');
    //                    setErrorDescription(data.errorDescription || '');
    //                    setAtmMake(data.atmMake || '');
    //                    setIsActive(data.isActive || false);
    //                    setShowEjErrorConfigModel(true);
    //                } else {
    //                    console.error('Unexpected response structure:', response);
    //                    // Optionally, you can show an error message to the user
    //                }
    //            })
    //            .catch(error => {
    //                console.error('Error fetching error details:', error.response ? error.response.data : error);
    //                // Optionally, you can show an error message to the user
    //            });

    //        setButtonValue('UPDATE');
    //    }
    //};

    const onEditClick = (item, Ops) => {
        let operation = Ops;
        if (window.confirm("Are you sure you want to " + operation + "!"));
        {
            setsrNo(item.srNo);
            setAtmMake(item.atmMake);
            setErrorDescription(item.errorDescription);
            setErrorCode(item.errorCode);

            if (operation === 'UPDATE') {
                setButtonValue(operation);
                setShowEjErrorConfigModel(true);
                setNewEntry(false);
            }
        }

    };


    const onAddClick = () => {

        

        if (errorCode === null || errorCode.trim().length === 0) {
            alert("Please enter Error Code!");
            return false;
        }

        if (errorDescription === null || errorDescription.trim().length === 0) {
            alert("Please enter Error Description!");
            return false;
        }

        if (atmMake === null || atmMake.trim().length === 0) {
            alert("Please enter ATM Make!");
            return false;
        }


        if (window.confirm("Are you sure you want to " + buttonValue + "!"));
        {
            setIsLoading(true);
            MaximusAxios.post(`api/EjErrorConfig/EJErroraddupdate`,
                {
                    SrNo: srNo,
                    Mode: buttonValue,
                    ErrorCode: errorCode,
                    ErrorDescription: errorDescription,
                    AtmMake: atmMake,               }
                , {  mode: 'cors' })
                .then(response => {
                    if (response.data === "1") {
                        if (buttonValue === 'ADD') { alert('EJ error configuration added successfully!'); }
                        if (buttonValue === 'UPDATE') { alert('EJ error configuration updated successfully!'); }
                        if (buttonValue === 'ADD') setEjErrorConfigurationTableData(null);
                        setIsLoading(false);
                        setisChange(!isChange);
                        setShowEjErrorConfigModel(false);
                    } else {
                        setIsLoading(false);
                        alert(response.data);
                        setisChange(!isChange);

                    }
                })
                .catch(error => {
                    console.error('Error fetching error details:', error.response ? error.response.data : error);
                });
                
        }
    };

    const onDeleteClick = (item) => {
        if (window.confirm("Are you sure you want to Delete!"));
        {
            setIsLoading(true);
            MaximusAxios.post(`api/EjErrorConfig/EJErroraddupdate`,
                {
                    SrNo: item.srNo,
                    Mode: 'DELETE',
                    ErrorCode: item.errorCode,
                    ErrorDescription: item.errorDescription,
                    AtmMake: item.atmMake,
                }
                , {  mode: 'cors' })
                .then(response => {
                    if (response.data === "DELETE") {
                        alert('EJ error configuration deleted successfully!');
                        setEjErrorConfigurationTableData(null);
                        setIsLoading(false);
                        setisChange(!isChange);
                    } else {
                        setIsLoading(false);
                        alert(response.data);
                        setisChange(!isChange);

                    }
                })
                .catch(error => {
                    console.error('Error fetching error details:', error.response ? error.response.data : error);
                });
        }
    };
    


        // Tooltip
        const renderTooltipAdd = (props) => (
            <Tooltip id="button-tooltip" {...props}>
                Click to add new entry
            </Tooltip>
        );

        return (
            <div className="configLeft currencyContainer">
                {/* Breadcrumb Box */}
                <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                    <h5 className="fontWeight-600 fileConfigHead colorBlack">
                        EJ Error Configuration
                    </h5>
                    <div className="d-flex align-items-center">
                        <Link to="/">
                            <p className="fontSize12 colorPrimaryDefault">Home</p>
                        </Link>
                        <span>
                            <svg
                                width="8"
                                height="100%"
                                viewBox="0 0 10 16"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                className="mx-1"
                            >
                                <path
                                    d="M3 4L7 8L3 12"
                                    stroke="black"
                                    strokeWidth="1.5"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    className="breadcrumbIcon"
                                />
                            </svg>
                        </span>
                        <p className="fontSize12 colorPrimaryDefault"> Configuration</p>
                        <span>
                            <svg
                                width="8"
                                height="100%"
                                viewBox="0 0 10 16"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                                className="mx-1"
                            >
                                <path
                                    d="M3 4L7 8L3 12"
                                    stroke="black"
                                    strokeWidth="1.5"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    className="breadcrumbIcon"
                                />
                            </svg>
                        </span>
                        <p className="fontSize12">EJ Error Configuration </p>
                    </div>
                </div>
                {/* Table Content */}
                <div className="configLeftBottom">
                    <div>
                        {/* Table */}
                        {(EjErrorConfigurationTableData !== null && EjErrorConfigurationTableData.length > 0) ? (
                            <div>
                                <div className="exportButton">
                                    <OverlayTrigger
                                        placement="top"
                                        delay={{ show: 150, hide: 400 }}
                                        overlay={renderTooltipAdd}
                                    >
                                        <button type="button" className="iconAddButtonBox" onClick={onNewClick}>
                                            <span className="icon-Plus">+</span>
                                            <span className="ms-1 fontSize12-m colorPrimaryDefault">Add New</span>
                                        </button>
                                    </OverlayTrigger>
                                </div>
                                <div className="tableBorderBox pt-3">
                                    <div className="w-100 table-responsive">
                                        <div className="table-responsive tableCurrencyContentBox">
                                            <table id="gvCurrencyRegistration" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }}>
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Sr No.</th>
                                                        <th scope="col">Error Code</th>
                                                        <th scope="col">Error Description</th>
                                                        <th scope="col">ATM Make</th>
                                                        <th scope="col">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {EjErrorConfigurationTableData.map((p) => (
                                                        <tr><td>{p.srNo}</td>
                                                            <td>{p.errorCode}</td>
                                                            <td style={{textAlign:"Left"}}><p className="tableTextInner">{p.errorDescription}</p></td>
                                                            <td>{p.atmMake}</td>
                                                            <td>
                                                                <div className="text-center">
                                                                    <button type="button" className="iconButtonBox" onClick={() => onEditClick(p,'UPDATE')}>
                                                                        <img src={editRow} alt="Edit" title="Edit" />
                                                                    </button>
                                                                    <button type="button" className="iconButtonBox" onClick={() => onDeleteClick(p)}>
                                                                        <img src={Delete} alt="Delete" title="Delete" />
                                                                    </button>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                        ) : (
                            <div className="text-center">No data available</div>
                        )}
                    </div>
                </div>

                {/* Add/Edit Modal */}

                {isShowEjErrorConfigModel && (
                    <Modal
                        show={isShowEjErrorConfigModel} // Updated to use the correct state variable
                        onHide={() => setShowEjErrorConfigModel(false)}
                        centered
                        className="currencyTableModal"
                    >
                        <Modal.Header closeButton>
                            <Modal.Title className="fontSize16-sm letterSpacing-2">
                                {isNewEntry ? <span>Add</span> : <span>Update</span>} 
                            </Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                            <div className="currencyControl">
                                <label htmlFor="errorCode">Error Code</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="errorCode"
                                    value={errorCode}
                                    onChange={(e) => setErrorCode(e.target.value)}
                                />
                            </div>
                            <div className="currencyControl">
                                <label htmlFor="errorDescription">Error Description</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="errorDescription"
                                    value={errorDescription}
                                    onChange={(e) => setErrorDescription(e.target.value)}
                                />
                            </div>
                            <div className="currencyControl">
                                <label htmlFor="atmMake">ATM Make</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    id="atmMake"
                                    value={atmMake}
                                    onChange={(e) => setAtmMake(e.target.value)}
                                />
                            </div>
                        </Modal.Body>
                        <Modal.Footer>
                                                      
                                <button type="button" className="btnPrimary ms-2" onClick={onAddClick} >{buttonValue}</button>
                             </Modal.Footer>
                    </Modal>
                )}

                <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
            </div>
        );
        
};

export default EjErrorConfigMainWindow;
