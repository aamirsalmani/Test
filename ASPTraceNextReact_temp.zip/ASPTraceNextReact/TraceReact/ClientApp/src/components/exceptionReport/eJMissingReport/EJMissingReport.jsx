﻿import React from "react";
import { useSelector } from "react-redux"; 
// Components
import SidebarMain from "../../common/SidebarMain";

import EJMissingReportMainWindow from "./EJMissingReportMainWindow";

const EJMissingReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <EJMissingReportMainWindow/>
        </div>
    );
};

export default EJMissingReport;
