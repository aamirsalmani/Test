﻿import MaximusAxios from "../../common/apiURL";
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import { getMonth, getYear } from "date-fns";
import { saveAs } from "file-saver";
import $ from "jquery";
import "jquery/dist/jquery.min.js";
import jsPDF from "jspdf";
import "jspdf-autotable";
import React, { useState } from "react";
import { OverlayTrigger, Tooltip } from "react-bootstrap";
import DatePicker from "react-datepicker";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import Select from "react-select";
import authHeader from "../../../pages/login/services/auth-header";
import AsyncSelect from "react-select/async";
import ExcelIcon from "../../../images/common/excel.svg";
import CsvIcon from "../../../images/common/csv.svg";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";

const EJMissingReportMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const onReset = (e) => {
    e.preventDefault();
    setStartDate(null);
    setEndDate(null);
    setEJMissingReport(null);
    setSelectedValue(null);
    setSelectedTerminalValue(null);
    setselectedUploadStatusValue(null);
    // window.location.reload(false);
  };

  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const fetchClientData = (inputValue) => {
    setStartDate(null);
    setEndDate(null);

    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const formatDate = (date) => {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

  const [inputValue, setValue] = useState("0");
  const [selectedValue, setSelectedValue] = useState(null);

  const [optionsTerminalType, setOptionsTerminalValue] = useState([
    { terminalid: "All", id: "All" },
  ]);

  const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

  const [selectedUploadStatusValue, setselectedUploadStatusValue] =
    useState(null);

  const [titleDate, setTitleDateValue] = useState("");

  const handleInputChange = (value) => {
    setValue(value);
  };

  const handleOptionsTerminalType = (value) => {
    setOptionsTerminalValue(value);
  };

  const chkU = () => {
    return currentUser?.user?.username.includes("Sayali");
  };

  const UploadStatus = [
    { value: "-1", label: "Missing" },
    { value: "1", label: "Uploaded" },
  ];

  const handleClientChange = (value) => {
    if (currentUser !== null && currentUser.user !== null) {
      setEJMissingReport(null);
      setSelectedTerminalValue(null);
      //setStartDate(null);
      //setEndDate(null);
      setSelectedValue(value);

      if (value.clientID !== "0") {
        //return MaximusAxios.get('api/Common/GetTerminalOptionList?ClientID=' + value.clientID + '&ChannelID=1' + '&UserName=' + currentUser.user.username, {  mode: 'cors' }).then(result => {

        //    var resData = result.data;

        //    var myObj = { "ID": "0", "TERMINALID": "All" };

        //    resData.push(myObj);

        //    handleOptionsTerminalType(resData);
        //});

        return MaximusAxios.get(
          "api/ExceptionReport/GetAllTerminals?ClientID=" + value.clientID,
          { mode: "cors" }
        )
          .then((result) => {
            var resData = result.data;
            var myObj = { id: "All", terminalid: "All" };

            resData.unshift(myObj);

            //  handleOptionsTerminalType(resData);
            setOptionsTerminalValue(resData);
          })
          .catch((error) => {
            console.error("Error fetching terminals:", error);
          });
      }
    } else {
      alert("Session Timeout");
    }
  };

  const handleTerminalChange = (value) => {
    setEJMissingReport(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedTerminalValue(value);
  };

  const handleUploadStatusChange = (value) => {
    setEJMissingReport(null);
    //setStartDate(null);
    //setEndDate(null);

    setselectedUploadStatusValue(value);
  };

  const [EJMissingReport, setEJMissingReport] = useState(null);

  const [startDate, setStartDate] = useState(new Date());

  const [endDate, setEndDate] = useState(new Date());

  const setStartDateValue = (value) => {
    setStartDate(value);
    setEJMissingReport(null);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date ");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    setEJMissingReport(null);
  };

  const downloadPDF = () => {
    if (EJMissingReport !== null) {
      if (EJMissingReport.length > 0) {
        MaximusAxios.get(
          "api/Common/GetClientLogoImage?ClientId=" + selectedValue.clientID,
          { mode: "cors" }
        ).then((result) => {
          const title = "EJ Missing Report";

          //console.log("EJ Missing Report");

          const headers = [
            [
              "Terminal ID",
              "Date Time",
              "Opening Balance",
              "ATM Dispense",
              "Amount Deposit",
              "Physical Cash Balance",
              "Amount Replenished",
              "Amount Returned",
              "Closing Balance",
              "Overage",
              "Shortage",
              "GL Balance",
              "GL Difference",
              "Opening Closing Mismatch",
              "EJ Missing Status",
            ],
          ];

          var data = $("#gvEJMissingReportPDF")
            .dataTable()
            ._("tr", { filter: "applied" });
          let filterDataPDF = [];
          let cntrow = 0;

          //console.log(data);

          for (let i = 0; i < data.length; i++) {
            var arr = [
              data[cntrow][0],
              data[cntrow][1],
              data[cntrow][2],
              data[cntrow][3],
              data[cntrow][4],
              data[cntrow][5],
              data[cntrow][6],
              data[cntrow][7],
              data[cntrow][8],
              data[cntrow][9],
              data[cntrow][10],
              data[cntrow][11],
              data[cntrow][12],
              data[cntrow][13],
            ];
            filterDataPDF.push(arr);
            cntrow++;
          }

          //console.log(filterDataPDF);

          const unit = "pt";
          const size = "LEGAL";
          const orientation = "landscape";

          const doc = new jsPDF(orientation, unit, size);

          //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
          var pageWidth =
            doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

          //console.log(result);

          doc.addImage(result.data.clientLogo, "PNG", 20, 20, 150, 50);

          doc.addImage(
            result.data.traceLogo,
            "PNG",
            pageWidth - 170,
            20,
            150,
            50
          );

          //doc.setTextColor(100);

          doc.setFontSize(24);

          doc.text(title, pageWidth / 2, 40, { align: "center" });

          doc.setFontSize(20);

          doc.text(titleDate, pageWidth / 2, 65, { align: "center" });

          let content = {
            startY: 80,
            head: headers,
            body: filterDataPDF,
          };

          doc.setFontSize(10);

          doc.autoTable(content);

          doc.save("EJ Missing Report.pdf");
        });
      } else {
        alert("No Record Found");
      }
    } else {
      alert("No Record Found");
    }
  };

  // Tooltip
  const renderTooltip = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to pdf
    </Tooltip>
  );

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to Excel
    </Tooltip>
  );

  const renderTooltipCsv = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to Csv
    </Tooltip>
  );

  const onSubmit = () => {
    setEJMissingReport(null);

    if (selectedValue === null || selectedValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
      alert("Please select Terminal Value!");
      return false;
    }

    if (
      selectedUploadStatusValue === undefined ||
      selectedUploadStatusValue === null
    ) {
      alert("Please select Upload Status!");
      return false;
    }

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let TerminalValue = "";

    if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
      TerminalValue = "";
    } else {
      TerminalValue = selectedTerminalValue.value;
    }

    let UploadStatusValue = "";

    if (
      selectedUploadStatusValue === undefined ||
      selectedUploadStatusValue === null
    ) {
      UploadStatusValue = "";
    } else {
      UploadStatusValue = selectedUploadStatusValue.value;
    }

    setIsLoading(true);

    MaximusAxios.post(
      "api/ExceptionReport/GetEJMissingDatalist",
      {
        Clientid: selectedValue.clientID,
        TERMINALID: TerminalValue,
        UploadStatus: UploadStatusValue,
        FROMDATE: formatDate(startDate),
        TODATE: formatDate(endDate),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setEJMissingReport(response.data);
        console.log(response.data);
        setTitleDateValue(
          "Report Date : " +
            formatDate(startDate) +
            " To " +
            formatDate(endDate)
        );
        setIsLoading(false);
        if (response.data === null || response.data.length == 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "No records found",
          });
        }
      })
      .catch(function (error) {
        console.log(error.response.data);
        setTitleDateValue("");
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  $(document).ready(function () {
    if (EJMissingReport !== null && EJMissingReport.length > 0) {
      $("#gvEJMissingReportPDF").DataTable();
    }
  });

  // ----------BY KUNDAN
  const ExportToExcelKS = () => {
    setEJMissingReport(null);

    if (selectedValue === null || selectedValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
      alert("Please select Terminal Value!");
      return false;
    }

    if (
      selectedUploadStatusValue === undefined ||
      selectedUploadStatusValue === null
    ) {
      alert("Please select Upload Status!");
      return false;
    }

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let TerminalValue = "";

    if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
      TerminalValue = "";
    } else {
      TerminalValue = selectedTerminalValue.value;
    }

    let UploadStatusValue = "";

    if (
      selectedUploadStatusValue === undefined ||
      selectedUploadStatusValue === null
    ) {
      UploadStatusValue = "";
    } else {
      UploadStatusValue = selectedUploadStatusValue.value;
    }

    let FileName = "EJMissingReport_" + formatDate(startDate) + ".xlsx";
    setIsLoading(true);

    MaximusAxios.post(
      "api/ExceptionReport/ExportExcelReportKS",
      {
        Clientid: selectedValue.clientID,
        TERMINALID: TerminalValue,
        UploadStatus: UploadStatusValue,
        FROMDATE: formatDate(startDate),
        TODATE: formatDate(endDate),
      },
      { responseType: "blob" }
    )
      .then(function (response) {
        saveAs(response.data, FileName);
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        setIsLoading(false);
      });
  };

  const ExportToCsvKS = () => {
    setEJMissingReport(null);

    if (selectedValue === null || selectedValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
      alert("Please select Terminal Value!");
      return false;
    }

    if (
      selectedUploadStatusValue === undefined ||
      selectedUploadStatusValue === null
    ) {
      alert("Please select Upload Status!");
      return false;
    }

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let TerminalValue = "";

    if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
      TerminalValue = "";
    } else {
      TerminalValue = selectedTerminalValue.value;
    }

    let UploadStatusValue = "";

    if (
      selectedUploadStatusValue === undefined ||
      selectedUploadStatusValue === null
    ) {
      UploadStatusValue = "";
    } else {
      UploadStatusValue = selectedUploadStatusValue.value;
    }

    let FileName = "EJMissingReport_" + formatDate(startDate) + ".csv";
    setIsLoading(true);

    MaximusAxios.post(
      "api/ExceptionReport/ExportCsvReportKS",
      {
        Clientid: selectedValue.clientID,
        TERMINALID: TerminalValue,
        UploadStatus: UploadStatusValue,
        FROMDATE: formatDate(startDate),
        TODATE: formatDate(endDate),
      },
      { responseType: "blob" }
    )
      .then(function (response) {
        saveAs(response.data, FileName);
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        console.log(error.response);
        setIsLoading(false);
      });
  };

  // ----------BY KUNDAN

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          EJ Missing Report
        </h5>

        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Exception Report</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">EJ Missing Report</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="EJMissingReportFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="EJMissingReportFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#EJMissingReportFiltersCollapse"
                aria-expanded="true"
                aria-controls="EJMissingReportFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="EJMissingReportFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="EJMissingReportFiltersHeading"
              data-bs-parent="#EJMissingReportFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="logType">Terminal</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlTerminal"
                      value={selectedTerminalValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsTerminalType.map((x) => ({
                        value: x.terminalid,
                        label: x.terminalid,
                      }))}
                      onChange={handleTerminalChange}
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="logType">Upload Status</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlTerminal"
                      value={selectedUploadStatusValue}
                      classNamePrefix="reactSelectBox"
                      options={UploadStatus}
                      onChange={handleUploadStatusChange}
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onSubmit}
                  >
                    Show
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Content */}
      <div className="configLeftBottom">
        {(EJMissingReport === null || EJMissingReport.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        {/* Table */}
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {EJMissingReport !== null && EJMissingReport.length > 0 ? (
              <div>
                <div className="exportButton">
                  {chkU() && (
                    <OverlayTrigger
                      placement="top"
                      delay={{ show: 150, hide: 400 }}
                      overlay={renderTooltipExcel}
                    >
                      <button
                        type="button"
                        className="iconButtonBox"
                        onClick={() => ExportToExcelKS()}
                      >
                        <img src={ExcelIcon} alt="Excel" />
                      </button>
                    </OverlayTrigger>
                  )}
                  {chkU() && (
                    <OverlayTrigger
                      placement="top"
                      delay={{ show: 150, hide: 400 }}
                      overlay={renderTooltipCsv}
                    >
                      <button
                        type="button"
                        className="iconButtonBox"
                        onClick={() => ExportToCsvKS()}
                      >
                        <img src={CsvIcon} alt="Csv" />
                      </button>
                    </OverlayTrigger>
                  )}
                </div>
                <div className="tableBorderBox pt-3">
                  <div className="w-100 table-responsive">
                    <div className="table-responsive tableContentBox">
                      <table
                        id="gvEJMissingReportPDF"
                        className="table table-striped table-hover table-borderless align-middle"
                      >
                        <thead>
                          <tr>
                            <th scope="col">Terminal ID</th>
                            <th scope="col">File Name</th>
                            <th scope="col">File Date</th>
                            <th scope="col">Upload Status</th>
                            <th scope="col">Insert Count</th>
                            <th scope="col">Total Row Count</th>
                            <th scope="col">Start Time</th>
                            <th scope="col">Completion Time</th>
                            <th scope="col">Message</th>
                          </tr>
                        </thead>
                        <tbody>
                          {EJMissingReport.map((p, rowindex) => {
                            return (
                              <tr key={rowindex}>
                                <td>{p.terminalid}</td>
                                <td>{p.fileName}</td>
                                <td>{p.fileDate}</td>
                                <td>{p.uploadStatus}</td>
                                <td>{p.insertCount}</td>
                                <td>{p.totalRowCount}</td>
                                <td>{p.startTime}</td>
                                <td>{p.completionTime}</td>
                                <td>{p.errorMessage}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        )}
      </div>
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default EJMissingReportMainWindow;
