import React, { useState } from "react";
import Select from "react-select";
import { Link } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import AsyncSelect from 'react-select/async';
import MaximusAxios from "../common/apiURL" ;  
import $ from 'jquery';
import 'jquery/dist/jquery.min.js';


import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";

import { useSelector } from "react-redux"; 

const FieldMainWindow = () => { 

    const currentUser = useSelector((state) => state.authReducer); 

    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null); 

    const [optionsVendorName, setOptionsVendorNameValue] = useState([]);
    const [selectedVendorValue, setSelectedVendorValue] = useState(null);

    const [optionsChannelType, setOptionsChannelTypeValue] = useState([{ channelID: "0", channelName: "--Select--" }]);
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);

    const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "--Select--" }]);
    const [selectedModeValue, setSelectedModeValue] = useState(null);

    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }  

    const [optionsReversalEntry, setOptionsReversalEntryValue] = useState([]); 

    const [optionsAmountDecimal, setAmountDecimalOptions] = useState([]); 

    const [FormatNo, setFormatNoValue] = useState('');

    const [ReversalEntry, setReversalEntryValue] = useState(null);

    const [TxnAmount, setTxnAmountValue] = useState(null);

    const handleOptionsVendorName = value => {
        setOptionsVendorNameValue(value);
    }; 

    const handleOptionsChannelType = value => {
        setOptionsChannelTypeValue(value);
    };

    const handleOptionsModeType = value => {
        setOptionsModeTypeValue(value);
    };

    const handleReversalEntry = value => {
        setReversalEntryValue(value);
    };

    const handleTxnAmount = value => {
        setTxnAmountValue(value);
    };

    const fetchClientData = (inputValue) => {
        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    const handleInputChange = value => {
        setValue(value);
    };

    const handleClientChange = value => {

        setSelectedValue(value);

        if (value.clientID !== '0') {

            MaximusAxios.get('api/Field/GetVendorFieldList?ClientId=' + value.clientID, {  mode: 'cors' }).then(result1 => {
                handleOptionsVendorName(result1.data);
                if (result1.data !== null || result1.data.length > 0) { setSelectedVendorValue({ value: "0", label: "All" }); }
            });

            MaximusAxios.get('api/Field/GetChannelFieldList?ClientID=' + value.clientID, {  mode: 'cors' }).then(result2 => {
                handleOptionsChannelType(result2.data);
                if (result2.data !== null || result2.data.length > 0) { setSelectedChannelValue({ value: "0", label: "All" }); }
            });

            MaximusAxios.get('api/Field/GetModeFieldList?ClientID=' + value.clientID + '&ChannelID=0', {  mode: 'cors' }).then(resultMode => {
                handleOptionsModeType(resultMode.data);
                if (resultMode.data !== null || resultMode.data.length > 0) { setSelectedModeValue({ value: "0", label: "All" }); }
            });
        }
        ClearData();
        setOptionsReversalEntryValue([{ value: "1", label: "1" }, { value: "2", label: "2" }]);
        setAmountDecimalOptions([{ value: "1", label: "True" }, { value: "2", label: "False" }]);
    }

    const ClearData = () => {
        $('#hdnfieldid').val('');
        $('#terminalCode').val('');
        $('#binno').val('');
        $('#acquirerId').val('');
        $('#reversalCode1').val('');
        $('#reversalCode2').val('');
        $('#RevType').val('');
        $('#reversalentry').val('');
        $('#txnDateType').val('');
        $('#valueDateTime').val('');
        $('#postDateTime').val('');
        $('#atm').val('');
        $('#pos').val('');
        $('#ecom').val('');
        $('#imps').val('');
        $('#upi').val('');
        $('#MicroAtm').val('');
        $('#MobileRecharge').val('');
        $('#CashDeposit').val('');
        $('#BalanceEnquiry').val('');
        $('#MiniStatement').val('');
        $('#pinChange').val('');
        $('#chequebookRequest').val('');
        $('#responseCode1').val('');
        $('#responseCode2').val('');
        $('#RespTpe').val('');
        $('#eodCode').val('');
        $('#OfflineCode').val('');
        $('#debitType').val('');
        $('#creditType').val('');
        $('#ddlTxnAmtIsDec').val('');
        setFormatNoValue('');
    }

    const fillData = (ClientID, VendorID, ChannelID, ModeID) => {

        MaximusAxios.get('api/Field/GetFormatIdFieldList?ClientID=' + ClientID + '&VendorID=' + VendorID + '&ChannelID=' + ChannelID + '&ModeID=' + ModeID, {  mode: 'cors' }).then(result => {

            if (result.data !== null && result.data.length > 0) {

                $('#hdnformatno').val(result.data[0].formatID);

                setFormatNoValue(result.data[0].formatID);

                MaximusAxios.get('api/Field/GetFieldIdentificationDetailsList?ClientID=' + ClientID + '&VendorID=' + VendorID + '&ChannelID=' + ChannelID + '&ModeID=' + ModeID + '&FormatID=' + result.data[0].formatID, {  mode: 'cors' }).then(FieldResult => {

                    console.log(FieldResult.data);

                    if (FieldResult.data !== null && FieldResult.data.length > 0) {

                        $('#hdnfieldid').val(FieldResult.data[0].fieldID);
                        $('#terminalCode').val(FieldResult.data[0].terminalCode);
                        $('#binno').val(FieldResult.data[0].biN_No);
                        $('#acquirerId').val(FieldResult.data[0].acquirerID);
                        $('#reversalCode1').val(FieldResult.data[0].reversalCode1);
                        $('#reversalCode2').val(FieldResult.data[0].reversalCode2);
                        $('#RevType').val(FieldResult.data[0].revType);
                        if (FieldResult.data[0].revEntryLeg === "1") { setReversalEntryValue({ value: '1', label: '1' }) };
                        if (FieldResult.data[0].revEntryLeg === "2") { setReversalEntryValue({ value: '2', label: '2' }) };
                        $('#txnDateType').val(FieldResult.data[0].txnDateType);
                        $('#valueDateTime').val(FieldResult.data[0].valueDateTime);
                        $('#postDateTime').val(FieldResult.data[0].postDateTime);
                        $('#atm').val(FieldResult.data[0].atm);
                        $('#pos').val(FieldResult.data[0].pos);
                        $('#ecom').val(FieldResult.data[0].ecom);
                        $('#imps').val(FieldResult.data[0].imps);
                        $('#upi').val(FieldResult.data[0].upi);
                        $('#MicroAtm').val(FieldResult.data[0].microAtm);
                        $('#MobileRecharge').val(FieldResult.data[0].mobileRecharge);
                        $('#CashDeposit').val(FieldResult.data[0].cashDeposit);
                        $('#BalanceEnquiry').val(FieldResult.data[0].balanceEnquiry);
                        $('#MiniStatement').val(FieldResult.data[0].miniStatement);
                        $('#pinChange').val(FieldResult.data[0].pinChange);
                        $('#chequebookRequest').val(FieldResult.data[0].chequebookRequest);
                        $('#responseCode1').val(FieldResult.data[0].responseCode1);
                        $('#responseCode2').val(FieldResult.data[0].responseCode2);
                        $('#RespTpe').val(FieldResult.data[0].respTpe);
                        $('#eodCode').val(FieldResult.data[0].eodCode);
                        $('#OfflineCode').val(FieldResult.data[0].offlineCode);
                        $('#debitType').val(FieldResult.data[0].debitType);
                        $('#creditType').val(FieldResult.data[0].creditType);
                        
                    }
                    else {
                        MaximusAxios.get('api/Field/GetFieldIdentificationVendorDetailsList?ClientID=' + ClientID + '&VendorID=' + VendorID + '&ChannelID=' + ChannelID, {  mode: 'cors' }).then(FieldResult => {

                            $('#hdnfieldid').val(FieldResult.data[0].fieldID);
                            $('#terminalCode').val(FieldResult.data[0].terminalCode);
                            $('#binno').val(FieldResult.data[0].biN_No);
                            $('#acquirerId').val(FieldResult.data[0].acquirerID);
                            $('#reversalCode1').val(FieldResult.data[0].reversalCode1);
                            $('#reversalCode2').val(FieldResult.data[0].reversalCode2);
                            $('#RevType').val(FieldResult.data[0].revType);
                            if (FieldResult.data[0].revEntryLeg === "1") { setReversalEntryValue({ value: '1', label: '1' }) };
                            if (FieldResult.data[0].revEntryLeg === "2") { setReversalEntryValue({ value: '2', label: '2' }) };
                            $('#txnDateType').val(FieldResult.data[0].txnDateType);
                            $('#valueDateTime').val(FieldResult.data[0].valueDateTime);
                            $('#postDateTime').val(FieldResult.data[0].postDateTime);
                            $('#atm').val(FieldResult.data[0].atm);
                            $('#pos').val(FieldResult.data[0].pos);
                            $('#ecom').val(FieldResult.data[0].ecom);
                            $('#imps').val(FieldResult.data[0].imps);
                            $('#upi').val(FieldResult.data[0].upi);
                            $('#MicroAtm').val(FieldResult.data[0].microAtm);
                            $('#MobileRecharge').val(FieldResult.data[0].mobileRecharge);
                            $('#CashDeposit').val(FieldResult.data[0].cashDeposit);
                            $('#BalanceEnquiry').val(FieldResult.data[0].balanceEnquiry);
                            $('#MiniStatement').val(FieldResult.data[0].miniStatement);
                            $('#pinChange').val(FieldResult.data[0].pinChange);
                            $('#chequebookRequest').val(FieldResult.data[0].chequebookRequest);
                            $('#responseCode1').val(FieldResult.data[0].responseCode1);
                            $('#responseCode2').val(FieldResult.data[0].responseCode2);
                            $('#RespTpe').val(FieldResult.data[0].respTpe);
                            $('#eodCode').val(FieldResult.data[0].eodCode);
                            $('#OfflineCode').val(FieldResult.data[0].offlineCode);
                            $('#debitType').val(FieldResult.data[0].debitType);
                            $('#creditType').val(FieldResult.data[0].creditType);
                           
                        });

                    }

                });
            }

        });


    }

    const handleVendorChange = value => {

        setSelectedVendorValue(value);

        ClearData();

        let VendorId = 0;
        if (value === undefined || value === null) {
            VendorId = 0;
        }
        else {
            VendorId = value.value;
        }

        let ChannelId = 0;
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }

        MaximusAxios.get('api/Field/GetModeFieldList?ClientID=' + selectedValue.clientID + '&ChannelID=' + ChannelId, {  mode: 'cors' }).then(resultMode => {
            handleOptionsModeType(resultMode.data);
            if (resultMode.data !== null || resultMode.data.length > 0) { setSelectedModeValue({ value: "0", label: "All" }); }
        });

        let ModeId = 0;
        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }

        if (selectedValue.clientID !== '0') {

            fillData(selectedValue.clientID, VendorId, ChannelId, ModeId);
        }

    }

    const handleChannelChange = value => {

        setSelectedChannelValue(value);

        ClearData();

        let VendorId = 0;
        if (selectedVendorValue === undefined || selectedVendorValue === null) {
            VendorId = 0;
        }
        else {
            VendorId = selectedVendorValue.value;
        }

        let ChannelId = 0;
        if (value === undefined || value === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = value.value;
        }

        MaximusAxios.get('api/Field/GetModeFieldList?ClientID=' + selectedValue.clientID + '&ChannelID=' + ChannelId, {  mode: 'cors' }).then(resultMode => {
            handleOptionsModeType(resultMode.data);
            if (resultMode.data !== null || resultMode.data.length > 0) { setSelectedModeValue({ value: "0", label: "All" }); }
        });

        let ModeId = 0;
        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }


        if (selectedValue.clientID !== '0') {

            fillData(selectedValue.clientID, VendorId, ChannelId, ModeId);   
        }

    }

    const handleModeChange = value => {

        setSelectedModeValue(value);

        ClearData();

        let VendorId = 0;
        if (selectedVendorValue === undefined || selectedVendorValue === null) {
            VendorId = 0;
        }
        else {
            VendorId = selectedVendorValue.value;
        }

        let ChannelId = 0;
        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }

        let ModeId = 0;
        if (value === undefined || value === null) {
            ModeId = 0;
        }
        else {
            ModeId = value.value;
        }

        if (selectedValue.clientID !== '0') {

            fillData(selectedValue.clientID, VendorId, ChannelId, ModeId);
        }

    }

    
 

    const btnSubmitClick = () => {

        try {

            let alertMessages = "";

            if (selectedValue === null || selectedValue.clientID === 0) {
                alertMessages += "Please select client. \n";
            }

            if (selectedVendorValue === undefined || selectedVendorValue === null) {
                alertMessages += "Please select Vendor. \n";
            }

            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                alertMessages += "Please select Channel. \n";
            }

            if (selectedModeValue === undefined || selectedModeValue === null) {
                alertMessages += "Please select mode Type. \n";
            }

            if (alertMessages.length > 0) {
                setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Mandatory Field", alertMessage: alertMessages });
                return false;
            }

            let VendorId = 0;

            if (selectedVendorValue === undefined || selectedVendorValue === null) {
                VendorId = 0;
            }
            else {
                VendorId = selectedVendorValue.value;
            }

            let ChannelId = 0;

            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                ChannelId = 0;
            }
            else {
                ChannelId = selectedChannelValue.value;
            }

            let ModeId = 0;

            if (selectedModeValue === undefined || selectedModeValue === null) {
                ModeId = 0;
            }
            else {
                ModeId = selectedModeValue.value;
            }

            let revEntryLeg = 0;
            if (ReversalEntry === undefined || ReversalEntry === null) {
                revEntryLeg = 0;
            }
            else {
                revEntryLeg = ReversalEntry.value;
            }

            let TxnAmountIsDecimal = 0;
            if (TxnAmount === undefined || TxnAmount === null) {
                TxnAmountIsDecimal = 0;
            }
            else {
                TxnAmountIsDecimal = TxnAmount.value;
            }

            setIsLoading(true);

            MaximusAxios.post('api/Field/AddFieldConfig', {
                ClientID: selectedValue.clientID,
                VendorID: VendorId,
                ChannelID: ChannelId,
                ModeID: ModeId,
                FormatID: $('#hdnformatno').val(),
                TerminalCode: $('#terminalCode').val(),
                BinNo: $('#binno').val(),
                AcquirerID: $('#acquirerId').val(),
                RevCode1: $('#reversalCode1').val(),
                RevCode2: $('#reversalCode2').val(),
                RevType: $('#reversalCode1').val().length > 0 && $('#reversalCode2').val().length > 0 ? '2' : $('#reversalCode1').val().length > 0 || $('#reversalCode2').val().length > 0 ? '1' : '',
                RevEntry: revEntryLeg,
                TxnDateTime: $('#txnDateType').val(),
                TxnValueDateTime: $('#valueDateTime').val(),
                TxnPostDateTime: $('#postDateTime').val(),
                ATMType: $('#atm').val(),
                POSType: $('#pos').val(),
                ECOMType: $('#ecom').val(),
                IMPSType: $('#imps').val(),
                UPIType: $('#upi').val(),
                MicroATMType: $('#MicroAtm').val(),
                MobileRechargeType: $('#MobileRecharge').val(),
                Deposit: $('#CashDeposit').val(),
                BalEnq: $('#BalanceEnquiry').val(),
                MiniStatement: $('#MiniStatement').val(),
                PinChange: $('#pinChange').val(),
                ChequeBookReq: $('#chequebookRequest').val(),
                RespCode1: $('#responseCode1').val(),
                RespCode2: $('#responseCode2').val(),
                RespTpe: $('#responseCode1').val().length > 0 && $('#responseCode2').val().length > 0 ? '2' : $('#responseCode1').val().length > 0 || $('#responseCode2').val().length > 0 ? '1' : '',
                EODCode: $('#eodCode').val(),
                OfflineCode: $('#OfflineCode').val(),
                DebitCode: $('#debitType').val(),
                CreditCode: $('#creditType').val(),
                CreatedBy: currentUser.user.username,
                TxnAmountIsDecimal: TxnAmountIsDecimal

            }, {  mode: 'cors' })
                .then(function (response) {
                    setIsLoading(false);
                    if (response.data === null || response.data.length > 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: response.data }); }
                    else { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'Error occurred while processing your request' }); }
                })
                .catch(function (error) {
                    if (error.response) {
                        console.log(error.response.data);
                    }
                    setIsLoading(false);
                });

        }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }
    };

    


    return (
        <div className="configLeft identificationContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Field Identification Config
        </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12 colorPrimaryDefault">Configuration</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12">Field Identification Config</p>
                </div>
            </div>

            {/* Top Content */}
            <div className="accordion" id="unmatchedFilters">
                <div className="accordion-item">
                    <div
                        className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                        id="unmatchedFiltersHeading"
                    >
                        <h6 className="fontWeight-600 colorBlack">Filters</h6>
                        <button
                            className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#unmatchedFiltersCollapse"
                            aria-expanded="true"
                            aria-controls="unmatchedFiltersCollapse"
                        >
                            <span className="icon-Hide"></span>
                            <span className="ms-1 fontSize12-m colorBlack">
                                Show / Hide
              </span>
                        </button>
                    </div>
                    <div
                        id="unmatchedFiltersCollapse"
                        className="accordion-collapse collapse show"
                        aria-labelledby="unmatchedFiltersHeading"
                        data-bs-parent="#unmatchedFilters"
                    >
                        <div className="accordion-body">
                            <div className="hrGreyLine"></div>
                            <div className="configSelectBoxTop row">
                                <div className="clientNameSelect col">
                                    <label htmlFor="clientName">Client Name</label>
                                    <span className="text-danger font-size13">*</span>
                                    <AsyncSelect
                                        cacheOptions
                                        defaultOptions
                                        value={selectedValue}
                                        getOptionLabel={e => e.clientName}
                                        getOptionValue={e => e.clientID}
                                        loadOptions={fetchClientData}
                                        onInputChange={handleInputChange}
                                        onChange={handleClientChange}
                                        id="ddlClient"
                                    />
                                </div>

                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlvendorname">Vendor Name</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlvendorname"
                                        value={selectedVendorValue}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsVendorName.map(x => (
                                            {
                                                value: x.vendorID,
                                                label: x.vendorName
                                            }
                                        ))}
                                        onChange={handleVendorChange}
                                    />
                                </div>

                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlChannel">Channel Type</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlChannel"
                                        value={selectedChannelValue}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsChannelType.map(x => (
                                            {
                                                value: x.channelID,
                                                label: x.channelName
                                            }
                                        ))}
                                        onChange={handleChannelChange}
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                    <label htmlFor="ddlMode">Mode Type</label>
                                    <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlMode"
                                        value={selectedModeValue}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsModeType.map(x => (
                                            {
                                                value: x.modeID,
                                                label: x.transactionMode
                                            }
                                        ))}
                                        onChange={handleModeChange}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Bottom Content */}

            <div className="configLeftBottom">
                <div className="configLeftBottom"><label>Format No:</label> <label><b>{FormatNo}</b></label>
                    <input type="hidden" id="hdnformatno" name="hdnformatno" value="0" />
                    <input type="hidden" id="hdnfieldid" name="hdnfieldid" value="0" /> 
                </div>
                <div className="tableBorderBox">
                    <div className="configSelectBoxTop row">

                        <div className="clientNameSelect col">
                            <label htmlFor="terminalCode">Terminal Code</label>
                            <span className="text-danger font-size13">*</span>
                            <input
                                type="text"
                                name="terminalCode"
                                id="terminalCode"
                                placeholder="Enter Terminal preffix"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="binno">BIN No.</label>
                            <span className="text-danger font-size13">*</span>
                            <input
                                type="number"
                                name="binno"
                                id="binno"
                                placeholder="Enter BIN No."
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="acquirerId">Acquirer ID</label>
                            <input
                                type="number"
                                name="acquirerId"
                                id="acquirerId"
                                placeholder="Enter Acquirer ID"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="reversalCode1">Reversal Code1</label>
                            <input
                                type="text"
                                name="reversalCode1"
                                id="reversalCode1"
                                placeholder="Enter Reversal Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="reversalCode2">Reversal Code2</label>
                            <input
                                type="text"
                                name="reversalCode2"
                                id="reversalCode2"
                                placeholder="Enter Reversal Code (If required)"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="reversalType">Reversal Type</label>
                            <input
                                type="number"
                                name="reversalType"
                                id="reversalType"
                                placeholder="Enter Reversal Type"
                                className="inputTextBox disabledInput"
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="reversalentry">Reversal Entry</label> 
                            <Select
                                id="ddlReversalentry"
                                classNamePrefix="reactSelectBox"
                                options={optionsReversalEntry}
                                value={ReversalEntry}
                                onChange={handleReversalEntry}
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="debitType">Debit Type</label>
                            <input
                                type="text"
                                name="debitType"
                                id="debitType"
                                placeholder="Enter Debit Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="creditType">Credit Type</label>
                            <input
                                type="text"
                                name="creditType"
                                id="creditType"
                                placeholder="Enter Credit Code"
                                className="inputTextBox" 

                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="txnDateType">Txn Date Time</label>
                            <input
                                type="date"
                                name="txnDateType"
                                id="txnDateType"
                                placeholder="Enter Txn Date Time"
                                className="inputTextBox"  
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="valueDateTime">Value Date Time</label>
                            <input
                                type="date"
                                name="valueDateTime"
                                id="valueDateTime"
                                placeholder="Enter Value Date Time"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="postDateTime">Post Date Time</label>
                            <input
                                type="date"
                                name="postDateTime"
                                id="postDateTime"
                                placeholder="Enter Post Date Time"
                                className="inputTextBox" 
                            />
                        </div>


                        <div className="clientNameSelect col">
                            <label htmlFor="atm">ATM</label>
                            <input
                                type="text"
                                name="atm"
                                id="atm"
                                placeholder="Enter ATM Code"
                                className="inputTextBox" 
                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="pos">POS</label>
                            <input
                                type="text"
                                name="pos"
                                id="pos"
                                placeholder="Enter POS Code"
                                className="inputTextBox" 
                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="ecom">ECOM</label>
                            <input
                                type="text"
                                name="ecom"
                                id="ecom"
                                placeholder="Enter ECOM Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="imps">IMPS</label>
                            <input
                                type="text"
                                name="imps"
                                id="imps"
                                placeholder="Enter IMPS Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="upi">UPI</label>
                            <input
                                type="text"
                                name="upi"
                                id="upi"
                                placeholder="Enter UPI Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="MicroAtm">MicroATM</label>
                            <input
                                type="text"
                                name="MicroAtm"
                                id="MicroAtm"
                                placeholder="Enter MICROATM Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="MobileRecharge">Mobile Recharge</label>
                            <input
                                type="text"
                                name="MobileRecharge"
                                id="MobileRecharge"
                                placeholder="Enter Mobile Recharge Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="CashDeposit">Cash Deposit</label>
                            <input
                                type="text"
                                name="CashDeposit"
                                id="CashDeposit"
                                placeholder="Enter Deposit Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="BalanceEnquiry">Balance Enquiry</label>
                            <input
                                type="text"
                                name="BalanceEnquiry"
                                id="BalanceEnquiry"
                                placeholder="Enter Balance Enquiry Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="MiniStatement">Mini Statement</label>
                            <input
                                type="text"
                                name="MiniStatement"
                                id="MiniStatement"
                                placeholder="Enter Mini Statement Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="pinChange">PIN Change</label>
                            <input
                                type="text"
                                name="pinChange"
                                id="pinChange"
                                placeholder="Enter PIN Change Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="chequebookRequest">Chequebook Request</label>
                            <input
                                type="text"
                                name="chequebookRequest"
                                id="chequebookRequest"
                                placeholder="Enter Chequebook Request Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="responseCode1">Response Code1</label>
                            <input
                                type="number"
                                name="responseCode1"
                                id="responseCode1"
                                placeholder="Enter Response Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="responseCode2">Response Code2</label>
                            <input
                                type="number"
                                name="responseCode2"
                                id="responseCode2"
                                placeholder="Enter Response Code"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="RespopnseType">Response Type</label>
                            <input
                                type="number"
                                name="ResponseType"
                                id="ResponseType"
                                placeholder="Enter Response Type"
                                className="inputTextBox" 
                            />
                        </div>

                        <div className="clientNameSelect col">
                            <label htmlFor="eodCode">EOD Code</label>
                            <input
                                type="text"
                                name="eodCode"
                                id="eodCode"
                                placeholder="Enter EOD Code"
                                className="inputTextBox" 
                            />
                        </div> 

                        <div className="clientNameSelect col">
                            <label htmlFor="txnAmountDecimal">Txn Amount’s Decimal</label>
                            <Select
                                id="ddlTxnAmtIsDec"
                                classNamePrefix="reactSelectBox"
                                options={optionsAmountDecimal}
                                value={TxnAmount}
                                onChange={handleTxnAmount}
                            />
                        </div>


                        <div className="clientNameSelect col">
                            <label htmlFor="OfflineCode">Offline Code</label>
                            <input
                                type="text"
                                name="OfflineCode"
                                id="OfflineCode"
                                placeholder="Enter Offline Code (If any)"
                                className="inputTextBox" 
                            />
                        </div>
                    </div>

                    <div className="text-center btnsBtm">

                        <button
                            type="button"
                            className="btnPrimary ms-2"
                            onClick={btnSubmitClick}
                        >
                            Submit
           </button>&nbsp;
              <button
                            type="button"
                            className="btnPrimaryOutline"
                            onClick={(e) => onReset(e)}
                        >
                            Reset
                                    </button>

                    </div>
                </div>
            </div>


            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>
    );
};

export default FieldMainWindow;


