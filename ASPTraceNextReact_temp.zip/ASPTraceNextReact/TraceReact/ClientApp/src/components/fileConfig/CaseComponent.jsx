﻿import React, { useState, useRef, useEffect, useContext } from 'react';
import './StyledCaseComponent.css';
import Select from "react-select"; 
import MaximusAxios from "../common/apiURL" ;


const CaseComponent = ({ Tabledata, Optionsdata, UpdateColumnID, UpdateColumnIDFn }) => {
     
    const [caseConditionsArr, setCaseConditionsArr] = useState([{ CaseID: 0, ColumnName: { value: 0, label: "select" }, Function: { value: 0, label: "select" },Operation: { value: 0, label: "select" }, ConditionTextValue: "", OutputValue: "", statusCondition:"",IsClear: false }]);
    const [finalCondition, setFinalCondition] = useState("");
    const [ColumnN, setColumnN] = useState(""); 

    useEffect(() => {
        let Column = Tabledata.filter((item, i) => item.columnID === UpdateColumnID.ID);
        //console.log(Column[0].aliasColumn);
        let ColumnName = '';
        if (Column !== null && Column !== undefined && Column.length > 0) {
            setColumnN(Column[0].aliasColumn);
        }
    }, []);

    const ColumnsList = () => {

        let ColumnNames = [];

        ColumnNames = Optionsdata.length > 0 ? Optionsdata.map((item) => (
            { value: item.ColumnID, label: item.MappedColumn }
        )) : [{ value: 0, label: "select" }];

        return ColumnNames;
    }

    const Functions = () => {

        let FunctionsArr = ['LIKE', 'SUBSTRING', 'LEFT', 'RIGHT', '=', '<', '<=', '>=', '>','!=','IN','IS NULL','IS NOT NULL'];

        let Functions = FunctionsArr.map((item,index) => (
            { value: index, label: item }
        ))

        return Functions;
    }

    const Operations = () => {

        let OperationsArr = ['AND', 'OR','THEN','ELSE','ELSE CASE','Only Value'];

        let Operations = OperationsArr.map((item, index) => (
            { value: index, label: item }
        ))

        return Operations;
    }

    const Data = {

        ColumnNames: ColumnsList()
        ,Functions: Functions()
        ,OutputValues:[]
        , Operations: Operations()
    }

    function generateSQLConditionString(caseConditionsArr) {
        let conditionString = "case ";
        let previousOperation = "";

        const allowedLabels = ['<', '<=', '>=', '>', '!=',  '='];

        for (const condition of caseConditionsArr) {
            if (condition.Function.label === "LIKE") {

                if (previousOperation !== "AND") {
                    conditionString += ` when `
                }
                conditionString += `${condition.ColumnName.label} ${condition.Function.label} '%${condition.ConditionTextValue}%' `;
            }
            else if (condition.Function.label === "SUBSTRING") {

                if (previousOperation !== "AND") {
                    conditionString += ` when `
                }
                conditionString += `${condition.Function.label}(${condition.ColumnName.label} , ${condition.ConditionTextValue}) `;
            }
            else if (condition.Function.label === "IN") {

                if (previousOperation !== "AND") {
                    conditionString += ` when `
                }
                const splitWords = condition.ConditionTextValue.split(',').map(word => `'${word.trim()}'`);
                let ConditionText = splitWords.join(', ');
                conditionString += `${condition.ColumnName.label} ${condition.Function.label}  (${ConditionText}) `;
            }
            else if (allowedLabels.includes(condition.Function.label)) {

                if (previousOperation !== "AND") {
                    conditionString += ` when `
                }
                conditionString += ` ${condition.ColumnName.label} ${condition.Function.label}  '${condition.ConditionTextValue}' `;
            }

            if (condition.Operation.label === "AND") {
                conditionString += "and ";
            }

            if (condition.Operation.label === "THEN") {
                conditionString += `then '${condition.OutputValue}' `;
            }

            if (condition.Operation.label === "ELSE") {
                conditionString += `else '${condition.OutputValue}' `;
            }

            if (condition.Operation.label === 'Only Value') {
                conditionString = ` '${condition.OutputValue}' `;
                break;
            }
            previousOperation = condition.Operation.label;
        }

        let ColName = ColumnN;

        if (!conditionString.includes('case')) {
            //conditionString += ` AS ${ColName}`;
        }
        else {
            conditionString += `END `;
            //conditionString += `END AS ${ColName}`;
        }

        return conditionString;
    }


    const FnUpdateConditionArr = (value) => {

        let caseConditions = [...value];

        let sqlCondition = generateSQLConditionString(caseConditions);
        sqlCondition = sqlCondition != "" ? sqlCondition : "";
        setFinalCondition(sqlCondition);

        UpdateColumnIDFn({ ID: UpdateColumnID.ID, CaseCondition: sqlCondition})
        //const JsonString = JSON.stringify(caseConditions);
        //console.log(JsonString);

        setCaseConditionsArr(caseConditions);
    };

    const handleFinalCondition = (value) => {
        setFinalCondition(value);
        UpdateColumnIDFn({ ID: UpdateColumnID.ID, CaseCondition: value })
    };


    return (
        <>
            <div>
                <textarea className="CaseConditionTextArea" placeholder="case condition will appear here"
                    value={finalCondition} onChange={(e) => handleFinalCondition(e.target.value)} />
            </div>
            <div className="Stage-box">

                <TableGrid
                    ColumnN={ColumnN}
                    caseConditionsArr={caseConditionsArr}
                    setFinalCondition={setFinalCondition}
                    FnUpdateConditionArr={FnUpdateConditionArr}
                    gridData={Data}
                />
                
            </div>
        </>
    );
};
export default CaseComponent;

const FetchDropDown = () => {
    return MaximusAxios
        .get('api/ReconConfig/CaseOutputList?ClientID=0', {  mode: 'cors' })
        .then((response) => {
            if (response.data != null || response.data.length > 0) {
                return response.data;
            } else {
                console.log('Error occurred while processing your request');
                return null; // You may want to handle the error case gracefully
            }
        })
        .catch((error) => {
            if (error.response) {
                console.log(error.response.data);
            }
            return null; // Handle the error case here as well
        });
};


const OutputDropDown = ({ DropData,columnName,DrpValue, DrpValueUpdateFn }) => {

    const dt = DropData.filter((D) => D.columnName === columnName);

    const DropdownValues = dt[0].dropDownValues.split(',');

    return (
        <div className="configSelectBoxTop row">
            <div className="clientNameSelect">
                {
                    <Select
                        id="ddlTable"
                        //{ value: p.status.value, label: p.status.label }
                        value={DrpValue}
                        classNamePrefix="reactSelectBox"
                        options={DropdownValues.map((label,i) => (
                            {
                                value: i,
                                label: label
                            }
                        ))}
                        onChange={(value) => DrpValueUpdateFn(DrpValue.value, value.label)}
                    />
                }
            </div>
        </div>
        );
};

const hasDropDown = (ColumnName) => {
    const Columns = ['TxnsSubType', 'TxnsStatus', 'TxnsType', 'CardNumber', 'DrCrType', 'CardType']
    const hasDrop = IsMatchedFunction(ColumnName, Columns)

    return hasDrop;

}
const IsMatchedFunction = (textToCheck, arr) => {

    const wordsToCheck = arr;

    // Your condition to check if p.Operation.label matches any of the words
    const doesMatch = wordsToCheck.includes(textToCheck);

    return doesMatch;
}


const TableGrid = ({ ColumnN, caseConditionsArr, setFinalCondition, FnUpdateConditionArr, gridData }) => {

    const [dropDownData, setDropDownData] = useState([]);

    useEffect(() => {
        FetchDropDown().then((data) => {
            if (data) {
                setDropDownData(data);
            }
        }); 

        console.log('dropDownData');
        console.log(dropDownData);
    }, []);


    function getRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    }

    // Example usage:
    const randomNum = getRandomNumber(1, 1000);

    const handleAdd = (index) => {
        // Create a new row object and add it to the array


        const newRow = {
            CaseID: randomNum,
            ColumnName: { value: 0, label: "select" },
            Function: { value: 0, label: "select" }, Operation: { value: 0, label: "select" },
            ConditionTextValue: "",
            OutputValue: "",
            statusCondition: "",
            IsClear: false
        };
        const updatedCaseConditionsArr = [...caseConditionsArr];
        updatedCaseConditionsArr.splice(index + 1, 0, newRow);
        FnUpdateConditionArr(updatedCaseConditionsArr);
    };

    const handleRemove = (index) => {
        // Remove the row at the given index
        const updatedCaseConditionsArr = [...caseConditionsArr];
        updatedCaseConditionsArr.splice(index, 1);


        if (updatedCaseConditionsArr.length === 0) {
            let OriginalRow = {
                CaseID: randomNum,
                ColumnName: { value: 0, label: "select" },
                Function: { value: 0, label: "select" }, Operation: { value: 0, label: "select" },
                ConditionTextValue: "",
                OutputValue: "",
                statusCondition: "",
                IsClear: false
            };

            updatedCaseConditionsArr.splice(index + 1, 0, OriginalRow);

        }
        FnUpdateConditionArr(updatedCaseConditionsArr);
    };

    const handleColumnChange = (CaseID, value) => {

        try {
            let val = caseConditionsArr.filter((item, i) => item.CaseID === CaseID);

            let Temp = [...caseConditionsArr].map((item) => {
                if (item.CaseID === CaseID) {
                    item.ColumnName = { value: value.value, label: value.label };
                    return item;
                } else {
                    return item;
                }
            })

            FnUpdateConditionArr(Temp);
        }
        catch (e) {
            console.log('handleColumnChange');
            console.log(e);
        }

    }

    const handleOperationChange = (CaseID, value) => {

        let val = caseConditionsArr.filter((item, i) => item.CaseID === CaseID);

        let Temp = [...caseConditionsArr].map((item) => {
            if (item.CaseID === CaseID) {
                item.Operation = { value: value.value, label: value.label };
                return item;
            } else {
                return item;
            }
        })

        FnUpdateConditionArr(Temp);

    }

    const handleFunctionChange = (CaseID, value) => {

        let val = caseConditionsArr.filter((item, i) => item.CaseID === CaseID);

        let Temp = [...caseConditionsArr].map((item) => {
            if (item.CaseID === CaseID) {
                item.Function = { value: value.value, label: value.label };
                return item;
            } else {
                return item;
            }
        })

        FnUpdateConditionArr(Temp);

    }

    const handleOutputChange = (CaseID, value) => {
        //if (e.key === 'Enter') {
        let val = caseConditionsArr.filter((item, i) => item.CaseID === CaseID);

        let Temp = [...caseConditionsArr].map((item) => {
            if (item.CaseID === CaseID) {
                item.OutputValue = value;
                return item;
            } else {
                return item;
            }
        });

        FnUpdateConditionArr(Temp);
        //}
    }
    const handleCaseValueChange = (CaseID, value, e) => {
        if (e.key === 'Enter') {
            let val = caseConditionsArr.filter((item, i) => item.CaseID === CaseID);

            let Temp = [...caseConditionsArr].map((item) => {
                if (item.CaseID === CaseID) {
                    item.ConditionTextValue = value;
                    return item;
                } else {
                    return item;
                }
            });

            FnUpdateConditionArr(Temp);
        }
    }


    return (
        <>
            <div className="stage_container">

                {
                    caseConditionsArr.value !== 0 &&
                    <div className="tableBorderBox mt-2 pt-3">
                        <div className="table-responsive overflow-suggestions">
                            <div className="tableContentBox " >
                                <table id="gvStatusConf" className="w-100 table table-striped table-hover table-borderless align-middle"  >
                                    <thead >
                                        <tr >
                                            <th scope="col">ColumnName</th>
                                            <th scope="col">Function</th>
                                            <th scope="col">TextValue</th>
                                            <th scope="col">Operation</th>
                                            <th scope="col">OutputValue</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            caseConditionsArr.map((p, index) => {
                                                //if (p.status != "")
                                                {
                                                    return <tr key={index}>
                                                        <td >
                                                            {
                                                                !IsMatchedFunction(p.Operation.label, ['ELSE', 'ELSE CASE', 'Only Value']) &&
                                                                <div className="configSelectBoxTop row">
                                                                    <div className="clientNameSelect">
                                                                        {
                                                                            <Select
                                                                                id="ddlTable" 
                                                                                classNamePrefix="reactSelectBox"
                                                                                options={gridData.ColumnNames.map(x => (
                                                                                    {
                                                                                        value: x.value,
                                                                                        label: x.label
                                                                                    }
                                                                                ))}
                                                                                onChange={(value) => handleColumnChange(p.CaseID, value)}
                                                                                maxMenuHeight={100}
                                                                            />
                                                                        }
                                                                    </div>
                                                                </div>
                                                            }
                                                        </td>
                                                        <td >
                                                            {
                                                                !IsMatchedFunction(p.Operation.label, ['ELSE', 'ELSE CASE', 'Only Value']) &&
                                                                <div className="configSelectBoxTop row">
                                                                    <div className="clientNameSelect">
                                                                        {
                                                                            <Select
                                                                                id="ddlTable"
                                                                                //{ value: p.status.value, label: p.status.label }
                                                                                value={p.Function}
                                                                                classNamePrefix="reactSelectBox"
                                                                                options={gridData.Functions.map(x => (
                                                                                    {
                                                                                        value: x.value,
                                                                                        label: x.label
                                                                                    }
                                                                                ))}
                                                                                onChange={(value) => handleFunctionChange(p.CaseID, value)}
                                                                                maxMenuHeight={100}
                                                                            />
                                                                        }
                                                                    </div>
                                                                </div>
                                                            }
                                                        </td>
                                                        <td >
                                                            {
                                                                !IsMatchedFunction(p.Operation.label, ['ELSE', 'ELSE CASE', 'Only Value']) &&
                                                                <div id="CaseTextValue" className="StartPositionField">
                                                                    <input type="text"
                                                                        onKeyDown={(e) => handleCaseValueChange(p.CaseID, e.target.value, e)}
                                                                    />
                                                                </div>
                                                            }
                                                        </td>
                                                        <td >
                                                            {
                                                                //p.Operation.label != 'ELSE' &&
                                                                <div className="configSelectBoxTop row">
                                                                    <div className="clientNameSelect">
                                                                        {
                                                                            <Select
                                                                                id="ddlTable"
                                                                                //{ value: p.status.value, label: p.status.label }
                                                                                value={p.Operation}
                                                                                classNamePrefix="reactSelectBox"
                                                                                options={gridData.Operations.map(x => (
                                                                                    {
                                                                                        value: x.value,
                                                                                        label: x.label
                                                                                    }
                                                                                ))}
                                                                                onChange={(value) => handleOperationChange(p.CaseID, value)}
                                                                                maxMenuHeight={100}
                                                                            />
                                                                        }
                                                                    </div>
                                                                </div>
                                                            }
                                                        </td>
                                                        <td >
                                                            {
                                                                IsMatchedFunction(p.Operation.label, ['ELSE', 'THEN', 'Only Value']) &&
                                                                <div className="StartPositionField">
                                                                    {
                                                                        hasDropDown(ColumnN) && dropDownData.length > 0 ?
                                                                            <OutputDropDown
                                                                                DropData={dropDownData}
                                                                                columnName={ColumnN}
                                                                                DrpValue={{ value: p.CaseID, label: p.OutputValue === '' ? 'select' : p.OutputValue }}
                                                                                DrpValueUpdateFn={handleOutputChange}
                                                                            />
                                                                            :
                                                                            <input type="text"
                                                                                onKeyDown={(e) => {
                                                                                    if (e.key === 'Enter') {
                                                                                        handleOutputChange(p.CaseID, e.target.value)
                                                                                    }
                                                                                }
                                                                                }
                                                                            />
                                                                    }
                                                                </div>
                                                            }
                                                        </td>

                                                        <td>
                                                            <div className="StyledRow_Action">
                                                                <button className="StyledRow_Action_Update Button-Green" onClick={() => (handleAdd(index))}>Add</button>
                                                                <button className="StyledRow_Action_Update Button-Red" onClick={() => (handleRemove(index))}>delete</button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                }
                                            })
                                        }
                                    </tbody>
                                </table>
                            </div>

                        </div>

                    </div>
                }
            </div>
        </>
    );

};

