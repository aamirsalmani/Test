import React from "react";
import { useSelector } from "react-redux";
import SidebarMain from "../common/SidebarMain"; 
import ExcelFileConfigMainWindow from "./ExcelFileConfigMainWindow";


const ExcelFileConfig = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                <ExcelFileConfigMainWindow />
            {/* </div> */}
        </div>
    );
};

export default ExcelFileConfig;