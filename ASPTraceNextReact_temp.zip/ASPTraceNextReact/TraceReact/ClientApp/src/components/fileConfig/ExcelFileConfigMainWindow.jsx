import React, { useState, useEffect } from "react";
import * as XLSX from "xlsx";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import Select from "react-select";
import MaximusAxios from "../common/apiURL" ;
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import "./ExcelFileConfig.css";
import resetHeader from "../../images/common/resetHeader.svg";
import resetDropDown from "../../images/common/Reset.svg";
import CaseComponent from "./CaseComponent";
import { useSelector } from "react-redux";
import { AddIcon, RemoveIcon } from '../dynamicReconConfig/Utility/assets/Icons/iconsIndex';
const ExcelFileConfigMainWindow = () => {
     const navigate = useNavigate();
    const currentUser = useSelector((state) => state.authReducer);
    const [excelColumns, setExcelColumns] = useState([]);
const [TableQuery, setTableQuery] = useState(null);
const [isEditMode, setIsEditMode] = useState(false);
  const { state } = useLocation();
    const [showSubmitConfig, setshowSubmitConfig] = useState(false);
  const { tableName,fileName, file, fileType, client,
    channel,
    mode } = state || {};

    const [clientInfo, setClientInfo] = useState(null);
const [channelInfo, setChannelInfo] = useState(null);
const [modeInfo, setModeInfo] = useState(null);
const [tableTitle, setTableTitle] = useState("");


    const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });
useEffect(() => {
  if (state?.isEditMode) {
    try {
      const parsedConfig = JSON.parse(state.tableConfigs);
      setExcelColumns(parsedConfig);
      setTableQuery(state.Query || "");
      setIsEditMode(true);
      setshowSubmitConfig(false);
console.log('Client',state.client);
console.log('channel',state.channel);
console.log('mode',state.mode);
console.log('tableName',state.tableName);
      // 👇 Set display values
      setClientInfo(state.client);
      setChannelInfo(state.channel);
      setModeInfo(state.mode);
      setTableTitle(state.tableName);
    } catch (err) {
      console.error("Failed to parse tableConfigs JSON", err);
    }
  } else if (file && fileType === "xlsx") {
    // Set info for non-edit mode
    setClientInfo(state.client);
    setChannelInfo(state.channel);
    setModeInfo(state.mode);
    setTableTitle(state.tableName);

    const reader = new FileReader();
    reader.onload = (e) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const json = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      const headers = json[0];

      if (Array.isArray(headers)) {
        const sampleData = json.slice(1, 6);
        const formatted = headers.map((col, i) => {
          const columnValues = sampleData.map((row) => row[i]?.toString() ?? "");
          const { type, value } = inferDataType(columnValues);
          return {
            selected: true,
            excelColumn: col,
            tableColumn: col,
            dataType: type,
            value: value || "",
            keyType: "",
          };
        });
        setExcelColumns(formatted);
      }
    };
    reader.readAsArrayBuffer(file);
  }
}, [file, state]);

const dataTypes = ["VARCHAR","NVARCHAR","INT","BIGINT","FLOAT","DECIMAL","BIT","DATETIME","DATE","TIME","TEXT","UNIQUEIDENTIFIER",];
const GenerateQuery = () => {
  const selectedColumns = excelColumns.filter(
    (col) => col.selected && col.dataType !== ""
  );

  if (isEditMode && Array.isArray(excelColumns)) {
    const originalConfig = JSON.parse(state.tableConfigs || "[]");
    const originalSelected = originalConfig.filter((col) => col.selected);

    const originalCols = originalSelected.map(
      (col) => col.tableColumn || col.excelColumn
    );
    const currentCols = selectedColumns.map(
      (col) => col.tableColumn || col.excelColumn
    );

    const queries = [];

    // 🔁 Detect renamed columns (same excelColumn, different tableColumn)
    const renamedCols = selectedColumns.filter((col) => {
      const original = originalSelected.find(
        (o) => o.excelColumn === col.excelColumn && o.selected
      );
      return original && original.tableColumn !== col.tableColumn;
    });

    const renamedFromTo = renamedCols.map((col) => {
      const original = originalSelected.find(
        (o) => o.excelColumn === col.excelColumn
      );
      return {
        oldName: original.tableColumn,
        newName: col.tableColumn,
      };
    });

    // 🛑 Prevent false drop/add for renamed
    const renamedOldNames = renamedFromTo.map((r) => r.oldName);
    const renamedNewNames = renamedFromTo.map((r) => r.newName);

    const droppedCols = originalCols.filter(
      (col) => !currentCols.includes(col) && !renamedOldNames.includes(col)
    );
    const addedCols = currentCols.filter(
      (col) => !originalCols.includes(col) && !renamedNewNames.includes(col)
    );

    // 🔧 Rename columns
    renamedFromTo.forEach(({ oldName, newName }) => {
      queries.push(
        `EXEC sp_rename '${tableName}.${oldName}', '${newName}', 'COLUMN';`
      );
    });

    // 🗑 Drop columns
    if (droppedCols.length > 0) {
      const dropQuery = `ALTER TABLE [${tableName}] DROP COLUMN ${droppedCols
        .map((col) => `[${col}]`)
        .join(", ")};`;
      queries.push(dropQuery);
    }

    // ➕ Add new columns
    if (addedCols.length > 0) {
      const addDefinitions = selectedColumns
        .filter((col) =>
          addedCols.includes(col.tableColumn || col.excelColumn)
        )
        .map((col) => {
          const name = col.tableColumn || col.excelColumn;
          const type = col.dataType;
          const value = col.value || "";
          return `[${name}] ${type}${value}`;
        });

      const addQuery = `ALTER TABLE [${tableName}] ADD ${addDefinitions.join(",\n")};`;
      queries.push(addQuery);
    }

    if (queries.length === 0) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "info",
        alertTitle: "No Changes Detected",
        alertMessage: "There are no changes to apply in edit mode.",
      });
      setTableQuery("");
      setshowSubmitConfig(false);
      return;
    }

    const finalAlterQuery = queries.join("\n\n");
    setTableQuery(finalAlterQuery);
    setshowSubmitConfig(true);
  } else {
    // ➕ CREATE TABLE for fresh config
    let createQuery = `CREATE TABLE [${tableName}] (\n`;

    selectedColumns.forEach((col, idx) => {
      const name = col.tableColumn || col.excelColumn;
      const type = col.dataType;
      const value = col.value || "";
      const key = col.keyType;

      createQuery += `  [${name}] ${type}${value} ${key}`.trim();
      createQuery += idx !== selectedColumns.length - 1 ? ",\n" : "\n";
    });

    createQuery += ");";
    setTableQuery(createQuery);
    setshowSubmitConfig(true);
  }
};




const inferDataType = (values) => {
  let isInt = true;
  let isFloat = true;
  let isDate = true;

  for (let value of values) {
    if (value === null || value === undefined || value === "") continue;

    if (!/^\d+$/.test(value)) isInt = false;
    if (!/^\d+(\.\d+)?$/.test(value)) isFloat = false;
    if (isNaN(Date.parse(value))) isDate = false;
  }

  if (isInt) return { type: "INT", value: "" };
  if (isFloat) return { type: "DECIMAL", value: "(18,2)" };
  if (isDate) return { type: "DATETIME", value: "" };

  // Fallback to VARCHAR with length
  const maxLength = Math.max(...values.map((v) => (v ? v.length : 0)));
  const length = Math.min(Math.max(maxLength, 1), 255);
  return { type: "VARCHAR", value: `(${length})` };
};
const keyTypes = ["", "PRIMARY KEY", "NOT NULL", "NULL"];
const handleSubmit = async () => {
  
  try {
    const response = await MaximusAxios.post(
      "api/DynamicTable/CreateDynamicTable", // adjust if your controller route is different
      TableQuery,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    console.log(response.data);
    const { Status, Message } = response.data;

    if (Status === 1) {
      
      const saveConfigPayload = {
        ClientID: client.value || client.clientID,
        ChannelID: channel.value || channel.channelID,
        ModeID: mode.value || mode.modeID,
        ClientName: client.label || client.clientName || "",
        ChannelName: channel.label || channel.channelName || "",
        ModeName: mode.label || mode.modeName || "",
        FileName: fileName,
        fileType: fileType,
        TableName: tableName,
        TableConfigs: JSON.stringify(excelColumns), // Save full config
        Query: TableQuery,
        CreatedBy: currentUser?.user?.username || "system",
      };

      const saveResponse = await MaximusAxios.post(
        "api/DynamicTable/InsertDynamicTableConfig",
        saveConfigPayload,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      alert("✅ Success: " + Message);
      navigate("/configuration/dynamic-table-config");
    } else {
      alert("❌ Error: " + (Message || "Table creation failed."));
    }
  } catch (error) {
    alert(
      "❌ Exception: " +
        (error.response?.data?.Message || error.Message || "Unknown error")
    );
  }
};

const handleCancel = ()=>{
    setExcelColumns([]);
  setTableQuery(null);
  setIsEditMode(false);
  setshowSubmitConfig(false);
navigate("/configuration/dynamic-table-config");
}
const handleUpdate = async () => {
  try {
    // 1. First call: Alter the table structure
    const alterResponse = await MaximusAxios.post(
      "api/DynamicTable/AlterDynamicTable",
      TableQuery,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    // Check if ALTER TABLE succeeded
    const { Status, Message } = alterResponse.data;

    if (Status !== 1 && Message) {
      alert("❌ ALTER Failed: " + Message);
      return;
    }

    // 2. Then update the table config
    const updatePayload = {
      TableID: state.tableConfigID,
      TableConfigs: JSON.stringify(excelColumns),
      Query: TableQuery,
      ModifiedBy: currentUser?.user?.username || "system",
    };

    const configResponse = await MaximusAxios.post(
      "api/DynamicTable/UpdateDynamicTableConfig",
      updatePayload,
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );

    const configResult = configResponse.data;

    console.log('Config Response',configResponse.data);
    if (configResult.status === 1) {
      alert("✅ Configuration updated successfully.");
      navigate("/configuration/dynamic-table-config");
    } else {
      alert("❌ Error: " + (configResult.message || "Update failed."));
    }
  } catch (error) {
    alert(
      "❌ Exception: " +
        (error.response?.data?.Message || error.message || "Unknown error")
    );
    console.error(error);
  }
};

const handleAddRowBelow = (index) => {
  const newRow = {
    excelColumn: "",
    tableColumn: "",
    dataType: "",
    value: "",
    keyType: "",
    selected: false,
    createdFromAction: true, // ✅ Flag to detect action-based row
  };

  const updated = [...excelColumns];
  updated.splice(index + 1, 0, newRow); // Insert row below current
  setExcelColumns(updated);
};


const handleRemoveRow = (index) => {
  const updated = [...excelColumns];
  updated.splice(index, 1);
  setExcelColumns(updated);
};


  return (
 <div className="configLeft identificationContainer">
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Dynamic File Configuration
        </h5>
        <span className="fontWeight-600 colorBlack">
          {" "}
          File Type ({fileType}){" "}
        </span>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">File Configuration</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Spreadsheet Config</p>
        </div>
      </div>
    <div className="configLeftTop">
      <div className="accordion" id="basicConfig">
        <div className="accordion-item">
          <div className="accordion-header">
            <h6 className="fontWeight-600 colorBlack">Selected Configuration</h6>
            <hr />
           {clientInfo && channelInfo && modeInfo && tableTitle ? (
              <div className="configSelectBoxTop row">
                <div className="clientNameSelect col">
                  <label><b>Client Name :</b></label>
                  <label>&nbsp;{clientInfo.label || clientInfo.clientName||clientInfo}</label>
                </div>
                <div className="clientNameSelect col">
                  <label><b>Channel Name :</b></label>
                  <label>&nbsp;{channelInfo.label || channelInfo.channelName||channelInfo}</label>
                </div>
                <div className="clientNameSelect col">
                  <label><b>Mode :</b></label>
                  <label>&nbsp;{modeInfo.label || modeInfo.modeName ||modeInfo}</label>
                </div>
                  <div className="clientNameSelect col">
                  <label><b>Table Name :</b></label>
                  <label>&nbsp;{tableTitle}</label>
                </div>
              </div>
             
            ) : (
              <div className="tableBorderBox pb-3 pt-3">
                <div className="clientNameSelect configFormatEntities">
                  <p className="text-danger font-size12">No Records</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
     {excelColumns.length > 0 && (
  <div className="accordion-body pt-3">
    <h5 className="fontWeight-600 fontSize14 colorBlack">
      Excel Column Mapping
    </h5>
    <div className="hrGreyLine"></div>

    <div className="tableBorderBox pt-3">
      <div
        className="w-100 table-responsive"
        style={{ maxHeight: "18.7rem", overflowY: "auto" }}
      >
        <table
          id="gvExcelColumnGrid"
          className="recontable table-striped table-hover table-borderless align-middle w-100"
        >
          <thead
            style={{
              position: "sticky",
              top: 0,
              backgroundColor: "white",
              zIndex: 1,
            }}
          >
            <tr>
              <th>✔</th>
              <th>Excel Column</th>
              <th>Table Column</th>
              <th>Data Type</th>
              <th>Value</th>
              <th>Key</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {excelColumns.map((col, index) => (
              <tr key={index} style={{ height: "45px" }}>
                <td>
                  <input
                    type="checkbox"
                    checked={col.selected}
                    onChange={(e) => {
                      const updated = [...excelColumns];
                      updated[index].selected = e.target.checked;
                      setExcelColumns(updated);
                    }}
                  />
                </td>
                <td>{col.excelColumn}</td>
                <td>
                  <input
                    type="text"
                    value={col.tableColumn}
                    onChange={(e) => {
                      const updated = [...excelColumns];
                      updated[index].tableColumn = e.target.value;

                      // ✅ Auto-fill excelColumn for + added rows only
                      if (updated[index].createdFromAction) {
                        updated[index].excelColumn = e.target.value;
                      }

                      setExcelColumns(updated);
                    }}

                    className="form-control txt"
                  />
                </td>
                <td>
                  <div className="clientNameSelect">
                   <Select
  id={"ddlDataType" + index}
  value={
    col.dataType !== ""
      ? { value: col.dataType, label: col.dataType }
      : { value: "", label: "Select" }
  }
  options={dataTypes.map((type) => ({
    value: type,
    label: type,
  }))}
  onChange={(selected) => {
    const updated = [...excelColumns];
    updated[index].dataType = selected.value;
    setExcelColumns(updated);
  }}
  classNamePrefix="reactSelectBox"
  menuPortalTarget={document.body}
  styles={{
  menuPortal: (base) => ({ ...base, zIndex: 9999 }),
  control: (base) => ({
    ...base,
    minHeight: '30px',
    height: '30px',
    fontSize: '12px',
  }),
  valueContainer: (base) => ({
    ...base,
    height: '30px',
    padding: '0 8px',
  }),
  input: (base) => ({
    ...base,
    margin: 0,
    padding: 0,
  }),
  indicatorsContainer: (base) => ({
    ...base,
    height: '30px',
  }),
  menu: (base) => ({
    ...base,
    fontSize: '12px',
  }),
}}
  menuPosition="fixed"
/>
                  </div>
                </td>
                <td>
                  <input
                    type="text"
                    value={col.value}
                    onChange={(e) => {
                      const updated = [...excelColumns];
                      updated[index].value = e.target.value;
                      setExcelColumns(updated);
                    }}
                    className="form-control txt"
                  />
                </td>
                <td>
                  <div className="clientNameSelect">
                   <Select
  id={"ddlKeyType" + index}
  value={
    col.keyType !== ""
      ? { value: col.keyType, label: col.keyType }
      : { value: "", label: "None" }
  }
  options={keyTypes.map((key) => ({
    value: key,
    label: key === "" ? "None" : key,
  }))}
  onChange={(selected) => {
    const updated = [...excelColumns];
    updated[index].keyType = selected.value;
    setExcelColumns(updated);
  }}
  classNamePrefix="reactSelectBox"
  menuPortalTarget={document.body}
  styles={{
  menuPortal: (base) => ({ ...base, zIndex: 9999 }),
  control: (base) => ({
    ...base,
    minHeight: '30px',
    height: '30px',
    fontSize: '12px',
  }),
  valueContainer: (base) => ({
    ...base,
    height: '30px',
    padding: '0 8px',
  }),
  input: (base) => ({
    ...base,
    margin: 0,
    padding: 0,
  }),
  indicatorsContainer: (base) => ({
    ...base,
    height: '30px',
  }),
  menu: (base) => ({
    ...base,
    fontSize: '12px',
  }),
}}
  menuPosition="fixed"
/>
                  </div>
                </td>
                <td>
                   <div className="d-flex gap-1">
  <button
    className="custom-edit-button"
    onClick={() => handleAddRowBelow(index)}
  >
     <AddIcon fontSize="small" />
  </button>
  <button
      className="custom-edit-button"
      onClick={() => handleRemoveRow(index)}
      disabled={excelColumns.length === 1} // Prevent removing last row
    >
     <RemoveIcon fontSize="small" />
    </button>
    </div>
</td>

              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  </div>
)}
 <div className="clientNameSelect row">
                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={GenerateQuery}
                  >
                    Parse Query
                  </button>
                </div>
              </div>
  <div className="accordion-body">
              <div className="tableBorderBox pt-3">
                <span>
                  <h5 className="fontWeight-600 fontSize14 colorBlack">
                    {TableQuery}
                  </h5>
                </span>
              </div>
            </div>
              {showSubmitConfig && (
              <div className="text-center btnsBtm">
                <button
                  className="btnPrimaryOutline"
                  onClick={handleCancel} // Define this function
                >
                  Cancel
                </button>
                {isEditMode ? (
          <button className="btnPrimary ms-2" onClick={handleUpdate}>
            Update
          </button>
        ) : (
          <button className="btnPrimary ms-2" onClick={handleSubmit}>
            Submit
          </button>
        )}
              </div>
        )}
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};
export default ExcelFileConfigMainWindow;
