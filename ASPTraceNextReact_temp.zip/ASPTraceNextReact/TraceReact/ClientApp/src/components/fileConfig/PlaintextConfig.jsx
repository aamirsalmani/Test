﻿import React from "react";
import { useSelector } from "react-redux";
import SidebarMain from "../common/SidebarMain";
import PlaintextMainWindow from "./PlaintextMainWindow";
import "./spreadsheetConfig.css";

const PlaintextConfig = () => {
    
    return (
        <div className="mainView">
            {/* <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                <PlaintextMainWindow />
            {/* </div> */}
        </div>
    );
};

export default PlaintextConfig;