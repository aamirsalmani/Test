﻿import React, { useState, useEffect, useMemo } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import Select from "react-select";
import MaximusAxios from "../common/apiURL";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";

import resetDropDown from "../../images/common/Reset.svg";
import CaseComponent from "./CaseComponent";
import { useSelector } from "react-redux";
import Delete from "../../images/common/redDelete.svg";


const PlaintextMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const { state } = useLocation();

  const navigate = useNavigate();

  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [ClientAdd, setClientAdd] = useState(null);

  const [fileConfigID, setFileConfigID] = useState(null);

  const [PlaintextDataTable, setPlaintextDataTable] = useState([]);

  const [XMLcolumns, setXMLColumns] = useState([]);

  const [optionsColumnsList, setoptionsColumnsList] = useState([]);

  const [aliasColumnsList, setAliasColumnsList] = useState([]);

  const [FileType, setFileType] = useState(null);

  const [TableName, setTableName] = useState(null);

  const [FileConfigData, setFileConfigData] = useState(null);

  const [TableQuery, setTableQuery] = useState(null);

  const [isDisabled, setIsDisabled] = useState(false);

  const [selectedText, setSelectedText] = useState("");
  const [selectionStart, setSelectionStart] = useState(null);
  const [selectionEnd, setSelectionEnd] = useState(null);

  const [isShowQuery, setShowQuery] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  const [ColumnEditID, setColumnEditID] = useState(null);

  const [MappedColumns, setMappedColumns] = useState(null);

  const customStyles = {
    control: (provided, state) => ({
      ...provided,
      width: "200px", // Set the desired width here
    }),
  };

  const renderTooltipShow = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to open window
    </Tooltip>
  );

  useEffect(() => {
    if (state !== null) {
      setFileConfigID(state.id);
      if (state.id > 0) {
        fetchFileData(state.id);
      }
    }
  }, [ClientAdd]);

  const renderTooltipAdd = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to add new Column
    </Tooltip>
  );

  const renderTooltipDelete = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to Remove
    </Tooltip>
  );

  const handleTextSelection = () => {
    const text = window.getSelection().toString();
    const selection = window.getSelection();
    if (text) {
      setSelectedText(text);
      setSelectionStart(selection.anchorOffset + 1);
      setSelectionEnd(selection.focusOffset);
    }
  };

  const selectionLength =
    selectionEnd !== null && selectionStart !== null
      ? Math.abs(selectionEnd - (selectionStart - 1))
      : null;

  const fetchFileData = (fileConfigIDValue) => {
    setIsLoading(true);

    MaximusAxios.get(
      "/api/DynamicFileConfig/GetPlaintextWithoutSeparatorDataTable?FileConfigID=" +
        fileConfigIDValue,
      { mode: "cors" }
    )
      .then((TableData) => {
        //console.log(TableData.data);
        if (TableData.data !== null && TableData.data !== undefined) {
          //console.log(TableData.data);
          //setPlaintextDataTable(TableData.data);
          const columns = JSON.parse(TableData.data.fileColumnString);
          const rows = [
            TableData.data.firstRow,
            TableData.data.secondRow,
            TableData.data.thirdRow,
            TableData.data.fourthRow,
            TableData.data.fifthRow,
          ];

          // Function to create an array of JSON objects
          const createJsonObjectArray = (columns, rows) => {
            return rows
              .filter((row) => row !== null) // Exclude null rows
              .map((row) => {
                const values = JSON.parse(row); // Parse each row
                return columns.reduce((obj, column, index) => {
                  obj[column] = values[index]; // Map each value to its corresponding column
                  return obj;
                }, {});
              });
          };

          // Creating the JSON object array
          const jsonObjectArray = createJsonObjectArray(columns, rows);
          setPlaintextDataTable(jsonObjectArray);

          //console.log(jsonObjectArray);

          MaximusAxios.get(
            "/api/DynamicFileConfig/GetConfiguredColumnString?FileConfigID=" +
              fileConfigIDValue,
            { mode: "cors" }
          )
            .then((XMLData) => {
              console.log("XMLData.data")
              console.log( XMLData.data);
              console.log (JSON.parse(XMLData.data.configuredXMLColumnString))
              if (XMLData.data !== null && XMLData.data !== undefined) {
                if (
                  XMLData.data.configuredXMLColumnString !== null &&
                  XMLData.data.configuredXMLColumnString !== undefined &&
                  XMLData.data.configuredXMLColumnString.length > 0
                ) {
                  setXMLColumns(
                    JSON.parse(XMLData.data.configuredXMLColumnString)
                  );
                  setIsDisabled(false);
                } else {
                  setXMLColumns([]);
                  setIsDisabled(false);
                }

                if (
                  XMLData.data.configuredRawColumnString !== null &&
                  XMLData.data.configuredRawColumnString !== undefined &&
                  XMLData.data.configuredRawColumnString.length > 0
                ) {
                  setAliasColumnsList(
                    JSON.parse(XMLData.data.configuredRawColumnString)
                  );
                  setIsDisabled(true);
                  setShowQuery(true);
                  //console.log(JSON.parse(XMLData.data.configuredRawColumnString));
                }
              } else {
                setXMLColumns([]);
                setIsDisabled(false);
              }

            //  console.log("XMLcolumns"+XMLcolumns)
            }
          )
            .catch(function (error) {
              if (error.response) {
                console.log(error.response.data);
              }
            });

          MaximusAxios.get(
            "/api/DynamicFileConfig/GetXMLSchemaColumn?FileConfigID=" +
              fileConfigIDValue,
            { mode: "cors" }
          )
            .then((AliasData) => {
              //console.log(AliasData.data);

              if (AliasData.data !== null && AliasData.data !== undefined) {
                setoptionsColumnsList(AliasData.data);

                MaximusAxios.get(
                  "/api/DynamicFileConfig/GetFileConfigData?FileConfigID=" +
                    fileConfigIDValue,
                  { mode: "cors" }
                )
                  .then((FileConfigData) => {
                    if (
                      FileConfigData.data !== null &&
                      FileConfigData.data !== undefined
                    ) {
                      setIsLoading(false);
                      //console.log(FileConfigData.data);
                      setFileType(FileConfigData.data.fileType);
                      setTableName(FileConfigData.data.tableName);
                      setFileConfigData(FileConfigData.data);
                    } else {
                      setIsLoading(false);
                    }
                  })
                  .catch(function (error) {
                    if (error.response) {
                      console.log(error.response.data);
                    }
                    setIsLoading(false);
                  });
              } else {
                setIsLoading(false);
              }
            })
            .catch(function (error) {
              if (error.response) {
                console.log(error.response.data);
              }
              setIsLoading(false);
            });
        } else {
          setIsLoading(false);
          alert("No Data Found");
        }
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
        alert("Error Occurred");
      });
  };

  const onNext = () => {
    if (
      XMLcolumns === null ||
      XMLcolumns === undefined ||
      XMLcolumns.length === 0
    ) {
      alert("Please do the mapping!");
      return false;
    }

    const arrayJsonString = JSON.stringify(XMLcolumns);

    const data = new FormData();

    data.append("FileConfigID", fileConfigID);
    data.append("MappedColumnString", arrayJsonString);

    setShowQuery(false);
    setIsLoading(true);

    MaximusAxios.post("api/DynamicFileConfig/UpdateMappedColumn", data, {
      mode: "cors",
    }).then(
      (res) => {
        if (res.data !== undefined && res.data !== null) {
          MaximusAxios.get(
            "/api/DynamicFileConfig/GetDynamicRawTableColumns?FileConfigID=" +
              fileConfigID,
            { mode: "cors" }
          )
            .then((ColumnData) => {
              //console.log(ColumnData.data);
              //console.log(XMLcolumns)

              if (ColumnData.data !== null && ColumnData.data !== undefined) {
                ColumnData.data.forEach((crow) => {
                  XMLcolumns.filter(({ TxtLength }) => TxtLength > 0).forEach(
                    (xrow) => {
                      if (crow.columnID === xrow.ColumnID) {
                        crow.position = xrow.StartPosition;
                        crow.length = xrow.TxtLength;
                        crow.columnValue = xrow.ColumnValue;
                        crow.dataColumn = xrow.MappedColumn;
                        crow.isChanged = true;
                      }
                    }
                  );
                });

                setAliasColumnsList(ColumnData.data);
                setIsDisabled(true);
                setTableQuery("");
                setShowQuery(true);
              }
              setIsLoading(false);
            })
            .catch(function (error) {
              if (error.response) {
                console.log(error.response.data);
              }
              setIsLoading(false);
            });
        } else {
          setIsLoading(false);
        }
      },
      (error) => {
        setIsLoading(false);
        console.log(error);
      }
    );

    //console.log(XMLcolumns);
    //console.log(arrayJsonString);
  };

  const onClickAdd = () => {
    if (selectionStart === null || selectionStart === undefined) {
      alert("Please select Text!");
      return false;
    }

    if (selectionLength === null || selectionLength === undefined) {
      alert("Please select Text!");
      return false;
    }

    if (selectedItem === undefined || selectedItem === null) {
      alert("Please select column");
      return false;
    }

    if (selectionLength < 0) {
      alert("Length can not be 0");
      return false;
    }

    let AlreadyAdded = false;

    if (XMLcolumns !== null && XMLcolumns !== undefined) {
      if (XMLcolumns.length === 0) {
        setXMLColumns([
          {
            MappedColumn: selectedItem.label,
            StartPosition: selectionStart,
            TxtLength: selectionLength,
            ColumnID: selectedItem.value,
            ColumnValue: selectedText,
          },
        ]);
      } else {
        let tempColumns = [...XMLcolumns].map((item, i) => {
          if (item.ColumnID === selectedItem.value) {
            AlreadyAdded = true;

            item.MappedColumn = selectedItem.label;
            item.ColumnID = selectedItem.value;
            item.StartPosition = selectionStart;
            item.TxtLength = selectionLength;
            item.ColumnValue = selectedText;

            return item;
          } else {
            return item;
          }
        });

        setXMLColumns(tempColumns);

        setSelectionStart(null);
        setSelectionEnd(null);

        if (!AlreadyAdded) {
          const newObject = {
            MappedColumn: selectedItem.label,
            StartPosition: selectionStart,
            TxtLength: selectionLength,
            ColumnID: selectedItem.value,
            ColumnValue: selectedText,
          };

          setXMLColumns([...XMLcolumns, newObject]);
        }
      }

      setSelectedItem(null);
    }

    if (AlreadyAdded) {
      alert(selectedItem.label + " start position updated");
    }
  };

  const onDeleteClick = (columnID) => {
    if (columnID !== null && columnID !== undefined) {
      const newArray = XMLcolumns.filter((obj) => obj.ColumnID !== columnID);
      setXMLColumns(newArray);
    }
  };

  const onResetColumnSelection = (e) => {
    e.preventDefault();
    setXMLColumns([]);
    alert("Column selection removed successfully");
  };

  const [hideModal, showModal] = useState(false);

  const [CaseStatementValue, setCaseStatementValue] = useState("");

  const [isShowCaseModal, setShowCaseModal] = useState(false);

  const [selectedColumnID, setSelectedColumnID] = useState(false);

  const AddCaseStatement = () => {
    let TempData = aliasColumnsList.map((item) => {
      if (item.columnID === selectedColumnID) {
        item.caseCondition = CaseStatementValue;
        item.isChanged = true;
        return item;
      } else {
        return item;
      }
    });

    setAliasColumnsList(TempData);

    showModal(false);
  };

  const onResetRaw = (e) => {
    e.preventDefault();
    setIsLoading(true);

    MaximusAxios.get(
      "/api/DynamicFileConfig/GetRawTableSelectedColumns?FileConfigID=" +
        fileConfigID,
      { mode: "cors" }
    )
      .then((ColumnData) => {
        //console.log(ColumnData.data); 
        if (ColumnData.data !== null && ColumnData.data !== undefined) {
          ColumnData.data.forEach((crow) => {
            XMLcolumns.filter(({ TxtLength }) => TxtLength > 0).forEach(
              (xrow) => {
                if (crow.columnID === xrow.ColumnID) {
                  crow.position = xrow.StartPosition;
                  crow.length = xrow.TxtLength;
                  crow.dataColumn = xrow.MappedColumn;
                  crow.columnValue = xrow.ColumnValue;
                  crow.isChanged = true;
                }
              }
            );
          });

          setAliasColumnsList(ColumnData.data);
          setIsDisabled(true);
          setTableQuery("");
          setShowQuery(true);
        }
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });

    alert("Column mapping removed successfully");
  };

  const onResetAll = (e) => {
    e.preventDefault();
    setIsLoading(true);
    setIsDisabled(false);
    setShowQuery(false);

    setXMLColumns([]);
    setAliasColumnsList([]);

    setIsLoading(false);

    alert("Column mapping removed successfully");
  };

  const ChangeDataColumn = (ID, value) => {
    let filterColumn = XMLcolumns.filter(
      (item, i) => item.MappedColumn === value.label
    );

    let TempData = aliasColumnsList.map((item) => {
      if (item.columnID === ID) {
        item.dataColumn = filterColumn[0].MappedColumn;
        item.columnValue = filterColumn[0].ColumnValue;
        item.position = filterColumn[0].StartPosition;
        item.length = filterColumn[0].TxtLength;
        item.isChanged = true;
        return item;
      } else {
        return item;
      }
    });

    setAliasColumnsList(TempData);

  };

  const onEditClick = (editColumnID) => {
    setSelectedColumnID(editColumnID);
    setCaseStatementValue("");
    setShowCaseModal(true);
    setColumnEditID({ ID: editColumnID, CaseCondition: "" });
    setMappedColumns(XMLcolumns.filter((item, i) => item.TxtLength > 0));
  };

  const GenerateQuery = () => {
    const RawJsonString = JSON.stringify(aliasColumnsList);
    const data = new FormData();
    data.append("MappedColumnString", RawJsonString);
    data.append("FileConfigID", fileConfigID);

    setIsLoading(true);

    MaximusAxios.post("api/DynamicFileConfig/ParseQuery", data, {
      mode: "cors",
    })
      .then((res) => {
        // then print response status
        setIsLoading(false);
        //console.log(res.data);
        if (res.data !== undefined && res.data !== null) {
          alert(res.data);
        }
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
        alert("Error occurred");
      });

    BuildQuery();
  };

  const BuildQuery = () => {
    let sqlQuery = "Select ";

    //console.log(aliasColumnsList);

    aliasColumnsList.forEach((row, rowIndex) => {
      //console.log(row);
      if (row.isChanged) {
        if (
          row.caseCondition !== null &&
          row.caseCondition !== undefined &&
          row.caseCondition.length > 0
        ) {
          sqlQuery += row.caseCondition + ", ";
        } else if (
          row.dataColumn !== null &&
          row.dataColumn !== undefined &&
          row.dataColumn === row.aliasColumn
        ) {
          sqlQuery += row.dataColumn + ", ";
        } else if (
          row.dataColumn !== null &&
          row.dataColumn !== undefined &&
          row.dataColumn !== row.aliasColumn
        ) {
          sqlQuery += row.dataColumn + " as " + row.aliasColumn + ", ";
        }
      }
    });

    sqlQuery = sqlQuery.slice(0, -2);

    sqlQuery += " From {" + TableName + "}";

    //console.log(sqlQuery);

    setTableQuery(sqlQuery);
  };

  const onFinalSubmit = () => {
    setIsLoading(true);

    const MappedJsonString = JSON.stringify(XMLcolumns);

    const RawJsonString = JSON.stringify(aliasColumnsList);

    const data = new FormData();

    data.append("FileConfigID", fileConfigID);
    data.append("XMLString", "");
    data.append("QueryString", "");
    data.append("RawColumnString", RawJsonString);
    data.append("MappedColumnString", MappedJsonString);

    MaximusAxios.post("api/DynamicFileConfig/UpdateXMLString", data, {
      mode: "cors",
    })
      .then((res) => {
        // then print response status
        setIsLoading(false);
        //console.log(res.data);
        if (res.data !== undefined && res.data !== null) {
          alert(res.data);
        }
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
        alert("Error occurred");
      });
  };

  const btnCaseSubmit = () => {
    let { ID, CaseCondition } = ColumnEditID;

    if (ID !== undefined && ID !== null) {
      setAliasColumnsList(
        aliasColumnsList.map((item) => {
          if (item.columnID === ID) {
            item.caseCondition = CaseCondition;
            item.isChanged = true;
            return item;
          } else {
            return item;
          }
        })
      );
    }

    setShowCaseModal(false);
  };

  const onImgClick = (colID, ddlID) => {
    let TempData = aliasColumnsList.map((item) => {
      if (item.columnID === colID) {
        item.dataColumn = "";
        item.columnValue = "";
        item.length = 0;
        item.position = 0;
        item.isChanged = false;
        return item;
      } else {
        return item;
      }
    });

    setAliasColumnsList(TempData);
  };

  console.log("aliasColumnsList");
  console.log(aliasColumnsList);

  return (
    <div className="configLeft identificationContainer">
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Dynamic File Configuration
        </h5>
        <span className="fontWeight-600 colorBlack">
          {" "}
          File Type ({FileType}){" "}
        </span>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">File Configuration</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Plaintext Config</p>
        </div>
      </div>
      <div className="configLeftTop">
        <div className="accordion" id="unmatchedFilters">
          <div className="accordion-item">
            <div className="accordion-header">
              <h6 className="fontWeight-600 colorBlack">Config Details</h6>
              {(FileConfigData === null || FileConfigData.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
              <div>
                <hr />
                {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
                {FileConfigData && (
                  <div>
                    <div className="configSelectBoxTop row">
                      <div className="clientNameSelect col">
                        <label>
                          <b>Client Name :</b>
                        </label>
                        <label>&nbsp;{FileConfigData.clientName}</label>
                      </div>
                      <div className="clientNameSelect col">
                        <label>
                          <b>Log Type :</b>
                        </label>
                        <label>&nbsp;{FileConfigData.tableName}</label>
                      </div>
                      <div className="clientNameSelect col">
                        <label>
                          <b>Channel Name :</b>
                        </label>
                        <label>&nbsp;{FileConfigData.channelName}</label>
                      </div>
                      <div className="clientNameSelect col">
                        <label>
                          <b>Mode :</b>
                        </label>
                        <label>&nbsp;{FileConfigData.transactionMode}</label>
                      </div>
                    </div>
                    <div className="configSelectBoxTop row">
                      <div className="clientNameSelect col">
                        <label>
                          <b>Splitter Type :</b>
                        </label>
                        <label>&nbsp;{FileConfigData.splitterType}</label>
                      </div>
                      <div className="clientNameSelect col">
                        <label>
                          <b>Vendor :</b>
                        </label>
                        <label>&nbsp;{FileConfigData.vendorName}</label>
                      </div>
                      <div className="clientNameSelect col">
                        <label>
                          <b>File Name :</b>
                        </label>
                        <label>&nbsp;{FileConfigData.originalFileName}</label>
                      </div>
                      <div className="clientNameSelect col">
                        <label> &nbsp;&nbsp;</label>
                        <label> &nbsp;&nbsp;</label>
                      </div>
                    </div>
                  </div>
                )}
                </>
            )}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Bottom Content */}
      <div className="configLeftBottom">
        <div className="accordion-body">
          <h5 className="fontWeight-600 fontSize14 colorBlack ">
            XML Column Mapping{" "}
          </h5>
          <div className="hrGreyLine"></div>
          <div className="tableBorderBox pt-3">
            <div className="w-100 table-responsive">
              <div className="table-responsive tableContentBox">
                {PlaintextDataTable.map((row, index) => (
                  <pre
                    className="txtSelectionField"
                    key={index}
                    onMouseUp={handleTextSelection}
                  >
                    {row.lineData}
                  </pre>
                ))}
              </div>
            </div>
            <div className="configSelectBoxTop row">
              <div className="clientNameSelect col">
                <label htmlFor="txtStart">Start Position</label>
                <input
                  id="txtStart"
                  type="text"
                  value={selectionStart !== null ? `${selectionStart}` : ""}
                  readOnly
                  style={{ height: "31px", width: "100%" }}
                />
              </div>
              <div className="clientNameSelect col">
                <label htmlFor="txtLength">Length</label>
                <input
                  id="txtLength"
                  type="text"
                  value={selectionLength !== null ? `${selectionLength}` : ""}
                  readOnly
                  style={{ height: "31px", width: "100%" }}
                />
              </div>
              <div className="clientNameSelect col">
                <label htmlFor="txtEndPosition">End Position</label>
                <input
                  id="txtEndPosition"
                  type="text"
                  value={selectionEnd !== null ? `${selectionEnd}` : ""}
                  readOnly
                  style={{ height: "31px", width: "100%" }}
                />
              </div>
              <div className="clientNameSelect col">
                <label htmlFor="ddlXMLColumns">Column</label>
                <Select
                  id="ddlXMLColumns"
                  value={selectedItem}
                  classNamePrefix="reactSelectBox"
                  options={optionsColumnsList.map((x) => ({
                    value: x.columnID,
                    label: x.aliasColumn,
                  }))}
                  onChange={(value) => setSelectedItem(value)}
                />
              </div>
              <div className="text-center btnsBtm">
                <button
                  type="button"
                  className="btnPrimary ms-2 "
                  onClick={onClickAdd}
                >
                  Add
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="configLeftBottom">
        <div>
          {PlaintextDataTable && (
            <div className="accordion-body">
              <div className="tableBorderBox pt-3">
                <div className="w-100 table-responsive pt-3">
                  <div className="table-responsive tablePlainTextBox">
                    <table
                      id="gvConfig"
                      className="recontable table-striped table-hover table-borderless align-middle w-100"
                    >
                      <thead>
                        <tr>
                          <th scope="col" style={{ width: "105px" }}>
                            Sr. No.
                          </th>
                          <th scope="col">Mapped Column</th>
                          <th scope="col" style={{ width: "155px" }}>
                            Start Position
                          </th>
                          <th scope="col" style={{ width: "155px" }}>
                            Length
                          </th>
                          <th scope="col">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {XMLcolumns.map((p, indexp) => {
                          return (
                            <tr key={indexp}>
                              <td>{indexp + 1}</td>
                              <td>{p.MappedColumn}</td>
                              <td>{p.StartPosition}</td>
                              <td>{p.TxtLength}</td>
                              <td>
                                {" "}
                                <OverlayTrigger
                                  placement="top"
                                  delay={{ show: 250, hide: 400 }}
                                  overlay={renderTooltipDelete}
                                >
                                  <button
                                    className="iconButtonBox"
                                    onClick={() => onDeleteClick(p.ColumnID)}
                                  >
                                    <img
                                      src={Delete}
                                      alt="Remove"
                                      title="Remove"
                                    />
                                  </button>
                                </OverlayTrigger>{" "}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
                {!isShowQuery ? (
                  <div className="text-center btnsBtm">
                    <button
                      type="button"
                      className="btnPrimaryOutline"
                      onClick={(e) => onResetColumnSelection(e)}
                    >
                      Reset
                    </button>
                    <button
                      type="button"
                      className="btnPrimary ms-2"
                      onClick={onNext}
                    >
                      Next
                    </button>
                  </div>
                ) : null}
              </div>
            </div>
          )}
        </div>

        {isShowQuery ? (
          <div>
            <div className="accordion-body pt-3">
              <h5 className="fontWeight-600 fontSize14 colorBlack">
                Raw Table Column Mapping
              </h5>
              <div className="hrGreyLine"></div>

              <div className="tableBorderBox pt-3">
                <div
                  className="w-100 table-responsive"
                  style={{ maxHeight: "18.7rem", overflowY: "auto" }}
                >
                  <table
                    id="gvRawColumnGrid"
                    className="recontable table-striped table-hover table-borderless align-middle w-100"
                  >
                    <thead
                      style={{
                        position: "sticky",
                        top: 0,
                        backgroundColor: "white",
                        zIndex: 1,
                      }}
                    >
                      <tr>
                        <th scope="col">Alias Column</th>
                        <th scope="col" style={{ width: "215px" }}>
                          Data Column
                        </th>
                        <th scope="col" style={{ width: "25px" }}></th>
                        <th scope="col">Data</th>
                        <th scope="col">Case Statement</th>
                        <th scope="col">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {aliasColumnsList.map((p, index) => (
                        <tr key={index} style={{ height: "45px" }}>
                          <td>{p.aliasColumn}</td>
                          <td>
                            <div className="clientNameSelect">
                            <Select
                                id={"ddlRawcolumn" + index}
                                value={
                                  p.columnValue !== ""
                                    ? {
                                        value: p.columnID,
                                        label: p.dataColumn,
                                      }
                                    : { value: 0, label: "select" }
                                }
                                classNamePrefix="reactSelectBox"
                                options={XMLcolumns.filter(
                                  ({ TxtLength }) => TxtLength > 0
                                ).map((x) => ({
                                  value: x.ColumnID,
                                  label: x.MappedColumn,
                                }))}
                                onChange={(value) =>
                                  ChangeDataColumn(p.columnID, value)
                                }
                                styles={customStyles}
                              />
                            </div>
                          </td>
                          <td>
                            <button
                              type="button"
                              className="iconRemoveButtonBox"
                              onClick={() =>
                                onImgClick(p.columnID, "ddlRawcolumn" + index)
                              }
                            >
                              <img
                                src={resetDropDown}
                                alt="Unmapped"
                                title="Unmapped"
                              />
                            </button>
                          </td>
                          <td>{p.dataValue}</td>
                          <td>{p.caseCondition}</td>
                          <td>
                            <OverlayTrigger
                              placement="top"
                              delay={{ show: 250, hide: 400 }}
                              overlay={renderTooltipShow}
                            >
                              <button
                                className="editBox"
                                onClick={() => onEditClick(p.columnID)}
                              >
                                <u>Edit</u>
                              </button>
                            </OverlayTrigger>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="clientNameSelect row">
                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline mb-2"
                    onClick={onResetAll}
                  >
                    Reset All
                  </button>

                  <button
                    type="button"
                    className="btnPrimaryOutline ms-2 mb-2"
                    onClick={onResetRaw}
                  >
                    Reset Raw Table
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={GenerateQuery}
                  >
                    Parse Query
                  </button>
                </div>
              </div>
            </div>
            <div className="accordion-body">
              <div className="tableBorderBox pt-3">
                <span>
                  <h5 className="fontWeight-600 fontSize14 colorBlack">
                    {TableQuery}
                  </h5>
                </span>
              </div>
            </div>

            <div className="clientNameSelect row">
              <div className="text-center btnsBtm">
                <button
                  type="button"
                  className="btnPrimary ms-2"
                  onClick={onFinalSubmit}
                >
                  Submit
                </button>
              </div>
            </div>
          </div>
        ) : null}
      </div>
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />

      {hideModal && (
        <Modal
          show={hideModal}
          onHide={() => showModal(!hideModal)}
          centered
          className="defaultThemeModal saveFiltersModal reportTableModal"
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              Case Statement
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="text-center">
            <input
              type="text"
              name="txtCaseStatement"
              id="txtCaseStatement"
              placeholder="Enter Case Statement"
              className="inputTextBox"
              onChange={(e) => setCaseStatementValue(e.target.value)}
              value={CaseStatementValue}
              style={{
                width: "90%",
                height: "50px !important",
                marginTop: "20px",
              }}
            />
          </Modal.Body>
          <Modal.Footer>
            <button
              type="button"
              className="btnPrimary ms-2"
              onClick={AddCaseStatement}
            >
              Submit
            </button>
          </Modal.Footer>
        </Modal>
      )}

      {isShowCaseModal && (
        <Modal
          show={isShowCaseModal}
          onHide={() => setShowCaseModal(!isShowCaseModal)}
          centered
          size="xl"
          className="CaseConditionModal"
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              <span>Modification Panel</span>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="CaseConditionControl">
              <CaseComponent
                Tabledata={aliasColumnsList}
                Optionsdata={MappedColumns}
                UpdateColumnID={ColumnEditID}
                UpdateColumnIDFn={setColumnEditID}
              />
            </div>
          </Modal.Body>
          <Modal.Footer>
            <button
              type="button"
              className="btnPrimary ms-2"
              onClick={() => {
                btnCaseSubmit(ColumnEditID);
              }}
            >
              Submit
            </button>
          </Modal.Footer>
        </Modal>
      )}
    </div>
  );
};

export default PlaintextMainWindow;
