﻿import React from "react";
import { useSelector } from "react-redux";
import SidebarMain from "../common/SidebarMain"; 
import SpreadsheetConfigMainWindow from "./SpreadsheetConfigMainWindow";
import "./spreadsheetConfig.css";

const Spreadsheet = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                <SpreadsheetConfigMainWindow />
            {/* </div> */}
        </div>
    );
};

export default Spreadsheet;