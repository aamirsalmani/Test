﻿import React from "react";
// Components
import SidebarMain from "../common/SidebarMain";
import FileConfigurationMainWindow from "./FileConfigurationMainWindow";

const FileConfig = () => {
    return (
        <div className="mainView">
            <FileConfigurationMainWindow />
        </div>
    );
};

export default FileConfig;
