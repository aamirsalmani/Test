﻿import React, { useState } from "react";
import { useSelector } from "react-redux";
import Select from "react-select";
import { Tooltip } from "react-bootstrap";
import { Link } from "react-router-dom";  
import AsyncSelect  from 'react-select/async';
import "datatables.net-dt/js/dataTables.dataTables"



import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
import MaximusAxios from "../common/apiURL" ;


const FileTypeOptions = [
    { value: "0", label: "--Select--" },
    { value: "1", label: "Spreadsheet" },
    { value: "2", label: "Plaintext" },
    { value: "3", label: "Plaintext With Separator" }
];

const SeparatorTypeOptions = [
    { value: "0", label: "--Select--" },
    { value: "|", label: "|" },
    { value: "||", label: "||" },
    { value: "@", label: "@" }, 
    { value: "%", label: "%" },
    { value: ",", label: "," },
    { value: ":", label: ":" },
    { value: "!", label: "!" },
];


const FileConfigurationMainWindow = () => {   

    const currentUser = useSelector((state) => state.authReducer);

    const fetchClientData = (inputValue) => {  
        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => { 
            if (inputValue.length === 0) { 
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            } 
        }).catch(function (error) {
            console.log(error.response);
        });
    } 
 
    const [OptionsClient, setClientOptions] = useState([{ clientID: "0", clientName: "--Select--" }]); 

    const [showFilters, setShowFilters] = useState(false);


    const [inputValue, setValue] = useState('0');
    const [selectedClientValue, setSelectedClientValue] = useState(null);

    const [optionsLogType, setOptionsLogTypeValue] = useState([{ id: "0", vendorType: "--Select--" }]);
    const [selectedLogValue, setSelectedLogValue] = useState(null);

    const [optionsChannelType, setOptionsChannelTypeValue] = useState([{ channelID: "0", channelName: "--Select--" }]);
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);

    const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "--Select--" }]);
    const [selectedModeValue, setSelectedModeValue] = useState(null);

    const [optionsFileExtention, setOptionsFileExtentionValue] = useState([{ ID: "0", FileType: "--Select--" }]); 
    const [selectedFileExtentionValue, setSelectedFileExtentionValue] = useState(null);
   
    const [selectedFileTypeValue, setSelectedFileTypeValue] = useState(null); 

    const [textboxFilePrefix, setTextBoxFilePrefixValue] = useState('');  

    const [optionsVendor, setOptionsVendorValue] = useState([{ vendorID: "0", vendorName: "--Select--" }]);
    const [selectedVendorValue, setSelectedVendorValue] = useState(null);

    const [FileConfiguration, setFileConfiguration] = useState(null);

    const [optionsSeparatorType, setOptionsSeparatorType] = useState(SeparatorTypeOptions);  

    const [FileFormatActive, setFileFormatActive] = useState(null);

    const [FileFormatHistory, setFileFormatHistory] = useState(null);

    const [FormatDescription, setFormatDescription] = useState(null); 
    
    const [selectedSeparatorType, setSelectedSeparatorTypeValue] = useState(null); 

    const [selectedOtherClientValue, setSelectedOtherClientValue] = useState(null);

    const [XMLValue, setXMLValue] = useState(null);
    
    const handleInputChange = value => {
        setValue(value);
    };


    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }


    const handleClientChange = value => {

        setSelectedClientValue(value);
        setSelectedChannelValue(null);
        setClientOptions([]); 

        if (value.clientID !== '0') {

            MaximusAxios.get('api/FileConFig/GetLogTypeFileConfigList?ClientId=' + value.clientID, {  mode: 'cors' }).then(result => {
                setOptionsLogTypeValue(result.data);
            });

            MaximusAxios.get('api/FileConFig/GetChannelFileConfigList?ClientId=' + value.clientID, {  mode: 'cors' }).then(result => {
                setOptionsChannelTypeValue(result.data);
            });

            return MaximusAxios.get('api/FileConFig/GetConfiguredFormatFileConfigList?ClientID=' + value.clientID, {  mode: 'cors' }).then(result => {
                setFileConfiguration(result.data);
            });
        }
    }


    const handleLogTypeChange = value => { 

        setSelectedLogValue(value);

        if (value.value !== '0' && selectedClientValue.clientID !== '0') { 
            return MaximusAxios.get('api/FileConfig/GetVendorFileConfigList?ClientID=' + selectedClientValue.clientID + '&VendorType=' + value.value, {  mode: 'cors' }).then(result => {
                setOptionsVendorValue(result.data);
            });
        }
    }  

    const handleChannelChange = value => {
        setSelectedChannelValue(value);
        setSelectedModeValue(null);

        if (value.value !== '0' && selectedClientValue.clientID !== '0') {
            return MaximusAxios.get('api/FileConfig/GetModeFileConfigList?ClientID=' + selectedClientValue.clientID + '&ChannelID=' + value.value, {  mode: 'cors' }).then(result => {
                setOptionsModeTypeValue(result.data);
            });
        }
    }

    const handleModeChange = value => {
        setSelectedModeValue(value);
    } 

    const handleFileExtentionChange = value => {
        setSelectedFileExtentionValue(value);
    };


    const handleFileTypeChange = value => {

        setClientOptions([]);
        setSelectedFileTypeValue(value);

        if (value.value === '1') {
            setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".xls", FileType: ".xls" }, { ID: "2", FileType: ".csv" }]);
            setOptionsSeparatorType([{ value: "0", label: "--Select--" }]);
        }
        else if (value.value === '2') {
            setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".txt", FileType: ".txt" }, { ID: ".RC", FileType: ".RC" }]);
            setOptionsSeparatorType([{ value: "0", label: "--Select--" }]);
        }
        else if (value.value === '3') {
            setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".txt", FileType: ".txt" }]);
            setOptionsSeparatorType(SeparatorTypeOptions);
        }


        let VendorId = 0;

        if (selectedVendorValue === undefined || selectedVendorValue === null) {
            VendorId = 0;
        }
        else {
            VendorId = selectedVendorValue.value;
        }

        let ModeId = 0;

        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }
        
        setSelectedOtherClientValue({ label: "--Select--", value: "0" });
        setSelectedSeparatorTypeValue({ label: "--Select--", value: "0" });   
        setSelectedVendorValue({ label: "--Select--", value: "0" });
        setSelectedFileExtentionValue({ label: "--Select--", value: "0" });

        $('#lblBankName').html('');
        $('#lblFormatNo').html('');
        $('#lblFormatType').html('');
        $('#CutOffTime').val('');
        $('#StartLineNo').val('');
        $('#EndLineNo').val('');

        if (selectedLogValue.value !== '4' && selectedLogValue.value !== '0') {
            MaximusAxios.get('api/FileConFig/GetFileFormatActiveFileConfigList?VendorType=' + selectedLogValue.value + '&ClientID=' + selectedClientValue.clientID + '&ChannelID=' + selectedChannelValue.value + '&ModeID=' + ModeId + '&VendorID=' + VendorId, {  mode: 'cors' }).then(result => {                

                if (result.data !== null) {
                   
                    $('#lblBankName').html(result.data.fileFormatActiveFileConfigModel.clientName);
                    $('#lblFormatNo').html(result.data.fileFormatActiveFileConfigModel.formatID);
                    $('#lblFormatType').html(result.data.fileFormatActiveFileConfigModel.formatStatus === 'Active' ? 'Current' : 'History' );
                    $('#CutOffTime').val(result.data.fileFormatActiveFileConfigModel.cutOffTime);
                    $('#StartLineNo').val(result.data.fileFormatActiveFileConfigModel.startIndex);
                    $('#EndLineNo').val(result.data.fileFormatActiveFileConfigModel.endIndex);

                    setFileFormatActive(result.data.fileFormatConfigModelList);       

                    setXMLValue(result.data.fileFormatActiveFileConfigModel.FormatDescriptionXml);
                   
                    fillClientData();
                    setSelectedOtherClientValue({ label: selectedClientValue.clientName, value: selectedClientValue.clientID });
                    setSelectedVendorValue({ label: result.data.fileFormatActiveFileConfigModel.vendorName, value: result.data.fileFormatActiveFileConfigModel.vendorID });

                    if (result.data.fileFormatActiveFileConfigModel.separatorType === null && result.data.fileFormatActiveFileConfigModel.separatorType.length > 0 ) {
                        setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".txt", FileType: ".txt" }]);
                        setOptionsSeparatorType(SeparatorTypeOptions);
                        setSelectedFileTypeValue({ value: "3", label: "Plaintext With Separator" });
                    }
                    else {
                        if (result.data.fileFormatActiveFileConfigModel.fileExtention === '.xls' || result.data.fileFormatActiveFileConfigModel.fileExtention === '.csv') {
                            setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".xls", FileType: ".xls" }, { ID: ".csv", FileType: ".csv" }]);
                            setOptionsSeparatorType([{ value: "0", label: "--Select--" }]);
                            setSelectedFileTypeValue({ value: "1", label: "Spreadsheet" });
                        }
                        else if (result.data.fileFormatActiveFileConfigModel.fileExtention === '.txt' || result.data.fileFormatActiveFileConfigModel.fileExtention === '.RC') {
                            setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".txt", FileType: ".txt" }, { ID: ".RC", FileType: ".RC" }]);
                            setOptionsSeparatorType([{ value: "0", label: "--Select--" }]);
                            setSelectedFileTypeValue({ value: "2", label: "Plaintext" });
                        }                          
                    }

                    setSelectedFileExtentionValue({ label: result.data.fileFormatActiveFileConfigModel.fileExtention, value: result.data.fileFormatActiveFileConfigModel.fileExtention });
                }

            });

            MaximusAxios.get('api/FileConFig/GetFileFormatHistoryFileConfigList?VendorType=' + selectedLogValue.value + '&ClientID=' + selectedClientValue.clientID + '&ChannelID=' + selectedChannelValue.value + '&ModeID=' + ModeId + '&VendorID=' + VendorId, {  mode: 'cors' }).then(result2 => {
                setFileFormatHistory(result2.data);
            }); 

            
        }  
     
    };


    const fillClientData = () => {
        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            setClientOptions(result.data);
        });
    }

    const handleVendorChange = value => {

        setSelectedVendorValue(value);

        if (textboxFilePrefix === null || textboxFilePrefix.length === 0) {
            alert('Please enter file prefix.');
        }
        else {
            if (value.value !== '0') {

                let ModeId = 0;

                if (selectedModeValue === undefined || selectedModeValue === null) {
                    ModeId = 0;
                }
                else {
                    ModeId = selectedModeValue.value;
                }

                let FileExtention = 0;

                if (selectedFileExtentionValue === undefined || selectedFileExtentionValue === null) {
                    FileExtention = 0;
                }
                else {
                    FileExtention = selectedFileExtentionValue.value;
                }

                let SeparatorType = '';

                if (selectedSeparatorType === undefined || selectedSeparatorType === null) {
                    SeparatorType = '';
                }
                else {
                    SeparatorType = selectedSeparatorType.value;
                }

                $('#lblBankName').html('');
                $('#lblFormatNo').html('');
                $('#lblFormatType').html('');
                $('#CutOffTime').val('');
                $('#StartLineNo').val('');
                $('#EndLineNo').val('');

                MaximusAxios.get('api/FileConFig/GetFileFormatFileConfig?ClientID=' + selectedClientValue.clientID + '&ChannelID=' + selectedChannelValue.value + '&ModeID=' + ModeId + '&VendorID=' + value.value + '&FileExt=' + FileExtention + '&SeparatorType=' + SeparatorType + '&FilePrefix=' + textboxFilePrefix, {  mode: 'cors' }).then(result => {

                    if (result.data !== null) {

                        $('#lblBankName').html(result.data.fileFormatActiveFileConfigModel.clientName);
                        $('#lblFormatNo').html(result.data.fileFormatActiveFileConfigModel.formatID);
                        $('#lblFormatType').html(result.data.fileFormatActiveFileConfigModel.formatStatus === 'Active' ? 'Current' : 'History');
                        $('#CutOffTime').val(result.data.fileFormatActiveFileConfigModel.cutOffTime);
                        $('#StartLineNo').val(result.data.fileFormatActiveFileConfigModel.startIndex);
                        $('#EndLineNo').val(result.data.fileFormatActiveFileConfigModel.endIndex);

                        setFileFormatActive(result.data.fileFormatConfigModelList);

                        setXMLValue(result.data.fileFormatActiveFileConfigModel.FormatDescriptionXml);

                        fillClientData();
                        setSelectedOtherClientValue({ label: selectedClientValue.clientName, value: selectedClientValue.clientID });
                        setSelectedVendorValue({ label: result.data.fileFormatActiveFileConfigModel.vendorName, value: result.data.fileFormatActiveFileConfigModel.vendorID });

                        if (result.data.fileFormatActiveFileConfigModel.separatorType === null && result.data.fileFormatActiveFileConfigModel.separatorType.length > 0) {
                            setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".txt", FileType: ".txt" }]);
                            setOptionsSeparatorType(SeparatorTypeOptions);
                            setSelectedFileTypeValue({ value: "3", label: "Plaintext With Separator" });
                        }
                        else {
                            if (result.data.fileFormatActiveFileConfigModel.fileExtention === '.xls' || result.data.fileFormatActiveFileConfigModel.fileExtention === '.csv') {
                                setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".xls", FileType: ".xls" }, { ID: ".csv", FileType: ".csv" }]);
                                setOptionsSeparatorType([{ value: "0", label: "--Select--" }]);
                                setSelectedFileTypeValue({ value: "1", label: "Spreadsheet" });
                            }
                            else if (result.data.fileFormatActiveFileConfigModel.fileExtention === '.txt' || result.data.fileFormatActiveFileConfigModel.fileExtention === '.RC') {
                                setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".txt", FileType: ".txt" }, { ID: ".RC", FileType: ".RC" }]);
                                setOptionsSeparatorType([{ value: "0", label: "--Select--" }]);
                                setSelectedFileTypeValue({ value: "2", label: "Plaintext" });
                            }
                        }

                        setSelectedFileExtentionValue({ label: result.data.fileFormatActiveFileConfigModel.fileExtention, value: result.data.fileFormatActiveFileConfigModel.fileExtention });
                    }
                    else {
                        MaximusAxios.get('api/FileConFig/GetFileFormatDefualtFileConfig?FileExt=' + FileExtention + '&SeparatorType=' + SeparatorType + '&ChannelID=' + selectedChannelValue.value + '&ModeID=' + ModeId + '&VendorID=' + value.value, {  mode: 'cors' }).then(result => {
                           
                            if (result.data !== null) {

                                $('#lblBankName').html("MAXIMUS INFOWARE PVT.LTD");
                                $('#lblFormatNo').html("0");
                                $('#lblFormatType').html("DEFUALT");

                                setFileFormatActive(result.data.fileFormatConfigModelList);

                                setXMLValue(result.data.fileFormatActiveFileConfigModel.FormatDescriptionXml);

                                fillClientData();
                                setSelectedOtherClientValue({ label: selectedClientValue.clientName, value: selectedClientValue.clientID });
                                setSelectedVendorValue({ label: result.data.fileFormatActiveFileConfigModel.vendorName, value: result.data.fileFormatActiveFileConfigModel.vendorID });

                                if (result.data.fileFormatActiveFileConfigModel.separatorType === null && result.data.fileFormatActiveFileConfigModel.separatorType.length > 0) {
                                    setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".txt", FileType: ".txt" }]);
                                    setOptionsSeparatorType(SeparatorTypeOptions);
                                    setSelectedFileTypeValue({ value: "3", label: "Plaintext With Separator" });
                                }
                                else {
                                    if (result.data.fileFormatActiveFileConfigModel.fileExtention === '.xls' || result.data.fileFormatActiveFileConfigModel.fileExtention === '.csv') {
                                        setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".xls", FileType: ".xls" }, { ID: ".csv", FileType: ".csv" }]);
                                        setOptionsSeparatorType([{ value: "0", label: "--Select--" }]);
                                        setSelectedFileTypeValue({ value: "1", label: "Spreadsheet" });
                                    }
                                    else if (result.data.fileFormatActiveFileConfigModel.fileExtention === '.txt' || result.data.fileFormatActiveFileConfigModel.fileExtention === '.RC') {
                                        setOptionsFileExtentionValue([{ ID: "0", FileType: "--Select--" }, { ID: ".txt", FileType: ".txt" }, { ID: ".RC", FileType: ".RC" }]);
                                        setOptionsSeparatorType([{ value: "0", label: "--Select--" }]);
                                        setSelectedFileTypeValue({ value: "2", label: "Plaintext" });
                                    }
                                }

                                setSelectedFileExtentionValue({ label: result.data.fileFormatActiveFileConfigModel.fileExtention, value: result.data.fileFormatActiveFileConfigModel.fileExtention });
                            }
                        });
                    }
                });

                MaximusAxios.get('api/FileConFig/GetFileFormatHistoryFileConfigList?VendorType=' + selectedLogValue.value + '&ClientID=' + selectedClientValue.clientID + '&ChannelID=' + selectedChannelValue.value + '&ModeID=' + ModeId + '&VendorID=' + value.value, {  mode: 'cors' }).then(result2 => {
                    setFileFormatHistory(result2.data);
                });

            }
        }
    }

    const handleFilePrefixChange = event => { setTextBoxFilePrefixValue(event.target.value); }

    const [textboxStartLineValue, setTextBoxStartLineValue] = useState('');  

    const handleStartLineChange = event => { setTextBoxStartLineValue(event.target.value); }

    const [textboxEndLineValue, setTextBoxEndLineValue] = useState('');  

    const handleEndLineChange = event => { setTextBoxEndLineValue(event.target.value); }

    const [textboxCutOffTimeValue, setTextBoxCutOffTimeValue] = useState('');  

    const handleCutOffTimeChange = event => { setTextBoxCutOffTimeValue(event.target.value); } 

    const handleSeparatorTypeChange = (value) => {
        setSelectedSeparatorTypeValue(value);
    };  

    const handleInputChangeXML = (e, index) => {
        const { name, value } = e.target; 
    }

    $(document).ready(function () {

        if (FileConfiguration !== null && FileConfiguration.length > 0) {
            $('#FileConfiguration').DataTable();
        }
    }); 

    $(document).ready(function () {

        if (FormatDescription !== null && FormatDescription.length > 0) {
            $('#FormatDescription').DataTable();
        }
    }); 

    const handleSubmit = (e) => {

        if (currentUser !== null && currentUser.user !== null) {

            e.preventDefault();

            console.log(e);
            console.log('You clicked submit.');

            if (selectedOtherClientValue === null || selectedOtherClientValue.clientID === 0) {
                alert("Please select client!");
                return false;
            }

            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                alert("Please select Channel!");
                return false;
            }

            if (selectedLogValue === undefined || selectedLogValue === null) {
                alert("Please select Log Type!");
                return false;
            }

            if (selectedFileExtentionValue === undefined || selectedFileExtentionValue === null) {
                alert("Please select File Extention!");
                return false;
            }

            let ModeId = 0;

            if (selectedModeValue === undefined || selectedModeValue === null) {
                ModeId = 0;
            }
            else {
                ModeId = selectedModeValue.value;
            }

            let FileExtention = 0;

            if (selectedFileExtentionValue === undefined || selectedFileExtentionValue === null) {
                FileExtention = 0;
            }
            else {
                FileExtention = selectedFileExtentionValue.value;
            }

            let SeparatorType = '';

            if (selectedSeparatorType === undefined || selectedSeparatorType === null) {
                SeparatorType = '';
            }
            else {
                SeparatorType = selectedSeparatorType.value;
            }

            const data = new FormData();

            data.append("ClientID", selectedOtherClientValue.clientID);
            data.append("VendorID", selectedVendorValue.value);
            data.append("FileExtention", FileExtention);
            data.append("FormatDescriptionXml", XMLValue);
            data.append("CutOffTime", textboxCutOffTimeValue);
            data.append("User", currentUser.user.username);
            data.append("FilePrefix", textboxFilePrefix);
            data.append("VendorType", selectedLogValue.value);
            data.append("ChannelID", selectedChannelValue.value);
            data.append("ModeID", ModeId);
            data.append("SeparatorType", SeparatorType);
            data.append("StartIndex", textboxStartLineValue);
            data.append("EndIndex", textboxEndLineValue);


            MaximusAxios.post('api/FileConfig/InsertFileFormat', data, {
                
            }, {  mode: 'cors' })
                .then((res) => {
                    setFileConfiguration(res.data);
                    alert('File Format Save Successfully.');
                }, error => {
                    alert(error);
                });
        }
        else {
            alert('Session Timeout');
        }
    };
     
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        
            <div
                className={
                    company.sidebarOpen
                        ? "mainWindow configMainContent d-flex justify-content-between sidebarOpened"
                        : "mainWindow configMainContent d-flex justify-content-between sidebarClosed"
                }
            >

          
            <div className="configLeft">
                {/* Config Left Top */}
                <div className="configLeftTop">
                    <div className="configLeftHead d-flex justify-content-between align-items-center">
                        <h5 className="fontWeight-600 fileConfigHead colorBlack">
                            File Configuration
          </h5>
                        <div className="d-flex align-items-center breadCrumbLeft">
                            <Link to="/">
                                <p className="fontSize12 colorPrimaryDefault">Home</p>
                            </Link>
                            <span>
                                <svg
                                    width="10"
                                    height="16"
                                    viewBox="0 0 10 16"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    className="mx-1"
                                >
                                    <path
                                        d="M3 4L7 8L3 12"
                                        stroke="black"
                                        strokeWidth="1.5"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        className="breadcrumbIcon"
                                    />
                                </svg>
                            </span>
                                <p className="fontSize12 colorPrimaryDefault">Configuration</p>
                            <span>
                                <svg
                                    width="10"
                                    height="16"
                                    viewBox="0 0 10 16"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    className="mx-1"
                                >
                                    <path
                                        d="M3 4L7 8L3 12"
                                        stroke="black"
                                        strokeWidth="1.5"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        className="breadcrumbIcon"
                                    />
                                </svg>
                            </span>
                                <p className="fontSize12">File Configuration</p>
                        </div>
                    </div> 
   
                    <div className="position-relative">
                        <div className={showFilters ? "lightBlueBox configTopBlueBox absoluteFiltersBox" : "lightBlueBox configTopBlueBox"  }    >
                            <div className="d-flex justify-content-between align-items-center configLeftFilters">
                                <h6 className="fontWeight-600 colorBlack">Filters</h6>
                              
                                {
                                    showFilters ? (
                                        <button
                                            type="button"
                                            className="allFiltersBtn"
                                            onClick={() => setShowFilters(false)}
                                        >
                                            <span>
                                                <svg
                                                    width="24"
                                                    height="24"
                                                    viewBox="0 0 24 24"
                                                    fill="none"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                >
                                                    <path
                                                        d="M6 6L18 18"
                                                        stroke="#004BBD"
                                                        strokeWidth="1.8"
                                                        strokeLinecap="round"
                                                    />
                                                    <path
                                                        d="M18 6L6 18"
                                                        stroke="#004BBD"
                                                        strokeWidth="1.8"
                                                        strokeLinecap="round"
                                                    />
                                                </svg>
                                            </span>
                                        </button>
                                    )
                                        : (

                    <button
                        type="button"
                        className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                        onClick={() => setShowFilters(true)}
                    >
                        <span className="icon-Filter-Icon"></span>
                        <span className="ms-1 fontSize12-m colorPrimaryDefault">
                            All Filters
                    
                </span>
                    </button>
                    )      }
                            </div>
                            <div className="hrGreyLine"></div>
                            <div className="configSelectBoxTop">
                                <div className="row">
                                <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedClientValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                </div>
                                <div className="clientNameSelect col" id="dvTxnType">
                                        <label htmlFor="ddllogType">Log Type</label>
                                        <span className="text-danger font-size13">*</span>
                                    <Select
                                        defaultValue={selectedLogValue}
                                        options={optionsLogType.map(x => (
                                            {
                                                value: x.id,
                                                label: x.vendorType
                                            }
                                        ))}
                                        id="ddllogType"
                                        onChange={handleLogTypeChange}
                                        classNamePrefix="reactSelectBox"
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlChannel"
                                        value={selectedChannelValue}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsChannelType.map(x => (
                                            {
                                                value: x.channelID,
                                                label: x.channelName
                                            }
                                        ))}
                                        onChange={handleChannelChange}
                                    />
                                </div>
                                <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                    <Select
                                        id="ddlMode"
                                        value={selectedModeValue}
                                        classNamePrefix="reactSelectBox"
                                        options={optionsModeType.map(x => (
                                            {
                                                value: x.modeID,
                                                label: x.modeName
                                            }
                                        ))}
                                        onChange={handleModeChange}
                                    />
                                </div>
</div>
                                {showFilters ? (
                                    <div className="row">
                                        <div className="clientNameSelect col">
                                            <label htmlFor="ddlFileType">File Type</label>
                                            <Select
                                                id="ddlFileType"
                                                value={selectedFileTypeValue}
                                                classNamePrefix="reactSelectBox"
                                                options={FileTypeOptions}
                                                onChange={handleFileTypeChange}>
                                            </Select>
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="ddlFileExt">File Extention</label>
                                            <Select
                                                id="ddlFileExt"
                                                value={selectedFileExtentionValue}
                                                classNamePrefix="reactSelectBox" 
                                                options={optionsFileExtention.map(x => (
                                                    {
                                                        value: x.ID,
                                                        label: x.FileType
                                                    }
                                                ))}
                                                onChange={handleFileExtentionChange}
                                            > 
                                            </Select>
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="FilePrefix">File Prefix</label>
                                            <input
                                                type="text"
                                                name="FilePrefix"
                                                id="FilePrefix"
                                                value={textboxFilePrefix}
                                                className="inputTextBox"
                                                onChange={handleFilePrefixChange}

                                            />
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="ddlseparator">Separator Type</label>
                                            <Select
                                                id="ddlseparator" 
                                                value={selectedSeparatorType}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsSeparatorType}
                                                onChange={handleSeparatorTypeChange}
                                            > 
                                            </Select>
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="ddlVendor">Vendor</label>
                                            <span className="text-danger font-size13">*</span>
                                            <Select
                                                id="ddlVendor"
                                                value={selectedVendorValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsVendor.map(x => (
                                                    {
                                                        value: x.vendorID,
                                                        label: x.vendorName
                                                    }
                                                ))}
                                                onChange={handleVendorChange}
                                            />
                                        </div>
                                       
                                        <div className="clientNameSelect col">
                                            <label htmlFor="CutOffTime">Cut Off Time</label>
                                            <input
                                                type="text"
                                                name="CutOffTime"
                                                id="CutOffTime"
                                                className="inputTextBox"
                                                placeholder="HH:MM"
                                                onChange={handleCutOffTimeChange}
                                            />
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="StartLineNo">Start Line No.</label>
                                            <input
                                                type="number"
                                                name="StartLineNo"
                                                id="StartLineNo"
                                                className="inputTextBox"
                                                onChange={handleStartLineChange}
                                            />
                                        </div>
                                        <div className="clientNameSelect col">
                                            <label htmlFor="EndLineNo">End Line No.</label>
                                            <input
                                                type="number"
                                                name="EndLineNo"
                                                id="EndLineNo"
                                                className="inputTextBox"
                                                onChange={handleEndLineChange}
                                            />
                                        </div>
                                    </div>
                                ) : null}
                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={(e) => handleSubmit(e)}
                                    >
                                        Save
              </button>
                                </div>
                            </div>                            
                        </div>

                       

                  
                    </div>
                </div>

                {/* Config Left Bottom */}
                <div className={showFilters ? "configLeftBottom configLeftBottomMargin" : "configLeftBottom"}>
                    <div className="configBottomHeadingBox">
                        <h6 className="fontWeight-600 colorBlack">Configured Format</h6>
                    </div>
                    {FileConfiguration && (
                        <div className="tableBorderBox">
                            {/* Table */}
                            <div className="w-100 table-responsive">

                                <div className="table-responsive" >

                                    <table id="FileConfiguration" className="table table-striped table-hover table-bordered"  >
                                        <thead>
                                            <tr>
                                                <th scope="col">Client Name</th>
                                                <th scope="col">Log Type</th>
                                                <th scope="col">Channel</th>
                                                <th scope="col">FilePrefix</th>
                                                <th scope="col">Mode</th>
                                                <th scope="col">VendorName</th>
                                                <th scope="col">FileExtention</th>
                                                <th scope="col">CutOffTime</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                FileConfiguration.map((p, index) => {
                                                    return <tr key={index}>
                                                        <td >{p.clientName}</td>
                                                        <td >{p.logType}</td>
                                                        <td >{p.channel}</td>
                                                        <td >{p.filePrefix}</td>
                                                        <td >{p.mode}</td>
                                                        <td >{p.vendorName}</td>
                                                        <td >{p.fileExtention}</td>
                                                        <td >{p.cutOffTime}</td>
                                                    </tr>
                                                })
                                            }
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    )
                    }
                </div>
            </div>

            <div className="configRight">
                {/* Config Left Top */}
                <div className="configLeftTop">
                    {/* BreadCrumb */}
                    <div className="configRightHead d-flex align-items-center justify-content-end">
                        <div className="d-flex align-items-center">
                            <Link to="/">
                                <p className="fontSize12 colorPrimaryDefault">Home</p>
                            </Link>
                            <span>
                                <svg
                                    width="8"
                                    height="100%"
                                    viewBox="0 0 10 16"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    className="mx-1"
                                >
                                    <path
                                        d="M3 4L7 8L3 12"
                                        stroke="black"
                                        strokeWidth="1.5"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        className="breadcrumbIcon"
                                    />
                                </svg>
                            </span>
                            <Link to="/">
                                <p className="fontSize12 colorPrimaryDefault">Configuration</p>
                            </Link>
                            <span>
                                <svg
                                    width="8"
                                    height="100%"
                                    viewBox="0 0 10 16"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                    className="mx-1"
                                >
                                    <path
                                        d="M3 4L7 8L3 12"
                                        stroke="black"
                                        strokeWidth="1.5"
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        className="breadcrumbIcon"
                                    />
                                </svg>
                            </span>
                            <Link to="/">
                                <p className="fontSize12">File Configuration</p>
                            </Link>
                        </div>
                    </div>

                    <div className="lightBlueBox configTopBlueBoxRight">
                        <div className="d-flex mb-12">
                            <label className="configDotLeftContent fontSize14" id="lblBank" >Client Name : </label> 
                            <label className="configDotRightContent fontSize14-m" id="lblBankName" ></label>
                            
                        </div>

                        <div className="d-flex mb-12">
                            <label className="configDotLeftContent fontSize14" id="lblFormat" >Format No. : </label> 
                            <label className="configDotRightContent fontSize14-m" id="lblFormatNo"  ></label>
                        </div>

                        <div className="d-flex mb-12">
                            <label className="configDotLeftContent fontSize14" id="lblFormatT" >Format Type : </label> 
                            <label className="configDotRightContent fontSize14-m" id="lblFormatType" ></label>
                        </div>

                        <div className="d-flex">
                            <label className="configDotLeftContent fontSize14" id="lblOtherClient">Format set to other client : </label> 
                            <div className="configDotRightContent">
                                <div className="clientNameSelect">
                                    <Select 
                                        id="ddlOtherClient" 
                                        options={OptionsClient.map(x => (
                                            {
                                                value: x.clientID,
                                                label: x.clientName
                                            }
                                        ))}
                                        value={selectedOtherClientValue}
                                        classNamePrefix="reactSelectBox"
                                    >
                                    </Select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="configBottomHeadingBoxRight configBottomHeadingBox"></div>

                {/*  Bottom Content */}
                <div className="configLeftBottom configRightBottom">
                    {/* Table */}
                    {FileFormatActive && (
                        <div className="tableBorderBox "> 
                            <div className="table-responsive tableContentBox">
                                <table className="table table-striped table-hover table-borderless align-middle configTableRight">
                                    <thead>
                                        <tr>
                                            <th scope="col">Field Name</th>
                                            <th scope="col">Start Position</th>
                                            <th scope="col">Field Length</th>
                                            <th scope="col">Position</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            FileFormatActive.map((row, i) => {
                                                return <tr key={i}>
                                                    <td >{row.fieldName}</td>
                                                    <td> <input
                                                        id={"txtStartPosition_" + i}
                                                        name="startPosition"
                                                        style={{ width: "70px" }}
                                                        value={row.startPosition}
                                                        onChange={(e) => handleInputChangeXML(e, i)}
                                                    />
                                                    </td>
                                                    <td> <input
                                                        id={"txtLength_" + i}
                                                        name="length"
                                                        style={{ width: "70px" }}
                                                        value={row.length}
                                                        onChange={(e) => handleInputChangeXML(e, i)}
                                                    />
                                                    </td>
                                                    <td> <input
                                                        id={"txtPosition_" + i}
                                                        name="position"
                                                        style={{ width: "50px" }}
                                                        value={row.position}
                                                        onChange={(e) => handleInputChangeXML(e, i)}
                                                    />
                                                    </td>
                                                </tr>
                                            })
                                        }

                                    </tbody>

                                </table>
                            </div> 
                        </div>
                    )
                    }
                </div>
            </div>
        </div>
    );
};

export default FileConfigurationMainWindow;
