﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
import "./forceSettlement.css";
// Components
import SidebarMain from "../common/SidebarMain";
import ForceSettlementMainWindow from "./ForceSettlementMainWindow";

const ForceSettlement = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <ForceSettlementMainWindow />
        </div>
    );
};

export default ForceSettlement;
