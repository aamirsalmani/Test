﻿import React, { useState } from "react";
import Select from "react-select";
import { Link } from "react-router-dom";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import AsyncSelect from "react-select/async";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import MaximusAxios from "../common/apiURL";

import "datatables.net-dt/js/dataTables.dataTables";
import $ from "jquery";
import "jquery/dist/jquery.min.js";
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";

import { useSelector } from "react-redux";

const optionsSettlementType = [
  { value: "1", label: "Successful" },
  { value: "2", label: "Reversal" },
  { value: "3", label: "Partial Reversal" },
  { value: "4", label: "Unsuccessful" },
];

const ForceSettlementMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  $(document).ready(function () {
    $("#select_all").on("click", function () {
      if (this.checked) {
        $(".inputCheckBoxGrid").each(function () {
          this.checked = true;
        });
      } else {
        $(".inputCheckBoxGrid").each(function () {
          this.checked = false;
        });
      }
    });

    $(".inputCheckBox").on("click", function () {
      if (
        $(".inputCheckBoxGrid:checked").length ===
        $(".inputCheckBoxGrid").length
      ) {
        $("#select_all").prop("checked", true);
      } else {
        $("#select_all").prop("checked", false);
      }
    });
  });

  const [inputValue1, setValue1] = useState("0");

  const fetchClientData = (inputValue) => {
    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  const handleInputChange = (value) => {
    setValue(value);
  };

  const fetchStatusData = (inputValue1) => {
    return MaximusAxios.get(
      "/api/ForceSettlement/GetStatusMasterForceSettlementList",
      { mode: "cors" }
    ).then((result) => {
      if (inputValue1.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.statusName.toLowerCase().includes(inputValue1.toLowerCase())
        );
      }
    });
  };

  const handleInputChange1 = (value) => {
    setValue1(value);
  };

  const renderTooltipShow = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to Force Settle
    </Tooltip>
  );

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const [ForceSettlement, setForceSettlement] = useState(null);

  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [selectedGLStatusValue, setSelectedGLStatusValue] = useState(null);
  const [selectedSWStatusValue, setSelectedSWStatusValue] = useState(null);
  const [selectedNWStatusValue, setSelectedNWStatusValue] = useState(null);
  const [selectedEJStatusValue, setSelectedEJStatusValue] = useState(null);

  const [selectedSettlementTypeValue, setSelectedSettlementTypeValue] =
    useState(null);
  const [selectedReconTypeValue, setSelectedReconTypeValue] = useState(null);

  const handleReconTypeChange = (value) => {
    setSelectedReconTypeValue(value);
  };

  const handleGLStatusChange = (value) => {
    setSelectedGLStatusValue(value);
  };

  const handleSWStatusChange = (value) => {
    setSelectedSWStatusValue(value);
  };

  const handleNWStatusChange = (value) => {
    setSelectedNWStatusValue(value);
  };

  const handleEJStatusChange = (value) => {
    setSelectedEJStatusValue(value);
  };

  const handleSettlementTypeChange = (value) => {
    setSelectedSettlementTypeValue(value);
  };

  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);

  const [settleDate, setSettleDate] = useState(new Date());

  const [inputValue, setValue] = useState("0");
  const [selectedValue, setSelectedValue] = useState(null);

  const [optionsChannelType, setOptionsChannelTypeValue] = useState([
    { channelID: "0", channelName: "Select " },
  ]);
  const [selectedChannelValue, setSelectedChannelValue] = useState(null);

  const [optionsModeType, setOptionsModeTypeValue] = useState([
    { modeID: "0", modeName: "Select " },
  ]);
  const [selectedModeValue, setSelectedModeValue] = useState(null);

  const handleOptionsChannelType = (value) => {
    setOptionsChannelTypeValue(value);
  };

  const handleOptionsModeType = (value) => {
    setOptionsModeTypeValue(value);
  };

  const [isGLChecked, setIsGLChecked] = useState(false);
  const [isSWChecked, setIsSWChecked] = useState(false);
  const [isNWChecked, setIsNWChecked] = useState(false);
  const [isEJChecked, setIsEJChecked] = useState(false);

  const [IsCheckedAll, setIsCheckedAll] = useState(false);

  const [isNWStatus, setIsNWStatus] = useState(true);
  const [isEJStatus, setIsEJStatus] = useState(true);

  const handleGLChecked = () => {
    setIsGLChecked(!isGLChecked);
  };

  const handleSWChecked = () => {
    setIsSWChecked(!isSWChecked);
  };

  const handleNWChecked = () => {
    setIsNWChecked(!isNWChecked);
  };

  const handleEJChecked = () => {
    setIsEJChecked(!isEJChecked);
  };

  const handleClientChange = (value) => {
    setSelectedValue(value);
    setSelectedChannelValue(null);

    if (value.clientID !== "0") {
      return MaximusAxios.get(
        "/api/Common/GetChannelOptionList?ClientId=" +
          value.clientID +
          "&UserID=" +
          currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsChannelType(result.data);
      });
    }
  };

  const handleChannelChange = (value) => {
    setSelectedChannelValue(value);
    setSelectedModeValue(null);

    if (value.value !== "0" && selectedValue.clientID !== "0") {
      return MaximusAxios.get(
        "/api/Common/GetModeOptionList?ClientID=" +
          selectedValue.clientID +
          "&ChannelID=" +
          value.value +
          "&UserID=" +
          currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsModeType(result.data);
      });
    }
  };

  const handleModeChange = (value) => {
    setForceSettlement(null);

    setSelectedModeValue(value);

    setIsEJStatus(true);
    setIsNWStatus(true);

    if (value.value === "1" || value.value === "3" || value.value === "4") {
      setOptionsReconTypeValue([
        { value: "1", label: "2-Way" },
        { value: "2", label: "3-Way" },
      ]);

      if (value.value === "1") {
        setIsNWStatus(false);
      } else {
        setIsEJStatus(false);
      }
    } else {
      setOptionsReconTypeValue([
        { value: "1", label: "2-Way" },
        { value: "2", label: "3-Way" },
        { value: "3", label: "4-Way" },
      ]);
    }

    setSelectedSettlementTypeValue([]);
    setSelectedReconTypeValue([]);
  };

  const [optionsReconType, setOptionsReconTypeValue] = useState([]);

  const [selectedChannelId, setSelectedChannelId] = useState(null);

  const setStartDateValue = (value) => {
    setStartDate(value);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
  };

  const SearchAllClick = () => {
    setIsGLChecked(false);
    setIsNWChecked(false);
    setIsSWChecked(false);
    setIsEJChecked(false);
    setIsCheckedAll(!IsCheckedAll);
  };

  const formatDate = (date) => {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

  const [isShowUnmatchedModal, setShowUnmatchedModal] = useState(false);

  $(document).ready(function () {
    if (ForceSettlement !== null && ForceSettlement.length > 0) {
      $("#gvForceSettlement").DataTable({
        order: [[1, "asc"]],
        bDestroy: true,
        columnDefs: [{ orderable: false, targets: [0] }],
      });
    }
  });

  const onShowClick = () => {
    setForceSettlement(null);

    if (selectedValue === null || selectedValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      alert("Please select Channel!");
      return false;
    }

    if (selectedModeValue === undefined || selectedModeValue === null) {
      alert("Please select Mode!");
      return false;
    }

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let ChannelId = 0;

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      ChannelId = 0;
    } else {
      ChannelId = selectedChannelValue.value;
    }

    let ModeId = 0;

    if (selectedModeValue === undefined || selectedModeValue === null) {
      ModeId = 0;
    } else {
      ModeId = selectedModeValue.value;
    }

    let GLStatus = 0;
    let EJStatus = 0;
    let NWStatus = 0;
    let SWStatus = 0;

    if (IsCheckedAll) {
      GLStatus = 0;
      EJStatus = 0;
      NWStatus = 0;
      SWStatus = 0;
    } else {
      if (
        isGLChecked &&
        selectedGLStatusValue !== undefined &&
        selectedGLStatusValue !== null
      ) {
        GLStatus = selectedGLStatusValue.statusID;
      }

      if (
        isEJChecked &&
        selectedEJStatusValue !== undefined &&
        selectedEJStatusValue !== null
      ) {
        EJStatus = selectedEJStatusValue.statusID;
      }

      if (
        isNWChecked &&
        selectedNWStatusValue !== undefined &&
        selectedNWStatusValue !== null
      ) {
        NWStatus = selectedNWStatusValue.statusID;
      }

      if (
        isSWChecked &&
        selectedSWStatusValue !== undefined &&
        selectedSWStatusValue !== null
      ) {
        SWStatus = selectedSWStatusValue.statusID;
      }
    }

    setIsLoading(true);

    MaximusAxios.post(
      "/api/ForceSettlement/GetClientForceSettlementDetailsList",
      {
        ClientID: selectedValue.clientID,
        ChannelID: ChannelId,
        ModeID: ModeId,
        FromDateTxns: formatDate(startDate),
        ToDateTxns: formatDate(endDate),
        GLStatus: String(GLStatus),
        EJStatus: String(EJStatus),
        NWStatus: String(NWStatus),
        SWStatus: String(SWStatus),
        User: currentUser.user.username,
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setForceSettlement(response.data);
        setIsLoading(false);
        setSelectedChannelId(ChannelId);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "",
            alertMessage: "No records found",
          });
        }
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
          //setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: error.response.data });
        }
        setIsLoading(false);
      });
  };

  const [UnmatchedTxnId, setUnmatchedTxnIds] = useState("");

  const [SettledReason, setReasonSettled] = useState("");

  const ShowModal = () => {
    let UnmatchedTxnIds = "";
    let i = 0;
    $(".inputCheckBoxGrid:checked").each(function () {
      if (this.checked) {
        if (i === 0) UnmatchedTxnIds = UnmatchedTxnIds + this.id;
        else UnmatchedTxnIds = UnmatchedTxnIds + "," + this.id;
        i++;
      }
    });

    if (UnmatchedTxnIds.length === 0) {
      setUnmatchedTxnIds("");
      setShowUnmatchedModal(false);
      alert("Please select atleast one");
      return false;
    } else {
      setUnmatchedTxnIds(UnmatchedTxnIds);
      setShowUnmatchedModal(true);
    }

    setSelectedSettlementTypeValue([]);
    setSelectedReconTypeValue([]);
    setReasonSettled("");
    setSettleDate(new Date());
  };

  const onForceClick = () => {
    if (
      UnmatchedTxnId === undefined ||
      UnmatchedTxnId === null ||
      UnmatchedTxnId.length === 0
    ) {
      alert("Please select atleast one transaction!");
      return false;
    }

    if (settleDate === undefined || settleDate === null) {
      alert("Please enter Settled Date!");
      return false;
    }

    if (SettledReason === undefined || SettledReason === null) {
      alert("Please enter Settled Reason!");
      return false;
    }

    if (
      selectedSettlementTypeValue === undefined ||
      selectedSettlementTypeValue === null
    ) {
      alert("Please select Settlement Type!");
      return false;
    }

    if (
      selectedReconTypeValue === undefined ||
      selectedReconTypeValue === null
    ) {
      alert("Please select Recon Type!");
      return false;
    }

    let reconType = "";

    if (
      selectedReconTypeValue === undefined ||
      selectedReconTypeValue === null
    ) {
      reconType = "";
    } else {
      reconType = selectedReconTypeValue.label;
    }

    let settlementType = "";

    if (
      selectedSettlementTypeValue === undefined ||
      selectedSettlementTypeValue === null
    ) {
      settlementType = "";
    } else {
      settlementType = selectedSettlementTypeValue.label;
    }

    setIsLoading(true);

    MaximusAxios.post(
      "/api/ForceSettlement/InsertForceSettlementDetails",
      {
        UnmatchedTxnIds: UnmatchedTxnId,
        SettledDate: settleDate,
        SettledReason: SettledReason,
        ReconType: reconType,
        SettlementType: settlementType,
        ChannelID: selectedChannelId,
        UserName: currentUser.user.username,
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setShowUnmatchedModal(false);
        setUnmatchedTxnIds("");
        setForceSettlement(null);
        setIsLoading(false);

        if (response.data === null || response.data === "Save") {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "",
            alertMessage: "Transactions Settled Successfully.",
          });
        }
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: error.response.data,
          });
        }

        setShowUnmatchedModal(false);
        setUnmatchedTxnIds("");
        setForceSettlement(null);
        setIsLoading(false);
      });
  };

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 colorBlack fileConfigHead">
          Force Settlement Txns
        </h5>

        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Configuration</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Force Settlement</p>
        </div>
      </div>

      {/* Top Content */}
      <div className="configLeftTop">
        <div className="accordion" id="onlineCbrEntryTop">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="forcesettledHeadingOne"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="d-flex justify-content-center align-items-center allFiltersBtn btn p-0 "
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#forcesettledCollapseOne"
                aria-expanded="true"
                aria-controls="forcesettledCollapseOne"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="forcesettledCollapseOne"
              className="accordion-collapse collapse show"
              aria-labelledby="forcesettledHeadingOne"
              data-bs-parent="#onlineCbrEntryTop"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      onChange={handleChannelChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlMode">Mode Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlMode"
                      value={selectedModeValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsModeType.map((x) => ({
                        value: x.modeID,
                        label: x.modeName,
                      }))}
                      onChange={handleModeChange}
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="forcesettledDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="forcesettledDate"
                      maxDate={new Date()}
                    />
                  </div>
                </div>
                <div className="configSelectBoxTop row">
                  {!IsCheckedAll && (
                    <React.Fragment>
                      <div className="clientNameSelect col">
                        <label>GL Status</label>
                        <input
                          type="checkbox"
                          name="GLStatus"
                          id="GLStatus"
                          className="inputCheckBox ms-2"
                          checked={isGLChecked}
                          onChange={handleGLChecked}
                        />
                        {isGLChecked && (
                          <AsyncSelect
                            cacheOptions
                            defaultOptions
                            value={selectedGLStatusValue}
                            getOptionLabel={(e) => e.statusName}
                            getOptionValue={(e) => e.statusID}
                            loadOptions={fetchStatusData}
                            onInputChange={handleInputChange1}
                            onChange={handleGLStatusChange}
                            id="ddlGLStatus"
                          />
                        )}
                      </div>
                      <div className="clientNameSelect col">
                        <label>SW Status</label>
                        <input
                          type="checkbox"
                          name="SWStatus"
                          id="SWStatus"
                          className="inputCheckBox ms-2"
                          checked={isSWChecked}
                          onChange={handleSWChecked}
                        />
                        {isSWChecked && (
                          <AsyncSelect
                            cacheOptions
                            defaultOptions
                            value={selectedSWStatusValue}
                            getOptionLabel={(e) => e.statusName}
                            getOptionValue={(e) => e.statusID}
                            loadOptions={fetchStatusData}
                            onInputChange={handleInputChange1}
                            onChange={handleSWStatusChange}
                            id="ddlSWStatus"
                          />
                        )}
                      </div>
                      {isNWStatus && (
                        <div className="clientNameSelect col">
                          <label>NW Status</label>
                          <input
                            type="checkbox"
                            name="NWStatus"
                            id="NWStatus"
                            className="inputCheckBox ms-2"
                            checked={isNWChecked}
                            onChange={handleNWChecked}
                          />
                          {isNWChecked && (
                            <AsyncSelect
                              cacheOptions
                              defaultOptions
                              value={selectedNWStatusValue}
                              getOptionLabel={(e) => e.statusName}
                              getOptionValue={(e) => e.statusID}
                              loadOptions={fetchStatusData}
                              onInputChange={handleInputChange1}
                              onChange={handleNWStatusChange}
                              id="ddlNWStatus"
                            />
                          )}
                        </div>
                      )}
                      {isEJStatus && (
                        <div className="clientNameSelect col">
                          <label>EJ Status</label>
                          <input
                            type="checkbox"
                            name="EJStatus"
                            id="EJStatus"
                            className="inputCheckBox ms-2"
                            checked={isEJChecked}
                            onChange={handleEJChecked}
                          />
                          {isEJChecked && (
                            <AsyncSelect
                              cacheOptions
                              defaultOptions
                              value={selectedEJStatusValue}
                              getOptionLabel={(e) => e.statusName}
                              getOptionValue={(e) => e.statusID}
                              loadOptions={fetchStatusData}
                              onInputChange={handleInputChange1}
                              onChange={handleEJStatusChange}
                              id="ddlEJStatus"
                            />
                          )}
                        </div>
                      )}
                    </React.Fragment>
                  )}
                </div>
                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    name="show"
                    id="show"
                    className="btnPrimary"
                    onClick={onShowClick}
                  >
                    Show
                  </button>
                  <button
                    type="button"
                    className="btnPrimaryOutline ms-2"
                    onClick={SearchAllClick}
                  >
                    Search All &nbsp;
                    <input
                      type="checkbox"
                      name="search"
                      id="Check_Search_All"
                      className="inputCheckBox"
                    />
                  </button>
                </div>
              </div>
            </div>
          </div>
          {/* Bottom Content */}
          <div className="configLeftBottom">
            {(ForceSettlement === null || ForceSettlement.length === 0) && (
              <div className="tableBorderBox pb-3 pt-3">
                <div className="clientNameSelect configFormatEntities">
                  <p className="text-danger font-size12">No Records</p>
                </div>
              </div>
            )}
            {/* Table */}
            {isShow ? (
              <div className="spinner-container">
                <div className="loading-spinner"></div>
              </div>
            ) : (
              <>
                {ForceSettlement !== null && ForceSettlement.length > 0 ? (
                  <div>
                    <div className="exportButton">
                      <OverlayTrigger
                        placement="top"
                        delay={{ show: 150, hide: 400 }}
                        overlay={renderTooltipShow}
                      >
                        <button
                          type="button"
                          className="iconForceButtonBox"
                          onClick={ShowModal}
                        >
                          Force Settle
                        </button>
                      </OverlayTrigger>
                    </div>
                    <div className="tableBorderBox pt-3">
                      <div className="w-100 table-responsive">
                        <div className="table-responsive tableContentBox">
                          <table
                            id="gvForceSettlement"
                            className="table table-striped table-hover table-borderless align-middle"
                          >
                            <thead>
                              <tr>
                                <th scope="col">
                                  <input
                                    type="checkbox"
                                    name="select_all"
                                    id="select_all"
                                  />
                                  <label>Select All</label>
                                </th>
                                <th scope="col">Channel Name</th>
                                <th scope="col">Txns Mode</th>
                                <th scope="col">Txns DateTime</th>
                                <th scope="col">Terminal ID</th>
                                <th scope="col">Reference Number</th>
                                <th scope="col">Card Number</th>
                                <th scope="col">Txns Amount</th>
                                <th scope="col">Actual Txns Amount</th>
                                <th scope="col">EJ Status</th>
                                <th scope="col">Switch Status</th>
                                <th scope="col">Network Status</th>
                                <th scope="col">GL Status</th>
                                <th scope="col">Recon Type</th>
                                <th scope="col">Client Name</th>
                              </tr>
                            </thead>
                            <tbody>
                              {ForceSettlement.map((p, index) => {
                                return (
                                  <tr key={index}>
                                    <td>
                                      {" "}
                                      <input
                                        type="checkbox"
                                        name="select"
                                        id={p.unmatchedID}
                                        className="inputCheckBoxGrid"
                                      />
                                    </td>
                                    <td>{p.channelName}</td>
                                    <td>{p.transactionMode}</td>
                                    <td>{p.txnsDateTime}</td>
                                    <td>{p.terminalId}</td>
                                    <td>{p.referenceNumber}</td>
                                    <td>{p.cardNumber}</td>
                                    <td>{p.txnsAmount}</td>
                                    <td>{p.actualTxnsAmount}</td>
                                    <td>{p.ejStatus}</td>
                                    <td>{p.switchStatus}</td>
                                    <td>{p.netWorkStatus}</td>
                                    <td>{p.glStatus}</td>
                                    <td>{p.reconType}</td>
                                    <td>{p.clientName}</td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : null}
              </>
            )}
          </div>
        </div>
      </div>
      {isShowUnmatchedModal && (
        <Modal
          show={isShowUnmatchedModal}
          onHide={() => setShowUnmatchedModal(!isShowUnmatchedModal)}
          centered
          className="vendorTableModal"
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              Force Settlement
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="vendorControl">
              <label htmlFor="ForceSettledDate">Settled Date</label>
              <span className="text-danger font-size13">*</span>
              <DatePicker
                renderCustomHeader={({
                  date,
                  changeYear,
                  changeMonth,
                  decreaseMonth,
                  increaseMonth,
                  prevMonthButtonDisabled,
                  nextMonthButtonDisabled,
                }) => (
                  <div
                    style={{
                      margin: 1,
                      display: "flex",
                      justifyContent: "center",
                    }}
                  >
                    <button
                      onClick={decreaseMonth}
                      disabled={prevMonthButtonDisabled}
                    >
                      <span
                        className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                        style={{ top: -11, left: -10 }}
                      ></span>
                    </button>
                    <select
                      value={getYear(date)}
                      onChange={({ target: { value } }) => changeYear(value)}
                    >
                      {years.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>

                    <select
                      value={months[getMonth(date)]}
                      onChange={({ target: { value } }) =>
                        changeMonth(months.indexOf(value))
                      }
                    >
                      {months.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>

                    <button
                      onClick={increaseMonth}
                      disabled={nextMonthButtonDisabled}
                    >
                      <span
                        className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                        style={{ top: -11, left: 10 }}
                      ></span>
                    </button>
                  </div>
                )}
                id="ForceSettledDate"
                selected={settleDate}
                dateFormat="dd/MM/yyyy"
                onChange={(date) => setSettleDate(date)}
                className="forcesettledDate"
                maxDate={new Date()}
              />
            </div>
            <div className="vendorControl">
              <label htmlFor="Reason">Reason</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="Reason"
                id="Reason"
                placeholder="Enter Reason"
                className="inputTextBox"
                onChange={(e) => setReasonSettled(e.target.value)}
                defaultValue={SettledReason}
                onKeyPress={(e) =>
                  !/[a-zA-Z ]/.test(e.key) && e.preventDefault()
                }
              />
            </div>
            <div className="vendorControl">
              <label htmlFor="ddlRecon">Recon Type</label>
              <span className="text-danger font-size13">*</span>
              <Select
                value={selectedReconTypeValue}
                options={optionsReconType}
                id="ddlRecon"
                onChange={handleReconTypeChange}
                classNamePrefix="reactSelectBox"
              />
            </div>

            <div className="vendorControl">
              <label htmlFor="ddlSettlement">Settlement Type</label>
              <span className="text-danger font-size13">*</span>
              <Select
                value={selectedSettlementTypeValue}
                options={optionsSettlementType}
                id="ddlSettlement"
                onChange={handleSettlementTypeChange}
                classNamePrefix="reactSelectBox"
              />
            </div>
          </Modal.Body>
          <Modal.Footer>
            <button
              type="button"
              className="btnPrimary ms-2"
              onClick={onForceClick}
            >
              Force Settle
            </button>
          </Modal.Footer>
        </Modal>
      )}
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default ForceSettlementMainWindow;
