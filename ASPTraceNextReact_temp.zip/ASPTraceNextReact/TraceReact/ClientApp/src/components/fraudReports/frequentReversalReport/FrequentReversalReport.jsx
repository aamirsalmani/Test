﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import FrequentReversalReportMainWindow from "./FrequentReversalReportMainWindow";

const FrequentReversalReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <FrequentReversalReportMainWindow />
        </div>
    );
};

export default FrequentReversalReport;
