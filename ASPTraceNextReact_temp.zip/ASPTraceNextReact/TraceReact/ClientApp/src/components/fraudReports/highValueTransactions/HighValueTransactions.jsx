﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import HighValueTransactionsMainWindow from "./HighValueTransactionsMainWindow";

const HighValueTransactions = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <HighValueTransactionsMainWindow />
        </div>
    );
};

export default HighValueTransactions;
