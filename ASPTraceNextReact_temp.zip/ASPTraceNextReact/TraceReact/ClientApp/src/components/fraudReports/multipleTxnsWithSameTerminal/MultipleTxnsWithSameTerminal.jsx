import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import MultipleTxnsWithSameTerminalMainWindow from "./MultipleTxnsWithSameTerminalMainWindow";

const MultipleTxnsWithSameTerminal = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView">
     <MultipleTxnsWithSameTerminalMainWindow />
    </div>
  );
};

export default MultipleTxnsWithSameTerminal;
