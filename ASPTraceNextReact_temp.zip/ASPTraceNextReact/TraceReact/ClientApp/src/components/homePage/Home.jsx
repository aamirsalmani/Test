﻿import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux"; 
import MaximusAxios from "../common/apiURL";

const Home = () => { 

    const currentUser = useSelector((state) => state.authReducer);

    const [isPostBack, setIsPostBack] = useState(null);

    const [PowerBIURL, setPowerBIURL] = useState(null);

    useEffect(() => {
        fetchPowerBIURL()
    },
        [isPostBack]
    );

    const fetchPowerBIURL = () => {

        //console.log(currentUser);

        let Username = '';

        if (currentUser && currentUser.user && currentUser.user.username) {

            Username = currentUser.user.username;

            if(Username.length > 0 )
            {   
                MaximusAxios.get('api/Home/GetPowerBIURL?UserID=' + Username, { mode: 'cors' }).then(result => {
                    setPowerBIURL(result.data);

                }).catch(function (error) {

                    if ([401, 403].includes(error.response.status)) {
                        localStorage.removeItem('user');
                        window.history.go('Login');
                    }

                });                       
            }
        }
        else {
            console.log('jhjh');
            localStorage.removeItem('user');
           // window.history.go('Login');
        }


    }

    return (
        <div className="mainView">
            {/* <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                <div className="configLeft reportContainer">
                    <div className="configLeftTop">
                        <iframe width="95%" height="700" src={PowerBIURL} style={{ position: "relative", clip: "rect(0px,1400px,700px,0px)", bottom: "-10px" }}  ></iframe>
                    </div>
                </div>
            {/* </div> */}
        </div>
    );
};

export default Home;
