﻿import React from "react";
import { useSelector } from "react-redux"; 
import SidebarMain from "../common/SidebarMain";
import ImportFileMainWindow from "./ImportFileMainWindow";

const ImportFile = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <ImportFileMainWindow />
        </div>
    );
};

export default ImportFile;