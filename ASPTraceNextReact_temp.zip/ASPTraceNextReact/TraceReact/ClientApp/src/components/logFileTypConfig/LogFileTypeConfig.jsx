import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../common/SidebarMain";
import LogFileTypeConfigMainWindow from "./LogFileTypeConfigMainWindow";

const LogFileTypeConfig = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <LogFileTypeConfigMainWindow />
        </div>
    );
};

export default LogFileTypeConfig;
