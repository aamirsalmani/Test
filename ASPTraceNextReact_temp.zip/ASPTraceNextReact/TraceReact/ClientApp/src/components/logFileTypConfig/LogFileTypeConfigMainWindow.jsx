import React, { useState, useEffect } from "react";
import Select from "react-select";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import AsyncSelect, { useAsync } from "react-select/async";
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import $ from "jquery";
import "jquery/dist/jquery.min.js";

// Images
import Delete from "../../images/common/redDelete.svg";
import editRow from "../../images/common/editRow.svg";

import { useSelector } from "react-redux";

const LogFileTypeConfigMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);
  const [selectedClientValue, setSelectedClientValue] = useState(null);
  const [selectedChannelValue, setSelectedChannelValue] = useState(null);
  const [selectedModeValue, setSelectedModeValue] = useState(null);
  const [FileID, setFileID] = useState(null);
  const [FileCount, setFileCount] = useState("");
  const [NetworkTypeID, setnetworkTypeID] = useState(null);
  const [tablenames, setTableNames] = useState(null);
  const [optionsFileID, setOptionsFileID] = useState([
    { FileID: "0", LogType: "ALL" },
  ]);
  const [optionsTableName, setOptionsTableName] = useState([
    { TableID: "0", RawTableName: "ALL" },
  ]);
  const [optionsnetworktypeID, setOptionNetworkTypeID] = useState([
    { ID: "0", Networktype: "ALL" },
  ]);

  const [selectedIsRecon, setSelectedIsRecon] = useState(null);
  const [optionsChannelType, setOptionsChannelType] = useState([
    { channelID: "0", channelName: "ALL" },
  ]);
  const [optionsModeType, setOptionsModeTypeValue] = useState([
    { modeID: "0", modeName: "ALL" },
  ]);
  const [inputValue, setValue] = useState("0");
  const [logfileData, setlogfileData] = useState([]);
  const [ID, setID] = useState("0");
  const optionsReconAvailable = [
    { isRecon: "0", isReconlabel: "No" },
    { isRecon: "1", isReconlabel: "Yes" },
  ];

  const [isNewEntry, setNewEntry] = useState(false);
  //const Show Loader
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });
  const handleInputChange = (value) => {
    setValue(value);
  };
  const handleIsReconChange = (value) => {
    setSelectedIsRecon(value);
  };

  const handleMaxFileCountChange = (value) => {
    setFileCount(value);
  };

  const fetchClientData = (inputValue) => {
    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  const onReset = (e) => {
    e.preventDefault();
    window.location.reload(false);
  };

  const [isShowModal, setShowModal] = useState(false);

  const [buttonValue, setButtonValue] = useState("ADD");

  const onNewClick = (btn) => {
    setShowModal(true);
    setFileCount(null);
    setButtonValue(btn);
    try {
      setnetworkTypeID(null);
      setTableNames(null);
      setFileID(null);
      // FileID.value
      // selectedIsRecon
      if (btn === "UPDATE") {
        alert("Are you sure you want to Edit.");
        setNewEntry(false);
      } else {
        alert("Are you sure you want to Add.");
        setNewEntry(true);
      }
      setIsLoading(true);
      setSelectedIsRecon(null);
      //Get FileID list

      MaximusAxios.get(
        "api/DynamicFileConfig/GetDynamicFileIdOptionList?",
        {}
      ).then((resultFileID) => {
        setOptionsFileID(resultFileID.data);
      });
      // console.log(optionsFileID);

      //Get Table list
      MaximusAxios.get("api/DynamicReconConfig/GetReconTables", {
        params: {
          ChannelID: selectedChannelValue.value,
          ModeID: selectedModeValue.value,
        },
        // Assuming authHeader() returns the necessary authorization headers
      })
        .then((response) => {
          setOptionsTableName(response.data);
          // console.log(optionsTableName);
        })
        .catch((error) => {
          console.error("Error fetching recon tables:", error);
        });
      setIsLoading(false);
    } catch (ex) {
      console.log(ex);
      setIsLoading(false);
    }
    //Get Network type list
    MaximusAxios.get(
      "api/DynamicFileConfig/GetDynamicNetworkTypeOptionList?",
      {}
    ).then((resultNetworkType) => {
      setOptionNetworkTypeID(resultNetworkType.data);
    });
    // console.log(optionsnetworktypeID)
  };

  const onEditClick = (item) => {
    setNewEntry(false);
    onNewClick("UPDATE");
    MaximusAxios.get(
      "api/LogFileTypeConfig/GetLogTypeConfigurationDetails?ID=" + item.id,
      { mode: "cors" }
    )
      .then((Response) => {
        if (Response.data != null) {
          //console.log(JSON.parse(Response.data.tableName).label);
          showEditData(Response.data);
          //setTableNames(item.tableName);
          //console.log("item" + item.tableName)
          setShowModal(true);
        }
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
      });

    //setButtonValue('UPDATE');
    //}
  };

  const showEditData = (obj) => {
    //alert("h11" + JSON.parse(obj.id.value))
    //  console.log(JSON.parse(obj.fileCount));
    setTableNames(JSON.parse(obj.tableName));
    setFileID(JSON.parse(obj.fileID));
    setnetworkTypeID(JSON.parse(obj.networkTypeID));
    setID(JSON.parse(obj.id));
    setSelectedIsRecon(JSON.parse(obj.isRecon));
    setFileCount(JSON.parse(obj.fileCount)?.value);
  };

  const onAddClick = () => {
    //  alert(tablenames);

    if (FileCount === null || FileCount.value === "") {
      alert("Please enter max file count for recon check!");
      return false;
    }

    setlogfileData(null);
    if (NetworkTypeID === null || NetworkTypeID.value === 0) {
      alert("Please select Network Type ID!");
      return false;
    }
    if (!FileID || FileID.value === "") {
      alert("Please enter File ID!");
      return false;
    }
    if (tablenames === null || tablenames.value === "") {
      alert("Please select Table Name!");
      return false;
    }


    if (selectedIsRecon === null || selectedIsRecon.value === "") {
      alert("Please enter Is Required for Recon!");
      return false;
    }

    setIsLoading(true);
    MaximusAxios.post(
      "api/LogFileTypeConfig/AddNewLogfileTypeconfigData",
      {
        Clientid: String(selectedClientValue.clientID),
        Channelid: String(selectedChannelValue.value),
        Modeid: String(selectedModeValue.value),
        NetworkTypeID: String(NetworkTypeID.value),
        FileID: String(FileID.value),
        TableName: String(tablenames.value),
        IsRecon: String(selectedIsRecon.value),
        ID: String(ID),
        FileCount: String(FileCount),
        UserName: String(currentUser.user.username),
        Mode: buttonValue,
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setShowModal(false);
        setIsLoading(false);

        if (response.data === "0") {
          alert("LogType Configuration already exists!");
        } else if (response.data === null || response.data === "1") {
          if (buttonValue === "ADD") {
            alert("LogType Configuration added successfully!");
          }
          if (buttonValue === "UPDATE") {
            alert("LogType Configuration updated successfully!");
          }
          if (buttonValue === "ADD") setlogfileData(null);
        } else {
          alert(response.data);
        }


        MaximusAxios.post(
          "api/LogFileTypeConfig/LogFileTypeConfigData",
          {
            ClientID: String(selectedClientValue.clientID),
            ChannelID: String(selectedChannelValue.value),
            ModeID: String(selectedModeValue.value),
          },
          {}
        )
          .then((response) => {
            setlogfileData(response.data);
          })
          .catch(function (error) {
            setIsLoading(false);
          });

      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });
    onShowClick();
  };


  const onDeleteClick = (item) => {
    if (window.confirm("Are you sure you want to delete.")) {
      MaximusAxios.post(
        "api/LogFileTypeConfig/DeleteLogFileTypeConfiglist",
        {
          ID: item.id,
          Mode: "DELETE",
        },
        { mode: "cors" }
      )
        .then(function (response) {
          if (response.data !== null || response.data.length > 0) {
            alert(response.data);
            setlogfileData(null);
          }
        })
        .catch(function (error) {
          if (error.response) {
            console.log(error.response.data);
          }
        });
    }
    onShowClick();
  };

  const handleClientChange = (value) => {
    //setShow(false);
    setlogfileData(null);
    setSelectedClientValue(value);
    setSelectedChannelValue(null);
    setSelectedModeValue(null);

    try {
      setIsLoading(true);

      if (value.clientID !== "0") {
        MaximusAxios.get(
          "api/DynamicFileConfig/GetChannelOptionList?ClientID=" +
          value.clientID,
          { mode: "cors" }
        ).then((resultChannel) => {
          setOptionsChannelType(resultChannel.data);

          setIsLoading(false);
        });
      }
    } catch (ex) {
      console.log(ex);
      setIsLoading(false);
    }
  };
  const handleChannelChange = (value) => {
    // setShow(false);
    setlogfileData(null);
    setSelectedChannelValue(value);
    setSelectedModeValue(null);

    let ChannelId = 0;
    if (value === undefined || value === null) {
      ChannelId = 0;
    } else {
      ChannelId = value.value;
    }
    setIsLoading(true);
    MaximusAxios.get(
      "api/DynamicFileConfig/GetDynamicModeOptionList?ClientID=" +
      selectedClientValue.clientID +
      "&ChannelID=" +
      ChannelId,
      { mode: "cors" }
    ).then((resultMode) => {
      setOptionsModeTypeValue(resultMode.data);
    });
    setIsLoading(false);
    // onShowClick();
  };

  const onShowClick = () => {
    let alertMessages = "";

    if (selectedClientValue === null || selectedClientValue === undefined) {
      alertMessages += "Please select client. \n";
    }
    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      alertMessages += "Please select Channel. \n";
    } else if (selectedModeValue === undefined || selectedModeValue === null) {
      alertMessages += "Please select mode Type. \n";
    }
    if (alertMessages.length > 0) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "info",
        alertTitle: "Mandatory Field",
        alertMessage: alertMessages,
      });
      return false;
    }
    //CheckSelectedValues();
    MaximusAxios.post(
      "api/LogFileTypeConfig/LogFileTypeConfigData",
      {
        ClientID: String(selectedClientValue.clientID),
        ChannelID: String(selectedChannelValue.value),
        ModeID: String(selectedModeValue.value),
      },
      {}
    )
      .then((response) => {
        setlogfileData(response.data);
        // console.log(response.data);
        setIsLoading(false);
      })
      .catch(function (error) {
        setIsLoading(false);
      });
  };
  const handleModeChange = (value) => {
    setlogfileData(null);
    setSelectedModeValue(value);
  };

  $(document).ready(function () {
    if (logfileData !== null && logfileData.length > 0) {
      $("#gvVendorRegistration").DataTable({
        bDestroy: true,
        columnDefs: [{ orderable: false, targets: [2] }],
      });
    }
  });
  return (
    <div className="configLeft dynamicContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Log FileType Configuration
        </h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Configuration</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">LogFileType Configuration</p>
        </div>
      </div>
      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="unmatchedFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="unmatchedFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>

              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#unmatchedFiltersCollapse"
                aria-expanded="true"
                aria-controls="unmatchedFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="unmatchedFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="unmatchedFiltersHeading"
              data-bs-parent="#unmatchedFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedClientValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      defaultValue={"ADd"}
                      id="ddlClient"
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      onChange={handleChannelChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlMode">Mode Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlMode"
                      value={selectedModeValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsModeType.map((x) => ({
                        value: x.modeID,
                        label: x.modeName,
                      }))}
                      onChange={handleModeChange}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onShowClick}
                    disabled={isShow}
                  >
                    Show
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={() => onNewClick("ADD")}
                    disabled={isShow}
                  >
                    Add New
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="configLeftBottom">
        <div>
          {(logfileData === null || logfileData.length === 0) && (
            <div className="tableBorderBox pb-3 pt-3">
              <div className="clientNameSelect configFormatEntities">
                <p className="text-danger font-size12">No Records</p>
              </div>
            </div>
          )}
          {isShow ? (
            <div className="spinner-container">
              <div className="loading-spinner"></div>
            </div>
          ) : (
            <>
              {/* Table */}
              {logfileData != null && logfileData.length > 0 && (
                <div>
                  <div className="tableBorderBox pt-3">
                    <div className="w-100 table-responsive">
                      <div className="table-responsive tableVendorContentBox">
                        <table
                          id="gvVendorRegistration"
                          className="table table-striped table-hover table-borderless align-middle"
                          style={{ width: "100%" }}
                        >
                          <thead>
                            <tr>
                              <th scope="col">ID</th>
                              <th scope="col">Client</th>
                              <th scope="col">Channel</th>
                              <th scope="col">Mode</th>
                              <th scope="col">Network Type</th>
                              <th scope="col">Log File Type</th>
                              <th scope="col">Max File Count</th>
                              <th scope="col">Table Name</th>
                              <th scope="col">Is Recon</th>

                              <th>EDIT</th>
                            </tr>
                          </thead>
                          <tbody>
                            {logfileData.map((item, index) => (
                              <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{item.clientName}</td>
                                <td>{item.channelName}</td>
                                <td>{item.transactionMode}</td>
                                <td>{item.networkTypeID}</td>
                                <td>{item.logFileType}</td>
                                <td>{item.maxFileCount}</td>
                                <td>{item.tableName}</td>
                                <td>{item.isRecon}</td>
                                <td>
                                  <div className="text-center">
                                    <button
                                      type="button"
                                      className="iconButtonBox"
                                      onClick={() => {
                                        onEditClick(item);
                                      }}
                                    >
                                      <img
                                        src={editRow}
                                        alt="Edit"
                                        title="Edit"
                                      />
                                    </button>
                                    <button
                                      type="button"
                                      className="iconButtonBox"
                                      onClick={() => onDeleteClick(item)}
                                    >
                                      <img
                                        src={Delete}
                                        alt="Delete"
                                        title="Delete"
                                      />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {isShowModal && (
        <Modal
          centered
          className="AddNewTableModal"
          size="xl"
          show={isShowModal}
          onHide={() => setShowModal(!isShowModal)}
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              {isNewEntry ? <span>Add</span> : <span>Update</span>} LogType
            </Modal.Title>
          </Modal.Header>
          <Modal.Body size="xl">
            <div
              id="unmatchedFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="unmatchedFiltersHeading"
              data-bs-parent="#unmatchedFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedClientValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                      isDisabled={true}
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      isDisabled={true}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlMode">Mode Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlMode"
                      value={selectedModeValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsModeType.map((x) => ({
                        value: x.modeID,
                        label: x.modeName,
                      }))}
                      isDisabled={true}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlFilecount">Max File Count</label>
                    <span className="text-danger font-size13">*</span>
                    <input
                      type="number"
                      id="ddlFilecount"
                      className="form-control"
                      onChange={(e) => setFileCount(e.target.value)}
                      value={FileCount ?? ""}
                      placeholder="Max count For Recon check"
                      min="0"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlNetwork">Network Type ID</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlNetwork"
                      classNamePrefix="reactSelectBox"
                      onChange={(value) => setnetworkTypeID(value)}
                      options={optionsnetworktypeID.map((x) => ({
                        value: x.id,
                        label: x.networkName,
                      }))}
                      value={NetworkTypeID}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlLog">LogFile Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlLog"
                      classNamePrefix="reactSelectBox"
                      onChange={(value) => setFileID(value)}
                      options={optionsFileID.map((x) => ({
                        value: x.fileID,
                        label: x.logType,
                      }))}
                      value={FileID}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlTable">Table Name</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlTable"
                      classNamePrefix="reactSelectBox"
                      onChange={(value) => setTableNames(value)}
                      options={optionsTableName.map((x) => ({
                        value: x.rawTableName,
                        label: x.rawTableName,
                      }))}
                      value={tablenames}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlRecon">Is Recon</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlRecon"
                      classNamePrefix="reactSelectBox"
                      value={selectedIsRecon}
                      options={optionsReconAvailable.map((x) => ({
                        value: x.isRecon,
                        label: x.isReconlabel,
                      }))}
                      onChange={handleIsReconChange}
                    />
                  </div>
                </div>
              </div>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <button
              type="button"
              className="btnPrimary ms-2"
              onClick={onAddClick}
            >
              {buttonValue}
            </button>
          </Modal.Footer>
        </Modal>
      )}

      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default LogFileTypeConfigMainWindow;
