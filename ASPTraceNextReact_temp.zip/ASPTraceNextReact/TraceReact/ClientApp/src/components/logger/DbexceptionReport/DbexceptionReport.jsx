﻿import React from "react";
import { useSelector } from "react-redux"; 
// Components
import SidebarMain from "../../common/SidebarMain";
import DbexceptionReportMainWindow from "./DbexceptionReportMainWindow";

const DbexceptionReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <DbexceptionReportMainWindow />
        </div>
    );
};

export default DbexceptionReport