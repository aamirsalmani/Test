﻿import React, { useRef, useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import MaximusAxios from "../../common/apiURL";
import DatePicker from "react-datepicker";
import authHeader from "../../../pages/login/services/auth-header";
import MessageBox from "../../common/MessageBox";
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import "jquery/dist/jquery.min.js";
import { getYear, getMonth } from "date-fns";
import ExcelIcon from "../../../images/common/excel.svg";
import $ from "jquery";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { useSelector } from "react-redux";

import { Tooltip, OverlayTrigger } from "react-bootstrap";
import LoadingSpinner from "../../common/LoadingSpinner";

const DbexceptionReportMainWindow = () => {
  let location = useLocation();
  let capitalizedLocation = location.pathname.replace(/\b\w/g, (char) =>
    char.toUpperCase()
  );

  const currentUser = useSelector((state) => state.authReducer);
  const [ShowGrid, setShowGrid] = useState(false);
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [LoginData, setLoginData] = useState([]);

  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());

  useEffect(() => {
    setEndDate(null);
    setStartDate(null);
  }, []);

  const ExportToExcel = async () => {
    MaximusAxios.post(
      "api/Logger/InsertUserActivityReport",
      {
        UserId: currentUser.user.username,
        PageName: capitalizedLocation,
        Activity: "Download Excel",
      },
      { headers: authHeader() }
    );

    const workbook = new ExcelJS.Workbook();

    try {
      setIsLoading(true);

      var data = $("#gvMatchingList")
        .dataTable()
        ._("tr", { filter: "applied" });
      let filterDataExcel = [];
      let cntrow = 0;

      for (let i = 0; i < data.length; i++) {
        var arr = {
          SrNo: data[cntrow][0],
          UserName: data[cntrow][1],
          ErrorNumber: data[cntrow][2],
          ErrorState: data[cntrow][3],
          ErrorSeverity: data[cntrow][4],
          ErrorLine: data[cntrow][5],
          ErrorProcedure: data[cntrow][6],
          ErrorMessage: data[cntrow][7],
          ErrorDate: data[cntrow][8],
        };
        filterDataExcel.push(arr);
        cntrow++;
      }

      // Create Excel workbook and worksheet
      const worksheet = workbook.addWorksheet("DataBaseExceptionReport");

      // Define columns in the worksheet, these columns are identified using a key.
      worksheet.columns = [
        { header: "Sr. No.", key: "SrNo" },
        { header: "User Name", key: "UserName" },
        { header: "Error Number", key: "ErrorNumber" },
        { header: "Error State", key: "ErrorState" },
        { header: "Error Severity", key: "ErrorSeverity" },
        { header: "Error Line", key: "ErrorLine" },
        { header: "Error Procedure", key: "ErrorProcedure" },
        { header: "Error Message", key: "ErrorMessage" },
        { header: "Error Date", key: "ErrorDate" },
      ];

      worksheet.columns = [
        { width: 15 },
        { width: 20 },
        { width: 15 },
        { width: 15 },
        { width: 15 },
      ];

      // loop through all of the columns and set the alignment with width.
      worksheet.columns.forEach((column) => {
        column.alignment = { horizontal: "center" };
      });

      // updated the font for first row.
      worksheet.getRow(1).font = { bold: true, color: { argb: "ffffff" } };

      // loop through data and add each one to worksheet
      filterDataExcel.forEach((singleData) => {
        worksheet.addRow(singleData);
      });

      // Add auto-filter on each column
      //worksheet.autoFilter = 'A1:D1';

      // Process each row for calculations and beautification
      worksheet.eachRow((row, rowNumber) => {
        row.eachCell((cell, colNumber) => {
          if (rowNumber == 1) {
            // First set the background of header row
            cell.fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "df5015" },
            };
          }
          // Set border of each cell
          cell.border = {
            top: { style: "thin" },
            left: { style: "thin" },
            bottom: { style: "thin" },
            right: { style: "thin" },
          };
        });
        //Commit the changed row to the stream
        row.commit();
      });

      //console.log(filterDataExcel);

      var today = new Date();
      var dateHeading =
        today.getDate() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getFullYear() +
        " " +
        today.getHours() +
        "_" +
        today.getMinutes() +
        "_" +
        today.getSeconds();
      // write the content using writeBuffer
      const buf = await workbook.xlsx.writeBuffer();

      // download the processed file
      saveAs(
        new Blob([buf]),
        "Database Exception Report " + dateHeading + ".xlsx"
      );

      setIsLoading(false);
    } catch (error) {
      console.error("<<<ERRROR>>>", error);
      console.error("Something Went Wrong", error.message);
    } finally {
      // removing worksheet's instance to create new one
      workbook.removeWorksheet("DbExceptionReport");
    }
  };

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const setStartDateValue = (value) => {
    setStartDate(value);
    //setFileStatusReport(null);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    //setFileStatusReport(null);
  };

  const formatDate = (date) => {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

  const onShowClick = () => {
    setShowGrid(false);
    setLoginData([])
    setIsLoading(true)
    let alertMessages = "";
    if (startDate === undefined || startDate === null) {
      alertMessages += "Please enter From Date! \n";
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alertMessages += "Please enter To Date! \n";
      return false;
    }
    if (alertMessages.length > 0) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "info",
        alertTitle: "Mandatory Field",
        alertMessage: alertMessages,
      });
      return false;
    }
    MaximusAxios.post(
      "api/Logger/GetDbExceptionList",
      {
        StartDate: formatDate(startDate),
        EndDate: formatDate(endDate),
      },
      {
        headers: authHeader(),
      }
    )
      .then((result) => {
        if (result.data.length > 0) {
          setLoginData(result.data);
          setShowGrid(true);
        } else {
          alertMessages += "Records Dosen't Exists";
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Mandatory Field",
            alertMessage: alertMessages,
          });
        }
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setIsLoading(false)
          console.log(error.response.data);
        }
      });
     // setIsLoading(false)
  };

  const onReset = (e) => {
    e.preventDefault();
    // window.location.reload(false);
    setShowGrid(false);
    setLoginData(null);
    setStartDate(null);
    setEndDate(null);
  };

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to excel
    </Tooltip>
  );

  $(document).ready(function () {
    if (LoginData !== null && LoginData.length > 0) {
      $("#gvMatchingList").DataTable();
    }
  });

  return (
    <div className="configLeft dynamicContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Database Exception Report
        </h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault"></p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Database Exception Report</p>
        </div>
      </div>
      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="unmatchedFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="unmatchedFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>

              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#unmatchedFiltersCollapse"
                aria-expanded="true"
                aria-controls="unmatchedFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="unmatchedFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="unmatchedFiltersHeading"
              data-bs-parent="#unmatchedFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onShowClick}
                    disabled={isShow}
                  >
                    Show
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Data Grid*/}
      <div className="configLeftBottom">
        {(LoginData === null || LoginData.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        <div>
          {isShow ? (
            <div className="spinner-container">
              <div className="loading-spinner"></div>
            </div>
          ) : (
            <>
              {/* Table */}
              {(LoginData !== null && LoginData.length > 0) ? (
                <div>
                  <div className="exportButton">
                    <OverlayTrigger
                      placement="top"
                      delay={{ show: 150, hide: 400 }}
                      overlay={renderTooltipExcel}
                    >
                      <button
                        type="button"
                        className="iconButtonBox"
                        onClick={ExportToExcel}
                      >
                        <img src={ExcelIcon} alt="Excel" />
                      </button>
                    </OverlayTrigger>
                  </div>
                  <div className="tableBorderBox pt-3">
                    <div className="w-100 table-responsive">
                      <div className="table-responsive tableContentBox">
                        <table
                          id="gvMatchingList"
                          className="table table-striped table-hover table-borderless align-middle"
                          style={{ width: "100%" }}
                        >
                          <thead>
                            <tr>
                              <th scope="col">Sr. No.</th>
                              <th scope="col">User Name</th>
                              <th scope="col">Error Number</th>
                              <th scope="col">Error State</th>
                              <th scope="col">Error Severity</th>
                              <th scope="col">Error Line</th>
                              <th scope="col">Error Procedure</th>
                              <th scope="col">Error Message</th>
                              <th scope="col">Error Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            {LoginData.map((item, index) => (
                              <tr key={index}>
                                <td>{index + 1}</td>{" "}
                                {/* Index starts from 0, so add 1 to make it 1-based */}
                                <td>{item.userName}</td>
                                <td>{item.errorNumber}</td>
                                <td>{item.errorState}</td>
                                <td>{item.errorSeverity}</td>
                                <td>{item.errorLine}</td>
                                <td>{item.errorProcedure}</td>
                                <td>{item.errorMessage}</td>
                                <td>{item.errorDateTime}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              ) : null}
            </>
          )}
        </div>
      </div>
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default DbexceptionReportMainWindow;
