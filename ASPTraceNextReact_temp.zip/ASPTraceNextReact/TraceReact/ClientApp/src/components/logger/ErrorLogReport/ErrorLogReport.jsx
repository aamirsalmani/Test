﻿import React from "react";
import { useSelector } from "react-redux"; 
// Components
import SidebarMain from "../../common/SidebarMain";
import ErrorLogReportMainWindow from "./ErrorLogReportMainWindow";

const ErrorLogReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <ErrorLogReportMainWindow />
        </div>
    );
};

export default ErrorLogReport