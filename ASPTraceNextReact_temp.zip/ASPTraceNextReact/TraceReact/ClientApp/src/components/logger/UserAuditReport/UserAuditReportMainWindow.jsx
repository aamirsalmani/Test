import React, { useRef, useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import MaximusAxios from "../../common/apiURL" ;
import DatePicker from "react-datepicker";
import authHeader from "../../../pages/login/services/auth-header";
import MessageBox from "../../common/MessageBox";
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import "jquery/dist/jquery.min.js";
import Select from "react-select";
import ExcelIcon from "../../../images/common/excel.svg";
import $ from "jquery";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { getYear, getMonth } from "date-fns";
import { useSelector } from "react-redux";

import { Tooltip, OverlayTrigger } from "react-bootstrap";

const UserAuditReportMainWindow = () => {
  let location = useLocation();
  let capitalizedLocation = location.pathname.replace(/\b\w/g, (char) =>
    char.toUpperCase()
  );


  const [ShowGrid, setShowGrid] = useState(false);
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [SelectedUserId, setSelectedUserId] = useState(null);
 
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());

  const [UserAuditDetails, setUserAuditDetails] = useState(null);
  const [titleDate, setTitleDateValue] = useState("");

  const formatDateForShow = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are zero-based
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };




  useEffect(() => {
   // onSubmit();
    setEndDate(null);
    setStartDate(null);
  }, []);

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const setStartDateValue = (value) => {
    setStartDate(value);
    setEndDate(null);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    //setFileStatusReport(null);
  };

  const formatDate = (date) => {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;

    return [year, month, day].join('-');
}

  const onShowClick = () => {
    let alertMessages = "";
    if (startDate === undefined || startDate === null) {
      alertMessages += "Please enter From Date! \n";
    }
    if (endDate === undefined || endDate === null) {
      alertMessages += "Please enter To Date! \n";
    }
    if (alertMessages.length > 0) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "info",
        alertTitle: "Mandatory Field",
        alertMessage: alertMessages,
      });
      return false;
    }

    MaximusAxios
    .post("api/Logger/UserAudit", {
      StartDate: (formatDate(startDate)),
      EndDate: (formatDate(endDate))
  }, {
      headers: authHeader()
  })
      .then((result) => {
        if (result.data.length > 0) {
          setUserAuditDetails(result.data);
          setIsLoading(false);
        } else {
          alertMessages += "Records Dosen't Exists";
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Mandatory Field",
            alertMessage: alertMessages,
          });  
          setIsLoading(false);
        }
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });
  };

  const onReset = (e) => {
    e.preventDefault();
   // window.location.reload(false);
   setUserAuditDetails(null)
   setEndDate(null);
   setStartDate(null);
  };
 
  $(document).ready(function () {
    if (UserAuditDetails !== null && UserAuditDetails.length > 0) {
      $("#gvUnmatchedReportPDF").DataTable();
    }
  });

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to excel
    </Tooltip>
  );

  const getColumnHeaders = () => {
    if (UserAuditDetails.length === 0) return [];
    return Object.keys(UserAuditDetails[0]);
  };
  const getColumnHeadersForUnmatched = () => {
    if (UserAuditDetails.length === 0) return [];
    return Object.keys(UserAuditDetails[0]);
  };



  return (
    <div className="configLeft dynamicContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
        User Add Modify Report
        </h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Logger</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">User Add Modify Report</p>
        </div>
      </div>
      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="unmatchedFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="unmatchedFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>

              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#unmatchedFiltersCollapse"
                aria-expanded="true"
                aria-controls="unmatchedFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="unmatchedFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="unmatchedFiltersHeading"
              data-bs-parent="#unmatchedFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onShowClick}
                    disabled={isShow}
                  >
                    Show
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Data Grid*/}
      <div className="configLeftTop">
      {(UserAuditDetails === null || UserAuditDetails.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        {UserAuditDetails !== null && UserAuditDetails.length > 0 ? (
          <div>
            <div className="tableBorderBox pt-3">
              <div className="w-100 table-responsive">
                <div className="table-responsive tableContentBox">
                  <table
                    id="gvUnmatchedReportPDF"
                    className="table table-striped table-hover table-borderless align-middle"
                    style={{ width: "100%" }}
                  >
                    <thead>
                      <tr>
                        {getColumnHeadersForUnmatched().map((header, index) => (
                          <th key={index} scope="col">
                            {header}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {UserAuditDetails.map((row, rowIndex) => (
                        <tr key={rowIndex}>
                          {getColumnHeadersForUnmatched().map(
                            (header, colIndex) => (
                              <td key={colIndex}>
                                {header === "Created On" ||
                                header === "Changed Password Date"
                                  ? formatDateForShow(row[header])
                                  : row[header]}
                              </td>
                            )
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </div>

      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default UserAuditReportMainWindow;
