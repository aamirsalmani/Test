﻿import React, { useRef, useState, useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import { useSelector } from "react-redux";
import MaximusAxios from "../../common/apiURL";
import DatePicker from "react-datepicker";
import authHeader from "../../../pages/login/services/auth-header";
import MessageBox from "../../common/MessageBox";
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import "jquery/dist/jquery.min.js";
import Select from "react-select";
import ExcelIcon from "../../../images/common/excel.svg";
import $ from "jquery";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import { getYear, getMonth } from "date-fns";

import { Tooltip, OverlayTrigger } from "react-bootstrap";
import LoadingSpinner from "../../common/LoadingSpinner";

const UserLoginReportMainWindow = () => {
  let location = useLocation();
  let capitalizedLocation = location.pathname.replace(/\b\w/g, (char) =>
    char.toUpperCase()
  );
  const currentUser = useSelector((state) => state.authReducer);

  const [ShowGrid, setShowGrid] = useState(false);
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [SelectedUserId, setSelectedUserId] = useState(null);
  const [LoginData, setLoginData] = useState([]);
  const [optionsUserId, setOptionsUserId] = useState([
    { iD: "0", userId: "ALL" },
  ]);

  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());

  const handleUserId = (value) => {
    setSelectedUserId(value);
    setLoginData(null);
  };

  const fetchUserId = () => {
    MaximusAxios.get("api/Logger/GetUserList", { mode: "cors" })
      .then((response) => {
        const modifiedOptions = [
          { iD: "0", userId: "ALL" },
          ...response.data, // Spread the existing data from the API response
        ];
        setOptionsUserId(modifiedOptions);
        console.log(modifiedOptions);
      })
      .catch((error) => {
        if (error.response) {
          console.log(error.response.data);
        }
      });
  };

  useEffect(() => {
    setEndDate(null);
    setStartDate(null);
    fetchUserId();
  }, []);

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const setStartDateValue = (value) => {
    setStartDate(value);
    //setFileStatusReport(null);
  };

  const setEndDateValue = (value) => {
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
    //setFileStatusReport(null);
  };

  const formatDate = (date) => {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

  const onShowClick = () => {
    setShowGrid(false);
    let alertMessages = "";
    if (startDate === undefined || startDate === null) {
      alertMessages += "Please enter From Date! \n";
    }

    if (endDate === undefined || endDate === null) {
      alertMessages += "Please enter To Date! \n";
    }

    if (SelectedUserId === undefined || SelectedUserId === null) {
      alertMessages += "Please select User ID! \n";
    }
    if (alertMessages.length > 0) {
      setShowMessageBox({
        isShow: true,
        alertVariant: "info",
        alertTitle: "Mandatory Field",
        alertMessage: alertMessages,
      });
      return false;
    }

    MaximusAxios.post(
      "api/Logger/GetUserLoginReport",
      {
        StartDate: formatDate(startDate),
        EndDate: formatDate(endDate),
        UserId: SelectedUserId.label,
      },
      {
        headers: authHeader(),
      }
    )
      .then((result) => {
        if (result.data.length > 0) {
          setLoginData(result.data);
          setShowGrid(true);
          setIsLoading(false);
        } else {
          alertMessages += "Records Dosen't Exists";
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Mandatory Field",
            alertMessage: alertMessages,
          });
          setLoginData(null);
          setShowGrid(false);
          setIsLoading(false);
        }
      })
      .catch(function (error) {
        setLoginData(null);
        if (error.response) {
          console.log(error.response.data);
        }
        setShowGrid(false);
        setIsLoading(false);
      });
  };

  const ExportToExcel = async () => {
    const workbook = new ExcelJS.Workbook();

    try {
      setIsLoading(true);

      var data = $("#gvMatchingList")
        .dataTable()
        ._("tr", { filter: "applied" });
      let filterDataExcel = [];
      let cntrow = 0;

      for (let i = 0; i < data.length; i++) {
        var arr = {
          SrNo: data[cntrow][0],
          UserId: data[cntrow][1],
          LoginTime: data[cntrow][2],
          LogoutTime: data[cntrow][3],
        };
        filterDataExcel.push(arr);
        cntrow++;
      }

      // Create Excel workbook and worksheet
      const worksheet = workbook.addWorksheet("LoginReport");

      // Define columns in the worksheet, these columns are identified using a key.
      worksheet.columns = [
        { header: "Sr. No.", key: "SrNo" },
        { header: "User Id", key: "UserId" },
        { header: "Login Time", key: "LoginTime" },
        { header: "Logout Time", key: "LogoutTime" },
      ];
      worksheet.columns = [
        { width: 15 },
        { width: 20 },
        { width: 15 },
        { width: 15 },
        { width: 15 },
      ];

      // loop through all of the columns and set the alignment with width.
      worksheet.columns.forEach((column) => {
        column.alignment = { horizontal: "center" };
      });

      // updated the font for first row.
      worksheet.getRow(1).font = { bold: true, color: { argb: "ffffff" } };

      // loop through data and add each one to worksheet
      filterDataExcel.forEach((singleData) => {
        worksheet.addRow(singleData);
      });

      // Add auto-filter on each column
      //worksheet.autoFilter = 'A1:D1';

      // Process each row for calculations and beautification
      worksheet.eachRow((row, rowNumber) => {
        row.eachCell((cell, colNumber) => {
          if (rowNumber == 1) {
            // First set the background of header row
            cell.fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "df5015" },
            };
          }
          // Set border of each cell
          cell.border = {
            top: { style: "thin" },
            left: { style: "thin" },
            bottom: { style: "thin" },
            right: { style: "thin" },
          };
        });
        //Commit the changed row to the stream
        row.commit();
      });

      //console.log(filterDataExcel);

      var today = new Date();
      var dateHeading =
        today.getDate() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getFullYear() +
        " " +
        today.getHours() +
        "_" +
        today.getMinutes() +
        "_" +
        today.getSeconds();
      // write the content using writeBuffer
      const buf = await workbook.xlsx.writeBuffer();

      // download the processed file
      saveAs(new Blob([buf]), "Login Report " + dateHeading + ".xlsx");
      //console.log(currentUser.user.username);
      MaximusAxios.post(
        "api/Logger/InsertUserActivityReport",
        {
          UserId: currentUser.user.username,
          PageName: capitalizedLocation,
          Activity: "Download Excel",
        },
        { headers: authHeader() }
      );

      setIsLoading(false);
    } catch (error) {
      console.error("<<<ERRROR>>>", error);
      console.error("Something Went Wrong", error.message);
    } finally {
      // removing worksheet's instance to create new one
      workbook.removeWorksheet("LoginReport");
    }
  };

  const onReset = (e) => {
    e.preventDefault();
    // window.location.reload(false);
    //setSelectedUserId(null);
    //setLoginData([]);
   // setOptionsUserId([]);
   // setStartDate(null);
    setEndDate(null);
  };

  $(document).ready(function () {
    if (LoginData !== null && LoginData.length > 0) {
      $("#gvMatchingList").DataTable();
    }
  });

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to excel
    </Tooltip>
  );

  return (
    <div className="configLeft dynamicContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          User Login Report
        </h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">User Login Report</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">User Login Report</p>
        </div>
      </div>
      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="unmatchedFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="unmatchedFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#unmatchedFiltersCollapse"
                aria-expanded="true"
                aria-controls="unmatchedFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="unmatchedFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="unmatchedFiltersHeading"
              data-bs-parent="#unmatchedFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlMode">UserId</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlReconType"
                      value={SelectedUserId}
                      classNamePrefix="reactSelectBox"
                      options={optionsUserId.map((x) => ({
                        value: x.iD,
                        label: x.userId,
                      }))}
                      loadOptions={fetchUserId}
                      onChange={handleUserId}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={onShowClick}
                    disabled={isShow}
                  >
                    Show
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Data Grid*/}
      <div className="configLeftBottom">
        <div>
          {(LoginData === null || LoginData.length === 0) && (
            <div className="tableBorderBox pb-3 pt-3">
              <div className="clientNameSelect configFormatEntities">
                <p className="text-danger font-size12">No Records</p>
              </div>
            </div>
          )}
          {isShow ? (
              <div className="spinner-container">
                <div className="loading-spinner"></div>
              </div>
            ) : (
              <>
              {(LoginData !== null && LoginData.length > 0) && (
                <>
          <div className="exportButton">
            <OverlayTrigger
              placement="top"
              delay={{ show: 150, hide: 400 }}
              overlay={renderTooltipExcel}
            >
              <button
                type="button"
                className="iconButtonBox"
                onClick={ExportToExcel}
              >
                <img src={ExcelIcon} alt="Excel" />
              </button>
            </OverlayTrigger>
          </div>
          <div className="tableBorderBox pt-3">
           
                <div className="w-100 table-responsive">
                  <div className="table-responsive tableContentBox">
                    <table
                      id="gvMatchingList"
                      className="table table-striped table-hover table-borderless align-middle"
                      style={{ width: "100%" }}
                    >
                      <thead>
                        <tr>
                          <th scope="col">Sr. No.</th>
                          <th scope="col">User ID</th>
                          <th scope="col">Login Time</th>
                          <th scope="col">Status </th>
                          <th scope="col">Logout Time</th>
                        </tr>
                      </thead>
                      <tbody>
                        {LoginData.map((item, index) => (
                          <tr key={index}>
                            <td>{index + 1}</td>{" "}
                            {/* Index starts from 0, so add 1 to make it 1-based */}
                            <td>{item.userId}</td>
                            <td>{item.loginTime}</td>
                            <td>{item.status}</td>
                            <td>{item.logoutTime}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
          </div>
          </>      )}
              </>
            )}
        </div>
      </div>
      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default UserLoginReportMainWindow;
