import React from "react";
import { useSelector } from "react-redux";
// CSS
import "./matchingRuleConfig.css";
// Components
import SidebarMain from "../common/SidebarMain";
import MatchingRuleMainWindow from "./matchingRuleConfigMainWindow";

const MatchingRule = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView d-flex">
      <SidebarMain />
      <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
              <MatchingRuleMainWindow />
      </div>
    </div>
  );
};

export default MatchingRule;
