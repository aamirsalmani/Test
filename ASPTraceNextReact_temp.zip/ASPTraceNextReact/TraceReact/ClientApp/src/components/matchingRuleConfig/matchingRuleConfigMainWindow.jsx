import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect  from 'react-select/async';
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL" ; 



import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
import { useSelector } from "react-redux"; 
import Delete from "../../images/common/redDelete.svg";
 
import "jspdf-autotable";

const optionsRuleType = [
    { value: "1", label: "Matching Rule" },
    { value: "2", label: "Settlement Rule" },
];

const MatchingRuleMainWindow = () => {

    const currentUser = useSelector((state) => state.authReducer);

    const fetchClientData = (inputValue) => {
        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }


    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }


    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);


    const handleInputChange = value => {
        setValue(value);
    };


    const [optionsChannelType, setOptionsChannelTypeValue] = useState([{ channelID: "0", channelName: "--Select--" }]);
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);
    const [selectedRuleTypeValue, setSelectedRuleTypeValue] = useState(null);

    const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "--Select--" }]);
    const [selectedModeValue, setSelectedModeValue] = useState(null);


    const handleOptionsChannelType = value => {
        setOptionsChannelTypeValue(value);
    };

    const handleOptionsModeType = value => {
        setOptionsModeTypeValue(value);
    };

    const [MatchingList, setMatchingList] = useState(null);
    const [selectedTablesValue, setSelectedTablesValue] = useState(null);
    const [ModeMatchingColumnList, setModeMatchingColumnList] = useState([]);
    const [selectedColumnList, setSelectedColumnList] = useState([]);

    const handleClientChange = value => {

        setSelectedValue(value);
        setSelectedChannelValue(null);

        if (value.clientID !== '0') {
            MaximusAxios.get('/api/MatchingRule/GetChannelMatchingList?ClientId=' + value.clientID, {  mode: 'cors' }).then(result => {
                handleOptionsChannelType(result.data);
            });

            return MaximusAxios.get('/api/MatchingRule/GetMatchingGrid?ClientId=' + value.clientID, {  mode: 'cors' }).then(result => {
                setMatchingList(result.data);
            });
        }
    }


    const handleChannelChange = value => {

        setSelectedChannelValue(value);

        //if (value.value === '1') 
        if (value.value !== '0' && selectedValue.clientID !== '0') {
            return MaximusAxios.get('/api/MatchingRule/GetImportConfigModes?ClientID=' + selectedValue.clientID + '&ChannelID=' + value.value, {  mode: 'cors' }).then(result => {
                handleOptionsModeType(result.data);
                setSelectedModeValue(null);
                setSelectedTablesValue(null);
                setModeMatchingColumnList([]);
            });
        }


    }

    const handleRuleTypeChange = value => {
        setSelectedRuleTypeValue(value);

    }


    const handleModeChange = value => {

        setSelectedModeValue(value);

        if (value !== null && selectedChannelValue !== null) {
            MaximusAxios.get('/api/MatchingRule/GetImportTables?ClientID=' + selectedValue.clientID + '&ChannelID=' + selectedChannelValue.value + '&ModeID=' + value.value, {  mode: 'cors' }).then(result => {
                setSelectedTablesValue(result.data);
            });

            return MaximusAxios.get('/api/MatchingRule/GetMatchingColumns?ClientID=' + selectedValue.clientID + '&ChannelID=' + selectedChannelValue.value + '&ModeID=' + value.value, {  mode: 'cors' }).then(resultColumn => {

                let ColumnValue = [];
                for (let cntrow = 0; cntrow < resultColumn.data.length; cntrow++) {
                    var arrP = { "TableName": resultColumn.data[cntrow].tableName, "ColumnName": resultColumn.data[cntrow].columnName };
                    ColumnValue.push(arrP);
                }

                setModeMatchingColumnList(ColumnValue);
                //console.log(ColumnValue);
            });
        }

        setSelectedColumnList([]);

    }

    const [selectedMatchingColumnValue, setSelectedMatchingColumnValue] = useState([]);

    const handleColumnChange = Value => {
        setSelectedMatchingColumnValue(Value);
        //const newItem = { "ColumnName": Value.value };
        //selectedColumnList.push(newItem); 
    }



    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });


    const onSubmit = () => {

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            alert("Please select Channel!");
            return false;
        }

        if (selectedRuleTypeValue === undefined || selectedRuleTypeValue === null) {
            alert("Please select Rule Type!");
            return false;
        }

        if (selectedModeValue === undefined || selectedModeValue === null) {
            alert("Please select mode Type!");
            return false;
        }

        //console.log(selectedModeValue);

        let ChannelId = 0;

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = selectedChannelValue.value;
        }

        let RuleType = '';

        if (selectedRuleTypeValue === undefined || selectedRuleTypeValue === null) {
            RuleType = '';
        }
        else {
            RuleType = selectedRuleTypeValue.value;
        }

        let ModeId = "";

        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.value;
        }

        let SelectedColumns = '';

        for (var i = 0; i < selectedColumnList.length; i++) {
            SelectedColumns = SelectedColumns + selectedColumnList[i]['ColumnName'] + ','
        }

        //console.log(SelectedColumns);

        MaximusAxios.post('/api/MatchingRule/AddMatchingRuleConfig', {
            ClientID: selectedValue.clientID,
            SelectedColumn: SelectedColumns,
            ChannelID: ChannelId,
            ModeID: ModeId,
            RuleType: RuleType,
            Username: 'Sayali',
        }, {  mode: 'cors' })
            .then(function (response) {
                if (response.data === null || response.data.length === 0) { alert('No records found'); }
                else {
                    MaximusAxios.get('/api/MatchingRule/GetMatchingGrid?ClientId=' + selectedValue.clientID, {  mode: 'cors' }).then(result => {
                        setMatchingList(result.data);
                    });
                    alert(response.data);
                    setSelectedColumnList([]);
                }
            });

    };

    const onAdd = () => {

        let ColumnFound = false;

        let RuleType = '';

        if (selectedRuleTypeValue === undefined || selectedRuleTypeValue === null) {
            RuleType = '';
        }
        else {
            RuleType = selectedRuleTypeValue.label;
        }

        let ChannelId = '';

        if (selectedChannelValue === undefined || selectedChannelValue === null) {
            ChannelId = '';
        }
        else {
            ChannelId = selectedChannelValue.label;
        }

        let ModeId = "";

        if (selectedModeValue === undefined || selectedModeValue === null) {
            ModeId = 0;
        }
        else {
            ModeId = selectedModeValue.label;
        }

        if (selectedColumnList !== null && selectedColumnList !== undefined) {

            if (selectedColumnList.length > 0) {
                for (var i = 0; i < selectedColumnList.length; i++) {
                    if (selectedColumnList[i]['ColumnName'] === selectedMatchingColumnValue.value) {
                        ColumnFound = true;
                    }
                }
            }
        }

        if (ColumnFound) {
            alert('ColumnName Already Present');
        }
        else {
            const newItem = { "ColumnName": selectedMatchingColumnValue.value, "RuleType": RuleType, "ChannelId": ChannelId, "ModeId": ModeId };
            //selectedColumnList.push(newItem); 
            setSelectedColumnList([...selectedColumnList, newItem]);
        }
    } 

    const onDeleteClick = (ClientIDValue, ChannelIDValue, ModeIDValue, RuleTypeValue) => {
        MaximusAxios.post('/api/MatchingRule/DeleteMatchingRuleConfig', {
            ClientID: ClientIDValue,
            ChannelID: ChannelIDValue,
            ModeID: ModeIDValue,
            RuleType: RuleTypeValue,
        }, {  mode: 'cors' })
            .then(function (response) {
                if (response.data === null || response.data.length === 0) { alert('No records found'); }
                else { alert(response.data); }

                MaximusAxios.get('/api/MatchingRule/GetMatchingGrid?ClientId=' + selectedValue.clientID, {  mode: 'cors' }).then(result2 => {
                    setMatchingList(result2.data);
                });
            });
    };


    return (
        <div className="configLeft matchingruleContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Matching Rule
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Daily Reports</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Matching Rule</p>
                </div>
            </div>

            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="matchingruleFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="matchingruleFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>
                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#matchingruleFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="matchingruleFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="matchingruleFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="matchingruleFiltersHeading"
                            data-bs-parent="#matchingruleFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedChannelValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            onChange={handleChannelChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col" id="dvRuleType">
                                        <label htmlFor="ruletype">Rule Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            defaultValue={selectedRuleTypeValue}
                                            options={optionsRuleType}
                                            id="ddlruletype"
                                            onChange={handleRuleTypeChange}
                                            classNamePrefix="reactSelectBox"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedModeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.transactionMode
                                                }
                                            ))}
                                            onChange={handleModeChange}
                                        />
                                    </div>


                                </div>

                                {(selectedTablesValue !== null && selectedTablesValue.length > 0) ? (
                                    <div className="configSelectBoxTop row">
                                        {
                                            selectedTablesValue.map((p, i) => {
                                                return <div className="clientNameSelect col" key={i}>
                                                    <label htmlFor={p.tableName}>{p.tableName}</label>
                                                    <span className="text-danger font-size13">*</span>
                                                    <Select
                                                        options={ModeMatchingColumnList.filter(t => t.TableName === p.tableName).map(x => (
                                                            {
                                                                value: x.ColumnName,
                                                                label: x.ColumnName
                                                            }))}
                                                        id={p.tableName}
                                                        value={selectedMatchingColumnValue}
                                                        onChange={handleColumnChange}
                                                        classNamePrefix="reactSelectBox"
                                                    />
                                                </div>
                                            })
                                        }
                                        <div className="clientNameSelect col">
                                            <div style={{ paddingTop: "22px" }}>
                                                <button
                                                    type="button"
                                                    className="btnPrimary ms-2"
                                                    onClick={(e) => onAdd(e)}
                                                >
                                                    Add
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                ) : null}

                                {(selectedColumnList !== null && selectedColumnList.length > 0) ? (
                                    <div className="configSelectBoxTop row">
                                        <div className="tableBorderBox pt-3">
                                            <div className="w-100 table-responsive">
                                                <div className="table-responsive tableContentBox" >
                                                    <table id="gvMatchingList" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                                        <thead>
                                                            <tr>
                                                                <th scope="col">Sr. No.</th>
                                                                <th scope="col">Selected Column</th>
                                                                <th scope="col">Rule Type</th>
                                                                <th scope="col">Channel</th>
                                                                <th scope="col">Mode</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            {
                                                                selectedColumnList.map((p, i) => {
                                                                    return <tr key={i}>
                                                                        <td >{i + 1}</td>
                                                                        <td >{p.ColumnName}</td>
                                                                        <td >{p.RuleType}</td>
                                                                        <td >{p.ChannelId}</td>
                                                                        <td >{p.ModeId}</td>
                                                                    </tr>
                                                                })
                                                            }

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ) : null}

                                <div className="configSelectBoxTop row">
                                    <div className="text-center btnsBtm">
                                        <button
                                            type="button"
                                            className="btnPrimaryOutline"
                                            onClick={(e) => onReset(e)}
                                        >
                                            Reset
                </button>
                                        <button
                                            type="button"
                                            className="btnPrimary ms-2"
                                            onClick={onSubmit}
                                        >
                                            Submit
                </button>

                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="configLeftBottom">
                {(MatchingList !== null && MatchingList.length > 0) ? (
                    <div>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvMatchingList" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                        <thead>
                                            <tr>
                                                <th scope="col">Client Name</th>
                                                <th scope="col">Channel</th>
                                                <th scope="col">Mode Name</th>
                                                <th scope="col">Recon Type</th>
                                                <th scope="col">Import File Status</th>
                                                <th scope="col">Matching Rule Status</th>
                                                <th scope="col">Settlement Rule Status</th>
                                                <th scope="col">Matching Rule Selected Columns</th>
                                                <th scope="col">Settlement Rule Selected Columns</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                MatchingList.map((p, i) => {
                                                    return <tr key={i} >
                                                        <td >{p.clientName} </td>
                                                        <td >{p.channelName} </td>
                                                        <td >{p.matchingModeName}</td>
                                                        <td >{p.reconName}</td>
                                                        <td className={p.importFileStatus == 'Done' ? 'FileStatusGreen' : 'FileStatusRed'}>{p.importFileStatus}</td>
                                                        <td >{p.matchingRuleStatus} </td>
                                                        <td >{p.settlementRuleStatus} </td>
                                                        <td >{p.matchingRuleSelectedColumns}
                                                            {
                                                                (p.matchingRuleStatus === 'Done' ) ? (
                                                                    <button type="button" className="iconButtonBox" onClick={() => onDeleteClick(p.clientID, p.channelID, p.modeID, 1)} >
                                                                        <img src={Delete} alt="Delete" title="Delete" />
                                                                    </button>) : null
                                                            }
                                                        </td>
                                                        <td >{p.settlementRuleSelectedColumns} {
                                                            (p.settlementRuleStatus === 'Done') ? (
                                                                <button type="button" className="iconButtonBox" onClick={() => onDeleteClick(p.clientID, p.channelID, p.modeID, 2)} >
                                                                    <img src={Delete} alt="Delete" title="Delete" />
                                                                </button>) : null
                                                        }</td>
                                                    </tr>
                                                })
                                            }

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
            </div>
            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />


        </div>
    );
};

export default MatchingRuleMainWindow;
