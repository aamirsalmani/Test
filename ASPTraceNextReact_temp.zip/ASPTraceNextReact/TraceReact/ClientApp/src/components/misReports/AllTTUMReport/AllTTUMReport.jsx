﻿import React from "react";
import { useSelector } from "react-redux";
// Components
import SidebarMain from "../../common/SidebarMain";
import AllTTUMReportMainWindow from "./AllTTUMReportMainWindow";

const AllTTUMReport = () => {
  const company = useSelector((state) => {
    return state.sidebarReducer;
  });

  return (
    <div className="mainView d-flex">
      <SidebarMain />
      <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
        <AllTTUMReportMainWindow />
      </div>
    </div>
  );
};

export default AllTTUMReport;
