﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import ATMTtumReportMainWindow from "./ATMTtumReportMainWindow";

const ATMTtumReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView d-flex">
            <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
                <ATMTtumReportMainWindow />
            </div>
        </div>
    );
};

export default ATMTtumReport;
