import React, { useState ,useEffect } from "react";
import { useLocation,Link   } from "react-router-dom";
import { useSelector } from "react-redux";
import AsyncSelect from 'react-select/async';
import { Modal,Tooltip, OverlayTrigger } from "react-bootstrap";
import DatePicker from "react-datepicker";
import authHeader from "../../../pages/login/services/auth-header";
import { saveAs } from 'file-saver';
import Select from "react-select";

import MaximusAxios from "../../common/apiURL" ;

import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';


import ExcelJS from "exceljs";

import ExcelIcon from "../../../images/common/excel.svg"; 

import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";


import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";


const ATMTtumReportMainWindow = () => {

    
    let location = useLocation();
    let capitalizedLocation = location.pathname.replace(/\b\w/g, char => char.toUpperCase());
    const [userRole,setUserRole]=useState(null);
    const [isShow, setIsLoading] = useState(false);
    const [isPendingPresent, setIsPendingPresent] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });
    const [startDate, setStartDate] = useState(new Date());
    const [ConfirmEntry,setConfirmEntry] = useState(false);
    const [showModal ,setshowModal] = useState(false);
    const [endDate, setEndDate] = useState(new Date());
    const[TTUMReport , setTTUMReport]=useState(null);
    const [selectedValue, setSelectedValue] = useState(null);
    const [optionsChannelType, setOptionsChannelType] = useState([{ channelID: "0", channelName: "ALL" }]);
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);
    const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "ALL" }]);
    const [selectedModeValue, setSelectedModeValue] = useState(null);
    const [optionsNetworkType, setOptionsNetworkTypeValue] = useState([{ vendorID: "0", vendorName: "ALL" }]);
    const [selectedNetworkValue, setSelectedNetworkValue] = useState(null);
    const [selectedTtumValue, setSelectedTtumValue] = useState(null);
    const [selectedCurrencyTypeValue, setSelectedCurrencyTypeValue] = useState([{ CurrencyTypeID: '3', CurrencyTypeType: 'N.A.'}]);
    const [CurrencyTypeChangeFlag, setCurrencyTypeChangeFlag] = useState(false);
    const[CheckerStatus,setCheckerStatus] = useState(null);
    const [allChecked, setAllChecked] = useState(false);
    const [checkedRows, setCheckedRows] = useState(new Set());
    const [tempTTumReport, setTempTTumReport] = useState(new Set());
    const [selectedCheckerStatus, setSelectedCheckerStatus] = useState(null);

    const handleMasterCheckboxChange = (event) => {
        const isChecked = event.target.checked;
        setAllChecked(isChecked);
        const newCheckedRows = new Set();

        if (isChecked) {
            TTUMReport.forEach((_, index) => newCheckedRows.add(index));
        }

        setCheckedRows(newCheckedRows);
        updateTempTTumReport(newCheckedRows);
    };

    const handleRowCheckboxChange = (event) => {
        const rowIndex = parseInt(event.target.dataset.rowindex, 10);
        const isChecked = event.target.checked;
        const newCheckedRows = new Set(checkedRows);

        if (isChecked) {
            newCheckedRows.add(rowIndex);
        } else {
            newCheckedRows.delete(rowIndex);
        }

        setCheckedRows(newCheckedRows);
        setAllChecked(newCheckedRows.size === TTUMReport.length);

        updateTempTTumReport(newCheckedRows);
    };

    const updateTempTTumReport = (newCheckedRows) => {
        const updatedReport = new Set();

        newCheckedRows.forEach(rowIndex => {
            updatedReport.add(TTUMReport[rowIndex]);
        });

        setTempTTumReport(updatedReport);
    };

   
    useEffect(() => {
    }, [tempTTumReport]);

    useEffect(() => {
        getRole();
    }, []);


    const getRole = () => {
        MaximusAxios.get('api/Common/GetUserRole?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            setUserRole(result.data);
        })
    }



    const currentUser = useSelector((state) => state.authReducer);

    const onReset = (e) => {
        e.preventDefault();
        window.location.reload(false);
    }

   
    const fetchClientData = (inputValue) => {
        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }


    


    const optionsTtumType = [
        { ttumID: '0', ttumType: 'ALL' },
        { ttumID: '1', ttumType: 'Credit Adjustment TTUM' }
    ];

    const optionsCheckerStatus = [
        { statusID: '0', statusType: 'ALL' },
        { statusID: '1', statusType: 'CheckerPending' },
        { statusID: '2', statusType: 'CheckerConfirm' },
        { statusID: '3', statusType: 'CheckerReject' },
    ];

    const optionsCkeckerStatus = [
        { ID: 1 ,RemarkByChecker : 'Approve' },
        { ID: 2 ,RemarkByChecker : 'Reject' }
    ];

    const optionsCurrencyType = [
        { CurrencyTypeID: '0', CurrencyTypeType: 'ALL' },
        { CurrencyTypeID: '1', CurrencyTypeType: 'Domestic' },
        { CurrencyTypeID: '2', CurrencyTypeType: 'International' }
    ];

    const handleInputChange = value => {
    };


    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];




    const handleClientChange = value => {
        setSelectedValue(value);
        setSelectedChannelValue(null);
        setSelectedCheckerStatus(null);
        setSelectedModeValue(null);
        try {
            setIsLoading(true);
            if (value.clientID !== '0') {
                MaximusAxios.get('api/Common/GetChannelOptionList?ClientId=' + value.clientID + '&UserID=' + currentUser.user.username, {  mode: 'cors' }).then(resultChannel => {
                    setOptionsChannelType(resultChannel.data);
                    setIsLoading(false);
                });}
            }
        catch (ex) {
            console.log(ex);
            setIsLoading(false);
        }
    }

    const handleChannelChange = value => {
        setSelectedChannelValue(value);
        setSelectedModeValue(null);
        setSelectedNetworkValue(null);
        setSelectedCheckerStatus(null);
        setSelectedTtumValue(null); 
        setCurrencyTypeChangeFlag(false);       
        setTTUMReport(null);
        setSelectedCurrencyTypeValue(null);
        setStartDate(null);
        setEndDate(null);
        let ChannelId = 0;
        if (value === undefined || value === null) {
            ChannelId = 0;
        }
        else {
            ChannelId = value.value;
        }
        setIsLoading(true);
        MaximusAxios.get('api/Common/GetModeOptionList?ClientID=' + selectedValue.clientID + '&ChannelID=' + ChannelId + '&UserID=' + currentUser.user.username, {  mode: 'cors' }).then(resultMode => {
            setOptionsModeTypeValue(resultMode.data);
        });
        setIsLoading(false);
    }
    const handleModeChange = value => {
        setSelectedModeValue(value);
        setSelectedNetworkValue(null);
        setSelectedTtumValue(null); 
        setCurrencyTypeChangeFlag(false);       
        setTTUMReport(null);
        setSelectedCurrencyTypeValue(null);
        setSelectedCheckerStatus(null);
        setStartDate(null);
        setEndDate(null);
        setIsLoading(true);
        MaximusAxios.get('api/DynamicReconConfig/GetNetworkList?ClientID=' + selectedValue.clientID , {  mode: 'cors' }).then(resultMode => {
            setOptionsNetworkTypeValue(resultMode.data);
        });
        setIsLoading(false);
    }
    const handleNetworkChange = value => {
        setSelectedNetworkValue(value);
        setSelectedTtumValue(null); 
        setCurrencyTypeChangeFlag(false);       
        setTTUMReport(null);
        setSelectedCurrencyTypeValue(null);
        setSelectedCheckerStatus(null);
        setStartDate(null);
        setEndDate(null);
    }
    const handleTtumChange = value => {
        setSelectedTtumValue(value);
        if(selectedNetworkValue.label==='VISA' && selectedChannelValue.value==2 && value.value==3)
        {
            setCurrencyTypeChangeFlag(true);
        }
        else{
            setCurrencyTypeChangeFlag(false);
        }
        setTTUMReport(null);
        setSelectedCheckerStatus(null);
        setSelectedCurrencyTypeValue(null);
        setStartDate(null);
        setEndDate(null);
    }
    const handleCurrencyTypeChange = value => {
        setSelectedCurrencyTypeValue(value);
        setSelectedCheckerStatus(null);
        setTTUMReport(null); 
        setStartDate(null);
        setEndDate(null);
    }
    

    const setStartDateValue = value => {
        setSelectedCheckerStatus(null);
        setStartDate(value);
        setEndDate(null);
        setTTUMReport(null);
    }
    
    const handleCheckerStatus = value => {
        setSelectedCheckerStatus(value);
    }

    const setEndDateValue = value => {

        if (startDate === null) {
            setEndDate(null);
            alert('Please enter From date first.');
        }
        else {
            if (startDate > value) {
                alert('To date must be greater than From date. ');
                setEndDate(null);
            }
            else {
                setEndDate(value);
            }
        }
        setTTUMReport(null);
    }


    const renderTooltip = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to pdf
        </Tooltip>
    );

    const renderTooltipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to excel
        </Tooltip>
    );



    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }




    const onShow = () => {
        setCheckedRows(new Set());
        setAllChecked(false);
        setTTUMReport(null);

        if (selectedValue === null || selectedValue.clientID === undefined) {
            alert("Please select client!");
            return false;
        }

        if (selectedChannelValue === null || selectedChannelValue === undefined) {
            alert("Please select channel!");
            return false;
        }

        if (selectedModeValue === undefined || selectedModeValue === null) {
            alert("Please select mode");
            return false;
        }

        if (selectedNetworkValue === undefined || selectedNetworkValue === null) {
            alert("Please select network type");
            return false;
        }

        if (selectedTtumValue === undefined || selectedTtumValue === null) {
            alert("Please select TTUM type!");
            return false;
        }
        
        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }
        if (selectedCheckerStatus === undefined || selectedCheckerStatus === null) {
            alert("Please enter To Checker Status!");
            return false;
        }

        let currencyType = (selectedCurrencyTypeValue === null || selectedCurrencyTypeValue === undefined) ? 'N.A.' :  selectedCurrencyTypeValue.label ;

        setIsLoading(true);

        MaximusAxios.post('api/Report/GetCreditAdjustmentTTUM', {
            ClientID: selectedValue.clientID,
            ChannelID: selectedChannelValue.value,
            ModeID: selectedModeValue.value,
            NetworkID: selectedNetworkValue.value,
            CurrencyType : currencyType,
            TTUMReportType: selectedTtumValue.value,
            FromDateTxns: formatDate(startDate),
            ToDateTxns: formatDate(endDate),
            CheckerStatus: selectedCheckerStatus.label

        }, {  mode: 'cors' })
            .then(function (response) {
                setTTUMReport(response.data);
                setIsPendingPresent(false);
                response.data.map((item) => {
                        if(item.checkerRemarks === null)
                            {
                                setIsPendingPresent(true);
                            }
                });
                setIsLoading(false);
                if (response.data === null || response.data.length === 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'No records found' }); }
            })
            .catch(function (error) {
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setIsLoading(false);
            });
    };

    const downloadExcel = () => {
        

        MaximusAxios.post('api/Logger/InsertUserActivityReport', 
            { UserId: currentUser.user.username,PageName: capitalizedLocation ,Activity:'Download Excel' }, { headers: authHeader()})

        let FileName = selectedChannelValue.label + selectedTtumValue.label +'Report_'  + formatDate(startDate) + '.xlsx'

        MaximusAxios.post('api/Report/ExportCheckedExcelReport', {
            ClientID: selectedValue.clientID,
            ChannelID: selectedChannelValue.value,
            ModeID: selectedModeValue.value,
            NetworkID: selectedNetworkValue.value,
            CurrencyType : 'N.A.',
            TTUMReportType: selectedTtumValue.value,
            FromDateTxns: formatDate(startDate),
            ToDateTxns: formatDate(endDate),
            CheckerStatus : selectedCheckerStatus.label

        }, {  responseType: 'blob', })
            .then(function (response) {
                saveAs(response.data, FileName);
                setIsLoading(false);
            })
            .catch(function (error) {
            
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                console.log(error.response);
                setIsLoading(false);
        });
    };

    const getColumnHeaders = () => {
        if (TTUMReport.length === 0) return []; 
        return Object.keys(TTUMReport[0]);
    };


    $(document).ready(function () {

        if (TTUMReport !== null && TTUMReport.length > 0) {
            $('#gvPOSTTUMReportPDF').DataTable();
        }
    });

    function capitalizeKeys(obj) {
        if (obj === null || typeof obj !== 'object') {
            return obj; 
        }
    
        if (Array.isArray(obj)) {
            return obj.map(item => capitalizeKeys(item)); 
        }
    
        const newObj = {};
        Object.keys(obj).forEach(key => {
            const capitalizedKey = key.charAt(0).toUpperCase() + key.slice(1);
            newObj[capitalizedKey] = capitalizeKeys(obj[key]); 
        });
    
        return newObj;
    }

    const onSubmit = () =>{
        
        if (checkedRows.size > 0) {
            setAllChecked(false);
            setCheckerStatus(null);
            setConfirmEntry(true);
            setshowModal(true);
        } else {
            alert('Please select at least one row before submitting.');
            return;
        }
        

    }

    const onSubmitAfterCheck = () => {


        if (checkedRows.size > 0) {
        } else {
            alert('Please select at least one row before submitting.');
            return;
        }
        if (CheckerStatus === null || CheckerStatus === undefined) {
            alert('Please select Checker Remarks.');
            return;
          }
        
          let checkerRemarksField =CheckerStatus.label;


        const tempTTumReportArray = Array.from(tempTTumReport);
        const modifiedObject = capitalizeKeys(tempTTumReportArray);
        const serializedArray = JSON.stringify(modifiedObject);

        if (selectedValue === null || selectedValue.clientID === undefined) {
            alert("Please select client!");
            return false;
        }

        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        }

        if (endDate === undefined || endDate === null) {
            alert("Please enter To Date!");
            return false;
        }
        if (selectedChannelValue === null || selectedChannelValue === undefined) {
            alert("Please select channel!");
            return false;
        }

        if (selectedModeValue === undefined || selectedModeValue === null) {
            alert("Please select mode");
            return false;
        }

        if (selectedNetworkValue === undefined || endDate === null) {
            alert("Please select network type");
            return false;
        }

        if (selectedTtumValue === undefined || selectedTtumValue === null) {
            alert("Please select TTUM type!");
            return false;
        }
        
        if (selectedCheckerStatus === undefined || selectedCheckerStatus === null) {
            alert("Please enter To Checker Status!");
            return false;
        }

        MaximusAxios.post('api/Logger/InsertUserActivityReport', 
            { UserId: currentUser.user.username,PageName: capitalizedLocation ,Activity :'Checker '+ checkerRemarksField }, { headers: authHeader()})


        setIsLoading(true);
        MaximusAxios.post('api/Report/UpdateCheckedData', {
            ClientID: selectedValue.clientID,
            ChannelID: selectedChannelValue.value,
            ModeID: selectedModeValue.value,
            NetworkID: selectedNetworkValue.value,
            CurrencyType: 'N.A.',
            TTUMReportType: selectedTtumValue.value,
            FromDateTxns: formatDate(startDate),
            ToDateTxns: formatDate(endDate),
            UserName : String(currentUser.user.username),
            CheckerRemarks:checkerRemarksField,
            TempTTumReport: serializedArray ,
        }, {  mode: 'cors' })
            .then(function (response) {
                setTTUMReport(response.data);
                setConfirmEntry(false);
                setshowModal(false);
                setIsLoading(false);
                onShow();
            })
            .catch(function (error) {
                if (error.response) {
                    console.log(error.response);
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setConfirmEntry(false);
                setshowModal(false);
                setIsLoading(false);
            });

    }
   
    const handleCheckerRemark = value => {
        
        setCheckerStatus(value);
    }

    


    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    NPCI TTUM Report
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12 colorPrimaryDefault">MIS Reports</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                        <p className="fontSize12">NPCI TTUM Report</p>
                </div>
            </div>

            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="posttumreportFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="posttumreportFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>
                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#posttumreportFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="posttumreportFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="posttumreportFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="posttumreportFiltersHeading"
                            data-bs-parent="#posttumreportFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlChannel">Channel Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlChannel"
                                            value={selectedChannelValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsChannelType.map(x => (
                                                {
                                                    value: x.channelID,
                                                    label: x.channelName
                                                }
                                            ))}
                                            onChange={handleChannelChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlMode">Mode Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlMode"
                                            value={selectedModeValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsModeType.map(x => (
                                                {
                                                    value: x.modeID,
                                                    label: x.modeName
                                                }
                                            ))}
                                            onChange={handleModeChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlNetworkType">Network Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlNetworkType"
                                            value={selectedNetworkValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsNetworkType.map(x => (
                                                {
                                                    value: x.vendorID,
                                                    label: x.vendorName
                                                }
                                            ))}
                                            onChange={handleNetworkChange}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlttumType">TTUM Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlttumType"
                                            value={selectedTtumValue}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsTtumType.map(x => (
                                                {
                                                    value: x.ttumID,
                                                    label: x.ttumType
                                                }
                                            ))}
                                            onChange={handleTtumChange}
                                        />
                                    </div>
                                    {(CurrencyTypeChangeFlag) && (
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlttumType">Currency Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        {/* Conditionally render the Select component */}
                                            <Select
                                                id="ddlttumType"
                                                value={selectedCurrencyTypeValue}
                                                classNamePrefix="reactSelectBox"
                                                options={optionsCurrencyType.map(x => ({
                                                    value: x.CurrencyTypeID,
                                                    label: x.CurrencyTypeType
                                                }))}
                                                onChange={handleCurrencyTypeChange}
                                            />
                                    </div>)}

                                    <div className="clientNameSelect col">
                                        <label htmlFor="StartDate">From Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                            selected={startDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setStartDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ToDate">To Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                    <div
                                                        style={{
                                                            margin: 1,
                                                            display: "flex",
                                                            justifyContent: "center",
                                                        }}
                                                    >
                                                        <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                        </button>
                                                        <select
                                                            value={getYear(date)}
                                                            onChange={({ target: { value } }) => changeYear(value)}
                                                        >
                                                            {years.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <select
                                                            value={months[getMonth(date)]}
                                                            onChange={({ target: { value } }) =>
                                                                changeMonth(months.indexOf(value))
                                                            }
                                                        >
                                                            {months.map((option) => (
                                                                <option key={option} value={option}>
                                                                    {option}
                                                                </option>
                                                            ))}
                                                        </select>

                                                        <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                            <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                        </button>
                                                    </div>
                                                )}
                                            selected={endDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setEndDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="ddlttumType">Checker Status</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlttumType"
                                            value={selectedCheckerStatus}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsCheckerStatus.map(x => (
                                                {
                                                    value: x.statusID,
                                                    label: x.statusType
                                                }
                                            ))}
                                            onChange={handleCheckerStatus}
                                        />
                                    </div>
                                </div>

                                <div className="text-center btnsBtm">
                                    <button
                                        type="button"
                                        className="btnPrimaryOutline"
                                        onClick={(e) => onReset(e)}
                                    >
                                        Reset
                                    </button>
                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onShow}
                                    >
                                        Show
                                    </button>
                                    {(userRole ==='Checker')&&<button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onSubmit}
                                    >
                                        Submit
                                    </button>}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            {/* Bottom Content */}
            <div className="configLeftBottom">
                {(TTUMReport === null || TTUMReport.length === 0) &&
                    <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div>
                }
                {/* Table */}

                {(TTUMReport !== null && TTUMReport.length > 0) ? (
                    <div>
                        <div className="exportButton">

                            <OverlayTrigger
                                placement="top"
                                delay={{ show: 150, hide: 400 }}
                                overlay={renderTooltipExcel}
                            >
                                <button type="button" className="iconButtonBox" onClick={downloadExcel}>
                                    <img src={ExcelIcon} alt="Excel" />
                                </button>
                            </OverlayTrigger>
                        </div>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvPOSTTUMReportPDF" className="table table-striped table-hover table-borderless align-middle"  >
                                    <thead>
                                    <tr>
                                    <th scope="col">
                                              CheckerRemark
                                              {(userRole === 'Checker' && isPendingPresent) && (
                                                <input
                                                  type="checkbox"
                                                  id="masterCheckbox"
                                                  checked={allChecked}
                                                  onChange={handleMasterCheckboxChange}
                                                />
                                              )}
                                            </th>
                                            <th scope="col">Bank Adjustment Reference</th>
                                            <th scope="col">Dr Cr</th>
                                            <th scope="col">Txns Date</th>
                                            <th scope="col">Txns Amount</th>
                                            <th scope="col">Reference Number</th>
                                            <th scope="col">Terminal Id</th>
                                            <th scope="col">EJ Status</th>
                                            <th scope="col">SW Status</th>
                                            <th scope="col">NW Status</th>
                                            <th scope="col">GL Status</th>
                                            <th scope="col">Error Code</th>
                                            <th scope="col">Network Date</th>
                                            <th scope="col">Maker ID</th>
                                            <th scope="col">Maker Remark</th>
                                            <th scope="col">Checker ID</th>
                                            <th scope="col">Upload</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        { TTUMReport.map((p, rowindex) => (
                                            <tr key={rowindex}>
                                                {(userRole ==='Checker')?(<td>
                                                    {p.checkerID === null ? (
                                                        <input
                                                            type="checkbox"
                                                            className="rowCheckbox"
                                                            data-rowindex={rowindex}
                                                            checked={checkedRows.has(rowindex)}
                                                            onChange={handleRowCheckboxChange}
                                                        />
                                                    ) : (
                                                        <span>{p.checkerRemarks || 'pending'}</span> 
                                                    )}
                                                </td>):<td>{p.checkerRemarks || 'pending'}</td>}
                                                <td>{p.bankAdjustmentReference}</td>
                                                <td>{p.drCr}</td>
                                                <td>{p.txnsDate}</td>
                                                <td>{p.txnsAmount}</td>
                                                <td>{p.referenceNumber}</td>
                                                <td>{p.terminalId}</td>
                                                <td>{p.ejStatus}</td>
                                                <td>{p.swStatus}</td>
                                                <td>{p.nwStatus}</td>
                                                <td>{p.glStatus}</td>
                                                <td>{p.errorCode}</td>
                                                <td>{p.networkDate}</td>
                                                <td>{p.makerID}</td>
                                                <td>{p.makerRemarks}</td>
                                                <td>{p.checkerID}</td>
                                                <td>{(p.checkerRemarks ==='Approve') ? 'Succesful' : ''}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
                <div>
                <Modal
                    centered
                    className="AddNewTableModal"
                    size='xl'
                    show={showModal && ConfirmEntry}
                    onHide={() => setshowModal(false)}>
                    <Modal.Header closeButton>
                        <Modal.Title>Checker Status Confirmation</Modal.Title>
                    </Modal.Header>
                    <Modal.Body size='xl'>
                        <div
                            id="unmatchedFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="unmatchedFiltersHeading"
                            data-bs-parent="#unmatchedFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                {(TTUMReport != null && TTUMReport.length > 0) ? (
                                <div>
                                   <div className="clientNameSelect col">
                                        <label htmlFor="ddlttumType">TTUM Type</label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            id="ddlttumType"
                                            value={CheckerStatus}
                                            classNamePrefix="reactSelectBox"
                                            options={optionsCkeckerStatus.map(x => (
                                                {
                                                    value: x.ID,
                                                    label: x.RemarkByChecker
                                                }
                                            ))}
                                            onChange={handleCheckerRemark}
                                        />
                                    </div>
                                </div>
                                ) : null}
                                </div>
                              
                            </div>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onSubmitAfterCheck}
                                    >Submit
                                    </button>
                    </Modal.Footer>
                </Modal>
            </div>
            </div>
            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />


        </div>
    );
};

export default ATMTtumReportMainWindow;
