﻿import React from "react";
import { useSelector } from "react-redux"; 
// Components
import SidebarMain from "../../common/SidebarMain";
import DispenseReportMainWindow from "./DispenseReportMainWindow";

const DispenseReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <DispenseReportMainWindow />
        </div>
    );
};

export default DispenseReport;
