﻿import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from "react-select/async";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL";
import { useSelector } from "react-redux";
import TransactionDetails from "../../common/TransactionDetails";
import { parse } from "date-fns";
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";

import $ from "jquery";
import "jquery/dist/jquery.min.js";

import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
// Images
import Pdf from "../../../images/common/pdf.svg";
import ExcelIcon from "../../../images/common/excel.svg";

import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";

import jsPDF from "jspdf";
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";

const optionsTxnType = [
  { value: "1", label: "Withdrawal" },
  { value: "2", label: "Deposit" },
];

const DispenseReportMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);
  const [dispensesummaryjobdetails, setDispensesummaryjobdetails] = useState([]);
  const fetchClientData = (inputValue) => {
    setStartDate(null);
    setEndDate(null);
    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };
  const onRefresh = (e) => {
    setDispenseSummaryReport(null);
    setUnmatchedReport(null);

    if (selectedValue === null || selectedValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      alert("Please select Channel!");
      return false;
    }

    if (selectedModeValue === undefined || selectedModeValue === null) {
      alert("Please select mode Type!");
      return false;
    }

    if (
      selectedChannelValue !== undefined &&
      selectedChannelValue !== null &&
      selectedChannelValue.value === "1" &&
      (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null)
    ) {
      alert("Please select Txn Type!");
      return false;
    }

    //if ((selectedChannelValue !== undefined && selectedChannelValue !== null && selectedChannelValue.value == '1 ') && (selectedTerminalValue === undefined || selectedTerminalValue === null )) {
    //    alert("Please select Terminal Value!");
    //    return false;
    //}

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let ChannelId = 0;

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      ChannelId = 0;
    } else {
      ChannelId = selectedChannelValue.value;
    }

    let ModeId = 0;

    if (selectedModeValue === undefined || selectedModeValue === null) {
      ModeId = 0;
    } else {
      ModeId = selectedModeValue.value;
    }

    let TxnType = "";

    if (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null) {
      TxnType = "";
    } else {
      TxnType = selectedTxnTypeValue.label;
    }

    let TerminalValue = 0;

    if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
      TerminalValue = 0;
    } else {
      TerminalValue = selectedTerminalValue.value;
    }

    setIsLoading(true);

    MaximusAxios.post(
      "api/Report/DispenseSummaryJobInsert",
      {
        ClientID: selectedValue.clientID,
        ChannelID: String(ChannelId),
        ModeID: String(ModeId),
        TERMINALID: String(TerminalValue),
        FromDateTxns: formatDate(startDate),
        ToDateTxns: formatDate(endDate),
        UserName: String(currentUser.user.username),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        // setDispenseSummaryReport(response.data);
        setIsLoading(false);
        setShowMessageBox({
          isShow: true,
          alertVariant: "success",
          alertTitle: "Info",
          alertMessage: response.data,
        });

        fetchDispenseSummaryJobDetails(
          selectedValue.clientID,
          String(ChannelId),
          String(ModeId),
          formatDate(startDate),
          formatDate(endDate)
        );
        setTimeout(() => {
          setShowMessageBox({
            isShow: false,
            alertVariant: "",
            alertTitle: "",
            alertMessage: "",
          });

          setShowModal(true);
        }, 1500);
      })

      .catch(function (error) {
        setTitleDateValue("");
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  }

  const buttonClass = (status) => {
    switch (status) {
      case "Failed":
        return "btnFailed";
      case "Completed":
        return "btnCompleted";
      case "Start":
        return "btnAwaiting";
      default:
        return "btnDefault";
    }
  };
  const [isShowModal, setShowModal] = useState(false);

  const fetchDispenseSummaryJobDetails = (clientID, channelID, modeID, fromDate, toDate) => {

    MaximusAxios.get("api/Report/GetDispenseSummaryJobDetails", {
      params: {
        ClientID: clientID,
        ChannelID: String(channelID),
        ModeID: String(modeID),
        FromDateTxns: fromDate,
        ToDateTxns: toDate,
      }
    })
      .then(res => {
        console.log("Summary Job Response: ", res.data);
        setDispensesummaryjobdetails(res.data);
      })
      .catch(err => {
        console.error("Error fetching Dispense Summary:", err);
      });
  };

  const onReset = (e) => {
    e.preventDefault();
    // window.location.reload(false);
    setOptionsChannelTypeValue([]);
    setTitleDateValue(null);
    setValue(null);
    setSelectedValue(null);
    setDispenseSummaryReport(null);
    setUnmatchedReport(null);
    setSelectedChannelValue(null);
    setOptionsModeTypeValue([]);
    setSelectedTerminalValue(null);
    setIsShowTerminal(false);
    setSelectedModeValue(null);
    setOptionsTerminalValue([]);
    setStartDate(null);
    setEndDate(null);
    setReferenceNo(false);
    setEJTxnList(null);
    setGLTxnList(null);
    setNWTxnList(null);
    setSWTxnList(null);
  };

  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [inputValue, setValue] = useState("0");
  const [selectedValue, setSelectedValue] = useState(null);
  const [titleDate, setTitleDateValue] = useState("");
  const [isShowCardNo, setIsShowCardNo] = useState(false);
  const [isShowTerminalId, setIsShowTerminald] = useState(false);

  // handle input change event
  const handleInputChange = (value) => {
    setValue(value);
  };

  const [optionsChannelType, setOptionsChannelTypeValue] = useState([
    { channelID: "0", channelName: "--Select--" },
  ]);

  const [selectedChannelValue, setSelectedChannelValue] = useState(null);

  const [optionsModeType, setOptionsModeTypeValue] = useState([
    { modeID: "0", modeName: "--Select--" },
  ]);

  const [selectedModeValue, setSelectedModeValue] = useState(null);

  const [optionsTerminalType, setOptionsTerminalValue] = useState([
    { ID: "0", TERMINALID: "All" },
  ]);

  const [selectedTerminalValue, setSelectedTerminalValue] = useState(null);

  const [selectedTxnTypeValue, setSelectedTxnTypeValue] = useState(null);

  const [isShowTxnType, setIsShowTxnType] = useState(false);

  const [isShowTerminal, setIsShowTerminal] = useState(false);

  const [isShowModeIssuer, setIsShowModeIssuer] = useState(false);
  const [isShowModeOnusAcquirer, setIsShowModeOnusAcquirer] = useState(false);
  const [isShowModeIMPSUPIOutward, setIsShowModeIMPSUPIOutward] =
    useState(false);

  // handle selection

  const handleOptionsChannelType = (value) => {
    setOptionsChannelTypeValue(value);
  };

  const handleOptionsModeType = (value) => {
    setOptionsModeTypeValue(value);
  };

  const handleOptionsTerminalType = (value) => {
    setOptionsTerminalValue(value);
  };

  const handleClientChange = (value) => {
    setDispenseSummaryReport(null);
    setUnmatchedReport(null);
    setSelectedChannelValue(null);
    setSelectedModeValue(null);
    setSelectedTxnTypeValue("0");
    setSelectedTerminalValue(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedValue(value);

    if (value.clientID !== "0") {
      return MaximusAxios.get(
        "/api/Common/GetChannelOptionList?ClientId=" +
        value.clientID +
        "&UserID=" +
        currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsChannelType(result.data);
      });
    }
  };

  // handle selection
  const handleChannelChange = (value) => {
    setDispenseSummaryReport(null);
    setUnmatchedReport(null);
    setSelectedModeValue(null);
    setSelectedTxnTypeValue("0");
    setSelectedTerminalValue(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedChannelValue(value);

    if (value.value === "1") {
      setIsShowTerminald(true);
    } else {
      setIsShowTerminald(false);
    }
    if (value.value === "4" || value.value === "7") {
      setIsShowCardNo(false);
    } else {
      setIsShowCardNo(true);
    }
    if (value.value === "7") {
      setIsShowTerminald(false);
    } else {
      setIsShowTerminald(true);
    }

    if (value.value !== "0" && selectedValue.clientID !== "0") {
      return MaximusAxios.get(
        "/api/Common/GetModeIMPSOptionList?ClientID=" +
        selectedValue.clientID +
        "&ChannelID=" +
        value.value +
        "&UserID=" +
        currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsModeType(result.data);
      });
    }
  };

  function formatDate1(dateString) {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are 0-indexed
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  }

  const handleModeChange = (value) => {
    if (currentUser !== null && currentUser.user !== null) {
      setDispenseSummaryReport(null);
      setUnmatchedReport(null);
      // setSelectedTxnTypeValue('0');
      setSelectedTerminalValue(null);
      //setStartDate(null);
      //setEndDate(null);
      setSelectedModeValue(value);

      if (value.value === "1") {
        setIsShowTerminal(true);
        setIsShowModeOnusAcquirer(false);
      } else {
        setIsShowTerminal(false);
        setIsShowModeOnusAcquirer(true);
      }
      if (value.value === "3") {
        setIsShowTerminal(false);
        setIsShowModeOnusAcquirer(true);
        setIsShowModeIssuer(false);
        setIsShowModeIMPSUPIOutward(false);
      } else {
        setIsShowTerminal(true);
        setIsShowModeIssuer(true);
        setIsShowModeIMPSUPIOutward(true);
        setIsShowModeOnusAcquirer(false);
      }
      if (value.value === "4") {
        setIsShowModeIssuer(false);
        setIsShowModeOnusAcquirer(true);
      } else if (value.value === "5" || value.value === "2") {
        setIsShowModeOnusAcquirer(false);
      }
      if (value.value === "4" || value.value === "5") {
        setIsShowTerminal(false);
        setIsShowModeIMPSUPIOutward(false);
      }

      //    if (value.value === '1' || value.value === '3') { setIsShowTerminal(true); } else { setIsShowTerminal(false); }
      ////    if (value.value === '3') { setIsShowTerminal(true); } else { setIsShowTerminal(false); }
      //    if ( value.value === '4') { setIsShowModeIssuer(false); } else { setIsShowModeIssuer(true); }
      //    if (value.value === '1' || value.value === '5' || value.value === '2') { setIsShowModeOnusAcquirer(false); } else { setIsShowModeOnusAcquirer(true); }
      //    if (value.value === '4' || value.value === '5' ) { setIsShowModeIMPSUPIOutward(false); } else { setIsShowModeIMPSUPIOutward(true); }

      if (
        value.value !== "0" &&
        selectedValue.clientID !== "0" &&
        selectedChannelValue.value
      ) {
        return MaximusAxios.get(
          "api/Report/GetAllTerminals?ClientID=" + selectedValue.clientID,
          { mode: "cors" }
        )
          .then((result) => {
            var resData = result.data;
            var myObj = { id: "All", terminalid: "All" };
            /*  console.log(result.data);*/
            resData.unshift(myObj);
            handleOptionsTerminalType(resData);
          })
          .catch((error) => {
            console.error("Error fetching terminals:", error);
          });
      }
    } else {
      alert("Session Timeout");
    }
  };

  //const handleTxnTypeChange = value => {
  //    setDispenseSummaryReport(null);
  //    setSelectedTerminalValue(null);
  //    //setStartDate(null);
  //    //setEndDate(null);
  //    setSelectedTxnTypeValue(value);
  //}

  const handleTerminalChange = (value) => {
    setDispenseSummaryReport(null);
    //setStartDate(null);
    //setEndDate(null);
    setSelectedTerminalValue(value);
  };

  //   Date Calendar
  const [startDate, setStartDate] = useState(new Date());
  //   Date Calendar
  const [endDate, setEndDate] = useState(new Date());

  const setStartDateValue = (value) => {
    setDispenseSummaryReport(null);
    setStartDate(value);
    setEndDate(value);
  };

  const setEndDateValue = (value) => {
    setDispenseSummaryReport(null);
    if (startDate === null) {
      setEndDate(null);
      alert("Please enter From date first");
    } else {
      if (startDate > value) {
        alert("To date must be greater than From date ");
        setEndDate(null);
      } else {
        setEndDate(value);
      }
    }
  };

  const [referenceNo, setReferenceNo] = useState(false);

  const [EJTxnList, setEJTxnList] = useState(null);
  const [GLTxnList, setGLTxnList] = useState(null);
  const [NWTxnList, setNWTxnList] = useState(null);
  const [SWTxnList, setSWTxnList] = useState(null);

  // Modals

  const [DispenseSummaryReport, setDispenseSummaryReport] = useState(null);
  const [UnmatchedReport, setUnmatchedReport] = useState(null);

  //const downloadExcel = () => {

  //    if (DispenseSummaryReport !== null) {
  //        if (DispenseSummaryReport.length > 0) {
  //            var data = $("#gvDispenseSummaryReportPDF").dataTable()._('tr', { "filter": "applied" });
  //            let filterDataExcel = [];
  //            let cntrow = 0;
  //            let NFSAcquirerDifference = '';
  //            let NFSIssuerDifference = '';
  //            let ATMDifference = '';
  //            let UnSettledAmount = '';

  //            if (selectedModeValue.value === "1" || selectedModeValue.value === "2") {
  //                for (let i = 0; i < data.length; i++) {

  //                    NFSAcquirerDifference = data[cntrow][8];
  //                    NFSAcquirerDifference = NFSAcquirerDifference.replace('<button class="editBox"><u>', '');
  //                    NFSAcquirerDifference = NFSAcquirerDifference.replace('</u></button>', '');

  //                    ATMDifference = data[cntrow][9];
  //                    ATMDifference = ATMDifference.replace('<button class="editBox"><u>', '');
  //                    ATMDifference = ATMDifference.replace('</u></button>', '');

  //                    UnSettledAmount = data[cntrow][10];
  //                    UnSettledAmount = UnSettledAmount.replace('<button class="editBox"><u>', '');
  //                    UnSettledAmount = UnSettledAmount.replace('</u></button>', '');

  //                    var arr = { "TxnDate": data[cntrow][0], "TerminalID": data[cntrow][1], "GLONUS": data[cntrow][2], "GLAcquirer": data[cntrow][3], "GLTotal": data[cntrow][4], "SwitchTotal": data[cntrow][5], "EJTotal": data[cntrow][6], "NFSAcquirer": data[cntrow][7], "NFSAcquirerDiff": NFSAcquirerDifference, "ATMDiff": ATMDifference, "UnSettledAmount": UnSettledAmount }
  //                    filterDataExcel.push(arr);
  //                    cntrow++;
  //                }
  //            }
  //            else if (selectedModeValue.value === "3" || selectedModeValue.value === "4") {
  //                for (let i = 0; i < data.length; i++) {

  //                    NFSIssuerDifference = data[cntrow][4];
  //                    NFSIssuerDifference = NFSIssuerDifference.replace('<button class="editBox"><u>', '');
  //                    NFSIssuerDifference = NFSIssuerDifference.replace('</u></button>', '');

  //                    UnSettledAmount = data[cntrow][5];
  //                    UnSettledAmount = UnSettledAmount.replace('<button class="editBox"><u>', '');
  //                    UnSettledAmount = UnSettledAmount.replace('</u></button>', '');

  //                    var arr = { "TxnDate": data[cntrow][0], "GLISS": data[cntrow][1], "SWISS": data[cntrow][2], "NFSIssuer": data[cntrow][3], "NFSIssuerDiff": NFSIssuerDifference, "UnSettledAmount": UnSettledAmount }
  //                    filterDataExcel.push(arr);
  //                    cntrow++;
  //                }
  //            } else if (selectedModeValue.value === "5") {
  //                for (let i = 0; i < data.length; i++) {

  //                    NFSAcquirerDifference = data[cntrow][4];
  //                    NFSAcquirerDifference = NFSAcquirerDifference.replace('<button class="editBox"><u>', '');
  //                    NFSAcquirerDifference = NFSAcquirerDifference.replace('</u></button>', '');

  //                    UnSettledAmount = data[cntrow][5];
  //                    UnSettledAmount = UnSettledAmount.replace('<button class="editBox"><u>', '');
  //                    UnSettledAmount = UnSettledAmount.replace('</u></button>', '');

  //                    var arr = { "TxnDate": data[cntrow][0], "GLAcquirer": data[cntrow][1], "SwitchTotal": data[cntrow][2], "NFSAcquirer": data[cntrow][3], "NFSAcquirerDiff": NFSAcquirerDifference, "UnSettledAmount": UnSettledAmount }
  //                    filterDataExcel.push(arr);
  //                    cntrow++;
  //                }
  //            }
  //            else {
  //                for (let i = 0; i < data.length; i++) {

  //                    NFSAcquirerDifference = data[cntrow][11];
  //                    NFSAcquirerDifference = NFSAcquirerDifference.replace('<button class="editBox"><u>', '');
  //                    NFSAcquirerDifference = NFSAcquirerDifference.replace('</u></button>', '');

  //                    NFSIssuerDifference = data[cntrow][12];
  //                    NFSIssuerDifference = NFSIssuerDifference.replace('<button class="editBox"><u>', '');
  //                    NFSIssuerDifference = NFSIssuerDifference.replace('</u></button>', '');

  //                    ATMDifference = data[cntrow][13];
  //                    ATMDifference = ATMDifference.replace('<button class="editBox"><u>', '');
  //                    ATMDifference = ATMDifference.replace('</u></button>', '');

  //                    UnSettledAmount = data[cntrow][14];
  //                    UnSettledAmount = UnSettledAmount.replace('<button class="editBox"><u>', '');
  //                    UnSettledAmount = UnSettledAmount.replace('</u></button>', '');

  //                    var arr = { "TxnDate": data[cntrow][0], "TerminalID": data[cntrow][1], "GLONUS": data[cntrow][2], "GLAcquirer": data[cntrow][3], "GLISS": data[cntrow][4], "GLTotal": data[cntrow][5], "SWISS": data[cntrow][6], "SwitchTotal": data[cntrow][7], "EJTotal": data[cntrow][8], "NFSAcquirer": data[cntrow][9], "NFSIssuer": data[cntrow][10], "NFSAcquirerDiff": data[cntrow][11], "NFSIssuerDiff": data[cntrow][12], "ATMDiff": data[cntrow][13], "UnSettledAmount": data[cntrow][14] }
  //                    filterDataExcel.push(arr);
  //                    cntrow++;
  //                }
  //            }
  //            //console.log(filterDataExcel);
  //            var wb = XLSX.utils.book_new();
  //            var ws = XLSX.utils.json_to_sheet(filterDataExcel);
  //            XLSX.utils.book_append_sheet(wb, ws);
  //            XLSX.writeFile(wb, "Dispense Summary Report.xlsx");
  //        } else {
  //            alert('No Record Found');
  //        }
  //    } else {
  //        alert('No Record Found');
  //    }

  //};

  const downloadPDF = () => {
    if (DispenseSummaryReport !== null) {
      if (DispenseSummaryReport.length > 0) {
        MaximusAxios.get(
          "api/Common/GetClientLogoImage?ClientId=" + selectedValue.clientID,
          { mode: "cors" }
        ).then((result) => {
          const title = "Dispense Summary Report";

          const headers = [
            [
              "TxnDate",
              "TerminalID",
              "GLONUS",
              "GLAcquirer",
              "GLISS",
              "GLTotal",
              "SWISS",
              "SwitchTotal",
              "EJTotal",
              "NFSAcquirer",
              "NFSIssuer",
              "NFSAcquirerDiff",
              "NFSIssuerDiff",
              "ATMDiff",
              "UnSettledAmount",
            ],
          ];
          const headers1 = [
            [
              "TxnDate",
              "TerminalID",
              "GLONUS",
              "GLAcquirer",
              "GLTotal",
              "SwitchTotal",
              "EJTotal",
              "NFSAcquirer",
              "NFSAcquirerDiff",
              "ATMDiff",
              "UnSettledAmount",
            ],
          ];
          const headers2 = [
            [
              "TxnDate",
              "GLISS",
              "SWISS",
              "NFSIssuer",
              "NFSIssuerDiff",
              "UnSettledAmount",
            ],
          ];
          const headers3 = [
            [
              "TxnDate",
              "GLAcquirer",
              "SwitchTotal",
              "NFSAcquirer",
              "NFSAcquirerDiff",
              "UnSettledAmount",
            ],
          ];

          var data = $("#gvDispenseSummaryReportPDF")
            .dataTable()
            ._("tr", { filter: "applied" });
          let filterDataPDF = [];
          let cntrow = 0;
          let NFSAcquirerDifference = "";
          let NFSIssuerDifference = "";
          let ATMDifference = "";
          let UnSettledAmount = "";
          // console.log(data);
          if (
            selectedModeValue.value === "1" ||
            selectedModeValue.value === "2"
          ) {
            for (let i = 0; i < data.length; i++) {
              let TxnsDate = "";
              TxnsDate = data[cntrow][0];
              TxnsDate = TxnsDate.replace("00:00:00", "");

              NFSAcquirerDifference = data[cntrow][8];
              NFSAcquirerDifference = NFSAcquirerDifference.replace(
                '<button class="editBox"><u>',
                ""
              );
              NFSAcquirerDifference = NFSAcquirerDifference.replace(
                "</u></button>",
                ""
              );

              ATMDifference = data[cntrow][9];
              ATMDifference = ATMDifference.replace(
                '<button class="editBox"><u>',
                ""
              );
              ATMDifference = ATMDifference.replace("</u></button>", "");

              UnSettledAmount = data[cntrow][10];
              UnSettledAmount = UnSettledAmount.replace(
                '<button class="editBox"><u>',
                ""
              );
              UnSettledAmount = UnSettledAmount.replace("</u></button>", "");

              var arr = [
                TxnsDate,
                data[cntrow][1],
                data[cntrow][2],
                data[cntrow][3],
                data[cntrow][4],
                data[cntrow][5],
                data[cntrow][6],
                data[cntrow][7],
                NFSAcquirerDifference,
                ATMDifference,
                UnSettledAmount,
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          } else if (
            selectedModeValue.value === "3" ||
            selectedModeValue.value === "4"
          ) {
            for (let i = 0; i < data.length; i++) {
              let TxnsDate = "";
              TxnsDate = data[cntrow][0];
              TxnsDate = TxnsDate.replace("00:00:00", "");

              NFSIssuerDifference = data[cntrow][4];
              NFSIssuerDifference = NFSIssuerDifference.replace(
                '<button class="editBox"><u>',
                ""
              );
              NFSIssuerDifference = NFSIssuerDifference.replace(
                "</u></button>",
                ""
              );

              UnSettledAmount = data[cntrow][5];
              UnSettledAmount = UnSettledAmount.replace(
                '<button class="editBox"><u>',
                ""
              );
              UnSettledAmount = UnSettledAmount.replace("</u></button>", "");

              var arr = [
                TxnsDate,
                data[cntrow][1],
                data[cntrow][2],
                data[cntrow][3],
                NFSIssuerDifference,
                UnSettledAmount,
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          } else if (selectedModeValue.value === "5") {
            for (let i = 0; i < data.length; i++) {
              let TxnsDate = "";
              TxnsDate = data[cntrow][0];
              TxnsDate = TxnsDate.replace("00:00:00", "");

              NFSAcquirerDifference = data[cntrow][4];
              NFSAcquirerDifference = NFSAcquirerDifference.replace(
                '<button class="editBox"><u>',
                ""
              );
              NFSAcquirerDifference = NFSAcquirerDifference.replace(
                "</u></button>",
                ""
              );

              UnSettledAmount = data[cntrow][5];
              UnSettledAmount = UnSettledAmount.replace(
                '<button class="editBox"><u>',
                ""
              );
              UnSettledAmount = UnSettledAmount.replace("</u></button>", "");

              var arr = [
                TxnsDate,
                data[cntrow][1],
                data[cntrow][2],
                data[cntrow][3],
                NFSAcquirerDifference,
                UnSettledAmount,
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          } else {
            for (let i = 0; i < data.length; i++) {
              let TxnsDate = "";
              TxnsDate = data[cntrow][0];
              TxnsDate = TxnsDate.replace("00:00:00", "");

              NFSAcquirerDifference = data[cntrow][11];
              NFSAcquirerDifference = NFSAcquirerDifference.replace(
                '<button class="editBox"><u>',
                ""
              );
              NFSAcquirerDifference = NFSAcquirerDifference.replace(
                "</u></button>",
                ""
              );

              NFSIssuerDifference = data[cntrow][12];
              NFSIssuerDifference = NFSIssuerDifference.replace(
                '<button class="editBox"><u>',
                ""
              );
              NFSIssuerDifference = NFSIssuerDifference.replace(
                "</u></button>",
                ""
              );

              ATMDifference = data[cntrow][13];
              ATMDifference = ATMDifference.replace(
                '<button class="editBox"><u>',
                ""
              );
              ATMDifference = ATMDifference.replace("</u></button>", "");

              UnSettledAmount = data[cntrow][14];
              UnSettledAmount = UnSettledAmount.replace(
                '<button class="editBox"><u>',
                ""
              );
              UnSettledAmount = UnSettledAmount.replace("</u></button>", "");

              var arr = [
                TxnsDate,
                data[cntrow][1],
                data[cntrow][2],
                data[cntrow][3],
                data[cntrow][4],
                data[cntrow][5],
                data[cntrow][6],
                data[cntrow][7],
                data[cntrow][8],
                data[cntrow][9],
                data[cntrow][10],
                NFSAcquirerDifference,
                NFSIssuerDifference,
                ATMDifference,
                UnSettledAmount,
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          }
          //console.log(filterDataPDF);

          const unit = "pt";
          const size = "LEGAL";
          const orientation = "landscape";

          const doc = new jsPDF(orientation, unit, size);

          //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
          var pageWidth =
            doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

          //console.log(result);

          doc.addImage(result.data.clientLogo, "PNG", 20, 20, 150, 50);

          doc.addImage(
            result.data.traceLogo,
            "PNG",
            pageWidth - 170,
            20,
            150,
            50
          );

          //doc.setTextColor(100);

          doc.setFontSize(24);

          doc.text(title, pageWidth / 2, 40, { align: "center" });

          doc.setFontSize(20);

          doc.text(titleDate, pageWidth / 2, 65, { align: "center" });

          if (
            selectedModeValue.value === "1" ||
            selectedModeValue.value === "2"
          ) {
            let content = {
              startY: 80,
              head: headers1,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          } else if (
            selectedModeValue.value === "3" ||
            selectedModeValue.value === "4"
          ) {
            let content = {
              startY: 80,
              head: headers2,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          } else if (selectedModeValue.value === "5") {
            let content = {
              startY: 80,
              head: headers3,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          } else {
            let content = {
              startY: 80,
              head: headers,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          }

          doc.setFontSize(10);
          //doc.autoTable(content);
          doc.save("Dispense Summary Report.pdf");
        });
      } else {
        alert("No Record Found");
      }
    } else {
      alert("No Record Found");
    }
  };

  //const downloadExcel1 = () => {

  //    if (UnmatchedReport !== null) {
  //        if (UnmatchedReport.length > 0) {
  //            var data = $("#gvUnmatchedReportPDF").dataTable()._('tr', { "filter": "applied" });
  //            let filterDataExcel = [];
  //            let cntrow = 0;
  //            let ReferenceNumber1 = '';

  //            console.log(data);
  //            for (let i = 0; i < data.length; i++) {

  //                ReferenceNumber1 = data[cntrow][4];
  //                ReferenceNumber1 = ReferenceNumber1.replace('<button><u>', '');
  //                ReferenceNumber1 = ReferenceNumber1.replace('</u></button>', '');

  //                var arr = { "ChannelName": data[cntrow][0], "TransactionMode": data[cntrow][1], "TerminalId": data[cntrow][2], "TxnsDateTime": data[cntrow][3], "ReferenceNumber": ReferenceNumber1, "CardNumber": data[cntrow][5], "CustAccountNo": data[cntrow][6], "TxnsAmount": data[cntrow][7], "EJStatus": data[cntrow][8], "SWStatus": data[cntrow][9], "NWStatus": data[cntrow][10], "GLStatus": data[cntrow][11], "TxnsSubType": data[cntrow][12], "OnSettled": data[cntrow][13] }
  //                filterDataExcel.push(arr);
  //                cntrow++;
  //            }
  //            console.log(filterDataExcel);
  //            var wb = XLSX.utils.book_new();
  //            var ws = XLSX.utils.json_to_sheet(filterDataExcel);
  //            XLSX.utils.book_append_sheet(wb, ws);
  //            XLSX.writeFile(wb, "Unmatched Report.xlsx");
  //        } else {
  //            alert('No Record Found');
  //        }
  //    } else {
  //        alert('No Record Found');
  //    }

  //};

  const downloadPDF1 = () => {
    if (UnmatchedReport !== null) {
      if (UnmatchedReport.length > 0) {
        MaximusAxios.get(
          "api/Common/GetClientLogoImage?ClientId=" + selectedValue.clientID,
          { mode: "cors" }
        ).then((result) => {
          const title = "Unmatched Report";
          const headers = [
            [
              "ChannelName",
              "TransactionMode",
              "TerminalId",
              "TxnsDateTime",
              "ReferenceNumber",
              "CardNumber",
              "CustAccountNo",
              "TxnsAmount",
              "EJStatus",
              "SWStatus",
              "NWStatus",
              "GLStatus",
              "TxnsSubType",
              "SwResponseCode",
              "OnSettled",
            ],
          ];
          const headers1 = [
            [
              "ChannelName",
              "TransactionMode",
              "TerminalId",
              "TxnsDateTime",
              "ReferenceNumber",
              "CustAccountNo",
              "TxnsAmount",
              "EJStatus",
              "SWStatus",
              "NWStatus",
              "GLStatus",
              "TxnsSubType",
              "SwResponseCode",
              "OnSettled",
            ],
          ];
          const headers2 = [
            [
              "ChannelName",
              "TransactionMode",
              "TxnsDateTime",
              "ReferenceNumber",
              "CustAccountNo",
              "TxnsAmount",
              "EJStatus",
              "SWStatus",
              "NWStatus",
              "GLStatus",
              "TxnsSubType",
              "SwResponseCode",
              "OnSettled",
            ],
          ];

          var data = $("#gvUnmatchedReportPDF")
            .dataTable()
            ._("tr", { filter: "applied" });
          let filterDataPDF = [];
          let cntrow = 0;
          let ReferenceNumber1 = "";
          console.log(data);

          if (selectedChannelValue.value === "4") {
            for (let i = 0; i < data.length; i++) {
              ReferenceNumber1 = data[cntrow][4];
              ReferenceNumber1 = ReferenceNumber1.replace("<button><u>", "");
              ReferenceNumber1 = ReferenceNumber1.replace("</u></button>", "");

              var arr = [
                data[cntrow][0],
                data[cntrow][1],
                data[cntrow][2],
                data[cntrow][3],
                ReferenceNumber1,
                data[cntrow][5],
                data[cntrow][6],
                data[cntrow][7],
                data[cntrow][8],
                data[cntrow][9],
                data[cntrow][10],
                data[cntrow][11],
                data[cntrow][12],
                data[cntrow][13],
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          } else if (selectedChannelValue.value === "7") {
            for (let i = 0; i < data.length; i++) {
              ReferenceNumber1 = data[cntrow][3];
              ReferenceNumber1 = ReferenceNumber1.replace("<button><u>", "");
              ReferenceNumber1 = ReferenceNumber1.replace("</u></button>", "");

              var arr = [
                data[cntrow][0],
                data[cntrow][1],
                data[cntrow][2],
                ReferenceNumber1,
                data[cntrow][4],
                data[cntrow][5],
                data[cntrow][6],
                data[cntrow][7],
                data[cntrow][8],
                data[cntrow][9],
                data[cntrow][10],
                data[cntrow][11],
                data[cntrow][12],
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          } else {
            for (let i = 0; i < data.length; i++) {
              ReferenceNumber1 = data[cntrow][4];
              ReferenceNumber1 = ReferenceNumber1.replace("<button><u>", "");
              ReferenceNumber1 = ReferenceNumber1.replace("</u></button>", "");

              var arr = [
                data[cntrow][0],
                data[cntrow][1],
                data[cntrow][2],
                data[cntrow][3],
                ReferenceNumber1,
                data[cntrow][5],
                data[cntrow][6],
                data[cntrow][7],
                data[cntrow][8],
                data[cntrow][9],
                data[cntrow][10],
                data[cntrow][11],
                data[cntrow][12],
                data[cntrow][13],
                data[cntrow][14],
              ];
              filterDataPDF.push(arr);
              cntrow++;
            }
          }

          console.log(filterDataPDF);

          const unit = "pt";
          const size = "LEGAL";
          const orientation = "landscape";
          const doc = new jsPDF(orientation, unit, size);

          //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
          var pageWidth =
            doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

          //console.log(result);

          doc.addImage(result.data.clientLogo, "PNG", 20, 20, 150, 50);

          doc.addImage(
            result.data.traceLogo,
            "PNG",
            pageWidth - 170,
            20,
            150,
            50
          );

          //doc.setTextColor(100);

          doc.setFontSize(24);

          doc.text(title, pageWidth / 2, 40, { align: "center" });

          doc.setFontSize(20);

          doc.text(titleDate, pageWidth / 2, 65, { align: "center" });

          if (selectedChannelValue.value === "4") {
            let content = {
              startY: 80,
              head: headers1,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          } else if (selectedChannelValue.value === "7") {
            let content = {
              startY: 80,
              head: headers2,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          } else {
            let content = {
              startY: 80,
              head: headers,
              body: filterDataPDF,
            };

            doc.autoTable(content);
          }

          doc.setFontSize(10);
          //doc.autoTable(content);
          doc.save("Unmatched Report.pdf");
        });
      } else {
        alert("No Record Found");
      }
    } else {
      alert("No Record Found");
    }
  };

  // Tooltip
  const renderTooltip = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to pdf
    </Tooltip>
  );

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to excel
    </Tooltip>
  );

  const renderTooltipShow = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to open window
    </Tooltip>
  );

  const formatDate = (date) => {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

  const onShow = () => {
    setDispenseSummaryReport(null);
    setUnmatchedReport(null);

    if (selectedValue === null || selectedValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      alert("Please select Channel!");
      return false;
    }

    if (selectedModeValue === undefined || selectedModeValue === null) {
      alert("Please select mode Type!");
      return false;
    }

    if (
      selectedChannelValue !== undefined &&
      selectedChannelValue !== null &&
      selectedChannelValue.value === "1" &&
      (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null)
    ) {
      alert("Please select Txn Type!");
      return false;
    }

    //if ((selectedChannelValue !== undefined && selectedChannelValue !== null && selectedChannelValue.value == '1 ') && (selectedTerminalValue === undefined || selectedTerminalValue === null )) {
    //    alert("Please select Terminal Value!");
    //    return false;
    //}

    if (startDate === undefined || startDate === null) {
      alert("Please enter From Date!");
      return false;
    }

    if (endDate === undefined || endDate === null) {
      alert("Please enter To Date!");
      return false;
    }

    let ChannelId = 0;

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      ChannelId = 0;
    } else {
      ChannelId = selectedChannelValue.value;
    }

    let ModeId = 0;

    if (selectedModeValue === undefined || selectedModeValue === null) {
      ModeId = 0;
    } else {
      ModeId = selectedModeValue.value;
    }

    let TxnType = "";

    if (selectedTxnTypeValue === undefined || selectedTxnTypeValue === null) {
      TxnType = "";
    } else {
      TxnType = selectedTxnTypeValue.label;
    }

    let TerminalValue = 0;

    if (selectedTerminalValue === undefined || selectedTerminalValue === null) {
      TerminalValue = 0;
    } else {
      TerminalValue = selectedTerminalValue.value;
    }

    setIsLoading(true);

    MaximusAxios.post(
      "api/Report/GetDispenseSummaryDetailsList",
      {
        ClientID: selectedValue.clientID,
        ChannelID: String(ChannelId),
        ModeID: String(ModeId),
        TERMINALID: String(TerminalValue),
        FromDateTxns: formatDate(startDate),
        ToDateTxns: formatDate(endDate),
        TxnType: TxnType,
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setDispenseSummaryReport(response.data);
        setTitleDateValue(
          "Report Date : " +
          formatDate(startDate) +
          " To " +
          formatDate(endDate)
        );
        console.log(response.data)
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "No records found",
          });
        }
      })
      .catch(function (error) {
        setTitleDateValue("");
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  const onNFSAcquirerDiffClick = (FromDate1, ToDate1, TERMINALID1) => {
    setUnmatchedReport(null);

    setIsLoading(true);

    MaximusAxios.post(
      "/api/Report/GetDispenseUnmatchedReportList",
      {
        ClientID: selectedValue.clientID,
        ChannelID: selectedChannelValue.value,
        ModeID: selectedModeValue.value,
        TERMINALID: TERMINALID1 || '0',
        Type: "1",
        FromDateTxns: formatDate(FromDate1),
        ToDateTxns: formatDate(ToDate1),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setUnmatchedReport(response.data);
        console.log(response.data);
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Info",
            alertMessage: "No Record Found",
          });
        }
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  const onNFSIssuerDiffClick = (FromDate2, ToDate2, TERMINALID2) => {
    setUnmatchedReport(null);

    setIsLoading(true);
    MaximusAxios.post(
      "api/Report/GetDispenseUnmatchedReportList",
      {
        ClientID: selectedValue.clientID,
        ChannelID: selectedChannelValue.value,
        ModeID: selectedModeValue.value,
        TERMINALID: TERMINALID2 || '0',
        Type: "1",
        FromDateTxns: formatDate(FromDate2),
        ToDateTxns: formatDate(ToDate2),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setUnmatchedReport(response.data);
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Info",
            alertMessage: "No Record Found",
          });
        }
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  const onATMDiffClick = (FromDate3, ToDate3, TERMINALID3) => {
    setUnmatchedReport(null);

    setIsLoading(true);
    MaximusAxios.post(
      "api/Report/GetDispenseUnmatchedReportList",
      {
        ClientID: selectedValue.clientID,
        ChannelID: selectedChannelValue.value,
        ModeID: selectedModeValue.value,
        TERMINALID: TERMINALID3 || '0',
        Type: "2",
        FromDateTxns: formatDate(FromDate3),
        ToDateTxns: formatDate(ToDate3),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setUnmatchedReport(response.data);
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Info",
            alertMessage: "No Record Found",
          });
        }
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  const onUnSettledAmountClick = (FromDate4, ToDate4, TERMINALID4) => {
    setUnmatchedReport(null);

    setIsLoading(true);
    MaximusAxios.post(
      "api/Report/GetDispenseUnmatchedReportList",
      {
        ClientID: selectedValue.clientID,
        ChannelID: selectedChannelValue.value,
        ModeID: selectedModeValue.value,
        TERMINALID: TERMINALID4 || '0',
        Type: "3",
        FromDateTxns: formatDate(FromDate4),
        ToDateTxns: formatDate(ToDate4),
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setUnmatchedReport(response.data);
        setIsLoading(false);
        if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Info",
            alertMessage: "No Record Found",
          });
        }
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
      });
  };

  const onReferenceNumberClick = (ReferenceNumber, Terminal, TrnDate) => {
    setEJTxnList(null);
    setGLTxnList(null);
    setNWTxnList(null);
    setSWTxnList(null);

    setReferenceNo(true);

    //  setIsLoading(true);

    let TerminalValue = "0";

    if (Terminal === undefined || Terminal === null) {
      TerminalValue = "0";
    } else {
      TerminalValue = Terminal;
    }

    // alert(ReferenceNumber + TerminalValue + TrnDate)
    MaximusAxios
      .post(
        "api/Report/GetTxnsDetailsByReferenceNumberList",
        {
          ClientID: String(selectedValue.clientID),
          ChannelID: String(selectedChannelValue.label),
          ModeID: String(selectedModeValue.label),
          TERMINALID: String(TerminalValue),
          ReferenceNumber: String(ReferenceNumber),
          TxnsDateTime: formatDate(
            parse(TrnDate, "dd-MM-yyyy HH:mm:ss", new Date())
          ),
        },
        { mode: 'cors' }
      )
      .then(function (response) {
        setEJTxnList(response.data.ejTxnDetails);
        setGLTxnList(response.data.glTxnDetails);
        setNWTxnList(response.data.nwTxnDetails);
        setSWTxnList(response.data.swTxnDetails);
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
      });
    setIsLoading(false);
  };

  $(document).ready(function () {
    if (DispenseSummaryReport !== null && DispenseSummaryReport.length > 0) {
      $("#gvDispenseSummaryReportPDF").DataTable();
    }
  });

  $(document).ready(function () {
    if (UnmatchedReport !== null && UnmatchedReport.length > 0) {
      $("#gvUnmatchedReportPDF").DataTable();
    }
  });

  const ExportToExcel = async () => {
    const workbook = new ExcelJS.Workbook();

    try {
      setIsLoading(true);

      var data = $("#gvDispenseSummaryReportPDF")
        .dataTable()
        ._("tr", { filter: "applied" });
      let filterDataExcel = [];
      let cntrow = 0;
      let NFSAcquirerDifference = "";
      let NFSIssuerDifference = "";
      let ATMDifference = "";
      let UnSettledAmount = "";

      if (selectedModeValue.value === "1" || selectedModeValue.value === "2") {
        for (let i = 0; i < data.length; i++) {
          let TxnsDate = "";
          TxnsDate = data[cntrow][0];
          TxnsDate = TxnsDate.replace("00:00:00", "");

          NFSAcquirerDifference = data[cntrow][8];
          NFSAcquirerDifference = NFSAcquirerDifference.replace(
            '<button class="editBox"><u>',
            ""
          );
          NFSAcquirerDifference = NFSAcquirerDifference.replace(
            "</u></button>",
            ""
          );

          ATMDifference = data[cntrow][9];
          ATMDifference = ATMDifference.replace(
            '<button class="editBox"><u>',
            ""
          );
          ATMDifference = ATMDifference.replace("</u></button>", "");

          UnSettledAmount = data[cntrow][10];
          UnSettledAmount = UnSettledAmount.replace(
            '<button class="editBox"><u>',
            ""
          );
          UnSettledAmount = UnSettledAmount.replace("</u></button>", "");

          var arr = {
            TxnDate: TxnsDate,
            TerminalID: data[cntrow][1],
            GLONUS: data[cntrow][2],
            GLAcquirer: data[cntrow][3],
            GLTotal: data[cntrow][4],
            SwitchTotal: data[cntrow][5],
            EJTotal: data[cntrow][6],
            NFSAcquirer: data[cntrow][7],
            NFSAcquirerDiff: NFSAcquirerDifference,
            ATMDiff: ATMDifference,
            UnSettledAmount: UnSettledAmount,
          };
          filterDataExcel.push(arr);
          cntrow++;
        }
      } else if (
        selectedModeValue.value === "3" ||
        selectedModeValue.value === "4"
      ) {
        for (let i = 0; i < data.length; i++) {
          let TxnsDate = "";
          TxnsDate = data[cntrow][0];
          TxnsDate = TxnsDate.replace("00:00:00", "");

          NFSIssuerDifference = data[cntrow][4];
          NFSIssuerDifference = NFSIssuerDifference.replace(
            '<button class="editBox"><u>',
            ""
          );
          NFSIssuerDifference = NFSIssuerDifference.replace(
            "</u></button>",
            ""
          );

          UnSettledAmount = data[cntrow][5];
          UnSettledAmount = UnSettledAmount.replace(
            '<button class="editBox"><u>',
            ""
          );
          UnSettledAmount = UnSettledAmount.replace("</u></button>", "");

          var arr = {
            TxnDate: TxnsDate,
            GLISS: data[cntrow][1],
            SWISS: data[cntrow][2],
            NFSIssuer: data[cntrow][3],
            NFSIssuerDiff: NFSIssuerDifference,
            UnSettledAmount: UnSettledAmount,
          };
          filterDataExcel.push(arr);
          cntrow++;
        }
      } else if (selectedModeValue.value === "5") {
        for (let i = 0; i < data.length; i++) {
          let TxnsDate = "";
          TxnsDate = data[cntrow][0];
          TxnsDate = TxnsDate.replace("00:00:00", "");

          NFSAcquirerDifference = data[cntrow][4];
          NFSAcquirerDifference = NFSAcquirerDifference.replace(
            '<button class="editBox"><u>',
            ""
          );
          NFSAcquirerDifference = NFSAcquirerDifference.replace(
            "</u></button>",
            ""
          );

          UnSettledAmount = data[cntrow][5];
          UnSettledAmount = UnSettledAmount.replace(
            '<button class="editBox"><u>',
            ""
          );
          UnSettledAmount = UnSettledAmount.replace("</u></button>", "");

          var arr = {
            TxnDate: TxnsDate,
            GLAcquirer: data[cntrow][1],
            SwitchTotal: data[cntrow][2],
            NFSAcquirer: data[cntrow][3],
            NFSAcquirerDiff: NFSAcquirerDifference,
            UnSettledAmount: UnSettledAmount,
          };
          filterDataExcel.push(arr);
          cntrow++;
        }
      } else {
        for (let i = 0; i < data.length; i++) {
          let TxnsDate = "";
          TxnsDate = data[cntrow][0];
          TxnsDate = TxnsDate.replace("00:00:00", "");

          NFSAcquirerDifference = data[cntrow][11];
          NFSAcquirerDifference = NFSAcquirerDifference.replace(
            '<button class="editBox"><u>',
            ""
          );
          NFSAcquirerDifference = NFSAcquirerDifference.replace(
            "</u></button>",
            ""
          );

          NFSIssuerDifference = data[cntrow][12];
          NFSIssuerDifference = NFSIssuerDifference.replace(
            '<button class="editBox"><u>',
            ""
          );
          NFSIssuerDifference = NFSIssuerDifference.replace(
            "</u></button>",
            ""
          );

          ATMDifference = data[cntrow][13];
          ATMDifference = ATMDifference.replace(
            '<button class="editBox"><u>',
            ""
          );
          ATMDifference = ATMDifference.replace("</u></button>", "");

          UnSettledAmount = data[cntrow][14];
          UnSettledAmount = UnSettledAmount.replace(
            '<button class="editBox"><u>',
            ""
          );
          UnSettledAmount = UnSettledAmount.replace("</u></button>", "");

          var arr = {
            TxnDate: TxnsDate,
            TerminalID: data[cntrow][1],
            GLONUS: data[cntrow][2],
            GLAcquirer: data[cntrow][3],
            GLISS: data[cntrow][4],
            GLTotal: data[cntrow][5],
            SWISS: data[cntrow][6],
            SwitchTotal: data[cntrow][7],
            EJTotal: data[cntrow][8],
            NFSAcquirer: data[cntrow][9],
            NFSIssuer: data[cntrow][10],
            NFSAcquirerDiff: data[cntrow][11],
            NFSIssuerDiff: data[cntrow][12],
            ATMDiff: data[cntrow][13],
            UnSettledAmount: data[cntrow][14],
          };
          filterDataExcel.push(arr);
          cntrow++;
        }
      }

      // Create Excel workbook and worksheet
      const worksheet = workbook.addWorksheet("Dispense");

      // Define columns in the worksheet, these columns are identified using a key.
      if (selectedModeValue.value === "1" || selectedModeValue.value === "2") {
        worksheet.columns = [
          { header: "Txns Date", key: "TxnDate" },
          { header: "Terminal ID", key: "TerminalID" },
          { header: "GL ONUS", key: "GLONUS" },
          { header: "GL Acquirer", key: "GLAcquirer" },
          { header: "GL Total", key: "GLTotal" },
          { header: "Switch Total", key: "SwitchTotal" },
          { header: "EJ Total", key: "EJTotal" },
          { header: "NFS Acquirer", key: "NFSAcquirer" },
          { header: "NFS Acquirer Diff", key: "NFSAcquirerDiff" },
          { header: "ATM Diff", key: "ATMDiff" },
          { header: "UnSettled Amount", key: "UnSettledAmount" },
        ];

        worksheet.columns = [
          { width: 20 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 20 },
          { width: 15 },
          { width: 20 },
        ];
      } else if (
        selectedModeValue.value === "3" ||
        selectedModeValue.value === "4"
      ) {
        worksheet.columns = [
          { header: "Txns Date", key: "TxnDate" },
          { header: "GL ISS", key: "GLISS" },
          { header: "SW ISS", key: "SWISS" },
          { header: "NFS Issuer", key: "NFSIssuer" },
          { header: "NFS Issuer Diff", key: "NFSIssuerDiff" },
          { header: "UnSettled Amount", key: "UnSettledAmount" },
        ];

        worksheet.columns = [
          { width: 20 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 20 },
          { width: 20 },
        ];
      } else if (selectedModeValue.value === "5") {
        worksheet.columns = [
          { header: "Txns Date", key: "TxnDate" },
          { header: "GL Acquirer", key: "GLAcquirer" },
          { header: "Switch Total", key: "SwitchTotal" },
          { header: "NFS Acquirer", key: "NFSAcquirer" },
          { header: "NFS Acquirer Diff", key: "NFSAcquirerDiff" },
          { header: "UnSettled Amount", key: "UnSettledAmount" },
        ];

        worksheet.columns = [
          { width: 20 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 20 },
          { width: 20 },
        ];
      } else {
        worksheet.columns = [
          { header: "Txns Date", key: "TxnDate" },
          { header: "Terminal ID", key: "TerminalID" },
          { header: "GL ONUS", key: "GLONUS" },
          { header: "GL Acquirer", key: "GLAcquirer" },
          { header: "GL ISS", key: "GLISS" },
          { header: "GL Total", key: "GLTotal" },
          { header: "SW ISS", key: "SWISS" },
          { header: "Switch Total", key: "SwitchTotal" },
          { header: "EJ Total", key: "EJTotal" },
          { header: "NFS Acquirer", key: "NFSAcquirer" },
          { header: "NFS Issuer", key: "NFSIssuer" },
          { header: "NFS Acquirer Diff", key: "NFSAcquirerDiff" },
          { header: "NFS Issuer Diff", key: "NFSIssuerDiff" },
          { header: "ATM Diff", key: "ATMDiff" },
          { header: "UnSettled Amount", key: "UnSettledAmount" },
        ];

        worksheet.columns = [
          { width: 20 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 15 },
          { width: 20 },
          { width: 20 },
          { width: 15 },
          { width: 20 },
        ];
      }

      // loop through all of the columns and set the alignment with width.
      worksheet.columns.forEach((column) => {
        column.alignment = { horizontal: "center" };
      });

      worksheet.columns.forEach((column) => {
        if (
          selectedModeValue.value === "1" ||
          selectedModeValue.value === "2"
        ) {
          if (
            column._number === 3 ||
            column._number === 4 ||
            column._number === 5 ||
            column._number === 6 ||
            column._number === 7 ||
            column._number === 8 ||
            column._number === 9 ||
            column._number === 10 ||
            column._number === 11
          ) {
            column.alignment = { horizontal: "right" };
          }
        } else if (
          selectedModeValue.value === "3" ||
          selectedModeValue.value === "4"
        ) {
          if (
            column._number === 2 ||
            column._number === 3 ||
            column._number === 4 ||
            column._number === 5 ||
            column._number === 6
          ) {
            column.alignment = { horizontal: "right" };
          }
        } else if (selectedModeValue.value === "5") {
          if (
            column._number === 2 ||
            column._number === 3 ||
            column._number === 4 ||
            column._number === 5 ||
            column._number === 6
          ) {
            column.alignment = { horizontal: "right" };
          }
        } else {
          if (
            column._number === 3 ||
            column._number === 4 ||
            column._number === 5 ||
            column._number === 6 ||
            column._number === 7 ||
            column._number === 8 ||
            column._number === 9 ||
            column._number === 10 ||
            column._number === 11 ||
            column._number === 12 ||
            column._number === 13 ||
            column._number === 14 ||
            column._number === 15
          ) {
            column.alignment = { horizontal: "right" };
          }
        }
      });

      // updated the font for first row.
      worksheet.getRow(1).font = { bold: true, color: { argb: "ffffff" } };

      // loop through data and add each one to worksheet
      filterDataExcel.forEach((singleData) => {
        worksheet.addRow(singleData);
      });

      // Add auto-filter on each column
      //worksheet.autoFilter = 'A1:D1';

      // Process each row for calculations and beautification
      worksheet.eachRow((row, rowNumber) => {
        row.eachCell((cell, colNumber) => {
          if (rowNumber == 1) {
            // First set the background of header row
            cell.fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "df5015" },
            };
          }
          // Set border of each cell
          cell.border = {
            top: { style: "thin" },
            left: { style: "thin" },
            bottom: { style: "thin" },
            right: { style: "thin" },
          };
        });
        //Commit the changed row to the stream
        row.commit();
      });

      //console.log(filterDataExcel);

      var today = new Date();
      var dateHeading =
        today.getDate() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getFullYear() +
        " " +
        today.getHours() +
        "_" +
        today.getMinutes() +
        "_" +
        today.getSeconds();
      // write the content using writeBuffer
      const buf = await workbook.xlsx.writeBuffer();

      // download the processed file
      saveAs(
        new Blob([buf]),
        "Dispense Summary Report " + dateHeading + ".xlsx"
      );
    } catch (error) {
      console.error("<<<ERRROR>>>", error);
      console.error("Something Went Wrong", error.message);
    } finally {
      // removing worksheet's instance to create new one
      workbook.removeWorksheet("Dispense");

      setIsLoading(false);
    }
  };

  const ExportToExcel1 = async () => {
    const workbook = new ExcelJS.Workbook();

    try {
      setIsLoading(true);

      var data = $("#gvUnmatchedReportPDF")
        .dataTable()
        ._("tr", { filter: "applied" });
      let filterDataExcel = [];
      let cntrow = 0;
      let ReferenceNumber1 = "";

      if (selectedChannelValue.value === "4") {
        for (let i = 0; i < data.length; i++) {
          let TxnsDate = "";
          TxnsDate = data[cntrow][3];
          TxnsDate = TxnsDate.replace("00:00:00", "");

          ReferenceNumber1 = data[cntrow][4];
          ReferenceNumber1 = ReferenceNumber1.replace("<button><u>", "");
          ReferenceNumber1 = ReferenceNumber1.replace("</u></button>", "");

          var arr = {
            ChannelName: data[cntrow][0],
            TransactionMode: data[cntrow][1],
            TerminalId: data[cntrow][2],
            TxnsDateTime: TxnsDate,
            ReferenceNumber: ReferenceNumber1,
            CustAccountNo: data[cntrow][5],
            TxnsAmount: data[cntrow][6],
            EJStatus: data[cntrow][7],
            SWStatus: data[cntrow][8],
            NWStatus: data[cntrow][9],
            GLStatus: data[cntrow][10],
            TxnsSubType: data[cntrow][11],
            OnSettled: data[cntrow][12],
          };
          filterDataExcel.push(arr);
          cntrow++;
        }
      } else if (selectedChannelValue.value === "7") {
        for (let i = 0; i < data.length; i++) {
          let TxnsDate = "";
          TxnsDate = data[cntrow][2];
          TxnsDate = TxnsDate.replace("00:00:00", "");

          ReferenceNumber1 = data[cntrow][3];
          ReferenceNumber1 = ReferenceNumber1.replace("<button><u>", "");
          ReferenceNumber1 = ReferenceNumber1.replace("</u></button>", "");

          var arr = {
            ChannelName: data[cntrow][0],
            TransactionMode: data[cntrow][1],
            TxnsDateTime: TxnsDate,
            ReferenceNumber: ReferenceNumber1,
            CustAccountNo: data[cntrow][6],
            TxnsAmount: data[cntrow][7],
            EJStatus: data[cntrow][8],
            SWStatus: data[cntrow][9],
            NWStatus: data[cntrow][10],
            GLStatus: data[cntrow][11],
            TxnsSubType: data[cntrow][12],
            OnSettled: data[cntrow][13],
          };
          filterDataExcel.push(arr);
          cntrow++;
        }
      } else {
        for (let i = 0; i < data.length; i++) {
          let TxnsDate = "";
          TxnsDate = data[cntrow][3];
          TxnsDate = TxnsDate.replace("00:00:00", "");

          ReferenceNumber1 = data[cntrow][4];
          ReferenceNumber1 = ReferenceNumber1.replace("<button><u>", "");
          ReferenceNumber1 = ReferenceNumber1.replace("</u></button>", "");

          var arr = {
            ChannelName: data[cntrow][0],
            TransactionMode: data[cntrow][1],
            TerminalId: data[cntrow][2],
            TxnsDateTime: TxnsDate,
            ReferenceNumber: ReferenceNumber1,
            CardNumber: data[cntrow][5],
            CustAccountNo: data[cntrow][6],
            TxnsAmount: data[cntrow][7],
            EJStatus: data[cntrow][8],
            SWStatus: data[cntrow][9],
            NWStatus: data[cntrow][10],
            GLStatus: data[cntrow][11],
            TxnsSubType: data[cntrow][12],
            OnSettled: data[cntrow][13],
          };
          filterDataExcel.push(arr);
          cntrow++;
        }
      }

      // Create Excel workbook and worksheet
      const worksheet = workbook.addWorksheet("DispenceUnmatched");

      // Define columns in the worksheet, these columns are identified using a key.
      if (selectedChannelValue.value === "4") {
        worksheet.columns = [
          { header: "ChannelName", key: "ChannelName" },
          { header: "TransactionMode", key: "TransactionMode" },
          { header: "TerminalId", key: "TerminalId" },
          { header: "TxnsDateTime", key: "TxnsDateTime" },
          { header: "ReferenceNumber", key: "ReferenceNumber" },
          { header: "CustAccountNo", key: "CustAccountNo" },
          { header: "TxnsAmount", key: "TxnsAmount" },
          { header: "EJStatus", key: "EJStatus" },
          { header: "SWStatus", key: "SWStatus" },
          { header: "NWStatus", key: "NWStatus" },
          { header: "GLStatus", key: "GLStatus" },
          { header: "TxnsSubType", key: "TxnsSubType" },
          { header: "OnSettled", key: "OnSettled" },
        ];

        worksheet.columns = [
          { width: 10 },
          { width: 15 },
          { width: 15 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 15 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
        ];
      } else if (selectedChannelValue.value === "7") {
        worksheet.columns = [
          { header: "ChannelName", key: "ChannelName" },
          { header: "TransactionMode", key: "TransactionMode" },
          { header: "TxnsDateTime", key: "TxnsDateTime" },
          { header: "ReferenceNumber", key: "ReferenceNumber" },
          { header: "CustAccountNo", key: "CustAccountNo" },
          { header: "TxnsAmount", key: "TxnsAmount" },
          { header: "EJStatus", key: "EJStatus" },
          { header: "SWStatus", key: "SWStatus" },
          { header: "NWStatus", key: "NWStatus" },
          { header: "GLStatus", key: "GLStatus" },
          { header: "TxnsSubType", key: "TxnsSubType" },
          { header: "OnSettled", key: "OnSettled" },
        ];

        worksheet.columns = [
          { width: 10 },
          { width: 15 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 15 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
        ];
      } else {
        worksheet.columns = [
          { header: "ChannelName", key: "ChannelName" },
          { header: "TransactionMode", key: "TransactionMode" },
          { header: "TerminalId", key: "TerminalId" },
          { header: "TxnsDateTime", key: "TxnsDateTime" },
          { header: "ReferenceNumber", key: "ReferenceNumber" },
          { header: "CardNumber", key: "CardNumber" },
          { header: "CustAccountNo", key: "CustAccountNo" },
          { header: "TxnsAmount", key: "TxnsAmount" },
          { header: "EJStatus", key: "EJStatus" },
          { header: "SWStatus", key: "SWStatus" },
          { header: "NWStatus", key: "NWStatus" },
          { header: "GLStatus", key: "GLStatus" },
          { header: "TxnsSubType", key: "TxnsSubType" },
          { header: "OnSettled", key: "OnSettled" },
        ];

        worksheet.columns = [
          { width: 10 },
          { width: 15 },
          { width: 15 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 15 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
          { width: 20 },
        ];
      }

      // loop through all of the columns and set the alignment with width.
      worksheet.columns.forEach((column) => {
        column.alignment = { horizontal: "center" };
      });

      worksheet.columns.forEach((column) => {
        if (selectedChannelValue.value === "4") {
          if (column._number === 7) {
            column.alignment = { horizontal: "right" };
          }
        } else if (selectedChannelValue.value === "7") {
          if (column._number === 6) {
            column.alignment = { horizontal: "right" };
          }
        } else {
          if (column._number === 8) {
            column.alignment = { horizontal: "right" };
          }
        }
      });

      // updated the font for first row.
      worksheet.getRow(1).font = { bold: true, color: { argb: "ffffff" } };

      // loop through data and add each one to worksheet
      filterDataExcel.forEach((singleData) => {
        worksheet.addRow(singleData);
      });

      // Add auto-filter on each column
      //worksheet.autoFilter = 'A1:D1';

      // Process each row for calculations and beautification
      worksheet.eachRow((row, rowNumber) => {
        row.eachCell((cell, colNumber) => {
          if (rowNumber == 1) {
            // First set the background of header row
            cell.fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "df5015" },
            };
          }
          // Set border of each cell
          cell.border = {
            top: { style: "thin" },
            left: { style: "thin" },
            bottom: { style: "thin" },
            right: { style: "thin" },
          };
        });
        //Commit the changed row to the stream
        row.commit();
      });

      //console.log(filterDataExcel);

      var today = new Date();
      var dateHeading =
        today.getDate() +
        "-" +
        (today.getMonth() + 1) +
        "-" +
        today.getFullYear() +
        " " +
        today.getHours() +
        "_" +
        today.getMinutes() +
        "_" +
        today.getSeconds();
      // write the content using writeBuffer
      const buf = await workbook.xlsx.writeBuffer();

      // download the processed file
      saveAs(
        new Blob([buf]),
        "Dispence Unmatched Transaction Report" + dateHeading + ".xlsx"
      );
    } catch (error) {
      console.error("<<<ERRROR>>>", error);
      console.error("Something Went Wrong", error.message);
    } finally {
      // removing worksheet's instance to create new one
      workbook.removeWorksheet("DispenceUnmatched");

      setIsLoading(false);
    }
  };

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Dispense Summary Report
        </h5>

        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">MIS Reports</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Dispense Summary Report</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="dispensereportFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="dispensereportFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#dispensereportFiltersCollapse"
                aria-expanded="true"
                aria-controls="dispensereportFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="dispensereportFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="dispensereportFiltersHeading"
              data-bs-parent="#dispensereportFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      onChange={handleChannelChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlMode">Mode Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlMode"
                      value={selectedModeValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsModeType.map((x) => ({
                        value: x.modeID,
                        label: x.modeName,
                      }))}
                      onChange={handleModeChange}
                    />
                  </div>

                  {/*{isShowTxnType &&(<div className="clientNameSelect col" id="dvTxnType">*/}
                  {/*        <label htmlFor="logType">Txn Type</label>*/}
                  {/*        <span className="text-danger font-size13">*</span>*/}
                  {/*        <Select*/}
                  {/*            defaultValue={selectedTxnTypeValue}*/}
                  {/*            options={optionsTxnType}*/}
                  {/*            id="ddlTxnType"*/}
                  {/*            onChange={handleTxnTypeChange}*/}
                  {/*            classNamePrefix="reactSelectBox"*/}
                  {/*            placeholder="Select..."*/}
                  {/*        />*/}
                  {/*</div>)}*/}

                  {isShowTerminal && (
                    <div className="clientNameSelect col">
                      <label htmlFor="logType">Terminal</label>
                      <Select
                        id="ddlTerminal"
                        value={selectedTerminalValue}
                        classNamePrefix="reactSelectBox"
                        options={optionsTerminalType.map((x) => ({
                          value: x.terminalid,
                          label: x.terminalid,
                        }))}
                        onChange={handleTerminalChange}
                      />
                    </div>
                  )}
                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  {/* <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button> */}
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onRefresh(e)}
                  >
                    Refresh
                  </button>

                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={(p) => onShow(p)}
                  >
                    Show
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {isShowModal && (
        <Modal
          centered
          className="AddNewTableModal"
          size="xl"
          show={isShowModal}
          onHide={() => setShowModal(false)}
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              Dispense Summary Job Details
            </Modal.Title>
          </Modal.Header>

          <Modal.Body size="xl">
            {isShow ? (
              <div className="spinner-container">
                <div className="loading-spinner"></div>
              </div>
            ) : dispensesummaryjobdetails && dispensesummaryjobdetails.length > 0 ? (
              <div className="table-responsive">
                <table
                  id="gvDispenseSummary"
                  className="table table-striped table-hover table-borderless align-middle"
                  style={{ width: "100%" }}
                >
                  <thead>
                    <tr>
                      <th scope="col">Client Name</th>
                      <th scope="col">Channel</th>
                      <th scope="col">Mode</th>
                      <th scope="col">From Date</th>
                      <th scope="col">To Date</th>
                      <th className="text-center" scope="col">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {dispensesummaryjobdetails.map((item, index) => (
                      <tr key={index}>
                        <td>{item.clientName}</td>
                        <td>{item.channelName}</td>
                        <td>{item.transactionMode}</td>
                        <td>{new Date(item.fromDate).toLocaleDateString("en-GB")}</td>
                        <td>{new Date(item.toDate).toLocaleDateString("en-GB")}</td>
                        <td className="text-center">
                          <button
                            type="button"
                            style={{ display: 'inline-block' }}
                            className={`btnStatusOutline ${buttonClass(item.status)}`}
                          >
                            {item.status}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div>No records found.</div>
            )}
          </Modal.Body>
        </Modal>
      )}


      {/* Bottom Content */}
      <div className="configLeftBottom">
        {(DispenseSummaryReport === null ||
          DispenseSummaryReport.length === 0) && (
            <div className="tableBorderBox pb-3 pt-3">
              <div className="clientNameSelect configFormatEntities">
                <p className="text-danger font-size12">No Records</p>
              </div>
            </div>
          )}
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {/* Table */}
            {DispenseSummaryReport !== null &&
              DispenseSummaryReport.length > 0 ? (
              <div>
                <div className="exportButton">
                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltipExcel}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={ExportToExcel}
                    >
                      <img src={ExcelIcon} alt="Excel" />
                    </button>
                  </OverlayTrigger>

                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltip}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={downloadPDF}
                    >
                      <img src={Pdf} alt="Pdf" />
                    </button>
                  </OverlayTrigger>
                </div>
                <div className="tableBorderBox pt-3">
                  <div className="w-100 table-responsive">
                    <div className="table-responsive tableContentBox">
                      <table
                        id="gvDispenseSummaryReportPDF"
                        className="table table-striped table-hover table-borderless align-middle"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th scope="col">Txn Date</th>
                            {isShowModeIMPSUPIOutward && (
                              <th scope="col">Terminal ID</th>
                            )}
                            {isShowModeIMPSUPIOutward && (
                              <th scope="col">GL Onus</th>
                            )}
                            {isShowModeIssuer && (
                              <th scope="col">GL Acquirer</th>
                            )}
                            {isShowModeOnusAcquirer && (
                              <th scope="col">GL Issuer</th>
                            )}
                            {isShowModeIMPSUPIOutward && (
                              <th scope="col">GL Total</th>
                            )}
                            {isShowModeOnusAcquirer && (
                              <th scope="col">SW Issuer</th>
                            )}
                            {isShowModeIMPSUPIOutward && (
                              <th scope="col">SW Acquirer</th>
                            )}
                            {isShowModeIssuer && (
                              <th scope="col">Switch Total</th>
                            )}
                            {isShowModeIMPSUPIOutward && (
                              <th scope="col">EJ Total</th>
                            )}
                            {isShowModeIssuer && (
                              <th scope="col">NFS Acquirer</th>
                            )}
                            {isShowModeOnusAcquirer && (
                              <th scope="col">NFS Issuer</th>
                            )}
                            {isShowModeIssuer && (
                              <th scope="col">NFS Acquirer Diff.</th>
                            )}
                            {isShowModeOnusAcquirer && (
                              <th scope="col">NFS Issuer Diff.</th>
                            )}
                            {isShowModeIMPSUPIOutward && (
                              <th scope="col">ATM Diff.</th>
                            )}
                            <th scope="col">UnSettled Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                          {DispenseSummaryReport.map((p, i) => {
                            return (
                              <tr key={i}>
                                <td>{formatDate1(p.txnDate)} </td>
                                {isShowModeIMPSUPIOutward && (
                                  <td>{p.terminalID}</td>
                                )}
                                {isShowModeIMPSUPIOutward && (
                                  <td>{p.glonus}</td>
                                )}
                                {isShowModeIssuer && <td>{p.glAcquirer}</td>}
                                {isShowModeOnusAcquirer && <td>{p.gliss}</td>}
                                {isShowModeIMPSUPIOutward && (
                                  <td>{p.glTotal}</td>
                                )}
                                {isShowModeOnusAcquirer && <td>{p.swiss}</td>}
                                {isShowModeIMPSUPIOutward && (
                                  <td>{p.swAcquirer}</td>
                                )}
                                {isShowModeIssuer && <td>{p.switchTotal}</td>}
                                {isShowModeIMPSUPIOutward && <td>{p.ej}</td>}
                                {isShowModeIssuer && <td>{p.nfsAcquirer}</td>}
                                {isShowModeOnusAcquirer && (
                                  <td>{p.nfsIssuer}</td>
                                )}
                                {isShowModeIssuer && (
                                  <td>
                                    <OverlayTrigger
                                      placement="top"
                                      delay={{ show: 250, hide: 400 }}
                                      overlay={renderTooltipShow}
                                    >
                                      <button
                                        className="editBox"
                                        onClick={() =>
                                          onNFSAcquirerDiffClick(
                                            p.txnDate,
                                            p.txnDate,
                                            p.terminalID
                                          )
                                        }
                                      >
                                        <u>{p.nfsAcquirerDiff}</u>
                                      </button>
                                    </OverlayTrigger>
                                  </td>
                                )}
                                {isShowModeOnusAcquirer && (
                                  <td>
                                    <OverlayTrigger
                                      placement="top"
                                      delay={{ show: 250, hide: 400 }}
                                      overlay={renderTooltipShow}
                                    >
                                      <button
                                        className="editBox"
                                        onClick={() =>
                                          onNFSIssuerDiffClick(
                                            p.txnDate,
                                            p.txnDate,
                                            p.terminalID
                                          )
                                        }
                                      >
                                        <u>{p.nfsIssuerDiff}</u>
                                      </button>
                                    </OverlayTrigger>
                                  </td>
                                )}
                                {isShowModeIMPSUPIOutward && (
                                  <td>
                                    <OverlayTrigger
                                      placement="top"
                                      delay={{ show: 250, hide: 400 }}
                                      overlay={renderTooltipShow}
                                    >
                                      <button
                                        className="editBox"
                                        onClick={() =>
                                          onATMDiffClick(
                                            p.txnDate,
                                            p.txnDate,
                                            p.terminalID
                                          )
                                        }
                                      >
                                        <u>{p.atmDiff}</u>
                                      </button>
                                    </OverlayTrigger>
                                  </td>
                                )}
                                <td>
                                  <OverlayTrigger
                                    placement="top"
                                    delay={{ show: 250, hide: 400 }}
                                    overlay={renderTooltipShow}
                                  >
                                    <button
                                      className="editBox"
                                      onClick={() =>
                                        onUnSettledAmountClick(
                                          p.txnDate,
                                          p.txnDate,
                                          p.terminalID
                                        )
                                      }
                                    >
                                      <u>{p.unSettledAmount}</u>
                                    </button>
                                  </OverlayTrigger>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        )}
      </div>

      {/* Bottom Content2 */}
      {isShow ? (
        <div className="spinner-container">
          <div className="loading-spinner"></div>
        </div>
      ) : (
        <>
          <div className="configLeftBottom">
            {UnmatchedReport !== null && UnmatchedReport.length > 0 ? (
              <div>
                <div className="exportButton">
                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltipExcel}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={ExportToExcel1}
                    >
                      <img src={ExcelIcon} alt="Excel" />
                    </button>
                  </OverlayTrigger>

                  <OverlayTrigger
                    placement="top"
                    delay={{ show: 150, hide: 400 }}
                    overlay={renderTooltip}
                  >
                    <button
                      type="button"
                      className="iconButtonBox"
                      onClick={downloadPDF1}
                    >
                      <img src={Pdf} alt="Pdf" />
                    </button>
                  </OverlayTrigger>
                </div>
                <div className="tableBorderBox pt-3">
                  <div className="w-100 table-responsive">
                    <div className="table-responsive tableContentBox">
                      <table
                        id="gvUnmatchedReportPDF"
                        className="table table-striped table-hover table-borderless align-middle"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th scope="col">Channel Name</th>
                            <th scope="col">Transaction Mode</th>
                            {isShowTerminalId && (
                              <th scope="col">Terminal ID</th>
                            )}
                            <th scope="col">TxnsDateTime</th>
                            <th scope="col">ReferenceNumber</th>
                            {isShowCardNo && <th scope="col">Card Number</th>}
                            <th scope="col">Cust Account No</th>
                            <th scope="col">Txns Amount</th>
                            <th scope="col">EJ Status</th>
                            <th scope="col">SW Status</th>
                            <th scope="col">NW Status</th>
                            <th scope="col">GLStatus</th>
                            <th scope="col">Txns Type</th>
                            <th scope="col">On Settled</th>
                          </tr>
                        </thead>
                        <tbody>
                          {UnmatchedReport.map((p, referenceNumber) => {
                            return (
                              <tr key={referenceNumber}>
                                <td>{p.channelName} </td>
                                <td>{p.transactionMode}</td>
                                {isShowTerminalId && <td>{p.terminalId}</td>}
                                <td>{p.txnsDateTime}</td>
                                <td>
                                  <OverlayTrigger
                                    placement="top"
                                    delay={{ show: 250, hide: 400 }}
                                    overlay={renderTooltipShow}
                                  >
                                    <button
                                      onClick={() =>
                                        onReferenceNumberClick(
                                          p.referenceNumber,
                                          p.terminalId,
                                          p.TxnsDateTime
                                        )
                                      }
                                    >
                                      <u>{p.referenceNumber}</u>
                                    </button>
                                  </OverlayTrigger>
                                </td>
                                {isShowCardNo && <td>{p.cardNumber}</td>}
                                <td>{p.custAccountNo}</td>
                                <td>{p.txnsAmount}</td>
                                <td>{p.ejStatus}</td>
                                <td>{p.swStatus}</td>
                                <td>{p.nwStatus}</td>
                                <td>{p.glStatus}</td>
                                <td>{p.txnsSubType}</td>
                                <td>{p.onSettled}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </>
      )}
      {isShow ? (
        <div className="spinner-container">
          <div className="loading-spinner"></div>
        </div>
      ) : (
        <>
          {referenceNo && (
            <TransactionDetails
              EJTxnList={EJTxnList}
              SWTxnList={SWTxnList}
              GLTxnList={GLTxnList}
              NWTxnList={NWTxnList}
              ReferenceNo={referenceNo}
              setReferenceNo={setReferenceNo}
            />
          )}

          <LoadingSpinner isShow={false} />
          <MessageBox
            alertJson={alertJson}
            setShowMessageBox={setShowMessageBox}
          />
        </>
      )}
    </div>
  );
};

export default DispenseReportMainWindow;
