﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import IMPSTTUMReportMainWindow from "./IMPSTTUMReportMainWindow";

const IMPSTTUMReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView d-flex">
            <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
                <IMPSTTUMReportMainWindow />
            </div>
        </div>
    );
};

export default IMPSTTUMReport;
