﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import IssuerTransactionTTUMReportMainWindow from "./IssuerTransactionTTUMReportMainWindow";

const IssuerTransactionTTUMReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView d-flex">
            <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
                <IssuerTransactionTTUMReportMainWindow />
            </div>
        </div>
    );
};

export default IssuerTransactionTTUMReport;
