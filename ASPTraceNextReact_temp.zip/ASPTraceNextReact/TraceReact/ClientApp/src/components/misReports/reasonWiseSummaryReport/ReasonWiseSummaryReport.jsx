﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import ReasonWiseSummaryReportMainWindow from "./ReasonWiseSummaryReportMainWindow";

const ReasonWiseSummaryReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <ReasonWiseSummaryReportMainWindow />
        </div>
    );
};

export default ReasonWiseSummaryReport;
