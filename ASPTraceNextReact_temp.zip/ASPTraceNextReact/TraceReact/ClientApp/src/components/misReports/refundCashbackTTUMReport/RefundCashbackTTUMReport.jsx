﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import RefundCashbackTTUMReportMainWindow from "./RefundCashbackTTUMReportMainWindow";

const RefundCashbackTTUMReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView d-flex">
            <SidebarMain />
            <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}>
                <RefundCashbackTTUMReportMainWindow />
            </div>
        </div>
    );
};

export default RefundCashbackTTUMReport;
