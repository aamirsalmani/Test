import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import SwitchFeeReportMainWindow from "./SwitchFeeReportMainWindow";

const SwitchFeeReport = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <SwitchFeeReportMainWindow />
        </div>
    );
};

export default SwitchFeeReport;
