import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from "react-select/async";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link, useLocation } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../../common/apiURL";
import { useSelector } from "react-redux";
import Excel from "../../../images/common/excel.svg";
import authHeader from "../../../pages/login/services/auth-header";
import "datatables.net-dt/js/dataTables.dataTables";
import "jquery/dist/jquery.min.js";
import { saveAs } from "file-saver";
import Pdf from "../../../images/common/pdf.svg";
import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";
const ConsoleSetReportMainWindow = () => {


    let location = useLocation();
     let capitalizedLocation = location.pathname.replace(/\b\w/g, (char) =>
        char.toUpperCase()
    );

    


  const currentUser = useSelector((state) => state.authReducer);
  const fetchClientData = (inputValue) => {
    setStartDate(null);
    setEndDate(null);
    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  };

  const onReset = (e) =>
  {
    setSelectedValue(null);
    setSelectedChannelValue(null);
    setStartDate(null);
    setEndDate(null);
  }
  

  const buttonClass = (status) => {
    switch (status) {
      case "Failed":
        return "btnFailed";
      case "Completed":
        return "btnCompleted";
      case "Start":
        return "btnAwaiting";
      default:
        return "btnDefault";
    }
  };
 
  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [inputValue, setValue] = useState("0");
  const [selectedValue, setSelectedValue] = useState(null);
  const [titleDate, setTitleDateValue] = useState("");
  const [isShowCardNo, setIsShowCardNo] = useState(false);

  // handle input change event
  const handleInputChange = (value) => {
    setValue(value);
  };

  const [optionsChannelType, setOptionsChannelTypeValue] = useState([
    { channelID: "0", channelName: "--Select--" },
  ]);

  const [selectedChannelValue, setSelectedChannelValue] = useState(null);


  const handleOptionsChannelType = (value) => {
    setOptionsChannelTypeValue(value);
  };

  const handleClientChange = (value) => {
    setConsoleSetColumn(null);
    setConsoleSetReport(null);
    setSelectedChannelValue(null);
    setSelectedValue(value);

if (value.clientID !== "0") {
      return MaximusAxios.get(
        "/api/Common/GetChannelOptionList?ClientId=" +
        value.clientID +
        "&UserID=" +
        currentUser.user.username,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsChannelType(result.data);
      });
    }
  };

  const handleChannelChange = (value) => {
    setSelectedChannelValue(value);
  }

  function formatDate1(dateString) {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0"); // Months are 0-indexed
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  }



  //   Date Calendar
  const [startDate, setStartDate] = useState(new Date());
  //   Date Calendar
  const [endDate, setEndDate] = useState(new Date());

  const setStartDateValue = (value) => {
    setConsoleSetColumn(null);
    setConsoleSetReport(null);
    setStartDate(value);
    setEndDate(value);
  };

//   const setEndDateValue = (value) => {
//     setConsoleSetColumn(null);
//     setConsoleSetReport(null);
//     if (startDate === null) {
//       setEndDate(null);
//       alert("Please enter From date first");
//     } else {
//       if (startDate > value) {
//         alert("To date must be greater than From date ");
//         setEndDate(null);
//       } else {
//         setEndDate(value);
//       }
//     }
//   };


  const [ConsoleSetReport, setConsoleSetReport] = useState(null);
    const [ConsoleSetColumn, setConsoleSetColumn] = useState(null);

  // Tooltip
  const renderTooltip = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to pdf
    </Tooltip>
  );

  const renderTooltipExcel = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Export to excel
    </Tooltip>
  );

  const renderTooltipShow = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to open window
    </Tooltip>
  );

  const formatDate = (date) => {
    var d = new Date(date),
      month = "" + (d.getMonth() + 1),
      day = "" + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2) month = "0" + month;
    if (day.length < 2) day = "0" + day;

    return [year, month, day].join("-");
  };

   const downloadExcel = () => {
  
          MaximusAxios.post(
              "api/Logger/InsertUserActivityReport",
              {
                  UserId: currentUser.user.username,
                  PageName: capitalizedLocation,
                  Activity: "Download Excel",
              },
              { headers: authHeader() }
          );
          if (selectedValue === null || selectedValue === undefined) {
              alert("Please select client!");
              return false;
          }
  
          if (
              startDate === undefined ||
              startDate === null
          ) {
              alert("Please select Date!");
              return false;
          }
  
        
  
          let datePart = formatDate(startDate);
  
          const FileName = `${selectedValue.clientName}_Settlement_${datePart}.xlsx`;
  
          // let FileName =
          //   "Settlement_" +   selectedReportTypeValue.label +  "_" +  formatDate(startDate) + ".xlsx";
          // setIsLoading(true);
          MaximusAxios.post(
              `api/Excel/SwitchingFeeTxnsReport`,
              {
                  ClientId: String(selectedValue.clientID),
                ChannelType: selectedChannelValue.label,
                  FromDateTxns: formatDate(startDate),
                  UserID: String(currentUser.user.username),
              },
              { responseType: "blob" }
          )
              .then(function (response) {
                  saveAs(response.data, FileName);
                  // setIsLoading(false);
              })
              .catch(function (error) {
                  if (error.response) {
                      setShowMessageBox({
                          isShow: true,
                          alertVariant: "danger",
                          alertTitle: "Error",
                          alertMessage: "Error occurred while processing your request",
                      });
                  }
                  console.log(error.response);
                  //setIsLoading(false);
              });
      };

       const downloadPDF = () => {
        if (ConsoleSetReport !== null) {
            if (ConsoleSetReport.length > 0) {
                alert('Please download report using excel utility');
            } else {
                alert('No Record Found');
            }
        } else {
            alert('No Record Found');
        }
    };

  const onShow = async () => {
    setConsoleSetReport(null);

    if (selectedValue === null || selectedValue.clientID === 0) {
      alert("Please select client!");
      return false;
    }

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      alert("Please select Channel!");
      return false;
    }

   
    if (startDate === undefined || startDate === null) {
      alert("Please select Date!");
      return false;
    }

    let ChannelId = 0;

    if (selectedChannelValue === undefined || selectedChannelValue === null) {
      ChannelId = 0;
    } else {
      ChannelId = selectedChannelValue.value;
    }

    setIsLoading(true);

    try {
        const response = await MaximusAxios.post(
            "api/Report/GetSwitchFeeReportList",
            {
                ClientID: selectedValue.clientID,
                ChannelID: selectedChannelValue.label,
                FromDateTxns: formatDate(startDate),
          },
          { headers: { "Content-Type": "application/json" }, mode: "cors" }
        );
    
        const data = response.data;
    
        if (data && data.length > 0) {
          // Dynamically get column names from first row
          const columns = Object.keys(data[0]);
          setConsoleSetColumn(columns); // dynamic columns
          setConsoleSetReport(data);    // dynamic rows
        } else {
          setConsoleSetReport([]);
          setConsoleSetColumn([]);
          alert("No records found");
        }
    
        setTitleDateValue(`Report Date : ${formatDate(startDate)} To ${formatDate(endDate)}`);
      } catch (error) {
        setTitleDateValue("");
        alert("Error occurred while processing your request");
      } finally {
        setIsLoading(false);
      } 
  
  };

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Fee Report
        </h5>

        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">MIS Reports</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Switch Fee Report</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="dispensereportFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="dispensereportFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#dispensereportFiltersCollapse"
                aria-expanded="true"
                aria-controls="dispensereportFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="dispensereportFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="dispensereportFiltersHeading"
              data-bs-parent="#dispensereportFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      onChange={handleChannelChange}
                    />
                  </div>
                 
                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
               
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>

                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={(p) => onShow(p)}
                  >
                    Show
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

     
     
                 {/* Bottom Content */}
                       <div className="configLeftBottom">
                 {(ConsoleSetReport === null || ConsoleSetReport.length === 0) &&
                   <div className="tableBorderBox pb-3 pt-3">
                     <div className="clientNameSelect configFormatEntities">
                       <p className="text-danger font-size12">No Records</p>
                     </div>
                   </div>
                 }
               
                 {/* Spinner */}
                 {isShow ? (
                   <div className="spinner-container">
                     <div className="loading-spinner"></div>
                   </div>
                 ) : (
                   <>
                     {(ConsoleSetReport != null && ConsoleSetReport.length > 0) && (
                       <div>
                         {/* Export Buttons - ABOVE the table */}
                         <div className="exportButton mb-2">
                           <OverlayTrigger
                             placement="top"
                             delay={{ show: 150, hide: 400 }}
                             overlay={renderTooltipExcel}
                           >
                             <button type="button" className="iconButtonBox" onClick={downloadExcel}>
                               <img src={Excel} alt="Excel" />
                             </button>
                           </OverlayTrigger>
               
                           <OverlayTrigger
                             placement="top"
                             delay={{ show: 150, hide: 400 }}
                             overlay={renderTooltip}
                           >
                             <button type="button" className="iconButtonBox" onClick={downloadPDF}>
                               <img src={Pdf} alt="Pdf" />
                             </button>
                           </OverlayTrigger>
                         </div>
               
                         {/* Table */}
                         <div className="tableBorderBox pt-3">
                           <div className="w-100 table-responsive">
                             {(ConsoleSetColumn != null && ConsoleSetColumn.length > 0) && (
                               <div className="table-responsive tableContentBox">
                                 <table
                                   id="gvConsoleSetReportPDF"
                                   className="table table-striped table-hover table-borderless align-middle"
                                   style={{ width: "100%" }}
                                 >
                                   <thead>
                                     <tr key='-1'>
                                       {ConsoleSetColumn.map((item) => <th scope="col">{item}</th>)}
                                     </tr>
                                   </thead>
                                   <tbody>
                                     {ConsoleSetReport.map((p, i) => (
                                       <tr key={i}>
                                         {ConsoleSetColumn.map((item) => <td scope="col">{p[item]}</td>)}
                                       </tr>
                                     ))}
                                   </tbody>
                                 </table>
                               </div>
                             )}
                           </div>
                         </div>
                       </div>
                     )}
                   </>
                 )}
               </div>
               
      
                  <LoadingSpinner isShow={false} />
                  <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default ConsoleSetReportMainWindow;
