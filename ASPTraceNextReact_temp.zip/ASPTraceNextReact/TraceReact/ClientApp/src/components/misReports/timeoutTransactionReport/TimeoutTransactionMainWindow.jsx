﻿import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from 'react-select/async';
import { Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import authHeader from "../../../pages/login/services/auth-header";
import MaximusAxios from "../../common/apiURL" ; 

import ExcelJS from "exceljs";
import { saveAs } from 'file-saver';


//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';

// Images
import CsvIcon from "../../../images/common/csv.svg";
import ExcelIcon from "../../../images/common/excel.svg";

import LoadingSpinner from "../../common/LoadingSpinner";
import MessageBox from "../../common/MessageBox";
import { useSelector } from "react-redux";


import jsPDF from 'jspdf'
import "jspdf-autotable";
import { getYear, getMonth } from "date-fns";

import * as XLSX from "xlsx";

const TimeoutTransactionMainWindow = () => {

    //const onReset = (e) => {
    //    e.preventDefault();
    //    window.location.reload(false);
    //}

    const currentUser = useSelector((state) => state.authReducer);

    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const fetchClientData = (inputValue) => {

        setStartDate(null);
        setEndDate(null);

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);
    const [titleDate, setTitleDateValue] = useState('');
    const [selectedChannelValue, setSelectedChannelValue] = useState(null);

    const handleInputChange = value => {
        setValue(value);
    };

    const handleClientChange = value => {
        setTimeoutReport(null);
        //setStartDate(null);
        //setEndDate(null);
        setSelectedValue(value);
    }

    var rangeYear = function (start, end) {
        var len = end - start + 1;
        var a = new Array(len);
        for (let i = 0; i < len; i++) a[i] = start + i;
        return a;
    }

    const years = rangeYear(2000, getYear(new Date()));
    const months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ];

    const [startDate, setStartDate] = useState(new Date());

    const [endDate, setEndDate] = useState(new Date());


    const setStartDateValue = value => {
        setStartDate(value);
        setTimeoutReport(null);
    }

     

    const [TimeoutReport, setTimeoutReport] = useState(null);

    const optionsTTUMType = [
        { value: "UPI", label: "UPI" },
        { value: "IMPS", label: "IMPS" },
    ];

    const [selectedModeTypeValue, setSelectedModeTypeValue] = useState(null);

    const handleModeTypeChange = value => {
        setSelectedModeTypeValue(value);
    } 

  
    // Tooltip
    const renderTooltip = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to CSV
        </Tooltip>
    );

    const renderTooltipExcel = (props) => (
        <Tooltip id="button-tooltip" {...props}>
            Export to excel
        </Tooltip>
    );



    const formatDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [year, month, day].join('-');
    }

    const formatReportDate = (date) => {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = '' + d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;

        return [day, month, year.substr(2)].join('');
    }


    const onSubmit = () => {

        setTimeoutReport(null);

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (selectedModeTypeValue === undefined || selectedModeTypeValue === null) {
            alert("Please select Channel!");
            return false;
        } 

        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        } 


        setIsLoading(true);

        MaximusAxios.post('api/Report/GetTimeOutReportList', {
            ClientID: selectedValue.clientID,
            TTUMType: selectedModeTypeValue.value,
            FromDate: formatDate(startDate),
            ToDate: formatDate(startDate),

        }, {  mode: 'cors' })
            .then(function (response) {
                setTimeoutReport(response.data);
                setTitleDateValue("Report Date : " + formatDate(startDate) + " To " + formatDate(startDate));
                setIsLoading(false);
                setSelectedChannelValue(selectedModeTypeValue.value);
                if (response.data === null || response.data.length === 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'No records found' }); }
            })
            .catch(function (error) {
                setTitleDateValue("");
                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                setIsLoading(false);
            });
    };
 

    $(document).ready(function () {

        if (TimeoutReport !== null && TimeoutReport.length > 0) {
            $('#gvTimeoutReportPDF').DataTable();
        }
    });


    const ExportToExcel = async () => {

        const workbook = new ExcelJS.Workbook();

        try {

            setIsLoading(true);

            let ChannelValue = "";
            if (selectedChannelValue === undefined || selectedChannelValue === null) {
                ChannelValue = "";
            }
            else {
                ChannelValue = selectedChannelValue;
            }

            var data = $("#gvTimeoutReportPDF").dataTable()._('tr', { "filter": "applied" });
            let filterDataExcel = [];
            let cntrow = 0;


            for (let i = 0; i < data.length; i++) {
                var arr = { "REFERENCENO": data[cntrow][0], "AMOUNT": data[cntrow][1], "ACCOUNTNUMBER": data[cntrow][2], "CYCLE": data[cntrow][3], "FILEDATE": data[cntrow][4], "REMARKS": data[cntrow][5], "TXNTYPE": data[cntrow][6] }
                filterDataExcel.push(arr);
                cntrow++;
            } 

            // Create Excel workbook and worksheet           
            const worksheet = workbook.addWorksheet('TIMEOUT');

            // Define columns in the worksheet, these columns are identified using a key. 

            worksheet.columns = [{ header: 'REFERENCENO', key: 'REFERENCENO' }, { header: 'AMOUNT', key: 'AMOUNT' }, { header: 'ACCOUNTNUMBER', key: 'ACCOUNTNUMBER' }, { header: 'CYCLE', key: 'CYCLE' }, { header: 'FILEDATE', key: 'FILEDATE' }, { header: 'REMARKS', key: 'REMARKS' }, { header: 'TXNTYPE', key: 'TXNTYPE' }];

            worksheet.columns = [
                { width: 30 }, { width: 15 }, { width: 25 }, { width: 15 }, { width: 15 }, { width: 45 }, { width: 10 }, 
            ];

            // loop through all of the columns and set the alignment with width.
            worksheet.columns.forEach(column => {
                column.alignment = { horizontal: 'center' };
            });

            worksheet.columns.forEach(column => {

                if (column._number === 2) {
                    column.alignment = { horizontal: 'right' };
                }

            });


            // updated the font for first row.
            worksheet.getRow(1).font = { bold: true, color: { argb: 'ffffff' } };

            // loop through data and add each one to worksheet
            filterDataExcel.forEach(singleData => {
                worksheet.addRow(singleData);
            });

            // Add auto-filter on each column
            //worksheet.autoFilter = 'A1:D1';

            // Process each row for calculations and beautification 
            worksheet.eachRow((row, rowNumber) => {

                row.eachCell((cell, colNumber) => {
                    if (rowNumber === 1) {
                        // First set the background of header row
                        cell.fill = {
                            type: 'pattern',
                            pattern: 'solid',
                            fgColor: { argb: 'df5015' }
                        };
                    };
                    // Set border of each cell 
                    cell.border = {
                        top: { style: 'thin' },
                        left: { style: 'thin' },
                        bottom: { style: 'thin' },
                        right: { style: 'thin' }
                    };
                })
                //Commit the changed row to the stream
                row.commit();
            });

            //console.log(filterDataExcel);

          
            var dateHeading = startDate.getDate() + '-' + (startDate.getMonth() + 1) + '-' + startDate.getFullYear() ;
            // write the content using writeBuffer
            const buf = await workbook.xlsx.writeBuffer();

            // download the processed file
            saveAs(new Blob([buf]), ChannelValue + ' Timeout Transaction Report ' + dateHeading + '.xlsx');

            setIsLoading(false);
        }
        catch (error) {
            console.error('<<<ERRROR>>>', error);
            console.error('Something Went Wrong', error.message);
        } finally {
            // removing worksheet's instance to create new one
            workbook.removeWorksheet('TIMEOUT');
        }
    };

    const downloadPDF = () => {
        let ChannelValue = "";
        if (TimeoutReport !== null) {
            if (TimeoutReport.length > 0) {

                MaximusAxios.get('api/Common/GetClientLogoImage?ClientId=' + selectedValue.clientID, {  mode: 'cors' }).then(result => {

                    
                    const headers = [["REFERENCENO", "AMOUNT", "ACCOUNTNUMBER", "CYCLE", "FILEDATE", "REMARKS", "TXNTYPE"]];

                    if (selectedChannelValue === undefined || selectedChannelValue === null) {
                        ChannelValue = "";
                    }
                    else {
                        ChannelValue = selectedChannelValue;
                    }

                    const title = ChannelValue + " Timeout Transaction Report ";

                    var data = $("#gvTimeoutReportPDF").dataTable()._('tr', { "filter": "applied" });
                    let filterDataPDF = [];
                    let cntrow = 0;
                    //console.log(data);
                    for (let i = 0; i < data.length; i++) {
                        var arr = [data[cntrow][0], data[cntrow][1], data[cntrow][2], data[cntrow][3], data[cntrow][4], data[cntrow][5], data[cntrow][6]];
                        filterDataPDF.push(arr);
                        cntrow++;
                    }
                    //console.log(filterDataPDF);
                    var today = new Date();
                    var dateHeading = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear() + ' ' + today.getHours() + '_' + today.getMinutes() + '_' + today.getSeconds();

                    const unit = "pt";
                    const size = "LEGAL";
                    const orientation = "landscape";

                    const doc = new jsPDF(orientation, unit, size);

                    //var pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
                    var pageWidth = doc.internal.pageSize.width || doc.internal.pageSize.getWidth();

                    //console.log(result); 

                    doc.addImage(result.data.clientLogo, 'PNG', 20, 20, 150, 50);

                    doc.addImage(result.data.traceLogo, 'PNG', pageWidth - 170, 20, 150, 50);

                    //doc.setTextColor(100);

                    doc.setFontSize(24);

                    doc.text(title, pageWidth / 2, 40, { align: 'center' });

                    doc.setFontSize(20);

                    doc.text(titleDate, pageWidth / 2, 65, { align: 'center' });

                    let content = {
                        startY: 80,
                        head: headers,
                        body: filterDataPDF
                    };

                    doc.setFontSize(10);
                    doc.autoTable(content);
                    doc.save(ChannelValue +" Timeout Transaction Report " + dateHeading + ".pdf")
                });
            } else {
                alert('No Record Found');
            }
        } else {
            alert('No Record Found');
        }
    };

 

    const ExportToCSV = () => { 

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }
        if (selectedModeTypeValue === undefined || selectedModeTypeValue === null) {
            alert("Please select Channel!");
            return false;
        }

        if (startDate === undefined || startDate === null) {
            alert("Please enter From Date!");
            return false;
        } 

        MaximusAxios.post('api/Report/Get_NPCI_BULK_UPLOAD_List', {
            ClientID: selectedValue.clientID,
            TTUMType: selectedModeTypeValue.value,
            FromDate: formatDate(startDate),
            ToDate: formatDate(startDate),

        }, {  mode: 'cors' })
            .then(function (response) {

                setIsLoading(false);

                if (response.data === null || response.data.length === 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'No records found' }); return; }
                 
                let ChannelValue = selectedModeTypeValue.value;

                if (selectedChannelValue === undefined || selectedChannelValue === null) {
                    ChannelValue = "";
                }
                else {
                    ChannelValue = selectedChannelValue;
                } 

                if (ChannelValue === "IMPS") {
                    response.data = response.data.map(item => {
                        const { ['utxid']: removedKey, ...rest } = item;
                        return rest;
                    });
                }
                // Convert JSON to worksheet
                const worksheet = XLSX.utils.json_to_sheet(response.data);

                // Create a new workbook
                const workbook = XLSX.utils.book_new();

                // Append worksheet to workbook
                XLSX.utils.book_append_sheet(workbook, worksheet, "TTC");

                // Generate buffer
                const csvBuffer = XLSX.write(workbook, { bookType: 'csv', type: 'array' });

                // Create a blob from the buffer
                const blob = new Blob([csvBuffer], { type: 'text/csv' });

                // Create a link element
                const link = document.createElement('a');

                // Set the download attribute with a filename
                if (ChannelValue === "IMPS") {
                    link.download = ChannelValue + 'CSV' + formatReportDate(startDate) + '.csv';
                }
                else if (ChannelValue === "UPI") {
                    link.download = ChannelValue + 'TCC ' + formatReportDate(startDate) + '.csv';
                } 

                // Create a URL for the blob and set it as the href attribute
                link.href = URL.createObjectURL(blob);

                // Append the link to the body
                document.body.appendChild(link);

                // Programmatically click the link to trigger the download
                link.click();

                // Remove the link from the document
                document.body.removeChild(link);
            })
            .catch(function (error) { 

                setIsLoading(false);

                if (error.response) {
                    setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' });
                }
                
            });

       

       
    };



    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Timeout Transaction Report
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">MIS Reports</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Timeout Transaction Report</p>
                </div>
            </div>

            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion" id="impsTimeoutReportFilters">
                    <div className="accordion-item">
                        <div
                            className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
                            id="impsTimeoutReportFiltersHeading"
                        >
                            <h6 className="fontWeight-600 colorBlack">Filters</h6>
                            <button
                                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#impsTimeoutReportFiltersCollapse"
                                aria-expanded="true"
                                aria-controls="impsTimeoutReportFiltersCollapse"
                            >
                                <span className="icon-Hide"></span>
                                <span className="ms-1 fontSize12-m colorBlack">
                                    Show / Hide
                                </span>
                            </button>
                        </div>
                        <div
                            id="impsTimeoutReportFiltersCollapse"
                            className="accordion-collapse collapse show"
                            aria-labelledby="impsTimeoutReportFiltersHeading"
                            data-bs-parent="#impsTimeoutReportFilters"
                        >
                            <div className="accordion-body">
                                <div className="hrGreyLine"></div>
                                <div className="configSelectBoxTop row">
                                    <div className="clientNameSelect col">
                                        <label htmlFor="clientName">Client Name</label>
                                        <span className="text-danger font-size13">*</span>
                                        <AsyncSelect
                                            cacheOptions
                                            defaultOptions
                                            value={selectedValue}
                                            getOptionLabel={e => e.clientName}
                                            getOptionValue={e => e.clientID}
                                            loadOptions={fetchClientData}
                                            onInputChange={handleInputChange}
                                            onChange={handleClientChange}
                                            id="ddlClient"
                                        />
                                    </div>
                                    <div className="clientNameSelect col"  >
                                        <label htmlFor="logType">Channel </label>
                                        <span className="text-danger font-size13">*</span>
                                        <Select
                                            defaultValue={selectedModeTypeValue}
                                            options={optionsTTUMType}
                                            id="ddlMode"
                                            onChange={handleModeTypeChange}
                                            classNamePrefix="reactSelectBox"
                                        />
                                    </div>
                                    <div className="clientNameSelect col">
                                        <label htmlFor="StartDate">From Date</label>
                                        <span className="text-danger font-size13">*</span>
                                        <DatePicker
                                            renderCustomHeader={({
                                                date,
                                                changeYear,
                                                changeMonth,
                                                decreaseMonth,
                                                increaseMonth,
                                                prevMonthButtonDisabled,
                                                nextMonthButtonDisabled,
                                            }) => (
                                                <div
                                                    style={{
                                                        margin: 1,
                                                        display: "flex",
                                                        justifyContent: "center",
                                                    }}
                                                >
                                                    <button onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous" style={{ top: -11, left: -10 }}></span>
                                                    </button>
                                                    <select
                                                        value={getYear(date)}
                                                        onChange={({ target: { value } }) => changeYear(value)}
                                                    >
                                                        {years.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <select
                                                        value={months[getMonth(date)]}
                                                        onChange={({ target: { value } }) =>
                                                            changeMonth(months.indexOf(value))
                                                        }
                                                    >
                                                        {months.map((option) => (
                                                            <option key={option} value={option}>
                                                                {option}
                                                            </option>
                                                        ))}
                                                    </select>

                                                    <button onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
                                                        <span className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next" style={{ top: -11, left: 10 }}></span>
                                                    </button>
                                                </div>
                                            )}
                                            selected={startDate}
                                            dateFormat="dd/MM/yyyy"
                                            onChange={(date) => setStartDateValue(date)}
                                            className="reportDate"
                                            maxDate={new Date()}
                                        />
                                    </div>
                                    
                                </div>

                                <div className="text-center btnsBtm">

                                    <button
                                        type="button"
                                        className="btnPrimary ms-2"
                                        onClick={onSubmit}
                                    >
                                        Show
                                    </button>

                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            {/* Bottom Content */}
            <div className="configLeftBottom">
                {(TimeoutReport === null || TimeoutReport.length === 0) &&
                    <div className="tableBorderBox pb-3 pt-3">
                        <div className="clientNameSelect configFormatEntities">
                            <p className="text-danger font-size12">No Records</p>
                        </div>
                    </div>
                }
                {/* Table */}
                {(TimeoutReport !== null && TimeoutReport.length > 0) ? (
                    <div>
                        <div className="exportButton">

                            <OverlayTrigger
                                placement="top"
                                delay={{ show: 150, hide: 400 }}
                                overlay={renderTooltipExcel}
                            >
                                <button type="button" className="iconButtonBox" onClick={ExportToExcel}>
                                    <img src={ExcelIcon} alt="Excel" />
                                </button>
                            </OverlayTrigger>

                            <OverlayTrigger
                                placement="top"
                                delay={{ show: 150, hide: 400 }}
                                overlay={renderTooltip}
                            >
                                <button type="button" className="iconButtonBox" onClick={ExportToCSV} >
                                    <img src={CsvIcon} alt="csv" />
                                </button>
                            </OverlayTrigger>
                        </div>
                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvTimeoutReportPDF" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                        <thead>
                                            <tr>
                                                <th scope="col">REFERENCENO</th>
                                                <th scope="col">AMOUNT</th>
                                                <th scope="col">AccountNumber</th>
                                                <th scope="col">CYCLE</th>
                                                <th scope="col">FILEDATE</th>
                                                <th scope="col">REMARKS</th>
                                                <th scope="col">TXNTYPE</th> 
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                TimeoutReport.map((p) => {
                                                    return <tr>
                                                        <td >{p.referenceNumber}</td>
                                                        <td >{p.txnAmount}</td>
                                                        <td >{p.accountNumber}</td>
                                                        <td >{p.cycle}</td>
                                                        <td >{p.fileDate}</td>
                                                        <td >{p.remarks}</td>
                                                        <td >{p.txnType}</td> 
                                                    </tr>
                                                })
                                            }

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
            </div>
            						
            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />

        </div>
    );
};

export default TimeoutTransactionMainWindow;
