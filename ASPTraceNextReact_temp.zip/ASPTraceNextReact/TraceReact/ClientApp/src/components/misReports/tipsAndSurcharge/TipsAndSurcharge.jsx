﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import TipsAndSurchargeMainWindow from "./TipsAndSurchargeMainWindow";

const TipsAndSurcharge = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
           <TipsAndSurchargeMainWindow />
        </div>
    );
};

export default TipsAndSurcharge;
