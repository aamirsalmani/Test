﻿import React from "react";
import { useSelector } from "react-redux";
// CSS

// Components
import SidebarMain from "../../common/SidebarMain";
import TxnCountMainWindow from "./TxnCountMainWindow";

const TxnCount = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <TxnCountMainWindow />
        </div>
    );
};

export default TxnCount;
