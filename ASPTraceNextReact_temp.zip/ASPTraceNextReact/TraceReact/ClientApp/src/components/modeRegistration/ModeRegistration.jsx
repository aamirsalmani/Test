﻿
import React from "react";
import { useSelector } from "react-redux";
// CSS
import "./modeRegistration.css";
// Components
import SidebarMain from "../common/SidebarMain";
import ModeRegistrationMainWindow from "./ModeRegistrationMainWindow";

const ModeRegistration = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
            {/* <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                <ModeRegistrationMainWindow />
            {/* </div> */}
        </div>
    );
};

export default ModeRegistration;
