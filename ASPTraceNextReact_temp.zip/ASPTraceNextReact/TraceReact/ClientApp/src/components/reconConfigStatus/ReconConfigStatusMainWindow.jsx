﻿import React, { useState } from "react";
import Select from "react-select";
import AsyncSelect from 'react-select/async';
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL" ; 
 
import { useSelector } from "react-redux"; 

const ReconConfigStatusMainWindow = () => {

    const currentUser = useSelector((state) => state.authReducer);

    const [isShow, setIsLoading] = useState(false);
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });


    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);

    const [MatchingList, setMatchingList] = useState(null);
    const [ImportConfigList, setImportConfigList] = useState(null);

    const fetchClientData = (inputValue) => {

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    const handleInputChange = value => {
        setValue(value);

    };

    const handleClientChange = value => {
        setSelectedValue(value);
        setMatchingList(null);
        setImportConfigList(null);

        if (value.clientID !== '0') {
            return MaximusAxios.get('/api/MatchingRule/GetMatchingGrid?ClientId=' + value.clientID, {  mode: 'cors' }).then(result => {
                setMatchingList(result.data);
            });
        }
    }

    return (
        <div className="configLeft reportContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Recon Config Status
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12 colorPrimaryDefault">Configuration</p>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span>
                    <p className="fontSize12">Recon Config Status</p>
                </div>
            </div>
            {/* Config Left Top */}
            <div className="configLeftTop">
                <div className="accordion-item">
                    <div className="containerWhiteBox d-flex justify-content-center w-100">
                        <div className="containerSmallBox">
                            <div className="clientNameSelect col">
                                <label htmlFor="clientName">Client Name</label>
                                <span className="text-danger font-size13">*</span>
                                <AsyncSelect
                                    cacheOptions
                                    defaultOptions
                                    value={selectedValue}
                                    getOptionLabel={e => e.clientName}
                                    getOptionValue={e => e.clientID}
                                    loadOptions={fetchClientData}
                                    onInputChange={handleInputChange}
                                    onChange={handleClientChange}
                                    id="ddlClient"
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <LoadingSpinner isShow={isShow} />
                <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
            </div>

            <div className="configLeftBottom"> 
            
                {(MatchingList !== null && MatchingList.length > 0) ? (
                    <div className="pt-3">
                        <h5 className="fontWeight-600 fileConfigHead colorBlack">
                            Matching Rule Config Status
                        </h5>

                        <div className="tableBorderBox pt-3">
                            <div className="w-100 table-responsive">
                                <div className="table-responsive tableContentBox" >
                                    <table id="gvMatchingList" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                        <thead>
                                            <tr>
                                                <th scope="col">Client Name</th>
                                                <th scope="col">Channel</th>
                                                <th scope="col">Mode Name</th>
                                                <th scope="col">Recon Type</th>
                                                <th scope="col">Import File Status</th>
                                                <th scope="col">Matching Rule Status</th>
                                                <th scope="col">Settlement Rule Status</th>
                                                <th scope="col">Matching Rule Selected Columns</th>
                                                <th scope="col">Settlement Rule Selected Columns</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {
                                                MatchingList.map((p, i) => {
                                                    return <tr key={i} >
                                                        <td >{p.clientName} </td>
                                                        <td >{p.channelName} </td>
                                                        <td >{p.matchingModeName}</td>
                                                        <td >{p.reconName}</td>
                                                        <td className={p.importFileStatus == 'Done' ? 'FileStatusGreen' : 'FileStatusRed'}>{p.importFileStatus}</td>
                                                        <td >{p.matchingRuleStatus} </td>
                                                        <td >{p.settlementRuleStatus} </td>
                                                        <td >{p.matchingRuleSelectedColumns} </td>
                                                        <td >{p.settlementRuleSelectedColumns} </td>
                                                    </tr>
                                                })
                                            }

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : null}
            </div>
        </div>
    );
};

export default ReconConfigStatusMainWindow;
