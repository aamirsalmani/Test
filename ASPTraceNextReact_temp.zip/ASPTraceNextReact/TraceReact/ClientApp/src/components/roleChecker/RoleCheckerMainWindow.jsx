import React, { useState, useEffect } from "react";
import Select from "react-select";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import MaximusAxios from "../common/apiURL";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables";
import "datatables.net-dt/css/jquery.dataTables.min.css";
import $ from "jquery";
import "jquery/dist/jquery.min.js";

// Images
import AccessRole from "../../images/common/filter.svg";

import { useSelector } from "react-redux";

const RoleCheckerMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const [RoleTableData, setRoleTableData] = useState(null);
  const [RoleAdd, setRoleAdd] = useState(true);
  const [optionsRole, setOptionsRoleValue] = useState(null);
  const [isNewEntry, setNewEntry] = useState(false);

  const [RoleTypeOption, setRoleTypeOption] = useState(true);

  //const Show Loader
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const fetchRoleData = () => {
    if (SelectedOptionStatus === null || SelectedOptionStatus === undefined) {
      alert("Please select Status");
    } else {
      setIsLoading(true);
      MaximusAxios.post(
        "api/RoleCreation/GetRoleAccessList",
        {
          UserID: currentUser.user.username,
          Status: SelectedOptionStatus.value,
        },
        { mode: "cors" }
      )
        .then((result) => {
          setRoleTableData(result.data);
          setIsLoading(false);
        })
        .catch(function (error) {
          if (error.response) {
            console.log(error.response.data);
          }
          setIsLoading(false);
        });
    }
  };

  const [isShowRemarkModal, setShowRemarkModal] = useState(false);

  const [RemarkValue, setRemarkValue] = useState(null);
  const [selectedRoleTypeValue, setSelectedRoleTypeValue] = useState();
  const [RoleID, setRoleID] = useState(0);

  const [RoleAccess, setRoleAccess] = useState(null);
  const [Access, setAccess] = useState(false);

  // const onNewClick = () => {};

  const optionsStatus = [
    { value: "Pending", label: "Pending" },
    { value: "Rejected", label: "Rejected" },
    { value: "Approved", label: "Approved" },
  ];

  const [SelectedOptionStatus, setSelectedOptionStatus] = useState(null);

  const handleOptionStatus = (value) => {
    setSelectedOptionStatus(value);
    setRoleTableData(null);
  };

  const onShow = (e) => {
    fetchRoleData();
  };

  const onReset = (e) => {
    e.preventDefault();
   setRoleTableData(null);
   setSelectedOptionStatus(null);
  };

  const onConfirmClick = (Role_ID) => {
    const PostParameter = {
      TrnID: Role_ID,
      Action: "Approve",
      UserName: currentUser.user.username,
      Remarks: "Approved",
    };

    if (window.confirm("Are you sure you want to Approve?")) {
      setIsLoading(true);

      MaximusAxios.post("api/RoleCreation/UpdateRoleStatus", PostParameter, {
        mode: "cors",
      })
        .then(function (response) {
          console.log(response);
          if (response.data.length > 0 && response.data === "1") {
            setShowMessageBox({
              isShow: true,
              alertVariant: "info",
              alertTitle: "Info",
              alertMessage: "Approved Successfully!",
            });
          } else if (response.data.length > 0 && response.data === "2") {
            setShowMessageBox({
              isShow: true,
              alertVariant: "info",
              alertTitle: "Info",
              alertMessage: "Action already taken!",
            });
          } else if (response.data === null || response.data.length === 0) {
            setShowMessageBox({
              isShow: true,
              alertVariant: "info",
              alertTitle: "Info",
              alertMessage: "Error occurred while processing your request",
            });
          }

          setIsLoading(false);
          setShowRemarkModal(false);
          setRoleTableData(null);
          fetchRoleData();
        })
        .catch(function (error) {
          //console.log(error.response.data);
          if (error.response) {
            setShowMessageBox({
              isShow: true,
              alertVariant: "danger",
              alertTitle: "Error",
              alertMessage: "Error occurred while processing your request",
            });
          }
          setIsLoading(false);
          setShowRemarkModal(false);
        });
    }
  };

  const onSubmit = () => {
    if (RemarkValue === null || RemarkValue.trim().length === 0) {
      alert("Please enter Remark!");
      return false;
    }

    const PostParameter = {
      TrnID: RoleID,
      Action: "Reject",
      UserName: currentUser.user.username,
      Remarks: RemarkValue,
    };

    setIsLoading(true);

    MaximusAxios.post("api/RoleCreation/UpdateRoleStatus", PostParameter, {
      mode: "cors",
    })
      .then(function (response) {
        if (response.data.length > 0 || response.data === "1") {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "Rejected Successfully!",
          });
        } else if (response.data.length > 0 || response.data === "2") {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "Action already taken!",
          });
        } else if (response.data === null || response.data.length === 0) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "Info",
            alertMessage: "Error occurred while processing your request",
          });
        }

        setIsLoading(false);
        setShowRemarkModal(false);
        setRemarkValue("");
        setRoleTableData(null);
        fetchRoleData();
      })
      .catch(function (error) {
        //console.log(error.response.data);
        if (error.response) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "danger",
            alertTitle: "Error",
            alertMessage: "Error occurred while processing your request",
          });
        }
        setIsLoading(false);
        setShowRemarkModal(false);
        setRemarkValue("");
      });
  };

  const onRejectClick = (RoleID) => {
    setRoleID(RoleID);
    setRemarkValue("");
    setShowRemarkModal(true);
  };

  const onClickAccess = (Role_ID) => {
    setRoleAccess(null);
    setRoleID(null);
    setAccess(true);

    MaximusAxios.get("/api/RoleCreation/GetRoleMenuList?RoleID=" + Role_ID, {
      mode: "cors",
    }).then((response) => {
      if (response.data === null || response.data.length === 0) {
        alert("No records found");
      }
      setRoleAccess(response.data);
      setRoleID(Role_ID);
    });
  };

  $(document).ready(function () {
    if (RoleTableData !== null && RoleTableData.length > 0) {
      $("#gvRole").DataTable({
        bDestroy: true,
        columnDefs: [{ orderable: false, targets: [3, 4] }],
      });
    }
  });

  // Tooltip

  const renderTooltipAdd = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to add new entry
    </Tooltip>
  );

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Role Checker
        </h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">User Management</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Role Checker</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="tableBorderBox containerWhiteBox d-flex justify-content-center w-100">
          <div className="containerSmallBox">
            <div className="tableBorderBox pt-3 accordion-item">
              <div className="configSelectBoxTop row">
                <div className="clientNameSelect col">
                  <label htmlFor="ddlRole">Status</label>
                  <span className="text-danger font-size13">*</span>
                  <Select
                    id="ddlStatus"
                    value={SelectedOptionStatus}
                    classNamePrefix="reactSelectBox"
                    options={optionsStatus}
                    onChange={handleOptionStatus}
                  />
                </div>
              </div>
              <div className="text-center btnsBtm">
                <button
                  type="button"
                  className="btnPrimaryOutline"
                  onClick={(e) => onReset(e)}
                >
                  Reset
                </button>
                <button
                  type="button"
                  className="btnPrimary ms-2"
                  onClick={(p) => onShow(p)}
                >
                  Show
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
      {/* Table Content */}
      <div className="configLeftBottom">
        <div>
          {/* Table */}
          {RoleTableData != null && RoleTableData.length > 0 ? (
            <div>
              <div className="exportButton"></div>
              <div className="tableBorderBox pt-3">
                <div className="w-100 table-responsive">
                  <div className="table-responsive tableRoleContentBox">
                    <table
                      id="gvRole"
                      className="table table-striped table-hover table-borderless align-middle"
                      style={{ width: "100%" }}
                    >
                      <thead>
                        <tr>
                          <th>Role Name</th>
                          <th>User Type</th>
                          <th>Status</th>
                          <th>Maker ID</th>
                          <th>Maker On</th>
                          <th>Maker Remarks</th>
                          <th>Checker ID</th>
                          <th>Checker On</th>
                          <th>Checker Remarks</th>
                          <th>Access</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {RoleTableData.map((p, index) => {
                          return (
                            <tr key={index}>
                              <td>{p.roleName}</td>
                              <td>{p.userType}</td>
                              <td>{p.mode}</td>
                              <td>{p.makerID}</td>
                              <td>{p.makerOn}</td>
                              <td>{p.makerRemarks}</td>
                              <td>{p.checkerID}</td>
                              <td>{p.checkerOn}</td>
                              <td>{p.checkerRemarks}</td>
                              <td>
                                <button onClick={() => onClickAccess(p.roleID)}>
                                  {" "}
                                  <img
                                    src={AccessRole}
                                    alt="Role Access"
                                    title="Role Access"
                                  />
                                </button>
                              </td>
                              <td>
                                {p.mode === "Pending" ? (
                                  <div className="text-center">
                                    <button
                                      className="editBox"
                                      onClick={() => onConfirmClick(p.roleID)}
                                    >
                                      <u
                                        className="colorPrimaryDefault"
                                        style={{ padding: "0.3rem 0.5rem" }}
                                      >
                                        Approve
                                      </u>
                                    </button>
                                    <button
                                      className="editBox"
                                      onClick={() => onRejectClick(p.roleID)}
                                    >
                                      <u
                                        className="text-danger"
                                        style={{ padding: "0.3rem 0.5rem" }}
                                      >
                                        Reject
                                      </u>
                                    </button>
                                  </div>
                                ) : (
                                  <span>{p.mode}</span>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="tableBorderBox pt-3">
              <div className="clientNameSelect configFormatEntities">
                <p className="text-danger font-size12">No Records</p>
              </div>
            </div>
          )}
        </div>
      </div>
      </>
        )}
      {isShowRemarkModal && (
        <Modal
          show={isShowRemarkModal}
          onHide={() => setShowRemarkModal(!isShowRemarkModal)}
          centered
          className="currencyTableModal"
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              Add Remark
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="currencyControl">
              <label htmlFor="Remark">Remark</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="Remark"
                id="Remark"
                placeholder="Enter Remark"
                className="inputTextBox"
                onChange={(e) => setRemarkValue(e.target.value)}
                value={RemarkValue}
                onKeyPress={(e) =>
                  !/[a-zA-Z ]/.test(e.key) && e.preventDefault()
                }
              />
            </div>
          </Modal.Body>
          <Modal.Footer>
            <button
              type="button"
              className="btnPrimary ms-2"
              onClick={onSubmit}
            >
              Reject
            </button>
          </Modal.Footer>
        </Modal>
      )}

      {Access && (
        <Modal
          show={Access}
          onHide={() => setAccess(!Access)}
          centered
          className="roleTableModal"
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              Role Access
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="text-center">
            <div className="w-100 table-responsive">
              <p className="fontWeight-600 colorBlack ModalHeading">
                Menu Details
              </p>
              <div className="tableBorderBox">
                <div className="d-flex justify-content-between align-items-center mt-3 mb-2">
                  <div className="w-100 table-responsive tableContentBox">
                    <table
                      className="table table-striped table-hover table-borderless align-middle"
                      id="RoleMenu"
                    >
                      <thead>
                        <tr>
                          <th scope="col">Report Name</th>
                          <th scope="col">Selected</th>
                          <th scope="col">Download Report</th>
                        </tr>
                      </thead>
                      <tbody>
                        {RoleAccess && RoleAccess.length > 0 ? (
                          RoleAccess.map((R, i) => {
                            return (
                              <tr key={i}>
                                <td>{R.menuName}</td>
                                <td>
                                  {R.active ? (
                                    <span>
                                      <b>&#10003;</b>
                                    </span>
                                  ) : (
                                    <span>x</span>
                                  )}
                                </td>
                                <td>
                                  {R.isReportSelected ? (
                                    <span>
                                      <b>&#10003;</b>
                                    </span>
                                  ) : (
                                    <span>x</span>
                                  )}
                                </td>
                              </tr>
                            );
                          })
                        ) : (
                          <tr>
                            <td colSpan="7">
                              <em>No record(s) found...</em>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>{" "}
              </div>
            </div>
          </Modal.Body>
        </Modal>
      )}

      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default RoleCheckerMainWindow;
