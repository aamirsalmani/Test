﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
import "../currencyRegistration/currencyRegistration.css";  
// Components
import SidebarMain from "../common/SidebarMain";
import RoleCreationMainWindow from "./RoleCreationMainWindow";

const RoleCreation = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView ">
            {/* <SidebarMain /> */}
            {/* <div className={company.sidebarOpen ? "sidebarOpened" : "sidebarClosed"}> */}
                <RoleCreationMainWindow />
            {/* </div> */}
        </div>
    );
};

export default RoleCreation;
