import React, { useState, useEffect } from "react";
import { Modal, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import AsyncSelect from "react-select/async";
import MaximusAxios from "../common/apiURL";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import $ from "jquery";
import Select from "react-select";
import AccessRole from "../../images/common/filter.svg";

// Images
import Delete from "../../images/common/redDelete.svg";
import editRow from "../../images/common/editRow.svg";

import { useSelector } from "react-redux";

const RoleCreationMainWindow = () => {
  $(document).ready(function () {
    $("#select_all").on("click", function () {
      if (this.checked) {
        $(".inputCheckBox").each(function () {
          this.checked = true;
        });
      } else {
        $(".inputCheckBox").each(function () {
          this.checked = false;
        });
      }
    });

    $(".inputCheckBox").on("click", function () {
      if ($(".inputCheckBox:checked").length === $(".inputCheckBox").length) {
        $("#select_all").prop("checked", true);
      } else {
        $("#select_all").prop("checked", false);
      }
    });
  });

  const renderTooltipAdd = (props) => (
    <Tooltip id="button-tooltip" {...props}>
      Click to add new role
    </Tooltip>
  );

  const optionsType = [
    { value: "Checker", label: "Checker" },
    { value: "Maker", label: "Maker" },
  ];

  const optionsStatus = [
    { value: "Pending", label: "Pending" },
    { value: "Rejected", label: "Rejected" },
    { value: "Approved", label: "Approved" },
  ];

  const currentUser = useSelector((state) => state.authReducer);

  const [buttonValue, setButtonValue] = useState("ADD");

  const [isShow, setIsLoading] = useState(false);

  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [selectedUserTypeValue, setSelectedUserTypeValue] = useState(null);

  const [Access, setAccess] = useState(false);

  const [RoleAccess, setRoleAccess] = useState(null);

  const [RoleCreation, setRoleCreation] = useState(null);

  const [SelectedOptionStatus, setSelectedOptionStatus] = useState(null);

  const [RoleAdd, setRoleAdd] = useState(null);

  const [RoleID, setRoleID] = useState(0);
  const [RoleNameValue, setRoleNameValue] = useState("");
  const [selectedMenus, setSelectedMenus] = useState("");
  const [DownloadMenustring, setDownloadMenustring] = useState("");
  const [isNewEntry, setNewEntry] = useState(false);
  const [inputerrors, setInputErrors] = useState("");

  const fetchRoleData = () => {
    if (SelectedOptionStatus === null || SelectedOptionStatus === undefined) {
      alert("Please select status");
    } else {
      setIsLoading(true);
      MaximusAxios.post(
        "api/RoleCreation/GetRoleAccessList",
        {
          UserID: currentUser.user.username,
          Status: SelectedOptionStatus.value,
        },
        { mode: "cors" }
      )
        .then((result) => {
          setRoleCreation(result.data);
          setIsLoading(false);
        })
        .catch(function (error) {
          if (error.response) {
            console.log(error.response.data);
          }
          setIsLoading(false);
        });
    }
  };

  const onShow = (e) => {
    fetchRoleData();
    setNewEntry(false);
  };

  const handleOptionStatus = (value) => {
    setSelectedOptionStatus(value);
  };

  const handleUserTypeChange = (value) => {
    setSelectedUserTypeValue(value);
    setRoleAccess(null);
  };

  const onFilterReset = () => {
    setSelectedOptionStatus(null);
  };
  const onReset = (e) => {
    e.preventDefault();
    setInputErrors("");
    // window.location.reload(false);
    onNewClick();
  };

  const onNewClick = () => {
    setButtonValue("ADD");
    setSelectedMenus("");
    setRoleNameValue("");
    setSelectedUserTypeValue(null);
    setNewEntry(true);
  };

  const onAddClick = () => {
    setRoleCreation(null);
    if (RoleNameValue === null || RoleNameValue.trim().length === 0) {
      alert("Please enter Role Name!");
      return false;
    } else if (!/^[a-zA-Z ]+$/.test(RoleNameValue)) {
      setInputErrors("Only alphabetic values are allowed.");
      return false;
    } else if (RoleNameValue.length < 3) {
      setInputErrors("Alphabetic value must be at least 3 characters long.");
      return false;
    } else if (RoleNameValue.length > 20) {
      setInputErrors("Alphabetic value must not exceed 20 characters.");
      return false;
    } else {
      setInputErrors("");
    }

    if (selectedUserTypeValue === null || selectedUserTypeValue === undefined) {
      alert("Please select User Type!");
      return false;
    }

    if (!selectedMenus?.trim() || !DownloadMenustring?.trim()) {
      alert("Please assign menu to current role!");
      return false;
    }

    setIsLoading(true);

    MaximusAxios.post(
      "/api/RoleCreation/AddUpdateRoleDetails",
      {
        Mode: buttonValue,
        RoleID: buttonValue === "ADD" ? "0" : RoleID,
        RoleName: RoleNameValue.trim(),
        RoleMenus: selectedMenus.trim(),
        ReportMenuString: DownloadMenustring.trim(),
        UserType: selectedUserTypeValue.value,
        CreatedBy: currentUser.user.username,
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setIsLoading(false);
        setNewEntry(false);
        if (response.data !== null && response.data === "2") {
          alert("Role already exists!");
          setNewEntry(true);
        } else if (response.data !== null && response.data === "1") {
          if (buttonValue === "ADD") {
            alert("Role Registration added successfully!");
          }
          if (buttonValue === "UPDATE") {
            alert("Role Registration updated successfully!");
          }
          if (buttonValue === "ADD") {
            setRoleCreation(null);
          }
          setRoleAdd(!RoleAdd);
        } else {
          alert(response.data);
          setRoleAdd(!RoleAdd);
        }
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });
    // fetchRoleData()
  };

  const onClickAccess = () => {
    setAccess(true);
    setRoleAccess(null);

    if (RoleAccess === null || RoleAccess === undefined) {
      console.log("s");
      MaximusAxios.get("/api/RoleCreation/GetRoleMenuList?RoleID=" + RoleID, {
        mode: "cors",
      }).then((response) => {
        if (response.data === null || response.data.length === 0) {
          alert("No records found");
        }
        setRoleAccess(response.data);
      });
    } else {
      // Convert Menustring to an array of menu IDs
      const menuIDs = selectedMenus.split(",").map((id) => id.trim());

      // Check if the current menuID is in the Menustring array
      const updatedMenuItems = RoleAccess.map((item) =>
        menuIDs.includes(item.menuID) ? { ...item, active: true } : item
      );

      const DownloadMenuIDs = DownloadMenustring.split(",").map((id) =>
        id.trim()
      );

      const updatedMenuItems2 = updatedMenuItems.map((item) =>
        DownloadMenuIDs.includes(item.menuID)
          ? { ...item, isReportSelected: true }
          : item
      );

      setRoleAccess(updatedMenuItems2);

      console.log(RoleAccess);
    }
  };

  const onSubmitBtn = () => {
    if (RoleAccess !== null && RoleAccess.length > 0) {
      let MenuName = "";
      let DownloadMenuName = ",";
      let i = 0;
      let j = 0;

      $(".inputCheckBox:checked").each(function () {
        if (this.checked && this.name === "selectmenu") {
          if (i === 0) MenuName = MenuName + this.id;
          else MenuName = MenuName + "," + this.id;
          i++;
        }
      });

      $(".reportCheckBox:checked").each(function () {
        if (this.checked && this.name === "report") {
          DownloadMenuName =
            DownloadMenuName + this.id.replace("report", "") + ",";
          j++;
        }
      });

      MenuName = MenuName.replace("select_all,", "");

      setSelectedMenus(MenuName);
      setDownloadMenustring(DownloadMenuName);
      setAccess(false);
      setNewEntry(true);
    } else {
      alert("Error occurred while processing your request");
    }
  };

  const onEditClick = (RoleID) => {
    if (window.confirm("Are you sure you want to edit.") === true) {
      EditRole(RoleID);
    }
  };

  const EditRole = (RoleID) => {
    setSelectedMenus("");
    setRoleNameValue("");
    setSelectedUserTypeValue(null);

    MaximusAxios.get("/api/RoleCreation/GetRoleMenuDetails?RoleID=" + RoleID, {
      mode: "cors",
    }).then((RoleGetresult) => {
      if (RoleGetresult.data != null) {
        setRoleID(RoleGetresult.data.roleID);
        setRoleNameValue(RoleGetresult.data.roleName);
        setSelectedMenus(RoleGetresult.data.roleMenus);
        setDownloadMenustring(RoleGetresult.data.reportMenuString);

        if (RoleGetresult.data.userType === "Checker") {
          setSelectedUserTypeValue({ value: "Checker", label: "Checker" });
        } else if (RoleGetresult.data.userType === "Maker") {
          setSelectedUserTypeValue({ value: "Maker", label: "Maker" });
        }

        setButtonValue("UPDATE");
        setNewEntry(true);
      }
    });
    fetchRoleData();
  };

  const onDeleteClick = (RoleID) => {
    if (window.confirm("Are you sure you want to delete.")) {
      setIsLoading(true);

      MaximusAxios.post(
        "/api/RoleCreation/RemoveRole",
        {
          TrnID: RoleID,
          Action: "Delete",
          UserName: currentUser.user.username,
          Remarks: "-",
        },
        { mode: "cors" }
      ).then(function (response) {
        if (response.data !== null || response.data.length > 0) {
          if (response.data !== null && response.data === "Delete") {
            alert("Role deleted successfully!");
          } else if (response.data !== null && response.data === "Error") {
            alert("Role can not be deleted!");
          } else {
            alert("Error occurred!");
          }
          setIsLoading(false);
          setRoleCreation(null);
          setRoleAdd(!RoleAdd);
        }
      });
    }
    fetchRoleData();
  };

  const onEditApprovedClick = (RoleIDValue, RoleStatus) => {
    setIsLoading(true);
    MaximusAxios.post(
      "/api/RoleCreation/UpdateApprovedRoleDetails",
      {
        UserID: RoleIDValue,
        Status: currentUser.user.username,
      },
      { mode: "cors" }
    )
      .then(function (response) {
        setIsLoading(false);
        if (response.data !== null && response.data.startsWith("Edit")) {
          const parts = response.data.split("|");
          if (parts.length > 1) {
            EditRole(parts[1]);
          } else {
            alert("Error accoured");
          }
        }
      })
      .catch(function (error) {
        setIsLoading(false);
        alert("Error accoured");
      });
  };

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">
          Role Creation
        </h5>

        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">User Management</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Role Creation</p>
        </div>
      </div>
      <div className="configLeftTop">
        <div className="tableBorderBox containerWhiteBox d-flex justify-content-center w-100">
          <div className="containerSmallBox">
            <div className="tableBorderBox pt-3 accordion-item">
              <div className="configSelectBoxTop row">
                <div className="clientNameSelect col">
                  <label htmlFor="ddlRole">Status</label>
                  <span className="text-danger font-size13">*</span>
                  <Select
                    id="ddlStatus"
                    value={SelectedOptionStatus}
                    classNamePrefix="reactSelectBox"
                    options={optionsStatus}
                    onChange={handleOptionStatus}
                  />
                </div>
              </div>
              <div className="text-center btnsBtm">
                <button
                  type="button"
                  className="btnPrimaryOutline"
                  onClick={onNewClick}
                >
                  + Add Role
                </button>
                <button
                  type="button"
                  className="btnPrimary ms-2"
                  onClick={(p) => onShow(p)}
                >
                  Show
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="configLeftBottom">
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {isNewEntry !== null && isNewEntry === false ? (
              <div>
                {(RoleCreation === null || RoleCreation.length === 0) && (
                  <div className="tableBorderBox pb-3 pt-3">
                    <div className="clientNameSelect configFormatEntities">
                      <p className="text-danger font-size12">No Records</p>
                    </div>
                  </div>
                )}
                {/* Table */}
                {RoleCreation !== null && RoleCreation.length > 0 ? (
                  <div>
                    <div className="exportButton">
                      <OverlayTrigger
                        placement="top"
                        delay={{ show: 150, hide: 400 }}
                        overlay={renderTooltipAdd}
                      >
                        <button
                          type="button"
                          className="iconAddButtonBox"
                          onClick={onNewClick}
                        >
                          <span className="icon-Plus">+</span>
                          <span className="ms-1 fontSize12-m colorPrimaryDefault">
                            Add User
                          </span>
                        </button>
                      </OverlayTrigger>
                    </div>
                    <div className="tableBorderBox pt-3">
                      <div className="w-100 table-responsive">
                        <div className="table-responsive tableContent">
                          <table
                            id="gvUserDetailsPDF"
                            className="table table-striped table-hover table-borderless align-middle"
                            style={{ width: "100%" }}
                          >
                            <thead>
                              <tr>
                                <th>Role Name</th>
                                <th>User Type</th>
                                <th>Status</th>
                                <th>Maker ID</th>
                                <th>Maker On</th>
                                <th>Maker Remarks</th>
                                <th>Checker ID</th>
                                <th>Checker On</th>
                                <th>Checker Remarks</th>
                                <th scope="col">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              {RoleCreation.map((p, access) => {
                                return (
                                  <tr key={access}>
                                    <td>{p.roleName}</td>
                                    <td>{p.userType}</td>
                                    <td>{p.mode}</td>
                                    <td>{p.makerID}</td>
                                    <td>{p.makerOn}</td>
                                    <td>{p.makerRemarks}</td>
                                    <td>{p.checkerID}</td>
                                    <td>{p.checkerOn}</td>
                                    <td>{p.checkerRemarks}</td>
                                    <td>
                                      {" "}
                                      {p.roleStatus === "Approved" &&
                                      p.roleExists ? (
                                        <button
                                          type="button"
                                          className="iconButtonBox"
                                          onClick={() =>
                                            onEditApprovedClick(
                                              p.roleID,
                                              p.roleStatus
                                            )
                                          }
                                        >
                                          <p id="edit"></p>
                                          <img
                                            src={editRow}
                                            alt="Edit"
                                            title="Edit"
                                          />
                                        </button>
                                      ) : (
                                        <div className="text-center">
                                          <button
                                            type="button"
                                            className="iconButtonBox"
                                            onClick={() =>
                                              onEditClick(p.roleID)
                                            }
                                          >
                                            <p id="edit"></p>
                                            <img
                                              src={editRow}
                                              alt="Edit"
                                              title="Edit"
                                            />
                                          </button>
                                          {p.roleStatus === "Pending" ? (
                                            <button
                                              type="button"
                                              className="iconButtonBox"
                                              onClick={() =>
                                                onDeleteClick(p.roleID)
                                              }
                                            >
                                              <p id="deActivate"></p>
                                              <img
                                                src={Delete}
                                                alt="Delete"
                                                title="Delete"
                                              />
                                            </button>
                                          ) : null}
                                        </div>
                                      )}
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            ) : (
              <div className="tableBorderBox PageWhiteBox PageWhiteBox2 d-flex justify-content-center w-100">
                <div className="containerSmallBox">
                  <div className="clientNameSelect col">
                    <label htmlFor="RoleName">Role Name</label>
                    <span className="text-danger font-size13">*</span>
                    <input
                      type="text"
                      name="RoleName"
                      id="RoleName"
                      className="inputTextBox"
                      placeholder="Enter New Role Name"
                      onChange={(e) => setRoleNameValue(e.target.value)}
                      value={RoleNameValue}
                      onKeyPress={(e) =>
                        !/[a-zA-Z ]/.test(e.key) && e.preventDefault()
                      }
                    />
                    {inputerrors !== null && inputerrors.length !== 0 && (
                      <span className="text-danger fontSize12">
                        {inputerrors}
                      </span>
                    )}
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlUserType">User Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      value={selectedUserTypeValue}
                      options={optionsType}
                      id="ddlUserType"
                      onChange={handleUserTypeChange}
                      classNamePrefix="reactSelectBox"
                    />
                  </div>

                  <div className="clientNameSelect col">
                    <div className="menuBox">
                      <p className="fontSize14 fontWeight-500 letterSpacing-2 mb-1">
                        Select Menu
                        <span className="text-danger font-size13">*</span>
                      </p>
                      <div
                        className="d-flex align-items-center"
                        onClick={onClickAccess}
                      >
                        <div className="menuLightBlueBox text-center">
                          <div>
                            <p className="fontSize16 fontWeight-500 colorPrimaryDefault">
                              Click To Open
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Buttons */}
                  <div className="text-center btnsBtm">
                    <button
                      type="button"
                      className="btnPrimaryOutline"
                      onClick={(e) => onReset(e)}
                    >
                      Reset
                    </button>
                    <button
                      type="button"
                      className="btnPrimary ms-2"
                      onClick={onAddClick}
                    >
                      {buttonValue === "UPDATE"
                        ? "Update"
                        : buttonValue === "ADD"
                        ? "Add"
                        : buttonValue}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {Access && (
        <Modal
          show={Access}
          onHide={() => setAccess(!Access)}
          centered
          className="roleTableModal"
        >
          <Modal.Header closeButton>
            <Modal.Title className="fontSize16-sm letterSpacing-2">
              Role Access
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="text-center">
            <div className="w-100 table-responsive">
              <p className="fontWeight-600 colorBlack ModalHeading">
                Menu Details
              </p>
              <div className="tableBorderBox">
                <div className="d-flex justify-content-between align-items-center mt-3 mb-2">
                  <div className="w-100 table-responsive tableContentBox">
                    <table
                      className="table table-striped table-hover table-borderless align-middle"
                      id="RoleMenu"
                    >
                      <thead>
                        <tr>
                          <th scope="col">Report Name</th>
                          <th scope="col">
                            <input
                              type="checkbox"
                              name="select_all"
                              id="select_all"
                            />
                            <label>Select All</label>
                          </th>
                          <th scope="col">Download Report</th>
                        </tr>
                      </thead>
                      <tbody>
                        {RoleAccess && RoleAccess.length > 0 ? (
                          RoleAccess.map((R, i) => {
                            return (
                              <tr key={i}>
                                <td className="text-start">{R.menuName}</td>
                                <td>
                                  <input
                                    type="checkbox"
                                    name="selectmenu"
                                    id={R.menuID}
                                    defaultChecked={R.active}
                                    className="inputCheckBox"
                                  />
                                </td>
                                <td>
                                  <input
                                    type="checkbox"
                                    name="report"
                                    id={"report" + R.menuID}
                                    disabled={!R.isReport}
                                    defaultChecked={R.isReportSelected}
                                    className="reportCheckBox"
                                  />
                                </td>
                              </tr>
                            );
                          })
                        ) : (
                          <tr>
                            <td colSpan="7">
                              <em>No record(s) found...</em>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <button
                type="button"
                className="btnPrimary ms-2"
                onClick={onSubmitBtn}
              >
                Submit
              </button>
            </div>
          </Modal.Body>
        </Modal>
      )}

      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};
export default RoleCreationMainWindow;
