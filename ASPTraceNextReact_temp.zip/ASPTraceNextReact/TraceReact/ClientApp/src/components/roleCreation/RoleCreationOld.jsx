﻿import React, { useState } from "react"; 
import { Modal} from "react-bootstrap";
import { Link } from "react-router-dom";
import AsyncSelect from 'react-select/async';
import MaximusAxios from "../common/apiURL" ;
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";  
import $ from 'jquery';
import 'jquery/dist/jquery.min.js'; 
import Select from "react-select";
import AccessRole from "../../images/common/filter.svg";  


// Images
import Delete from "../../images/common/redDelete.svg";
import editRow from "../../images/common/editRow.svg"; 

import { useSelector } from "react-redux"; 


const RoleCreationMainWindow = () => {


    $(document).ready(function () {
        $('#select_all').on('click', function () {
            if (this.checked) {
                $('.inputCheckBox').each(function () {
                    this.checked = true;
                });
            } else {
                $('.inputCheckBox').each(function () {
                    this.checked = false;
                });
            }
        });

        $('.inputCheckBox').on('click', function () {
            
            if ($('.inputCheckBox:checked').length === $('.inputCheckBox').length) {
                $('#select_all').prop('checked', true);
                
            } else {
                $('#select_all').prop('checked', false);
            }  
        });
    });

    const optionsType = [
        { value: "Checker", label: "Checker" },
        { value: "Maker", label: "Maker" },
    ];


    const currentUser = useSelector((state) => state.authReducer); 

    const [buttonValue, setButtonValue] = useState('ADD');

    const [isShowRoleModal, setShowRoleModal] = useState(false);

    
    const [isShow, setIsLoading] = useState(false);
   
    const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

    const [selectedUserTypeValue, setSelectedUserTypeValue] = useState(null);

    const [Access, setAccess] = useState(false);
    const [inputValue, setValue] = useState('0');
    const [selectedValue, setSelectedValue] = useState(null);

    const [RoleAccess, setRoleAccess] = useState(null);

    const [RoleCreation, setRoleCreation] = useState(null);

    const [RoleAdd, setRoleAdd] = useState(null);

    const [RoleID, setRoleID] = useState(0);
    const [RoleNameValue, setRoleNameValue] = useState('');
    const [DefaultPageAccessValue, setDefaultPageAccessValue] = useState('');
    const [ClientNameValue, setClientNameValue] = useState('');
    const [isNewEntry , setNewEntry] = useState(false);

    const fetchClientData = (inputValue) => {

        return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, {  mode: 'cors' }).then(result => {
            if (inputValue.length === 0) {
                return result.data;
            }
            else {
                return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
            }
        }).catch(function (error) {
            console.log(error.response);
        });
    }

    const handleInputChange = value => {
        setValue(value);

    };

    const handleClientChange = value => {

        setSelectedValue(value);
        setClientNameValue(value.clientName);
        setRoleCreation([]); 

        if (value.clientID !== '0') {

            return MaximusAxios.get('/api/RoleCreation/GetRoleList?ClientID=' + value.clientID, {  mode: 'cors' }).then(result => {
                setRoleCreation(result.data);
            });
        } 

        
    } 

    const handleUserTypeChange = value => {
        setSelectedUserTypeValue(value);
    }


    const onNewClick = () => {
        setShowRoleModal(true);
        setButtonValue('ADD');
        setDefaultPageAccessValue('');
        setRoleNameValue('');
        setNewEntry(true);
    }

    const onAddClick = () => {

        setRoleCreation(null);

        if (selectedValue === null || selectedValue.clientID === 0) {
            alert("Please select client!");
            return false;
        }

        if (RoleNameValue === null || RoleNameValue.length === 0) {
            alert("Please enter Role Name!");
            return false;
        }
        else if (RoleNameValue.trim().length === 0) {
            alert("Please enter proper Role Name!");
            return false;
        }

        if (DefaultPageAccessValue === null || DefaultPageAccessValue.length === 0) {
            alert("Please enter Default Page!");
            return false;
        }
        else if (DefaultPageAccessValue.trim().length === 0) {
            alert("Please enter proper Default Page!");
            return false;
        }    
        
        if (selectedUserTypeValue === null || selectedUserTypeValue === undefined) {
            alert("Please select User Type!");
            return false;
        } 

        setIsLoading(true);
        

        MaximusAxios.post('/api/RoleCreation/AddUpdateRole', {
            Mode: buttonValue,
            RoleID: buttonValue === 'ADD' ? '0' : RoleID,
            ClientID: selectedValue.clientID,
            RoleName: RoleNameValue.trim(),
            HomePage: DefaultPageAccessValue.trim(),
            UserType: selectedUserTypeValue.value,
            CreatedBy: currentUser.user.username,

        }, {  mode: 'cors' }).then(function (response) {
            setShowRoleModal(false);
                setIsLoading(false);

            if (response.data === 0) {
                alert("Role already exists!");
                MaximusAxios.get('/api/RoleCreation/GetRoleList?ClientID=' + selectedValue.clientID, {  mode: 'cors' }).then(result => {
                    setRoleCreation(result.data);
                });

            }else if (response.data !== null || response.data === '1') {
                if (buttonValue === 'ADD') alert('Role Registration added successfully!');
                if (buttonValue === 'UPDATE') alert('Role Registration updated successfully!');
                if (buttonValue === 'ADD') setRoleCreation(null);

                MaximusAxios.get('/api/RoleCreation/GetRoleList?ClientID=' + selectedValue.clientID, {  mode: 'cors' }).then(result => {
                    setRoleCreation(result.data);
                });

            } else {
                alert(response.data);
            }
            setRoleAdd(!RoleAdd);
        })
            .catch(function (error) {
                if (error.response) {
                    console.log(error.response.data);             
                }
                setIsLoading(false);
            });

        MaximusAxios.get('/api/RoleCreation/GetRoleList?ClientID=' + selectedValue.clientID, {  mode: 'cors' }).then(result => {
                    setRoleCreation(result.data);
                });
    };

    const onClickAccess = (Client_ID, Role_ID) => { 

        setRoleAccess(null);
        setRoleID(null);
        setAccess(true);

        MaximusAxios.get('/api/RoleCreation/GetRoleAccessRightsList?ClientID=' + Client_ID + '&RoleID=' + Role_ID, {  mode: 'cors' }).then(response => { 
            if (response.data === null || response.data.length === 0) { alert('No records found'); }
            setRoleAccess(response.data);
            setRoleID(Role_ID);
        });
    }



    const onSubmitBtn = () => {

        if (RoleAccess !== null && RoleAccess.length > 0) {

            let MenuName = '';
            let DownloadMenuName = ',';
            let i = 0;
            let j = 0;
            $('.inputCheckBox:checked').each(function () {
                if (this.checked && this.name==='selectmenu') {
                    if (i === 0) MenuName = MenuName + this.id;
                    else MenuName = MenuName + ',' + this.id;
                    i++;
                }
                else if (this.checked && this.name==='report') {
                    DownloadMenuName = DownloadMenuName  + this.id.replace('report','')+ ',';
                    j++;
                }
            });

            MenuName = MenuName.replace('select_all,', '');
           
            MaximusAxios.post('/api/RoleCreation/AssignRoleMenuAccessRights', {
                RoleID: RoleID,
                ClientID: selectedValue.clientID,
                Menustring: MenuName,
                DownloadReportMenustring: DownloadMenuName,
                CreatedBy: currentUser.user.username
            }, {  mode: 'cors' })
                .then(function (response) {
                    var records = parseInt(response.data);
                    setRoleAccess(null);
                    setAccess(false);
                    if (records > 0) { setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'Menu accessed rights assigned successfully.' }); }
                    else { setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: 'Error occurred while processing your request' }); }
                })
                .catch(function (error) {
                    setRoleAccess(null);
                    setAccess(false);
                    if (error.response) {
                        console.log(error.response.data);
                        setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: error.response.data });
                    }
                    setIsLoading(false);
                });
        }
        else {
            alert('Error occurred while processing your request');
        }
    }



    const onEditClick = (ClientID, RoleName, HomePage, RoleID) => { 
       
        if (window.confirm("Are you sure you want to edit.") === true) {

            setNewEntry(false);

            MaximusAxios.get('/api/RoleCreation/GetRoleDetails?ClientID=' + ClientID + '&RoleID=' + RoleID, {  mode: 'cors' }).then(RoleGetresult => {

                if (RoleGetresult.data != null) {
                    setRoleID(RoleGetresult.data.roleID);
                    setRoleNameValue(RoleGetresult.data.roleName);
                    setDefaultPageAccessValue(RoleGetresult.data.homePage);

                    if(RoleGetresult.data.userType==='Checker') 
                    {
                        setSelectedUserTypeValue({ value: "Checker", label: "Checker" });
                    }
                    else if(RoleGetresult.data.userType==='Maker') 
                    {
                        setSelectedUserTypeValue({ value: "Maker", label: "Maker" });
                    }
                 
                    setShowRoleModal(true);
                }

            });

            setButtonValue('UPDATE');
        }

    };

    const onDeleteClick = (RoleID) => {
      
        if (window.confirm("Are you sure you want to delete.")) {

            setIsLoading(true);

            MaximusAxios.post('/api/RoleCreation/DeleteRoleReg', {
                Mode: 'DELETE',
                RoleID: RoleID
            }, {  mode: 'cors' })
                .then(function (response) {

                    if (response.data !== null || response.data.length > 0) {
                        alert(response.data);
                        setIsLoading(false);
                        setRoleCreation(null);
                        setRoleAdd(!RoleAdd);
                    }

                    MaximusAxios.get('/api/RoleCreation/GetRoleList?ClientID=' + selectedValue.clientID, {  mode: 'cors' }).then(result => {
                        setRoleCreation(result.data);
                    });
                });
        }
    };

    

    return (
        <div className="configLeft currencyContainer">
            {/* Breadcrumb Box */}
            <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
                <h5 className="fontWeight-600 fileConfigHead colorBlack">
                    Role Creation
                </h5>

                <div className="d-flex align-items-center">
                    <Link to="/">
                        <p className="fontSize12 colorPrimaryDefault">Home</p>
                    </Link>
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span> 
                        <p className="fontSize12 colorPrimaryDefault">User Management</p> 
                    <span>
                        <svg
                            width="8"
                            height="100%"
                            viewBox="0 0 10 16"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                            className="mx-1"
                        >
                            <path
                                d="M3 4L7 8L3 12"
                                stroke="black"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="breadcrumbIcon"
                            />
                        </svg>
                    </span> 
                        <p className="fontSize12">Role Creation</p> 
                </div>
            </div>
            {/* Config Left Top */}
            <div className="tableBorderBox containerWhiteBox d-flex justify-content-center w-100">
                <div className="containerSmallBox">
                    <div className="clientNameSelect col">
                        <label htmlFor="clientName">Client Name</label>
                        <span className="text-danger font-size13">*</span>  
                        <AsyncSelect
                            cacheOptions
                            defaultOptions
                            value={selectedValue}
                            getOptionLabel={e => e.clientName}
                            getOptionValue={e => e.clientID}
                            loadOptions={fetchClientData}
                            onInputChange={handleInputChange}
                            onChange={handleClientChange}
                            id="ddlClient"
                        />
                        {(RoleCreation !== null && RoleCreation.length === 0) ? (<button type="button" className="iconAddRole" style={{ marginRight: "8px" }} onClick={onNewClick} >
                            <span className="icon-Plus">+</span>
                            <span className="ms-1 fontSize12-m colorPrimaryDefault" >Add Role</span>
                        </button>
                        ) : null}
                    </div> 
                    {/* Table */}
                    {(RoleCreation !== null && RoleCreation.length > 0) ? (
                        <div>
                            <div >
                                <button type="button" className="iconAddRole" style={{ marginRight: "8px" }} onClick={onNewClick} >
                                    <span className="icon-Plus">+</span>
                                    <span className="ms-1 fontSize12-m colorPrimaryDefault" >Add Role</span>
                                </button>
                            </div>
                            <div>
                                <div className="tableBorderBox pt-3">
                                    <div className="w-100 table-responsive">
                                        <div className="table-responsive tableContentBox" >
                                            <table id="RoleCreation" className="table table-striped table-hover table-borderless align-middle" style={{ width: "100%" }} >
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Role Name</th>
                                                        <th scope="col">Access</th>
                                                        <th scope="col">Update</th>
                                                        <th scope="col">Delete</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {
                                                        RoleCreation.map((p, index) => {
                                                            return <tr key={index}>
                                                                <td >{p.roleName}</td>
                                                                <td>
                                                                    <button onClick={() => onClickAccess(p.clientID, p.roleID)}> <img src={AccessRole} alt="Role Access" title="Role Access" /></button>
                                                                </td>
                                                                <td>
                                                                    <div className="text-center">
                                                                        <button type="button" className="iconButtonBox" onClick={() => onEditClick(p.clientID, p.roleName, p.homePage, p.roleID)} > 
                                                                        <img src={editRow} alt="Edit" title="Edit" />
                                                                       </button>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div className="text-center">
                                                                        <button type="button" className="iconButtonBox" onClick={() => onDeleteClick(p.roleID)} > 
                                                                        <img src={Delete} alt="Delete" title="Delete" />
                                                                        </button>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        })
                                                    }

                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : null}
                </div>
            </div>         
     

            {isShowRoleModal && (
                <Modal
                    show={isShowRoleModal}
                    onHide={() => setShowRoleModal(!isShowRoleModal)}
                    centered
                    className="currencyTableModal"
                >
                    <Modal.Header closeButton>
                        <Modal.Title className="fontSize16-sm letterSpacing-2">
                            {isNewEntry ? <span>Add</span> : <span>Update</span>} Role
              </Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="clientNameSelect col">
                            <label htmlFor="clientName">Client Name</label>
                            <span className="text-danger font-size13">*</span> 
                            <input
                                type="text"
                                name="ClientName"
                                id="ClientName"
                                className="inputTextBox" 
                                autoComplete="no"
                                value={ClientNameValue}
                                disabled
                            />
                        </div> 
                        <div className="clientNameSelect col">
                            <label htmlFor="RoleName">Role Name</label>
                            <span className="text-danger font-size13">*</span> 
                            <input
                                type="text"
                                name="RoleName"
                                id="RoleName"
                                className="inputTextBox"
                                placeholder="Enter New Role Name"
                                onChange={(e) => setRoleNameValue(e.target.value)}
                                value={RoleNameValue}
                                onKeyPress={(e) => !/[a-zA-Z ]/.test(e.key) && e.preventDefault()}
                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="defaultpageaccess">Default Page Access</label>
                            <span className="text-danger font-size13">*</span> 
                            <input
                                type="text"
                                name="defaultpageaccess"
                                id="defaultpageaccess"
                                className="inputTextBox"
                                placeholder="Enter Default Page Access (Eg:\ABC.aspx)"
                                onChange={(e) => setDefaultPageAccessValue(e.target.value)}
                                value={DefaultPageAccessValue}
                            />
                        </div>
                        <div className="clientNameSelect col">
                            <label htmlFor="defaultpageaccess">User Type</label>
                            <span className="text-danger font-size13">*</span> 
                            <Select
                                                defaultValue={selectedUserTypeValue}
                                                options={optionsType}
                                                id="ddlUserType"
                                                onChange={handleUserTypeChange}
                                                classNamePrefix="reactSelectBox"
                            />                             
                        </div>
                         
                    </Modal.Body>
                    <Modal.Footer>
                        <button type="button" className="btnPrimary ms-2" onClick={onAddClick} >{buttonValue}</button>
                    </Modal.Footer>
                </Modal>
            )}

            {Access && (
                <Modal
                    show={Access}
                    onHide={() => setAccess(!Access)}
                    centered
                    className="roleTableModal"
                >
                    <Modal.Header closeButton>
                        <Modal.Title className="fontSize16-sm letterSpacing-2">
                            Role Access
              </Modal.Title>
                    </Modal.Header>
                    <Modal.Body className="text-center">
                        <div className="w-100 table-responsive">
                            <p className="fontWeight-600 colorBlack ModalHeading">
                                Menu Details
                </p>
                            <div className="tableBorderBox">
                                <div className="d-flex justify-content-between align-items-center mt-3 mb-2">
                                    <div className="w-100 table-responsive tableContentBox">
                                        <table className="table table-striped table-hover table-borderless align-middle" id="RoleMenu">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Menu ID</th>
                                                    <th scope="col">Report Name</th>
                                                    <th scope="col">
                                                        <input type="checkbox"
                                                            name="select_all"
                                                            id="select_all"  />
                                                        <label>Select All</label>
                                                    </th>
                                                    <th scope="col">Download Report</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {
                                                    (RoleAccess && RoleAccess.length > 0) ?
                                                        RoleAccess.map( (R, i) => {
                                                            return <tr key={i} >
                                                                <td >{R.menuID} </td>
                                                                <td >{R.menuName}</td>
                                                                <td ><input type="checkbox"
                                                                    name="selectmenu"
                                                                    id={R.menuID}
                                                                    defaultChecked={R.active}
                                                                    className="inputCheckBox" /></td>
                                                                <td ><input type="checkbox"
                                                                    name="report"
                                                                    id={"report" + R.menuID}
                                                                    disabled={!R.isReport}
                                                                    defaultChecked={R.isReportSelected}
                                                                    className="inputCheckBox" /></td>
                                                            </tr>
                                                        })
                                                        :
                                                        <tr>
                                                            <td colSpan="7">
                                                                <em>No record(s) found...</em>
                                                            </td>
                                                        </tr>
                                                }
                                            </tbody>
                                        </table>
                                    </div>
                                </div> </div>
                        </div>
                        <div>
                            <button type="button" className="btnPrimary ms-2" onClick={onSubmitBtn}>Submit</button>
                        </div>
                    </Modal.Body>
                </Modal>
            )}

            <LoadingSpinner isShow={isShow} />
            <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
        </div>


    );


};
export default RoleCreationMainWindow;