﻿import React from "react";
import { useSelector } from "react-redux"; 
// Components
import SidebarMain from "../common/SidebarMain";
import RunReconProcessMainWindow from "./RunReconProcessMainWindow";

const RunReconProcess = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <RunReconProcessMainWindow />
        </div>
    );
};

export default RunReconProcess;
