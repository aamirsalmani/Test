﻿import React, { useState, useEffect } from "react";
import './runReconProcess.css';
import Select from "react-select";
import AsyncSelect from 'react-select/async';
import { Modal, Button, Tooltip, OverlayTrigger } from "react-bootstrap";
import { Link } from "react-router-dom";
import DatePicker from "react-datepicker";
import MaximusAxios from "../common/apiURL";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import { useSelector } from "react-redux";


//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"

import $ from 'jquery';
import 'jquery/dist/jquery.min.js';
import { getYear, getMonth } from "date-fns";

import "jspdf-autotable";
import { setChannel } from "../dynamicReconConfig/Redux/Reducers/MenuBarReducer";



const RunReconProcessMainWindow = () => {
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [inputValue, setValue] = useState('0');
  const [selectedClientValue, setSelectedClientValue] = useState(null);
  const [optionsChannelType, setOptionsChannelTypeValue] = useState([{ channelID: "0", channelName: "--Select--" }]);
  const [selectedChannelValue, setSelectedChannelValue] = useState(null);
  const [optionsModeType, setOptionsModeTypeValue] = useState([{ modeID: "0", modeName: "--Select--" }]);
  const [selectedModeValue, setSelectedModeValue] = useState(null);
  const [RunRecon, setRunRecon] = useState(null);
  const [FileStatus, setFileStatus] = useState(false);
  const [FileList, setFileList] = useState(null);
  const currentUser = useSelector((state) => state.authReducer);
  const [ClientChange, setClientChange] = useState(false);
  const [IsShowfiles, setIsShowFiles] = useState(false);
  const [FileCount, setFileCount] = useState(null);
  const [FileUploadedList, setFileUploadedList] = useState(null);
  const [showForceModal, setShowForceModal] = useState(false);
  const [remarks, setRemarks] = useState('');

  const [reconStatus, setReconStatus] = useState(-1);


  useEffect(() => {
    if (selectedClientValue) {
      setshowModal(false);
      setRunRecon(null);
      handleClientChange(selectedClientValue);
    }
  }, [ClientChange]);

  const onStatus = (item) => {
    setFileList(null);
    setIsLoading(true);
    setFileStatus(false);
    setConfirmEntry(false);
    setshowModal(false);
    MaximusAxios.post('api/RunReconProcess/GetRunReconFileStatusList', {
      ClientID: (item.clientID),
      ChannelID: (item.channelID),
      ModeID: (item.modeID),
      Fromdate: formatDateNew(item.fromdate),
      Todate: formatDateNew(item.todate),
      CreatedDate: item.createdDate

    }, { mode: 'cors' })
      .then(function (response) {
        setFileList(response.data);
        setFileStatus(true);
        setIsLoading(false);
        setConfirmEntry(true);
        setshowModal(true);
      })
      .catch(function (error) {
        if (error.response) {
          setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: error.response.data });
        }
        setIsLoading(false);
      });
  }


  const onReset = (e) => {
    e.preventDefault();
    setStartDate(null);
    setEndDate(null);
    setSelectedModeValue(null);
    setOptionsModeTypeValue([]);
    setSelectedChannelValue(null);
    setOptionsChannelTypeValue([]);
    setSelectedClientValue(null);
    setRunRecon(null);
    setFileList(null);
    setConfirmEntry(null);
    // window.location.reload(false);
  }

  const [ConfirmEntry, setConfirmEntry] = useState(false);
  const [showModal, setshowModal] = useState(false);
  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({ isShow: false, alertVariant: 'success', alertTitle: '', alertMessage: '' });

  /**
   * Fetch client data based on the input value and current user.
   * 
   * @param {string} inputValue - The input value to filter client options.
   * @returns {Promise<Array>} A promise that resolves to a list of client options.
   */
  const fetchClientData = (inputValue) => {
    // Reset start and end dates
    setStartDate(null);
    setEndDate(null);

    // Fetch client options from API
    return MaximusAxios.get('api/Common/GetClientOptionList?UserID=' + currentUser.user.username, { mode: 'cors' })
      .then(result => {
        // If no input value, return all data
        if (inputValue.length === 0) {
          return result.data;
        }
        // Filter data based on clientName matching input value
        else {
          return result.data.filter(d => d.clientName.toLowerCase().includes(inputValue.toLowerCase()));
        }
      })
      .catch(function (error) {
        // Log any errors with the API request
        console.log(error.response);
      });
  }
  var rangeYear = function (start, end) {
    var len = end - start + 1;
    var a = new Array(len);
    for (let i = 0; i < len; i++) a[i] = start + i;
    return a;
  }
  const years = rangeYear(2000, getYear(new Date()));
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const setStartDateValue = value => {
    setStartDate(value);
    setEndDate(value);
  }
  const setEndDateValue = value => {
    //alert (value);
    if (startDate === null) {
      setEndDate(null);
      alert('Please enter From date first');
    }
    else {
      if (startDate > value) {
        alert('To date must be greater than From date ');
        setEndDate(null);
      }
      else if (value > new Date(startDate.getTime() + 6 * 24 * 60 * 60 * 1000)) {
        alert('Date diff should not be greater than 7 days');
        setEndDate(null);
      }
      else {
        setEndDate(value);
      }
    }
  }
  const formatDate = (date) => {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2)
      month = '0' + month;
    if (day.length < 2)
      day = '0' + day;

    return [year, month, day].join('-');
  }
  const formatDateNew = (inputDate) => {
    const parts = inputDate.split('/');

    const day = parts[0];
    const month = parts[1];
    const year = parts[2];

    const date = new Date(`${year}-${month}-${day}`);

    const formattedDate = [
      date.getFullYear(),
      ('0' + (date.getMonth() + 1)).slice(-2),
      ('0' + date.getDate()).slice(-2)
    ].join('-');

    return formattedDate;
  };

  const handleInputChange = value => {
    setValue(value);
  };
  const handleClientChange = value => {
    setRunRecon(null);
    setSelectedClientValue(value);
    setSelectedChannelValue(null);
    setSelectedModeValue(null);
    setStartDate(null);
    setEndDate(null);

    let ChannelId = 0;
    let ModeId = 0;
    if (value.clientID !== '0' || selectedClientValue !== null) {
      if (setSelectedChannelValue === null || setSelectedChannelValue === undefined) {
        ChannelId = 0;
      }
      if (setSelectedModeValue === null || setSelectedModeValue === undefined) {
        ModeId = 0;
      }
      MaximusAxios.get('api/RunReconProcess/GetChannelRunReconProcessList?ClientId=' + value.clientID + '&ChannelID=' + value.channelID, { mode: 'cors' }).then(result => {
        setOptionsChannelTypeValue(result.data);
      });

      return MaximusAxios.get('api/RunReconProcess/GetRunReconHistoryRunReconProcessList?ClientID=' + value.clientID + '&ChannelID=' + ChannelId + '&ModeId=' + ModeId, { mode: 'cors' }).then(result => {
        setRunRecon(result.data);
      });
    }

  }
  const handleChannelChange = value => {
    setSelectedChannelValue(value);
    setSelectedModeValue(null);
    setRunRecon(null);
    //setStartDate(null);
    //setEndDate(null);
    let ChannelId = 0;
    let ModeId = 0;
    if (value === undefined || value === null) {
      ChannelId = 0;
    }
    else {
      ChannelId = value.value;
    }
    if (setSelectedModeValue === null || setSelectedModeValue === undefined) {
      ModeId = 0;
    }
    if (value.value !== '0' && selectedClientValue.clientID !== '0') {
      return MaximusAxios.get('api/RunReconProcess/GetModeRunReconProcessList?ClientID=' + selectedClientValue.clientID + '&ChannelID=' + value.value, { mode: 'cors' }).then(result => {
        setOptionsModeTypeValue(result.data);

        return MaximusAxios.get('api/RunReconProcess/GetRunReconHistoryRunReconProcessList?ClientID=' + selectedClientValue.clientID + '&ChannelID=' + ChannelId + '&ModeId=' + ModeId, { mode: 'cors' }).then(result => {
          setRunRecon(result.data);
        });

      });

    }

  }
  const handleModeChange = value => {
    setSelectedModeValue(value);
    setRunRecon(null);
    //setStartDate(null);
    //setEndDate(null);
    let ModeId = 0;
    if (value === undefined || value === null) {
      ModeId = 0;
    }
    else {
      ModeId = value.value;
    }

    return MaximusAxios.get('api/RunReconProcess/GetRunReconHistoryRunReconProcessList?ClientID=' + selectedClientValue.clientID + '&ChannelID=' + selectedChannelValue.value + '&ModeId=' + ModeId, { mode: 'cors' }).then(result => {
      setRunRecon(result.data);
    });
  }

  const getFileColumnHeaders = () => {
    if (FileUploadedList.length === 0) return [];
    return Object.keys(FileUploadedList[0]);
  };


  $(document).ready(function () {
    if (
      FileUploadedList !== null &&
      FileUploadedList.length > 0 &&
      !$.fn.DataTable.isDataTable("#FileList")
    ) {
      $("#FileList").DataTable({
        searching: false,
        ordering: true,
        info: false,
        lengthChange: false,
        scrollY: "200px",
        scrollCollapse: true
      });
    }
  });
  $(document).ready(function () {
    if (
      RunRecon !== null &&
      RunRecon.length > 0 &&
      !$.fn.DataTable.isDataTable("#gvRunRecon")
    ) {
      $("#gvRunRecon").DataTable({
        paging: false,
        searching: false,
        ordering: true,
        info: false,
        lengthChange: false,
      });
    }
  });

  const handleSubmit = () => {

    if (currentUser !== null && currentUser.user !== null) {

      if (selectedClientValue === null || selectedClientValue.clientID === 0) {
        alert("Please select client!");
        return false;
      }

      if (selectedChannelValue === undefined || selectedChannelValue === null) {
        alert("Please select Channel!");
        return false;
      }

      if (selectedModeValue === undefined || selectedModeValue === null) {
        alert("Please select mode Type!");
        return false;
      }

      if (startDate === undefined || startDate === null) {
        alert("Please enter From Date!");
        return false;
      }

      if (endDate === undefined || endDate === null) {
        alert("Please enter To Date!");
        return false;
      }


      let ChannelId = 0;

      if (selectedChannelValue === undefined || selectedChannelValue === null) {
        ChannelId = 0;
      }
      else {
        ChannelId = selectedChannelValue.value;
      }

      let ModeId = 0;

      if (selectedModeValue === undefined || selectedModeValue === null) {
        ModeId = 0;
      }
      else {
        ModeId = selectedModeValue.value;
        (ModeId == 1) ? ModeId = 2 : ModeId = ModeId;
      }

      setFileList(null);
      setFileStatus(false);
      setIsLoading(true);
      MaximusAxios.post('api/RunReconProcess/GetDefaultFileUploadCount', {
        FromDate: formatDate(startDate),
        ToDate: formatDate(endDate),
        ClientID: (selectedClientValue.clientID),
        ChannelID: ChannelId,
        ModeID: ModeId,

      }, { mode: 'cors' })
        .then(function (response) {
          setFileList(JSON.parse(response.data.jsonString));
          setReconStatus(response.data.reconStatus);
          setConfirmEntry(true);
          setshowModal(true);
          setIsLoading(false);
        })
        .catch(function (error) {
          if (error.response) {
            setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: error.response.data });
          }
          setIsLoading(false);
        });
    } else {
      alert('Session Timeout');
    }
  };

  const AddRunRecon = () => {
    let alertMessages = "";
    FileList.map((item) => {
      Object.keys(item).map((col) => {
        if (item[col] === 'No') {
          alertMessages += `Please upload all ${col} files.\n`;
        }
      })
    })
    if (alertMessages.length > 0) {
      setShowMessageBox({ isShow: true, alertVariant: "info", alertTitle: "Following files not found", alertMessage: alertMessages });
      return false;
    }
    else {
      if (reconStatus == 0) {
        setShowForceModal(true);
        setshowModal(false);
      }
      else {
        MaximusAxios.post('api/RunReconProcess/ConfirmRunReconAdd', {
          FromDate: formatDate(startDate),
          ToDate: formatDate(endDate),
          ClientID: String(selectedClientValue.clientID),
          ChannelID: String(selectedChannelValue.value),
          ModeID: String(selectedModeValue.value),
          User: currentUser.user.username,

        }, { mode: 'cors' })
          .then(function (response) {
            // console.log(response.data);
            setIsLoading(false);
            if (response.data !== null && response.data.length !== 0 && response.data !== 'Failed') {
              setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: 'Info', alertMessage: 'Run recon added successfully' });
              setClientChange(!ClientChange);
            }
            else {
              setshowModal(false);
              setShowMessageBox({ isShow: true, alertVariant: 'info', alertTitle: response.data, alertMessage: "Not able to add Run recon" });
            }

          })
          .catch(function (error) {
            if (error.response) {
              setShowMessageBox({ isShow: true, alertVariant: 'danger', alertTitle: 'Error', alertMessage: error.response.data });
              setClientChange(!ClientChange);
            }
            setIsLoading(false);
          });
      }

    }
  }

  const getColumnHeaders = () => {
    if (FileList.length === 0) return [];
    return Object.keys(FileList[0]);
  };

  const buttonClass = (status) => {
    switch (status) {
      case "Failed":
        return "btnFailed";
      case "Completed":
        return "btnCompleted";
      case "Start":
        return "btnAwaiting";
      default:
        return "btnDefault";
    }
  };

  const FileButtonStatus = (fileStatus) => {
    if (fileStatus !== null && fileStatus !== undefined) {
      switch (fileStatus.includes("Yes")) {
        case false:
          return "btnYellow";
        case true:
          return "btnCompleted";
        default:
          return "btnDefault";
      }
    }
    else {
      return "btnDefault";
    }
  };

  const handleForceRun = () => {
    setIsLoading(true);

    const payload = {
      ForceRemarks: remarks.trim(),
      FromDate: formatDate(startDate),
      ToDate: formatDate(endDate),
      ClientId: String(selectedClientValue.clientID),
      ChannelId: String(selectedChannelValue.value),
      ModeId: String(selectedModeValue.value),
      User: currentUser.user.username,
    };

    console.log(payload); // ✅ Inspect if needed

    MaximusAxios.post("api/RunReconProcess/ForceRunRecon", payload)
      .then((response) => {
        setIsLoading(false);
        if (response.data) {
          setShowMessageBox({
            isShow: true,
            alertVariant: "info",
            alertTitle: "",
            alertMessage: "Force Run executed successfully!",
          });
          setShowForceModal(false);
          setClientChange(!ClientChange);
          setRemarks(null);
        }
      })
      .catch((error) => {
        setIsLoading(false);
        setShowMessageBox({
          isShow: true,
          alertVariant: "danger",
          alertTitle: "Error",
          alertMessage:
            error.response?.data || "Something went wrong during Force Run",
        });
      });
  };



  const CheckFileCount = (status, filetype) => {
    // alert(filetype);
    if (filetype !== null) {
      if (currentUser !== null && currentUser.user !== null) {
        if (
          selectedClientValue === null ||
          selectedClientValue.clientID === 0
        ) {
          alert("Please select client!");
          return false;
        }

        if (
          selectedChannelValue === undefined ||
          selectedChannelValue === null
        ) {
          alert("Please select Channel!");
          return false;
        }

        if (selectedModeValue === undefined || selectedModeValue === null) {
          alert("Please select mode Type!");
          return false;
        }

        if (startDate === undefined || startDate === null) {
          alert("Please enter From Date!");
          return false;
        }

        if (endDate === undefined || endDate === null) {
          alert("Please enter To Date!");
          return false;
        }

        let ChannelId = 0;

        if (
          selectedChannelValue === undefined ||
          selectedChannelValue === null
        ) {
          ChannelId = 0;
        } else {
          ChannelId = selectedChannelValue.value;
        }

        let ModeId = 0;

        if (selectedModeValue === undefined || selectedModeValue === null) {
          ModeId = 0;
        } else {
          ModeId = selectedModeValue.value;
          ModeId == 1 ? (ModeId = 2) : (ModeId = ModeId);
        }

        setFileCount(null);
        setFileStatus(false);
        setIsLoading(true);
        MaximusAxios
          .post(
            "api/RunReconProcess/GetUploadedFileList?Filetype=" + filetype,
            {
              FromDate: formatDate(startDate),
              ToDate: formatDate(endDate),
              ClientID: selectedClientValue.clientID,
              ChannelID: ChannelId,
              ModeID: ModeId,
            },
            { mode: 'cors' }
          )
          .then(function (response) {
            setFileUploadedList(JSON.parse(response.data));
            setIsShowFiles(true);
            // setshowModal(true);
            setIsLoading(false);
            console.log("File Data " + FileUploadedList);
          })
          .catch(function (error) {
            if (error.response) {
              setShowMessageBox({
                isShow: true,
                alertVariant: "danger",
                alertTitle: "Error",
                alertMessage: error.response.data,
              });
            }
            setIsLoading(false);
          });
      } else {
        alert("Session Timeout");
      }
    }
  };

  return (
    <div className="configLeft reportContainer">
      {/* Breadcrumb Box */}
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">Run Recon</h5>

        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Run Recon</p>
        </div>
      </div>

      {/* Config Left Top */}
      <div className="configLeftTop">
        <div className="accordion" id="runreconFilters">
          <div className="accordion-item">
            <div
              className="d-flex justify-content-between align-items-center configLeftFilters accordion-header"
              id="runreconFiltersHeading"
            >
              <h6 className="fontWeight-600 colorBlack">Filters</h6>
              <button
                className="allFiltersBtn btn p-0 d-flex justify-content-center align-items-center"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#runreconFiltersCollapse"
                aria-expanded="true"
                aria-controls="runreconFiltersCollapse"
              >
                <span className="icon-Hide"></span>
                <span className="ms-1 fontSize12-m colorBlack">
                  Show / Hide
                </span>
              </button>
            </div>
            <div
              id="runreconFiltersCollapse"
              className="accordion-collapse collapse show"
              aria-labelledby="runreconFiltersHeading"
              data-bs-parent="#runreconFilters"
            >
              <div className="accordion-body">
                <div className="hrGreyLine"></div>
                <div className="configSelectBoxTop row">
                  <div className="clientNameSelect col">
                    <label htmlFor="clientName">Client Name</label>
                    <span className="text-danger font-size13">*</span>
                    <AsyncSelect
                      cacheOptions
                      defaultOptions
                      value={selectedClientValue}
                      getOptionLabel={(e) => e.clientName}
                      getOptionValue={(e) => e.clientID}
                      loadOptions={fetchClientData}
                      onInputChange={handleInputChange}
                      onChange={handleClientChange}
                      id="ddlClient"
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlChannel">Channel Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlChannel"
                      value={selectedChannelValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsChannelType.map((x) => ({
                        value: x.channelID,
                        label: x.channelName,
                      }))}
                      onChange={handleChannelChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ddlMode">Mode Type</label>
                    <span className="text-danger font-size13">*</span>
                    <Select
                      id="ddlMode"
                      value={selectedModeValue}
                      classNamePrefix="reactSelectBox"
                      options={optionsModeType.map((x) => ({
                        value: x.modeID,
                        label: x.modeName,
                      }))}
                      onChange={handleModeChange}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="StartDate">From Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={startDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setStartDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                  <div className="clientNameSelect col">
                    <label htmlFor="ToDate">To Date</label>
                    <span className="text-danger font-size13">*</span>
                    <DatePicker
                      renderCustomHeader={({
                        date,
                        changeYear,
                        changeMonth,
                        decreaseMonth,
                        increaseMonth,
                        prevMonthButtonDisabled,
                        nextMonthButtonDisabled,
                      }) => (
                        <div
                          style={{
                            margin: 1,
                            display: "flex",
                            justifyContent: "center",
                          }}
                        >
                          <button
                            onClick={decreaseMonth}
                            disabled={prevMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--previous"
                              style={{ top: -11, left: -10 }}
                            ></span>
                          </button>
                          <select
                            value={getYear(date)}
                            onChange={({ target: { value } }) =>
                              changeYear(value)
                            }
                          >
                            {years.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <select
                            value={months[getMonth(date)]}
                            onChange={({ target: { value } }) =>
                              changeMonth(months.indexOf(value))
                            }
                          >
                            {months.map((option) => (
                              <option key={option} value={option}>
                                {option}
                              </option>
                            ))}
                          </select>

                          <button
                            onClick={increaseMonth}
                            disabled={nextMonthButtonDisabled}
                          >
                            <span
                              className="react-datepicker__navigation-icon react-datepicker__navigation-icon--next"
                              style={{ top: -11, left: 10 }}
                            ></span>
                          </button>
                        </div>
                      )}
                      selected={endDate}
                      dateFormat="dd/MM/yyyy"
                      onChange={(date) => setEndDateValue(date)}
                      className="reportDate"
                      maxDate={new Date()}
                    />
                  </div>
                </div>

                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimaryOutline"
                    onClick={(e) => onReset(e)}
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    className="btnPrimary ms-2"
                    onClick={handleSubmit}
                  >
                    RunRecon
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Config Left Bottom */}
      <div className="configLeftBottom">
        {(RunRecon === null || RunRecon.length === 0) && (
          <div className="tableBorderBox pb-3 pt-3">
            <div className="clientNameSelect configFormatEntities">
              <p className="text-danger font-size12">No Records</p>
            </div>
          </div>
        )}
        {/* Table */}
        {isShow ? (
          <div className="spinner-container">
            <div className="loading-spinner"></div>
          </div>
        ) : (
          <>
            {/* Table */}
            {RunRecon !== null && RunRecon.length > 0 ? (
              <div>
                <div className="tableBorderBox pt-3">
                  <div className="w-100 table-responsive">
                    <div className="table-responsive tableContentBox">
                      <table
                        id="gvRunRecon"
                        className="table table-striped table-hover table-borderless align-middle"
                        style={{ width: "100%" }}
                      >
                        <thead>
                          <tr>
                            <th scope="col">Client Name</th>
                            <th scope="col">Channel </th>
                            <th scope="col">Mode </th>
                            <th scope="col">From Date</th>
                            <th scope="col">To Date</th>
                            <th scope="col">Created by</th>
                            <th scope="col">Created Date</th>
                            <th scope="col">Started On</th>
                            <th scope="col">End On</th>
                            <th scope="col">TimeTaken</th>
                            <th scope="col">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          {RunRecon.map((p, I) => {
                            return (
                              <tr key={I}>
                                <td>{p.clientName}</td>
                                <td>{p.channel}</td>
                                <td>{p.mode}</td>
                                <td>{p.fromdate}</td>
                                <td>{p.todate}</td>
                                <td>{p.createdby}</td>
                                <td>{p.createdDate}</td>
                                <td>{p.reconStartOn}</td>
                                <td>{p.reconEndOn}</td>
                                <td>{p.timeTaken}</td>
                                <td>
                                  <button
                                    type="button"
                                    className={`btnStatusOutline ${buttonClass(
                                      p.status
                                    )}`}
                                    onClick={() => onStatus(p)}
                                  >
                                    {p.status}
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </>
        )}
      </div>

      <Modal
        centered
        className="AddNewTableModal"
        size="xl"
        show={showModal}
        onHide={() => setshowModal(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {FileStatus
              ? "Run Recon Status"
              : "Run Recon File Status"}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body size="xl">
          <div
            id="unmatchedFiltersCollapse"
            className="accordion-collapse collapse show"
            aria-labelledby="unmatchedFiltersHeading"
            data-bs-parent="#unmatchedFilters"
          >
            <div className="accordion-body">
              <div className="hrGreyLine"></div>
              <div className="configSelectBoxTop row">
                {showModal && FileList && FileList.length > 0 ? (
                  <div>
                    <div className="tableBorderBox pt-3">
                      <div className="w-100 table-responsive">
                        <div className="table-responsive tableContentBox">
                          <table
                            id="gvRunRecon"
                            className="table table-striped table-hover table-borderless align-middle text-center"
                            style={{ width: "100%" }}
                          >
                            <thead>
                              <tr>
                                {getColumnHeaders().map((header, index) => (
                                  <th
                                    key={index}
                                    scope="col"
                                    style={{
                                      textAlign: "center",
                                      verticalAlign: "middle",
                                    }}
                                  >
                                    {header}
                                  </th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {FileList.map((row, rowIndex) => (
                                <tr key={rowIndex}>
                                  {getColumnHeaders().map(
                                    (header, colIndex) => (
                                      <td
                                        key={colIndex}
                                        style={{
                                          textAlign: "center",
                                          verticalAlign: "middle",
                                        }}
                                      >
                                        {header === "Switch" ||
                                          header === "GL" ||
                                          header === "Log" ||
                                          header === "MerchantFile" ||
                                          header === "EJ" ? (
                                          <div
                                            style={{
                                              display: "flex",
                                              justifyContent: "center",
                                              alignItems: "center",
                                              textDecoration: "none",
                                            }}
                                          >
                                            <button
                                              className={`btnStatusOutline ${FileButtonStatus(
                                                row[header]
                                              )}`}
                                              onClick={() =>
                                                CheckFileCount(
                                                  row[header],
                                                  header
                                                )
                                              }
                                            >
                                              <b>{row[header]}</b>
                                            </button>
                                          </div>
                                        ) : (
                                          row[header]
                                        )}
                                      </td>
                                    )
                                  )}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p>No data available.</p>
                )}
              </div>
              <div className="configSelectBoxTop row">
                <div className="text-center btnsBtm">
                  {!FileStatus && (
                    <button
                      type="button"
                      className="btnPrimary ms-2"
                      onClick={AddRunRecon}
                      disabled={isShow} // Disable if loading
                    >
                      RunRecon
                    </button>
                  )}
                  {FileStatus && (
                    <button
                      type="button"
                      className="btnPrimary ms-2"
                      onClick={() => {
                        setClientChange(!ClientChange);
                        setshowModal(false);
                      }}
                    >
                      Close
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </Modal.Body>
      </Modal>

      <Modal
        centered
        className="AddNewTableModal"
        size="xl"
        show={IsShowfiles}
        onHide={() => {
          setshowModal(true);
          setIsShowFiles(false);
        }}
      >
        <Modal.Header closeButton>
          <Modal.Title>File Details</Modal.Title>
        </Modal.Header>
        <Modal.Body size="xl">
          <div
            className="accordion-collapse collapse show"
            aria-labelledby="unmatchedFiltersHeading"
            data-bs-parent="#unmatchedFilters"
          >
            <div className="accordion-body">
              <div className="hrGreyLine"></div>
              <div className="configSelectBoxTop row">
                {IsShowfiles &&
                  FileUploadedList &&
                  FileUploadedList.length > 0 ? (
                  <div>
                    <div className="tableBorderBox pt-3">
                      <div className="w-100 table-responsive">
                        <div className="table-responsive tableContentBox">
                          <table
                            id="FileList"
                            className="table table-striped table-hover table-borderless align-middle"
                            style={{ width: "100%" }}
                          >
                            <thead>
                              <tr>
                                {getFileColumnHeaders().map((header, index) => (
                                  <th key={index} scope="col">
                                    {header}
                                  </th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {FileUploadedList.map((row, rowIndex) => (
                                <tr key={rowIndex} >
                                  {getFileColumnHeaders().map(
                                    (header, colIndex) => (
                                      <td key={colIndex}>{row[header]}</td>
                                    )
                                  )}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p>No files available.</p>
                )}
              </div>
            </div>
          </div>
        </Modal.Body>
      </Modal>
      <Modal
        centered
        className="AddNewTableModal"
        show={showForceModal}
        onHide={() => setShowForceModal(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>Force Run Recon</Modal.Title>
        </Modal.Header>
        <Modal.Body size="xl">
          <div
            id="forceRunCollapse"
            className="accordion-collapse collapse show"
            aria-labelledby="forceRunHeading"
          >
            <div className="accordion-body">
              <div className="hrGreyLine"></div>
              <div className="configSelectBoxTop row">
                <div className="col-12">
                  <label htmlFor="remarksInput" className="form-label fw-bold">
                    Do you want to forcefully run recon? Enter remarks:
                  </label>
                  <input
                    id="remarksInput"
                    type="text"
                    className="inputTextBox"
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="Enter your remarks here..."
                  />
                </div>
              </div>

              <div className="configSelectBoxTop row mt-4">
                <div className="text-center btnsBtm">
                  <button
                    type="button"
                    className="btnPrimary me-2"
                    onClick={() => setShowForceModal(false)}
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="btnPrimary"
                    onClick={handleForceRun}
                  //disabled={remarks.trim() === ""}
                  >
                    Force Run
                  </button>
                </div>
              </div>
            </div>
          </div>
        </Modal.Body>
      </Modal>




      <LoadingSpinner isShow={false} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );


};

export default RunReconProcessMainWindow;
