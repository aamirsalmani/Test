﻿import React from "react";
import { useSelector } from "react-redux"; 
// Components
import SidebarMain from "../common/SidebarMain";
import SearchByRRNMainWindow from "./SearchByRRNMainWindow";

const SearchByRRN = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <SearchByRRNMainWindow />
        </div>
    );
};

export default SearchByRRN;
