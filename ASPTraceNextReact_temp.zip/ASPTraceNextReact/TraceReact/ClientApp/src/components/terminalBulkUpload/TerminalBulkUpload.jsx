﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
import "./terminalBulkUpload.css"; 
// Components
import TerminalBulkUploadMainWindow from "./TerminalBulkUploadMainWindow";
import SidebarMain from "../common/SidebarMain";

const TerminalBulkUpload = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <TerminalBulkUploadMainWindow />
        </div>
    );
};

export default TerminalBulkUpload;
