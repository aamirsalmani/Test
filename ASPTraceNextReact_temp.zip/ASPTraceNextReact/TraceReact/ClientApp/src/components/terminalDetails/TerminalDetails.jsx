﻿import React from "react";
import { useSelector } from "react-redux";
// CSS
import "../fieldIdentification/fieldConfig.css";
// Components
import SidebarMain from "../common/SidebarMain";
import TerminalDetailsMainWindow from "./TerminalDetailsMainWindow";


const TerminalDetails = () => {
    const company = useSelector((state) => {
        return state.sidebarReducer;
    });

    return (
        <div className="mainView">
                <TerminalDetailsMainWindow />
        </div>
    );
};

export default TerminalDetails;
