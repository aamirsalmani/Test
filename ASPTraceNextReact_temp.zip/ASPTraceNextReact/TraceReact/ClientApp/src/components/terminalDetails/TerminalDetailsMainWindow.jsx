﻿import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import "react-datepicker/dist/react-datepicker.css";
import AsyncSelect from "react-select/async";
import Select from "react-select";
import MaximusAxios from "../common/apiURL";
import LoadingSpinner from "../common/LoadingSpinner";
import MessageBox from "../common/MessageBox";
import $ from "jquery";

import { useSelector } from "react-redux";

const TerminalDetailsMainWindow = () => {
  const currentUser = useSelector((state) => state.authReducer);

  const fetchClientData = (inputValue) => {
    return MaximusAxios.get(
      "api/Common/GetClientOptionList?UserID=" + currentUser.user.username,
      { mode: "cors" }
    )
      .then((result) => {
        if (inputValue.length === 0) {
          return result.data;
        } else {
          return result.data.filter((d) =>
            d.clientName.toLowerCase().includes(inputValue.toLowerCase())
          );
        }
      })
      .catch(function (error) {
        console.log(error.response);
      });
  };

  const handleClientChange = (value) => {
    setSelectedValue(value);
    setSelectedBranchValue(null);

    if (value.clientID !== "0") {
      return MaximusAxios.get(
        "/api/TerminalRegistration/GetBranchMasterList?ClientID=" +
          value.clientID,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsBranchName(result.data);
        console.log(result.data);
      });
    }
  };

  const handleBranchNameChange = (value) => {
    setSelectedBranchValue(value);
  };

  const fetchVendorData = (inputValue) => {
    return MaximusAxios.get("/api/TerminalRegistration/GetVendorMasterList", {
      mode: "cors",
    }).then((result) => {
      if (inputValue.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.vendorName.toLowerCase().includes(inputValue.toLowerCase())
        );
      }
    });
  };

  const handleVendorChange = (value) => {
    setSelectedVendorValue(value);
  };

  const { state } = useLocation();

  const navigate = useNavigate();

  const [inputValue, setValue] = useState("0");

  const [selectedValue, setSelectedValue] = useState(null);
  const [selectedVendorValue, setSelectedVendorValue] = useState(null);
  const [stateTermID, setTermIDValue] = useState(null);
  const [selectedStateValue, setSelectedStateValue] = useState(null);
  const [selectedLocationTypeValue, setSelectedLocationTypeValue] =
    useState(null);
  const [selectedATMMakeTypeValue, setSelectedATMMakeTypeValue] =
    useState(null);
  const [selectedSiteTypeValue, setSelectedSiteTypeValue] = useState([
    { siteTypeID: "0", siteType: "--Select--" },
  ]);
  const [selectedSiteClassValue, setSelectedSiteClassValue] = useState(null);
  const [selectedTerminalTypeValue, setSelectedTerminalTypeValue] =
    useState(null);
  const [selectedDistrictValue, setSelectedDistrictValue] = useState(null);
  const [optionsDistrictType, setOptionsDistrictTypeValue] = useState([
    { districtID: "0", districtName: "--Select--" },
  ]);
  const [selectedBranchValue, setSelectedBranchValue] = useState(null);
  const [optionsBranchName, setOptionsBranchNameValue] = useState([
    { branchCode: "0", branchName: "--Select--" },
  ]);
  const [IsDisabled, setIsDisabled] = useState(true);

  const [isShow, setIsLoading] = useState(false);
  const [alertJson, setShowMessageBox] = useState({
    isShow: false,
    alertVariant: "success",
    alertTitle: "",
    alertMessage: "",
  });

  const [TerminalAdd, setTerminalAdd] = useState(null);
  const [TerminalIDValue, setTerminalIDValue] = useState(null);
  const [TerminalLocationValue, setTerminalLocationValue] = useState(null);
  const [GLAccountNoValue, setGLAccountNoValue] = useState(null);
  const [ContactNoValue, setContactNoValue] = useState(null);
  const [EmailIDValue, setEmailIDValue] = useState(null);
  const [ConcernPersonValue, setConcernPersonValue] = useState(null);
  const [Cassette1Value, setCassette1Value] = useState(null);
  const [Cassette2Value, setCassette2Value] = useState(null);
  const [Cassette3Value, setCassette3Value] = useState(null);
  const [Cassette4Value, setCassette4Value] = useState(null);
  const [Cassette5Value, setCassette5Value] = useState(null);
  const [Cassette6Value, setCassette6Value] = useState(null);
  const [CassetteCurrencyCode1Value, setCassetteCurrencyCode1Value] =
    useState(null);
  const [CassetteCurrencyCode2Value, setCassetteCurrencyCode2Value] =
    useState(null);
  const [CassetteCurrencyCode3Value, setCassetteCurrencyCode3Value] =
    useState(null);
  const [CassetteCurrencyCode4Value, setCassetteCurrencyCode4Value] =
    useState(null);
  const [CassetteCurrencyCode5Value, setCassetteCurrencyCode5Value] =
    useState(null);
  const [CassetteCurrencyCode6Value, setCassetteCurrencyCode6Value] =
    useState(null);
  const [IsActiveValue, setIsActiveValue] = useState(null);
  const [IsCassetteSwapValue, setIsCassetteSwapValue] = useState(null);

  const [inputerrors, setInputErrors] = useState({});
  const [inputerrorObject, setinputerrorObject] = useState({
    emailID: "",
    contactNo: "",
    cassette1: "",
    cassette2: "",
    cassette3: "",
    cassette4: "",
    cassette5: "",
    cassette6: "",
  });

  const handleOptionsDistrictType = (value) => {
    setOptionsDistrictTypeValue(value);
  };

  const handleOptionsBranchName = (value) => {
    setOptionsBranchNameValue(value);
  };

  const handleIsActiveChange = (evt) => {
    setIsActiveValue(evt.target.value);
  };

  const handleIsCassetteSwapChange = (evt) => {
    setIsCassetteSwapValue(evt.target.value);
  };

  useEffect(() => {
    if (state !== null) {
      setTermIDValue(state.id);
      if (state.id > 0) {
        fetchTerminalMasterData(state.id);
      }
    }
  }, [TerminalAdd]);

  const fetchTerminalMasterData = (TermIDValue) => {
    setIsLoading(true);
    setIsDisabled(false);

    MaximusAxios.get(
      "/api/TerminalRegistration/GetTerminalData?ID=" + TermIDValue,
      { mode: "cors" }
    )
      .then((TerminalData) => {
        if (TerminalData.data != null) {
          console.log(TerminalData.data);

          setSelectedValue({
            clientID: TerminalData.data.clientID,
            clientName: TerminalData.data.clientName,
          });
          setSelectedVendorValue({
            vendorID: TerminalData.data.vendorID,
            vendorName: TerminalData.data.vendorName,
          });
          MaximusAxios.get(
            "/api/TerminalRegistration/GetBranchMasterList?ClientID=" +
              TerminalData.data.clientID,
            { mode: "cors" }
          ).then((result) => {
            handleOptionsBranchName(result.data);
          });
          setSelectedBranchValue({
            value: TerminalData.data.branchCode,
            label: TerminalData.data.branchName,
          });
          setTerminalIDValue(TerminalData.data.terminalID);
          setTerminalLocationValue(TerminalData.data.terminalLocation);
          setSelectedStateValue({
            stateID: TerminalData.data.stateID,
            stateName: TerminalData.data.stateName,
          });
          MaximusAxios.get(
            "api/TerminalRegistration/GetDistrictOptionList?StateID=" +
              TerminalData.data.stateID,
            { mode: "cors" }
          ).then((result) => {
            handleOptionsDistrictType(result.data);
          });
          setSelectedDistrictValue({
            value: TerminalData.data.districtID,
            label: TerminalData.data.districtName,
          });
          setSelectedLocationTypeValue({
            locationTypeID: TerminalData.data.locationTypeID,
            locationType: TerminalData.data.locationType,
          });
          setSelectedATMMakeTypeValue({
            atmMakeTypeID: TerminalData.data.atmMakeTypeID,
            atmMakeType: TerminalData.data.atmMakeType,
          });
          setSelectedSiteTypeValue({
            siteTypeID: TerminalData.data.siteTypeID,
            siteType: TerminalData.data.siteType,
          });
          setSelectedSiteClassValue({
            siteClassID: TerminalData.data.siteClassID,
            siteClass: TerminalData.data.siteClass,
          });
          setGLAccountNoValue(TerminalData.data.glAccountNo);
          setSelectedTerminalTypeValue({
            terminalTypeID: TerminalData.data.terminalTypeID,
            terminalType: TerminalData.data.terminalType,
          });
          setContactNoValue(TerminalData.data.contactNo);
          setEmailIDValue(TerminalData.data.emailID);
          setConcernPersonValue(TerminalData.data.concernPerson);
          setCassette1Value(TerminalData.data.cassette1);
          setCassette2Value(TerminalData.data.cassette2);
          setCassette3Value(TerminalData.data.cassette3);
          setCassette4Value(TerminalData.data.cassette4);
          setCassette5Value(TerminalData.data.cassette5);
          setCassette6Value(TerminalData.data.cassette6);
          setCassetteCurrencyCode1Value(
            TerminalData.data.cassetteCurrencyCode1
          );
          setCassetteCurrencyCode2Value(
            TerminalData.data.cassetteCurrencyCode2
          );
          setCassetteCurrencyCode3Value(
            TerminalData.data.cassetteCurrencyCode3
          );
          setCassetteCurrencyCode4Value(
            TerminalData.data.cassetteCurrencyCode4
          );
          setCassetteCurrencyCode5Value(
            TerminalData.data.cassetteCurrencyCode5
          );
          setCassetteCurrencyCode6Value(
            TerminalData.data.cassetteCurrencyCode6
          );
          if (TerminalData.data.isActive) {
            setIsActiveValue("Yes");
          } else {
            setIsActiveValue("No");
          }
          if (TerminalData.data.isCassetteSwap) {
            setIsCassetteSwapValue("Yes");
          } else {
            setIsCassetteSwapValue("No");
          }
        }
        setIsLoading(false);
      })
      .catch(function (error) {
        if (error.response) {
          console.log(error.response.data);
        }
        setIsLoading(false);
      });
  };

  const handleInputChange = (value) => {
    setValue(value);
  };

  const checkTerminalIDValue = (elementId) => {
    console.log(elementId);
    MaximusAxios.get(
      "/api/TerminalRegistration/CheckTerminalID?ID=" +
        String(stateTermID) +
        "&TerminalID=" +
        $("#" + elementId).val(),
      { mode: "cors" }
    ).then((TermData) => {
      if (TermData !== null) {
        if (TermData.data === "1") {
          setTerminalIDValue("");
          $("#" + elementId).val("");
          alert("Terminal ID already exists.");
        }
      }
    });
  };

  const fetchStateData = (inputValue) => {
    setSelectedDistrictValue(null);

    return MaximusAxios.get("/api/TerminalRegistration/GetTerminalStateList", {
      mode: "cors",
    }).then((result) => {
      if (inputValue.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.stateName.toLowerCase().includes(inputValue.toLowerCase())
        );
      }
    });
  };

  const handleStateChange = (value) => {
    setSelectedStateValue(value);

    if (value.stateID !== "0") {
      return MaximusAxios.get(
        "api/TerminalRegistration/GetDistrictOptionList?StateID=" +
          value.stateID,
        { mode: "cors" }
      ).then((result) => {
        handleOptionsDistrictType(result.data);
      });
    }
  };

  const handleDistrictChange = (value) => {
    setSelectedDistrictValue(value);
  };

  const fetchLocationTypeData = (inputValue) => {
    return MaximusAxios.get(
      "/api/TerminalRegistration/GetLocationTypeMasterList",
      { mode: "cors" }
    ).then((result) => {
      if (inputValue.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.locationType.toLowerCase().includes(inputValue.toLowerCase())
        );
      }
    });
  };

  const handleLocationTypeChange = (value) => {
    setSelectedLocationTypeValue(value);
  };

  const fetchATMMakeTypeData = (inputValue) => {
    return MaximusAxios.get(
      "/api/TerminalRegistration/GetATMMakeTypeMasterList",
      { mode: "cors" }
    ).then((result) => {
      if (inputValue.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.aTMMakeType.toLowerCase().includes(inputValue.toLowerCase())
        );
      }
    });
  };

  const handleATMMakeTypeChange = (value) => {
    setSelectedATMMakeTypeValue(value);
  };

  const fetchSiteTypeData = (inputValue) => {
    return MaximusAxios.get("/api/TerminalRegistration/GetSiteTypeMasterList", {
      mode: "cors",
    }).then((result) => {
      if (inputValue.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.siteType.toLowerCase().includes(inputValue.toLowerCase())
        );
      }
    });
  };

  const handleSiteTypeChange = (value) => {
    setSelectedSiteTypeValue(value);
  };

  const fetchSiteClassData = (inputValue) => {
    return MaximusAxios.get(
      "/api/TerminalRegistration/GetSiteClassMasterList",
      { mode: "cors" }
    ).then((result) => {
      if (inputValue.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.siteClass.toLowerCase().includes(inputValue.toLowerCase())
        );
      }
    });
  };

  const handleSiteClassChange = (value) => {
    setSelectedSiteClassValue(value);
  };

  const fetchTerminalTypeData = (inputValue) => {
    return MaximusAxios.get(
      "/api/TerminalRegistration/GetTerminalTypeMasterList",
      { mode: "cors" }
    ).then((result) => {
      if (inputValue.length === 0) {
        return result.data;
      } else {
        return result.data.filter((d) =>
          d.terminalType.toLowerCase().includes(inputValue.toLowerCase())
        );
      }
    });
  };

  const handleTerminalTypeChange = (value) => {
    setSelectedTerminalTypeValue(value);
  };

  const handleEmailIDChange = (event) => {
    const { name, value } = event.target;
    setEmailIDValue(value);

    const ValidEmailID = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

    // Updating input error object correctly
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "emailID") {
        if (!value.trim()) {
          newErrors.emailID = "Please enter Email ID";
        } else if (!ValidEmailID.test(value)) {
          newErrors.emailID = "Please enter a valid Email ID";
        } else {
          delete newErrors.emailID;
        }
      }
      return newErrors;
    });
  };
  const handleContactNoChange = (event) => {
    setContactNoValue(event.target.value);
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };

      if (name === "contactNo") {
        if (!value || value.trim().length === 0) {
          newErrors.contactNo = "Please enter your contact number.";
        } else if (/^0/.test(value)) {
          newErrors.contactNo = "Leading zeros are not allowed.";
        } else if (!/^\d+$/.test(value)) {
          newErrors.contactNo = "Contact number must contain only numbers";
        }  else if (!/^[789]/.test(value)) {
            newErrors.contactNo = "Contact number must begin with 7, 8, or 9.";
        }else if (value.length !== 10) {
            newErrors.contactNo = "Contact number must be exactly 10 digits.";
          }
        else {
          delete newErrors.contactNo; // Remove error if valid
        }
      }

      return newErrors; // Return updated errors
    });
  };
  const handleCassette1Change = (event) => {
    setCassette1Value(event.target.value);
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));

    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };
      if (name === "cassette1") {
        if (/^0/.test(value)) {
          newErrors.cassette1 = "Leading zeros are not allowed.";
        } else {
          delete newErrors.cassette1; // Remove error if valid
        }
      }
      return newErrors; // Return updated errors
    });
  };
  const handleCassette2Change = (event) => {
    setCassette2Value(event.target.value);
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };
      if (name === "cassette2") {
        if (/^0/.test(value)) {
          newErrors.cassette2 = "Leading zeros are not allowed.";
        } else {
          delete newErrors.cassette2; // Remove error if valid
        }
      }
      return newErrors; // Return updated errors
    });
  };
  const handleCassette3Change = (event) => {
    setCassette3Value(event.target.value);
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };
      if (name === "cassette3") {
        if (/^0/.test(value)) {
          newErrors.cassette3 = "Leading zeros are not allowed.";
        } else {
          delete newErrors.cassette3; // Remove error if valid
        }
      }
      return newErrors; // Return updated errors
    });
  };
  const handleCassette4Change = (event) => {
    setCassette4Value(event.target.value);
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };
      if (name === "cassette4") {
        if (/^0/.test(value)) {
          newErrors.cassette4 = "Leading zeros are not allowed.";
        } else {
          delete newErrors.cassette4; // Remove error if valid
        }
      }
      return newErrors; // Return updated errors
    });
  };
  const handleCassette5Change = (event) => {
    setCassette5Value(event.target.value);
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };
      if (name === "cassette5") {
        if (/^0/.test(value)) {
          newErrors.cassette5 = "Leading zeros are not allowed.";
        } else {
          delete newErrors.cassette5; // Remove error if valid
        }
      }
      return newErrors; // Return updated errors
    });
  };
  const handleCassette6Change = (event) => {
    setCassette6Value(event.target.value);
    const { name, value } = event.target;
    // Update form values
    setinputerrorObject((prevValues) => ({
      ...prevValues,
      [name]: value,
    }));
    setInputErrors((prevErrors) => {
      const newErrors = { ...prevErrors };
      if (name === "cassette6") {
        if (/^0/.test(value)) {
          newErrors.cassette6 = "Leading zeros are not allowed.";
        } else {
          delete newErrors.cassette6; // Remove error if valid
        }
      }
      return newErrors; // Return updated errors
    });
  };
  const btnSubmitClick = () => {
    try {
      if (selectedValue === undefined || selectedValue === null) {
        alert("Please select Client Name");
        return false;
      } else if (
        selectedVendorValue === undefined ||
        selectedVendorValue === null
      ) {
        alert("Please select Vendor Name");
        return false;
      } else if (
        selectedBranchValue === undefined ||
        selectedBranchValue === null
      ) {
        alert("Please select Branch Name");
        return false;
      } else if (
        TerminalIDValue === null ||
        TerminalIDValue.trim().length === 0
      ) {
        alert("Please enter Terminal ID");
        return false;
      } else if (TerminalIDValue.trim().length < 8) {
        alert("Please Enter Proper Terminal ID value");
        return false;
      } else if (
        TerminalLocationValue === null ||
        TerminalLocationValue.trim().length === 0
      ) {
        alert("Please enter Terminal Location Value");
        return false;
      } else if (
        selectedStateValue === undefined ||
        selectedStateValue === null
      ) {
        alert("Please enter State Name");
        return false;
      } else if (
        selectedDistrictValue === undefined ||
        selectedDistrictValue === null
      ) {
        alert("Please enter City Name");
        return false;
      } else if (
        selectedLocationTypeValue === null ||
        selectedLocationTypeValue === null
      ) {
        alert("Please enter Location Type");
        return false;
      } else if (
        selectedATMMakeTypeValue === null ||
        selectedATMMakeTypeValue === null
      ) {
        alert("Please enter ATMMake Type Value");
        return false;
      } else if (
        selectedSiteTypeValue === null ||
        selectedSiteTypeValue === null
      ) {
        alert("Please enter Site Type Value");
        return false;
      } else if (
        selectedSiteClassValue === null ||
        selectedSiteClassValue === null
      ) {
        alert("Please enter Site Class Value");
        return false;
      } else if (
        GLAccountNoValue === null ||
        GLAccountNoValue.trim().length === 0
      ) {
        alert("Please enter GLAccountNo Value");
        return false;
      } else if (
        GLAccountNoValue === "0000000000000000" ||
        GLAccountNoValue.trim().length < 16
      ) {
        alert("Please enter correct GL Account No Value");
        return false;
      } else if (
        selectedTerminalTypeValue === null ||
        selectedTerminalTypeValue === null
      ) {
        alert("Please enter Terminal Type Value");
        return false;
      } else if (
        ContactNoValue === null ||
        ContactNoValue.trim().length === 0
      ) {
        alert("Please enter ContactNo Value");
        return false;
      } else if (
        ContactNoValue === "0000000000" ||
        ContactNoValue.trim().length < 10
      ) {
        alert("Please enter correct Contact No Value");
        return false;
      } else if (EmailIDValue === null || EmailIDValue.trim().length === 0) {
        alert("Please enter EmailID Value");
        return false;
      } else if (
        ConcernPersonValue === null ||
        ConcernPersonValue.trim().length === 0
      ) {
        alert("Please enter ConcernPerson Name");
        return false;
      } else if (
        Cassette1Value === null ||
        Cassette1Value.trim().length === 0
      ) {
        alert("Please enter Cassette1 Value");
        return false;
      } else if (
        Cassette2Value === null ||
        Cassette2Value.trim().length === 0
      ) {
        alert("Please enter Cassette2 Value");
        return false;
      } else if (
        Cassette3Value === null ||
        Cassette3Value.trim().length === 0
      ) {
        alert("Please enter Cassette3 Value");
        return false;
      } else if (
        Cassette4Value === null ||
        Cassette4Value.trim().length === 0
      ) {
        alert("Please enter Cassette4 Value");
        return false;
      } else if (
        Cassette5Value === null ||
        Cassette5Value.trim().length === 0
      ) {
        alert("Please enter Cassette5 Value");
        return false;
      } else if (
        Cassette6Value === null ||
        Cassette6Value.trim().length === 0
      ) {
        alert("Please enter Cassette6 Value");
        return false;
      } else if (
        CassetteCurrencyCode1Value === null ||
        CassetteCurrencyCode1Value.trim().length === 0
      ) {
        alert("Please enter CassetteCurrencyCode1 Value");
        return false;
      } else if (
        CassetteCurrencyCode2Value === null ||
        CassetteCurrencyCode2Value.trim().length === 0
      ) {
        alert("Please enter CassetteCurrencyCode2 Value");
        return false;
      } else if (
        CassetteCurrencyCode3Value === null ||
        CassetteCurrencyCode3Value.trim().length === 0
      ) {
        alert("Please enter CassetteCurrencyCode3 Value");
        return false;
      } else if (
        CassetteCurrencyCode4Value === null ||
        CassetteCurrencyCode4Value.trim().length === 0
      ) {
        alert("Please enter CassetteCurrencyCode4 Value");
        return false;
      } else if (
        CassetteCurrencyCode5Value === null ||
        CassetteCurrencyCode5Value.trim().length === 0
      ) {
        alert("Please enter CassetteCurrencyCode5 Value");
        return false;
      } else if (
        CassetteCurrencyCode6Value === null ||
        CassetteCurrencyCode6Value.trim().length === 0
      ) {
        alert("Please enter CassetteCurrencyCode6 Value");
        return false;
      } else if (IsActiveValue === undefined || IsActiveValue === null) {
        alert("Please select IsActive Value");
        return false;
      } else if (
        IsCassetteSwapValue === undefined ||
        IsCassetteSwapValue === null
      ) {
        alert("Please enter CassetteSwap Value");
        return false;
      }
      const ValidEmailID = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      if (!ValidEmailID.test(EmailIDValue)) {
        alert("Please enter proper email id");
        return false;
      }
      if(state.IsDisabled === "ADD"){
        //   Check all correct or not
           const hasErrors = Object.keys(inputerrors).length > 0;
        console.log(inputerrors)
        console.log(inputerrorObject)
           const isAllFieldsFilled = Object.values(inputerrorObject).every(
             (value) => value.trim() !== ""
           );
          
           if (hasErrors || !isAllFieldsFilled) {
             alert("Please correct all details and try again.");
             return;
           }
         }
         else{
           const hasErrors = Object.keys(inputerrors).length > 0;
           if (hasErrors) {
             alert("Please correct all details and try again.");
             return;
           }
         }

      setIsLoading(true);

      const TerminalData = new FormData();

      TerminalData.append("ID", stateTermID);
      TerminalData.append("ClientID", selectedValue.clientID);
      TerminalData.append("Mode", IsDisabled === "ADD" ? "1" : "0");
      TerminalData.append("VendorID", selectedVendorValue.vendorID);
      TerminalData.append("BranchCode", selectedBranchValue.value);
      TerminalData.append("TerminalID", TerminalIDValue);
      TerminalData.append("TerminalLocation", TerminalLocationValue);
      TerminalData.append("StateID", selectedStateValue.stateID);
      TerminalData.append("DistrictID", selectedDistrictValue.value);
      TerminalData.append(
        "LocationTypeID",
        selectedLocationTypeValue.locationTypeID
      );
      TerminalData.append(
        "ATMMakeTypeID",
        selectedATMMakeTypeValue.atmMakeTypeID
      );
      TerminalData.append("SiteTypeID", selectedSiteTypeValue.siteTypeID);
      TerminalData.append("SiteClassID", selectedSiteClassValue.siteClassID);
      TerminalData.append("GLAccountNo", GLAccountNoValue);
      TerminalData.append(
        "TerminalTypeID",
        selectedTerminalTypeValue.terminalTypeID
      );
      TerminalData.append("ContactNo", ContactNoValue);
      TerminalData.append("EmailID", EmailIDValue);
      TerminalData.append("ConcernPerson", ConcernPersonValue);
      TerminalData.append("Cassette1", Cassette1Value);
      TerminalData.append("Cassette2", Cassette2Value);
      TerminalData.append("Cassette3", Cassette3Value);
      TerminalData.append("Cassette4", Cassette4Value);
      TerminalData.append("Cassette5", Cassette5Value);
      TerminalData.append("Cassette6", Cassette6Value);
      TerminalData.append("CassetteCurrencyCode1", CassetteCurrencyCode1Value);
      TerminalData.append("CassetteCurrencyCode2", CassetteCurrencyCode2Value);
      TerminalData.append("CassetteCurrencyCode3", CassetteCurrencyCode3Value);
      TerminalData.append("CassetteCurrencyCode4", CassetteCurrencyCode4Value);
      TerminalData.append("CassetteCurrencyCode5", CassetteCurrencyCode5Value);
      TerminalData.append("CassetteCurrencyCode6", CassetteCurrencyCode6Value);
      TerminalData.append("IsActive", IsActiveValue === "Yes" ? "1" : "0");
      TerminalData.append(
        "IsCassetteSwap",
        IsCassetteSwapValue === "Yes" ? "1" : "0"
      );
      TerminalData.append("FileName", "Default");
      TerminalData.append("FilePath", "Default");
      TerminalData.append("UserName", currentUser.user.username);

      console.log(TerminalData);

      MaximusAxios.post(
        "/api/TerminalRegistration/AddUpdateTerminalMaster",
        TerminalData,
        { mode: "cors" }
      )
        .then(function (response) {
          setIsLoading(false);
          console.log(response.data);
          if (response.data === null || response.data === undefined) {
            setShowMessageBox({
              isShow: true,
              alertVariant: "info",
              alertTitle: "Error",
              alertMessage: "Error occurred",
            });
          } else if (response.data.length > 0) {
            alert(response.data);
            navigate("/client-management/terminal-registration");
          } else {
            setShowMessageBox({
              isShow: true,
              alertVariant: "info",
              alertTitle: "Error",
              alertMessage: "Error occurred",
            });
          }
        })
        .catch(function (error) {
          setIsLoading(false);
          console.log(error);
        });
    } catch (ex) {
      console.log(ex);
      setIsLoading(false);
    }
  };

  const handlePaste = (event) => {
    const clipboardValue = event.clipboardData.getData("text");
    const numberPattern = /^[0-9\b]+$/;
    if (!numberPattern.test(clipboardValue)) {
      event.preventDefault();
    }
  };

  const onBackClick = (e) => {
    navigate("/client-management/terminal-registration");
  };

  return (
    <div className="configLeft identificationContainer">
      <div className="d-flex justify-content-between align-items-center breadcrumbHeading">
        <h5 className="fontWeight-600 fileConfigHead colorBlack">&nbsp;</h5>
        <div className="d-flex align-items-center">
          <Link to="/">
            <p className="fontSize12 colorPrimaryDefault">Home</p>
          </Link>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12 colorPrimaryDefault">Client Management</p>
          <span>
            <svg
              width="8"
              height="100%"
              viewBox="0 0 10 16"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="mx-1"
            >
              <path
                d="M3 4L7 8L3 12"
                stroke="black"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="breadcrumbIcon"
              />
            </svg>
          </span>
          <p className="fontSize12">Terminal Registration</p>
        </div>
      </div>

      {/* Bottom Content */}
      <div className="configLeftBottom">
        <div className="accordion-body">
          <h5 className="fontWeight-600 fileConfigHead colorBlack ">
            Terminal Information
          </h5>
          <div className="hrGreyLine"></div>
          <div className="configSelectBoxTop row">
            <div className="clientNameSelect col">
              <label htmlFor="clientName">Client Name</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedValue}
                getOptionLabel={(e) => e.clientName}
                getOptionValue={(e) => e.clientID}
                loadOptions={fetchClientData}
                onInputChange={handleInputChange}
                onChange={handleClientChange}
                id="ddlClient"
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="Vendorname">Vendor Name</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedVendorValue}
                getOptionLabel={(e) => e.vendorName}
                getOptionValue={(e) => e.vendorID}
                loadOptions={fetchVendorData}
                onInputChange={handleInputChange}
                onChange={handleVendorChange}
                id="ddlVendor"
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="ddlbranchname">Branch Name</label>
              <span className="text-danger font-size13">*</span>
              <Select
                id="ddlbranchname"
                value={selectedBranchValue}
                classNamePrefix="reactSelectBox"
                options={optionsBranchName.map((x) => ({
                  value: x.branchCode,
                  label: x.branchName,
                }))}
                onChange={handleBranchNameChange}
              />
            </div>
            {IsDisabled ? (
              <div className="clientNameSelect col">
                <label htmlFor="terminalid">Terminal ID</label>
                <span className="text-danger font-size13">*</span>
                <input
                  type="text"
                  name="terminalid"
                  id="terminalid"
                  maxLength="10"
                  autoComplete="off"
                  onPaste={handlePaste}
                  placeholder="Enter Terminal ID"
                  className="inputTextBox"
                  onChange={(e) => setTerminalIDValue(e.target.value)}
                  onBlur={(e) => checkTerminalIDValue(e.target.id)}
                  defaultValue={TerminalIDValue}
                  onKeyPress={(e) =>
                    !/^[a-zA-Z0-9 ]+$/.test(e.key) && e.preventDefault()
                  }
                />
              </div>
            ) : (
              <div className="clientNameSelect col">
                <label htmlFor="terminalid">Terminal ID</label>
                <span className="text-danger font-size13">*</span>
                <input
                  type="text"
                  name="terminalid"
                  id="terminalid"
                  maxLength="10"
                  autoComplete="off"
                  onPaste={handlePaste}
                  placeholder="Enter Terminal ID"
                  className="inputTextBox"
                  disabled
                  onChange={(e) => setTerminalIDValue(e.target.value)}
                  onBlur={(e) => checkTerminalIDValue(e.target.id)}
                  defaultValue={TerminalIDValue}
                  onKeyPress={(e) =>
                    !/^[a-zA-Z0-9 ]+$/.test(e.key) && e.preventDefault()
                  }
                />
              </div>
            )}
            <div className="clientNameSelect col">
              <label htmlFor="terminallocation">Terminal Location</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="terminallocation"
                id="terminallocation"
                maxLength="50"
                onPaste={handlePaste}
                placeholder="Enter Terminal Location"
                className="inputTextBox"
                autoComplete="off"
                onChange={(e) => setTerminalLocationValue(e.target.value)}
                defaultValue={TerminalLocationValue}
                onKeyPress={(e) =>
                  !/^[a-zA-Z ]+$/.test(e.key) && e.preventDefault()
                }
              />
              {inputerrors.choosecolorcode && (
                <span className="text-danger fontSize12">
                  {inputerrors.choosecolorcode}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="stateName">State Name</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedStateValue}
                getOptionLabel={(e) => e.stateName}
                getOptionValue={(e) => e.stateID}
                loadOptions={fetchStateData}
                onInputChange={handleInputChange}
                onChange={handleStateChange}
                id="ddlstate"
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="ddlCity">City Name</label>
              <span className="text-danger font-size13">*</span>
              <Select
                id="ddlCity"
                value={selectedDistrictValue}
                classNamePrefix="reactSelectBox"
                options={optionsDistrictType.map((x) => ({
                  value: x.districtID,
                  label: x.districtName,
                }))}
                onChange={handleDistrictChange}
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="locationtype">Location Type</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedLocationTypeValue}
                getOptionLabel={(e) => e.locationType}
                getOptionValue={(e) => e.locationTypeID}
                loadOptions={fetchLocationTypeData}
                onInputChange={handleInputChange}
                onChange={handleLocationTypeChange}
                id="ddllocationtype"
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="atmmaketype">ATM Make Type</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedATMMakeTypeValue}
                getOptionLabel={(e) => e.atmMakeType}
                getOptionValue={(e) => e.atmMakeTypeID}
                loadOptions={fetchATMMakeTypeData}
                onInputChange={handleInputChange}
                onChange={handleATMMakeTypeChange}
                id="ddlatmmaketype"
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="sitetype">Site Type</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedSiteTypeValue}
                getOptionLabel={(e) => e.siteType}
                getOptionValue={(e) => e.siteTypeID}
                loadOptions={fetchSiteTypeData}
                onInputChange={handleInputChange}
                onChange={handleSiteTypeChange}
                id="ddlsitetype"
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="siteclass">Site Class</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedSiteClassValue}
                getOptionLabel={(e) => e.siteClass}
                getOptionValue={(e) => e.siteClassID}
                loadOptions={fetchSiteClassData}
                onInputChange={handleInputChange}
                onChange={handleSiteClassChange}
                id="ddlsiteclass"
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="glaccountno">GL Account No.</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="glaccountno"
                id="glaccountno"
                maxLength="16"
                autoComplete="off"
                placeholder="Enter GL AccountNo"
                className="inputTextBox"
                onChange={(e) => setGLAccountNoValue(e.target.value)}
                defaultValue={GLAccountNoValue}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="terminaltype">Terminal Type</label>
              <span className="text-danger font-size13">*</span>
              <AsyncSelect
                cacheOptions
                defaultOptions
                value={selectedTerminalTypeValue}
                getOptionLabel={(e) => e.terminalType}
                getOptionValue={(e) => e.terminalTypeID}
                loadOptions={fetchTerminalTypeData}
                onInputChange={handleInputChange}
                onChange={handleTerminalTypeChange}
                id="ddlterminaltype"
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="contactNo">Contact No.</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="tel"
                name="contactNo"
                id="contactNo"
                placeholder="Enter Contact No"
                className="inputTextBox"
                maxLength="10"
                required
                autoComplete="off"
                onPaste={handlePaste}
                onChange={handleContactNoChange}
                onBlur={handleContactNoChange}
                defaultValue={ContactNoValue}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
              {inputerrors.contactNo && (
                <span className="text-danger fontSize12">
                  {inputerrors.contactNo}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="emailID">Email ID</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="emailID"
                id="emailID"
                autoComplete="off"
                placeholder="Enter EmailID"
                className="inputTextBox"
                onChange={handleEmailIDChange} //setEmailIDValue(e.target.value)
                onBlur={handleEmailIDChange}
                defaultValue={EmailIDValue}
                maxLength={50}
              />
              {inputerrors.emailID && (
                <span className="text-danger fontSize12">
                  {inputerrors.emailID}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="concernPerson">Concern Person's Name</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="concernPerson"
                id="concernPerson"
                maxLength="20"
                autoComplete="off"
                placeholder="Enter ConcernPerson Name"
                className="inputTextBox"
                onChange={(e) => setConcernPersonValue(e.target.value)}
                defaultValue={ConcernPersonValue}
                onKeyPress={(e) =>
                  !/^[a-zA-Z ]+$/.test(e.key) && e.preventDefault()
                }
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassette1">Cassette1</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassette1"
                id="cassette1"
                maxLength="4"
                autoComplete="off"
                onPaste={handlePaste}
                placeholder="Enter Cassette1 Value"
                className="inputTextBox"
                onChange={handleCassette1Change}
                onBlur={handleCassette1Change}
                defaultValue={Cassette1Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
              {inputerrors.cassette1 && (
                <span className="text-danger fontSize12">
                  {inputerrors.cassette1}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassette2">Cassette2</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassette2"
                id="cassette2"
                maxLength="4"
                autoComplete="off"
                onPaste={handlePaste}
                placeholder="Enter Cassette2 Value"
                className="inputTextBox"
                onChange={handleCassette2Change}
                onBlur={handleCassette2Change}
                defaultValue={Cassette2Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
              {inputerrors.cassette2 && (
                <span className="text-danger fontSize12">
                  {inputerrors.cassette2}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassette3">Cassette3</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassette3"
                id="cassette3"
                autoComplete="off"
                maxLength="4"
                onPaste={handlePaste}
                placeholder="Enter Cassette3 Value"
                className="inputTextBox"
                onChange={handleCassette3Change}
                onBlur={handleCassette3Change}
                defaultValue={Cassette3Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
              {inputerrors.cassette3 && (
                <span className="text-danger fontSize12">
                  {inputerrors.cassette3}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassette4">Cassette4</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassette4"
                id="cassette4"
                autoComplete="off"
                maxLength="4"
                onPaste={handlePaste}
                placeholder="Enter Cassette4 Value"
                className="inputTextBox"
                onChange={handleCassette4Change}
                onBlur={handleCassette4Change}
                defaultValue={Cassette4Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
              {inputerrors.cassette4 && (
                <span className="text-danger fontSize12">
                  {inputerrors.cassette4}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassette5">Cassette5</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassette5"
                id="cassette5"
                autoComplete="off"
                maxLength="4"
                onPaste={handlePaste}
                placeholder="Enter Cassette5 Value"
                className="inputTextBox"
                onChange={handleCassette5Change}
                onBlur={handleCassette5Change}
                defaultValue={Cassette5Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
              {inputerrors.cassette5 && (
                <span className="text-danger fontSize12">
                  {inputerrors.cassette5}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassette6">Cassette6</label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassette6"
                autoComplete="off"
                id="cassette6"
                maxLength="4"
                onPaste={handlePaste}
                placeholder="Enter Cassette6 Value"
                className="inputTextBox"
                onChange={handleCassette6Change}
                onBlur={handleCassette6Change}
                defaultValue={Cassette6Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
              {inputerrors.cassette6 && (
                <span className="text-danger fontSize12">
                  {inputerrors.cassette6}
                </span>
              )}
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassettecurrencycode1">
                Cassette Currency Code1
              </label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassettecurrencycode1"
                id="cassettecurrencycode1"
                autoComplete="off"
                maxLength="4"
                onPaste={handlePaste}
                placeholder="Enter CassetteCurrencyCode1 Value"
                className="inputTextBox"
                onChange={(e) => setCassetteCurrencyCode1Value(e.target.value)}
                defaultValue={CassetteCurrencyCode1Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassettecurrencycode2">
                Cassette Currency Code2
              </label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                autoComplete="off"
                name="cassettecurrencycode2"
                id="cassettecurrencycode2"
                maxLength="4"
                onPaste={handlePaste}
                placeholder="Enter CassetteCurrencyCode2 Value"
                className="inputTextBox"
                onChange={(e) => setCassetteCurrencyCode2Value(e.target.value)}
                defaultValue={CassetteCurrencyCode2Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassettecurrencycode3">
                Cassette Currency Code3
              </label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassettecurrencycode3"
                id="cassettecurrencycode3"
                maxLength="4"
                autoComplete="off"
                onPaste={handlePaste}
                placeholder="Enter CassetteCurrencyCode3 Value"
                className="inputTextBox"
                onChange={(e) => setCassetteCurrencyCode3Value(e.target.value)}
                defaultValue={CassetteCurrencyCode3Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassettecurrencycode4">
                Cassette Currency Code4
              </label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassettecurrencycode4"
                id="cassettecurrencycode4"
                maxLength="4"
                onPaste={handlePaste}
                autoComplete="off"
                placeholder="Enter CassetteCurrencyCode4 Value"
                className="inputTextBox"
                onChange={(e) => setCassetteCurrencyCode4Value(e.target.value)}
                defaultValue={CassetteCurrencyCode4Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassettecurrencycode5">
                Cassette Currency Code5
              </label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassettecurrencycode5"
                id="cassettecurrencycode5"
                maxLength="4"
                autoComplete="off"
                onPaste={handlePaste}
                placeholder="Enter CassetteCurrencyCode5 Value"
                className="inputTextBox"
                onChange={(e) => setCassetteCurrencyCode5Value(e.target.value)}
                defaultValue={CassetteCurrencyCode5Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="cassettecurrencycode6">
                Cassette Currency Code6
              </label>
              <span className="text-danger font-size13">*</span>
              <input
                type="text"
                name="cassettecurrencycode6"
                id="cassettecurrencycode6"
                maxLength="4"
                autoComplete="off"
                onPaste={handlePaste}
                placeholder="Enter CassetteCurrencyCode6 Value"
                className="inputTextBox"
                onChange={(e) => setCassetteCurrencyCode6Value(e.target.value)}
                defaultValue={CassetteCurrencyCode6Value}
                onKeyPress={(e) => !/[0-9]/.test(e.key) && e.preventDefault()}
              />
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="isactive">Is Active</label>
              <span className="text-danger font-size13">*</span>
              <br />
              <label>
                <br />
                Yes &nbsp; &nbsp;
                <input
                  type="radio"
                  name="isactive"
                  className="radiobutton"
                  value="Yes"
                  onChange={handleIsActiveChange}
                  checked={IsActiveValue === "Yes"}
                />
              </label>
              &nbsp; &nbsp;
              <label>
                No &nbsp;
                <input
                  type="radio"
                  name="isactive"
                  className="radiobutton"
                  value="No"
                  onChange={handleIsActiveChange}
                  checked={IsActiveValue === "No"}
                />
              </label>
            </div>
            <div className="clientNameSelect col">
              <label htmlFor="iscassetteswap">Is Cassette Swap</label>
              <span className="text-danger font-size13">*</span>
              <br />
              <label>
                <br />
                Yes &nbsp; &nbsp;
                <input
                  type="radio"
                  name="iscassetteswap"
                  className="radiobutton"
                  value="Yes"
                  onChange={handleIsCassetteSwapChange}
                  checked={IsCassetteSwapValue === "Yes"}
                />
              </label>
              &nbsp; &nbsp;
              <label>
                No &nbsp;
                <input
                  type="radio"
                  name="iscassetteswap"
                  className="radiobutton"
                  value="No"
                  onChange={handleIsCassetteSwapChange}
                  checked={IsCassetteSwapValue === "No"}
                />
              </label>
            </div>
          </div>
          <div className="configSelectBoxTop row">
            <div className="text-center btnsBtm">
              <button
                type="button"
                className="btnPrimary ms-2"
                onClick={btnSubmitClick}
              >
                Submit
              </button>
              &nbsp;
              <button
                type="button"
                className="btnPrimaryOutline"
                onClick={(e) => onBackClick(e)}
              >
                Back
              </button>
            </div>
          </div>
        </div>
      </div>
      <LoadingSpinner isShow={isShow} />
      <MessageBox alertJson={alertJson} setShowMessageBox={setShowMessageBox} />
    </div>
  );
};

export default TerminalDetailsMainWindow;
