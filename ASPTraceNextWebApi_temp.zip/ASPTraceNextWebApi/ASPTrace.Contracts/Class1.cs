﻿namespace ASPTrace.Contracts
{
    public class Class1
    {

    }
}
