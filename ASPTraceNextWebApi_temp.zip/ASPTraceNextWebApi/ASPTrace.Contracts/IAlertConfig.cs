﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IAlertConfig
    {
        string SaveAlertConfig(DataTable alertTable, DataTable escalationTable);
        List<AlertConfigDataModel> GetAlertConfigDataList(string ClientID, string AlertTypeID, string AlertSeverityID, string CreatedBy);

        List<dynamic> GetAdditionalDataByAlertID(int AlertID , string Type);

    }
}
