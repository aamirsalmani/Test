﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection.Metadata;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IAuditReport
    {
        List<SettledTransactionsReportDetailsModel> GetSettledTransactionsReport(SettledTransactionsReportModel settledTransactionsReportModel);

        SettledTransactionsReportByReferenceNumber GetSettledTransactionsReportByReferenceNumber(SettledTransactionsReportModel settledTransactionsReportModel);

        List<ATMChargesReportDetailsModel> GetATMChargesReportDetails(ATMChargesReportModel aTMChargesReportModel);

        System.Data.DataTable GetBankSettlementReportDetails(BankReportModel bankSettlementReportModel);

        List<POSSettlementReportDetailsModel> GetPOSSettlementReportDetails(POSSettlementReportModel pOSSettlementReportModel);

        List<RefundCashbackTTUMReportDetailsModel> GetRefundCashbackTTUMReportDetails(RefundCashbackTTUMReportModel refundCashbackTTUMReport);

        List<IMPSSettlementReportDetailsModel> GetIMPSSettlementReportDetails(IMPSSettlementReportModel iMPSSettlementReportModel);

        System.Data.DataTable GetIMPSSettlementReport(IMPSSettlementReportModel iMPSSettlementReportModel);

        System.Data.DataTable GetUPISettlementReportDetails(UPISettlementReportModel uPISettlementReportModel);

        List<RefundTxnsReportDetailsModel> GetRefundTxnsReportDetails(RefundTxnsReportModel refundTxnsReportModel);

        List<dynamic> GetAdjustmentTxnsReport(AdjustmentTxnsModel adjustmentTxnsModel);

        List<FileStatusReportDetailsModel> GetFileStatusReportDetails(FileStatusModel fileUploadStatus);

        //NPCI Bulk Upload 
        List<dynamic> GetNPCIBulkUploadDetails(NPCIBulkUploadModel npciBulkUploadModel);

        DataSet GetBankFormatSettlementdetailsIMPS(BankReportModel impsBankFormatSettlementInputModel);

        DataSet GetBankFormatSettlementdetailsUPI(BankReportModel upiBankFormatSettlementInputModel);
        string ChangeUploadStatus(string filename);

        //ExportRawData KUNDAN
        System.Data.DataTable GetExportRawDataDetails(ExportRawDataModel exportRawDataModel);
        System.Data.DataTable ExportCsvReportKS(DownloadRawDataModel downloadRawDataModel);
        System.Data.DataTable ExportExcelReportKS(DownloadRawDataModel downloadRawDataModel);
        List<logTypeModel> GetLogList(String ChannelID);
        DataSet GetGLReconReport(GLReconModel ParamsModel);
    }
}
