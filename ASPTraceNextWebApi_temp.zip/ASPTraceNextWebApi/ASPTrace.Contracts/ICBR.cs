﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface ICBR
    {
        //List<CBRReportDetailsModel> GetCBRReportDetails(CBRReportModel pOSTtumReportModel);
        List<CBRReportDetailsNewModel> GetCBRReportDetails(CBRReportModel cBRReportModel);
        List<C3RReportDetailsModel> GetC3RReportDetails(C3RReportModel c3RReportModel);
        List<TerminalOptionModel> GetTerminalOptionsOld(string ClientID, string UserName);
        List<TerminalOptionModel> GetTerminalOptions(string UserName);
        string GetTerminalType(string Terminalid);
        TerminalModel GetTerminalData(string Terminalid);
        PreviousClosingModel GetPreviousClosing(string Terminalid, string TimeStamp);
        int CBRCounterInsertUpdate(CBRCounterModel cBRCounterModel);
        int CBRInsertUpdate(CBRDataModel cBRDataModel);

        DataTable CBRReportDatatable(CBRReportModel cBROCDataModel);

        DataTable CBROpeningClosingDatatable(C3RReportModel cBROCDataModel);
        List<CBRMissingDataModel> GetCBRMissingData(CBRMissingReportModel cbrMissingModel);

        System.Data.DataTable ExportCsvReportcbr(CBRMissingReportModelData cBRMissingReportModelData);
        System.Data.DataTable ExportExcelReportcbr(CBRMissingReportModelData cBRMissingReportModelData);

        DataTable CBRmissingDataTable(CBRMissingReportModelData cBRMissingReportModelData);
        List<CBRDifferenceReportModel> GetCBROpeningClosingDetails(C3RReportModel c3RReportModel);

    }
}

