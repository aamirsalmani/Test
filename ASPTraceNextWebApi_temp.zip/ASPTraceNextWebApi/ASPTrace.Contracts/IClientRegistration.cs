﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IClientRegistration
    {
        List<ClientRegModel> GetClientRegModel();
        List<ClientDetails> GetClientDetails(string BankID);
        List<ClientCountry> GetClientCountry();
        List<ClientCurrency> GetClientCurrency(string CountryID);
        List<ClientDomain> GetClientDomain();
        List<ClientModule> GetClientModule();
        List<ClientChannel> GetClientChannel();
        int AddUpdateClientMaster(ClientConfig clientConfig);
        List<ClientConfigMaster> GetClientMasterGridData(ClientRegModel clientRegModel);
        List<ClientConfigMaster> GetClientMasterGridData(int Status);
        int AddClientChannelMode(ClientChannelModeDetails clientChannelModeDetail);
        //List<CheckClientCode> GetCheckClientCode(string ClientCode);
        //List<ClientConfigMaster1> GetClientConfigMaster1(ClientConfig1 clientConfig1);
        List<ClientChannelModeDetails> GetChannelData(string ClientID);
        ClientConfigMaster GetClientMasterData(string ClientID);
        string CheckClientCodeExists(string ClientID, string ClientCode);
    }
}
