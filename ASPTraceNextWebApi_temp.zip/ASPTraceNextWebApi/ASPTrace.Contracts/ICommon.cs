﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface ICommon
    {
        List<ClientOptionModel> GetClientOptions(string UserID);

        List<LogOptionModel> GetLogOptions(string ChannelID);
        string GetUserRole(string UserID);
        List<ChannelOptionModel> GetChannelOptions(string ClientID, string UserID);
        List<ModeOptionModel> GetModeOptions(string ClientID, string ChannelID, string UserID);
        List<ModeIMPSOptionModel> GetModeIMPSOptions(string ClientID, string ChannelID);
        List<TerminalOptionModel> GetTerminals(string ClientID, string ChannelID, string UserName);
        List<TerminalOptionModel> GetTerminalOptions(string ClientID, string UserName); 

        System.Data.DataSet GetCardNetwork();
        System.Data.DataTable GetEncryptedDEK();

        List<FileTypeOptionModel> GetFileTypeOptions(string ClientID);

        void InsertLogs(string Msg, string ClientCode, string FormName, string FunctionName, int Lineno, string Filename, string UserName, char LogType);

        List<SideBarMenuModel> GetMenuList(string UserID, string MenuLevel);

        List<MenuModel> GetMenuList(string UserID);

        ClientLogoDetails GetClientLogo(string ClientID);

        List<OptionModel> GetNPCIReportTypeOptions(string ClientID, string ChannelID, string UserID);
        string GetReactFileTypes();
        string GetPowerBIURL_Link(string UserID);

        string GetUserLogin(string UserID);
        string ResetPassword(ResetPasswordModel userDetailsModel);
        DataTable GetTerminalSwappedDetail(string ClientID, string TerminalID);
        int AddUpdateFileUploadStatus(FileUploadStatusModel fileUploadStatusModel);
        Task<string> PushNotification(DataTable notificationsType);

        LoginSuccessModel GetById(string UserID);

        List<GetSuccessfulUnSuccessfulCount> GetSuccessfulUnSuccessRecords(string UserID);
        
        List<GetSuccessfulUnSuccessfulCount> GetATMSuccessfulUnSuccessRecords(ATMChartInput aTM);

        List<GetSuccessfulUnSuccessfulCount> GetATMSuccessfulUnSuccessRecords(string UserID);

        string UserHasAccessAsync(string UserID, string path);
        string InsertFileUploadDetail(FileUploadStatusModel fileUploadStatusModel);
        int UpdateFileUploadStatus(FileUploadStatusModel fileUploadStatusModel, string FileImportID);




        List<AlertTypeModel> GetAlertTypes();
        List<AlertSeverityModel> GetAlertSeverity();
        List<AlertScheduleTypeModel> GetAlertScheduleType();
        List<AlertNotificationChannelModel> GetAlertNotificationChannel();
        List<AlertEscalationUserModel> GetAlertEscalationUser();


    }
}
