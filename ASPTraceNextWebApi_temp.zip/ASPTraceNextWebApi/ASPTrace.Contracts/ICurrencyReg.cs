﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface ICurrencyReg
    {
        List<ClientCurrencyRegModel> GetClientCurrencyReg();
        List<CurrencyRegModel> GetCurrencyRegGrid();
        string CurrencyAddUpdate(CurrencyRegModel currencyRegDetailsModel); 
        CurrencyRegModel GetCurrencyDetails(string CurrencyID); 
        List<CountryRegModel> GetCountryReg(); 
        string DeleteCurrencyReg(DeleteCurrencyRegModel currencyRegDetailsModel);

       CurrencyOptRegModel GetCountryCodeByCountryName(string countryName);
    }
}
