using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;
using Microsoft.AspNetCore.Http;

namespace ASPTrace.Contracts
{
    public interface IDMS
    {
        //Dispute Tracking
        List<UnmatchedTxnsReportModel> GetUnmatchedTxnsReport(UnmatchedTxnsModel unmatchedTxnsModel);
        UnmatchedTxnByReferenceNumber GetUnmatchedTxnByReferenceNumberReport(UnmatchedTxnsModel unmatchedTxnsModel);
        List<AdjustmentTerminalDetailsModel> GetAdjustmentTerminalDetails(string UserName, string ClientID);
        List<AdjustmentModeModel> GetAdjustmentMode(string ClientID, string ChannelID);
        List<OptionsModel> GetDisputeTypeList(string ClientID, string ChannelID);
        List<dynamic> GetAdjustmentTxnsReport(AdjustmentTxnsIputModel adjustmentTxnsModel); 
        string BulkRaiseDispute(List<BulkDisputeRaiseModel> SubmitRemarks);
        string BulkUpdateDisputeRemarks(string ChannelID,List<SubmitRemarksModel> SubmitRemarks);
        string UpdateDisputeRemarks(SubmitRemarksModel SubmitRemarks);
        string DeleteAttachmentFile(AttachmentModel attachmentDetails);
        byte[] GetAttachmentsFile(AttachmentModel AttachmentDetails);
        List<AttachmentModel> GetAttachmentsData(DisputeModel adjustmentTxnsModel);
        List<AdjustmentTxnsReportModel> GetDisputeByReferenceNumber(AdjustmentTxnsReferenceNumberModel unmatchedTxnsModel);
        IFormFile ConvertToIFormFile(byte[] fileBytes, string fileName, string contentType);
        string UploadDisputeAttachments(DisputeUpload attachment);
        bool checkFileType(string file);
        string IsUserChecker(string UserName);

        //Dispute Tracking NPCI 
        List<OptionsModel> GetReasonCodeOptionList(string ClientID, int ChannelID, string AdjType);
        List<OptionsModel> GetAdjTypeOptionList(string ClientID, int ChannelID); 
        List<DisputeDetails> GetNPCIDisputeTracking(AdjustmentTxnsNPCIModel ParamsModel);

        //----------------------------------------------------------------- Advait Nair ---------------------------------------------------------------------------------------

        List<dynamic> GetDisputeRaiseData(GetDisputeRaiseDataModel getDisputeRaiseDataModel);

    }
}