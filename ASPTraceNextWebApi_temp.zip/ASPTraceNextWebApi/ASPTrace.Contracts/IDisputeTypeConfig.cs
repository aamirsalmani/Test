﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IDisputeTypeConfig
    {
              List<GetDisputeTypeconfiglist> GetDisputeTypeconfigData(GetDisputeTypeConfigModel getDisputeTypeConfigModel);
            string  EditDisputeTypeconfigData(EditDisputeTypeConfigModel editDisputeTypeConfigModel);
        string DeleteDisputeTypeConfigData(DeleteDisputeTypeConfigModel deleteDisputeTypeConfigModel);

        string AddNewDisputeTypeconfigData(AddNewDisputeTypeConfigModel addNewDisputeTypeConfigModel);

        //        string AddDynamicStatusData(GetStatusModelData getStatusModelData);
        //        string UpdateDynamicStatusData(GetStatusModelData getStatusModelData);
        //        string UploadExcelFile(DataTable dataTable, int clientId, int channelId, int modeId, int reconType, int InsertCount, int ErrorCount);
        //        string CheckExtension(string fileExtension);
    }
}
