﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IDownloadReport
    {

        object DownloadReport(InputReportModel matchedTxnsModel);
    }

    public interface IDownloadService
    {
        Task<string> SaveFileAsync(IFormFile file, string userId);
        Task<int?> BulkInsertDownloadsAsync(DataTable downloadsData, int? ID);
        List<dynamic> DownloadReport(DownloadReportRequest details);
        List<dynamic> DownloadReportByID(DownloadReportRequest details);
        Task<IFormFile> DownloadFileAsync(string filePath);
        string InsertFileToDb(string userId,DataTable FilesList);
        string CheckFilesAndInsertToDb(string userId);
    }
}
