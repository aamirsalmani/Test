﻿using System;
using System.Collections.Generic;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IDynamicFile
    {
        List<LogTypeFileConfigModel> GetLogTypeFileConfig(string ClientID);
        List<ChannelFileConfigModel> GetDynamicChannelList(string ClientID);
        List<ModeFileConfigModel> GetModeFileConfig(string ClientID, int ChannelID);
        List<DynamicModeFileConfigModel> GetDynamicModeFileConfig(string ClientID, int ChannelID);
        List<DynamicFileIDModel> GetDynamicFileID();
        List<DynamicNetworkTypeIDModel> GetDynamicNetworkType(); 
        List<VendorFileConfigModel> GetVendorFileConfig(string VendorType);
        string AddUpdateFileConfig(DynamicFileConfigModel dynamicFileConfigModel);
        List<DynamicFileConfigGrid> GetFileConfigGrid(string ClientID, string LogTypeID);
        List<DynamicFileConfigGrid> GetFileConfigGrid(string ClientID, string NetworkType, string LogTypeID, string ChannelID);
        string AddUpdateFileUploadDetails(DynamicFileUploadModel UploadModel, string FileName, string FilePath, string OriginalFileName);
        DynamicImportFileConfigModel GetDynamicFileUploadDetails(string FileConfigID);
        ConfiguredColumnJsonString GetConfiguredColumnJsonString(string FileConfigID);
        List<XMLColumnModel> GetDynamicColumnsForMapping(string FileConfigID);
        DynamicFileConfigDataModel GetDynamicFileConfigData(string FileConfigID);
        string UpdateMappedColumnJsonString(DynamicFileMappedColumn reconConfigModel);
        string GetConfiguredRawColumnString(string FileConfigID);
        List<XMLColumnModel> GetRawTableSelectedColumns(string FileConfigID);
        List<RawTableColumn> GetRawTableAllColumns(string FileConfigID);
        List<OptionModel> GetFileTypeConfig(string FileExtension);
        string UpdateQueryXMLString(DynamicFileXMLModel reconConfigModel);
        string ParseSqlQuery(DynamicFileMappedColumn reconConfigModel);
        DateTimeFormat GetDateTimeFormat(string FileConfigID, string TableName);
        string UpdateDateTimeFormat(DateTimeFormat dateTimeFormat);
        string GetDynamicFileConfigTable(string FileConfigID);
        List<NetworkTypeModel> GetNetworkTypeFileConfig(string ClientID);
        List<ChannelFileConfigModel> GetChannelList();
        List<ModeFileConfigModel> GetModeList();
        List<DynamicChannelConfigModel> GetDynamicChannelConfigGrid(string ClientID);
        string AddUpdateChannelConfig(DynamicChannelModeConfigModel dynamicFileConfigModel);
        string DeleteChannelModeConfig(DeleteChannelConfigModel objDeleteChannelConfigModel);
        string AddUpdateFileContent(DynamicFileContentModel dynamicFileContentModel);
        List<ClientOptionModel> GetClientListByConfig(DynamicFileConfigModel dynamicFileConfigModel);
        string CopyDynamicFileConfig(tempDynamicFileConfigModel dynamicFileConfigModel);
        DynamicFileContentModel GetFileContent(string FileConfigID);
    }
}
