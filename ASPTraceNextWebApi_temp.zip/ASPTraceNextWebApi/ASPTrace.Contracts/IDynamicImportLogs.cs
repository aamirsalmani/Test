﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;
using Utility;


namespace ASPTrace.Contracts
{
    public interface IDynamicImportLogs
    {
        //IDynamicImportLogs Clone();

        List<ClientOptionModel> GetClientOptions(string UserID);
        List<FileTypeOptionModel> GetFileTypeOptions(string ClientID);
        DataTable GetDynamicFieldDetailsById(string ClientID, string FormatID);
      //  string BulkInsertIssuerDataUPITable(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
        //string BulkInsertAcquirerDataUPITable(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
       // string BulkInsertSWITCHTable(DataTable __DataTable, string ConfigID, DateTime? FileDate, string path, string FileName, string UserName);
       // string BulkInsertSWITCHTableUPI(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
      //  string BulkInsertCBSTable(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
      //  string BulkInsertIssuerDataIMPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
        //string BulkInsertAcquirerDataIMPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
        //string BulkInsertIssuerDataPOS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
        //string BulkInsertIssuerDataATM(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
       // string BulkInsertAcquirerDataATM(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
       // string BulkInsertSettlementDataATM(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
       // string BulkInsertSettlementDataIMPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
        //string BulkInsertSettlementDataUPI(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
        // string BulkInsertAcquirerDataAEPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
        //string BulkInsertIssuerDataAEPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
       // string BulkInsertSettlementDataAEPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
       // string BulkInsertNPCIAdjustmentATM(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
       // string BulkInsertNPCIAdjustmentUPI(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);
        //string BulkInsertNPCIAdjustmentIMPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName);

        //int GetBatchSize(string ConfigID);
        public List<BatchDetails> GetStartBatchPosition(string FileName, int ClientID, int ChannelID, int ModeID);
    }
}
