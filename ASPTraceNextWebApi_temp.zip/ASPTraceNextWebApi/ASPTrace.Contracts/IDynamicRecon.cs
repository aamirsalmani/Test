﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IDynamicRecon
    {
        List<DynamicReconModel> GetDynamicRecon(string ClientID);
        List<ModeDynamicReconModel> GetModeDynamicRecon(string ClientID, int ChannelID);
        List<RunReconHistoryDynamicReconModel> GetRunReconHistoryDynamicRecon(string ClientID);
        List<RunReconAddDynamicReconModel> GetRunReconAddDynamicRecon(ReconStatusDynamicReconModel reconStatusDynamicReconModel);
    }
}
