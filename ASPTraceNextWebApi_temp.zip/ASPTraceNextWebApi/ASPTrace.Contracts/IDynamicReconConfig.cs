﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IDynamicReconConfig
    {
        List<ReconTablesModel> GetReconTables(int ChannelID, int ModeID);
        List<VendorFieldModel> GetNetworkList(string ClientID);
        string GetPreset(int ClientID,int NetworkType ,int ChannelID, int ModeID); 
        List<OptionModel> GetOtherPreset( int NetworkType, int ChannelID, int ModeID,int Type);
        string GetUnmatchedColumns(int ChannelID);
        string GetUnmatchedAllColumns(int ChannelID);
        List<OptionsArray> GetTablesColumns(string TableName);
        List<OptionsArray> GetOperations(string type);
        string GetReconAliasColumns(int ChannelID, int ModeID, int VendorType, int Type);
        string PostJoinTables(ReconQueryFields ClientDetails, List<JoinTableModel> JoinTables);
        
        string PostFormData(FormValues FormValues);
        string PostCaseTable(CaseTableForm ClientParameters, List<AliasReconColumnsModel> PostCaseTable);
        DataTable GenerateRecon(ReconQueryFields reconQueryFields);
        string GenerateReconQuery(int ClientID, int NetworkType, int ChannelID, int ModeID);
        string GenerateJoinQuery(List<JoinTableModel> joinConfigs);

    }
}
