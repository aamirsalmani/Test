﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IDynamicStatus
    {
        List<GetStatusModelData> GetDynamicStatusData(GetStatusModel getStatusModel);
        List<GetFileStatusModel> GetDynamicStatusData();

        string SetDefaultStatus(DefaultStatusModel defaultStatusModel);
        string DeleteDynamicStatusData(GetStatusModelData getStatusModelData);
        string AddDynamicStatusData(GetStatusModelData getStatusModelData);
        string UpdateDynamicStatusData(GetStatusModelData getStatusModelData);
        string UploadExcelFile(DataTable dataTable , int clientId, int channelId,int modeId,int reconType ,int InsertCount,int ErrorCount );
        string CheckExtension(string fileExtension);
    }
}
