﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ASPTrace.Models;


namespace ASPTrace.Contracts
{
    public interface IEjErrorConfig
    {

        string EjErroraddupdate(EjErrorConfigModelssOperations ejErrorConfigModelsOps);

        List<EjErrorConfigModelssData> GetEjErrorListGrid();

        //string DeleteEjErrorConfig(EjErrorConfigModelss ejErrorConfigModels);


    }

}
