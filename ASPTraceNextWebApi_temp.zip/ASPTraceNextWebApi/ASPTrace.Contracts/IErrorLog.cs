﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Contracts
{
    public interface IErrorLog
    {
        void LogUnHandledError(string errorMessage, string stackTrace, string InnerException, string className, string methodName, string userName, string hostName, string ipAddress);
    }
}
