﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IExceptionsReport
    {


        List<EJMissingDataModel> GetEJMissingData(EJMissingReportModel eJMissingModel);

        System.Data.DataTable ExportCsvReportKS(RawDataInputModel rawDataInput);
        System.Data.DataTable ExportExcelReportKS(RawDataInputModel rawDataInput);

        List<TerminalOptionModel> GetTerminalOptions(int ClientID);


    }
}
