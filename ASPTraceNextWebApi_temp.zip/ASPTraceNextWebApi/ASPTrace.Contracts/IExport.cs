﻿using System;
using System.Collections.Generic;
using System.Data; 
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IExport
    {
        DataTable GetUnmatchedTxnsDataTable(InputReportModel unmatchedTxnsModel, string SearchText);
        DataTable GetMatchedTxnsDataTable(InputReportModel unmatchedTxnsModel, string SearchText);
        DataTable GetReversalTxnsDataTable(InputReportModel unmatchedTxnsModel);
        DataTable GetUnsuccessfulTxnsDataTable(InputReportModel unmatchedTxnsModel, string SearchText);
        DataTable GetDuplicateTxnsDataTable(InputReportModel unmatchedTxnsModel);
        DataTable GetAdjustmentDataTable(AdjustmentTxnsModel adjustmentTxnsModel);
        DataTable  GetDmsTxnsDataTable(InputReportModel dmsTxnsModel);
        DataTable GetSettlementTxnsDataTable(InputSettlementReportModel settlementTxnsModel);
        DataTable GetConsoleSetTxnsDataTable(ConsoleSetReportModel details);

        DataTable GetSwitchFeeTxnsDataTable(SwitchFeeReportModel details);
    }
}
