﻿using ASPTrace.Models;

namespace ASPTrace.Contracts;

   public interface IField
    {
         
        System.Data.DataTable GetChannelModeDetailsField(string ClientID);
        System.Data.DataTable AddFieldConfig(AddFieldConfigModel addFieldConfigModel);
        List<VendorFieldModel> GetVendorFields(string ClientID);
        List<ChannelFieldModel> GetChannelFields(string ClientID);
        List<ModeFieldModel> GetModeFields(string ClientID, string ChannelID);
        List<FormatIdFieldModel> GetFormatIdFields(string ClientID, string VendorID, string ChannelID, string ModeID);
        List<FieldIdentificationDetailsModel> GetFieldIdentificationDetails(string ClientID, string VendorID, string ChannelID, string ModeID, string FormatID);
        List<FieldIdentificationVendorDetailsModel> GetFieldIdentificationVendorDetails(string VendorID, string ChannelID);

    }

 
