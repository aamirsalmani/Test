﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IFileConfig
    {
        List<ClientFileConfigModel> GetClientFileConfig();
        List<ConfiguredFormatFileConfigModel> GetConfiguredFormatFileConfig(string ClientID);
        List<LogTypeFileConfigModel> GetLogTypeFileConfig(string ClientID);
        List<ChannelFileConfigModel> GetChannelFileConfig(string ClientID);
        List<ModeFileConfigModel> GetModeFileConfig(string ClientID, int ChannelID);
        List<VendorFileConfigModel> GetVendorFileConfig(string VendorType);
        FileFormatActiveFileConfigModel GetFileFormatActiveFileConfig(string VendorType, string ClientID, string ChannelID, string ModeID, string VendorID);
        List<FileFormatHistoryFileConfigModel> GetFileFormatHistoryFileConfig(string VendorType, string ClientID, string ChannelID, string ModeID, string VendorID);
        FileFormatActiveFileConfigModel GetFileFormatFileConfig(string ClientID, string ChannelID, string ModeID, string VendorID, string FileExt, string SeparatorType, string FilePrefix);
        FileFormatByFileType GetFileFormatByFileTypeFileConfig(FileFormatFileConfigModel fileFormatFileConfigModel);
        FileFormatActiveFileConfigModel GetFileFormatDefualtFileConfig(string FileExt, string SeparatorType, string ChannelID, string ModeID, string VendorID);
        List<ConfiguredFormatFileConfigModel> InsertFileFormat(FileFormatHistoryFileConfigModel fileFormatHistoryFileConfigModel);
    }
}