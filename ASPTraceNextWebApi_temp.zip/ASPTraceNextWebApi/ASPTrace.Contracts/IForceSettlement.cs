﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
  public interface IForceSettlement
    {
        List<StatusMasterForceSettlementModel> GetStatusMasterForceSettlement();
        List<ClientForceSettlementDetailsModel> GetClientForceSettlementDetails(ClientForceSettlementModel clientForceSettlementModel);
        //int GetForceSettlementTxnsInsert(System.Data.DataTable tblForceSettledTxns, ClientForceSettlementModel clientForceSettlementModel);
        //ForceSettleByReferenceNumber GetForceSettleByReferenceNumber(ForceSettledModel forceSettledModel);
        string InsertForceSettlementDetails(ForceSettledModel forceSettledModel);
    }
}
