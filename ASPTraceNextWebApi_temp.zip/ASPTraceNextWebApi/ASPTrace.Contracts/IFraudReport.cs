﻿using ASPTrace.Models;

namespace ASPTrace.Contracts;

    public interface IFraudReport
    {
        List<MultipleTxnsWithDiffTerminalModel> GetMultipleTxnsWithDiffTerminal(MultipleTxnsDiffModel multipleTxnsDiffModel);

        FraudReportDiffByTxnCount GetFraudReportDiffByTxnCount(MultipleTxnDiffModel multipleTxnsDiffModel);
        List<MidnightTransactionsReportModel> GetMidnightTransactionsTxnCount(MidnightTransactionsModel midnightTransactionsModel);

        List<MultipleTxnsWithSameTerminalModel> GetMultipleTxnsWithSameTerminal(FraudReportModel multipleTxnsSameModel);

        FraudReportSameByTxnCount GetFraudReportSameByTxnCount(MultipleTxnsSameModel multipleTxnsSameModel);

        List<FrequentReversalReportDetailsModel> GetFrequentReversalReportDetails(FraudReportModel frequentReversalReportModel);

        FrequentReversalTxnByTxnCount GetFrequentReversalTxnByTxnCount(FrequentReversalsReportModel frequentReversalReportModel);

        List<HighValueTerminalTransactionsModel> GetHighValueTerminalTransactions(string ClientID, string ChannelID, string UserName);

        List<HighValueTransactionsReportModel> GetHighValueTransactionsReport(HighValueTransactionsModel highValueTransactionsModel);

        HighValueTransactionsOnTxnCountModel GetHighValueTransactionsOnTxnCount(HighValueTransactionModel highValueTransactionsModel);
		
		List<DuplicateRecordModel> GetDuplicateRecordsReport(InputReportModel duplicateTxnsModel);
    } 
