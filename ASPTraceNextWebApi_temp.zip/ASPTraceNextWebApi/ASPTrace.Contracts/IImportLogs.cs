﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IImportLogs
    {


        int AddBranchMaster(string ClientId, System.Data.DataTable dtBranch);
        int AddTerminalMaster(string ClientId, System.Data.DataTable dtTerminal);

        List<FileTypeImportLogsModel> GetFileTypeImportLogs(string ClientID);

        System.Data.DataTable GetFileTypeFormatById(string ClientID, string FormatID);
        System.Data.DataTable GetFileNameNotContain(string ClientID, string FormatID); 
        string SWDataTable(System.Data.DataTable _DataTable);
        string GetFileQuery(int ClientID, int ChannelID, int ModeID, int VendorID);
        string SWDataTableDynamic(System.Data.DataTable _DataTable,string Query);
        string GLDataTableDynamic(System.Data.DataTable _DataTable, string Query);
        string GLDataTable(System.Data.DataTable _DataTable);
        string AcquirerDataNPCIATM(System.Data.DataTable _DataTable);
        string IssuerDataNPCIATM(System.Data.DataTable _DataTable);
        string EJDataTable(System.Data.DataTable _DataTable);
        string BulkInsertEJData(System.Data.DataTable __DataTable, string FileImportID);
        string AdjlogImportdata(System.Data.DataTable _DataTable);
        string NPCISettlementDataTable(System.Data.DataTable _DataTable);
        string IMPSAdjustmentimportlogImportdata(System.Data.DataTable _DataTable);
        string IMPSSettlementDataTable(System.Data.DataTable _DataTable);
        string IMPSIssuerimportlogImportdata(System.Data.DataTable _DataTable);
        string IMPSAcquirerimportlogImportdata(System.Data.DataTable _DataTable);
        string RefundlogImportdata(System.Data.DataTable _DataTable);
        //string NPCIBillingSummarryDataTable(System.Data.DataTable _DataTable);
        //string InterchangeSummarryDataTable(System.Data.DataTable _DataTable);
        //string NetSettlementDataTable(System.Data.DataTable _DataTable);
        //string DSRSummarryDataTable(System.Data.DataTable _DataTable);
        //string PresentmentDataTable(System.Data.DataTable _DataTable);
        string IssuerDataNPCIPOS(System.Data.DataTable _DataTable);
        string UPISettlementDataTable(System.Data.DataTable _DataTable);
        string IssuerDataUPITable(System.Data.DataTable _DataTable);
        string UPIacquirerimportlogImportdata(System.Data.DataTable _DataTable);
        string BFSDataBFSTable(System.Data.DataTable _DataTable);
        string UPIDRCImportdata(System.Data.DataTable _DataTable);
        string IssuerDataVISA(System.Data.DataSet _DataSet);
        string chargebackTable(System.Data.DataTable _DataTable);
        string NEFTRTGSImportdataBankINWARD(System.Data.DataTable _DataTable);
        string BFSDataCommon(System.Data.DataSet _DataSet);
        string NEFTRTGSImportdata(System.Data.DataTable _DataTable);
        string C3Rimportdata(System.Data.DataTable _DataTable);
        string impsissuerimportlogImportdata(System.Data.DataTable _DataTable);
        string impsAdjustmentimportlogImportdata(System.Data.DataTable _DataTable);
        string impsacquirerimportlogImportdata(System.Data.DataTable _DataTable);
       
        string BulkInsertEJMachineCounterData(System.Data.DataTable __DataTable);
        string BulkInsertEJSwitchCounterData(System.Data.DataTable __DataTable);

        string BulkInsertUPIAdjustment(System.Data.DataTable __DataTable);
        string BulkInsertAEPSAcquirerData(System.Data.DataTable __DataTable);
        string BulkInsertAEPSIssuerData(DataTable __DataTable);

        string AcquirerDataVISA(System.Data.DataTable _DataTable);
        string AcquirerDataVISAEP745(System.Data.DataTable _DataTable);
        string AcquirerDataMASTER(System.Data.DataTable _DataTable);

        string BulkInsertAEPSSettlement(System.Data.DataTable __DataTable);
        string BulkInsertAEPSAdjustment(System.Data.DataTable __DataTable);
        string NEFTRTGSImportdataNPCI(System.Data.DataTable __DataTable);
        string BulkInsertNETCACQUIERDATA(System.Data.DataTable __DataTable);
        string BulkInsertNETCDisputeDATA(System.Data.DataTable __DataTable);
        string BulkInsertNPCINETCSettlementData(System.Data.DataTable __DataTable);
        string BulkInsertNpciNETCServiceFee(System.Data.DataTable __DataTable);
        string BulkInsertNPCIFee(System.Data.DataTable __DataTable);
        string MasterT464DataTable(System.Data.DataTable _DataTable);
        int AddDisputeCHBK(DisputeAddModel disputeModel);

        string BulkInsertBBPSNetwork(System.Data.DataTable dataTable);
        string TableBBPSSettlement(System.Data.DataTable dataTable);
        string GLAgentLedgerBBPS(System.Data.DataTable dataTable);
        string MobiwareDataTable(System.Data.DataTable dataTable);
        string BulkInsertSwitchFilesDataBBPS(System.Data.DataTable dataTable);

        string GLDataTable_L(System.Data.DataTable dataTable);
        string SWDataTable_L(System.Data.DataTable dataTable);
        string BulkInsertEJData_L(System.Data.DataTable dataTable);
        string AcquirerDataNPCIATM_L(System.Data.DataTable dataTable);
        string IssuerDataNPCIATM_L(System.Data.DataTable dataTable);
        string BFSDataBFSTable_L(System.Data.DataTable dataTable);
        string IssuerDataNPCIPOS_L(System.Data.DataTable dataTable);
        string RefundlogImportdata_L(System.Data.DataTable dataTable);
        string BBPSPaySWDataTableDynamic(System.Data.DataTable _DataTable);
        string BulkInsertGLFilesDataCycleWise(System.Data.DataTable _DataTable);

        string BulkInsertPayrakkamSWDataTableCSV(System.Data.DataTable _DataTable);
        string BulkInsertPayrakkamGLDataTableCSV(DataTable _DataTable);
        string BulkInsertPayrakkamBBPSSettlementCSV(DataTable _DataTable);
        string BulkInsertPayrakkamBBPSNetworkXML(DataTable _DataTable);
        string BulkInsertPayrakkamFranchiseLedger(DataTable _DataTable);
        string BulkInsertPayrakkamFranchiseLedgerCycleWise(DataTable _DataTable);
        string BulkInsertPayrakkamIMPSAdjData(DataTable _DataTable);
        string BulkInsertPayrakamAdjustmentData(DataTable _DataTable);
        string BulkInsertPayrakkamMATMAdjustmentData(DataTable _DataTable);
        string BulkInsertTimeout(DataTable _DataTable, string ClientID, string FilePath, string FileName, string UserName);
        string BulkInsertDebitReversal(DataTable _DataTable, string ClientID, string FilePath, string FileName, string UserName);
        string BulkInsertGLAdjustmentALL(DataTable __DataTable, string path, string FileName, string UserName);
        string BulkInsertRefundlogs(DataTable __DataTable);
        string BulkInsertCBRData(DataTable __DataTable, DateTime? FileDate, string FilePath, string FileName, string UserName);
        string BulkInsertSwapCBRDataNCR(DataTable __DataTable, DateTime? FileDate, string FilePath, string FileName, string UserName, string ClientID);
    }
}
