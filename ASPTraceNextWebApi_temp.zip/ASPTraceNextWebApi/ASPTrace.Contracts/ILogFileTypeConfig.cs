﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface ILogFileTypeConfig
    {

        List<GetLogFileTypeconfiglist> GetLogFileTypeConfigData(GetLogFileTypeConfigModel getLogFileTypeConfigModel);

        string AddNewLogfileTypeconfigData(LogfileTypeConfigModel addNewLogfileTypeConfigModel);

        string EditLogfileTypeconfigData(LogfileTypeConfigModel editLogfileTypeConfigModel);
        string DeleteLogFileTypeConfigData(DeleteLogFileTypeConfigModel deleteLogfileTypeConfigModel);

        LogfileTypeConfigModel GetLogTypeConfigurationDetails(int ID);
    }
}
