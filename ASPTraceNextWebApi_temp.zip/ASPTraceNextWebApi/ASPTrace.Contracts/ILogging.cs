﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface ILogging
    {
        List<UserLoginReportDataModel> GetUserLoginReport(UserLoginReportModel userLoginReport);
        List<UserListModel> GetUserList();
        List<MenuListModel> GetMenuList();
        string EnableMenuItem(MenuEnableModel menuEnableModel);
        List<DbExceptionDataModel> GetDbExceptionList(DbExceptionModel dbExceptionModel);
        List<ErrorLogDataModel> GetErrorLogList(ErrorLogModel errorLogModel);

        List<UserActivityReportDataModel> GetUserActivityReport(UserLoginReportModel userLoginReportModel);

        string InsertUserActivityReport(UserActivityReportInsertModel userLoginReportModel);
        List<dynamic> GetUserAddedModifiedDetails(UserAuditReportModel usermodel);
    }
}
