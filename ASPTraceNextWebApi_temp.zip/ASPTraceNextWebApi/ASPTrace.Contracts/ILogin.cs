﻿using System.Threading.Tasks;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface ILogin
    {
        UserClientModel GetClientCodeDetails(string UserID);
        LoginSuccessModel ValidateUser(LoginModel loginModel);
        LoginSuccessModel GetById(string UserID);
        CAPTCHAModel GetCAPTCHA(string UniqueId);
        string VERIFY_CAPTCHA(string CAPTCHACODE, string WebToken);
        int UpdateLoginCount(UserLoginCountModel loginCountModel);
        FirstLoginModel GetUserDetailsByEmailId(string EMAILID);
        Task InsertUserLoginAuditAsync(LoginRequest loginRequest);
        Task InsertUserLogoutAuditAsync(LogoutRequest logoutRequest);
        Task<int> AddUserLoginHistoryAsync(UserLoginHistory userLoginHistory); 
        string GetUserIdFromRefreshToken(string TokenId);
        string AddRefreshToken(string UserID, DateTime ExpirationDate);
        string AddOrUpdateThemes(ThemeModel themeModel);
    }
}
