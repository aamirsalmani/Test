﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IMatchingRule
    {
        List<ChannelMatchingModel> GetChannelMatching(string ClientID);
        List<ModeMatchingModel> GetModeMatching(string ClientID, string ChannelID);
        System.Data.DataTable GetMatchingRuleSetForClient(string ClientID, string ChannelID, string RuleType);
        //List<AddMatchingRuleConfig> GetAddMatchingRuleConfig(string BindMatchingRules);
        int ChannelModeDetailsField(System.Data.DataTable dtMatchingRules);

        List<MatchingRuleSetForClient> GetMatchingListByClient(string ClientID);
        List<ModeMatchingModel> GetImportConfigModeList(string ClientID, string ChannelID);

        List<MatchingColumnTable> GetMatchingColumnTableList(string ClientID, string ChannelID, string ModeID);
        List<MatchingColumns> GetMatchingColumnList(string ClientID, string ChannelID, string ModeID);

        int AddMatchingRuleConfig(System.Data.DataTable dtMatchingRules);

        List<ReconImportConfig> GetImportConfigListByClient(string ClientID);

        string DeleteMatchingRuleConfig(DeleteMatchingModel deleteMatchingModel);
    }
}
