﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IModeReg
    {
        List<ModeRegModel> GetModeReg();
        string ModeRegAdd(ModeRegAddModel modeRegAddModel);
        ModeRegDetcailsModel GetModeDetails(string ModeID);
        string ModeRegDelete(ModeRegDeleteModel modeRegDeleteModel);
    }
}
