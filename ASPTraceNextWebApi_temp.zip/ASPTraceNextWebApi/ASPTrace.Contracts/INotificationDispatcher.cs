﻿using ASPTrace.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASPTrace.Contracts
{
    public interface INotificationDispatcher
    {
        Task HandleNotification(NotificationEvent notificationEvent);
    }
}
