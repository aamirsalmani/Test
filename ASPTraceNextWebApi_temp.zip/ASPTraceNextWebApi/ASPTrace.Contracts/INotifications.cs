﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface INotifications
    { 
        public Task<List<dynamic>> GetNotificationListAsync();
        public Task<string> SetNotificationAsReadAsync(string notificationId, string notificationType);
    }
}
