﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;


namespace ASPTrace.Contracts
{
   public interface IReconConfig
    {
        string SubmitReconConfig(ReconImportConfigModel table);
        string XMLConfig(int ClientID, int ChannelID, int ModeID,int VendorID,string XML,string FileData);
        string DateFormatArray(int ClientID, int ChannelID, int ModeID, int VendorID, System.Data.DataTable DateFormats);
        string RawFileUploadQuery(int ClientID, int ChannelID, int ModeID, int VendorID,int ReconType, string RawQuery,string UserName);
        System.Data.DataTable GetChannelModeDetailsField(string ClientID);
        System.Data.DataTable AddFieldConfig(AddFieldConfigModel addFieldConfigModel);
        System.Data.DataTable txtTableWithSeperator(string path,string Seperator); 
        System.Data.DataTable txtTableWithoutSeperator(string path);
        System.Data.DataTable ExcelTable(string path);
        System.Data.DataSet tblStatusConditions(List<StatusConditionsModel> RawData);
        System.Data.DataSet AddRawTableFields(List<ReconRawTableFields>  RawData);
        System.Data.DataTable GenerateRecon(ReconQueryFields reconQueryFields);
        List<VendorFieldModel> GetVendorFields(string ClientID);
        List<VendorFieldModel> GetPreset(int ClientId, int ChannelID, int ModeID); 
        List<CaseOutputModel> CaseOutputList(string ClientID);
        List<ChannelFieldModel> GetChannelFields(string ClientID);
        List<ModeFieldModel> GetModeFields(string ClientID, int ChannelID);
        List<ReconTablesModel> GetReconTables(int ChannelID,int ModeID);
        List<MasterValues> GetOperations();
        List<MasterValues> GetDateFormats();
        List<MasterValues> GetParameters();
        List<ReconColumnsModel> GetReconColumns(string Tablename);
        List<ReconAliasColumnsModel> GetReconAliasColumns(int ChannelID, int ModeID, int VendorType, int Type);
        List<ReconTypeModel> GetReconType();
        List<FormatIdFieldModel> GetFormatIdFields(string ClientID, string VendorID, int ChannelID, string ModeID);
        List<FieldIdentificationDetailsModel> GetFieldIdentificationDetails(string ClientID, string VendorID, int ChannelID, string ModeID, string FormatID);
        List<FieldIdentificationVendorDetailsModel> GetFieldIdentificationVendorDetails(string VendorID, int ChannelID);


        List<ReconTablesModel> GetReconTableList(int ChannelID, int ModeID); 
        List<ChannelOptionModel> GetChannelOptions(string ClientId);
        List<ModeOptionModel> GetModeOptions(string ClientID, string ChannelID);
        string AddUpdateReconImportConfig(ReconConfigModel reconConfigModel, ReconConfigTableModel reconConfigTableModel);
        List<DynamicReconConfig> GetReconConfigGrid(string ClientID, string ChannelID, string ModeID, string ReconType);
        string GetSelectedTables(string ClientID, string ChannelID, string ModeID, string ReconType);
        string AddUpdateReconFileConfig(DynamicImportFileModel reconConfigModel, string FileName, string FilePath, string OriginalFileName);
        DynamicImportFileConfigModel GetDynamicImportFileConfig(string FileConfigID);

        List<ReconAliasColumnsModel> GetXMLSchemaColumn(string FileConfigID);
        string GetConfiguredColumnString(string FileConfigID);
        string UpdateMappedColumnString(DynamicFileMappedColumn reconConfigModel);
        ConfiguredColumnJsonString GetConfiguredColumnJsonString(string FileConfigID);
        DynamicFileConfigDataModel GetDynamicReconFileConfigData(string FileConfigID);
        List<ReconAliasColumnsModel> GetRawTableSelectedColumns(string FileConfigID);
        string GetConfiguredRawColumnString(string FileConfigID);
        List<RawTableColumn> GetRawTableAllColumns(string FileConfigID);
        string UpdateQueryXMLString(DynamicFileXMLModel reconConfigModel);
    }

}
