﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IReport
    {
        //Unmatched Report
        // List<dynamic> GetUnmatchedTxnsReport(InputReportModel unmatchedTxnsModel);
        PaginatedResult GetUnmatchedTxnsReport(DailyReportInputReportModel unmatchedTxnsModel, int pageNumber, int pageSize);

        TxnByReferenceNumber GetUnmatchedTxnByReferenceNumberReport(InputReferenceNumberModel unmatchedTxnsModel);

        //Matched Report
        PaginatedResult GetMatchedTxnsReport(DailyReportInputReportModel matchedTxnsModel, int pageNumber, int pageSize);

        //Reversal Report 
        PaginatedResult GetReversalTxnsReport(DailyReportInputReportModel reversalTxnsModel, int pageNumber, int pageSize);

        //Unsuccessful Report
        PaginatedResult GetUnsuccessfulTxnsReport(DailyReportInputReportModel unsuccessfulTxnsModel, int pageNumber, int pageSize);

        //Duplicate Report
        PaginatedResult GetDuplicateTxnsReport(DailyReportInputReportModel duplicateTxnsModel, int pageNumber, int pageSize);
        List<dynamic> GetPosDmsTxnsReports(DailyReportInputReportModel dmsTxnsModel);

        //Adjustment Report 
        List<AdjustmentTerminalDetailsModel> GetAdjustmentTerminalDetails(string UserName, string ClientID);
        List<AdjustmentModeModel> GetAdjustmentMode(string ClientID, string ChannelID);
        List<AdjustmentTxnsReportModel> GetAdjustmentTxnsReport(AdjustmentTxnsModel adjustmentTxnsModel);

        //File Status Report 

        List<FileStatusReportDetailsModel> GetFileStatusReportDetails(FileStatusReportModel fileStatusReportModel);

        //Dispense Unmatched Report

        List<TerminalOptModel> GetTerminalOptions(int ClientID);
        List<DispenseUnmatchedReportModel> GetDispenseUnmatchedReport(DispenseUnmatchedModel dispenseUnmatchedModel);

        DispenseUnmatchedReportByReferenceNumberClick GetDispenseUnmatchedReportByReferenceNumberClick(DispenseUnmatchedReferenceNumberModel dispenseUnmatchedModel);
        //-------------------------------------------------nk----------------------------------------------//
        List<dynamic> GetALLTTUMReportDetailsList(AllTTUMReportModelNew allTTUMReportModel);

        List<dynamic> ExportCheckedExcelReport(AllTTUMReportModelNew allTTUMReportModel);

        List<CreditAdjustmentTTUMData> UpdateCheckedData(UpdateCheckerModel updateCheckerModel, DataTable dataTable);

        string UpdateCheckedDataNew(UpdateNewCheckerModel updateCheckerModel);

        List<dynamic> GetCreditAdjustmentTTUM(NPCIAllTTUMReportModel allTTUMReportModel);

        List<SettelmentTTUMReport> GetSettelmentTTUMReport(AllTTUMReportModelNew allTTUMReportModel);

        List<TipsAndSurTTUMReport> GetTipsAndSurchargeTTUMReport(AllTTUMReportModelNew allTTUMReportModel);
        //-------------------------------------------------nk----------------------------------------------//
        List<ATMTtumReportDetailsModel> GetATMTtumReportDetails(ATMTtumReportModel aTMTtumReportModel);

        List<IMPSSettlementReportDetailsModel> GetIMPSSettlementReportDetails(IMPSSettlementReportModel iMPSSettlementReportModel);
        System.Data.DataTable GetIMPSSettlementReport(IMPSSettlementReportModel iMPSSettlementReportModel);

        List<IMPSTTUMReportDetailsModel> GetIMPSTTUMReportDetails(IMPSTTUMReportModel iMPSTTUMReportModel);
        List<IMPSTTUMInsertReportDetailsModel> GetIMPSTTUMInsertReportDetails(IMPSTTUMInsertReportModel iMPSTTUMInsertReportModel);

        List<IssuerTransactionTTUMReportDetailsModel> GetIssuerTransactionTTUMReportDetails(IssuerTransactionTTUMReportModel issuerTransactionTTUMReportModel);

        //List<BankSettlementReportDetailsModel> GetBankSettlementReportDetails(BankReportModel bankSettlementReportModel);

        List<ReasonWiseSummaryReportDetailsModel> GetReasonWiseSummaryReportDetails(ReasonWiseSummaryReportModel reasonWiseSummaryReportModel);

        List<RefundCashbackTTUMReportDetailsModel> GetRefundCashbackTTUMReportDetails(RefundCashbackTTUMReportModel refundCashbackTTUMReport);

        List<RefundTxnsReportDetailsModel> GetRefundTxnsReportDetails(RefundTxnsReportModel refundTxnsReportModel);

        List<POSTtumReportDetailsModel> GetPOSTtumReportDetails(POSTtumReportModel pOSTtumReportModel);

        List<POSSettlementReportDetailsModel> GetPOSSettlementReportDetails(POSSettlementReportModel pOSSettlementReportModel);

        List<PendingAcqEntryReportDetailsModel> GetPendingAcqEntryReportDetails(PendingAcqEntryReportModel pendingAcqEntryReportModel);

        List<SettledTransactionsReportDetailsModel> GetSettledTransactionsReport(SettledTransactionsReportModel settledTransactionsReportModel);

        SettledTransactionsReportByReferenceNumber GetSettledTransactionsReportByReferenceNumber(SettledTransactionsReportModel settledTransactionsReportModel);

        List<SuccessfulAmountCountReportDetailsModel> GetSuccessfulAmountCountReportDetails(SuccessfulAmountCountReportModel successfulAmountCountReportModel);
        List<UPISettlementReportDetailsModel> GetUPISettlementReportDetails(UPISettlementReportModel uPISettlementReportModel);

        List<TipsAndSurchargeDetailsModel> GetTipsAndSurchargeDetails(TipsAndSurchargeModel tipsAndSurchargeModel);
        
        List<dynamic> GetConsoleSetReportDetails(ConsoleSetModel ConsoleSetModel);

        List<dynamic> GetSwitchFeeReportDetails(SwitchFeeModel SwitchFeeModel);


        List<DispenseSummaryDetailsModel> GetDispenseSummaryDetails(DispenseSummaryModel dispenseSummaryModel);
        
       public string InsertDispenseSummaryJob(InsertDispenseSummaryModel dispenseSummaryModel);

        List<TxnCountDetailsModel> GetTxnCountDetails(TxnCountModel txnCountModel);

        //Unsuccessful Txns Report

        List<UnsuccessfulTxnsGridReportModel> GetUnsuccessfulTxnsGridReport(UnSuccessfulTxnsModel unSuccessfulTxnsModel);

        UnsuccessfulTxnsByReferenceNumber GetUnsuccessfulTxnsByReferenceNumberReport(UnSuccessfulTxnsModel unSuccessfulTxnsModel);
        List<UPI_TTUM_DisputeModel> GetUPITTUMDisputeReportDetails(TTUMReportModel iMPTTUMReportModel);
        List<UPI_TTUM_DisputeModel> GetIMPSTTUMDisputeReportDetails(TTUMReportModel iMPTTUMReportModel);
        List<TIMEOUTModel> GetTIMEOUTReportDetails(TTUMReportModel iMPTTUMReportModel);
        List<NPCIBulkModel> Get_NPCI_BULK_UPLOAD_Report(TTUMReportModel iMPTTUMReportModel);
        List<NPCIBulkModel> GetDrcReportDetails(TTUMReportModel iMPTTUMReportModel);

        //Cash Tally
        List<dynamic> GetCashTallyReportDetail(CashTallyReportModel cashTallyReportModel);

        List<dynamic> GetCashTallyUnmatchedReport(DispenseUnmatchedModel dispenseUnmatchedModel);
        //TxnByReferenceNumber GetUnmatchedTxnByTerminalNumberReport(InputTerminalModel unmatchedTxnsModel);
        TxnDetailsByReferenceNumber GetTxnsReportByReferenceNumber(InputReferenceNumberModel unmatchedTxnsModel);
        System.Data.DataTable GetALLTTUMReportDataTable(AllTTUMReportModelNew allTTUMReportModel);
        List<DispenseSummaryJobGridModel> GetDispenseSummaryJobDetails(GetDispenseSummaryJob dispenseSummaryModel);
    }


}
