﻿using ASPTrace.Models;

namespace ASPTrace.Contracts;

    public interface IRoleCreation
    {
        List<RoleCreationModel> GetRole(string ClientID);
        List<RoleMenuAccessModel> GetRoleAccessRights(string ClientID, string RoleID);
        string RoleAddUpdate(RoleDetailsRegModel roleDetailsRegModel);
        RoleDetailsRegModel GetRoleDetails(string ClientID, string RoleID);
        string DeleteRoleReg(DeleteRoleModel roleDetailsRegModel);
        int AssignRoleAccessRights(AssignRoleAccessRightsModel assignRoleAccessRightsModel);
        int AssignRoleMenuAccessRights(AssignRoleMenuAccessRightsModel assignRoleAccessRightsModel);
        List<MenuAccessModel> GetMenuAccess(string UserID, string RoleID, string MenuLevel, string ClientID);
        string AddUpdateRole(RoleDetailsRegModel roleDetailsRegModel);
        string AddUpdateRoleCore(RoleDetailsModel roleDetailsRegModel);
        List<RoleMenuModel> GetRoleAccessRightsCore(string RoleID);
        List<RoleListModel> GetRoleAccessGrid(UserFilterModel2 userModel);
        RoleDetailsModel GetRoleDetails(string RoleID);
        string DeleteRoleCore(DeleteRoleModel roleDetailsRegModel);
        string ActionTakenByChecker(ActionModel nModel);
        string DeleteTempRoleCore(ActionModel actionModel);
        string EditApprovedRole(UserFilterModel2 userModel);
}
    