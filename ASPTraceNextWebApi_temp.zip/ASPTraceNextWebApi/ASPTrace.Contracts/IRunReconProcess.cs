﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{

    public interface IRunReconProcess
    {
        List<ChannelRunReconProcessModel> GetChannelRunReconProcess(string ClientID);
        List<ModeRunReconProcessModel> GetModeRunReconProcess(string ClientID, int ChannelID);
        List<RunReconHistoryRunReconProcessModel> GetRunReconHistoryRunReconProcess(string ClientID, string ChannelID, string ModeId);
        List<RunReconAddRunReconProcessModel> GetRunReconAddRunReconProcess(ReconStatusRunReconProcessModel reconStatusRunReconProcessModel);

        List<dynamic> GetRunReconFileStatusList(ReconFileStatusProcessModel reconFileStatusProcessModel);

        string ConfirmRunReconAdd(ReconStatusRunReconProcessModel reconStatusRunReconProcessModel);

        string ForceRunRecon(ForceRunReconRequest model); //Added By Kaif 

        RunReconFileStatus GetDefaultFileUploadCount(ReconFileStatusListModel defaultFileCountProcessModel);
        List<dynamic> GetTtumReportJobGrid(NPCIReportModel nPCIReportModel);
        string AddTtumReportJob(NPCIReportModel nPCIReportModel);
        List<dynamic> GetReportGrid(NPCIReportModel nPCIReportModel);

        string UpdateStatusByMaker(NPCIReportModel nPCIReportModel);
        string UpdateStatusByChecker(NPCIReportModel nPCIReportModel);
        string DeleteTransaction(DeleteReportModel nPCIReportModel);
        string GetCheckerMakerStatus(NPCIReportModel nPCIReportModel);
        DataTable GetReportDataTable(NPCIReportModel nPCIReportModel);

        string GetUploadedFileList(ReconFileStatusListModel defaultFileCountProcessModel, string Filetype);
    }
}
