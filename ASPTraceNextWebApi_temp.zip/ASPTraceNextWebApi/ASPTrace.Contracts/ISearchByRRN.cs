﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
   public interface ISearchByRRN
    {
        List<SearchByRRNDetailsModel> GetSearchByRRNDetails(SearchByRRNModel searchByRRNModel);
    }
}
