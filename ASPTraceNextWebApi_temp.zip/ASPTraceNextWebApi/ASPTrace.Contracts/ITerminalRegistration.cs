﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface ITerminalRegistration
    {
        List<TerminalConfigMaster> GetTerminalMasterGridData();
        string CheckTerminalIDExists(string ID, string TerminalID);
        List<TerminalState> GetTerminalState();
        List<StateDistrictModel> GetDistrictOptions(string StateID);
        TerminalRegConfigMaster GetTerminalRegConfigMasterData(string ID);
        List<VendorMaster> GetVendorMaster();
        List<LocationTypeMaster> GetLocationTypeMaster();
        List<ATMMakeTypeMaster> GetATMMakeTypeMaster();
        List<SiteTypeMaster> GetSiteTypeMaster();
        List<SiteClassMaster> GetSiteClassMaster();
        List<TerminalTypeMaster> GetTerminalTypeMaster();
        List<BranchMaster> GetBranchMaster(string ClientID);
        int AddUpdateTerminalMaster(TerminalConfigMasterNew terminalConfigMasterNew);
        string TerminalRegDelete(TerminalRegDeleteModel terminalRegDeleteModel);
    }
}
