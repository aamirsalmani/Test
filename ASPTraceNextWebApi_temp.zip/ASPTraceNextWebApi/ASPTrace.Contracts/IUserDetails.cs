﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts;

public interface IUserDetails
{
    List<UserClientDetailsModel> GetUserClientDetails();
    List<UserBranchDetailsModel> GetUserBranchDetails(string ClientID);
    List<UserRoleDetailsModel> GetUserRoleDetails(string ClientID);
    List<UserDetailsGridModel> GetUserDetailsGrid(UserFilterModel userDetailsModel);
    List<UserResetPasswordModel> GetUserResetPassword(GetUserResetPassModel userDetailsModel);
    string CreateUser(UserDetailsModel userDetailsModel, string Salt);
    string UpdateChangePassword(PasswordModel passwordModel);
    PasswordHistoryModel GetLastPasswords(string UserID, string ClientCode);
    string CheckUserId(string UserID, string ClientID);
    UpdateDetailsModel GetUserDetail(string UserID);
    string UpdateUser(UpdateUserModel userDetailsModel);
    string DeleteUser(DeleteUserModel userDetailsModel);
    List<RoleAccessRightsModel> GetRoleAccessRights(RoleAccessList userDetailsModel);
    int AssignRoleAccessRights(AssignRoleAccessModel assignRoleAccessRightsModel);
    string GetUserEmailId(string UserID, string ClientID);
    int AddClientDetails(ClientConfigMaster objReg);
    string GetClientCodeByUserName(string UserID);
    List<UserClientChannelModeDetails> GetUserChannelModeConfiguration(string ClientID, string UserId);
    int AddUserChannelMode(UserClientChannelModeDetails channelModeDetail);
    List<UserDetailsGridModel> GetUsers(UserFilterModel2 userDetailsModel);
    List<RoleOptionModel> GetUserRoles();
    string CreateUserCore(UserDetailsModel userDetailsModel, string Salt);
    UpdateDetailsModel GetUserData(UserFilterModel2 userModel);
    List<UserChannelModeDetails> GetClientIDChannelModeConfiguration(RoleAccessList roleAccess);
    List<ClientBranchDetailsModel> GetClientBranches(RoleAccessList roleAccess);
    string ActionTakenByChecker(ActionModel nModel);
    string DeleteTempUser(ActionModel nModel);
    string EditApprovedUser(UserFilterModel2 userModel);
}

