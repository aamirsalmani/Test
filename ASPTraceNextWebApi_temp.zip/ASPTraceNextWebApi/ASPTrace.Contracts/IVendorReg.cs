﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Contracts
{
    public interface IVendorReg
    {
        List<VendorRegModel> GetVendorReg();
        string VendorRegAdd(VendorRegDetailsModel vendorRegDetailsModel);
        List<VendorRegUpdateModel> GetVendorRegUpdateModel(VendorRegDetailsModel vendorRegDetailsModel);
        VendorRegModel GetVendorDetails(int VendorID);
        string VendorRegDelete (VendorRegDeleteModel vendorRegDeleteModel);
        List<VendorTypeModel> GetVendorType();

    }
}
