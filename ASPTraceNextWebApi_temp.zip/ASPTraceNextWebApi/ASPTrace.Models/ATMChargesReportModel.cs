﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class ATMChargesReportModel
    {
        public string TR_POSTDATE { get; set; }
        public string TR_ENDDATE { get; set; }
        public string ClientID { get; set; }
        public string TxnMode { get; set; }
    }

    public class ATMChargesReportDetailsModel
    {
        public string SR { get; set; }
        public string Date { get; set; }
        public string Txn_Type { get; set; }
        public string No_of_Txn { get; set; }
        public string Interchange_Non_Fanancial { get; set; }
        public string Interchange_Fanancial { get; set; }
        public string NonFanancialGST { get; set; }
        public string FanancialGST { get; set; }
        public string Total_Interchange { get; set; }
        public string Total_GST { get; set; }
        public string Total_Amount { get; set; }
    }
}