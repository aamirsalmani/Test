﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASPTrace.Models
{
    public class AlertConfigModel
    {
    }

    public class AlertFilterModel
    {
        public string ClientID { get; set; }
        public string AlertTypeID { get; set; }
        public string AlertSeverityID { get; set; }
        public string CreatedBy { get; set; }
    }


    public class AlertConfigDataModel
    {
        public int AlertID { get; set; }
        public int ClientID { get; set; }
        public string ClientName { get; set; } = string.Empty;
        public string AlertName { get; set; } = string.Empty;
        public int AlertTypeID { get; set; }
        public string AlertTypeName { get; set; } = string.Empty;
        public int AlertSeverityID { get; set; }
        public string AlertSeverityName { get; set; } = string.Empty;
        public string AlertChannels { get; set; } = string.Empty;
        public string HasEmailConfig { get; set; } = string.Empty;
        public string SpName { get; set; } = string.Empty;
        public int ScheduleTypeID { get; set; }
        public string ScheduleType { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string HasSmsConfig { get; set; } = string.Empty;
        public string HasEscalationConfig { get; set; } = string.Empty;
        public string CreatedBy { get; set; } = string.Empty;
        public string CreatedOn { get; set; }
    }

    public class SaveAlertConfigRequest
    {
        public string? clientID { get; set; }
        public string? alertTypeID { get; set; }
        public string? alertName { get; set; }
        public string? alertSeverityID { get; set; }
        public string? description { get; set; }
        public string? spName { get; set; }
        public string? scheduleTypeID { get; set; }

        public ScheduleConfig? scheduleConfig { get; set; }

        public List<ChannelConfig>? channels { get; set; }

        public EmailConfig? emailConfig { get; set; }

        public SmsConfig? smsConfig { get; set; }

        public bool isEscalationEnabled { get; set; }

        public List<EscalationConfig>? escalations { get; set; }

        public string? userName { get; set; }
    }

    public class ScheduleConfig
    {
        public List<string>? months { get; set; }
        public List<string>? days { get; set; }
        public List<string>? hours { get; set; }
        public List<string>? minutes { get; set; }
    }

    public class ChannelConfig
    {
        public string? channelID { get; set; }
        public string? channelName { get; set; }
    }

    public class EmailConfig
    {
        public string? recipients { get; set; }
        public string? subject { get; set; }
        public string? body { get; set; }
        public string? footer { get; set; }
    }

    public class SmsConfig
    {
        public string? recipients { get; set; }
        public string? body { get; set; }
        public string? footer { get; set; }
    }

    public class EscalationConfig
    {
        public int level { get; set; }
        public string? userID { get; set; }
        public string? delayType { get; set; }
        public string? month { get; set; }
        public string? day { get; set; }
        public string? hour { get; set; }
        public string? minute { get; set; }

        public List<ChannelConfig>? channels { get; set; }

        public EmailConfig? emailConfig { get; set; }

        public SmsConfig? smsConfig { get; set; }
    }

}
