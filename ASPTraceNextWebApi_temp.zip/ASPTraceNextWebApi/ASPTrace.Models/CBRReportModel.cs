﻿using System;
using System.Collections.Generic;
using System.Reflection.PortableExecutable;
using System.Runtime.ConstrainedExecution;
using System.Text;

namespace ASPTrace.Models
{ 
    public class CBRReportModel
    {
        public string TERMINALID { get; set; }
        public string FROMDATE { get; set; }
        public string TODATE { get; set; }
        public string Username { get; set; }
        public string Clientid { get; set; }
    }

    public class CBRMissingReportModel
    {
        public string TERMINALID { get; set; }
        public string FROMDATE { get; set; }
        public string TODATE { get; set; }
        public string ClientID { get; set; }

    }
    public class CBRMissingReportModelData
    {
        public string TERMINALID { get; set; }
        public string FROMDATE { get; set; }
        public string TODATE { get; set; }
        public string ClientID { get; set; }

    }
    public class CBRMissingDataModel
    {

        public string TERMINALID { get; set; }
        public string CBRDATE { get; set; }
        public string MachineLoading { get; set; }
        public string CBRStatus { get; set; }

    }

    public class CBRReportDetailsModel
    {
        public string TerminalID { get; set; }
        public string DateTime { get; set; }
        public string OpeningBalance { get; set; }
        public string ATMDispense { get; set; }
        public string AmountDeposit { get; set; }
        public string PhysicalCashBalance { get; set; }
        public string AmountReplenished { get; set; }
        public string AmountReturned { get; set; }
        public string ClosingBalance { get; set; }
        public string Overage { get; set; }
        public string Shortage { get; set; }
        public string GLBalance { get; set; }
        public string GLDifference { get; set; }
        public string OpeningClosingMismatch { get; set; }
        public string CBRStatus { get; set; }
    }

    public class TerminalModel
    {
        public string TerminalId { get; set; }
        public string TerminalLocation { get; set; }
        public string TerminalType { get; set; }
        public string BranchCode { get; set; }
        public string ContactNo { get; set; }

    }

    public class C3RReportModel
    {
        public string TERMINALID { get; set; }
        public string ClientID { get; set; }
        public string FROMDATE { get; set; }
        public string TODATE { get; set; }
    }

    public class C3RReportDetailsModel
    {
        public string TERMINALID { get; set; }
        public string TR_TIMESTAMP { get; set; }
        public string DateTime { get; set; }
        public string MSP { get; set; }
        public string FeederBranchAC { get; set; }
        public string FeederBranchName { get; set; }
        public string TotalOpeningBalance { get; set; }
        public string TotalDispensed { get; set; }
        public string TotalBalancebeforeEOD { get; set; }
        public string TotalCashReplenishLoading { get; set; }
        public string TotalCashbroughtBackUnloading { get; set; }
        public string TotalBalanceafterEOD { get; set; }
        public string TotalOverage { get; set; }
        public string TotalShortage { get; set; }
        public string TotalSwitchBalanceBeforeReplenish { get; set; }
        public string TotalSwitchBalanceAfterReplenish { get; set; }
        public string REMARKS { get; set; }
    }

    public class CBRDifferenceReportModel
    {
        public string TERMINALID { get; set; }
        public DateTime TR_TIMESTAMP { get; set; }
        public decimal Machine_OPBALANCE { get; set; }
        public decimal Machine_LOADING { get; set; }
        public decimal Machine_DISPENSE { get; set; }
        public decimal Machine_REMANING { get; set; }
        public decimal Machine_CLOSING { get; set; }
        public decimal Diffrence { get; set; }
        public string CreatedBy { get; set; }

    }

    public class CBRReportDetailsNewModel
    {
        public string ClientID { get; set; }
        public string TR_TIMESTAMP { get; set; }
        public string CIT { get; set; }
        public string TerminalID { get; set; }
        public string Bank { get; set; }
        public string ATMLOCATION { get; set; }
        public string REMARK { get; set; }
        public string Deno { get; set; }
        public decimal Machine_OPBALANCE { get; set; }
        public decimal Machine_DISPENSE { get; set; }
        public decimal Machine_REMANING { get; set; }
        public decimal Machine_LOADING { get; set; }
        public decimal Machine_CLOSING { get; set; }
        public decimal Machine_DIVERTED { get; set; }
        public decimal Cash_REMOVED { get; set; }
        public decimal Physical_CASSETTE { get; set; }
        public decimal Physical_REMANING { get; set; }
        public decimal Physical_LOADING { get; set; }
        public decimal Physical_CLOSING { get; set; }
        public decimal Switch_OPBALANCE { get; set; }
        public decimal Switch_DISPENSE { get; set; }
        public decimal Switch_REMANING { get; set; }
        public decimal Switch_LOADING { get; set; }
        public decimal Switch_CLOSING { get; set; }
        public decimal Switch_INCREASE { get; set; }
        public decimal Switch_DECREASE { get; set; }
        public decimal CashLoadSettledAmount { get; set; }
        public decimal OVGSettledAmount { get; set; }
        public decimal SHTGSettledAmount { get; set; }
        public decimal OVG { get; set; }
        public decimal SHTG { get; set; }
        public decimal PURGE_BIN { get; set; }
        public decimal CASH_DUMP { get; set; }
        public string CASHFILLNO { get; set; }
        public decimal Prev_Closing { get; set; }
        public string STATUS { get; set; }
        public string EOD { get; set; }
        public string FileName { get; set; }
    }
        public class PreviousClosingModel
    {
        public string Atmopening50 { get; set; }
        public string Atmopening100 { get; set; }
        public string Atmopening500 { get; set; }
        public string Atmopening1000 { get; set; }
        public string Previousdate { get; set; }
        public string NextDate { get; set; }
        public string MaxDate { get; set; }
        public string PreviousPHYSICALBALANCE { get; set; }
        public string EJDispense { get; set; }
        public string PreviousDateTime { get; set; }
        public string NextDateTime { get; set; }
        public string AtmopeningTotal { get; set; }

    }

    public class CBRCounterModel
    {
        public string TerminalId { get; set; }
        public string TR_TIMESTAMP { get; set; }
        public string Branchlocation { get; set; }
        public string Atmopeningbalance50 { get; set; }
        public string Atmopeningbalance100 { get; set; }
        public string Atmopeningbalance500 { get; set; }
        public string Atmopeningbalance1000 { get; set; }
        public string Atmdispensecounter50 { get; set; }
        public string Atmdispensecounter100 { get; set; }
        public string Atmdispensecounter500 { get; set; }
        public string Atmdispensecounter1000 { get; set; }
        public string Atmremaingcounter50 { get; set; }
        public string Atmremaingcounter100 { get; set; }
        public string Atmremaingcounter500 { get; set; }
        public string Atmremaingcounter1000 { get; set; }
        public string Atmdivertcounter50 { get; set; }
        public string Atmdivertcounter100 { get; set; }
        public string Atmdivertcounter500 { get; set; }
        public string Atmdivertcounter1000 { get; set; }
        public string Amountreplenished50 { get; set; }
        public string Amountreplenished100 { get; set; }
        public string Amountreplenished500 { get; set; }
        public string Amountreplenished1000 { get; set; }
        public string Amountreturned50 { get; set; }
        public string Amountreturned100 { get; set; }
        public string Amountreturned500 { get; set; }
        public string Amountreturned1000 { get; set; }
        public string Newbalperatmcounters50 { get; set; }
        public string Newbalperatmcounters100 { get; set; }
        public string Newbalperatmcounters500 { get; set; }
        public string Newbalperatmcounters1000 { get; set; }
        public string Cashincassettes50 { get; set; }
        public string Cashincassettes100 { get; set; }
        public string Cashincassettes500 { get; set; }
        public string Cashincassettes1000 { get; set; }
        public string CASHFROMPURGEBIN50 { get; set; }
        public string CASHFROMPURGEBIN100 { get; set; }
        public string CASHFROMPURGEBIN500 { get; set; }
        public string CASHFROMPURGEBIN1000 { get; set; }
        public string ClosingCounter50 { get; set; }
        public string ClosingCounter100 { get; set; }
        public string ClosingCounter500 { get; set; }
        public string ClosingCounter1000 { get; set; }
        public string Glamount { get; set; }
        public string Switchopeningbal50 { get; set; }
        public string Switchopeningbal100 { get; set; }
        public string Switchopeningbal500 { get; set; }
        public string Switchopeningbal1000 { get; set; }
        public string Switchdispensebal50 { get; set; }
        public string Switchdispensebal100 { get; set; }
        public string Switchdispensebal500 { get; set; }
        public string Switchdispensebal1000 { get; set; }
        public string UserName { get; set; }
        public string Atmdepositcounter50 { get; set; }
        public string Atmdepositcounter100 { get; set; }
        public string Atmdepositcounter500 { get; set; }
        public string Atmdepositcounter1000 { get; set; }
        public string Switchdepositcounter50 { get; set; }
        public string Switchdepositcounter100 { get; set; }
        public string Switchdepositcounter500 { get; set; }
        public string Switchdepositcounter1000 { get; set; }

        public string Switchremainingcounter50 { get; set; }
        public string Switchremainingcounter100 { get; set; }
        public string Switchremainingcounter500 { get; set; }
        public string Switchremainingcounter1000 { get; set; }

        public string CDamount { get; set; }
        public string ClientCode { get; set; }
    }

    public class CBRDataModel
    {
        public string TR_TIMESTAMP { get; set; }
        public string BANK { get; set; }
        public string TERMINALID { get; set; }
        public string BRANCH { get; set; }
        public string BRANCHLOCATION { get; set; }
        public string ATMPREVIOUSBALANCE { get; set; }
        public string ATMDISPANSECOUNTER { get; set; }
        public string ATMREMAINGCOUNTER { get; set; }
        public string ATMDIVERTCOUNTER { get; set; }
        public string AMOUNTREPLENISHED { get; set; }
        public string AMOUNTRETURNED { get; set; }
        public string NEWBALPERATMCOUNTERS { get; set; }
        public string CASHINCASSETTES { get; set; }
        public string CASHFROMPURGEBIN { get; set; }
        public string TOTALCASHINATM { get; set; }
        public string PHYSICALBALANCE { get; set; }
        public string GLAMOUNT { get; set; }
        public string SWITCHOPENINGBAL { get; set; }
        public string SWITCHDISPENSEBAL { get; set; }
        public string SWITCHCLOSINGBAL { get; set; }
        public string GLANDPHYSICALCASHDIFF { get; set; }
        public string OVERAGE { get; set; }
        public string SHORTAGE { get; set; }
        public string STATUS { get; set; }
        public string UserName { get; set; }
        public string Atmdepositcounter { get; set; }
        public string Switchdepositcounter { get; set; }
        public string CDAMOUNT { get; set; }
        public string GLANDCDCASHDIFF { get; set; }
        public string ATMANDPHYSICALCOUNTERSTATUS { get; set; }
        public string ISMANUALEntry { get; set; }
        public string ClientCode { get; set; }
    }
}