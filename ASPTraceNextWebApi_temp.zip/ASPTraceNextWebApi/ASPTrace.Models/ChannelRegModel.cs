﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public  class ChannelRegModel
    {
        public int ChannelID { get; set; }
        public string ChannelName { get; set; }
    }


    public class ChannelRegDetailsModel
    {
        public string ChannelName { get; set; }
        public string ChannelID { get; set; }
        public string Mode { get; set; }
        public string CreatedBy { get; set; }
 
    }

    public class GetChannelDetails
    {
        public string ChannelID { get; set; }
        public string ChannelName { get; set; }
        
    }

    public class ChannelRegUpdateDetails
    {
        public long ChannelID { get; set; } // Assuming ChannelID is a long in your stored procedure
        public string ChannelName { get; set; }
        public int IsRemove { get; set; } // Assuming IsRemove is a boolean in your stored procedure
        public string CreatedBy { get; set; }
    }
    public class DeleteChannelDetails
    {
        public string Mode { get; set; }
        public string ChannelID { get; set; }

    }

}
