﻿using System;

namespace ASPTrace.Models
{
    public class Class1
    {
    }
}
