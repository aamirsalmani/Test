﻿namespace ASPTrace.Models;

#nullable disable warnings

public class ClientRegModel
{
    public string ClientID { get; set; }
    public string DomainID { get; set; }
    public string ModuleID { get; set; }
}

public class ClientDetails
{
    public string BankID { get; set; }
    public string ClientID { get; set; }
    public string ClientName { get; set; }
}

public class ClientCountry
{
    public string ID { get; set; }
    public string Country { get; set; }
}

public class ClientCurrency
{
    public string CountryID { get; set; }
    public string CurrencyID { get; set; }
    public string CurrencyCode { get; set; }
    public string IsRemoved { get; set; }
}
public class ClientDomain
{
    public string DomainID { get; set; }
    public string DomainType { get; set; }
    public string IsRemoved { get; set; }
}
public class ClientModule
{
    public string ModuleID { get; set; }
    public string ModuleType { get; set; }
    public string IsRemoved { get; set; }
}

public class ClientChannel
{
    public string ChannelID { get; set; }
    public string ChannelName { get; set; }
    public string IsRemoved { get; set; }
}
public class ClientConfig
{
    public string ClientID { get; set; }
    public string Mode { get; set; }
    public string DomainID { get; set; }
    public string ModuleID { get; set; }
    public string ClientCode { get; set; }
    public string ClientName { get; set; }
    public string Address { get; set; }
    public string ContactNo { get; set; }
    public string EmailID { get; set; }
    public string ConcernPerson { get; set; }
    public string CPEmailID { get; set; }
    public string CPContactNo { get; set; }
    public string IsBank { get; set; }
    public string IsActive { get; set; }
    public string CountryID { get; set; }
    public string CurrencyID { get; set; }
    public string FTP_IP { get; set; }
    public string FTPUserName { get; set; }
    public string FTPPassword { get; set; }
    public string FTPPort { get; set; }
    public string ClientLogo { get; set; }
    public string UserLimit { get; set; }
    public string TerminalCount { get; set; }
    public string ReportTime { get; set; }
    public string UserName { get; set; }
    public string Colorcode { get; set; }
    public string ClientChannelModes { get; set; }
    public Microsoft.AspNetCore.Http.IFormFile? ClientLogoFile { get; set; }
}

public class ClientTest
{
    public string ClientID { get; set; }
}

public class ClientConfigMaster
{
    public string ClientID { get; set; }
    public string Mode { get; set; }
    public string DomainID { get; set; }
    public string ModuleID { get; set; }
    public string ClientCode { get; set; }
    public string ClientName { get; set; }
    public string Address { get; set; }
    public string ContactNo { get; set; }
    public string EmailID { get; set; }
    public string ConcernPerson { get; set; }
    public string CPEmailID { get; set; }
    public string CPContactNo { get; set; }
    public bool IsBank { get; set; }
    public bool IsActive { get; set; }
    public string CountryID { get; set; }
    public string CurrencyID { get; set; }
    public string FTP_IP { get; set; }
    public string FTPUserName { get; set; }
    public string FTPPassword { get; set; }
    public string FTPPort { get; set; }
    public string ClientLogo { get; set; }
    public string UserLimit { get; set; }
    public string TerminalCount { get; set; }
    public string ReportCutoffTime { get; set; }
    public string UserName { get; set; }
    public string Colorcode { get; set; }
    public string Createdby { get; set; }
    public string Country { get; set; }
    public string CurrencyCode { get; set; }
    public string DomainType { get; set; }
    public string ModuleType { get; set; }
}

public class ClientChannelModeDetails
{
    public string ChannelID { get; set; }
    public string ChannelName { get; set; }
    public string ModeID { get; set; }
    public string ClientCode { get; set; }
    public string CreatedBy { get; set; }
}

public class ChannelData
{
    public string ChannelID { get; set; }
    public string ChannelName { get; set; }
}

public class ClientChannelDetails
{
    public string channelID { get; set; }
    public string channelName { get; set; }
    public bool onus { get; set; }
    public bool acquirer { get; set; }
    public bool issuer { get; set; }
    public string CreatedBy { get; set; }
}

public class ClientLogoDetails
{
    public string TraceLogo { get; set; }
    public string ClientLogo { get; set; }
    public string ClientName { get; set; }
}
#nullable restore