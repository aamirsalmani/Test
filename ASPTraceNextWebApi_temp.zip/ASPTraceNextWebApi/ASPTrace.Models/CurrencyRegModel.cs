﻿namespace ASPTrace.Models ;

#nullable disable warnings
    public class ClientCurrencyRegModel
    {
        public string Isremoved { get; set; }
        public string CountryID { get; set; }
        public string CurrencyCode { get; set; }
        public string CurrencyID { get; set; }

    }
    public class CurrencyRegModel
    {
        public string Mode { get; set; }
        public string CurrencyID { get; set; }
        public string CurrencyCode { get; set; }
        public string CurrencyDescription { get; set; }
        public string CountryID { get; set; }
        public string CountryName { get; set; }
        public string NumericCode { get; set; }
        public string CreatedBy { get; set; }
        // public string Country { get; set; }
        public string Scale { get; set; }

    }

    public class DeleteCurrencyRegModel
    {
        public string Mode { get; set; }
        public string CurrencyID { get; set; }
    }
#nullable restore

 