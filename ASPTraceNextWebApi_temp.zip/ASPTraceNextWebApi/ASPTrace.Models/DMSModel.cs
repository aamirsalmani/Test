using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Numerics;
using System.Text;

namespace ASPTrace.Models
{
    //Unmatched Report
    public class UnmatchedTxnsModel
    {
        public string ClientID { get; set; }
        public string ClientCode { get; set; }
        public string UserName { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TerminalID { get; set; }
        public string TxnType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReferenceNumber { get; set; }
    }

    public class UnmatchedTxnsReportModel
    {
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string CustAccountNo { get; set; }
        public string TxnsAmount { get; set; }
        public string EJStatus { get; set; }
        public string SWStatus { get; set; }
        public string NWStatus { get; set; }
        public string GLStatus { get; set; }
        public string TxnsSubType { get; set; }
        public string Remark { get; set; }
        public string PStatus { get; set; }
    }

    public class UnmatchedTxnDetailsModel
    {
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string TxnsAmount { get; set; }
        public string ResponseCode { get; set; }
        public string ReversalFlag { get; set; }
        public string EJStatus { get; set; }
    }

    public class UnmatchedTxnByReferenceNumber
    {
        public List<UnmatchedTxnDetailsModel> EJTxnDetails { get; set; }
        public List<UnmatchedTxnDetailsModel> GLTxnDetails { get; set; }
        public List<UnmatchedTxnDetailsModel> NWTxnDetails { get; set; }
        public List<UnmatchedTxnDetailsModel> SWTxnDetails { get; set; }
    }



    //Dispute Tracking Report


    public class AdjustmentTerminalDetailsModel
    {
        public string UserName { get; set; }
        public string ClientID { get; set; }
        public string ID { get; set; }
        public string TERMINALID { get; set; }

    }

    public class AdjustmentModeModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ModeName { get; set; }
    }

    public class AdjustmentTxnsModel1
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string NetworkType { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        public string TxnDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string Type { get; set; }

    }

    public class AdjustmentTxnsIputModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string NetworkType { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }

    }

    public class AdjustmentTxnsReferenceNumberModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string NetworkType { get; set; }
        public string TxnDateTime { get; set; }
        public string ReferenceNumber { get; set; }

    }

    public class AdjustmentTxnsNPCIModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string NetworkType { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        public string Type { get; set; }


    }



    public class DisputeModel
    {
        public string DisputeID { get; set; }
        public string TxnDateTime { get; set; }
        public string ReferenceNumber { get; set; }

    }
    public class BulkDisputeRaiseModel
    { 
        public string DisputeID { get; set; }
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string? TerminalID { get; set; }
        public string ReferenceNumber { get; set; }
        public string? AuthCode { get; set; }
        public string? ResponseCode { get; set; }
        public string? CardNumber { get; set; }
        public string? FromAccount { get; set; }
        public string? ToAccount { get; set; }
        public string TxnsDateTime { get; set; }
        public decimal TxnsAmount { get; set; }
        public string? ReasonCode { get; set; }
        public string? ReasonDescription { get; set; }
        public string AdjType { get; set; }
        public decimal DisputeAmount { get; set; }
        public string? ContactNo { get; set; }
        public string DisputeDate { get; set; }
        public string UserID { get; set; }
        public string? Status { get; set; }
        public bool IsChecker { get; set; }
    }

    public class SubmitRemarksModel
    {
        public string DisputeID { get; set; }
        public string TxnDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public DisputeStatus CheckerStatus { get; set; }
        public DisputeStatus MakerStatus { get; set; }
    }
    public class DisputeStatus
    {
        public string? Remark { get; set; }
        public string? Status { get; set; }
    }
    public class AttachmentModel
    {
        public int ID { get; set; }
        public string DisputeID { get; set; }
        public string DisputeType { get; set; }
        public string ReferenceNumber { get; set; }
        public string TxnsDateTime { get; set; }
        public string FileName { get; set; }
        public string FileSize { get; set; }
        public string FileType { get; set; }
        public string? Attachment { get; set; }
        public string ContentType { get; set; }
    }
    public class AdjustmentTxnsReportModel
    {
        public string CurrentDate { get; set; }
        public string ExpiryDate { get; set; }
        public string RemainingDays { get; set; }
        public string AdjDate { get; set; }
        public string TAT { get; set; }
        public string AdjType { get; set; }
        public string FutureActions { get; set; }
        public string MakerAction { get; set; }
        public string MakerRemarks { get; set; }
        public string CheckerAction { get; set; }
        public string CheckerRemarks { get; set; }
        //public string MakerActionDate { get; set; }
        //public string CheckerActionDate { get; set; }
        public string DisputeID { get; set; }
        public string TxnUID { get; set; }
        //public string UID { get; set; }
        public string Remitter { get; set; }
        public string Beneficiery { get; set; }
        public string ResponseCode { get; set; }
        public DateTime TxnDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string TerminalID { get; set; }
        //public string Ben_Mobile_No { get; set; }
        //public string Rem_Mobile_No { get; set; }
        public decimal TxnAmount { get; set; }
        public decimal AdjAmount { get; set; }
        //public string AdjRef { get; set; }
        //public string BankAdjRef { get; set; }
        public string GLStatus { get; set; }
        public string GLResponseCode { get; set; }
        public string SWStatus { get; set; }
        public string SWResponseCode { get; set; }
        public string NWStatus { get; set; }
        public string NWResponseCode { get; set; }
        public string Remarks { get; set; }
        //public string TxnTime { get; set; }
        public string ChargebackDate { get; set; }
        public string Chbref { get; set; }
        public string ReasonCode { get; set; }
        public string Cycle { get; set; }
        public string IsSettled { get; set; }
        public string SettledOn { get; set; }
        public string SettledRemarks { get; set; }
        public string SettledBy { get; set; }
        public string CardNo { get; set; }
        //public DateTime FileDate { get; set; }
        //public string FileName { get; set; }
        //public string FilePath { get; set; }
    }
    public class OptionsModel
    {
        public string value { get; set; }
        public string label { get; set; }

    }
    public class DisputeUpload
    {
        public string DisputeID { get; set; }
        public string ReferenceNumber { get; set; }
        public string TxnsDateTime { get; set; }
        public IFormFile Attachment { get; set; }

    }
    public class DisputeAttachment
    {
        public string DisputeID { get; set; }
        public int DisputeType { get; set; }
        public string ReferenceNumber { get; set; }
        public DateTime? TxnsDateTime { get; set; }
        public string FileName { get; set; }
        public string FileSize { get; set; }
        public string FileType { get; set; }
        public string UploadedBy { get; set; }
        public DateTime? UploadedDate { get; set; }
        public byte[] Attachment { get; set; }
        public string FileDescription { get; set; }
        public bool IsRemoved { get; set; } = false;
        public string FilePath { get; set; }
        public string FileTypeId { get; set; }
        public string IsProcess { get; set; }
        public string DeletedBy { get; set; }
        public DateTime? DeletedDate { get; set; }
    }


    //Dispute Tracking NPCI 

    public class DisputeDetails
    {
        public string BankAdjRef { get; set; }
        public string Flag { get; set; }
        public DateTime Shdate { get; set; }  // Adjust the type if TxnsDateTime is not a DateTime
        public decimal AdjustmentAmount { get; set; }
        public string ReferenceNumber { get; set; }
        public string Sncrd { get; set; }
        public string FileName { get; set; }
        public string ReasonCode { get; set; }
        public string SpecifyOther { get; set; } = null;

    }
    public class DisputeReportModel
    {
        public string ClientID { get; set; }
        public string ChannelType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }




    public class NPCIDISPUTETRACKINGBulkModel
    {
        public string Bankadjref { get; set; }
        public string Flag { get; set; }
        public DateTime shtdat { get; set; }
        public decimal adjamt { get; set; }
        public string shser { get; set; }
        public string Sncrd { get; set; }
        public string filename { get; set; }
        public string Reason { get; set; }
        public string SpecifyOther { get; set; } = string.Empty;
    }


    //----------------------------------------------------------------- Advait Nair ---------------------------------------------------------------------------------------

    public class GetDisputeRaiseDataModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string? ReferenceNumber { get; set; }
        public string? FromAccount { get; set; }
        public string? TxnsAmount { get; set; }
        public string ToDate { get; set; }
        public string FromDate { get; set; }

    }


    public class GetDisputeRaiseListModel
    {
        public string DisputeID { get; set; }
        public string TxnID { get; set; }
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReferenceNumber { get; set; }
        public string FromAccount { get; set; }
        public string TxnsAmount { get; set; }
        public string TxnsDateTime { get; set; }
        public string ResponseCode { get; set; }
        public string Status { get; set; }
        public string ReasonCode { get; set; }
        public string AdjType { get; set; }
        public string DisputeAmount { get; set; }
        public string ContactNo { get; set; }
        public string DisputeDate { get; set; }
        public string UserID { get; set; }
        public bool IsChecker { get; set; }
    }

}
