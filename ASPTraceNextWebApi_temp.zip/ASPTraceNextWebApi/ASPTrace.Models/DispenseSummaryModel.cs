﻿
namespace ASPTrace.Models
{

    public class ConsoleSetModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }

        public string Cycle { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        //public string TxnType { get; set; }
    }

    public class SwitchFeeModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }

        public string FromDateTxns { get; set; }
        //public string TxnType { get; set; }
    }

    public class DispenseSummaryModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TERMINALID { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        //public string TxnType { get; set; }
    }
    public class InsertDispenseSummaryModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TERMINALID { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        public string UserName { get; set; }
    }

    public class GetDispenseSummaryJob
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
    }

    public class DispenseSummaryJobGridModel
    {
        public string ClientName { get; set; }
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string Status { get; set; }
    }


    public class DispenseSummaryDetailsModel
    {
        public string TxnDate { get; set; }
        public string TerminalID { get; set; }
        public string GLONUS { get; set; }
        public string GLAcquirer { get; set; }
        public string GLISS { get; set; }
        public string GLTotal { get; set; }
        public string SWISS { get; set; }
        public string SWAcquirer { get; set; }
        public string SwitchTotal { get; set; }
        public string EJ { get; set; }
        public string NFSAcquirer { get; set; }
        public string NFSIssuer { get; set; }
        public string NFSAcquirerDiff { get; set; }
        public string NFSIssuerDiff { get; set; }
        public string ATMDiff { get; set; }
        public string UnSettledAmount { get; set; }
    }
}
