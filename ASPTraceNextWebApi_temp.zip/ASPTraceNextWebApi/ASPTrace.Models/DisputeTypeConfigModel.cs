﻿
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class DisputeTypeConfigModel
    {


    }

 
    public class GetDisputeTypeConfigModel
    {
    public int ClientID { get; set; }
    public int ChannelID { get; set; }
    public int ModeID { get; set; }
   

    }
   
  
    public class GetDisputeTypeconfiglist
    {
        public string ClientName { get; set; }
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; } 
        public string AdjustmentType { get; set; }
        public string flag { get; set; }
        public string reasonCode { get; set; }
        public string TAT { get; set; }
        public string disputeOrder { get; set; }
        public string IsAquirerAction { get; set; }


    }
    public class EditDisputeTypeConfigModel
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public string AdjustmentType { get; set; }
        public string flag { get; set; }
        public string ReasonCode { get; set; }
        public string TAT { get; set; }
        public string DisputeOrder { get; set; }
        public string IsAquirerAction { get; set; }

    }

    public class AddNewDisputeTypeConfigModel
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public string AdjustmentType { get; set; }
        public string flag { get; set; }
        public string ReasonCode { get; set; }
        public string TAT { get; set; }
        public string DisputeOrder { get; set; }
        public string IsAquirerAction { get; set; }

    }
    public class DeleteDisputeTypeConfigModel
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public string AdjustmentType { get; set; }
        public string flag { get; set; }
        public string ReasonCode { get; set; }
        public string TAT { get; set; }
        public string DisputeOrder { get; set; }
        public string IsAquirerAction { get; set; }

    }



}
