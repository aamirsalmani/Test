﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class DynamicFileConfigModel
    {
        public string ClientID { get; set; }
        public string UserName { get; set; }
        public string LogTypeID { get; set; }
        public string VendorID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string NetworkType { get; set; }

    }

    public class DynamicModeFileConfigModel
    {
        public string ModeID { get; set; }
        public string ModeName { get; set; }
    }
    public class DynamicFileIDModel
    {
        public string FileID { get; set; }
        public string LogType { get; set; }
    }
    public class DynamicNetworkTypeIDModel
    {
        public string ID { get; set; }
        public string NetworkName { get; set; }
    }



    public class DynamicFileConfigGrid
    {
        public string ClientID { get; set; }
        public string VendorID { get; set; }
        public string LogTypeID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string VendorName { get; set; }
        public string LogType { get; set; }
        public string NetworkType { get; set; }
        public string TransactionMode { get; set; }
        public string ChannelName { get; set; }
        public string ClientName { get; set; }
        public string ReconStatus { get; set; }
        public string TableName { get; set; }
        public string ConfigID { get; set; }
    }

    public class DynamicFileUploadModel
    {
        public string ConfigID { get; set; }
        public string TableName { get; set; }
        public string FileType { get; set; }
        public string? Separator { get; set; }
        public Microsoft.AspNetCore.Http.IFormFile ImportFile { get; set; }
        public string UserName { get; set; }
    }

    public class DynamicImportFileStatus
    {
        public string MSG { get; set; }
        public string Type { get; set; }
        public string FileConfigID { get; set; }
    }


    public class DynamicImportFileConfigModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ConfigID { get; set; }
        public string TableName { get; set; }
        public string VendorID { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string FileType { get; set; }
        public string FileSeparator { get; set; }
        public string OriginalFileName { get; set; }
        public string ConnectionString { get; set; }
        public string UserName { get; set; }
    }

    public class ConfiguredColumnJsonString
    {
        public string FileConfigID { get; set; }
        public string ConfiguredXMLColumnString { get; set; }
        public string ConfiguredRawColumnString { get; set; }
    }

    public class DynamicFileMappedColumn
    {
        public string FileConfigID { get; set; }
        public string MappedColumnString { get; set; }
    }

    public class DynamicFileXMLModel
    {
        public string FileConfigID { get; set; }
        public string XMLString { get; set; }
        public string QueryString { get; set; }
        public string RawColumnString { get; set; }
        public string MappedColumnString { get; set; }
    }

    public class DynamicFileConfigDataModel
    {
        public string ChannelName { get; set; }
        public string TableName { get; set; }
        public string TransactionMode { get; set; }
        public string VendorType { get; set; }
        public string VendorName { get; set; }
        public string FileType { get; set; }
        public string SplitterType { get; set; }
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string OriginalFileName { get; set; }
        public string ClientName { get; set; }
    }
    public class DynamicFileMappedColumnModel
    {
        public string FileColumn { get; set; }
        public string DataValue { get; set; }
        public string MappedColumn { get; set; }
        public string Position { get; set; }
        public string ColumnID { get; set; }
    }

    public class DynamicFilePlaintextMappedColumnModel
    {
        public string FileColumn { get; set; }
        public string DataValue { get; set; }
        public string MappedColumn { get; set; }
        public string StartPosition { get; set; }
        public string ColumnID { get; set; }
        public string TxtLength { get; set; }

    }

    public class DateTimeFormat
    {
        public string TxnDateTimeDateFormat { get; set; }
        public string TxnValueDateTimeDateFormat { get; set; }
        public string TxnPostDateTimeDateFormat { get; set; }
        public string FileDateFormat { get; set; }
        public string FileNameContains { get; set; }
        public string AllowedExtensions { get; set; }
        
        public string? SFTPPath { get; set; }
        public string? FileName { get; set; }

        public string? StartPosition { get; set; }
        public string? EndPosition { get; set; }
        public string DecimalNumber { get; set; } 
        public string TableName { get; set; }
        public string FileConfigID { get; set; }
    }

    public class XMLColumnModel
    {
        public int ColumnID { get; set; }
        public string AliasColumn { get; set; }
        public string ColumnValue { get; set; }
        public string DataColumn { get; set; }
        public string Position { get; set; }
        public string Length { get; set; }
        public string CaseCondition { get; set; }
        public bool IsChanged { get; set; }
    }

    public class DynamicChannelConfigModel
    {
        public string ConfigID { get; set; }
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ChannelName { get; set; }
        public string ClientName { get; set; }
        public string SelectedModes { get; set; }

    }

    public class DeleteChannelConfigModel
    {
        public string ConfigID { get; set; }
    }

    public class DynamicChannelModeConfigModel
    {
        public string ClientID { get; set; } 
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string UserName { get; set; }

    }

    public class DynamicFileContentModel
    {
        public string ConfigID { get; set; }
        public string FileColumnString { get; set; }
        public string FirstRow { get; set; }
        public string SecondRow { get; set; }
        public string ThirdRow { get; set; }
        public string FourthRow { get; set; }
        public string FifthRow { get; set; }
        public string UserName { get; set; }
    }

    public class tempDynamicFileConfigModel
    {
        public string ClientID { get; set; }
        public string UserName { get; set; }
        public string LogTypeID { get; set; }
        public string VendorID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string NetworkType { get; set; }
        public string ClientIDToCopy { get; set; }
    }
}
