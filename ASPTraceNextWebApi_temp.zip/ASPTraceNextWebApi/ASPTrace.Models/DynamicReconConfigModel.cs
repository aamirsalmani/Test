﻿using System;
using System.Collections.Generic;
using System.Text;
using ASPTrace.Models;

namespace ASPTrace.Models
{
    

    public class OptionsListModel
    {
        public string value { get; set; }
        public string label { get; set; }
    }

    public class SelectedColumn
    {
        public int RowID { get; set; }
        public OptionsListModel Value { get; set; }
    }

    public class JoinTableModel
    {
        public int ID { get; set; }
        public OptionsListModel SelectedTable { get; set; }
        public OptionsListModel SelectedJoin { get; set; }
        public object DdlOptions { get; set; }
        public List<SelectedColumn> SelectedColumns { get; set; }
        public int IsMultiTable { get; set; }
    }
    public class JoinTablesWrapper
    {
        public ReconQueryFields Clientdetails { get; set; }
        public List<JoinTableModel> JoinTables { get; set; }
    }
    public class CaseConfigOptions
    {
        public List<OptionsArray> Options { get; set; }
        public List<OptionsArray> Condition { get; set; }

    }
        public class TableInfo
    {
        public int ID { get; set; }
        public OptionsListModel TableName { get; set; }
        public List<OptionsArray> Options { get; set; }
    }
    public class CaseDataModel
    {
        public List<AliasReconColumnsModel> AliasColumnsData { get; set; }
        public List<TableInfo> TableInfoData { get; set; }


    }


    public class OptionsArray
    {
        public string value { get; set; }
        public string label { get; set; }

    }
    public class UnmatchedColumnsModel
    {
        public int ID { get; set; }
        public string AliasColumn { get; set; }
        public string CaseStatement { get; set; }
    }
    public class AliasReconColumnsModel
    {
        public int ID { get; set; }
        public string AliasColumn { get; set; }
        public OptionsArray TableAlias { get; set; }
        public OptionsArray DataColumn { get; set; }
        public string CaseStatement { get; set; }
        public ActionsMenu ActionsMenu { get; set; }
    }



    public class ActionsMenu
    {
        public bool Edit { get; set; }
        public bool Delete { get; set; }
    }
    public class FormValues
    {
        public int ClientID { get; set; }
        public int NetworkType { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public string Form { get; set; }
    }
    public class CaseTableForm
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReconType { get; set; }

        public TableDetails Table { get; set; }

        public string ConfigData { get; set; }
        public string UserName { get; set; }
    }

    public class TempDataJSON
    {
        public int TableNo { get; set; }
        public string TableName { get; set; }
        public string Query { get; set; }
        public bool isMultiTable { get; set; }
        public string MultiTableJOIN { get; set; }
        public string WHERE { get; set; }
    }

    public class QueryFormJSON
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public int ReconType { get; set; }
        public List<TempDataJSON> TempData { get; set; }
    }



}


