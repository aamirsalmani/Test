﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{    
    public class Status
    {
        public bool IsActive { get; set; }
        public bool IsComplete { get; set; }
    }

    public class Option
    {
        public int value { get; set; }
        public string label { get; set; }
    }

    public class Column
    {
        public string value { get; set; }
        public string label { get; set; }
    }

    public class Operation
    {
        public Option Option { get; set; }
        public string OperationValue { get; set; }
    }

    public class Condition
    {
        public string value { get; set; }
        public string label { get; set; }
    }

    public class Boolean
    {
        public string value { get; set; }
        public string label { get; set; }
    }

    public class Conditions
    {
        public Column Column { get; set; }
        public Operation Operation { get; set; }
        public Condition Condition { get; set; }
        public string Value { get; set; }
        public Boolean boolean { get; set; }
    }

    public class MergeTable
    {
        public int ID { get; set; }
        public string AliasColumn { get; set; }
        public string CaseStatement { get; set; }
    }

    public class TableName
    {
        public int value { get; set; }
        public string label { get; set; }
    }

    public class MainJoinForm
    {
        public Status Status { get; set; }
        public TableName OrderNo { get; set; }
        public TableName TableName { get; set; }
        public string JoinColumns { get; set; }
        public List<Conditions> conditions { get; set; }
        public List<MergeTable> MergeTable { get; set; }
    }

    public class UnmatchedTable
    {
        public int ID { get; set; }
        public string AliasColumn { get; set; }
        public string CaseStatement { get; set; }
    }

    public class RootObject
    {
        public List<object> TabsFormData { get; set; }
        public List<MainJoinForm> MainJoinForm { get; set; }
        public List<UnmatchedTable> UnmatchedTable { get; set; }
    }

    public class TablesQuery
    {
        public int OrderNo { get; set; }
        public string TableName { get; set; }
        public string JOIN { get; set; } // Note: JOIN is a reserved keyword in some SQL dialects, consider renaming this property
        public string Query { get; set; }
    }
}
