﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
   public class DynamicReconModel
    {
        public string ClientID { get; set; }
        public int ChannelID { get; set; }
        public string ChannelName { get; set; }
    }
  
    public class ModeDynamicReconModel
    {
        public string ClientID { get; set; }
        public int ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ModeName { get; set; }
    }

    public class RunReconHistoryDynamicReconModel
    {
        public string ClientID { get; set; }
        public string ClientName { get; set; }
        public string Fromdate { get; set; }
        public string Todate { get; set; }
        public string Channel { get; set; }
        public string Mode { get; set; }
        public string Status { get; set; }
        public string Createdby { get; set; }
        public string CreatedDate { get; set; }
    }

    public class ReconStatusDynamicReconModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string Mode { get; set; }
        public string User { get; set; }
    }

    public class RunReconAddDynamicReconModel
    {
        public string ClientID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public int ChannelID { get; set; }
        public string Mode { get; set; }
        public string Status { get; set; }
        public string Createdby { get; set; }
        public string CreatedOn { get; set; }
    }
}
