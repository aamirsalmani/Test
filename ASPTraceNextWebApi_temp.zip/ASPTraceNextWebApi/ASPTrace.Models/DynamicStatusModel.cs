﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class DynamicStatusModel
    { }

    public class FormDataModel
    {
        public IFormFile file { get; set; }
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReconType { get; set; }
    }
    public class GetStatusModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReconType { get; set; }
        public string EJFilter { get; set; }
        public string GLFilter { get; set; }
        public string SWFilter { get; set; }
        public string NWFilter { get; set; }

    }
    public class DefaultStatusModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReconType { get; set; }

    }

    public class GetFileStatusModel
    {
        public string StatusID { get; set; }
        public string StatusName { get; set; }
    }
    public class GetStatusModelData
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReconType { get; set; }
        public string EJStatus { get; set; }
        public string GLStatus { get; set; }
        public string SwitchStatus { get; set; }
        public string NetworkStatus { get; set; }
        public string Remarks { get; set; }
        public string SettledRemarks { get; set; }
        public string UserName { get; set; }

    }
}
