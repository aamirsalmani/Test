﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace ASPTrace.Models

{ 
    public class EjErrorConfigModelssOperations
    {
        public string Mode { get; set; } 
        public int SrNo { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }
        public string AtmMake { get; set; }
    }

    public class EjErrorConfigModelssData
    {
        public int SrNo { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }
        public string AtmMake { get; set; }
    }

}

