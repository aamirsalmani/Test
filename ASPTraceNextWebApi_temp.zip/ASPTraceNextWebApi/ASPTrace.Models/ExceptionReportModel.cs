﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class ExceptionReportModel
    {


    }

    public class EJMissingReportModel
    {

        public string ClientID { get; set; }

        public string TERMINALID { get; set; }

        public string UploadStatus { get; set; }

        public string FROMDATE { get; set; }
        public string TODATE { get; set; }


    }

    public class RawDataInputModel
    {

        public string ClientID { get; set; }

        public string TERMINALID { get; set; }

        public string UploadStatus { get; set; }

        public string FROMDATE { get; set; }
        public string TODATE { get; set; }


    }


    public class EJMissingDataModel
    {
        public string clientid { get; set; }
        public string terminalid { get; set; }
        public string FileName { get; set; }
        public string FileDate { get; set; }
        public string UploadStatus { get; set; }
        public int InsertCount { get; set; }
        public int TotalRowCount { get; set; }
        public string StartTime { get; set; }
        public string CompletionTime { get; set; }
        public string ErrorMessage { get; set; }
    }




    public class EJMissingModel
    {


        public string clientid { get; set; }

        public string terminalid { get; set; }

        //public string uploadstatus { get; set; }

        public string fromdate { get; set; }
        public string todate { get; set; }
    }



    //public class DownloadRawDataModel1
    //{

    //    public string clientid { get; set; }
    //    public string terminalid { get; set; }
    //    public string FileName { get; set; }
    //    public DateTime FileDate { get; set; }
    //    public string UploadStatus { get; set; }
    //    public int InsertCount { get; set; }
    //    public int TotalRowCount { get; set; }
    //    public DateTime StartTime { get; set; }
    //    public DateTime CompletionTime { get; set; }
    //    public string ErrorMessage { get; set; }

    //}

    // public class EJMissingReportModel
    //{
    //    public string TerminalID { get; set; }
    //    public string FileName { get; set; }
    //    public DateTime FileDate { get; set; }
    //    public string UploadStatus { get; set; }
    //    public int InsertCount { get; set; }
    //    public int TotalRowCount { get; set; }
    //    public DateTime StartTime { get; set; }
    //    public DateTime CompletionTime { get; set; }
    //    public string ErrorMessage { get; set; }
    //}

}
