﻿namespace ASPTrace.Models;

#nullable disable warnings

    public class ChannelModeDetailsFieldModel
    {
        public string ClientID { get; set; }
        public int ChannelID { get; set; }
        public string ChannelName { get; set; }
    }
    public class AddFieldConfigModel
    {
        public string ClientID { get; set; }
        public string VendorID {get; set;}  
        public string ChannelID {get; set;}
        public string ModeID {get; set;}  
        public string FormatID {get; set;}
        public string TerminalCode { get; set; }  
        public string AcquirerID {get;set;}  
        public string BinNo {get;set;}  
        public string RevCode1 {get;set;}  
        public string RevCode2 {get;set;}  
        public string RevType {get;set;}  
        public string RevEntry { get; set; }
        public string TxnDateTime {get;set;}  
        public string TxnValueDateTime {get;set;}  
        public string TxnPostDateTime {get;set;}  
        public string ATMType {get;set;}  
        public string POSType {get;set;}  
        public string ECOMType {get;set;}  
        public string IMPSType {get;set;}  
        public string UPIType {get;set;}  
        public string MicroATMType {get;set;}  
        public string MobileRechargeType {get;set;}  
        public string Deposit {get;set;}  
        public string BalEnq {get;set;}  
        public string MiniStatement {get;set;}  
        public string PinChange {get;set;}  
        public string ChequeBookReq {get;set;}  
        public string RespCode1 {get;set;}  
        public string RespCode2 {get;set;}  
        public string RespTpe {get;set;}  
        public string EODCode {get;set;}  
        public string OfflineCode {get;set;}  
        public string DebitCode {get;set;}  
        public string CreditCode {get;set;}  
        public string CreatedBy { get; set; }
        public string TxnAmountIsDecimal { get; set; }
     
      


    }

    public class AddFieldConfigFieldModel
    {
        public string ModifiedOn { get; set; }
        public string ModifiedBy { get; set; }
        public string TerminalCode { get; set; }
        public string BIN_No { get; set; }
        public string AcquirerID { get; set; }
        public string ReversalCode1 { get; set; }
        public string ReversalCode2 { get; set; }
        public string ReversalType { get; set; }
        public string TxnDateTime { get; set; }
        public string TxnValueDateTime { get; set; }
        public string TxnPostDateTime  { get; set; }
        public string ATMType { get; set; }
        public string CDMType { get; set; }
        public string POSType { get; set; }
        public string ECOMType { get; set; }
        public string IMPType { get; set; }
        public string UPIType  { get; set; }
        public string MicroATMType  { get; set; }
        public string MobileRechargeType { get; set; }
        public string BalanceEnquiry { get; set; }
        public string MiniStatement { get; set; }
        public string PinChange { get; set; }
        public string ChequeBookReq { get; set; }
        public string ResponseCode1  { get; set; }
        public string ResponseCode2 { get; set; }
        public string ResponseType { get; set; }
        public string EODCode { get; set; }
        public string OfflineCode { get; set; }
        public string DebitCode { get; set; }
        public string CreditCode { get; set; }
        public string RevEntryLeg { get; set; }
        public string TxnAmountIsDecimal { get; set; }
    }


    public class VendorFieldModel
    {
        public string VendorID { get; set; }
        public string VendorName { get; set; }
    }

    public class ChannelFieldModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ChannelName { get; set; }
    }
    public class ModeFieldModel
    {
        public string ModeID { get; set; }
        public string ModeName { get; set; }
        public string TransactionMode { get; set; }
    }

    public class FormatIdFieldModel
    {
        public string FormatID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ClientID { get; set; }
        public string VendorID { get; set; }
    }

    public class FieldIdentificationDetailsModel
    {
       public string ChannelID { get; set; }
       public string ModeID { get; set; }
       public string TerminalCode { get; set; }
       public string BIN_No {get;set;}
       public string AcquirerID {get;set;}
       public string ReversalCode1 {get;set;}
       public string ReversalCode2  {get;set;}
       public string ReversalType {get;set;}
       public string TxnDateTime  {get;set;}
       public string TxnValueDateTime {get;set;}
       public string TxnPostDateTime   {get;set;}
       public string ATMType  {get;set;}
       public string POSType {get;set;}
       public string ECOMType{get;set;}
       public string IMPType {get;set;}
       public string UPIType {get;set;}
       public string MicroATMType {get;set;}
       public string MobileRechargeType {get;set;}
       public string CDMType {get;set;}
       public string BalanceEnquiry {get;set;}
       public string MiniStatement {get;set;}
       public string PinChange {get;set;}
       public string ChequeBookReq {get;set;}
       public string ResponseCode1 {get;set;}
       public string ResponseCode2 {get;set;}
       public string ResponseType {get;set;}
       public string EODCode  {get;set;}
       public string OfflineCode {get;set;}
       public string DebitCode { get; set; }
       public string CreditCode { get; set; }
       public string RevEntryLeg { get; set; }
       public string FormatID { get; set; }
       public string ClientID { get; set; }
       public string VendorID { get; set; }
    }

    public class FieldIdentificationVendorDetailsModel
    {
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TerminalCode { get; set; }
        public string BIN_No { get; set; }
        public string AcquirerID { get; set; }
        public string ReversalCode1 { get; set; }
        public string ReversalCode2 { get; set; }
        public string ReversalType { get; set; }
        public string TxnDateTime { get; set; }
        public string TxnValueDateTime { get; set; }
        public string TxnPostDateTime { get; set; }
        public string ATMType { get; set; }
        public string POSType { get; set; }
        public string ECOMType { get; set; }
        public string IMPType { get; set; }
        public string UPIType { get; set; }
        public string MicroATMType { get; set; }
        public string MobileRechargeType { get; set; }
        public string CDMType { get; set; }
        public string BalanceEnquiry { get; set; }
        public string MiniStatement { get; set; }
        public string PinChange { get; set; }
        public string ChequeBookReq { get; set; }
        public string ResponseCode1 { get; set; }
        public string ResponseCode2 { get; set; }
        public string ResponseType { get; set; }
        public string EODCode { get; set; }
        public string OfflineCode { get; set; }
        public string DebitCode { get; set; }
        public string CreditCode { get; set; }
        public string RevEntryLeg { get; set; }
        public string FormatID { get; set; }
        public string ClientID { get; set; }
        public string VendorID { get; set; }
    }
 
#nullable restore