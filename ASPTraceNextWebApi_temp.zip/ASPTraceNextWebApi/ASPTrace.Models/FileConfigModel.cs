﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;


namespace ASPTrace.Models
{
    public class ClientFileConfigModel
    {
        public string ClientID { get; set; }
        public string ClientName { get; set; }
        public string VendorID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string UserName { get; set; }

    }


    public class ConfiguredFormatFileConfigModel
    {

        public string ClientName { get; set; }
        public string LogType { get; set; }
        public string Channel { get; set; }
        public string FilePrefix { get; set; }
        public string Mode { get; set; }
        public string VendorName { get; set; }
        public string FileExtention { get; set; }
        public string CutOffTime { get; set; }

    }

    public class LogTypeFileConfigModel
    {
        public string ID { get; set; }
        public string LogType { get; set; }
    }

    public class ChannelFileConfigModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ChannelName { get; set; }
    }
    public class ModeFileConfigModel
    {
        public string ModeID { get; set; }
        public string ModeName { get; set; }
    }

    public class VendorFileConfigModel
    {
        public string VendorID { get; set; }
        public string VendorName { get; set; }
        public string VendorType { get; set; }
    }

    public class FileFormatActiveFileConfigModel
    {
        public string FormatID { get; set; }
        public string ClientID { get; set; }
        public string ClientName { get; set; }
        public string FileExtention { get; set; }
        public string VendorID { get; set; }
        public string VendorName { get; set; }
        public string FormatDescriptionXml { get; set; }
        public string CutOffTime { get; set; }
        public string StartIndex { get; set; }
        public string EndIndex { get; set; }
        public string FormatStatus { get; set; }
        public string VendorType { get; set; }
        public string FilePrefix { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string SeparatorType { get; set; }
    }

    public class FileFormatHistoryFileConfigModel
    {
        public string FormatID { get; set; }
        public string ClientID { get; set; }
        public string ClientName { get; set; }
        public string FileExtention { get; set; }
        public string VendorID { get; set; }
        public string VendorName { get; set; }
        public string FormatDescriptionXml { get; set; }
        public string CutOffTime { get; set; }
        public string StartIndex { get; set; }
        public string EndIndex { get; set; }
        public string FormatStatus { get; set; }
        public string VendorType { get; set; }
        public string FilePrefix { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string SeparatorType { get; set; }
        public string CreatedBy { get; set; }
    }

    public class FileFormatFileConfigModel
    {
        public string VendorType { get; set; }
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string VendorID { get; set; }

    }

    public class FileFormatByFileType
    {
        public List<FileFormatHistoryFileConfigModel> FileFormatDetails { get; set; }
    }

    public class FileFormatConfigModel
    {
        public string FieldName { get; set; }
        public string StartPosition { get; set; }
        public string Length { get; set; }
        public string Position { get; set; }
    }


    public class ReturnFileFormatActive
    {
        public FileFormatActiveFileConfigModel fileFormatActiveFileConfigModel { get; set; }

        public List<FileFormatConfigModel> fileFormatConfigModelList { get; set; }
    }

    public class ReportTypeModel
    {
        public string ReportID { get; set; }
        public string ReportName { get; set; }
    }

    public class NetworkTypeModel
    {
        public string TypeId { get; set; }
        public string NetworkName { get; set; }
    }

    public class ReportTableColumn
    {
        public bool IsChecked { get; set; }
        public string ColumnID { get; set; }
        public string ColumnName { get; set; }
        public string CaseCondition { get; set; }
        public string AliasColumnName { get; set; }
    }
}





