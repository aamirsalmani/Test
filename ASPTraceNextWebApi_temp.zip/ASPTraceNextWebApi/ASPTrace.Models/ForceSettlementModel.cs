﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace ASPTrace.Models
{

    public class StatusMasterForceSettlementModel
    {
        public string StatusID { get; set; }
        public string StatusName { get; set; }
    }
    public class ClientForceSettlementModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string GLStatus { get; set; }
        public string EJStatus { get; set; }
        public string NWStatus { get; set; }
        public string SWStatus { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; } 
        public string User { get; set; }
       
    }
    public class ClientForceSettlementDetailsModel
    {
        public string ClientName { get; set; }
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string TxnsDateTime { get; set; }
        public string TerminalId { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string TxnsAmount { get; set; }
        public string ActualTxnsAmount { get; set; }
        public string EJStatus { get; set; }
        public string SwitchStatus { get; set; }
        public string NetWorkStatus { get; set; }
        public string GLStatus { get; set; }
        public string ReconType { get; set; }
        public string TxnsSubType { get; set; }
        public string DrCrType { get; set; }
        public string Aging { get; set; }
        public string ClientID { get; set; }
        public string ModeID { get; set; }
        public string ChannelID { get; set; }
        public string StatusID { get; set; }
        public string UnmatchedID { get; set; }
    }

    public class ForceSettledModel
    {
        public string UnmatchedTxnIds { get; set; }
        public string SettledDate { get; set; }
        public string SettledReason { get; set; }
        public string ReconType { get; set; }
        public string SettlementType { get; set; }
        public string UserName { get; set; }
        public string ChannelID { get; set; }
    }



    //public class ForceSettlementTxnsInsertModel
    //{
    //    public string ClientID { get; set; }
    //    public string ChannelID { get; set; }
    //    public string ModeID { get; set; }
    //    public string TerminalId { get; set; }
    //    public string ReferenceNumber { get; set; }
    //    public string CardNumber { get; set; }
    //    public string CardType { get; set; }
    //    public string TxnsValueDateTime { get; set; }
    //    public string TxnsDateTime { get; set; }
    //    public string TxnsAmount { get; set; }
    //    public string ActualTxnsAmount { get; set; }
    //    public string GLStatus { get; set; }
    //    public string EJStatus { get; set; }
    //    public string NWStatus { get; set; }
    //    public string SWStatus { get; set; }
    //    public string ReconType { get; set; }
    //    public string CustAccountNo { get; set; }
    //    public string ATMAccountNo { get; set; }
    //    public string DrCrType { get; set; }
    //    public string TxnsType { get; set; }
    //    public string TxnsSubType { get; set; }
    //    public string TxnsEntryType { get; set; }
    //    public string TxnRemarks { get; set; }
    //    public string IsSettled { get; set; }
    //    public string OnSettled { get; set; }
    //    public string SettledRemarks { get; set; }
    //    public string SettledBy { get; set; }
    //    public string Aging { get; set; }
    //    public string IsRemoved { get; set; }
    //    public string TxnsParticulars { get; set; }
    //    public string CreatedBy { get; set; }
    //    public string CreatedOn { get; set; }
    //    public string ModifiedBy { get; set; }
    //    public string ModifiedOn { get; set; }
    //    public string Add_Reason { get; set; }
    //    public string Status { get; set; }
    //    public bool GLInclude { get; set; }
    //    public bool EJInclude { get; set; }
    //    public bool NWInclude { get; set; }
    //    public bool SWInclude { get; set; }
    //    public string SettlementType { get; set; }
    //    public string User { get; set; }
    //    public string FromDateTxns { get; set; }
    //    public string ToDateTxns { get; set; }
    //    public string SettleDt { get; set; }
    //}


    //public class UnmatchedDataModel
    //{
    //    public string ClientID { get; set; }
    //    public string ChannelID { get; set; }
    //    public string ModeID { get; set; }
    //    public string ChannelName { get; set; }
    //    public string TransactionMode { get; set; }
    //    public string TxnsDateTime { get; set; }
    //    public string TerminalId { get; set; }
    //    public string ReferenceNumber { get; set; }
    //    public string CardNumber { get; set; }
    //    public string TxnsAmount { get; set; }
    //    public string ActualTxnsAmount { get; set; }
    //    public string EJStatus { get; set; }
    //    public string SWStatus { get; set; }
    //    public string NWStatus { get; set; }
    //    public string GLStatus { get; set; }
    //    public string ReconType { get; set; }
    //    public string ClientName { get; set; }
    //}

    //public class ForceSettleByReferenceNumber
    //{
    //    public List<UnmatchedDataModel> UnmatchedTxnDetails { get; set; }

    //}
}
