﻿namespace ASPTrace.Models;

#nullable disable warnings

    
    public class FrequentReversalsReportModel
    { 
        public string ClientID { get; set; }
        public string TERMINALID { get; set; }
        public string CardNumber { get; set; } 
        public string FromDate { get; set; }
        public string ToDate { get; set; }

    }

    public class FrequentReversalReportDetailsModel
    {
        public string DateTime { get; set; }
        public string CardNo { get; set; }
        public string ReversalCount { get; set; }
    }

    public class FrequentReversalTxnDetailsModel
    {
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string CustAccountNo { get; set; }
        public string TxnsAmount { get; set; }
        public string ActualTxnsAmount { get; set; }
        public string EJStatus { get; set; }
        public string SWStatus { get; set; }
        public string NWStatus { get; set; }
        public string GLStatus { get; set; }
        public string TxnsSubType { get; set; }
    }

    public class FrequentReversalTxnByTxnCount
    {
        public List<FrequentReversalTxnDetailsModel> FrequentReversalTxnDetails { get; set; }
        
    }

public class FraudReportModel
{
    public string FromDate { get; set; }
    public string ToDate { get; set; }
    public string ClientID { get; set; }
    public string UserName { get; set; }
    public string TerminalId { get; set; }
}

public class DuplicateRecordModel
{
    public string referencenumber { get; set; }
    public string txnsdatetime { get; set; }
    public string txnsamount { get; set; }
    public string cardnumber { get; set; }
    public string txnsperticulars { get; set; }
    public string transactionstatus { get; set; }
    public string terminalid { get; set; }
    public string terminalname { get; set; }
}

#nullable restore


