﻿namespace ASPTrace.Models;

#nullable disable warnings

    public class HighValueTerminalTransactionsModel
    {
        public string ID { get; set; }
        public string TERMINALID { get; set; }
    }

    public class HighValueTransactionsModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ClientID { get; set; }
        public string TerminalId { get; set; } 

    }

     public class HighValueTransactionModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ClientID { get; set; }
        public string TerminalId { get; set; }
        public string CardNumber { get; set; }
       

    }


    public class HighValueTransactionsReportModel
    {
        public string TxnsDatetime { get; set; }
        public string CardNumber { get; set; }
        public string Success_trycount { get; set; }
        public string Success_txnsamount { get; set; }
        public string Retrycount { get; set; }
        public string Unsuccess_txnsamount { get; set; }
        public string TotalCount { get; set; }
    }

    public class HighValueTransactionsFraudCardDetailsReportModel
    {
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string CustAccountNo { get; set; }
        public string TxnsAmount { get; set; }
        public string ActualTxnsAmount { get; set; }
        public string EJStatus { get; set; }
        public string SWStatus { get; set; }
        public string NWStatus { get; set; }
        public string GLStatus { get; set; }
        public string TxnsSubType { get; set; }
    }

    public class HighValueTransactionsOnTxnCountModel
    {
        public List<HighValueTransactionsFraudCardDetailsReportModel> FraudCardDetails { get; set; }
    }
#nullable restore  
