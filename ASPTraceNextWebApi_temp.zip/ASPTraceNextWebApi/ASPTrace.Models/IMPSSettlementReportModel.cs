﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class IMPSSettlementReportModel
    {
        public string TR_POSTDATE { get; set; }
        public string TR_ENDDATE { get; set; }
        public string ClientID { get; set; }
    }

    public class IMPSSettlementReportDetailsModel
    {
        public string Date { get; set; }
        public string Cycle { get; set; }
        public string col { get; set; }
        public string value { get; set; }
        public string SrNo { get; set; }
        public string Flag { get; set; }
    }
}