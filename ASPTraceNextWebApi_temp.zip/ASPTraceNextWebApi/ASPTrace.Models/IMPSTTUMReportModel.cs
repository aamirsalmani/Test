﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class IMPSTTUMReportModel
    {
        public string ClientID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }

    public class IMPSTTUMReportDetailsModel
    {        
        public string AccountNumber { get; set; }
        public string DrCr { get; set; }
        public string Amount { get; set; }
        public string TranParticular { get; set; }
        public string TranRemarks { get; set; }
        public string PartitionedAccount { get; set; }
        public string PartitionType { get; set; }
        public string RefNum { get; set; }
        public string ValueDate { get; set; }
        public string InstType { get; set; }
        public string InstDate { get; set; }
        public string InstAlpha { get; set; }
        public string InstNumber { get; set; }
        public string RefCCY { get; set; }
        public string RateCode { get; set; }
        public string LoanFlowID { get; set; }
        public string Rate { get; set; }
        public string AccountCCY { get; set; }
        public string BRANCH { get; set; }
    }

    public class IMPSTTUMInsertReportModel
    {
        public string ClientID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }

    public class IMPSTTUMInsertReportDetailsModel
    {
        public string ClientID { get; set; }
        public string TRANSACTIONTYPE { get; set; }
        public string TRANSACTIONDATE { get; set; }
        public string BANK { get; set; }
        public string CURRENCYINR { get; set; }
        public string TRANSAMOUNT { get; set; }
        public string Cycle { get; set; }
        public string Approved_Fee { get; set; }
        public string Approved_Fee_GST { get; set; }
        public string Switching_Fee { get; set; }
        public string Switching_Fee_GST { get; set; }
        public string Total_Amount { get; set; }
        public string Flag1 { get; set; }
        public string Flag2 { get; set; }
        public string IsActive { get; set; }
        public string CREATEDON { get; set; }
        public string CreatedBy { get; set; }
    }

    public class UPI_TTUM_DisputeModel
    {
        public string Adjtype { get; set; }
        public string AdjustmentDate { get; set; }
        public string TerminalID { get; set; }
        public string CardNumber { get; set; }
        public string BranchCode { get; set; }
        public string Mode { get; set; }
        public string ReferenceNumber { get; set; }
        public string CustAccountNo { get; set; }
        public string Txnamount { get; set; }
        public string DrCrType { get; set; }
    }

    public class TTUMReportModel
    {
        public string ClientID { get; set; }
        public string TTUMType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }

    public class TIMEOUTModel
    {
        public string ReferenceNumber { get; set; }
        public string TxnAmount { get; set; }
        public string AccountNumber { get; set; } 
        public string TxnType { get; set; }
        public string FileDate { get; set; } 
        public string Remarks { get; set; }
        public string Cycle { get; set; }
    }

    public class NPCIBulkModel
    {
        public string BANK_ADJT_REF { get; set; }
        public string FLAG { get; set; }
        public string SHTDAT { get; set; }
        public string ADJAMT { get; set; }
        public string SHSER { get; set; }
        public string UTXID { get; set; }
        public string FILENAME { get; set; }
        public string REASON { get; set; }
        public string SPECIFYOTHER { get; set; }
    }
}
