﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace ASPTrace.Models
{
    public class FileTypeImportLogsModel
    {
        public string ID { get; set; }
        public string FileName { get; set; }
    }

    public class DisputeAddModel
    {
        public string ClientID { get; set; }
        public string ApprovalCode { get; set; }
        public string TxnsKey { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TerminalId { get; set; }
        public string AccountNumber { get; set; }
        public string ReasonCode { get; set; }
        public string TxnAmount { get; set; }
        public string ActualTxnsAmount { get; set; }
        public string ReferenceNo { get; set; }
        public string CardNo { get; set; }
        public string ComplaintID { get; set; }
        public string CardType { get; set; }
        public string TxnDate { get; set; }
        public string NoOfClaim { get; set; }
        public string ClaimDate { get; set; }
        public string Remark { get; set; }
        public string CreatedBy { get; set; }
        public string ContactNumber { get; set; }
        public string CardScheme { get; set; }
        public string ClaimType { get; set; }
        public string TxnsSubType { get; set; }
        public string FileName { get; set; }
        public string TxnValueDateTime { get; set; }
        public string CycleID { get; set; }
        public string CycleDate { get; set; }
        public string CurrencyCode { get; set; }
    }

    public class FileUploadStatusModel
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public string FileFormatId { get; set; }
        public string FileType { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public DateTime? FileDate { get; set; }
        public int InsertCount { get; set; }
        public int TotalRowCount { get; set; }
        public string ErrorMessage { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? StartTime { get; set; }
        public int UploadStatus { get; set; }
        public string FinalBatchDetails { get; set; }

    }

    //public class BatchDetails
    //{
    //    public int BatchNo { get; set; }
    //    public int BatchSize { get; set; }
    //    public int TxnUploadCount { get; set; }
    //    public int TxnsCount { get; set; }
    //    public string BatchStatus { get; set; }
    //    public int FailedCount { get; set;}
    //    public string BatchStartTime { get; set; }
    //    public string BatchEndTime { get; set; }
        
    //}

    //public class DtDetails
    //{
    //    public DateTime? FileDateTime { get; set; }
    //    public string ConfigID { get; set;}
    //}
}