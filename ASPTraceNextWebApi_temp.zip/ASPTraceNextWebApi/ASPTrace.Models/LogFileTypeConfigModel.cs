﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class LogFileTypeConfigModel
    {
    }


    public class GetLogFileTypeConfigModel
    {

        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }

    }

    //Sidd
    public class GetLogFileTypeconfiglist
    {
        public string ID { get; set; }
        public string ClientName { get; set; }
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string NetworkTypeID { get; set; }
        public string LogFileType { get; set; }
        public string MaxFileCount { get; set; }
        public string TableName { get; set; }
        public string IsRecon { get; set; }
    }


    //public class GetLogFileTypeconfiglist
    //{
    //    public string ID { get; set; }
    //    public string ClientName { get; set; }
    //    public string ChannelName { get; set; }
    //    public string TransactionMode { get; set; }
    //    public string NetworkTypeID { get; set; }
    //    public string FileID { get; set; }
    //    public string LogFileType { get; set; }
    //    public string TableName { get; set; }
    //    public string IsRecon { get; set; }
    //}



    public class LogfileTypeConfigModel
    {
        public string Clientid { get; set; }
        public string Channelid { get; set; }
        public string Modeid { get; set; }
        public string NetworkTypeID { get; set; }
        public string FileID { get; set; }
        public string TableName { get; set; }
        public string IsRecon { get; set; }
        public string ID { get; set; }
        public string FileCount { get; set; }
        public string UserName { get; set; }
        public string Mode { get;set; }
    }

    //public class EditLogfileTypeConfigModel
    //{
    //    public string ID { get; set; }
    //    public string Clientid { get; set; }
    //    public string ChannelID { get; set; }
    //    public string ModeID { get; set; }
    //    public string NetworkTypeID { get; set; }
    //    public string FileID { get; set; }
    //    public string LogFileType { get; set; }
    //    public string TableName { get; set; }
    //    public string IsRecon { get; set; }


    //}

    public class DeleteLogFileTypeConfigModel
    {
        public string ID { get; set; }
        public string Mode { get; set; } 
    }

}
