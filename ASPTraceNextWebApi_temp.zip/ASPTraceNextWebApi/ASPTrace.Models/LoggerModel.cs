﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class LoggerModel
    { }
    public class UserLoginReportModel
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string UserId { get; set; }
    }

    public class InsertLoginInstanceModel  
    {
        public string UserId { get; set; }
        public string LoginTime { get; set; }
        public string Status { get; set; }
    }

    public class InsertLogoutInstanceModel
    {
        public string UserId { get; set; }
        public string LogoutTime { get; set; }
    }

    public class MenuEnableModel
    {
        public string MenuName { get; set; }
    }

    public class DbExceptionModel
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }

    public class UserLoginReportDataModel
    {
        public string UserId { get; set; }
        public string LoginTime { get; set; }
        public string Status { get; set; }
        public string LogoutTime { get; set; }
    }


    public class UserActivityReportDataModel
    {
        public string UserId { get; set; }
        public string ActivityDate { get; set; }    
        public string PageName { get; set; }
        public string Activity { get; set; }
    }

    public class UserActivityReportInsertModel
    {
        public string UserId { get; set; }
        public string PageName { get; set; }
        public string Activity { get; set; }
    }

    public class DbExceptionDataModel
    {
        public string UserName { get; set; }
        public string ErrorNumber { get; set; }
        public string ErrorState { get; set; }
        public string ErrorSeverity { get; set; }
        public string ErrorLine { get; set; }
        public string ErrorProcedure { get; set; }
        public string ErrorMessage { get; set; }
        public string ErrorDateTime { get; set; }
    }


    public class ErrorLogModel
    {
        public string ClientId { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }

    public class ErrorLogDataModel
    {
        public string PageName { get; set; }
        public string ErrorDescription { get; set; }
        public string UploadFileName { get; set; }
        public string LineNumber { get; set; }
        public string MethodName { get; set; } 
        public string ErrorDate { get; set; }
    }

    public class UserListModel
    {
        public string ID { get; set; }
        public string UserId { get; set; }
    }

    public class MenuListModel
    {
        public string MenuName { get; set; }
        public string ParentMenuName { get; set; }
        public string IsEnable { get; set;}
    }

    public class UserAuditReportModel
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
    }


}
