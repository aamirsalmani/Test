﻿using System;
using System.Collections.Generic;
using System.Text;


#nullable disable warnings  

namespace ASPTrace.Models
{
    public class LoginModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string ClientID { get; set; }
        public string CAPTCHACODE { get; set; }
        public string WebToken { get; set; } 
        public string UserAgent { get; set; }
        public string KeyToken { get; set; }
        public string IVToken { get; set; }
    }

    public class LoginSuccessModel
    {
        public string UserName { get; set; }
        public string ClientID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserID { get; set; }
        public string RoleName { get; set; }
        public string ClientLogo { get; set; }
        public string theme { get; set; }
    }

    public class CAPTCHAModel
    {
        public string CAPTCHACODE { get; set; }

        public string WEBTOKEN { get; set; }
    }

    public class CaptchaImageModel
    {
        public string captchaimagebase64 { get; set; }
        public string webtoken { get; set; }
    }

    public class ForgotModel
    {
        public string EmailID { get; set; }
        public string CAPTCHACODE { get; set; }
        public string WebToken { get; set; }
    }

    public class UserClientModel
    {
        public string ClientID { get; set; }
        public string UserID { get; set; }
        public string IsCount { get; set; }
        public string IsLocked { get; set; }

    }

    public class UserLoginCountModel
    {
        public string UserID { get; set; }
        public int LoginFailedCount { get; set; }
        public int LoginAttemptCount { get; set; }
    }

    public class UserLoginHistory
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public DateTime LoginTime { get; set; }
        public string IpAddress { get; set; }
        public string UserAgent { get; set; }
    }

    public class LoginAttemptModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class FirstLoginModel
    {
        public string ClientCode { get; set; }
        public string UserID { get; set; }
        public string IsFirstLogin { get; set; }
    }


    public class SessionSettings
    {
        public string Secret { get; set; }
        public string SessionTimout { get; set; }
        public string LoginAttemptCount { get; set; }
    }

    public class LoginRequest
    {
        public string UserId { get; set; } 
        public string IpAddress { get; set; }
        public string UserAgent { get; set; }
        public bool Success { get; set; }
        public string FailureReason { get; set; }
        public string Webtoken { get; set; }
        public string RefreshToken { get; set; }
    }

    public class LogoutRequest
    {
        public string UserId { get; set; } 
        public string IpAddress { get; set; }
        public string UserAgent { get; set; }
        public string Webtoken { get; set; }
        public string RefreshToken { get; set; }
    }

    public class RefreshTokenRequest
    {
        public string RefreshToken { get; set; }
    }

    public class ThemeModel
    {
        public string UserName { get; set; }
        public string Theme { get; set; }
    }

}
