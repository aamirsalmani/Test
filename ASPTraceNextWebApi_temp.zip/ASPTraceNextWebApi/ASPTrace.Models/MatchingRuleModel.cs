﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace ASPTrace.Models
{
   
    public class ChannelMatchingModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ChannelName { get; set; }
        public string MODEID { get; set; }
    }
    public class ModeMatchingModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TransactionMode { get; set; }
    }

    public class MatchingRuleSetForClient
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReconName { get; set; }
        public string RuleName { get; set; }
        public string MatchingModeName { get; set; } 
        public string ChannelName { get; set; }
        public string ClientName { get; set; }
        
        public string ImportFileStatus { get; set; }
        public string MatchingRuleStatus { get; set; } 
        public string SettlementRuleStatus { get; set; }
        public string MatchingRuleSelectedColumns { get; set; }
        public string SettlementRuleSelectedColumns { get; set; }
    }

    public class AddMatchingRuleConfig
    {
        public string BindMatchingRules { get; set; }
        public string ModeID { get; set; }
        public string IsRemoved { get; set; }
        public string ClientID { get; set; }
        public string ColumnName { get; set; }
        public string ChannelID { get; set; }
        public string RuleType { get; set; }
        public string Username { get; set; }
        public string CreatedOn { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string TerminalId { get; set; }
        public string TxnDate { get; set; }
        public string TxnAmount { get; set; }
        public bool RRNInclude { get; set; }
        public bool CardNoInclude { get; set; }
        public bool TerminalIdInclude { get; set; }
        public bool DateInclude { get; set; }
        public bool AmountInclude { get; set; }
    }

    public class MatchingColumnTable
    {
        public string ClientID { get; set; } 
        public string TableName { get; set; }
    }

    public class MatchingColumns
    {
        public string RowID { get; set; }
        public string TableName { get; set; }
        public string ColumnName { get; set; }
    }

    public class MatchingRuleConfig
    {
        public string BindMatchingRules { get; set; }
        public string ModeID { get; set; }
        public string SelectedColumn { get; set; }
        public string ClientID { get; set; } 
        public string ChannelID { get; set; }
        public string RuleType { get; set; }
        public string Username { get; set; } 
    }

    public class ReconImportConfig
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ReconType { get; set; }
        public string ModeID { get; set; }
        public string TransactionMode { get; set; }
        public string Table1 { get; set; }
        public string Table2 { get; set; }
        public string Table3 { get; set; }
        public string Table4 { get; set; } 
        public string ChannelName { get; set; }
        public string ClientName { get; set; } 
    }

    public class DeleteMatchingModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string RuleType { get; set; }
    }
}
