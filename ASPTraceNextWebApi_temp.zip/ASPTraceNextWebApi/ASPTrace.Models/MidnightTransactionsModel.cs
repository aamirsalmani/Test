﻿namespace ASPTrace.Models;

#nullable disable warnings

    public class MidnightTransactionsModel
    {
       public string FromDate { get; set; }
       public string ToDate { get; set; }
       public string ClientID { get; set; }
       public string TerminalId { get; set; }
    }

    public class MidnightTransactionsReportModel
    {
        public string DateTime { get; set; }
        public string CardNumber { get; set; }
        public string TxnCount { get; set; }
        public string RetryCount { get; set; }
        public string TERMINALID { get; set; }
    } 
#nullable restore