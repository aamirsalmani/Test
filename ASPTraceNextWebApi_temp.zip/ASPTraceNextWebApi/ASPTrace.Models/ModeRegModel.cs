﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class ModeRegModel
    {
        public string ModeId { get; set; }
        public string TransactionMode { get; set; }
    }
    
    public class ModeRegDetcailsModel
    {
        public string ModeID { get; set; }
        public string TransactionMode { get; set; }
    }
    
    public class ModeRegAddModel
    {
        public string TransactionMode { get; set; }
        public string ModeID { get; set; }
        public string Mode { get; set; }
        public string CreatedBy { get; set; }
    }
    
    
    public class ModeRegDeleteModel
    {
        public string Mode { get; set; }
        public string ModeID { get; set; }
    }
}
