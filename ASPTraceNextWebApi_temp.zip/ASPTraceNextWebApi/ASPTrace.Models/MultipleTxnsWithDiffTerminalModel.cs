﻿namespace ASPTrace.Models;

#nullable disable warnings

    public class MultipleTxnsDiffModel
{
    public string FromDate { get; set; }
    public string ToDate { get; set; }
    public string ClientID { get; set; }
    public string TerminalID { get; set; }
    // public string CardNumber { get; set; }
}
public class MultipleTxnDiffModel
{
    public string FromDate { get; set; }
    public string ToDate { get; set; }
    public string ClientID { get; set; }
    // public string TerminalID { get; set; }
    public string CardNumber { get; set; }
}

public class MultipleTxnsWithDiffTerminalModel
{
    public string DateTime { get; set; }
    public string TerminalID { get; set; }
    public string CardNo { get; set; }
    public string TxnCount { get; set; }
    public string TerminalCount { get; set; }


}

public class FraudReportDiffModel
{
    public string ChannelName { get; set; }
    public string TransactionMode { get; set; }
    public string TerminalID { get; set; }
    public string TxnsDateTime { get; set; }
    public string ReferenceNumber { get; set; }
    public string CardNumber { get; set; }
    public string CustAccountNo { get; set; }
    public string TxnsAmount { get; set; }
    public string ActualTxnsAmount { get; set; }
    public string EJStatus { get; set; }
    public string SWStatus { get; set; }
    public string NWStatus { get; set; }
    public string GLStatus { get; set; }
    public string TxnsSubType { get; set; }
}

public class FraudReportDiffByTxnCount
{
    public List<FraudReportDiffModel> FraudReports { get; set; }
}


#nullable restore