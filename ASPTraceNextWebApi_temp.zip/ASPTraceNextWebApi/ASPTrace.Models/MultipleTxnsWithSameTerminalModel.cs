﻿namespace ASPTrace.Models;

#nullable disable warnings

    public class MultipleTxnsSameModel
    {
        public string ClientID { get; set; }
        public string TerminalId { get; set; }
        public string CardNumber { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }

    } 

    public class MultipleTxnsWithSameTerminalModel
    {
        public string DateTime { get; set; }
        public string TerminalID { get; set; }
        public string CardNo { get; set; }
        public string TxnCount { get; set; }
    }

    public class FraudReportSameModel
    {
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string CustAccountNo { get; set; }
        public string TxnsAmount { get; set; }
        public string ActualTxnsAmount { get; set; }
        public string EJStatus { get; set; }
        public string SWStatus { get; set; }
        public string NWStatus { get; set; }
        public string GLStatus { get; set; }
        public string TxnsSubType { get; set; }
    }

    public class FraudReportSameByTxnCount
    {
        public List<FraudReportSameModel> FraudReports { get; set; }
    }

#nullable restore