﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASPTrace.Models
{
    public class NotificationEvent
    {
        public int ID { get; set; }
        public int MenuID { get; set; }
        public string Message { get; set; }
        public string QueryData { get; set; }
        public string Path { get; set; }
        public string Unread { get; set; }
        public bool IsSent { get; set; }
        public string Time { get; set; }
        public string NotificationType { get; set; }
        public string NotificationTypeID { get; set; }
        public bool HasButton { get; set; }
        public string ButtonText { get; set; }
        public string IconClass { get; set; }
    }
}
