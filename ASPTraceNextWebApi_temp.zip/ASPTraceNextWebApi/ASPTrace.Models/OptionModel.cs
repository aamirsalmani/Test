﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using Utility;

namespace ASPTrace.Models
{
    public class OptionModel
    {
        public string value { get; set; }
        public string label { get; set; }
    }

    public class ClientOptionModel
    {
        public string ClientID { get; set; }
        public string ClientName { get; set; }
    }
    public class LogOptionModel
    {
        public string LogID { get; set; }
        public string LogName { get; set; }
    }

    
    public class ChannelOptionModel
    {
        public string ChannelID { get; set; }
        public string ChannelName { get; set; }
    }
    public class ModeOptionModel
    {
        public string ModeID { get; set; }
        public string ModeName { get; set; }
    }

    public class ModeIMPSOptionModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ModeName { get; set; }
    }
    public class TerminalOptionModel
    {
        public string ClientID { get; set; }
        public string ID { get; set; }
        public string TERMINALID { get; set; }
    }

    public class FileModel
    {
        public string ClientID { get; set; }
        public IFormFile BranchFile { get; set; }
        public IFormFile TerminalFile { get; set; }
    }

    public class ImportFileModel
    {
        public string ClientID { get; set; }
        public IFormFile ImportFile { get; set; }
        public string FileFormatId { get; set; }
        public string FileFormatText { get; set; }
        public string UserName { get; set; }
    }

    public class ImportFileStatus
    {
        public string MSG { get; set; }
        public string Status { get; set; }
    }


    public class FileTypeOptionModel
    {
        public string FileTypeID { get; set; }
        public string FileTypeName { get; set; }
    }

    public class CountryRegModel
    {
        public string Id { get; set; }
        public string Country { get; set; }
    }
    public class CurrencyOptRegModel
    {
        public long currencyID { get; set; }
        public string? CountryCode { get; set; }
    }


    public class ReactFileTypesModel
    {
        public string ID { get; set; }
        public string FileTypes { get; set; }
    }

    public class ReconImportFileModel
    {
        public string ClientID { get; set; }
        public IFormFile ImportFile { get; set; }
        public string Seperator { get; set; }
        public string UserName { get; set; }
    }

    public class ReconImportConfigModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string VendorID { get; set; }
        public string ReconType { get; set; }

        public TableDetails Table { get; set; }

        public ReconAliasColumnsModel ConfigData { get; set; }
        public string UserName { get; set; }
        public string FileData { get; set; }
        public string DateFieldArray { get; set; }
        public string FormatXML { get; set; }
    }
    public class FileDataArray
    {
        //{ id: index, columnName: item.label ,columnAlias:item.renamed , position: item.position, dataType: "string", dataValue: item.dataValue }
        public string ID { get; set; }
        public string columnName { get; set; }
        public string columnAlias { get; set; }
        public string position { get; set; }
        public string dataType { get; set; }
        public string dataValue { get; set; }

    }
    public class DateArray
    {
        public string DateColumn { get; set; }
        public List<string> DateFormat { get; set; }

    }


    public class TableDetails
    {
        public string TableNo { get; set; }
        public string TableName { get; set; }
    }

    public class DynamicImportFileModel
    {
        public string ClientID { get; set; }
        public string ConfigID { get; set; }
        public string TableName { get; set; }
        public string VendorID { get; set; }
        public IFormFile ImportFile { get; set; }
        public string UserName { get; set; }
    } 

    public class RawTableColumn
    {
        public string ColumnID { get; set; }
        public string ColumnName { get; set; }
    }

    public class FileData
    {
        public string fileName { get; set; }
    }


    public class GetSuccessfulUnSuccessfulCount
    {
        public string date { get; set; }
        public string Successful { get; set; }
        public string Unsuccessful { get; set; }
    }

    public class ATMChartInput
    {
        public string UserID { get; set; }
        public int ChannelID { get; set; }
    }

    public class RoleOptionModel
    {
        public string RoleID { get; set; }
        public string RoleName { get; set; } 

    }

    public class AlertTypeModel
    {
        public string AlertID { get; set; }
        public string AlertName { get; set; }
    }
    public class AlertSeverityModel
    {
        public string SeverityID { get; set; }
        public string SeverityName { get; set; }
    }
    public class AlertScheduleTypeModel
    {
        public string AlertScheduleTypeID { get; set; }
        public string AlertScheduleTypeName { get; set; }
    }
    public class AlertNotificationChannelModel
    {
        public string AlertChannelID { get; set; }
        public string AlertChannelName { get; set; }
    }
    public class AlertEscalationUserModel
    {
        public string EscalationUserID { get; set; }
        public string EscalationUserName { get; set; }
    }
}