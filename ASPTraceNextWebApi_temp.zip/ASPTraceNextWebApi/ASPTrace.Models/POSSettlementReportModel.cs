﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class POSSettlementReportModel
    {
        public string ClientID { get; set; }
        public string SettlementType { get; set; }
        public string TR_POSTDATE { get; set; }
        public string TR_ENDDATE { get; set; }
    }

    public class POSSettlementReportDetailsModel
    {
        public string RaiseDate { get; set; }
        public string SettlementDate { get; set; }
        public string TransactionDate { get; set; }
        public string RRN { get; set; }
        public string ProcessingCode { get; set; }
        public string CurrencyCode { get; set; }
        public string AmountTransaction { get; set; }
        public string AmountAdditional { get; set; }
        public string SettlementTxnAmount { get; set; }
        public string SettlementAddAmount { get; set; }
        public string ApprovalCode { get; set; }
        public string AcquirerID { get; set; }
        public string IssuerID { get; set; }
        public string CardType { get; set; }
        public string CardBrand { get; set; }
        public string CardAcceptorTerminalID { get; set; }
        public string Channel { get; set; }
        public string Cycle { get; set; }
        public string TXNCOUNT { get; set; }
        public string TxnAmtDR { get; set; }
        public string TxnAmtCR { get; set; }
        public string SETAMTDR { get; set; }
        public string SETAMTCR { get; set; }
        public string IntFeeAmtDR { get; set; }
        public string IntFeeAmtCR { get; set; }
        public string MemIncFeeAmtDR { get; set; }
        public string MemIncFeeAmtCR { get; set; }
        public string OthFeeAmtDR { get; set; }
        public string OthFeeAmtCR { get; set; }
        public string OthFeeGSTDR { get; set; }
        public string OthFeeGSTCR { get; set; }
        public string FinalSumCr { get; set; }
        public string FinalSumDr { get; set; }
        public string FinalNet { get; set; }
        public string NPCICount { get; set; }
        public string NPCIAmt { get; set; }
        public string GLCount { get; set; }
        public string GLAmt { get; set; }
        public string DebitCredit { get; set; }
        public string NFSDiff { get; set; }
        public string Net { get; set; }
        public string FeeAmt { get; set; }
        public string FeeAmtGST { get; set; }
        public string Fee { get; set; }
        public string AmtCR { get; set; }
        public string AmtDR { get; set; }
        public string FeeCR { get; set; }
        public string FeeDR { get; set; }
    }
}