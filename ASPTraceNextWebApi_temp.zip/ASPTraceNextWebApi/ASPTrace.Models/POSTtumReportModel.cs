﻿using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Text;

namespace ASPTrace.Models
{
    public class POSTtumReportModel
    {
        public string ClientID { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
    }

    //-------------------------------------------------nk----------------------------------------------//
    public class AllTTUMReportModel
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public int NetworkID { get; set; }
        public string CurrencyType { get; set; }
        public int TTUMReportType { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
    }

    public class AllTTUMReportModelNew
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public int NetworkID { get; set; }
        public string CurrencyType { get; set; }
        public int TTUMReportType { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        public string Status { get; set; }
        public string UserRole { get; set; }
    }

    public class NPCIAllTTUMReportModel
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public int NetworkID { get; set; }
        public string CurrencyType { get; set; }
        public int TTUMReportType { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        public string CheckerStatus { get; set; }
    }

    public class UpdateCheckerModel
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public int NetworkID { get; set; }
        public string CurrencyType { get; set; }
        public int TTUMReportType { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        public string UserName { get; set; }
        public string CheckerRemarks { get; set; }
        public string TempTTumReport { get; set; }
    }

    public class UpdateNewCheckerModel
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public int NetworkID { get; set; }
        public string CurrencyType { get; set; }
        public int TTUMReportType { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        public string UserName { get; set; }
        public string UserRole { get; set; }
        public string CheckerRemarks { get; set; }
        public int [] CheckedID { get; set; }
    }
    public class CreditAdjustmentTTUMData
    {
        public int ClientID { get; set; } 
        public int ChannelID { get; set; } 
        public int ModeID { get; set; } 
        public string BankAdjustmentReference { get; set; }
        public string DrCr { get; set; }
        public DateTime TxnsDate { get; set; } 
        public decimal TxnsAmount { get; set; } 
        public string ReferenceNumber { get; set; }
        public string TerminalId { get; set; }
        public string EjStatus { get; set; }
        public string SwStatus { get; set; }
        public string NwStatus { get; set; }
        public string GlStatus { get; set; }
        public string ErrorCode { get; set; }
        public DateTime NetworkDate { get; set; } 
        public string MakerID { get; set; }
        public string MakerRemarks { get; set; }
        public string CheckerID { get; set; }
        public string CheckerRemarks { get; set; }
    }

    public class SettelmentTTUMReport
    {
        public string ChannelName { get; set; }
        public string CurrencyType { get; set; }
        public string TxnsDate { get; set; }
        public string TxnsPerticulars { get; set; }
        public string POS { get; set; }
        public string ATM { get; set; }
        public string AccountNumber { get; set; }
        public string MakerID { get; set; }
        public string MakerRemarks { get; set; }
        public string CheckerID { get; set; }
        public string CheckerRemarks { get; set; }
    }

    public class ReportModel
    {
        public string Report { get; set; }
    }
    public class TipsAndSurTTUMReport
    {
        public string ChannelName { get; set; }
        public string Mode { get; set; }
        public string TxnsDate { get; set; }
        public string ReferenceNumber { get; set; }
        public string AccountNumber { get; set; }
        public string TxnsAmount { get; set; }
        public string TerminalID { get; set; }
        public string CardType { get; set; }
        public string VisaAmount { get; set; }
        public string GLAmount { get; set; }
        public string AmountVisaGLDiff { get; set; }
        public string DrCr { get; set; }
        public string NostroAcToBeDebited { get; set; }
        public string Narriation { get; set; }
        public string MakerID { get; set; }
        public string MakerRemarks { get; set; }
        public string CheckerID { get; set; }
        public string CheckerRemarks { get; set; }
    }

    //-------------------------------------------------nk----------------------------------------------//
    public class POSTtumReportDetailsModel
    {
        public string AccountNumber { get; set; }
        public string DrCr { get; set; }
        public string Amount { get; set; }
        public string TranParticular { get; set; }
        public string TranRemarks { get; set; }
        public string PartitionedAccount { get; set; }
        public string PartitionType { get; set; }
        public string RefNum { get; set; }
        public string ValueDate { get; set; }
        public string InstType { get; set; }
        public string InstDate { get; set; }
        public string InstAlpha { get; set; }
        public string InstNumber { get; set; }
        public string RefCCY { get; set; }
        public string RateCode { get; set; }
        public string LoanFlowID { get; set; }
        public string Rate { get; set; }
        public string AccountCurrency { get; set; }
        public string BRANCH { get; set; }

    }

    public class CashTallyReportModel
    {
        public int ClientID { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
    }
}
