﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class ReasonWiseSummaryReportModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }

    public class ReasonWiseSummaryReportDetailsModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ChannelName { get; set; }
        public string TxnsDate { get; set; }
        public string Mode { get; set; }
        public string EJStatus { get; set; }
        public string SWStatus { get; set; }
        public string NWStatus { get; set; }
        public string GLStatus { get; set; }
        public string NoOfCount { get; set; }
        public string TxnAmount { get; set; }
 
    }
}
