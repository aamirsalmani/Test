﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class ReconConfigModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; } 
        public string ReconType { get; set; } 
        public string ReconTables { get; set; } 
        public string UserName { get; set; }
    }

    public class ReconConfigTableModel
    { 
        public string Table1 { get; set; }
        public string Table2{ get; set; }
        public string Table3 { get; set; }
        public string Table4 { get; set; } 
    }

    public class DynamicReconConfig
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReconName { get; set; }
        public string ReconType { get; set; }
        public string TransactionMode { get; set; }
        public string ChannelName { get; set; }
        public string ClientName { get; set; } 
        public string ReconStatus { get; set; }
        public string TableName { get; set; }
        public string ConfigID { get; set; }
    }
    public class CaseOutputModel
    {
        public string ColumnName { get; set; }
        public string DropDownValues { get; set; }
    }
}
