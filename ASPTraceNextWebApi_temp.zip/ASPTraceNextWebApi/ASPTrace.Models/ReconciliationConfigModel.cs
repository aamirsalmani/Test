﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace ASPTrace.Models
{
    public class ReconTypeModel
    {
        public int ID { get; set; }
        public string ReconType { get; set; }
    }
    public class ReconTablesModel
    {
        public int TableID { get; set; }
        public string TableName { get; set; }
        public string RawTableName { get; set; }

    }

    public class MasterValues
    {
        public int ID { get; set; }
        public string Value { get; set; }
    }
    public class ReconColumnsModel
    {
        public int ID { get; set; }
        public string ColumnName { get; set; }
        public string DataType { get; set; }
        public int CharMaxLength { get; set; }
        public string Nullable { get; set; }

    }
    public class ReconAliasColumnsModel
    {
        public int ColumnID { get; set; }
        public string AliasColumn { get; set; }
        public string ColumnValue { get; set; }
        public string DataColumn { get; set; }
        public string Position { get; set; }
        public string DataType { get; set; }
        public string startPosition { get; set; }
        public string txtlength { get; set; }
        public string CaseCondition { get; set; }
        public bool IsChanged { get; set; }


    }
    public class StatusConditionsModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReconType { get; set; }
        public string TableNo { get; set; }
        public TableStruct table { get; set; }
        public string status { get; set; }
        public string statusCondition { get; set; }
        public bool isClear { get; set; }

    }
    public class TableStruct
    {
        public int TableNo { get; set; }
        public string TableName { get; set; }

    }

    public class ReconRawTableFields
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReconType { get; set; }
        public string TableNo { get; set; }
        public string TableName { get; set; }
        public string ColumnID { get; set; }
        public string AliasColumn { get; set; }
        public string ColumnValue { get; set; }
        public string Reversal { get; set; }
        public string ReversalCode { get; set; }

    }

    public class ReconQueryFields
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ChannelName { get; set; }
        public string ModeName { get; set; }
        public string VendorType { get; set; }
        public string ReconType { get; set; }
        public string Type { get; set; }
        public TableStruct Selectedtable { get; set; }

    }


    public class ReconQueryBlocks
    {
        public string RawTable1 { get; set; }
        public string Reversal1 { get; set; }
        public string RawTable2 { get; set; }
        public string Reversal2 { get; set; }
        public string RawTable3 { get; set; }
        public string Reversal3 { get; set; }
        public string RawTable4 { get; set; }
        public string Reversal4 { get; set; }
        public string RawTable5 { get; set; }
        public string Reversal5 { get; set; }
        public string TempUnmatched { get; set; }


    }

}
