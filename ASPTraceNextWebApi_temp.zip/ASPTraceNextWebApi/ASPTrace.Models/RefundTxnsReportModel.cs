﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class RefundTxnsReportModel
    {
        public string ClientID { get; set; }
        public string FROMDATE { get; set; }
        public string TODATE { get; set; }
    }

    public class RefundTxnsReportDetailsModel
    {
        public string Date { get; set; }
        public string Type { get; set; }
        public string CardNo { get; set; }
        public string AccNo { get; set; }
        public string Trandate { get; set; }
        public string Settledate { get; set; }
        public string Amount { get; set; }
        public string Refno { get; set; }
        public string Pcode { get; set; }
        public string Name { get; set; }
        public string DisputeAmt { get; set; }
        public string Indicator { get; set; }
        public string Dispute { get; set; }
        public string status { get; set; }
    }
}