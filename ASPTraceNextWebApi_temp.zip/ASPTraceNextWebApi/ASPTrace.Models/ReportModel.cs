﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models;

    public class InputReportModel
    {
    public string ClientID { get; set; }
    public string ClientName { get; set; }
    public string ChannelID { get; set; }
    public string ModeID { get; set; }
    public string TerminalID { get; set; }
    public string TxnType { get; set; }
    public string FromDate { get; set; }
    public string ToDate { get; set; }
    public string ChannelName { get; set; }
    public string ModeName { get; set; }
    public string UserID { get; set; }
    public string ReportType { get; set; }
}

public class InputSettlementReportModel
    {
        public string ClientId { get; set; }
        public string ReportType { get; set; }
        public string ReportName { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string UserID { get; set; }
    }

public class ConsoleSetReportModel
{
    public string ClientID { get; set; }
    public string ChannelID { get; set; }
    public string Cycle { get; set; }
    public string FromDateTxns { get; set; }
    public string ToDateTxns { get; set; }
    public string UserID { get; set; }
}

public class SwitchFeeReportModel
{
    public string ClientID { get; set; }
    public string ChannelType { get; set; }
    public string FromDateTxns { get; set; }
    public string UserID { get; set; }
}

public class DailyReportInputReportModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string? TerminalID { get; set; }
        public string? TxnType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string? search { get; set; }
    }
    public class DownloadReportRequest
    {
        public string UserID { get; set; }         
        public string DownloadStatus { get; set; }   
        public string StartDate { get; set; }   
        public string EndDate { get; set; }
        public int ID { get; set; }
    }

    public class DownloadsModel
    {
        public string FileName { get; set; }            
        public string FilePath { get; set; }            
        public string FileSize { get; set; }              
        public DateTime DownloadDate { get; set; }      
        public string UserID { get; set; }              
        public int DownloadStatus { get; set; }      
        public string FileType { get; set; }            
        public string IPAddress { get; set; }           

    }

    public class InputReconReportModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TerminalID { get; set; }
        public string TxnType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReportType { get; set; }
        public string search { get; set; }
    }
    //Sidd
    public class InputUnmatchedReportModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TerminalID { get; set; }
        public string TxnType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string search { get; set; }
    }


    public class PaginatedResult
    {
        public List<dynamic> Data { get; set; }
        public int TotalRecords { get; set; }
    }

    public class InputReferenceNumberModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string? TerminalID { get; set; }
        public string ReferenceNumber { get; set; }
        public string? TxnsDateTime { get; set; }
    }
     

    public class DailyReportModel
    {
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string CustAccountNo { get; set; }
        public string TxnsAmount { get; set; }
        public string EJStatus { get; set; }
        public string SWStatus { get; set; }
        public string NWStatus { get; set; }
        public string GLStatus { get; set; }
        public string TxnsSubType { get; set; }
        public string Remark { get; set; }
        public string Aging { get; set; }
        public string PStatus { get; set; }
    }

    public class TxnDetailsModel
    {
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string TxnsAmount { get; set; }
        public string ResponseCode { get; set; }
        public string ReversalFlag { get; set; }
    }

    public class ATMTxnDetailsModel
    {
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string TxnsAmount { get; set; }
        public string ResponseCode { get; set; }
        public string ReversalFlag { get; set; }
        public string EJStatus { get; set; }
    }

    public class TxnByReferenceNumber
    {
        public List<TxnDetailsModel> EJTxnDetails { get; set; }
        public List<TxnDetailsModel> GLTxnDetails { get; set; }
        public List<TxnDetailsModel> NWTxnDetails { get; set; }
        public List<TxnDetailsModel> SWTxnDetails { get; set; }
    }

    public class TxnDetailsByReferenceNumber
    {
        public List<dynamic> EJTxnDetails { get; set; }
        public List<dynamic> GLTxnDetails { get; set; }
        public List<dynamic> NWTxnDetails { get; set; }
        public List<dynamic> SWTxnDetails { get; set; }
    }

    public class DynamicTable
    {
        public string Columns { get; set; }
        public string JsonData { get; set; }
    }

    ////Adjustment Report 
    //public class AdjustmentTerminalDetailsModel
    //{
    //    public string UserName { get; set; }
    //    public string ClientID { get; set; }
    //    public string ID { get; set; }
    //    public string TERMINALID { get; set; }

    //}

    //public class AdjustmentModeModel
    //{
    //    public string ClientID { get; set; }
    //    public string ChannelID { get; set; }
    //    public string ModeID { get; set; }
    //    public string ModeName { get; set; }
    //}

    public class AdjustmentTxnsModel
    {
        public string ClientID { get; set; }
        public string TR_POSTDATE { get; set; }
        public string TR_ENDDATE { get; set; }
        public string ReportType { get; set; }
        public string UserName { get; set; }
        public string? ChannelName { get; set; }
    }

    //public class AdjustmentTxnsReportModel
    //{
    //    public string TxnUID { get; set; }
    //    public string TxnType { get; set; }
    //    public string UID { get; set; }
    //    public string AdjDate { get; set; }
    //    public string AdjType { get; set; }
    //    public string AcquirerBank { get; set; }
    //    public string IssuerBank { get; set; }
    //    public string ResponseCode { get; set; }
    //    public string TxnDateTime { get; set; }
    //    public string ReferenceNumber { get; set; }
    //    public string TerminalID { get; set; }
    //    public string CardNo { get; set; }
    //    public string ChargebackDate { get; set; }
    //    public string ChargebackRemarks { get; set; }
    //    public string TxnAmount { get; set; }
    //    public string AdjAmount { get; set; }
    //    public string ACQFee { get; set; }
    //    public string ISSFee { get; set; }
    //    public string ISSFeeSW { get; set; }
    //    public string NPCIFee { get; set; }
    //    public string AcqFeeTax { get; set; }
    //    public string IssFeetax { get; set; }
    //    public string NPCITax { get; set; }
    //    public string AdjRef { get; set; }
    //    public string BankAdjRef { get; set; }
    //    public string AdjProof { get; set; }
    //    public string Reasondesc { get; set; }
    //    public string PinCode { get; set; }
    //    public string TerminalLocation { get; set; }
    //    public string MultiDisputeGroup { get; set; }
    //    public string FCQM { get; set; }
    //    public string ADJSettlementdate { get; set; }
    //    public string CustomerPenalty { get; set; }
    //    public string TATExpDate { get; set; }
    //    public string ACQSTLAmount { get; set; }
    //    public string AcqCC { get; set; }
    //    public string PanEntryMode { get; set; }
    //    public string ServiceCode { get; set; }
    //    public string CardDataInputCapability { get; set; }
    //    public string MCCCode { get; set; }
    //    public string Remitter { get; set; }
    //    public string Beneficiery { get; set; }
    //    public string Ben_Mobile_No { get; set; }
    //    public string Rem_Mobile_No { get; set; }
    //    public string Chbref { get; set; }
    //    public string Rem_Fee { get; set; }
    //    public string Ben_Fee { get; set; }
    //    public string BenFeeSW { get; set; }
    //    public string AdjFee { get; set; }
    //    public string RemFeeGST { get; set; }
    //    public string BenFeeGST { get; set; }
    //    public string NWGST { get; set; }
    //    public string Cust_Comp { get; set; }
    //    public string Adj_Raise_Time { get; set; }
    //    public string SHDT72 { get; set; }
    //    public string SHDT73 { get; set; }
    //    public string SHDT74 { get; set; }        
    //    public string SHDT75 { get; set; }
    //    public string SHDT76 { get; set; }
    //    public string SHDT77 { get; set; }
    //}

    //File Status Report

    public class FileStatusReportModel
    {
        public string ClientID { get; set; }
        public string FileType { get; set; }
        public string ChannelID { get; set; }
        public string TR_POSTDATE { get; set; }
        public string TR_ENDDATE { get; set; }
    }

    public class FileStatusReportDetailsModel
    {
        public string ChannelName { get; set; }
        public string FileName { get; set; }
        public string FileDate { get; set; }
        public string LogType { get; set; }
        public int TransactionCount { get; set; }
        public string UploadStatus { get; set; }
        public string CreateDate { get; set; }
        public string StartTime { get; set; }
        public string CompletionTime { get; set; }
        public string ExecutionTime { get; set; }
        public string ReUploadStatus { get; set; }
    }

    public class FileStatusModel
    {
        public string ClientID { get; set; }
        public string FileType { get; set; }
        public string ChannelID { get; set; }
        public string TR_POSTDATE { get; set; }
        public string TR_ENDDATE { get; set; }
        public string FileStatus { get; set; }
    }

     
    //Dispense Unmatched Report
    public class DispenseUnmatchedModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TERMINALID { get; set; }
        public string Type { get; set; } 
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        //public string ReferenceNumber { get; set; }
    }

    //Dispense Unmatched Report
    public class DispenseUnmatchedReferenceNumberModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TERMINALID { get; set; }        
        public string ReferenceNumber { get; set; }
    }

    public class DispenseUnmatchedReportModel
    {
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string CustAccountNo { get; set; }
        public string TxnsAmount { get; set; }
        public string EJStatus { get; set; }
        public string SWStatus { get; set; }
        public string NWStatus { get; set; }
        public string GLStatus { get; set; }
        public string TxnsSubType { get; set; }
        public string Type { get; set; }
        public string ReconType { get; set; }
        public string OnSettled { get; set; }
    }

    public class DispenseUnmatchedDetailsModel
    {
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string TxnsAmount { get; set; }
        public string ResponseCode { get; set; }
        public string ReversalFlag { get; set; }
        public string EJStatus { get; set; }
    }

    public class NPCIBulkUploadModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TERMINALID { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        public string TxnType { get; set; }
        public string ReportType { get; set; }
    }

    public class NPCIBulkUploadDetailsModel
    {
        public string BankAdjRef { get; set; }
        public string Flag { get; set; }
        public string ShtDat { get; set; }
        public string AdjAmt { get; set; }
        public string ShSer { get; set; }
        public string ShCrd { get; set; }
        public string FileName { get; set; }
        public string Reason { get; set; }
        public string SpecifyOther { get; set; }

    }

    public class DispenseUnmatchedReportByReferenceNumberClick
    {
        public List<DispenseUnmatchedDetailsModel> EJTxnDetails { get; set; }
        public List<DispenseUnmatchedDetailsModel> GLTxnDetails { get; set; }
        public List<DispenseUnmatchedDetailsModel> NWTxnDetails { get; set; }
        public List<DispenseUnmatchedDetailsModel> SWTxnDetails { get; set; }
    }

    //Unsuccessful Txns Report

    public class UnSuccessfulTxnsModel
    {
        public string ClientID { get; set; }
        public string ClientCode { get; set; }
        public string UserName { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TerminalID { get; set; }
        public string TxnType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ReferenceNumber { get; set; }
    }

    public class UnsuccessfulTxnsGridReportModel
    {
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string CustAccountNo { get; set; }
        public string TxnsAmount { get; set; }
        public string EJStatus { get; set; }
        public string SWStatus { get; set; }
        public string NWStatus { get; set; }
        public string GLStatus { get; set; }
        public string TxnsSubType { get; set; }
        public string Remark { get; set; }
    }

    public class UnsuccessfulTxnsDetailsModel
    {
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string TxnsAmount { get; set; }
        public string ResponseCode { get; set; }
        public string ReversalFlag { get; set; }
        public string EJStatus { get; set; }
    }

    public class UnsuccessfulTxnsByReferenceNumber
    {
        public List<UnsuccessfulTxnsDetailsModel> EJTxnDetails { get; set; }
        public List<UnsuccessfulTxnsDetailsModel> GLTxnDetails { get; set; }
        public List<UnsuccessfulTxnsDetailsModel> NWTxnDetails { get; set; }
        public List<UnsuccessfulTxnsDetailsModel> SWTxnDetails { get; set; }
    } 
    public class BankReportModel
    {
        public string TR_POSTDATE { get; set; }
        public string TR_ENDDATE { get; set; }
        public string ReportType { get; set; }
        public string ClientID { get; set; }
    }


    //Export Raw Data Model KUNDAN
    public class ExportRawDataModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string FileType { get; set; }
        public string TR_POSTDATE { get; set; }
        public string TR_ENDDATE { get; set; }

    }

    public class DownloadRawDataModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string FileType { get; set; }
        public string FileLogName { get; set; }
        public string TR_POSTDATE { get; set; }
        public string TR_ENDDATE { get; set; }

    }



    public class ExportRawDataDetailsModel
    {
        public string FileDate { get; set; }
        public string FileName { get; set; }
        public string TxnsCount { get; set; }
        public string CREATEDON { get; set; }
        public string CreatedBy { get; set; }
    }

    public class logTypeModel
    {
        public string ID { get; set; }
        public string LogFileName { get; set; }
    }

    public class TerminalOptModel
    {
        public string ClientID { get; set; }
        public string ID { get; set; }
        public string TERMINALID { get; set; }
    }



    public class InputTerminalModel
    {
        public string ClientID { get; set; }
        public string TERMINALID { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
    }

