﻿namespace ASPTrace.Models;

#nullable disable warnings

public class RoleCreationModel
{
    public string ClientID { get; set; }
    public string RoleID { get; set; }
    public string RoleName { get; set; }
    public string HomePage { get; set; }
    public string IsActive { get; set; }
}


public class RoleAccessRightsModel
{
    public string MenuID { get; set; }
    public string MenuName { get; set; }
    public bool Active { get; set; }
    public string MenuLevel { get; set; }
    public string FilePath { get; set; }
    public string ParentMenuID { get; set; }
    public string MenuType { get; set; }
    public string SequenceNo { get; set; }

}

public class RoleMenuAccessModel
{
    public string MenuID { get; set; }
    public string MenuName { get; set; }
    public bool Active { get; set; }
    public string MenuLevel { get; set; }
    public string FilePath { get; set; }
    public string ParentMenuID { get; set; }
    public string MenuType { get; set; }
    public string SequenceNo { get; set; }    
    public bool IsReport { get; set; }
    public bool IsReportSelected { get; set; }
}



public class RoleDetailsRegModel
{
    public string Mode { get; set; }
    public string RoleID { get; set; }
    public string ClientID { get; set; }
    public string RoleName { get; set; }
    public string HomePage { get; set; }
    public string UserType { get; set; }    
    public string CreatedBy { get; set; }

}

public class RoleDetailsModel
{
    public string Mode { get; set; }
    public string RoleID { get; set; }
    public string RoleName { get; set; }
    public string UserType { get; set; }
    public string RoleMenus { get; set; }
    public string ReportMenuString { get; set; }
    public string CreatedBy { get; set; }

}

public class RoleMenuModel
{
    public string MenuID { get; set; }
    public string MenuName { get; set; }
    public bool Active { get; set; }   
    public bool IsReport { get; set; }
    public bool IsReportSelected { get; set; }    
}

    public class DeleteRoleModel
{
    public string Mode { get; set; }
    public string RoleID { get; set; }

}

public class AssignRoleAccessRightsModel
{
    public string RoleID { get; set; }
    public string ClientID { get; set; }
    public string Menustring { get; set; }
    //public string Username { get; set; }
    public string CreatedBy { get; set; }
    //     public string CreatedOn { get; set; }
    //     public string IsActive { get; set; }
}

public class AssignRoleMenuAccessRightsModel
{
    public string RoleID { get; set; }
    public string ClientID { get; set; }
    public string Menustring { get; set; }
    public string DownloadReportMenustring { get; set; }
    public string CreatedBy { get; set; } 
}

public class MenuAccessModel
{
    public string UserID { get; set; }
    public string RoleID { get; set; }
    public string MenuLevel { get; set; }
    public string ClientID { get; set; }
    public string MenuName { get; set; }
    public string MenuID { get; set; }
    public string FilePath { get; set; }
    public string ParentMenuID { get; set; }
    public string SequenceNo { get; set; }
}

public class SideBarMenuModel
{
    public string MenuName { get; set; }
    public string MenuID { get; set; }
    public string FilePath { get; set; }
    public string ParentMenuID { get; set; }
    public string SequenceNo { get; set; }
    public string MenuClassName { get; set; }
    public IList<SubMenuModel> SubMenus { get; set; }
}

public class SubMenuModel
{
    public string MenuName { get; set; }
    public string MenuID { get; set; }
    public string FilePath { get; set; }
    public string ParentMenuID { get; set; }
    public string SequenceNo { get; set; }
}

public class MenuModel
{
    public string MenuName { get; set; }
    public string MenuID { get; set; }
    public string FilePath { get; set; }
    public string ParentMenuID { get; set; }
    public string SequenceNo { get; set; }
    public string MenuClassName { get; set; }
    public string hasChildMenu { get; set; }
}

public class RoleListModel
{
    public string Mode { get; set; }
    public string RoleID { get; set; }
    public string RoleName { get; set; }
    public string UserType { get; set; }
    public string MakerID { get; set; }
    public string MakerOn { get; set; }
    public string MakerRemarks { get; set; }
    public string CheckerID { get; set; }
    public string CheckerOn { get; set; }
    public string CheckerRemarks { get; set; }
    public string RoleStatus { get; set; }
    public string RoleExists { get; set; }
}

public class ActionModel
{
    public string TrnID { get; set; }
    public string UserName { get; set; }
    public string Remarks { get; set; }
    public string Action { get; set; }
}
 

#nullable restore