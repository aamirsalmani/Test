﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Http;


namespace ASPTrace.Models
{

    public class ChannelRunReconProcessModel
    {
        public string ClientID { get; set; }
        public int ChannelID { get; set; }
        public string ChannelName { get; set; }
    }

    public class ModeRunReconProcessModel
    {
        public string ClientID { get; set; }
        public int ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ModeName { get; set; }
    }

    public class ReconFileStatusProcessModel
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public string Fromdate { get; set; }
        public string Todate { get; set; }
        public string CreatedDate { get; set; }

    }

    public class ReconFileStatusListModel
    {
        public int ClientID { get; set; }
        public int ChannelID { get; set; }
        public int ModeID { get; set; }
        public string Fromdate { get; set; }
        public string Todate { get; set; }

    }

    public class RunReconHistoryRunReconProcessModel
    {
        public string ClientID { get; set; }
        public string ClientName { get; set; }
        public string Fromdate { get; set; }
        public string Todate { get; set; }
        public string Channel { get; set; }
        public string ModeID { get; set; }
        public string ChannelID { get; set; }
        public string Mode { get; set; }
        public string Status { get; set; }
        public string Createdby { get; set; }
        public string CreatedDate { get; set; }
        public string ReconStartOn { get; set; }
        public string ReconEndOn    { get; set; }
        public string TimeTaken     { get; set; }
    }

    public class ReconStatusRunReconProcessModel
    {
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string User { get; set; }
    }

    public class RunReconAddRunReconProcessModel
    {
        public string ClientID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public int ChannelID { get; set; }
        public string Mode { get; set; }
        public string Status { get; set; }
        public string Createdby { get; set; }
        public string CreatedOn { get; set; }
    }
    
    public class DefaultFileCountList
    {
        public string FileType { get; set; }
        public int FileCount { get; set; }
    }

    public class FileCountList
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string GLFile { get; set; }
        public string SwitchFile { get; set; }
        public string NetworkFile { get; set; }
        public int EJTerminalCount { get; set; }
        public DateTime LastReconDate { get; set; }

    }

    public class NPCIReportModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ReportType { get; set; }
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
        public string UserName { get; set; }
        public string? Remark { get; set; }
    }

    public class DeleteReportModel
    {
        public int DeleteId { get; set; }
        public string Role { get; set; }
        public string UserName { get; set; }
    }

    public class ForceRunReconRequest
    {
        public string ForceRemarks { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string ClientId { get; set; }
        public string ChannelId { get; set; }
        public string ModeId { get; set; }
        public string User { get; set; }
    }

    public class RunReconFileStatus
    {
        public string JsonString { get; set; }
        public int ReconStatus { get; set; }
    }


}
