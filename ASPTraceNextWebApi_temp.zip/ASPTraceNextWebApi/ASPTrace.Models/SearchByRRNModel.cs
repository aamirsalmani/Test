﻿
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
 
    public class SearchByRRNModel
    {
        public string ClientID { get; set; }
        public string ReferenceNo { get; set; }
        public string TERMINALID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }
    public class SearchByRRNDetailsModel
    {
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string CustAccountNo { get; set; }
        public string TxnsAmount { get; set; }
        public string ActualTxnsAmount { get; set; }
        public string EJStatus { get; set; }
        public string SWStatus { get; set; }
        public string NWStatus { get; set; }
        public string GLStatus { get; set; }
        public string TxnsSubType { get; set; }
        public string Type { get; set; }
    }
}
