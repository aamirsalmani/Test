﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class GLReconModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string? NetworkType { get; set; }
        public string? FromDateTxns { get; set; }
        public string? ToDateTxns { get; set; }
        //public string TxnDateTime { get; set; } 
    }

    public class SettledTransactionsReportModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string ReferenceNumber { get; set; }
        public string TERMINALID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string TxnType { get; set; }
    }

    public class SettledTransactionsReportDetailsModel
    {
        public string ChannelName { get; set; }
        public string TransactionMode { get; set; }
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string CustAccountNo { get; set; }
        public string TxnsAmount { get; set; }
        public string EJStatus { get; set; }
        public string SWStatus { get; set; }
        public string NWStatus { get; set; }
        public string GLStatus { get; set; }
        public string TxnsSubType { get; set; }
        public string SettledRemarks { get; set; }
        public string OnSettled { get; set; }
 
    }

    public class SettledTransactionsReportDetails1Model
    {
        public string TerminalId { get; set; }
        public string TxnsDateTime { get; set; }
        public string ReferenceNumber { get; set; }
        public string CardNumber { get; set; }
        public string TxnsAmount { get; set; }
        public string ResponseCode { get; set; }
        public string ReversalFlag { get; set; }
        public string EJStatus { get; set; }

    }

    public class SettledTransactionsReportByReferenceNumber
    {
        public List<SettledTransactionsReportDetails1Model> EJTxnDetails { get; set; }
        public List<SettledTransactionsReportDetails1Model> GLTxnDetails { get; set; }
        public List<SettledTransactionsReportDetails1Model> NWTxnDetails { get; set; }
        public List<SettledTransactionsReportDetails1Model> SWTxnDetails { get; set; }
    }
}
