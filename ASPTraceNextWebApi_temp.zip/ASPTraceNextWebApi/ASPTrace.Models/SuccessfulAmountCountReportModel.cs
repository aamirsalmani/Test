﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class SuccessfulAmountCountReportModel
    {
        public string FromDateTxns { get; set; }
        public string ToDateTxns { get; set; }
    }

    public class SuccessfulAmountCountReportDetailsModel
    {
        public string Month { get; set; }
        public string ClientName { get; set; }
        public string Channelname { get; set; }
        public string ModeName { get; set; }
        public string SuccessfulCount { get; set; }
        public string SuccessfulAmount { get; set; }       
    }
}
