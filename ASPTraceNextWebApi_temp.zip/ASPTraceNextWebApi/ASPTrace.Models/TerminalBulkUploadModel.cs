﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
   public class TerminalBulkUploadModel
    {
        public string ClientID { get; set; }
        public IFormFile TerminalFile { get; set; }
    }
}
