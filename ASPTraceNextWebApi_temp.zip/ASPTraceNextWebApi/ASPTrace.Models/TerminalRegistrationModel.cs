﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
   public class TerminalConfigMaster
    {
        public string ID { get; set; }
        public string UserName { get; set; }
        public string Mode { get; set; }
        public string ClientID { get; set; }
        public string ClientName { get; set; }
        public string VendorID { get; set; }
        public string VendorName { get; set; }
        public string BranchID { get; set; }
        public string BranchCode { get; set; }
        public string BranchName { get; set; }
        public string TerminalID { get; set; }
        public string TerminalLocation { get; set; }
        public string StateID { get; set; }
        public string StateName { get; set; }
        public string DistrictID { get; set; }
        public string DistrictName { get; set; }
        public string LocationTypeID { get; set; }
        public string LocationType { get; set; }
        public string ATMMakeTypeID { get; set; }
        public string ATMMakeType { get; set; }
        public string SiteTypeID { get; set; }
        public string SiteType { get; set; }
        public string SiteClassID { get; set; }
        public string SiteClass { get; set; }
        public string GLAccountNo { get; set; }
        public string TerminalTypeID { get; set; }
        public string TerminalType { get; set; }
        public string ContactNo { get; set; }
        public string EmailID { get; set; }
        public string ConcernPerson { get; set; }
        public string Cassette1 { get; set; }
        public string Cassette2 { get; set; }
        public string Cassette3 { get; set; }
        public string Cassette4 { get; set; }
        public string Cassette5 { get; set; }
        public string Cassette6 { get; set; }
        public string CassetteCurrencyCode1 { get; set; }
        public string CassetteCurrencyCode2 { get; set; }
        public string CassetteCurrencyCode3 { get; set; }
        public string CassetteCurrencyCode4 { get; set; }
        public string CassetteCurrencyCode5 { get; set; }
        public string CassetteCurrencyCode6 { get; set; }
        public string IsActive { get; set; }
        public string IsCassetteSwap { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
    }


    public class TerminalConfigMasterNew
    {
        public string ID { get; set; }
        public string ClientID { get; set; }
        public string Mode { get; set; }
        public string VendorID { get; set; }
        public string BranchCode { get; set; }
        public string TerminalID { get; set; }
        public string TerminalLocation { get; set; }
        public string StateID { get; set; }
        public string DistrictID { get; set; }
        public string LocationTypeID { get; set; }
        public string ATMMakeTypeID { get; set; }
        public string SiteTypeID { get; set; }
        public string SiteClassID { get; set; }
        public string GLAccountNo { get; set; }
        public string TerminalTypeID { get; set; }
        public string ContactNo { get; set; }
        public string EmailID { get; set; }
        public string ConcernPerson { get; set; }
        public string Cassette1 { get; set; }
        public string Cassette2 { get; set; }
        public string Cassette3 { get; set; }
        public string Cassette4 { get; set; }
        public string Cassette5 { get; set; }
        public string Cassette6 { get; set; }
        public string CassetteCurrencyCode1 { get; set; }
        public string CassetteCurrencyCode2 { get; set; }
        public string CassetteCurrencyCode3 { get; set; }
        public string CassetteCurrencyCode4 { get; set; }
        public string CassetteCurrencyCode5 { get; set; }
        public string CassetteCurrencyCode6 { get; set; }
        public string IsActive { get; set; }
        public string IsCassetteSwap { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string UserName { get; set; }
}
    public class TerminalState
    {
        public string StateID { get; set; }
        public string StateName { get; set; }
        public string bitIsRemoved { get; set; }
    }

    public class VendorMaster
    {
        public string VendorID { get; set; }
        public string VendorName { get; set; }
        public string VendorTypeID { get; set; }
        public string IsRemoved { get; set; }
    }

    public class LocationTypeMaster
    {
        public string LocationTypeID { get; set; }
        public string LocationType { get; set; }
        public string IsRemoved { get; set; }
    }

    public class ATMMakeTypeMaster
    {
        public string ATMMakeTypeID { get; set; }
        public string ATMMakeType { get; set; }
        public string IsRemoved { get; set; }
    }

    public class SiteTypeMaster
    {
        public string SiteTypeID { get; set; }
        public string SiteType { get; set; }
        public string IsRemoved { get; set; }
    }

    public class SiteClassMaster
    {
        public string SiteClassID { get; set; }
        public string SiteClass { get; set; }
        public string IsRemoved { get; set; }
    }

    public class TerminalTypeMaster
    {
        public string TerminalTypeID { get; set; }
        public string TerminalType { get; set; }
        public string IsRemoved { get; set; }
    }

    public class StateDistrictModel
    {
        public string DistrictID { get; set; }
        public string DistrictName { get; set; }
    }

    public class BranchMaster
    {
        public string BranchID { get; set; }
        public string BranchName { get; set; }
        public string BranchCode { get; set; } 
    }

    public class TerminalRegDeleteModel
    {
        public string ID { get; set; }
        public string Mode { get; set; }
    }

    public class TerminalRegConfigMaster
    {
        public string ID { get; set; }
        public string UserName { get; set; }
        public string Mode { get; set; }
        public string ClientID { get; set; }
        public string ClientName { get; set; }
        public string VendorID { get; set; }
        public string VendorName { get; set; }
        public string BranchCode { get; set; }
        public string BranchName { get; set; }
        public string TerminalID { get; set; }
        public string TerminalLocation { get; set; }
        public string StateID { get; set; }
        public string StateName { get; set; }
        public string DistrictID { get; set; }
        public string DistrictName { get; set; }
        public string LocationTypeID { get; set; }
        public string LocationType { get; set; }
        public string ATMMakeTypeID { get; set; }
        public string ATMMakeType { get; set; }
        public string SiteTypeID { get; set; }
        public string SiteType { get; set; }
        public string SiteClassID { get; set; }
        public string SiteClass { get; set; }
        public string GLAccountNo { get; set; }
        public string TerminalTypeID { get; set; }
        public string TerminalType { get; set; }
        public string ContactNo { get; set; }
        public string EmailID { get; set; }
        public string ConcernPerson { get; set; }
        public string Cassette1 { get; set; }
        public string Cassette2 { get; set; }
        public string Cassette3 { get; set; }
        public string Cassette4 { get; set; }
        public string Cassette5 { get; set; }
        public string Cassette6 { get; set; }
        public string CassetteCurrencyCode1 { get; set; }
        public string CassetteCurrencyCode2 { get; set; }
        public string CassetteCurrencyCode3 { get; set; }
        public string CassetteCurrencyCode4 { get; set; }
        public string CassetteCurrencyCode5 { get; set; }
        public string CassetteCurrencyCode6 { get; set; }
        public string IsActive { get; set; }
        public string IsCassetteSwap { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
    }
}
