﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class TipsAndSurchargeModel
    {
        public string ClientID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }

    public class TipsAndSurchargeDetailsModel
    {
        public string AccountNumber { get; set; }
        public string DrCr { get; set; }
        public string Amount { get; set; }
        public string TxnsParticular { get; set; }
        public string TxnsRemarks { get; set; }
        public string PartitionedAccount { get; set; }
        public string PartitionType { get; set; }
        public string RefNum { get; set; }
        public string ValueDate { get; set; }
        public string InstType { get; set; }
        public string InstDate { get; set; }
        public string InstAlpha { get; set; }
        public string InstNumber { get; set; }
        public string RefCCY { get; set; }
        public string RateCode { get; set; }
        public string LoanFlowID { get; set; }
        public string Rate { get; set; }
        public string AccountCCY { get; set; }
        public string BRANCH { get; set; }

    }
}
