﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models
{
    public class TxnCountModel
    {
        public string ClientID { get; set; }
        public string ChannelID { get; set; }
        public string ModeID { get; set; }
        public string TERMINALID { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
    }

    public class TxnCountDetailsModel
    {
        public string TxnDate { get; set; }
        public string TerminalID { get; set; }
        public string SucessCount { get; set; }
        public string SuccessAmt { get; set; }
        public string UnmatchedCount { get; set; }
        public string UnmatchedAmt { get; set; }
        public string ReversalCount { get; set; }
        public string ReversalAmt { get; set; }
        public string SettledCount { get; set; }
        public string SettledAmt { get; set; }
        public string UnsucessCount { get; set; }
        public string UnsucessAmt { get; set; }
        public string GLCount { get; set; }
        public string NWCount { get; set; }
        public string EJCount { get; set; }
        public string TotalTxnsCount { get; set; }
 
    }
}
