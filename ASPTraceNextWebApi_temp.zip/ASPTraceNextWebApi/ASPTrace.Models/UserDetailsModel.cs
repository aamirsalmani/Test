﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASPTrace.Models;

#nullable disable warnings
    public class UserClientDetailsModel
    {
        public string ClientID { get; set; }
        public string ClientName { get; set; }
    }

    public class UserBranchDetailsModel
    {
        public string ClientID { get; set; }
        public string BranchID { get; set; }
        public string BranchName { get; set; }
    }

    public class UserBranchcodePopDetailsModel
    {
        public string ClientID { get; set; }
        public string BranchCode { get; set; }
        public string BranchID { get; set; }
        public string BranchName { get; set; }
    }

    public class UserRoleDetailsModel
    {
        public string ClientID { get; set; }
        public string RoleID { get; set; }
        public string RoleName { get; set; }
        public string HomePage { get; set; }
        public string IsActive { get; set; }
    }

    public class UserFilterModel
    { 
        public string UserID { get; set; } 
        public string ClientID { get; set; }
        public string BranchID { get; set; }
        public string RoleID { get; set; }
       
    }

    public class DeleteUserModel
    {
        public string ClientID { get; set; } 
        public string UserID { get; set; }
        public string DeletedBy { get; set; }
    }

    public class UserDetailsModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; } 
        public string ClientID { get; set; }
        public string BranchID { get; set; }
        public string RoleID { get; set; }
        public string UserID { get; set; }
        public string ConfirmPassword { get; set; }
        public string Password { get; set; }
        public string CreatedBy { get; set; }
        public string EmailID { get; set; }
        public string BranchTerminalID { get; set; }
        public string ContactNo { get; set; }
        public string ChannelModeConfig { get; set; }
    }
       
    public class UpdateDetailsModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; } 
        public string ClientID { get; set; }
        public string BranchID { get; set; }
        public string RoleID { get; set; }
        public string UserID { get; set; }
        public string EmailID { get; set; }
        public string ContactNo { get; set; }
        public string RoleName {get; set;}
        public string BranchName {get; set;}
        public string ChannelModeConfig { get; set; }
        public string ClientName { get; set; }
        public bool UserExists { get; set; }
        public string UserStatus { get; set; }
    }


     public class GetUserResetPassModel
    {
       
        public string ClientID { get; set; }
        public string UserID { get; set; }
        public string ConfirmPassword { get; set; }
        public string CreatedBy { get; set; }
        public string NewSalt{get; set;}
       
    }

    
    public class UpdateUserModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; } 
       
        public string BranchID { get; set; }
        public string RoleID { get; set; }
        public string UserID { get; set; }
        
        // public string CreatedBy { get; set; }
        public string EmailID { get; set; }
      
        public string ContactNo { get; set; }
        
    }

    public class RoleAccessList
    {
        public string UserID { get; set; }
        public string ClientID { get; set; }  
    }

     public class AssignRoleAccessModel
    {
       
        public string ClientID { get; set; }
        public string Menustring { get; set; }
        public string Username { get; set; }
        public string CreatedBy { get; set; }
    //     public string CreatedOn { get; set; }
    //     public string IsActive { get; set; }
     }
    
    
    

    public class UserDetailsGridModel
    {
        public string ID { get; set; }
        public string UserID { get; set; }
        public string EmailID { get; set; }
        public string RoleName { get; set; }
        public string BranchName { get; set; }
        public string ClientName { get; set; }
        public string ClientID { get; set; }
        public string IsActivate { get; set; }
        public string BranchTerminalID { get; set; }
        public string RoleID { get; set; }
        public string BranchID { get; set; }
        public string MakerID { get; set; }
        public string MakerOn { get; set; }
        public string MakerRemarks { get; set; }
        public string CheckerID { get; set; }
        public string CheckerOn { get; set; }
        public string CheckerRemarks { get; set; }
        public bool UserExists { get; set; }
        public string UserStatus { get; set; }
    }

    public class UserResetPasswordModel
    {
        public string NewSalt { get; set; }
        public string ConfirmPassword { get; set; }
        public string Salt1 { get; set; }
        public string Salt2 { get; set; }
        public string Salt3 { get; set; }
        public string Salt4 { get; set; }
        public string Password1 { get; set; }
        public string Password2 { get; set; }
        public string Password3 { get; set; }
        public string Password4 { get; set; }
        public string PasswordType { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedOn { get; set; }
        public string UserID { get; set; }
        public string ClientID { get; set; }
        public string Type { get; set; }
    }

    public class UserAddUserUpdateModel
    {
        public string EmailID { get; set; }
        public string RoleID { get; set; }
        public string BranchID { get; set; }
        public string BranchTerminalID { get; set; }
        public string TerminalID { get; set; }
        public string ClientID { get; set; }
        public string UserID { get; set; }
        public string USERNAME { get; set; }
        public string IsApproved { get; set; }
    }

    public class UserAddUserDeleteModel
    {
        public string IsActivate { get; set; }
        public string CreatedBy { get; set; }
        public string UserID { get; set; }
    }

    public class PasswordModel
    { 
       public string ClientCode { get; set; } 
        public string UserID { get; set; }
        public string OldPassword { get; set; }
        public string ConfirmPassword { get; set; }
        public string NewPassword { get; set; }
        
        public string NewSalt { get; set; }
        public string CreatedBy { get; set; } 
        

    }

    public class PasswordHistoryModel
    {
        public string Password1 { get; set; }
        public string Password2 { get; set; }
        public string Password3 { get; set; }
        public string Password4 { get; set; }
    }

    public class ResetPasswordModel
    {
        public string ClientCode { get; set; }
        public string UserID { get; set; } 
        public string NewPassword { get; set; } 
        public string NewSalt { get; set; }
        public string CreatedBy { get; set; } 
    }

    //public class UserChannelModeDetails
    //{
    //    public string ChannelID { get; set; }
    //    public string ChannelName { get; set; }
    //    public string ModeID { get; set; }
    //    public string ClientCode { get; set; }
    //    public string CreatedBy { get; set; }
    //}

    public class UserChannelModeDetails
    {
        public string clientID { get; set; }
        public string userID { get; set; }    
        public string channelID { get; set; }
        public string channelName { get; set; }
        public bool onus { get; set; }
        public bool acquirer { get; set; }
        public bool issuer { get; set; }
        public string createdBy { get; set; }
    }

    public class UserClientChannelModeDetails
{
        public string ChannelID { get; set; }
        public string UserID { get; set; }
        public string ChannelName { get; set; }
        public string ModeID { get; set; }
        public string ClientID { get; set; }
        public string CreatedBy { get; set; }
    }

    public class UserChannelModeConfig
    {
        public string UserID { get; set; }
        public string ClientID { get; set; }
        public string ClientChannelModes { get; set; }
        public string CreatedBy { get; set; }
    }

    public class UserFilterModel2
    {
        public string UserID { get; set; } 
        public string Status { get; set; }

    }

    public class ClientBranchDetailsModel
    {
        public string ClientID { get; set; }
        public string BranchID { get; set; }
        public string BranchName { get; set; }
        public string BranchCode { get; set; }
        public string BranchAddress { get; set; }
        public bool Selected { get; set; }
    }

#nullable restore