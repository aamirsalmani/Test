﻿namespace ASPTrace.Models;

#nullable disable warnings

public class VendorRegModel
{
    public string ID { get; set; }
    public string VendorName { get; set; }
    public int VendorTypeID { get; set; }
    public string VendorType { get; set; }
    //public string VendorId { get; set; }
    public string VendorID { get; set; }
}

public class VendorRegDetailsModel
{
    public string Mode { get; set; }
    public string VendorID { get; set; }
    public string VendorName { get; set; }
    public int VendorTypeID { get; set; }
    public string CreatedBy { get; set; }
    public string Vendor { get; set; }
    // public string IsRemoved { get; set; }
}

public class VendorRegAddModel
{
    public string VendorName { get; set; }
    public string VendorID { get; set; }
    public int VendorTypeID { get; set; }
    public string CreatedOn { get; set; }
    public string CreatedBy { get; set; }
    public string IsRemoved { get; set; }
}

public class VendorRegUpdateModel
{
    public string VendorName { get; set; }
    public int VendorTypeID { get; set; }
    public string ModifiedOn { get; set; }
    public string ModifiedBy { get; set; }
    public string VendorID { get; set; }
}

public class VendorRegDeleteModel
{
    public string Mode { get; set; }
    public string VendorID { get; set; }
}


public class VendorTypeModel
{
    public string Id { get; set; }
    public string VendorType { get; set; }
}

#nullable restore