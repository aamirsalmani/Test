﻿using Microsoft.Extensions.Configuration;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;
using System.Data.SqlClient;


namespace ASPTrace.Repository
{
    public class AlertConfigRepository : IAlertConfig
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public AlertConfigRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public string SaveAlertConfig(DataTable alertTable, DataTable escalationTable)
        {
            string status = string.Empty;
            string message = string.Empty;
            int alertId = 0;

            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    param.Add("@AddUpdate", 1);
                    param.Add("@tblAlertData", alertTable, DbType.Object);
                    param.Add("@tblEscalationData", escalationTable, DbType.Object);

                    var result = connection.QueryFirstOrDefault<dynamic>("sp_SaveAlertConfig", param, commandType: CommandType.StoredProcedure);
                    status = result?.Status;
                    alertId = result?.AlertID;
                    message = result?.Message;
                }
            }
            catch (Exception ex) 
            {
                return "Error occurred in API";
            }
            if(status == "ERROR")
            {
                return message;
            }
            else
            {
                return status;
            }
        }

        public List<AlertConfigDataModel> GetAlertConfigDataList(string ClientID, string AlertTypeID, string AlertSeverityID, string CreatedBy)
        {
            List<AlertConfigDataModel> LogOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@AlertTypeID", AlertTypeID);
                param.Add("@AlertSeverityID", AlertSeverityID);
                param.Add("@CreatedBy", CreatedBy);
                LogOptionModelsList = connection.Query<AlertConfigDataModel>("sp_GetAlertConfigList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (LogOptionModelsList == null)
            {
                LogOptionModelsList = new List<AlertConfigDataModel>();
            }
            return LogOptionModelsList;
        }

        public List<dynamic> GetAdditionalDataByAlertID(int AlertID, string Type)
        {
            List<dynamic> DataOutput = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@AlertID", AlertID);
                param.Add("@Type", Type);
                DataOutput = connection.Query<dynamic>("sp_GetAlertConfigAdditionalData", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (DataOutput == null)
            {
                DataOutput = new List<dynamic>();
            }
            return DataOutput;
        }
    }
}
