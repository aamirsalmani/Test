﻿ 
using System.Data;
using System.Data.SqlClient;
using Dapper;
using Microsoft.Extensions.Configuration;
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTrace.Repository
{
    public class AuditReportRepository : IAuditReport
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public AuditReportRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<SettledTransactionsReportDetailsModel> GetSettledTransactionsReport(SettledTransactionsReportModel settledTransactionsReportModel)
        {
            List<SettledTransactionsReportDetailsModel> settledTransactionsReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", settledTransactionsReportModel.ClientID);
                param.Add("@ChannelID", settledTransactionsReportModel.ChannelID);
                param.Add("@ModeID", settledTransactionsReportModel.ModeID);
                param.Add("@TERMINALID", settledTransactionsReportModel.TERMINALID);
                param.Add("@FromDateTxns", settledTransactionsReportModel.FromDate);
                param.Add("@ToDateTxns", settledTransactionsReportModel.ToDate);
                param.Add("@TxnType", settledTransactionsReportModel.TxnType);

                settledTransactionsReportList = connection.Query<SettledTransactionsReportDetailsModel>("UspSettlementTxns_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (settledTransactionsReportList == null)
            {
                settledTransactionsReportList = new List<SettledTransactionsReportDetailsModel>();
            }

            return settledTransactionsReportList;
        }


        public SettledTransactionsReportByReferenceNumber GetSettledTransactionsReportByReferenceNumber(SettledTransactionsReportModel settledTransactionsReportModel)
        {
            SettledTransactionsReportByReferenceNumber settledTransactionsReportByReferenceNumber = new SettledTransactionsReportByReferenceNumber();
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ReferenceNumber", settledTransactionsReportModel.ReferenceNumber);
                param.Add("@TERMINALID", settledTransactionsReportModel.TERMINALID);
                param.Add("@ClientID", settledTransactionsReportModel.ClientID);

                settledTransactionsReportByReferenceNumber.EJTxnDetails = connection.Query<SettledTransactionsReportDetails1Model>("spEJTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                settledTransactionsReportByReferenceNumber.GLTxnDetails = connection.Query<SettledTransactionsReportDetails1Model>("spGLTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                settledTransactionsReportByReferenceNumber.SWTxnDetails = connection.Query<SettledTransactionsReportDetails1Model>("spSWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                param.Add("@Channel", settledTransactionsReportModel.ChannelID);
                param.Add("@Mode", settledTransactionsReportModel.ModeID);

                settledTransactionsReportByReferenceNumber.NWTxnDetails = connection.Query<SettledTransactionsReportDetails1Model>("UspNWTxnDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (settledTransactionsReportByReferenceNumber.EJTxnDetails == null)
            {
                settledTransactionsReportByReferenceNumber.EJTxnDetails = new List<SettledTransactionsReportDetails1Model>();
            }

            if (settledTransactionsReportByReferenceNumber.GLTxnDetails == null)
            {
                settledTransactionsReportByReferenceNumber.GLTxnDetails = new List<SettledTransactionsReportDetails1Model>();
            }

            if (settledTransactionsReportByReferenceNumber.NWTxnDetails == null)
            {
                settledTransactionsReportByReferenceNumber.NWTxnDetails = new List<SettledTransactionsReportDetails1Model>();
            }

            if (settledTransactionsReportByReferenceNumber.SWTxnDetails == null)
            {
                settledTransactionsReportByReferenceNumber.SWTxnDetails = new List<SettledTransactionsReportDetails1Model>();
            }

            return settledTransactionsReportByReferenceNumber;
        }

        public List<ATMChargesReportDetailsModel> GetATMChargesReportDetails(ATMChargesReportModel aTMChargesReportModel)
        {
            List<ATMChargesReportDetailsModel> aTMChargesReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_POSTDATE", aTMChargesReportModel.TR_POSTDATE);
                param.Add("@TR_ENDDATE", aTMChargesReportModel.TR_ENDDATE);
                param.Add("@ClientID", aTMChargesReportModel.ClientID);
                param.Add("@TxnMode", aTMChargesReportModel.TxnMode);

                aTMChargesReportList = connection.Query<ATMChargesReportDetailsModel>("Proc_NPCI_Settlement_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (aTMChargesReportList == null)
            {
                aTMChargesReportList = new List<ATMChargesReportDetailsModel>();
            }

            return aTMChargesReportList;
        }

        public DataTable GetBankSettlementReportDetails(BankReportModel bankSettlementReportModel)
        {
            DataTable dt = new DataTable();

            string StoredProc = "usp_ATM_Settlement_Report";

            if (bankSettlementReportModel.ReportType == "1")
            {
                StoredProc = "usp_ATM_Settlement_Report";
            }
            else if (bankSettlementReportModel.ReportType == "2")
            {
                StoredProc = "usp_IMPS_Settlement_Report";
            }
            else if (bankSettlementReportModel.ReportType == "3")
            {
                StoredProc = "usp_UPI_Settlement_Report";
            }
            else if (bankSettlementReportModel.ReportType == "4")
            {
                StoredProc = "usp_POS_Settlement_Report";
            }
            else if (bankSettlementReportModel.ReportType == "8")
            {
                StoredProc = "usp_POS_Settlement_Report";
            }

            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(StoredProc, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000000;

                    cmd.Parameters.AddWithValue("@TR_POSTDATE", SqlDbType.DateTime).Value = bankSettlementReportModel.TR_POSTDATE;
                    cmd.Parameters.AddWithValue("@TR_ENDDATE", SqlDbType.DateTime).Value = bankSettlementReportModel.TR_ENDDATE;
                    cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = bankSettlementReportModel.ClientID;
                    if (bankSettlementReportModel.ReportType == "4")
                    {
                        cmd.Parameters.AddWithValue("@SettlementType", SqlDbType.VarChar).Value = "4";
                    }
                    else if (bankSettlementReportModel.ReportType == "8")
                    {
                        cmd.Parameters.AddWithValue("@SettlementType", SqlDbType.VarChar).Value = "8";
                    }

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                    //if (bankSettlementReportModel.ReportType == "2")
                    //{
                    //    if (!dt.Columns.Contains("NPCI Outward Raw Total Amount"))
                    //        dt.Columns.Add("NPCI Outward Raw Total Amount", typeof(decimal));
                    //    if (!dt.Columns.Contains(" NPCI Outward Raw VS Settlement Outward Amount Difference"))
                    //        dt.Columns.Add("NPCI Outward Raw VS Settlement Outward Amount Difference", typeof(decimal));

                    //    // ✅ Copy value from "Beneficiary/Remitter Sub Totals_Debit"
                    //    if (dt.Columns.Contains("Beneficiary/Remitter Sub Totals_Debit"))
                    //    {
                    //        foreach (DataRow row in dt.Rows)
                    //        {
                    //            if (decimal.TryParse(row["Beneficiary/Remitter Sub Totals_Debit"]?.ToString(), out decimal val))
                    //            {
                    //                row["NPCI Outward Raw Total Amount"] = val;
                    //                row["NPCI Outward Raw VS Settlement Outward Amount Difference"] = 0;
                    //            }
                    //            else
                    //            {
                    //                row["NPCI Outward Raw Total Amount"] = 0;
                    //                row["NPCI Outward Raw VS Settlement Outward Amount Difference"] = 0;
                    //            }
                    //        }
                    //    }


                    //    if (!dt.Columns.Contains("NPCI Inward Raw Total Amount"))
                    //        dt.Columns.Add("NPCI Inward Raw Total Amount", typeof(decimal));
                    //    if (!dt.Columns.Contains(" NPCI Inward Raw VS Settlement Outward Amount Difference"))
                    //        dt.Columns.Add("NPCI Inward Raw VS Settlement Outward Amount Difference", typeof(decimal));

                    //    // ✅ Copy value from "Beneficiary/Remitter Sub Totals_Debit"
                    //    if (dt.Columns.Contains("Beneficiary/Remitter Sub Totals_Credit"))
                    //    {
                    //        foreach (DataRow row in dt.Rows)
                    //        {
                    //            if (decimal.TryParse(row["Beneficiary/Remitter Sub Totals_Credit"]?.ToString(), out decimal val))
                    //            {
                    //                row["NPCI Inward Raw Total Amount"] = val;
                    //                row["NPCI Inward Raw VS Settlement Outward Amount Difference"] = 0;
                    //            }
                    //            else
                    //            {
                    //                row["NPCI Inward Raw Total Amount"] = 0;
                    //                row["NPCI Inward Raw VS Settlement Outward Amount Difference"] = 0;
                    //            }
                    //        }
                    //    }
                    //}
                    //else if (bankSettlementReportModel.ReportType == "3")
                    //{
                    //    if (!dt.Columns.Contains("NPCI Outward Raw Total Amount"))
                    //        dt.Columns.Add("NPCI Outward Raw Total Amount", typeof(decimal));
                    //    if (!dt.Columns.Contains(" NPCI Outward Raw VS Settlement Outward Amount Difference"))
                    //        dt.Columns.Add("NPCI Outward Raw VS Settlement Outward Amount Difference", typeof(decimal));

                    //    // ✅ Copy value from "Beneficiary/Remitter Sub Totals_Debit"
                    //    if (dt.Columns.Contains("Beneficiary / Remitter Sub Totals_Credit"))
                    //    {
                    //        foreach (DataRow row in dt.Rows)
                    //        {
                    //            if (decimal.TryParse(row["Beneficiary / Remitter Sub Totals_Debit"]?.ToString(), out decimal val))
                    //            {
                    //                row["NPCI Outward Raw Total Amount"] = val;
                    //                row["NPCI Outward Raw VS Settlement Outward Amount Difference"] = 0;
                    //            }
                    //            else
                    //            {
                    //                row["NPCI Outward Raw Total Amount"] = 0;
                    //                row["NPCI Outward Raw VS Settlement Outward Amount Difference"] = 0;
                    //            }
                    //        }
                    //    }

                    //    if (!dt.Columns.Contains("NPCI Inward Raw Total Amount"))
                    //        dt.Columns.Add("NPCI Inward Raw Total Amount", typeof(decimal));
                    //    if (!dt.Columns.Contains(" NPCI Inward Raw VS Settlement Outward Amount Difference"))
                    //        dt.Columns.Add("NPCI Inward Raw VS Settlement Outward Amount Difference", typeof(decimal));

                    //    // ✅ Copy value from "Beneficiary/Remitter Sub Totals_Debit"
                    //    if (dt.Columns.Contains("Beneficiary / Remitter Sub Totals_Credit"))
                    //    {
                    //        foreach (DataRow row in dt.Rows)
                    //        {
                    //            if (decimal.TryParse(row["Beneficiary / Remitter Sub Totals_Credit"]?.ToString(), out decimal val))
                    //            {
                    //                row["NPCI Inward Raw Total Amount"] = val;
                    //                row["NPCI Inward Raw VS Settlement Outward Amount Difference"] = 0;
                    //            }
                    //            else
                    //            {
                    //                row["NPCI Inward Raw Total Amount"] = 0;
                    //                row["NPCI Inward Raw VS Settlement Outward Amount Difference"] = 0;
                    //            }
                    //        }
                    //    }
                    //}
                }
            }

            return dt;
        }

        public List<POSSettlementReportDetailsModel> GetPOSSettlementReportDetails(POSSettlementReportModel pOSSettlementReportModel)
        {
            List<POSSettlementReportDetailsModel> pOSSettlementReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", pOSSettlementReportModel.ClientID);
                param.Add("@SettlementType", pOSSettlementReportModel.SettlementType);
                param.Add("@TR_POSTDATE", pOSSettlementReportModel.TR_POSTDATE);
                param.Add("@TR_ENDDATE", pOSSettlementReportModel.TR_ENDDATE);

                pOSSettlementReportList = connection.Query<POSSettlementReportDetailsModel>("uspPOSSettlementReport_Core", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (pOSSettlementReportList == null)
            {
                pOSSettlementReportList = new List<POSSettlementReportDetailsModel>();
            }

            return pOSSettlementReportList;
        }

        public List<RefundTxnsReportDetailsModel> GetRefundTxnsReportDetails(RefundTxnsReportModel refundTxnsReportModel)
        {
            List<RefundTxnsReportDetailsModel> refundTxnsReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", refundTxnsReportModel.ClientID);
                param.Add("@FROMDATE", refundTxnsReportModel.FROMDATE);
                param.Add("@TODATE", refundTxnsReportModel.TODATE);

                refundTxnsReportList = connection.Query<RefundTxnsReportDetailsModel>("spRefundTxnsReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (refundTxnsReportList == null)
            {
                refundTxnsReportList = new List<RefundTxnsReportDetailsModel>();
            }

            return refundTxnsReportList;
        }
        public List<IMPSSettlementReportDetailsModel> GetIMPSSettlementReportDetails(IMPSSettlementReportModel iMPSSettlementReportModel)
        {
            List<IMPSSettlementReportDetailsModel> iMPSSettlementReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_POSTDATE", iMPSSettlementReportModel.TR_POSTDATE);
                param.Add("@TR_ENDDATE", iMPSSettlementReportModel.TR_ENDDATE);
                param.Add("@ClientID", iMPSSettlementReportModel.ClientID);

                iMPSSettlementReportList = connection.Query<IMPSSettlementReportDetailsModel>("Proc_IMPS_Settlement_New", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (iMPSSettlementReportList == null)
            {
                iMPSSettlementReportList = new List<IMPSSettlementReportDetailsModel>();
            }

            return iMPSSettlementReportList;
        }


        public DataTable GetIMPSSettlementReport(IMPSSettlementReportModel iMPSSettlementReportModel)
        {
            DataTable dt = new DataTable();
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("Proc_IMPS_Settlement_New", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000000;

                    cmd.Parameters.AddWithValue("@TR_POSTDATE", SqlDbType.DateTime).Value = iMPSSettlementReportModel.TR_POSTDATE;
                    cmd.Parameters.AddWithValue("@TR_ENDDATE", SqlDbType.DateTime).Value = iMPSSettlementReportModel.TR_ENDDATE;
                    cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = iMPSSettlementReportModel.ClientID;

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                }
            }

            return dt;
        }

        public DataTable GetUPISettlementReportDetails(UPISettlementReportModel uPISettlementReportModel)
        {
            //List<UPISettlementReportDetailsModel> uPISettlementReportList = null;
            //using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString)
            //{
            //    connection.Open();
            //    var param = new DynamicParameters();
            //    param.Add("@TR_POSTDATE", uPISettlementReportModel.TR_POSTDATE);
            //    param.Add("@TR_ENDDATE", uPISettlementReportModel.TR_ENDDATE);
            //    param.Add("@ClientID", uPISettlementReportModel.ClientID);

            //    uPISettlementReportList = connection.Query<UPISettlementReportDetailsModel>("Proc_UPI_Settlement_Report", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
            //}

            //if (uPISettlementReportList == null)
            //{
            //    uPISettlementReportList = new List<UPISettlementReportDetailsModel>();
            //}

            //return uPISettlementReportList;

            DataTable dt = new DataTable();
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("Proc_UPI_Settlement_Report", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000000;

                    cmd.Parameters.AddWithValue("@TR_POSTDATE", SqlDbType.DateTime).Value = uPISettlementReportModel.TR_POSTDATE;
                    cmd.Parameters.AddWithValue("@TR_ENDDATE", SqlDbType.DateTime).Value = uPISettlementReportModel.TR_ENDDATE;
                    cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = uPISettlementReportModel.ClientID;

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                }
            }

            return dt;
        }

        public List<RefundCashbackTTUMReportDetailsModel> GetRefundCashbackTTUMReportDetails(RefundCashbackTTUMReportModel refundCashbackTTUMReportModel)
        {
            List<RefundCashbackTTUMReportDetailsModel> refundCashbackTTUMReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", refundCashbackTTUMReportModel.ClientID);
                param.Add("@FromDateTxns", refundCashbackTTUMReportModel.FromDate);
                param.Add("@ToDateTxns", refundCashbackTTUMReportModel.ToDate);

                refundCashbackTTUMReportList = connection.Query<RefundCashbackTTUMReportDetailsModel>("UspRefundAndCashbackTTUM_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (refundCashbackTTUMReportList == null)
            {
                refundCashbackTTUMReportList = new List<RefundCashbackTTUMReportDetailsModel>();
            }

            return refundCashbackTTUMReportList;
        }

        public List<dynamic> GetAdjustmentTxnsReport(AdjustmentTxnsModel adjustmentTxnsModel)
        {
            List<dynamic> AdjustmentList  = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", adjustmentTxnsModel.ClientID);
                param.Add("@TR_POSTDATE", adjustmentTxnsModel.TR_POSTDATE);
                param.Add("@TR_ENDDATE", adjustmentTxnsModel.TR_ENDDATE);
                param.Add("@ReportType", adjustmentTxnsModel.ReportType);

                AdjustmentList = connection.Query<dynamic>("UspAdjustmentTxnsReport_Core", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }
            if (AdjustmentList == null)
            {
                AdjustmentList = new List<dynamic>();
            }

            return AdjustmentList;
        }

        public List<FileStatusReportDetailsModel> GetFileStatusReportDetails(FileStatusModel fileUploadStatus)
        {
            List<FileStatusReportDetailsModel> FileStatusReportDetailsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", fileUploadStatus.ClientID);
                param.Add("@FileType", fileUploadStatus.FileType);
                param.Add("@ChannelID", fileUploadStatus.ChannelID);
                param.Add("@TR_POSTDATE", fileUploadStatus.TR_POSTDATE);
                param.Add("@TR_ENDDATE", fileUploadStatus.TR_ENDDATE);
                param.Add("@file_status", fileUploadStatus.FileStatus);

                FileStatusReportDetailsModelList = connection.Query<FileStatusReportDetailsModel>("SpDynamicFileUploadStatusReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (FileStatusReportDetailsModelList == null)
            {
                FileStatusReportDetailsModelList = new List<FileStatusReportDetailsModel>();
            }
            return FileStatusReportDetailsModelList;
        }

        //NPCI Bulk Upload
        public List<dynamic> GetNPCIBulkUploadDetails(NPCIBulkUploadModel npciBulkUploadModel)
        {
            List<dynamic> NPCIBulkUploadList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", npciBulkUploadModel.ClientID);
                param.Add("@ChannelID", npciBulkUploadModel.ChannelID);
                param.Add("@ModeID", npciBulkUploadModel.ModeID);
                param.Add("@TERMINALID", npciBulkUploadModel.TERMINALID);
                param.Add("@FromDateTxns", npciBulkUploadModel.FromDateTxns);
                param.Add("@ToDateTxns", npciBulkUploadModel.ToDateTxns);
                param.Add("@TxnType", npciBulkUploadModel.TxnType);
                param.Add("@ReportType", npciBulkUploadModel.ReportType);

                NPCIBulkUploadList = connection.Query<dynamic>("spUnmatchedTxnsReport_bulk_upi", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (NPCIBulkUploadList == null)
            {
                NPCIBulkUploadList = new List<dynamic>();
            }
            return NPCIBulkUploadList;
        }

        //IMPS Bank Format Settlement
        public DataSet GetBankFormatSettlementdetailsIMPS(BankReportModel impsBankFormatSettlementInputModel)
        {

            DataSet ds = new DataSet();
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("usp_IMPS_Settlement_BankFormat_withCount", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000000;

                    cmd.Parameters.AddWithValue("@TR_POSTDATE", SqlDbType.DateTime).Value = impsBankFormatSettlementInputModel.TR_POSTDATE;
                    cmd.Parameters.AddWithValue("@TR_ENDDATE", SqlDbType.DateTime).Value = impsBankFormatSettlementInputModel.TR_ENDDATE;
                    cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = impsBankFormatSettlementInputModel.ClientID;
                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(ds);
                    }
                }
            }

            return ds;

        }

        //UPI Bank Format Settlement
        public DataSet GetBankFormatSettlementdetailsUPI(BankReportModel upiBankFormatSettlementInputModel)
        {

            DataSet ds = new DataSet();
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("usp_UPI_Settlement_BankFormat_WithCount", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000000;

                    cmd.Parameters.AddWithValue("@TR_POSTDATE", SqlDbType.DateTime).Value = upiBankFormatSettlementInputModel.TR_POSTDATE;
                    cmd.Parameters.AddWithValue("@TR_ENDDATE", SqlDbType.DateTime).Value = upiBankFormatSettlementInputModel.TR_ENDDATE;
                    cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = upiBankFormatSettlementInputModel.ClientID;
                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(ds);
                    }
                }
            }

            return ds;

        }

        public string ChangeUploadStatus(string filename)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@filename", filename);  // Correct parameter name if different

                int rowsAffected = connection.Execute("SpReuploadStatus", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure);

                // Check if rows were affected
                if (rowsAffected > 0)
                {
                    result = "Success";
                }
                else
                {
                    result = "No rows affected or failure";
                }
            }

            return result;
        }

        //ExportRawData KUNDAN
        public DataTable GetExportRawDataDetails(ExportRawDataModel exportRawDataModel)
        {
            DataTable dt = new DataTable();
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (var cmd = new System.Data.SqlClient.SqlCommand("spShowRawDataFileName", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000000;

                    cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = exportRawDataModel.ClientID;
                    cmd.Parameters.AddWithValue("@ChannelID", SqlDbType.Int).Value = exportRawDataModel.ChannelID;
                    cmd.Parameters.AddWithValue("@ModeID", SqlDbType.Int).Value = exportRawDataModel.ModeID;
                    cmd.Parameters.AddWithValue("@FileType", SqlDbType.VarChar).Value = exportRawDataModel.FileType;
                    cmd.Parameters.AddWithValue("@TR_POSTDATE", SqlDbType.DateTime).Value = exportRawDataModel.TR_POSTDATE ?? (object)DBNull.Value;
                    cmd.Parameters.AddWithValue("@TR_ENDDATE", SqlDbType.DateTime).Value = exportRawDataModel.TR_ENDDATE ?? (object)DBNull.Value;



                    using (var sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                }
            }

            return dt;
        }

        public DataTable ExportCsvReportKS(DownloadRawDataModel downloadRawDataModel)
        {
            try
            {
                DataTable dt = new DataTable();
                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (var cmd = new System.Data.SqlClient.SqlCommand("spGetRawDataFileName", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 1000000;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = downloadRawDataModel.ClientID;
                        cmd.Parameters.AddWithValue("@ChannelID", SqlDbType.Int).Value = downloadRawDataModel.ChannelID;
                        cmd.Parameters.AddWithValue("@ModeID", SqlDbType.Int).Value = downloadRawDataModel.ModeID;
                        cmd.Parameters.AddWithValue("@FileType", SqlDbType.VarChar).Value = downloadRawDataModel.FileType;
                        cmd.Parameters.AddWithValue("@FileLogName", SqlDbType.VarChar).Value = downloadRawDataModel.FileLogName;
                        cmd.Parameters.AddWithValue("@TR_POSTDATE", SqlDbType.DateTime).Value = downloadRawDataModel.TR_POSTDATE ?? (object)DBNull.Value;
                        cmd.Parameters.AddWithValue("@TR_ENDDATE", SqlDbType.DateTime).Value = downloadRawDataModel.TR_ENDDATE ?? (object)DBNull.Value;



                        using (var sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public DataTable ExportExcelReportKS(DownloadRawDataModel downloadRawDataModel)
        {
            try
            {
                DataTable dt = new DataTable();
                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (var cmd = new System.Data.SqlClient.SqlCommand("spGetRawDataFileName", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 1000000;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = downloadRawDataModel.ClientID;
                        cmd.Parameters.AddWithValue("@ChannelID", SqlDbType.Int).Value = downloadRawDataModel.ChannelID;
                        cmd.Parameters.AddWithValue("@ModeID", SqlDbType.Int).Value = downloadRawDataModel.ModeID;
                        cmd.Parameters.AddWithValue("@FileType", SqlDbType.VarChar).Value = downloadRawDataModel.FileType;
                        cmd.Parameters.AddWithValue("@FileLogName", SqlDbType.VarChar).Value = downloadRawDataModel.FileLogName;
                        cmd.Parameters.AddWithValue("@TR_POSTDATE", SqlDbType.DateTime).Value = downloadRawDataModel.TR_POSTDATE ?? (object)DBNull.Value;
                        cmd.Parameters.AddWithValue("@TR_ENDDATE", SqlDbType.DateTime).Value = downloadRawDataModel.TR_ENDDATE ?? (object)DBNull.Value;



                        using (var sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public List<logTypeModel> GetLogList(string ChannelID)
        {
            List<logTypeModel> data = new List<logTypeModel>();

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var parameters = new { ChannelID = ChannelID };
                data = connection.Query<logTypeModel>(
                    "uspGetLogFileType",
                    parameters,
                    commandType: System.Data.CommandType.StoredProcedure
                ).AsList();
            }

            return data ?? new List<logTypeModel>();
        }

        public DataSet GetGLReconReport(GLReconModel ParamsModel)
        {
            DataSet ds = new DataSet();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("ClientWiseGLReconReport", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Adding parameters to the command
                    command.Parameters.Add(new SqlParameter("@ClientID", ParamsModel.ClientID));
                    command.Parameters.Add(new SqlParameter("@ChannelID", ParamsModel.ChannelID));
                    command.Parameters.Add(new SqlParameter("@ModeID", ParamsModel.ModeID));
                    //command.Parameters.Add(new SqlParameter("@NetworkType", ParamsModel.NetworkType));
                    command.Parameters.Add(new SqlParameter("@FromDateTxns", ParamsModel.FromDateTxns));
                    command.Parameters.Add(new SqlParameter("@ToDateTxns", ParamsModel.ToDateTxns));

                    // Using SqlDataAdapter to fill the DataTable
                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(ds);
                    }
                }
            }

            return ds;
        }


    }
}
