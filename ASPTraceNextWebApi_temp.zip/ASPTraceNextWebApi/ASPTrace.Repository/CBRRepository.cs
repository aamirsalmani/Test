﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTrace.Repository
{
    public class CBRRepository : ICBR
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public CBRRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected System.Data.IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<C3RReportDetailsModel> GetC3RReportDetails(C3RReportModel c3RReportModel)
        {
            List<C3RReportDetailsModel> c3RReportList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TERMINALID", c3RReportModel.TERMINALID);
                param.Add("@clientid", c3RReportModel.ClientID);
                param.Add("@FromDateTxns", c3RReportModel.FROMDATE);
                param.Add("@ToDateTxns", c3RReportModel.TODATE);

                c3RReportList = connection.Query<C3RReportDetailsModel>("Proc_c3rdata_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (c3RReportList == null)
            {
                c3RReportList = new List<C3RReportDetailsModel>();
            }

            return c3RReportList;
        }

        public List<CBRDifferenceReportModel> GetCBROpeningClosingDetails(C3RReportModel c3RReportModel)
        {
            List<CBRDifferenceReportModel> CBRDifferenceReportList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TERMINALID", c3RReportModel.TERMINALID);
                param.Add("@clientid", c3RReportModel.ClientID);
                param.Add("@FROMDATE", c3RReportModel.FROMDATE);
                param.Add("@TODATE", c3RReportModel.TODATE);

                CBRDifferenceReportList = connection.Query<CBRDifferenceReportModel>("spCBROpeningClosing", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (CBRDifferenceReportList == null)
            {
                CBRDifferenceReportList = new List<CBRDifferenceReportModel>();
            }

            return CBRDifferenceReportList;
        }

        public List<CBRReportDetailsNewModel> GetCBRReportDetails(CBRReportModel cBRReportModel)
        {
            List<CBRReportDetailsNewModel> cBRReportList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TERMINALID", cBRReportModel.TERMINALID);
                param.Add("@FROMDATE", cBRReportModel.FROMDATE);
                param.Add("@TODATE", cBRReportModel.TODATE);
                param.Add("@username", cBRReportModel.Username);
                param.Add("@clientid", cBRReportModel.Clientid);

                cBRReportList = connection.Query<CBRReportDetailsNewModel>("spCBRReport_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (cBRReportList == null)
            {
                cBRReportList = new List<CBRReportDetailsNewModel>();
            }

            return cBRReportList;
        }
        //-----------------------------------advait----------------------------------------------
        List<CBRMissingDataModel> ICBR.GetCBRMissingData(CBRMissingReportModel cbrMissingModel)
        {
            {
                List<CBRMissingDataModel> cBRMissingReportData = null;
                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    param.Add("@ClientID", cbrMissingModel.ClientID);
                    param.Add("@TERMINALID", cbrMissingModel.TERMINALID);
                    param.Add("@FromDate", cbrMissingModel.FROMDATE);
                    param.Add("@ToDate", cbrMissingModel.TODATE);
                    
                    cBRMissingReportData = connection.Query<CBRMissingDataModel>("sp_CBRmissing", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                }

                if (cBRMissingReportData == null)
                {
                    cBRMissingReportData = new List<CBRMissingDataModel>();
                }

                return cBRMissingReportData;
            }
        }



        DataTable ICBR.ExportCsvReportcbr(CBRMissingReportModelData cBRMissingReportModelData)
        {
            try
            {
                DataTable dt = new DataTable();
                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (var cmd = new System.Data.SqlClient.SqlCommand("sp_CBRmissing", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 1000000;
                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = cBRMissingReportModelData.ClientID;
                        cmd.Parameters.AddWithValue("@TERMINALID", SqlDbType.Int).Value = cBRMissingReportModelData.TERMINALID;
                        cmd.Parameters.AddWithValue("@FromDate", SqlDbType.DateTime).Value = cBRMissingReportModelData.FROMDATE ?? (object)DBNull.Value;
                        cmd.Parameters.AddWithValue("@ToDate", SqlDbType.DateTime).Value = cBRMissingReportModelData.TODATE ?? (object)DBNull.Value;




                        using (var sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        DataTable ICBR.ExportExcelReportcbr(CBRMissingReportModelData cBRMissingReportModelData)
        {

            try
            {
                DataTable dt = new DataTable();
                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (var cmd = new System.Data.SqlClient.SqlCommand("sp_CBRmissing", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 1000000;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = cBRMissingReportModelData.ClientID;
                        cmd.Parameters.AddWithValue("@TERMINALID", SqlDbType.Int).Value = cBRMissingReportModelData.TERMINALID;
                        cmd.Parameters.AddWithValue("@FromDate", SqlDbType.DateTime).Value = cBRMissingReportModelData.FROMDATE ?? (object)DBNull.Value;
                        cmd.Parameters.AddWithValue("@ToDate", SqlDbType.DateTime).Value = cBRMissingReportModelData.TODATE ?? (object)DBNull.Value;



                        using (var sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        //-----------------------------------advait----------------------------------------------
        public List<TerminalOptionModel> GetTerminalOptionsOld(string ClientID, string UserName)
        {
            List<TerminalOptionModel> terminalOptionModelsList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@UserName", UserName);

                terminalOptionModelsList = connection.Query<TerminalOptionModel>("spGetTerminalDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (terminalOptionModelsList == null)
            {
                terminalOptionModelsList = new List<TerminalOptionModel>();
            }
            return terminalOptionModelsList;
        }

        public List<TerminalOptionModel> GetTerminalOptions(string UserName)
        {
            List<TerminalOptionModel> terminalOptionModelsList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters(); 
                param.Add("@UserName", UserName);

                terminalOptionModelsList = connection.Query<TerminalOptionModel>("UspGetTerminalList_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (terminalOptionModelsList == null)
            {
                terminalOptionModelsList = new List<TerminalOptionModel>();
            }
            return terminalOptionModelsList;
        }


        public string GetTerminalType(string Terminalid)
        {
            string TerminalType = string.Empty;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@Terminalid", Terminalid);

                TerminalType = connection.QuerySingleOrDefault<string>("GetTerminalType", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return TerminalType;
        }

        public TerminalModel GetTerminalData(string Terminalid)
        {
            TerminalModel terminalModel = new TerminalModel();
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@Terminalid", Terminalid);

                terminalModel = connection.QuerySingle<TerminalModel>("spGetTerminalData", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return terminalModel;
        }

        public PreviousClosingModel GetPreviousClosing(string Terminalid, string TimeStamp)
        {
            PreviousClosingModel previousClosingModel = new PreviousClosingModel();
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@terminalid", Terminalid);
                param.Add("@tr_timestamp", TimeStamp);

                previousClosingModel = connection.QuerySingle<PreviousClosingModel>("spGetPreviousClosingCBR", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return previousClosingModel;
        }

        public int CBRCounterInsertUpdate(CBRCounterModel cBRCounterModel)
        {
            int affectedRows = 0;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters(); 
                param.Add("@terminalid", cBRCounterModel.TerminalId);
                param.Add("@Tr_timestamp", cBRCounterModel.TR_TIMESTAMP);
                param.Add("@Branchlocation", cBRCounterModel.Branchlocation);
                param.Add("@Atmopeningbalance50", cBRCounterModel.Atmopeningbalance50);
                param.Add("@Atmopeningbalance100", cBRCounterModel.Atmopeningbalance100);
                param.Add("@Atmopeningbalance500", cBRCounterModel.Atmopeningbalance500);
                param.Add("@Atmopeningbalance1000", cBRCounterModel.Atmopeningbalance1000);
                param.Add("@Atmdispensecounter50", cBRCounterModel.Atmdispensecounter50);
                param.Add("@Atmdispensecounter100", cBRCounterModel.Atmdispensecounter100);
                param.Add("@Atmdispensecounter500", cBRCounterModel.Atmdispensecounter500);
                param.Add("@Atmdispensecounter1000", cBRCounterModel.Atmdispensecounter1000);
                param.Add("@Atmremaingcounter50", cBRCounterModel.Atmremaingcounter50);
                param.Add("@Atmremaingcounter100", cBRCounterModel.Atmremaingcounter100);
                param.Add("@Atmremaingcounter500", cBRCounterModel.Atmremaingcounter500);
                param.Add("@Atmremaingcounter1000", cBRCounterModel.Atmremaingcounter1000);
                param.Add("@Atmdivertcounter50", cBRCounterModel.Atmdivertcounter50);
                param.Add("@Atmdivertcounter100", cBRCounterModel.Atmdivertcounter100);
                param.Add("@Atmdivertcounter500", cBRCounterModel.Atmdivertcounter500);
                param.Add("@Atmdivertcounter1000", cBRCounterModel.Atmdivertcounter1000);
                param.Add("@Amountreplenished50", cBRCounterModel.Amountreplenished50);
                param.Add("@Amountreplenished100", cBRCounterModel.Amountreplenished100);
                param.Add("@Amountreplenished500", cBRCounterModel.Amountreplenished500);
                param.Add("@Amountreplenished1000", cBRCounterModel.Amountreplenished1000);
                param.Add("@Amountreturned50", cBRCounterModel.Amountreturned50);
                param.Add("@Amountreturned100", cBRCounterModel.Amountreturned100);
                param.Add("@Amountreturned500", cBRCounterModel.Amountreturned500);
                param.Add("@Amountreturned1000", cBRCounterModel.Amountreturned1000);
                param.Add("@Newbalperatmcounters50", cBRCounterModel.Newbalperatmcounters50);
                param.Add("@Newbalperatmcounters100", cBRCounterModel.Newbalperatmcounters100);
                param.Add("@Newbalperatmcounters500", cBRCounterModel.Newbalperatmcounters500);
                param.Add("@Newbalperatmcounters1000", cBRCounterModel.Newbalperatmcounters1000);
                param.Add("@Cashincassettes50", cBRCounterModel.Cashincassettes50);
                param.Add("@Cashincassettes100", cBRCounterModel.Cashincassettes100);
                param.Add("@Cashincassettes500", cBRCounterModel.Cashincassettes500);
                param.Add("@Cashincassettes1000", cBRCounterModel.Cashincassettes1000);
                param.Add("@CASHFROMPURGEBIN50", cBRCounterModel.CASHFROMPURGEBIN50);
                param.Add("@CASHFROMPURGEBIN100", cBRCounterModel.CASHFROMPURGEBIN100);
                param.Add("@CASHFROMPURGEBIN500", cBRCounterModel.CASHFROMPURGEBIN500);
                param.Add("@CASHFROMPURGEBIN1000", cBRCounterModel.CASHFROMPURGEBIN1000);
                param.Add("@ClosingCounter50", cBRCounterModel.ClosingCounter50);
                param.Add("@ClosingCounter100", cBRCounterModel.ClosingCounter100);
                param.Add("@ClosingCounter500", cBRCounterModel.ClosingCounter500);
                param.Add("@ClosingCounter1000", cBRCounterModel.ClosingCounter1000);
                param.Add("@Glamount", cBRCounterModel.Glamount);
                param.Add("@switchopeningbal50", cBRCounterModel.Switchopeningbal50);
                param.Add("@switchopeningbal100", cBRCounterModel.Switchopeningbal100);
                param.Add("@switchopeningbal500", cBRCounterModel.Switchopeningbal500);
                param.Add("@switchopeningbal1000", cBRCounterModel.Switchopeningbal1000);
                param.Add("@switchdispensebal50", cBRCounterModel.Switchdispensebal50);
                param.Add("@switchdispensebal100", cBRCounterModel.Switchdispensebal100);
                param.Add("@switchdispensebal500", cBRCounterModel.Switchdispensebal500);
                param.Add("@switchdispensebal1000", cBRCounterModel.Switchdispensebal1000);
                param.Add("@user", cBRCounterModel.UserName);
                param.Add("@Atmdepositcounter50", cBRCounterModel.Atmdepositcounter50);
                param.Add("@Atmdepositcounter100", cBRCounterModel.Atmdepositcounter100);
                param.Add("@Atmdepositcounter500", cBRCounterModel.Atmdepositcounter500);
                param.Add("@Atmdepositcounter1000", cBRCounterModel.Atmdepositcounter1000);
                param.Add("@Switchdepositcounter50", cBRCounterModel.Switchdepositcounter50);
                param.Add("@Switchdepositcounter100", cBRCounterModel.Switchdepositcounter100);
                param.Add("@Switchdepositcounter500", cBRCounterModel.Switchdepositcounter500);
                param.Add("@Switchdepositcounter1000", cBRCounterModel.Switchdepositcounter1000);
                param.Add("@CDamount", cBRCounterModel.CDamount);
                param.Add("@ClientCode", cBRCounterModel.ClientCode);

                affectedRows = connection.Execute("Pro_CBRCounterInsertUpdate", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return affectedRows;
        }

        public int CBRInsertUpdate(CBRDataModel cBRDataModel)
        {
            int affectedRows = 0;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_TIMESTAMP", cBRDataModel.TR_TIMESTAMP);
                param.Add("@BANK", cBRDataModel.ClientCode);
                param.Add("@TERMINALID", cBRDataModel.TERMINALID);
                param.Add("@BRANCH", cBRDataModel.BRANCH);
                param.Add("@BRANCHLOCATION", cBRDataModel.BRANCHLOCATION);
                param.Add("@ATMPREVIOUSBALANCE", cBRDataModel.ATMPREVIOUSBALANCE);
                param.Add("@ATMDISPANSECOUNTER", cBRDataModel.ATMDISPANSECOUNTER);
                param.Add("@ATMREMAINGCOUNTER", cBRDataModel.ATMREMAINGCOUNTER);
                param.Add("@ATMDIVERTCOUNTER", cBRDataModel.ATMDIVERTCOUNTER);
                param.Add("@AMOUNTREPLENISHED", cBRDataModel.AMOUNTREPLENISHED);
                param.Add("@AMOUNTRETURNED", cBRDataModel.AMOUNTRETURNED);
                param.Add("@NEWBALPERATMCOUNTERS", cBRDataModel.NEWBALPERATMCOUNTERS);
                param.Add("@CASHINCASSETTES", cBRDataModel.CASHINCASSETTES);
                param.Add("@CASHFROMPURGEBIN", cBRDataModel.CASHFROMPURGEBIN);
                param.Add("@TOTALCASHINATM", cBRDataModel.TOTALCASHINATM);
                param.Add("@PHYSICALBALANCE", cBRDataModel.PHYSICALBALANCE);
                param.Add("@GLAMOUNT", cBRDataModel.GLAMOUNT);
                param.Add("@SWITCHOPENINGBAL", cBRDataModel.SWITCHOPENINGBAL);
                param.Add("@SWITCHDISPENSEBAL", cBRDataModel.SWITCHDISPENSEBAL);
                param.Add("@SWITCHCLOSINGBAL", cBRDataModel.SWITCHCLOSINGBAL);
                param.Add("@GLANDPHYSICALCASHDIFF", cBRDataModel.GLANDPHYSICALCASHDIFF);
                param.Add("@OVERAGE", cBRDataModel.OVERAGE);
                param.Add("@SHORTAGE", cBRDataModel.SHORTAGE);
                param.Add("@STATUS", cBRDataModel.STATUS);
                param.Add("@user", cBRDataModel.UserName);
                param.Add("@Atmdepositcounter", cBRDataModel.Atmdepositcounter);
                param.Add("@Switchdepositcounter", cBRDataModel.Switchdepositcounter);
                param.Add("@CDAMOUNT", cBRDataModel.CDAMOUNT);
                param.Add("@GLANDCDCASHDIFF", 0);
                param.Add("@ATMANDPHYSICALCOUNTERSTATUS", null);
                param.Add("@ClientCode", cBRDataModel.ClientCode);
                param.Add("@ISMANUALEntry", cBRDataModel.ISMANUALEntry);
                affectedRows = connection.Execute("PRO_CBRinsertUpdate", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return affectedRows;
        } 

        public DataTable CBRReportDatatable(CBRReportModel cBROCDataModel)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter odaDEK = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        connExcel.Open();
                        cmd.CommandText = "spCBRReport_Core";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@TERMINALID", cBROCDataModel.TERMINALID);
                        cmd.Parameters.AddWithValue("@FROMDATE", cBROCDataModel.FROMDATE ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@TODATE", cBROCDataModel.TODATE ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@username", cBROCDataModel.Username);
                        cmd.Parameters.AddWithValue("@clientid", cBROCDataModel.Clientid);

                        odaDEK.SelectCommand = cmd;
                        odaDEK.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }
        
        public DataTable CBROpeningClosingDatatable(C3RReportModel cBROCDataModel)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter odaDEK = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        connExcel.Open();
                        cmd.CommandText = "spCBROpeningClosing";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@TERMINALID", cBROCDataModel.TERMINALID);
                        cmd.Parameters.AddWithValue("@FROMDATE", cBROCDataModel.FROMDATE ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@TODATE", cBROCDataModel.TODATE ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@clientid", cBROCDataModel.ClientID);

                        odaDEK.SelectCommand = cmd;
                        odaDEK.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }


        public DataTable CBRmissingDataTable(CBRMissingReportModelData cBRMissingReportModelData)
        {
            try
            {
                DataTable dt = new DataTable();
                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (var cmd = new System.Data.SqlClient.SqlCommand("sp_CBRmissing", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 1000000;
                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = cBRMissingReportModelData.ClientID;
                        cmd.Parameters.AddWithValue("@TERMINALID", SqlDbType.Int).Value = cBRMissingReportModelData.TERMINALID;
                        cmd.Parameters.AddWithValue("@FromDate", SqlDbType.DateTime).Value = cBRMissingReportModelData.FROMDATE ?? (object)DBNull.Value;
                        cmd.Parameters.AddWithValue("@ToDate", SqlDbType.DateTime).Value = cBRMissingReportModelData.TODATE ?? (object)DBNull.Value; 

                        using (var sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
