﻿using Dapper;
using Microsoft.Extensions.Configuration; 
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTrace.Repository
{
    public class ChannelRegRepository : IChannelReg
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public ChannelRegRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<ChannelRegModel> GetChannelReg()
        {
            List<ChannelRegModel> ChannelRegList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                ChannelRegList = connection.Query<ChannelRegModel>("UspGetChannelData_Core", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }
            if (ChannelRegList == null)
            {
                ChannelRegList = new List<ChannelRegModel>();
            }
            return ChannelRegList;
        }

        public string ChannelRegAdd(ChannelRegDetailsModel channelRegDetailsModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@ChannelID", channelRegDetailsModel.ChannelID);
                param.Add("@ChannelName", channelRegDetailsModel.ChannelName);
                param.Add("@CreatedBy", channelRegDetailsModel.CreatedBy);
                param.Add("@Mode", channelRegDetailsModel.Mode);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspChannelMaster_core", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }
        public GetChannelDetails GetChannelRegById(string ChannelID)
        {
            GetChannelDetails getChannelDetails = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@channelID", ChannelID);
                connection.Open();
                List<GetChannelDetails> channelList = connection.Query<GetChannelDetails>("uspGetChannelDetailsById_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                if (channelList != null && channelList.Count > 0)
                {
                    getChannelDetails = channelList[0];
                }
            }
            if (getChannelDetails == null)
            {
                getChannelDetails = new GetChannelDetails();
            }
            return getChannelDetails;
        }



        public string ChannelRegDelete(DeleteChannelDetails deleteChannelDetails)
        {
            string result = "";
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Mode", deleteChannelDetails.Mode);
                    param.Add("@ChannelID", Convert.ToInt32(deleteChannelDetails.ChannelID));
                    connection.Open();
                    result = connection.ExecuteScalar<string>("uspChannelMaster_core", param, commandType: System.Data.CommandType.StoredProcedure);
                }
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }
        }
    }
}
