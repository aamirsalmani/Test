﻿namespace ASPTrace.Repository
{
    public class Class1
    {

    }
}
