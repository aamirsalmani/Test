﻿using Microsoft.Extensions.Configuration; 
using System.Data; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;

namespace ASPTrace.Repository
{
    public class ClientRegRepository : IClientRegistration
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public ClientRegRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<ClientRegModel> GetClientRegModel()
        {
            List<ClientRegModel> ClientRegList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                ClientRegList = connection.Query<ClientRegModel>("GetClientCode", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientRegList == null)
            {
                ClientRegList = new List<ClientRegModel>();
            }

            return ClientRegList;
        }

        public List<ClientDetails> GetClientDetails(string BankID)
        {
            List<ClientDetails> ClientDetailsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@BankID", BankID);

                ClientDetailsList = connection.Query<ClientDetails>("spGeClientDetails1", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientDetailsList == null)
            {
                ClientDetailsList = new List<ClientDetails>();
            }

            return ClientDetailsList;
        }


        public List<ClientCountry> GetClientCountry()
        {
            List<ClientCountry> ClientCountryList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                ClientCountryList = connection.Query<ClientCountry>("UspGetCountry_Core", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientCountryList == null)
            {
                ClientCountryList = new List<ClientCountry>();
            }

            return ClientCountryList;
        }


        public List<ClientCurrency> GetClientCurrency(string CountryID)
        {
            List<ClientCurrency> ClientCurrencyList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@CountryID", CountryID);

                ClientCurrencyList = connection.Query<ClientCurrency>("spGetClientCurrency", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientCurrencyList == null)
            {
                ClientCurrencyList = new List<ClientCurrency>();
            }

            return ClientCurrencyList;
        }

        public List<ClientDomain> GetClientDomain()
        {
            List<ClientDomain> ClientDomainList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                ClientDomainList = connection.Query<ClientDomain>("spGetDomainMaster", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientDomainList == null)
            {
                ClientDomainList = new List<ClientDomain>();
            }

            return ClientDomainList;
        }

        public List<ClientModule> GetClientModule()
        {
            List<ClientModule> ClientModuleList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                ClientModuleList = connection.Query<ClientModule>("spGetModuleMaster", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientModuleList == null)
            {
                ClientModuleList = new List<ClientModule>();
            }

            return ClientModuleList;
        }

        public List<ClientChannel> GetClientChannel()
        {
            List<ClientChannel> ClientChannelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                ClientChannelList = connection.Query<ClientChannel>("spGetChannelMaster", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientChannelList == null)
            {
                ClientChannelList = new List<ClientChannel>();
            }

            return ClientChannelList;
        }

        public int AddUpdateClientMaster(ClientConfig clientConfig)
        {
            int rowsAffected = 0;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                
                param.Add("@Mode", clientConfig.Mode);
                param.Add("@DomainID", clientConfig.DomainID);
                param.Add("@ModuleID", clientConfig.ModuleID);
                param.Add("@ClientCode", clientConfig.ClientCode);
                param.Add("@ClientName", clientConfig.ClientName);
                param.Add("@Address", clientConfig.Address);
                param.Add("@ContactNo", clientConfig.ContactNo);
                param.Add("@EmailID", clientConfig.EmailID);
                param.Add("@ConcernPerson", clientConfig.ConcernPerson);
                param.Add("@CPEmailID", clientConfig.CPEmailID);
                param.Add("@CPContactNo", clientConfig.CPContactNo);
                param.Add("@IsBank", clientConfig.IsBank);
                param.Add("@IsActive", clientConfig.IsActive);
                param.Add("@CountryID", clientConfig.CountryID);
                param.Add("@CurrencyID", clientConfig.CurrencyID);
                param.Add("@FTP_IP", clientConfig.FTP_IP);
                param.Add("@FTPUserName", clientConfig.FTPUserName);
                param.Add("@FTPPassword", clientConfig.FTPPassword);
                param.Add("@FTPPort", clientConfig.FTPPort);
                param.Add("@ClientLogo", clientConfig.ClientLogo);
                param.Add("@UserLimit", clientConfig.UserLimit);
                param.Add("@TerminalCount", clientConfig.TerminalCount);
                param.Add("@ReportTime", clientConfig.ReportTime);
                param.Add("@UserName", clientConfig.UserName);
                param.Add("@Colorcode", clientConfig.Colorcode);

                rowsAffected = connection.Execute("spClientConfigMaster", param, commandType: System.Data.CommandType.StoredProcedure);
             } 

            return rowsAffected;
        }

        public List<ClientConfigMaster> GetClientMasterGridData(ClientRegModel clientRegModel)
        {
            List<ClientConfigMaster> ClientConfigMasterList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters(); 
                param.Add("@ClientID", clientRegModel.ClientID);
                param.Add("@DomainID", clientRegModel.DomainID);
                param.Add("@ModuleID", clientRegModel.ModuleID);

                ClientConfigMasterList = connection.Query<ClientConfigMaster>("Usp_ClientConfigMasterList_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientConfigMasterList == null)
            {
                ClientConfigMasterList = new List<ClientConfigMaster>();
            }

            return ClientConfigMasterList;
        }
            
        public List<ClientConfigMaster> GetClientMasterGridData(int status)
        {
            List<ClientConfigMaster> ClientConfigMasterList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@status", status);

                ClientConfigMasterList = connection.Query<ClientConfigMaster>("Usp_ClientList_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientConfigMasterList == null)
            {
                ClientConfigMasterList = new List<ClientConfigMaster>();
            }

            return ClientConfigMasterList;
        }

        public int AddClientChannelMode(ClientChannelModeDetails clientChannelModeDetail)
        {
            int rowsAffected = 0;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ChannelID", clientChannelModeDetail.ChannelID);
                param.Add("@ModeID", clientChannelModeDetail.ModeID);
                param.Add("@ClientCode", clientChannelModeDetail.ClientCode);
                param.Add("@Username", clientChannelModeDetail.CreatedBy);

                rowsAffected = connection.Execute("UspClientChannelModeDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure);
            }            

            return rowsAffected;
        }

        public string CheckClientCodeExists(string ClientID, string ClientCode)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ClientCode", ClientCode);

                result = connection.ExecuteScalar<string>("UspCheckClientCode_Core", param, commandType: System.Data.CommandType.StoredProcedure);
            } 

            return result;
        }
       
        public List<ClientChannelModeDetails> GetChannelData(string ClientID)
        {
            List<ClientChannelModeDetails> ChannelDataList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                ChannelDataList = connection.Query<ClientChannelModeDetails>("UspGetChannelData_Core",param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ChannelDataList == null)
            {
                ChannelDataList = new List<ClientChannelModeDetails>();
            }

            return ChannelDataList;
        }

        public ClientConfigMaster GetClientMasterData(string ClientID)
        {
            ClientConfigMaster clientConfigMaster = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                List<ClientConfigMaster>  ClientConfigMasterList = connection.Query<ClientConfigMaster>("Usp_ClientDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (ClientConfigMasterList != null && ClientConfigMasterList.Count > 0)
                {
                    clientConfigMaster = ClientConfigMasterList[0];
                }
            }

            if (clientConfigMaster == null)
            {
                clientConfigMaster = new ClientConfigMaster();
            }

            return clientConfigMaster;
        }
    }
}
