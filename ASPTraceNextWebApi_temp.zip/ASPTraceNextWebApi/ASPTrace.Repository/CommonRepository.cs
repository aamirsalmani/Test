﻿using Microsoft.Extensions.Configuration;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;
using System.Data.SqlClient;

namespace ASPTrace.Repository
{
    public class CommonRepository : ICommon
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public CommonRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<ClientOptionModel> GetClientOptions(string UserID)
        {
            List<ClientOptionModel> clientOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                clientOptionModelsList = connection.Query<ClientOptionModel>("uspGeClientCodeCore", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientOptionModelsList == null)
            {
                clientOptionModelsList = new List<ClientOptionModel>();
            }
            //else
            //{
            //    ClientOptionModel objSelect = new ClientOptionModel();
            //    objSelect.ClientID = "0"; objSelect.ClientName = "--Select--";
            //    clientOptionModelsList.Insert(0, objSelect);
            //}

            return clientOptionModelsList;
        }
        public List<LogOptionModel> GetLogOptions(string ChannelID)
        {
            List<LogOptionModel> LogOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ChannelID", ChannelID);
                LogOptionModelsList = connection.Query<LogOptionModel>("uspGetLogType_New", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (LogOptionModelsList == null)
            {
                LogOptionModelsList = new List<LogOptionModel>();
            }
            //else
            //{
            //    ClientOptionModel objSelect = new ClientOptionModel();
            //    objSelect.ClientID = "0"; objSelect.ClientName = "--Select--";
            //    clientOptionModelsList.Insert(0, objSelect);
            //}

            return LogOptionModelsList;
        }


        public string GetUserRole(string UserID)
        {
            string Role = "";
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                Role = connection.ExecuteScalar<string>("UspGetUserRole_Core", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return Role;
        }

        public List<ChannelOptionModel> GetChannelOptions(string ClientID, string UserID)
        {
            List<ChannelOptionModel> clientOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@UserID", UserID);

                clientOptionModelsList = connection.Query<ChannelOptionModel>("UspGetChannelTypeALL_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientOptionModelsList == null)
            {
                clientOptionModelsList = new List<ChannelOptionModel>();
            }
            return clientOptionModelsList;
        }

        public List<ModeOptionModel> GetModeOptions(string ClientID, string ChannelID, string UserID)
        {
            List<ModeOptionModel> clientOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@UserID", UserID);

                clientOptionModelsList = connection.Query<ModeOptionModel>("UspGetModeTypeALL_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientOptionModelsList == null)
            {
                clientOptionModelsList = new List<ModeOptionModel>();
            }
            return clientOptionModelsList;
        }

        public List<ModeIMPSOptionModel> GetModeIMPSOptions(string ClientID, string ChannelID)
        {
            List<ModeIMPSOptionModel> clientOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                clientOptionModelsList = connection.Query<ModeIMPSOptionModel>("UspGetModeTypeALLIMPS_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientOptionModelsList == null)
            {
                clientOptionModelsList = new List<ModeIMPSOptionModel>();
            }
            return clientOptionModelsList;
        }

        public List<TerminalOptionModel> GetTerminals(string ClientID, string ChannelID, string UserName)
        {
            List<TerminalOptionModel> terminalOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@UserName", UserName);

                terminalOptionModelsList = connection.Query<TerminalOptionModel>("spGetTerminalDetailsChannelWise", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (terminalOptionModelsList == null)
            {
                terminalOptionModelsList = new List<TerminalOptionModel>();
            }
            return terminalOptionModelsList;
        }

        public List<TerminalOptionModel> GetTerminalOptions(string ClientID, string UserName)
        {
            List<TerminalOptionModel> terminalOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@UserName", UserName);

                terminalOptionModelsList = connection.Query<TerminalOptionModel>("spGetTerminalDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (terminalOptionModelsList == null)
            {
                terminalOptionModelsList = new List<TerminalOptionModel>();
            }
            return terminalOptionModelsList;
        }

        public DataSet GetCardNetwork()
        {
            DataSet ds = new DataSet();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter odaCard = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        connExcel.Open();
                        cmd.CommandText = "spGetCardNetwork";
                        cmd.CommandType = CommandType.StoredProcedure;
                        odaCard.SelectCommand = cmd;
                        odaCard.Fill(ds);
                        connExcel.Close();
                    }
                }
            }

            return ds;
        }

        public DataTable GetEncryptedDEK()
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter odaDEK = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        connExcel.Open();
                        cmd.CommandText = "GetEncryptedDEK";
                        cmd.CommandType = CommandType.StoredProcedure;
                        odaDEK.SelectCommand = cmd;
                        odaDEK.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }

        public List<FileTypeOptionModel> GetFileTypeOptions(string ClientID)
        {
            List<FileTypeOptionModel> OptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                OptionModelsList = connection.Query<FileTypeOptionModel>("UspGetFileType_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (OptionModelsList == null)
            {
                OptionModelsList = new List<FileTypeOptionModel>();
            }
            return OptionModelsList;
        }

        public void InsertLogs(string Msg, string ClientCode, string FormName, string FunctionName, int Lineno, string Filename, string UserName, char LogType)
        {
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@LogType", LogType);
                param.Add("@ClientCode", ClientCode);
                param.Add("@MachineIP", FormName);
                param.Add("@Description", Msg);
                param.Add("@UploadFilename", Filename);
                param.Add("@LineNo", Lineno);
                param.Add("@MethodName", FunctionName);
                param.Add("@UploadBy", UserName);
                connection.Open();
                connection.ExecuteAsync("UspInsertLogs", param, commandType: System.Data.CommandType.StoredProcedure);
            }
        }

        public List<SideBarMenuModel> GetMenuList(string UserID, string MenuLevel)
        {
            List<SideBarMenuModel> MenuList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                param.Add("@MenuLevel", MenuLevel);

                MenuList = connection.Query<SideBarMenuModel>("uspGetMenusCore", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (MenuList == null)
            {
                MenuList = new List<SideBarMenuModel>();
            }
            return MenuList;
        }

        public List<MenuModel> GetMenuList(string UserID)
        {
            List<MenuModel> MenuList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                param.Add("@MenuLevel", 0);

                MenuList = connection.Query<MenuModel>("uspGetMenusCore", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (MenuList == null)
            {
                MenuList = new List<MenuModel>();
            }
            return MenuList;
        }

        public ClientLogoDetails GetClientLogo(string ClientID)
        {
            ClientLogoDetails clientLogoDetails = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                List<ClientLogoDetails> clientLogoList = connection.Query<ClientLogoDetails>("uspGetClientLogo_core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (clientLogoList != null && clientLogoList.Count > 0)
                {
                    clientLogoDetails = clientLogoList[0];
                }
            }

            if (clientLogoDetails == null)
            {
                clientLogoDetails = new ClientLogoDetails();
            }
            return clientLogoDetails;
        }

        public List<OptionModel> GetNPCIReportTypeOptions(string ClientID, string ChannelID, string UserID)
        {
            List<OptionModel> clientOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@UserID", UserID);

                clientOptionModelsList = connection.Query<OptionModel>("UspGetNPCIReportTypes", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientOptionModelsList == null)
            {
                clientOptionModelsList = new List<OptionModel>();
            }
            return clientOptionModelsList;
        }

        public string GetReactFileTypes()
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                result = connection.ExecuteScalar<string>("UspGetFileTypes_core", null, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public string GetPowerBIURL_Link(string UserID)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                var param = new DynamicParameters();
                param.Add("@UserID", UserID);

                result = connection.ExecuteScalar<string>("uspGetPowerBIURLCore", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public string GetUserLogin(string UserID)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                var param = new DynamicParameters();
                param.Add("@UserID", UserID);

                result = connection.ExecuteScalar<string>("uspGetUserLogin_core", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public string ResetPassword(ResetPasswordModel userDetailsModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", userDetailsModel.ClientCode);
                param.Add("@UserID", userDetailsModel.UserID);
                param.Add("@ConfirmPassword", userDetailsModel.NewPassword);
                param.Add("@NewSalt", userDetailsModel.NewSalt);
                param.Add("@CreatedBy", userDetailsModel.CreatedBy);

                result = connection.ExecuteScalar<string>("uspResetUserPassword", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public DataTable GetTerminalSwappedDetail(string ClientID, string TerminalID)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter odaDEK = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        connExcel.Open();
                        cmd.CommandText = "uspGetTerminalSwappedDetails";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ClientID", ClientID);
                        cmd.Parameters.AddWithValue("@TerminalID", TerminalID);

                        odaDEK.SelectCommand = cmd;
                        odaDEK.Fill(dt);
                        connExcel.Close();
                    }
                }
            }
            return dt;
        }

        public int AddUpdateFileUploadStatus(FileUploadStatusModel fileUploadStatusModel)
        {
            int rowsAffected = 0;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                param.Add("@ClientID", fileUploadStatusModel.ClientID);
                param.Add("@ChannelID", fileUploadStatusModel.ChannelID);
                param.Add("@ModeID", fileUploadStatusModel.ModeID);
                param.Add("@FileFormatId", fileUploadStatusModel.FileFormatId);
                param.Add("@FileType", fileUploadStatusModel.FileType);
                param.Add("@FileName", fileUploadStatusModel.FileName);
                param.Add("@FilePath", fileUploadStatusModel.FilePath);
                param.Add("@FileDate", fileUploadStatusModel.FileDate);
                param.Add("@InsertCount", fileUploadStatusModel.InsertCount);
                param.Add("@TotalRowCount", fileUploadStatusModel.TotalRowCount);
                param.Add("@ErrorMessage", fileUploadStatusModel.ErrorMessage);
                param.Add("@CreatedBy", fileUploadStatusModel.CreatedBy);
                param.Add("@Starttime", fileUploadStatusModel.StartTime);
                param.Add("@status", fileUploadStatusModel.UploadStatus);
                param.Add("@BatchDetails", fileUploadStatusModel.FinalBatchDetails);
                rowsAffected = connection.Execute("uspInsertFileUploadStatus", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return rowsAffected;
        }

        public List<GetSuccessfulUnSuccessfulCount> GetSuccessfulUnSuccessRecords(string UserID)
        {
            List<GetSuccessfulUnSuccessfulCount> records;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                //var parameters = new { "@UserID", UserID };

                records = connection.Query<GetSuccessfulUnSuccessfulCount>("GetChartData", param, commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
            return records;
        }
        public List<GetSuccessfulUnSuccessfulCount> GetATMSuccessfulUnSuccessRecords(ATMChartInput aTM)
        {
            List<GetSuccessfulUnSuccessfulCount> records;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", aTM.UserID);
                param.Add("@ChannelID", aTM.ChannelID);
                //var parameters = new { "@UserID", UserID };

                records = connection.Query<GetSuccessfulUnSuccessfulCount>("GetChartData_GLOCBalence", param, commandType: System.Data.CommandType.StoredProcedure).ToList();
            }

            return records;
        }


        public List<GetSuccessfulUnSuccessfulCount> GetATMSuccessfulUnSuccessRecords(string UserID)
        {
            List<GetSuccessfulUnSuccessfulCount> records;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                //var parameters = new { "@UserID", UserID };

                records = connection.Query<GetSuccessfulUnSuccessfulCount>("GetATMSUUNChartData", param, commandType: System.Data.CommandType.StoredProcedure).ToList();
            }
            return records;
        }

        public LoginSuccessModel GetById(string UserID)
        {
            LoginSuccessModel loginModel;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                loginModel = connection.QueryFirstOrDefault<LoginSuccessModel>("Usp_GetuserById_Core", param, commandType: CommandType.StoredProcedure);

            }

            if (loginModel == null)
            {
                loginModel = new LoginSuccessModel();
            }
            return loginModel;
        }

        public string InsertFileUploadDetail(FileUploadStatusModel fileUploadStatusModel)
        {
            string result = string.Empty;

            using (SqlConnection conn = new SqlConnection(_connectionString))
            using (SqlCommand cmd = new SqlCommand("uspInsertFileUploadDetails", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ClientID", fileUploadStatusModel.ClientID);
                cmd.Parameters.AddWithValue("@ChannelID", fileUploadStatusModel.ChannelID);
                cmd.Parameters.AddWithValue("@ModeID", fileUploadStatusModel.ModeID);
                cmd.Parameters.AddWithValue("@FileFormatId", fileUploadStatusModel.FileFormatId);
                cmd.Parameters.AddWithValue("@FileName", fileUploadStatusModel.FileName);
                cmd.Parameters.AddWithValue("@FilePath", fileUploadStatusModel.FilePath);
                cmd.Parameters.AddWithValue("@FileDate", fileUploadStatusModel.FileDate);
                cmd.Parameters.AddWithValue("@CreatedBy", fileUploadStatusModel.CreatedBy);

                // Add OUT parameter
                var outParam = new SqlParameter("@FileImportID", SqlDbType.BigInt)
                {
                    Direction = ParameterDirection.Output
                };
                cmd.Parameters.Add(outParam);

                conn.Open();
                cmd.ExecuteNonQuery();

                // Get the value of the OUT parameter
                result = Convert.ToString(outParam.Value);

            }


            return result;
        }

        public int UpdateFileUploadStatus(FileUploadStatusModel fileUploadStatusModel, string FileImportID)
        {
            int rowsAffected = 0;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                param.Add("@ClientID", fileUploadStatusModel.ClientID);
                param.Add("@ChannelID", fileUploadStatusModel.ChannelID);
                param.Add("@ModeID", fileUploadStatusModel.ModeID);
                param.Add("@FileFormatId", fileUploadStatusModel.FileFormatId);
                param.Add("@FileType", fileUploadStatusModel.FileType);
                param.Add("@FileName", fileUploadStatusModel.FileName);
                param.Add("@FilePath", fileUploadStatusModel.FilePath);
                param.Add("@FileDate", fileUploadStatusModel.FileDate);
                param.Add("@InsertCount", fileUploadStatusModel.InsertCount);
                param.Add("@TotalRowCount", fileUploadStatusModel.TotalRowCount);
                param.Add("@ErrorMessage", fileUploadStatusModel.ErrorMessage);
                param.Add("@CreatedBy", fileUploadStatusModel.CreatedBy);
                param.Add("@Starttime", fileUploadStatusModel.StartTime);
                param.Add("@status", fileUploadStatusModel.UploadStatus);
                param.Add("@BatchDetails", fileUploadStatusModel.FinalBatchDetails);
                param.Add("@FileImportID", FileImportID);
                rowsAffected = connection.Execute("uspUpdateFileUploadStatus", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return rowsAffected;
        }

        public static DataTable ToDataTable<T>(IList<T> data)
        {
            DataTable table = new DataTable();

            if (data == null || data.Count == 0)
                return table;

            // Get properties of the type T
            var properties = typeof(T).GetProperties();

            // Define the columns for the DataTable based on model properties
            foreach (var prop in properties)
            {
                // Use the property type as the column type
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }

            // Populate the DataTable rows
            foreach (var item in data)
            {
                var values = new object[properties.Length];
                for (int i = 0; i < properties.Length; i++)
                {
                    // Fetch the value from the property
                    values[i] = properties[i].GetValue(item) ?? DBNull.Value;
                }
                table.Rows.Add(values);
            }

            return table;
        }

        public string UserHasAccessAsync(string UserID, string path)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                param.Add("@Urlpath", path);

                result = connection.ExecuteScalar<string>("uspCheckUserHasAccess", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public async Task<string> PushNotification(DataTable NotificationsTable)
        {
            List<string> records;
            string MSG = string.Empty;
            try
            {
                using (SqlConnection connExcel = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spPushNotificationKS";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NotificationsTable", NotificationsTable);
                        connExcel.Open();
                        await cmd.ExecuteNonQueryAsync();
                        connExcel.Close();

                        MSG = "Success";
                    }
                }
            }
            catch (Exception ex)
            {
                MSG = ex.Message;
            }

            return MSG;


        }

        public List<AlertTypeModel> GetAlertTypes()
        {
            List<AlertTypeModel> OptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                OptionModelsList = connection.Query<AlertTypeModel>("UspGetAlertTypes", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (OptionModelsList == null)
            {
                OptionModelsList = new List<AlertTypeModel>();
            }
            return OptionModelsList;
        }
        public List<AlertSeverityModel> GetAlertSeverity()
        {
            List<AlertSeverityModel> OptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                OptionModelsList = connection.Query<AlertSeverityModel>("UspGetAlertSeverity", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (OptionModelsList == null)
            {
                OptionModelsList = new List<AlertSeverityModel>();
            }
            return OptionModelsList;
        }
        public List<AlertScheduleTypeModel> GetAlertScheduleType()
        {
            List<AlertScheduleTypeModel> OptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                OptionModelsList = connection.Query<AlertScheduleTypeModel>("UspGetAlertScheduleType", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (OptionModelsList == null)
            {
                OptionModelsList = new List<AlertScheduleTypeModel>();
            }
            return OptionModelsList;
        }
        public List<AlertNotificationChannelModel> GetAlertNotificationChannel()
        {
            List<AlertNotificationChannelModel> OptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                OptionModelsList = connection.Query<AlertNotificationChannelModel>("UspGetAlertNotificationChannel", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (OptionModelsList == null)
            {
                OptionModelsList = new List<AlertNotificationChannelModel>();
            }
            return OptionModelsList;
        }
        public List<AlertEscalationUserModel> GetAlertEscalationUser()
        {
            List<AlertEscalationUserModel> OptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                OptionModelsList = connection.Query<AlertEscalationUserModel>("UspGetAlertEscalationUser", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (OptionModelsList == null)
            {
                OptionModelsList = new List<AlertEscalationUserModel>();
            }
            return OptionModelsList;
        }

    }
}
