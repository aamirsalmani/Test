﻿using Microsoft.Extensions.Configuration;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;

namespace ASPTrace.Repository
{
    public class CurrencyRegRepository : ICurrencyReg
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public CurrencyRegRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }


        public List<ClientCurrencyRegModel> GetClientCurrencyReg()
        {
            List<ClientCurrencyRegModel> ClientCurrencyRegList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
               
                connection.Open();
                ClientCurrencyRegList = connection.Query<ClientCurrencyRegModel>("spGetCurrency", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientCurrencyRegList == null)
            {
                ClientCurrencyRegList = new List<ClientCurrencyRegModel>();
            }
            return ClientCurrencyRegList;
        }

        public List<CurrencyRegModel> GetCurrencyRegGrid()
        {
            List<CurrencyRegModel> CurrencyRegList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                CurrencyRegList = connection.Query<CurrencyRegModel>("UspGetCurrencyDetails_Core", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (CurrencyRegList == null)
            {
                CurrencyRegList = new List<CurrencyRegModel>();
            }
            return CurrencyRegList;
        }

        
        public string CurrencyAddUpdate(CurrencyRegModel currencyRegDetailsModel)
         {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", currencyRegDetailsModel.Mode);
                param.Add("@CurrencyID", currencyRegDetailsModel.CurrencyID);
                param.Add("@CurrencyCode", currencyRegDetailsModel.CurrencyCode);
                param.Add("@CurrencyDescription", currencyRegDetailsModel.CurrencyDescription);
                param.Add("@CountryID", currencyRegDetailsModel.CountryID);
                param.Add("@CountryName", currencyRegDetailsModel.CountryName);
                param.Add("@NumericCode", currencyRegDetailsModel.NumericCode);
                param.Add("@CreatedBy", currencyRegDetailsModel.CreatedBy); 
                param.Add("@Scale", currencyRegDetailsModel.Scale);
                connection.Open();
                result= connection.ExecuteScalar<string>("spCurrencyMaster", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

       

        public CurrencyRegModel GetCurrencyDetails(string CurrencyID)
        {
            CurrencyRegModel currencyDetails = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                
                var param = new DynamicParameters();
                param.Add("@CurrencyID", CurrencyID);

                connection.Open();
                List<CurrencyRegModel> currencyList = connection.Query<CurrencyRegModel>("UspGetCurrencyData_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (currencyList != null && currencyList.Count > 0)
                {
                    currencyDetails = currencyList[0];
                }
            }

            if (currencyDetails == null)
            {
                currencyDetails = new CurrencyRegModel();
            }
            return currencyDetails;
        } 


        public List<CountryRegModel> GetCountryReg()
        {
            List<CountryRegModel> CountryRegList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                CountryRegList = connection.Query<CountryRegModel>("UspGetCountry_Core", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (CountryRegList == null)
            {
                CountryRegList = new List<CountryRegModel>();
            }
            else
            {
                CountryRegModel countryRegModel = new CountryRegModel();
                countryRegModel.Country = "Select";
                countryRegModel.Id = "0";
                CountryRegList.Insert(0, countryRegModel);
            }
            return CountryRegList;
        }

        public string DeleteCurrencyReg(DeleteCurrencyRegModel currencyRegDetailsModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", currencyRegDetailsModel.Mode);
                param.Add("@CurrencyID", currencyRegDetailsModel.CurrencyID);
                connection.Open();
                result = connection.ExecuteScalar<string>("DeleteCurrencyMaster_Core", param, commandType: System.Data.CommandType.StoredProcedure);
            } 
            return result;
        }
        public CurrencyOptRegModel GetCountryCodeByCountryName(string CountryName )
        {
            CurrencyOptRegModel CurrecnyRegList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@CountryName", CountryName);
                connection.Open();
                //CurrecnyRegList = connection.ExecuteScalar<CurrencyOptRegModel>("GetCountryCodeByCountryName", param, commandType: System.Data.CommandType.StoredProcedure);
                CurrecnyRegList = connection.QueryFirstOrDefault<CurrencyOptRegModel>("GetCountryCodeByCountryName",param,commandType: System.Data.CommandType.StoredProcedure);
            }
            return CurrecnyRegList;
        }
    }
}
