
using Microsoft.Extensions.Configuration; 
using System.Data; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;
using Microsoft.AspNetCore.Http; 
using Microsoft.AspNetCore.Http.Internal;
using DataTable = System.Data.DataTable;
using Microsoft.VisualBasic;

namespace ASPTrace.Repository
{
    public class DMSRepository : IDMS
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public DMSRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }


        public List<OptionsModel> GetReasonCodeOptionList(string ClientID, int ChannelID, string AdjType)
        {
            List<OptionsModel> ReasonCodeOptionList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@AdjType", AdjType);

                ReasonCodeOptionList = connection.Query<OptionsModel>("uspGetReasonCodeOptionList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReasonCodeOptionList == null)
            {
                ReasonCodeOptionList = new List<OptionsModel>();
            }
            return ReasonCodeOptionList;
        }

        public List<OptionsModel> GetAdjTypeOptionList(string ClientID, int ChannelID)
        {
            List<OptionsModel> ReasonCodeOptionList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                ReasonCodeOptionList = connection.Query<OptionsModel>("uspGetAdjTypeOptionList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReasonCodeOptionList == null)
            {
                ReasonCodeOptionList = new List<OptionsModel>();
            }
            return ReasonCodeOptionList;
        }

        //Unmatched Report

        public List<UnmatchedTxnsReportModel> GetUnmatchedTxnsReport(UnmatchedTxnsModel unmatchedTxnsModel)
        {
            List<UnmatchedTxnsReportModel> unmatchedTxnsReportList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", unmatchedTxnsModel.ClientID);
                param.Add("@FromDateTxns", unmatchedTxnsModel.FromDate);
                param.Add("@ToDateTxns", unmatchedTxnsModel.ToDate);
                param.Add("@ChannelID", unmatchedTxnsModel.ChannelID);
                param.Add("@ModeID", unmatchedTxnsModel.ModeID);
                param.Add("@TERMINALID", unmatchedTxnsModel.TerminalID);
                param.Add("@TxnType", unmatchedTxnsModel.TxnType);

                unmatchedTxnsReportList = connection.Query<UnmatchedTxnsReportModel>("GetUnmatchedDisputesReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (unmatchedTxnsReportList == null)
            {
                unmatchedTxnsReportList = new List<UnmatchedTxnsReportModel>();
            }

            return unmatchedTxnsReportList;
        }

        public UnmatchedTxnByReferenceNumber GetUnmatchedTxnByReferenceNumberReport(UnmatchedTxnsModel unmatchedTxnsModel)
        {
            UnmatchedTxnByReferenceNumber unmatchedTxnByReferenceNumber = new UnmatchedTxnByReferenceNumber();
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ReferenceNumber", unmatchedTxnsModel.ReferenceNumber);
                param.Add("@TERMINALID", unmatchedTxnsModel.TerminalID);
                param.Add("@ClientID", unmatchedTxnsModel.ClientID);

                unmatchedTxnByReferenceNumber.EJTxnDetails = connection.Query<UnmatchedTxnDetailsModel>("spEJTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                unmatchedTxnByReferenceNumber.GLTxnDetails = connection.Query<UnmatchedTxnDetailsModel>("spGLTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                unmatchedTxnByReferenceNumber.SWTxnDetails = connection.Query<UnmatchedTxnDetailsModel>("spSWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                param.Add("@Channel", unmatchedTxnsModel.ChannelID);
                param.Add("@Mode", unmatchedTxnsModel.ModeID);

                unmatchedTxnByReferenceNumber.NWTxnDetails = connection.Query<UnmatchedTxnDetailsModel>("UspNWTxnDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (unmatchedTxnByReferenceNumber.EJTxnDetails == null)
            {
                unmatchedTxnByReferenceNumber.EJTxnDetails = new List<UnmatchedTxnDetailsModel>();
            }

            if (unmatchedTxnByReferenceNumber.GLTxnDetails == null)
            {
                unmatchedTxnByReferenceNumber.GLTxnDetails = new List<UnmatchedTxnDetailsModel>();
            }

            if (unmatchedTxnByReferenceNumber.NWTxnDetails == null)
            {
                unmatchedTxnByReferenceNumber.NWTxnDetails = new List<UnmatchedTxnDetailsModel>();
            }

            if (unmatchedTxnByReferenceNumber.SWTxnDetails == null)
            {
                unmatchedTxnByReferenceNumber.SWTxnDetails = new List<UnmatchedTxnDetailsModel>();
            }

            return unmatchedTxnByReferenceNumber;
        }


        //Adjustment Report

        public List<AdjustmentTerminalDetailsModel> GetAdjustmentTerminalDetails(string UserName, string ClientID)
        {
            List<AdjustmentTerminalDetailsModel> AdjustmentTerminalDetailsModelList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserName", UserName);
                param.Add("@ClientID", ClientID);

                AdjustmentTerminalDetailsModelList = connection.Query<AdjustmentTerminalDetailsModel>("spGetTerminalDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (AdjustmentTerminalDetailsModelList == null)
            {
                AdjustmentTerminalDetailsModelList = new List<AdjustmentTerminalDetailsModel>();
            }
            return AdjustmentTerminalDetailsModelList;
        }

        public List<AdjustmentModeModel> GetAdjustmentMode(string ClientID, string ChannelID)
        {
            List<AdjustmentModeModel> AdjustmentModeModelList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                AdjustmentModeModelList = connection.Query<AdjustmentModeModel>("spGetModeTypeALL", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (AdjustmentModeModelList == null)
            {
                AdjustmentModeModelList = new List<AdjustmentModeModel>();
            }
            return AdjustmentModeModelList;
        }

        public string IsUserChecker(string UserName)
        {
            List<string> DisputeTypeList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserName", UserName);

                DisputeTypeList = connection.Query<string>("spIsUserChecker", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (DisputeTypeList == null)
            {
                DisputeTypeList = new List<string>() { "maker" };
            }
            return DisputeTypeList[0];
        }
        public List<OptionsModel> GetDisputeTypeList(string ClientID, string ChannelID)
        {
            List<OptionsModel> DisputeTypeList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                DisputeTypeList = connection.Query<OptionsModel>("spGetDisputeTypes", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (DisputeTypeList == null)
            {
                DisputeTypeList = new List<OptionsModel>();
            }
            return DisputeTypeList;
        }

        public List<dynamic> GetAdjustmentTxnsReport(AdjustmentTxnsIputModel adjustmentTxnsModel)
        {
            List<dynamic> AdjustmentTxnsReportModelList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", adjustmentTxnsModel.ClientID);
                param.Add("@ChannelID", adjustmentTxnsModel.ChannelID);
                param.Add("@NetworkType", adjustmentTxnsModel.NetworkType);
                param.Add("@FromDateTxns", adjustmentTxnsModel.FromDateTxns);
                param.Add("@ToDateTxns", adjustmentTxnsModel.ToDateTxns);
                //param.Add("@ReportType", adjustmentTxnsModel.ReportType);
                //param.Add("@UserName", adjustmentTxnsModel.UserName);

                AdjustmentTxnsReportModelList = connection.Query<dynamic>("GetDisputeTrackingData", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (AdjustmentTxnsReportModelList == null)
            {
                AdjustmentTxnsReportModelList = new List<dynamic>();
            }
            return AdjustmentTxnsReportModelList;
        }
        public IFormFile ConvertToIFormFile(byte[] fileBytes, string fileName, string contentType)
        {
            // Create a MemoryStream from the byte array
            using (var stream = new MemoryStream(fileBytes))
            {
                // Create a FormFile from the MemoryStream
                IFormFile formFile = new FormFile(stream, 0, fileBytes.Length, "name", fileName)
                {
                    Headers = new HeaderDictionary(),
                    ContentType = contentType
                };

                return formFile;
            }
        }
        public string BulkRaiseDispute(List<BulkDisputeRaiseModel> DisputeRaiseRecords)
        {
            string Output = null;
            DataTable DisputeRaiseTable = new DataTable();

            DisputeRaiseTable.Columns.Add("DisputeID", typeof(string)); 
            DisputeRaiseTable.Columns.Add("ClientID", typeof(string));
            DisputeRaiseTable.Columns.Add("ChannelID", typeof(string));
            DisputeRaiseTable.Columns.Add("ModeID", typeof(string));
            DisputeRaiseTable.Columns.Add("TerminalID", typeof(string));
            DisputeRaiseTable.Columns.Add("ReferenceNumber", typeof(string));
            DisputeRaiseTable.Columns.Add("AuthCode", typeof(long)); 
            DisputeRaiseTable.Columns.Add("ResponseCode", typeof(string));
            DisputeRaiseTable.Columns.Add("CardNumber", typeof(string)); 
            DisputeRaiseTable.Columns.Add("FromAccount", typeof(string));
            DisputeRaiseTable.Columns.Add("ToAccount", typeof(string));
            DisputeRaiseTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            DisputeRaiseTable.Columns.Add("TxnsAmount", typeof(decimal)); // decimal(18,2) in SQL Server  
            DisputeRaiseTable.Columns.Add("ReasonCode", typeof(string));
            DisputeRaiseTable.Columns.Add("ReasonDescription", typeof(string));
            DisputeRaiseTable.Columns.Add("AdjType", typeof(string));
            DisputeRaiseTable.Columns.Add("DisputeAmount", typeof(decimal));
            DisputeRaiseTable.Columns.Add("ContactNo", typeof(string));
            DisputeRaiseTable.Columns.Add("DisputeDate", typeof(DateTime));
            DisputeRaiseTable.Columns.Add("UserID", typeof(string));
            DisputeRaiseTable.Columns.Add("Status", typeof(string));
            DisputeRaiseTable.Columns.Add("IsChecker", typeof(bool)); // bit in SQL Server maps to bool in C#

            foreach (var Records in DisputeRaiseRecords)
            {
                DataRow row = DisputeRaiseTable.NewRow();
                row["DisputeID"] = Records.DisputeID;
                row["ClientID"] = Records.ClientID; // Assuming you have these fields in your model
                row["ChannelID"] = Records.ChannelID;
                row["ModeID"] = Records.ModeID;
                row["TerminalID"] = Records.TerminalID;
                row["ReferenceNumber"] = Records.ReferenceNumber;                 
                row["AuthCode"] = string.IsNullOrEmpty(Records.AuthCode) ? DBNull.Value : Convert.ToDateTime(Records.AuthCode);  
                row["ResponseCode"] = Records.ResponseCode;
                row["CardNumber"] = string.IsNullOrEmpty(Records.CardNumber) ? DBNull.Value : Convert.ToDateTime(Records.CardNumber); 
                row["FromAccount"] = Records.FromAccount; 
                row["ToAccount"] = Records.ToAccount;
                row["TxnsDateTime"] = Convert.ToDateTime(Records.TxnsDateTime);
                row["TxnsAmount"] = Records.TxnsAmount;
                row["ReasonCode"] = Records.ReasonCode; 
                row["ReasonDescription"] = Records.ReasonDescription;
                row["AdjType"] = Records.AdjType;
                row["DisputeAmount"] = Records.DisputeAmount;
                row["ContactNo"] = Records.ContactNo;
                row["DisputeDate"] = Convert.ToDateTime(Records.DisputeDate);
                row["UserID"] = Records.UserID;
                row["Status"] = Records.Status;
                row["IsChecker"] = Records.IsChecker;

                DisputeRaiseTable.Rows.Add(row);
            }

            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkDisputeRaise";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@DisputeRaiseTable", DisputeRaiseTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        Output = "Upload Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exception (e.g., log it)
                Output = "Upload Failed: " + ex.Message;
            }

            return Output;
        }

        public string BulkUpdateDisputeRemarks(string ChannelID,List<SubmitRemarksModel> SubmitRemarks)
        {
            string Output = null;
            DataTable DisputeRemarksTable = new DataTable();
            DisputeRemarksTable.Columns.Add("DisputeID", typeof(string));
            DisputeRemarksTable.Columns.Add("TxnDateTime", typeof(DateTime));
            DisputeRemarksTable.Columns.Add("ReferenceNumber", typeof(string));
            DisputeRemarksTable.Columns.Add("MakerRemark", typeof(string));
            DisputeRemarksTable.Columns.Add("MakerStatus", typeof(string));
            DisputeRemarksTable.Columns.Add("CheckerRemark", typeof(string));
            DisputeRemarksTable.Columns.Add("CheckerStatus", typeof(string));

            foreach (var submitRemarks in SubmitRemarks)
            {

                DataRow row = DisputeRemarksTable.NewRow();
                row["DisputeID"] = submitRemarks.DisputeID;
                row["TxnDateTime"] = Convert.ToDateTime(submitRemarks.TxnDateTime);
                row["ReferenceNumber"] = submitRemarks.ReferenceNumber;
                row["MakerRemark"] = submitRemarks.MakerStatus.Remark;
                row["MakerStatus"] = submitRemarks.MakerStatus.Status;
                row["CheckerRemark"] = submitRemarks.CheckerStatus.Remark;
                row["CheckerStatus"] = submitRemarks.CheckerStatus.Status;

                DisputeRemarksTable.Rows.Add(row);

            }

            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkUpdateDisputeRemarks";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@DisputeRemarksTable", DisputeRemarksTable);
                        cmd.Parameters.AddWithValue("@ChannelID", ChannelID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        Output = "Upload Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                
            }

            return Output;
        }
        public string UpdateDisputeRemarks(SubmitRemarksModel SubmitRemarks)
        {
            List<string> Output = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@DisputeID", SubmitRemarks.DisputeID);
                param.Add("@TxnDateTime", SubmitRemarks.TxnDateTime);
                param.Add("@ReferenceNumber", SubmitRemarks.ReferenceNumber);
                param.Add("@MakerRemark", SubmitRemarks.MakerStatus.Remark);
                param.Add("@MakerStatus", SubmitRemarks.MakerStatus.Status);
                param.Add("@CheckerRemark", SubmitRemarks.CheckerStatus.Remark);
                param.Add("@CheckerStatus", SubmitRemarks.CheckerStatus.Status);

                Output = connection.Query<string>("spUpdateDisputeRemarks", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }
            if (Output.Count == 0)
            {
                return "No Record Updated";
            }

            return Output[0];
        }
        public string DeleteAttachmentFile(AttachmentModel attachmentDetails)
        {
            List<string> Output = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ID", attachmentDetails.ID);
                param.Add("@DisputeID", attachmentDetails.DisputeID);
                param.Add("@TxnDateTime", attachmentDetails.TxnsDateTime);
                param.Add("@ReferenceNumber", attachmentDetails.ReferenceNumber);
                param.Add("@FileName", attachmentDetails.FileName);
                param.Add("@FileType", attachmentDetails.FileType);

                Output = connection.Query<string>("spDeleteAttachmentsFile", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }


            return Output[0];
        }
        public byte[] GetAttachmentsFile(AttachmentModel attachmentDetails)
        {
            List<byte[]> DisputeFileData = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ID", attachmentDetails.ID);
                param.Add("@DisputeID", attachmentDetails.DisputeID);
                param.Add("@TxnDateTime", attachmentDetails.TxnsDateTime);
                param.Add("@ReferenceNumber", attachmentDetails.ReferenceNumber);
                param.Add("@FileName", attachmentDetails.FileName);
                param.Add("@FileType", attachmentDetails.FileType);

                DisputeFileData = connection.Query<byte[]>("spGetAttachmentsFile", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }


            return DisputeFileData[0];
        }
        public List<AttachmentModel> GetAttachmentsData(DisputeModel DisputeData)
        {
            List<AttachmentModel> DisputeDataList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@DisputeID", DisputeData.DisputeID);
                param.Add("@TxnDateTime", DisputeData.TxnDateTime);
                param.Add("@ReferenceNumber", DisputeData.ReferenceNumber);

                DisputeDataList = connection.Query<AttachmentModel>("spGetAttachmentsData", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (DisputeDataList == null)
            {
                DisputeDataList = new List<AttachmentModel>();
            }
            return DisputeDataList;
        }
        public List<AdjustmentTxnsReportModel> GetDisputeByReferenceNumber(AdjustmentTxnsReferenceNumberModel adjustmentTxnsModel)
        {
            List<AdjustmentTxnsReportModel> AdjustmentTxnsReportModelList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", adjustmentTxnsModel.ClientID);
                param.Add("@ChannelID", adjustmentTxnsModel.ChannelID);
                param.Add("@NetworkType", adjustmentTxnsModel.NetworkType);
                param.Add("@TxnDateTime", adjustmentTxnsModel.TxnDateTime);
                param.Add("@ReferenceNumber", adjustmentTxnsModel.ReferenceNumber);
                //param.Add("@ReportType", adjustmentTxnsModel.ReportType);
                //param.Add("@UserName", adjustmentTxnsModel.UserName);

                AdjustmentTxnsReportModelList = connection.Query<AdjustmentTxnsReportModel>("GetDisputeByReferenceNumber", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (AdjustmentTxnsReportModelList == null)
            {
                AdjustmentTxnsReportModelList = new List<AdjustmentTxnsReportModel>();
            }
            return AdjustmentTxnsReportModelList;
        }
        public bool checkFileType(string extension)
        {
            List<string> isValid = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@Extension", extension);
                param.Add("@Type", 1);
                isValid = connection.Query<string>("spValidateExtension", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (isValid == null)
            {
                return false;
            }
            else if (isValid.Count > 0)
            {
                return isValid[0] == "Valid";
            }
            else
            {
                return false;
            }


        }
        public string UploadDisputeAttachments(DisputeUpload attachment)
        {
            byte[] fileBytes;
            string FileSize;
            if (attachment.Attachment != null)
            {
                long fileSizeInBytes = attachment.Attachment.Length;
                double fileSizeInKB = fileSizeInBytes / 1024.0;
                double fileSizeInMB = fileSizeInKB / 1024.0;

                FileSize = fileSizeInMB < 1 ? $"{Math.Round(fileSizeInKB, 2)} KB" : $"{Math.Round(fileSizeInKB, 2)} MB";

                using (var ms = new MemoryStream())
                {
                    attachment.Attachment.CopyTo(ms);
                    fileBytes = ms.ToArray();
                }
            }
            else
            {
                fileBytes = new byte[0];
                FileSize = "0 KB";
            }

            System.Data.DataTable disputeAttachment = new System.Data.DataTable();
            disputeAttachment.Columns.Add("DisputeID", typeof(string));
            disputeAttachment.Columns.Add("DisputeType", typeof(int));
            disputeAttachment.Columns.Add("ReferenceNumber", typeof(string));
            disputeAttachment.Columns.Add("TxnsDateTime", typeof(DateTime));
            disputeAttachment.Columns.Add("FileName", typeof(string));
            disputeAttachment.Columns.Add("FileSize", typeof(string));
            disputeAttachment.Columns.Add("FileType", typeof(string));
            disputeAttachment.Columns.Add("UploadedBy", typeof(string));
            disputeAttachment.Columns.Add("UploadedDate", typeof(DateTime));
            disputeAttachment.Columns.Add("Attachment", typeof(byte[]));
            disputeAttachment.Columns.Add("ContentType", typeof(string));
            disputeAttachment.Columns.Add("FilePath", typeof(string));


            disputeAttachment.Rows.Add(
                  attachment.DisputeID
                , 0
                , attachment.ReferenceNumber
                , Convert.ToDateTime(attachment.TxnsDateTime)
                , attachment.Attachment.FileName
                , FileSize
                , attachment.Attachment.FileName.Split('.').Last()
                , "System"
                , DateTime.Now
                , fileBytes
                , attachment.Attachment.ContentType
                , null
            );

            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertDisputeAttachments";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@DisputeAttachments", disputeAttachment);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return $"{attachment.Attachment.FileName} Upload Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return $"Error occrued {attachment.Attachment.FileName}  Upload Failed";
            }

        }

        // -------------------------------  NPCI Dispute Tracking Report ---------------------------------------------------------

        public List<DisputeDetails> GetNPCIDisputeTracking(AdjustmentTxnsNPCIModel reportModel)
        {

            List<DisputeDetails> dispute_List = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", reportModel.ClientID);
                param.Add("@ChannelID", reportModel.ChannelID);
                param.Add("@NetworkType", reportModel.NetworkType);
                param.Add("@FromDateTxns", reportModel.FromDateTxns);
                param.Add("@ToDateTxns", reportModel.ToDateTxns);
                param.Add("@Type", reportModel.Type);
                dispute_List = connection.Query<DisputeDetails>("spNPCIBulkDisputeReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (dispute_List == null)
            {
                dispute_List = new List<DisputeDetails>();
            }

            return dispute_List;
        }

        //----------------------------------------------------------------- Advait Nair ---------------------------------------------------------------------------------------

        public List<dynamic> GetDisputeRaiseData(GetDisputeRaiseDataModel getDisputeRaiseDataModel)
        {
            List<dynamic> GetDisputeRaiseDataModelList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", getDisputeRaiseDataModel.ClientID);
                param.Add("@ChannelID", getDisputeRaiseDataModel.ChannelID);
                param.Add("@ModeID", getDisputeRaiseDataModel.ModeID);
                param.Add("@FromDate", getDisputeRaiseDataModel.FromDate);
                param.Add("@referenceNumber", getDisputeRaiseDataModel.ReferenceNumber);
                param.Add("@ToDate", getDisputeRaiseDataModel.ToDate);
                param.Add("@TxnsAmount", getDisputeRaiseDataModel.TxnsAmount);
                param.Add("@FromAccount", getDisputeRaiseDataModel.FromAccount);

                GetDisputeRaiseDataModelList = connection.Query<dynamic>("uspGetRawDataforDispute", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (GetDisputeRaiseDataModelList == null)
            {
                GetDisputeRaiseDataModelList = new List<dynamic>();
            }
            return GetDisputeRaiseDataModelList;
        }

    }
}