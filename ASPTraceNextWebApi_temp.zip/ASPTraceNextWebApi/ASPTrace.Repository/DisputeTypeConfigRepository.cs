﻿
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;
using System.Text.RegularExpressions;

namespace ASPTrace.Repository
{
    public class DisputeTypeConfigRepository : IDisputeTypeConfig
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public DisputeTypeConfigRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }
        

       public List<GetDisputeTypeconfiglist> GetDisputeTypeconfigData(GetDisputeTypeConfigModel getDisputeTypeConfigModel)
        {
            List<GetDisputeTypeconfiglist> GetDisputeTypeconfiglist = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientId", getDisputeTypeConfigModel.ClientID);
                param.Add("@ChannelId", getDisputeTypeConfigModel.ChannelID);
                param.Add("@ModeId", getDisputeTypeConfigModel.ModeID);


                GetDisputeTypeconfiglist = connection.Query<GetDisputeTypeconfiglist>("uspGetDisputeTypeconfiglist", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (GetDisputeTypeconfiglist == null)
            {
                GetDisputeTypeconfiglist = new List<GetDisputeTypeconfiglist>();
            }

            return GetDisputeTypeconfiglist;
        }

        public string EditDisputeTypeconfigData(EditDisputeTypeConfigModel editDisputeTypeConfigModel)
        {
            string UpdateDisputeTypeconfigData = "";
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientId", editDisputeTypeConfigModel.ClientID);
                param.Add("@ChannelId", editDisputeTypeConfigModel.ChannelID);
                param.Add("@ModeId", editDisputeTypeConfigModel.ModeID);
                param.Add("@adjustmenttype", editDisputeTypeConfigModel.AdjustmentType);
                param.Add("@flag", editDisputeTypeConfigModel.flag);
                param.Add("@reasoncode", editDisputeTypeConfigModel.ReasonCode);
                param.Add("@tat", editDisputeTypeConfigModel.TAT);
                param.Add("@disputeorder", editDisputeTypeConfigModel.DisputeOrder);
                param.Add("@isAquirerAction", editDisputeTypeConfigModel.IsAquirerAction);

                UpdateDisputeTypeconfigData = connection.ExecuteScalar<string>("uspEditDisputeTypeconfiglist", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return UpdateDisputeTypeconfigData;
        }


        public string AddNewDisputeTypeconfigData(AddNewDisputeTypeConfigModel addNewDisputeTypeConfigModel)
        {
            string AddNewDisputeTypeconfigData = "";
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientId", addNewDisputeTypeConfigModel.ClientID);
                param.Add("@ChannelId", addNewDisputeTypeConfigModel.ChannelID);
                param.Add("@ModeId", addNewDisputeTypeConfigModel.ModeID);
                param.Add("@adjustmenttype", addNewDisputeTypeConfigModel.AdjustmentType);
                param.Add("@flag", addNewDisputeTypeConfigModel.flag);
                param.Add("@reasoncode", addNewDisputeTypeConfigModel.ReasonCode);
                param.Add("@tat", addNewDisputeTypeConfigModel.TAT);
                param.Add("@disputeorder", addNewDisputeTypeConfigModel.DisputeOrder);
                param.Add("@isAquirerAction", addNewDisputeTypeConfigModel.IsAquirerAction);

                AddNewDisputeTypeconfigData = connection.ExecuteScalar<string>("spAddNewDisputeTypeconfigData", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return AddNewDisputeTypeconfigData;
        }



        public string DeleteDisputeTypeConfigData(DeleteDisputeTypeConfigModel deleteDisputeTypeConfigModel)
        {
            string result = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@ClientId", deleteDisputeTypeConfigModel.ClientID);
                param.Add("@ChannelId", deleteDisputeTypeConfigModel.ChannelID);
                param.Add("@ModeId", deleteDisputeTypeConfigModel.ModeID);
                param.Add("@adjustmenttype", deleteDisputeTypeConfigModel.AdjustmentType);
                param.Add("@flag", deleteDisputeTypeConfigModel.flag);
                param.Add("@reasoncode", deleteDisputeTypeConfigModel.ReasonCode);
                param.Add("@tat", deleteDisputeTypeConfigModel.TAT);
                param.Add("@disputeorder", deleteDisputeTypeConfigModel.DisputeOrder);
                param.Add("@isAquirerAction", deleteDisputeTypeConfigModel.IsAquirerAction);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspDeleteDisputeTypeConfigData", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }
        

    }
}


