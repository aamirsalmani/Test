﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration; 
using Dapper;
using ASPTrace.Models;
using Microsoft.AspNetCore.Http.Internal;
using ASPTrace.Contracts;

namespace ASPTrace.Repository
{
    public class DownloadService : IDownloadService
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;

        public DownloadService(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }


        public string CheckFilesAndInsertToDb(string userId)
        {

            string userDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", userId);

            if (!Directory.Exists(userDirectory))
            {
                return "Directory not found.";
            }


            var files = Directory.GetFiles(userDirectory);

            if (files.Length == 0)
            {

                return "No files found for this user.";
            }

            DataTable FileList = new DataTable();
            FileList.Columns.Add("ID",typeof(int));
            FileList.Columns.Add("FilePath", typeof(string));
            int i =0;
            foreach (var filePath in files)
            {
                //var fileName = Path.GetFileName(filePath);
                i++;
                FileList.Rows.Add(i,filePath);    


            }

            return  InsertFileToDb(userId, FileList);
        }

        public  string InsertFileToDb(string userId, DataTable FilesList)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                try
                {

                    using (SqlCommand cmd = new SqlCommand("spBulkInsertFileList", conn))
                    {
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@FilesList", FilesList);
                        cmd.Parameters.AddWithValue("@UserId", userId);
                        cmd.ExecuteNonQuery();
                        return "Success";
                    }
                }
                catch (Exception ex)
                {
                    return null;
                }
            }

        }

        //-------------------------------------Download Section ----------------------------------------------
        public List<dynamic> DownloadReport(DownloadReportRequest details)
        {
            List<dynamic> DownloadReportList = null;
            details.DownloadStatus = null;
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();


                param.Add("@UserID", details.UserID);
                param.Add("@DownloadStatus", details.DownloadStatus);
                param.Add("@StartDate", details.StartDate);
                param.Add("@EndDate", details.EndDate);

                // Execute the stored procedure
                DownloadReportList = connection.Query<dynamic>("spGetDownloadsData", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            // Initialize to an empty list if no results are found
            if (DownloadReportList == null || !DownloadReportList.Any())
            {
                DownloadReportList = new List<dynamic>();
            }

            return DownloadReportList;
        }

        public List<dynamic> DownloadReportByID(DownloadReportRequest details)
        {
            List<dynamic> DownloadReportList = null;
            details.DownloadStatus = null;
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", details.UserID);
                param.Add("@DownloadStatus", details.DownloadStatus);
                param.Add("@StartDate", details.StartDate);
                param.Add("@EndDate", details.EndDate);
                param.Add("@ID", details.ID);

                DownloadReportList = connection.Query<dynamic>("spGetDownloadsDataById", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }


            if (DownloadReportList == null || !DownloadReportList.Any())
            {
                DownloadReportList = new List<dynamic>();
            }

            return DownloadReportList;
        }



        public async Task<int?> BulkInsertDownloadsAsync(DataTable downloadsData, int? ID)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                try
                {

                    using (SqlCommand cmd = new SqlCommand("InsertDownloads", conn))
                    {
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Downloads", downloadsData);
                        if (ID.HasValue)
                        {
                            cmd.Parameters.AddWithValue("@ID", ID.Value);
                        }
                        else
                        {
                        }
                        SqlParameter outputIdParam = new SqlParameter("@Output", SqlDbType.Int)
                        {
                            Direction = ParameterDirection.Output
                        };
                        cmd.Parameters.Add(outputIdParam);

                        await cmd.ExecuteNonQueryAsync();
                        ID = outputIdParam.Value as int?;
                        return ID;

                    }
                }
                catch (Exception ex)
                {
                    return null;
                }
            }
        }

        public async Task<string> SaveFileAsync(IFormFile file, string userId)
        {
            if (file == null || file.Length == 0)
            {
                throw new ArgumentException("Invalid file.");
            }

            try
            {
                // Define the user-specific directory
                string userDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", userId);

                // Create the directory if it doesn't exist
                if (!Directory.Exists(userDirectory))
                {
                    Directory.CreateDirectory(userDirectory);
                }

                // Define the full path to save the file
                string filePath = Path.Combine(userDirectory, file.FileName);

                // Save the file asynchronously
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                return filePath; // Return the saved file path
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                throw new Exception("Error saving the file", ex);
            }
        }
        public async Task<IFormFile> DownloadFileAsync(string filePath)
        {


            try
            {
                // Open the file stream from the file path
                var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);

                // Get the file information
                var fileInfo = new FileInfo(filePath);

                // Create a memory stream to hold the file data
                var memoryStream = new MemoryStream();
                await fileStream.CopyToAsync(memoryStream);
                memoryStream.Position = 0; // Reset the stream position to the beginning

                // Create an IFormFile instance
                IFormFile formFile = new FormFile(memoryStream, 0, fileInfo.Length, fileInfo.Name, fileInfo.Name)
                {
                    Headers = new HeaderDictionary(),
                    ContentType = "application/octet-stream"
                };

                // Return the IFormFile
                return formFile;
            }
            catch (Exception ex)
            {
                // Handle or log the exception as needed
                throw new Exception("Error retrieving the file", ex);
            }
        }
    }
}
