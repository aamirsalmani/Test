﻿using Microsoft.Extensions.Configuration; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using System.Data;
using Dapper;


namespace ASPTrace.Repository
{
    public class DynamicFileRepository : IDynamicFile
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public DynamicFileRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<LogTypeFileConfigModel> GetLogTypeFileConfig(string ClientID)
        {
            List<LogTypeFileConfigModel> ClientFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                ClientFileConfigModelsList = connection.Query<LogTypeFileConfigModel>("uspGetLogType", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientFileConfigModelsList == null)
            {
                ClientFileConfigModelsList = new List<LogTypeFileConfigModel>();
            }
            return ClientFileConfigModelsList;
        }

        public List<NetworkTypeModel> GetNetworkTypeFileConfig(string ClientID)
        {
            List<NetworkTypeModel> ModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                ModelList = connection.Query<NetworkTypeModel>("uspGetNetworkType", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ModelList == null)
            {
                ModelList = new List<NetworkTypeModel>();
            }
            return ModelList;
        }

        public List<ChannelFileConfigModel> GetDynamicChannelList(string ClientID)
        {
            List<ChannelFileConfigModel> ClientFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);


                ClientFileConfigModelsList = connection.Query<ChannelFileConfigModel>("uspGetDynamicChannelTypeALL", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientFileConfigModelsList == null)
            {
                ClientFileConfigModelsList = new List<ChannelFileConfigModel>();
            }
            return ClientFileConfigModelsList;
        }

        public List<ChannelFileConfigModel> GetChannelList()
        {
            List<ChannelFileConfigModel> ChannelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                ChannelList = connection.Query<ChannelFileConfigModel>("uspGetChannels", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ChannelList == null)
            {
                ChannelList = new List<ChannelFileConfigModel>();
            }
            return ChannelList;
        }

        public List<ModeFileConfigModel> GetModeList()
        {
            List<ModeFileConfigModel> ChannelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                ChannelList = connection.Query<ModeFileConfigModel>("uspGetModes", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ChannelList == null)
            {
                ChannelList = new List<ModeFileConfigModel>();
            }
            return ChannelList;
        }

        public List<ModeFileConfigModel> GetModeFileConfig(string ClientID, int ChannelID)
        {
            List<ModeFileConfigModel> ClientFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                ClientFileConfigModelsList = connection.Query<ModeFileConfigModel>("uspGetModeTypeALL", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientFileConfigModelsList == null)
            {
                ClientFileConfigModelsList = new List<ModeFileConfigModel>();
            }
            return ClientFileConfigModelsList;
        }
        //public List<DynamicModeFileConfigModel> GetDynamicModeFileConfig(string ClientID, int ChannelID)
        //{
        //    List<DynamicModeFileConfigModel> ClientFileConfigModelsList = null;
        //    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();
        //        param.Add("@ClientID", ClientID);
        //        param.Add("@ChannelID", ChannelID);

        //        ClientFileConfigModelsList = connection.Query<DynamicModeFileConfigModel>("uspGetDynamicModeTypeALL", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //    }

        //    if (ClientFileConfigModelsList == null)
        //    {
        //        ClientFileConfigModelsList = new List<DynamicModeFileConfigModel>();
        //    }
        //    return ClientFileConfigModelsList;
        //}


        public List<DynamicModeFileConfigModel> GetDynamicModeFileConfig(string ClientID, int ChannelID)
        {
            List<DynamicModeFileConfigModel> ClientFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                ClientFileConfigModelsList = connection.Query<DynamicModeFileConfigModel>("uspGetDynamicModeTypeALL", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientFileConfigModelsList == null)
            {
                ClientFileConfigModelsList = new List<DynamicModeFileConfigModel>();
            }
            return ClientFileConfigModelsList;
        }

        //  List<DynamicModeFileConfigModel> GetDynamicFileID();


        List<DynamicFileIDModel> IDynamicFile.GetDynamicFileID()
        {
            List<DynamicFileIDModel> getFileID = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                getFileID = connection.Query<DynamicFileIDModel>("uspGetDynamicFileIDALL", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (getFileID == null)
            {
                getFileID = new List<DynamicFileIDModel>();
            }
            return getFileID;
        }


        List<DynamicNetworkTypeIDModel> IDynamicFile.GetDynamicNetworkType()
        {
            List<DynamicNetworkTypeIDModel> getNetworkTypeID = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                getNetworkTypeID = connection.Query<DynamicNetworkTypeIDModel>("uspGetDynamicNetworkType", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (getNetworkTypeID == null)
            {
                getNetworkTypeID = new List<DynamicNetworkTypeIDModel>();
            }
            return getNetworkTypeID;
        }



        public List<VendorFileConfigModel> GetVendorFileConfig(string VendorType)
        {
            List<VendorFileConfigModel> VendorFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@VendorType", VendorType);

                VendorFileConfigModelsList = connection.Query<VendorFileConfigModel>("uspGetVendorType", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (VendorFileConfigModelsList == null)
            {
                VendorFileConfigModelsList = new List<VendorFileConfigModel>();
            }
            return VendorFileConfigModelsList;
        }

        public string AddUpdateFileConfig(DynamicFileConfigModel dynamicFileConfigModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", dynamicFileConfigModel.ClientID);
                param.Add("@NetworkType", dynamicFileConfigModel.NetworkType);
                param.Add("@LogTypeID", dynamicFileConfigModel.LogTypeID);
                param.Add("@VendorID", dynamicFileConfigModel.VendorID);
                param.Add("@ChannelID", dynamicFileConfigModel.ChannelID);
                param.Add("@ModeID", dynamicFileConfigModel.ModeID);
                param.Add("@CreatedBy", dynamicFileConfigModel.UserName);
                result = connection.ExecuteScalar<string>("uspAddUpdateDynamicFileConfig", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public List<OptionModel> GetFileTypeConfig(string FileExtension)
        {
            List<OptionModel> ClientFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileExtension", FileExtension);

                ClientFileConfigModelsList = connection.Query<OptionModel>("uspGetDynamicFileType", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientFileConfigModelsList == null)
            {
                ClientFileConfigModelsList = new List<OptionModel>();
            }
            return ClientFileConfigModelsList;
        }

        public List<DynamicFileConfigGrid> GetFileConfigGrid(string ClientID, string LogTypeID)
        {
            List<DynamicFileConfigGrid> ConfigGrid = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@LogTypeID", LogTypeID);

                ConfigGrid = connection.Query<DynamicFileConfigGrid>("uspDynamicFileConfigGrid", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ConfigGrid == null)
            {
                ConfigGrid = new List<DynamicFileConfigGrid>();
            }
            return ConfigGrid;
        }

        public List<DynamicFileConfigGrid> GetFileConfigGrid(string ClientID, string NetworkType, string LogTypeID, string ChannelID)
        {
            List<DynamicFileConfigGrid> ConfigGrid = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@NetworkType", NetworkType);
                param.Add("@LogTypeID", LogTypeID);

                if (Convert.ToInt32(ChannelID) > 0)
                {
                    param.Add("@ChannelID", ChannelID);
                }

                ConfigGrid = connection.Query<DynamicFileConfigGrid>("uspDynamicFileConfigGrid", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ConfigGrid == null)
            {
                ConfigGrid = new List<DynamicFileConfigGrid>();
            }
            return ConfigGrid;
        }

        public string AddUpdateFileUploadDetails(DynamicFileUploadModel UploadModel, string FileName, string FilePath, string OriginalFileName)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters(); 
                param.Add("@ConfigID", UploadModel.ConfigID); 
                param.Add("@FileName", FileName);
                param.Add("@FilePath", FilePath);
                param.Add("@FileTypeID", UploadModel.FileType);
                param.Add("@FileSeparator", UploadModel.Separator);
                param.Add("@OriginalFileName", OriginalFileName);
                param.Add("@CreatedBy", UploadModel.UserName);
                result = connection.ExecuteScalar<string>("uspAddUpdateDynamicFileConfigDetails", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public DynamicImportFileConfigModel GetDynamicFileUploadDetails(string FileConfigID)
        {
            DynamicImportFileConfigModel dynamicImportFileConfigModel = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                List<DynamicImportFileConfigModel> FileConfigList = connection.Query<DynamicImportFileConfigModel>("uspGetDynamicFileConfigDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (FileConfigList != null && FileConfigList.Count > 0)
                {
                    dynamicImportFileConfigModel = FileConfigList[0];
                }
            }

            if (dynamicImportFileConfigModel == null)
            {
                dynamicImportFileConfigModel = new DynamicImportFileConfigModel();
            }

            return dynamicImportFileConfigModel;
        }

        public ConfiguredColumnJsonString GetConfiguredColumnJsonString(string FileConfigID)
        {
            ConfiguredColumnJsonString configuredColumnJsonString = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                List<ConfiguredColumnJsonString> FileConfigList = connection.Query<ConfiguredColumnJsonString>("uspGetDynamicFileColumnJsonString", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (FileConfigList != null && FileConfigList.Count > 0)
                {
                    configuredColumnJsonString = FileConfigList[0];
                }
            }

            if (configuredColumnJsonString == null)
            {
                configuredColumnJsonString = new ConfiguredColumnJsonString();
            }

            return configuredColumnJsonString;
        }


        public List<XMLColumnModel> GetDynamicColumnsForMapping(string FileConfigID)
        {
            List<XMLColumnModel> ReconColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                ReconColumns = connection.Query<XMLColumnModel>("uspGetDynamicColumnsForMapping", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconColumns == null)
            {
                ReconColumns = new List<XMLColumnModel>();
            }
            return ReconColumns;

        }

        public DynamicFileConfigDataModel GetDynamicFileConfigData(string FileConfigID)
        {
            DynamicFileConfigDataModel dynamicImportFileConfigModel = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                List<DynamicFileConfigDataModel> FileConfigList = connection.Query<DynamicFileConfigDataModel>("uspGetDynamicFileConfigData", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (FileConfigList != null && FileConfigList.Count > 0)
                {
                    dynamicImportFileConfigModel = FileConfigList[0];
                }
            }

            if (dynamicImportFileConfigModel == null)
            {
                dynamicImportFileConfigModel = new DynamicFileConfigDataModel();
            }

            return dynamicImportFileConfigModel;
        }

        public string UpdateMappedColumnJsonString(DynamicFileMappedColumn reconConfigModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", reconConfigModel.FileConfigID);
                param.Add("@MappedColumnString", reconConfigModel.MappedColumnString);
                result = connection.ExecuteScalar<string>("uspUpdateXMLColumnString", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public string GetConfiguredRawColumnString(string FileConfigID)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);
                result = connection.ExecuteScalar<string>("uspGetDynamicFileRawColumnString", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }

        public List<XMLColumnModel> GetRawTableSelectedColumns(string FileConfigID)
        {
            List<XMLColumnModel> ReconColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                ReconColumns = connection.Query<XMLColumnModel>("uspGetDynamicFileRawTableSelectedColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconColumns == null)
            {
                ReconColumns = new List<XMLColumnModel>();
            }
            return ReconColumns;

        }

        public List<RawTableColumn> GetRawTableAllColumns(string FileConfigID)
        {
            List<RawTableColumn> ReconColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                ReconColumns = connection.Query<RawTableColumn>("uspGetDynamicFileRawTableAllColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconColumns == null)
            {
                ReconColumns = new List<RawTableColumn>();
            }
            return ReconColumns;

        }

        public string UpdateQueryXMLString(DynamicFileXMLModel reconConfigModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", reconConfigModel.FileConfigID);
                param.Add("@XMLString", reconConfigModel.XMLString);
                param.Add("@QueryString", reconConfigModel.QueryString);
                param.Add("@RawColumnString", reconConfigModel.RawColumnString);
                param.Add("@MappedColumnString", reconConfigModel.MappedColumnString);
                result = connection.ExecuteScalar<string>("uspUpdateDynamicFileQueryandXML", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public string ParseSqlQuery(DynamicFileMappedColumn reconConfigModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", reconConfigModel.FileConfigID);
                param.Add("@QueryString", reconConfigModel.MappedColumnString);
                result = connection.ExecuteScalar<string>("ParseSqlQueryRecon", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public DateTimeFormat GetDateTimeFormat(string FileConfigID, string TableName)
        {
            DateTimeFormat configuredColumnJsonString = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID); 

                List<DateTimeFormat> FormatList = connection.Query<DateTimeFormat>("uspGetDateTimeFormatString", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (FormatList != null && FormatList.Count > 0)
                {
                    configuredColumnJsonString = FormatList[0];
                }
            }

            if (configuredColumnJsonString == null)
            {
                configuredColumnJsonString = new DateTimeFormat();
            }

            return configuredColumnJsonString;
        }

        public string UpdateDateTimeFormat(DateTimeFormat dateTimeFormat)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", dateTimeFormat.FileConfigID);
                param.Add("@TxnDateTimeDateFormat", (dateTimeFormat.TxnDateTimeDateFormat == null || dateTimeFormat.TxnDateTimeDateFormat.Length == 0) ? null : dateTimeFormat.TxnDateTimeDateFormat);
                param.Add("@TxnValueDateTimeDateFormat", (dateTimeFormat.TxnValueDateTimeDateFormat == null || dateTimeFormat.TxnValueDateTimeDateFormat.Length == 0) ? null : dateTimeFormat.TxnValueDateTimeDateFormat);
                param.Add("@TxnPostDateTimeDateFormat", (dateTimeFormat.TxnPostDateTimeDateFormat == null || dateTimeFormat.TxnPostDateTimeDateFormat.Length == 0) ? null : dateTimeFormat.TxnPostDateTimeDateFormat);
                param.Add("@FileDateFormat", (dateTimeFormat.FileDateFormat == null || dateTimeFormat.FileDateFormat.Length == 0) ? null : dateTimeFormat.FileDateFormat);

                param.Add("@TxnAmountIsDecimal", (dateTimeFormat.DecimalNumber == null || dateTimeFormat.DecimalNumber.Length == 0) ? null : dateTimeFormat.DecimalNumber);
                param.Add("@AllowedExtensions", (dateTimeFormat.AllowedExtensions == null || dateTimeFormat.AllowedExtensions.Length == 0) ? null : dateTimeFormat.AllowedExtensions);
                param.Add("@FileNameContains", (dateTimeFormat.FileNameContains == null || dateTimeFormat.FileNameContains.Length == 0) ? null : dateTimeFormat.FileNameContains);
                param.Add("@SFTPPath", (dateTimeFormat.SFTPPath == null || dateTimeFormat.SFTPPath == "null" || dateTimeFormat.SFTPPath.Length == 0) ? null : dateTimeFormat.SFTPPath);
                param.Add("@StartPosition", (dateTimeFormat.StartPosition == null || dateTimeFormat.StartPosition == "null" || dateTimeFormat.StartPosition.Length == 0) ? null : dateTimeFormat.StartPosition);
                param.Add("@EndPosition", (dateTimeFormat.EndPosition == null || dateTimeFormat.EndPosition == "null" || dateTimeFormat.EndPosition.Length == 0) ? null : dateTimeFormat.EndPosition);

                result = connection.ExecuteScalar<string>("uspUpdateDateTimeFormatFileConfig", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public string GetDynamicFileConfigTable(string FileConfigID)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters(); 
                param.Add("@FileConfigID", FileConfigID);
                result = connection.ExecuteScalar<string>("uspGetDynamicFileConfigTable", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public List<DynamicChannelConfigModel> GetDynamicChannelConfigGrid(string ClientID)
        {
            List<DynamicChannelConfigModel> ConfigGrid = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID); 

                ConfigGrid = connection.Query<DynamicChannelConfigModel>("uspGetDynamicChannelConfigGrid", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ConfigGrid == null)
            {
                ConfigGrid = new List<DynamicChannelConfigModel>();
            }
            return ConfigGrid;
        }

        public string AddUpdateChannelConfig(DynamicChannelModeConfigModel dynamicFileConfigModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", dynamicFileConfigModel.ClientID); 
                param.Add("@ChannelID", dynamicFileConfigModel.ChannelID);
                param.Add("@ModeID", dynamicFileConfigModel.ModeID);
                param.Add("@CreatedBy", dynamicFileConfigModel.UserName);
                result = connection.ExecuteScalar<string>("uspAddUpdateDynamicChannelModeConfig", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public string DeleteChannelModeConfig(DeleteChannelConfigModel objDeleteChannelConfigModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters(); 
                param.Add("@ConfigID", objDeleteChannelConfigModel.ConfigID);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspDeleteChannelModeConfig", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }

        public string AddUpdateFileContent(DynamicFileContentModel dynamicFileContentModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ConfigID", dynamicFileContentModel.ConfigID);
                param.Add("@FileColumnString", dynamicFileContentModel.FileColumnString);
                param.Add("@FirstRow", dynamicFileContentModel.FirstRow);
                param.Add("@SecondRow", dynamicFileContentModel.SecondRow);
                param.Add("@ThirdRow", dynamicFileContentModel.ThirdRow);
                param.Add("@FourthRow", dynamicFileContentModel.FourthRow);
                param.Add("@FifthRow", dynamicFileContentModel.FifthRow);
                param.Add("@CreatedBy", dynamicFileContentModel.UserName);

                result = connection.ExecuteScalar<string>("uspAddUpdateDynamicFileContentData", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public List<ClientOptionModel> GetClientListByConfig(DynamicFileConfigModel dynamicFileConfigModel)
        {             
            List<ClientOptionModel> ClientOptionList = null;            

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", dynamicFileConfigModel.ClientID);
                param.Add("@NetworkType", dynamicFileConfigModel.NetworkType);
                param.Add("@LogTypeID", dynamicFileConfigModel.LogTypeID);
                param.Add("@VendorID", dynamicFileConfigModel.VendorID);
                param.Add("@ChannelID", dynamicFileConfigModel.ChannelID);
                param.Add("@ModeID", dynamicFileConfigModel.ModeID);
                param.Add("@CreatedBy", dynamicFileConfigModel.UserName);
                ClientOptionList = connection.Query<ClientOptionModel>("uspGetClientbyConfig", param, commandType: System.Data.CommandType.StoredProcedure).AsList(); 
            }

            if (ClientOptionList == null)
            {
                ClientOptionList = new List<ClientOptionModel>();
            }

            return ClientOptionList;
        }

        public string CopyDynamicFileConfig(tempDynamicFileConfigModel dynamicFileConfigModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", dynamicFileConfigModel.ClientID);
                param.Add("@NetworkType", dynamicFileConfigModel.NetworkType);
                param.Add("@LogTypeID", dynamicFileConfigModel.LogTypeID);
                param.Add("@VendorID", dynamicFileConfigModel.VendorID);
                param.Add("@ChannelID", dynamicFileConfigModel.ChannelID);
                param.Add("@ModeID", dynamicFileConfigModel.ModeID);
                param.Add("@CreatedBy", dynamicFileConfigModel.UserName); 
                param.Add("@ClientIDToCopy", dynamicFileConfigModel.ClientIDToCopy);
                result = connection.ExecuteScalar<string>("uspCopyDynamicFileConfig", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public DynamicFileContentModel GetFileContent(string FileConfigID)
        {
            DynamicFileContentModel dynamicFileContentModel = null; 
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                List<DynamicFileContentModel> ModelList = connection.Query<DynamicFileContentModel>("uspGetDynamicFileContent", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (ModelList != null && ModelList.Count > 0)
                {
                    dynamicFileContentModel = ModelList[0];
                }
            } 

            return dynamicFileContentModel;
        }
    }

}
