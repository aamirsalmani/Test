﻿using Dapper;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Data; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using System.Text.Json;
using Utility;

namespace ASPTrace.Repository
{
    public class DynamicImportLogsRepository : IDynamicImportLogs
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public DynamicImportLogsRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<ClientOptionModel> GetClientOptions(string UserID)
        {
            List<ClientOptionModel> clientOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                clientOptionModelsList = connection.Query<ClientOptionModel>("uspGetClientList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientOptionModelsList == null)
            {
                clientOptionModelsList = new List<ClientOptionModel>();
            }

            return clientOptionModelsList;
        }

        public List<FileTypeOptionModel> GetFileTypeOptions(string ClientID)
        {
            List<FileTypeOptionModel> OptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                OptionModelsList = connection.Query<FileTypeOptionModel>("uspGetFileTypeList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (OptionModelsList == null)
            {
                OptionModelsList = new List<FileTypeOptionModel>();
            }
            return OptionModelsList;
        }

        public DataTable GetDynamicFieldDetailsById(string ClientID, string FormatID)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandText = "uspGetDynamicFieldDetailsByFormatId";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.BigInt).Value = ClientID;
                        cmd.Parameters.AddWithValue("@FormatID", SqlDbType.BigInt).Value = FormatID;

                        connExcel.Open();
                        da.SelectCommand = cmd;
                        da.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }

        //public string BulkInsertSWITCHTable(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        int batchSize = 2500000;
        //        int totalRows = __DataTable.Rows.Count;
        //        int batchCount = (int)Math.Ceiling((double)totalRows / batchSize);

        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            connExcel.Open();
        //            for (int i = 0; i < batchCount; i++)
        //            {
        //                int startRow = i * batchSize;
        //                int endRow = Math.Min(startRow + batchSize, totalRows);
        //                var batchRows = __DataTable.AsEnumerable().Skip(startRow).Take(endRow - startRow).CopyToDataTable();

        //                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //                {
        //                    cmd.Connection = connExcel;
        //                    cmd.CommandTimeout = 1000000;
        //                    cmd.CommandText = "uspBulkInsertSWITCHData";
        //                    cmd.CommandType = CommandType.StoredProcedure;
        //                    cmd.Parameters.AddWithValue("@SWITCH", batchRows);
        //                    cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                    cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                    cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                    cmd.Parameters.AddWithValue("@FileName", FileName);
        //                    cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                    cmd.ExecuteNonQuery();
        //                }
        //            }
        //            connExcel.Close();
        //            return "Successful";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process: " + ex.Message;
        //    }
        //}


        //public string BulkInsertSWITCHTable(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertSWITCHData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@SWITCH", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //public string BulkInsertSWITCHTableUPI(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertSWITCHDataUPI";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@SWITCH", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //InsertLogs(ex.Message.ToString(), "56", "DynamicImportLogsRepository.cs", "BulkInsertSWITCHTableUPI", 0, FileName, UserName, 'E', _connectionString);
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        public static void InsertLogs(string Msg, string ClientCode, string FormName, string FunctionName, int Lineno, string Filename, string UserName, char LogType, string connectionString)
        {
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {

                    cmd.Parameters.AddWithValue("@LogType", LogType);
                    cmd.Parameters.AddWithValue("@ClientCode", ClientCode);
                    cmd.Parameters.AddWithValue("@MachineIP", FormName);
                    cmd.Parameters.AddWithValue("@Description", Msg);
                    cmd.Parameters.AddWithValue("@UploadFilename", Filename);
                    cmd.Parameters.AddWithValue("@LineNo", Lineno);
                    cmd.Parameters.AddWithValue("@MethodName", FunctionName);
                    cmd.Parameters.AddWithValue("@UploadBy", UserName);

                    cmd.CommandText = "UspInsertLogs";
                    cmd.Connection = connection;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    connection.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        //public string BulkInsertCBSTable(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        int batchSize = 2500000;
        //        int totalRows = __DataTable.Rows.Count;
        //        int batchCount = (int)Math.Ceiling((double)totalRows / batchSize);

        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            connExcel.Open();
        //            for (int i = 0; i < batchCount; i++)
        //            {
        //                int startRow = i * batchSize;
        //                int endRow = Math.Min(startRow + batchSize, totalRows);
        //                var batchRows = __DataTable.AsEnumerable().Skip(startRow).Take(endRow - startRow).CopyToDataTable();

        //                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //                {
        //                    cmd.Connection = connExcel;
        //                    cmd.CommandTimeout = 1000000;
        //                    cmd.CommandText = "uspBulkInsertCBSData";
        //                    cmd.CommandType = CommandType.StoredProcedure;
        //                    cmd.Parameters.AddWithValue("@CBS", batchRows);
        //                    cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                    cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                    cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                    cmd.Parameters.AddWithValue("@FileName", FileName);
        //                    cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                    cmd.ExecuteNonQuery();
        //                }
        //            }
        //            connExcel.Close();
        //            return "Successful";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process: " + ex.Message;
        //    }
        //}


        //public string BulkInsertCBSTable(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertCBSData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@CBS", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}



        //public string BulkInsertIssuerDataUPITable(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertUPIIssuerData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //public string BulkInsertAcquirerDataUPITable(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertUPIAcquirerData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}
        //public string BulkInsertIssuerDataIMPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertIMPSIssuerData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //public string BulkInsertAcquirerDataIMPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertIMPSAcquirerData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //public string BulkInsertSettlementDataATM(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertATMSettlementData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //public string BulkInsertIssuerDataPOS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertPOSIssuerData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}


        //public string BulkInsertIssuerDataATM(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        int batchSize = 2500000;// 25 Lakh
        //        int totalRows = __DataTable.Rows.Count;
        //        int batchCount = (int)Math.Ceiling((double)totalRows / batchSize);

        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            connExcel.Open();
        //            for (int i = 0; i < batchCount; i++)
        //            {
        //                int startRow = i * batchSize;
        //                int endRow = Math.Min(startRow + batchSize, totalRows);
        //                var batchRows = __DataTable.AsEnumerable().Skip(startRow).Take(endRow - startRow).CopyToDataTable();
        //                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //                {
        //                    cmd.Connection = connExcel;
        //                    cmd.CommandTimeout = 1000000;
        //                    cmd.CommandText = "uspBulkInsertATMIssuerData";
        //                    cmd.CommandType = CommandType.StoredProcedure;
        //                    cmd.Parameters.AddWithValue("@NETWORK", batchRows); 
        //                    cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                    cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                    cmd.Parameters.AddWithValue("@FileName", FileName);
        //                    cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                    cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                    cmd.ExecuteNonQuery();
        //                }
        //            }
        //            connExcel.Close();
        //            return "Successful";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process: " + ex.Message;
        //    }
        //}


        //public string BulkInsertIssuerDataATM(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertATMIssuerData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //public string BulkInsertAcquirerDataATM(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertATMAcquirerData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}
        //public string BulkInsertNPCIAdjustmentATM(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertNPCIAdjustmentATM";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //public string BulkInsertSettlementDataIMPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertIMPSSettlementData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //public string BulkInsertSettlementDataUPI(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertUPISettlementData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        // BulkInsertAcquirerDataAEPS
        //public string BulkInsertAcquirerDataAEPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspDynamicBulkInsertAEPSAcquirerData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}
        //public string BulkInsertIssuerDataAEPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspDynamicBulkInsertAEPSIssuerData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //public string BulkInsertSettlementDataAEPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertAEPSSettlementData";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //UPI Adj
        //public string BulkInsertNPCIAdjustmentUPI(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertNPCIAdjustmentUPI";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}

        //public string BulkInsertNPCIAdjustmentIMPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        //{
        //    try
        //    {
        //        using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
        //        {
        //            using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
        //            {
        //                cmd.Connection = connExcel;
        //                cmd.CommandTimeout = 1000000;
        //                cmd.CommandText = "uspBulkInsertAdjustmentIMPS";
        //                cmd.CommandType = CommandType.StoredProcedure;
        //                cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
        //                cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
        //                cmd.Parameters.AddWithValue("@FileDate", FileDate);
        //                cmd.Parameters.AddWithValue("@FilePath", FilePath);
        //                cmd.Parameters.AddWithValue("@FileName", FileName);
        //                cmd.Parameters.AddWithValue("@CreatedBy", UserName);
        //                connExcel.Open();
        //                cmd.ExecuteNonQuery();
        //                connExcel.Close();
        //                return "Successful";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return "An error occurred during the bulk insert process;";
        //    }
        //}


        //Batch Processing
       //public int GetBatchSize(string ConfigID)
       // {
       //     try
       //     {
       //         using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
       //         {
       //             using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
       //             {
       //                 cmd.Connection = connExcel;
       //                 cmd.CommandTimeout = 10000;
       //                 cmd.CommandText = "spGetBatchSize";
       //                 cmd.CommandType = CommandType.StoredProcedure;
       //                 cmd.Parameters.AddWithValue("@ConfigID", ConfigID);

       //                 connExcel.Open();

       //                 object result = cmd.ExecuteScalar();
       //                 return result != null ? Convert.ToInt32(result) : 100000;
       //             }
       //         }
       //     }
       //     catch (Exception ex)
       //     {
       //         return 10000; 
       //     }
       // }

        public List<BatchDetails> GetStartBatchPosition(string FileName, int ClientID, int ChannelID, int ModeID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("GetBatchDetails", connExcel))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 1000000;
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@ClienID", ClientID);
                        cmd.Parameters.AddWithValue("@ChannelID", ChannelID);
                        cmd.Parameters.AddWithValue("@ModeID", ModeID);

                        connExcel.Open();
                        object result = cmd.ExecuteScalar();

                        // Convert the result (JSON string) to a List of BatchDetails
                        if (result != null)
                        {
                            string jsonString = Convert.ToString(result);
                            List<BatchDetails> allBatches = JsonConvert.DeserializeObject<List<BatchDetails>>(jsonString);
                             return allBatches; 
                        }
                        else
                        {
                            return new List<BatchDetails>(); 
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return new List<BatchDetails>();
            }
        }




    }
}
