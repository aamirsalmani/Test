﻿using Microsoft.Extensions.Configuration;
using System.Text;
using ASPTrace.Contracts;
using ASPTrace.Models;
using System.Data;
using Dapper;
using Newtonsoft.Json;
using DataTable = System.Data.DataTable;


namespace ASPTrace.Repository
{
    public class DynamicReconConfigRepository : IDynamicReconConfig
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public DynamicReconConfigRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }
        public List<ReconTablesModel> GetReconTables(int ChannelID, int ModeID)
        {
            List<ReconTablesModel> ReconType = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);

                ReconType = connection.Query<ReconTablesModel>("spGetTables"
                    , param
                    , commandType: System.Data.CommandType.StoredProcedure
                    ).AsList();
            }

            if (ReconType == null)
            {
                ReconType = new List<ReconTablesModel>();
            }
            return ReconType;

        }

        public List<VendorFieldModel> GetNetworkList(string ClientID)
        {
            List<VendorFieldModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                clientFieldModelsList = connection.Query<VendorFieldModel>("spGetNetworkType", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<VendorFieldModel>();
            }
            return clientFieldModelsList;
        }
        public string GetPreset(int ClientID, int NetworkType, int ChannelID, int ModeID)
        {
            List<string> Data;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@ReconType", NetworkType);

                Data = connection.Query<string>("spGetPresetKS", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (Data.Count == 0)
            {
                Data = new List<string>();

                return null;
            }

            return Data[0];
        }
        public List<OptionModel> GetOtherPreset( int NetworkType, int ChannelID, int ModeID,int PresetType)
        {
            List<OptionModel> Data;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@NetworkType", NetworkType);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@Type", PresetType);

                Data = connection.Query<OptionModel>("GetOtherReconPreset", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (Data.Count == 0)
            {
                Data = new List<OptionModel>();

                return null;
            }

            return Data;
        }
        public string GetReconAliasColumns(int ChannelID, int ModeID, int VendorType, int Type)
        {
            List<OptionsArray> ReconColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@VendorType", VendorType);
                param.Add("@TYPE", Type);

                ReconColumns = connection.Query<OptionsArray>("spGetAliasColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconColumns == null)
            {
                ReconColumns = new List<OptionsArray>();
            }

            string json = JsonConvert.SerializeObject(ReconColumns, Formatting.Indented);


            return json;

        }
        public List<OptionsArray> GetTablesColumns(string TableName)
        {
            List<OptionsArray> ColumnsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TableName", TableName);

                ColumnsList = connection.Query<OptionsArray>("spGetOptionColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ColumnsList == null)
            {
                ColumnsList = new List<OptionsArray>();
            }

            return ColumnsList;
        }

        public List<AliasReconColumnsModel> ConvertToTableData(List<ReconAliasColumnsModel> reconAliasList)
        {
            List<AliasReconColumnsModel> tableData = new List<AliasReconColumnsModel>();

            foreach (var item in reconAliasList)
            {
                tableData.Add(new AliasReconColumnsModel
                {
                    ID = item.ColumnID,
                    AliasColumn = item.AliasColumn,
                    TableAlias = new OptionsArray
                    {
                        value = item.ColumnID.ToString()
                        ,
                        label = "Select"
                    },
                    DataColumn = new OptionsArray
                    {
                        value = item.ColumnID.ToString()
                        ,
                        label = "Select"
                    },
                    CaseStatement = "",
                    ActionsMenu = new ActionsMenu
                    {
                        Edit = false,
                        Delete = false
                    }
                });
            }

            return tableData;
        }
        public List<OptionsArray> GetOperations(string type = "0")
        {
            List<OptionsArray> Operations = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@Type", type);

                Operations = connection.Query<OptionsArray>("spGetOperations",
                 param,
                 commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (Operations == null)
            {
                Operations = new List<OptionsArray>();
            }
            return Operations;

        }
        public string GetUnmatchedColumns(int ChannelID)
        {
            List<UnmatchedColumnsModel> UnmatchedColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ChannelID", ChannelID);

                UnmatchedColumns = connection.Query<UnmatchedColumnsModel>("spGetUnmatchColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (UnmatchedColumns == null)
            {
                UnmatchedColumns = new List<UnmatchedColumnsModel>();
            }


            var FinalData = UnmatchedColumns;

            string json = JsonConvert.SerializeObject(FinalData, Formatting.Indented);


            return json;
        }
        public string GetUnmatchedAllColumns(int ChannelID)
        {
            List<UnmatchedColumnsModel> UnmatchedColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ChannelID", ChannelID);

                UnmatchedColumns = connection.Query<UnmatchedColumnsModel>("spGetUnmatchAllColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (UnmatchedColumns == null)
            {
                UnmatchedColumns = new List<UnmatchedColumnsModel>();
            }


            var FinalData = UnmatchedColumns;

            string json = JsonConvert.SerializeObject(FinalData, Formatting.Indented);


            return json;
        }
        public string PostJoinTables(ReconQueryFields ClientDetails, List<JoinTableModel> JoinTables)
        {

            string outputValue = string.Empty;
            List<ReconAliasColumnsModel> ReconAliasList = null;
            string JoinsData = JsonConvert.SerializeObject(JoinTables);
            if (JoinTables.Count == 1)
            {
                QueryFormJSON newValues = new QueryFormJSON
                {
                    ClientID = Convert.ToInt32(ClientDetails.ClientID),
                    ChannelID = Convert.ToInt32(ClientDetails.ChannelID),
                    ModeID = Convert.ToInt32(ClientDetails.ModeID),
                    ReconType = Convert.ToInt32(ClientDetails.ReconType),
                    TempData = new List<TempDataJSON>
                    {
                        new TempDataJSON
                        {
                            TableNo = ClientDetails.Selectedtable.TableNo,
                            TableName = ClientDetails.Selectedtable.TableName,
                            Query = null,
                            isMultiTable = false,
                            MultiTableJOIN = JoinTables[0].SelectedTable.label,
                            WHERE = null
                        }
                    }
                };

                string Status = UpdateQueryFORM(newValues);

            }
            else
            {

                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    try
                    {
                        param.Add("@ClientID", ClientDetails.ClientID);
                        param.Add("@ChannelID", ClientDetails.ChannelID);
                        param.Add("@ModeID", ClientDetails.ModeID);
                        param.Add("@JoinsData", JoinsData);
                        param.Add("@Output", dbType: DbType.String, size: 100, direction: ParameterDirection.Output);
                        connection.Query("spInsertJoinsData", param, commandType: CommandType.StoredProcedure);
                        outputValue = param.Get<string>("@Output");
                    }
                    catch (Exception ex)
                    {
                        outputValue = ex.Message;

                    }

                }




                string MultiTableJOIN = GenerateJoinQuery(JoinTables);

                QueryFormJSON newValues = new QueryFormJSON
                {
                    ClientID = Convert.ToInt32(ClientDetails.ClientID),
                    ChannelID = Convert.ToInt32(ClientDetails.ChannelID),
                    ModeID = Convert.ToInt32(ClientDetails.ModeID),
                    ReconType = Convert.ToInt32(ClientDetails.ReconType),
                    TempData = new List<TempDataJSON>
                    {
                        new TempDataJSON
                        {
                            TableNo = ClientDetails.Selectedtable.TableNo,
                            TableName = ClientDetails.Selectedtable.TableName,
                            Query = null,
                            isMultiTable = true,
                            MultiTableJOIN = MultiTableJOIN,
                            WHERE = null
                        }
                    }
                };

                string Status = UpdateQueryFORM(newValues);

            }


            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                try
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    param.Add("@ChannelID", ClientDetails.ChannelID);
                    param.Add("@ModeID", ClientDetails.ModeID);
                    param.Add("@VendorType", ClientDetails.VendorType);
                    param.Add("@TYPE", ClientDetails.ReconType);

                    ReconAliasList = connection.Query<ReconAliasColumnsModel>("spGetAliasColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                }
                catch (Exception ex)
                {


                }
            }








            if (ReconAliasList == null)
            {
                ReconAliasList = new List<ReconAliasColumnsModel>();
            }

            var TableInformation = new List<TableInfo>();

            foreach (var item in JoinTables)
            {
                var OptionsList = new List<OptionsArray>();
                string Tablename = item.SelectedTable.label;
                try
                {
                    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                    {
                        connection.Open();
                        var param = new DynamicParameters();
                        param.Add("@Tablename", Tablename);

                        OptionsList = connection.Query<OptionsArray>("spGetOptionColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                    }
                }
                catch (Exception ex)
                {

                }



                TableInformation.Add(new TableInfo
                {
                    ID = item.ID,
                    TableName = item.SelectedTable,
                    Options = OptionsList
                });
            }


            CaseDataModel FinalData = new CaseDataModel
            {
                AliasColumnsData = ConvertToTableData(ReconAliasList),
                TableInfoData = TableInformation
            };

            string json = JsonConvert.SerializeObject(FinalData, Formatting.Indented);


            return json;

        }
        public DataTable GenerateRecon(ReconQueryFields reconQueryFields)
        {


            DataTable dtRecords = new DataTable();
            string table = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spTempDataKS", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientID", reconQueryFields.ClientID);
                    cmd.Parameters.AddWithValue("@ChannelID", reconQueryFields.ChannelID);
                    cmd.Parameters.AddWithValue("@Mode", reconQueryFields.ModeID);
                    cmd.Parameters.AddWithValue("@ReconType", reconQueryFields.ReconType);


                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dtRecords);
                    }
                }
            }



            return dtRecords;

        }

        public DataTable GetAllUnmatchColumns(string ChannelID)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter odaDEK = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        connExcel.Open();
                        cmd.CommandText = "uspGetAllUnmatchColumns";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ChannelID", ChannelID); 

                        odaDEK.SelectCommand = cmd;
                        odaDEK.Fill(dt);
                        connExcel.Close();
                    }
                }
            }
            return dt;
        }

        public string GenerateReconQuery(int ClientID, int NetworkType, int ChannelID, int ModeID)
        {

            List<string> Data;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@ReconType", NetworkType);

                Data = connection.Query<string>("spGetPresetKS", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (Data.Count == 0)
            {
                Data = new List<string>();

                return null;
            }
            try
            {

                var FormData = JsonConvert.DeserializeObject<RootObject>(Data[0]);
                var sqlQueryBuilder = new SQLQueryBuilder();
                DataTable dtUnmatchColumns = GetAllUnmatchColumns(ChannelID.ToString()); // Replace with your actual dataTable
                List<TablesQuery> tablesQuery = sqlQueryBuilder.BuildQueries(FormData, dtUnmatchColumns, ChannelID,  ModeID);

                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("ClientID", typeof(int));
                dataTable.Columns.Add("NetworkType", typeof(string));
                dataTable.Columns.Add("ChannelID", typeof(int));
                dataTable.Columns.Add("ModeID", typeof(int));
                dataTable.Columns.Add("OrderNo", typeof(int));
                dataTable.Columns.Add("TableName", typeof(string));
                dataTable.Columns.Add("JOIN", typeof(string));
                dataTable.Columns.Add("Query", typeof(string));
                dataTable.Columns.Add("IsRemoved", typeof(bool));
                dataTable.Columns.Add("CreatedBy", typeof(string));
                dataTable.Columns.Add("ModifiedBy", typeof(string));
                dataTable.Columns.Add("CreatedOn", typeof(DateTime));
                dataTable.Columns.Add("ModifiedOn", typeof(DateTime));

                for (int i = 0; i < tablesQuery.Count; i++)
                {
                    dataTable.Rows.Add(ClientID, NetworkType, ChannelID, ModeID, tablesQuery[i].OrderNo, tablesQuery[i].TableName, tablesQuery[i].JOIN, tablesQuery[i].Query, 0, "System", null, DateTime.Now, null);
                }

                DataTable dtRecords = new DataTable();
                try
                {

                    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                    {
                        using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("BulkInsertReconTablesQueryData", connection))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@ReconTablesQuery", dataTable);
                            using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                            {
                                sda.Fill(dtRecords);
                            }
                        }
                    }
                    return "Successful";
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }


            }
            catch (Exception ex)
            {
                return ex.Message;
            }




        }

        public string PostFormData(FormValues formValues)
        {
            DataTable dtRecords = new DataTable();
            string table = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spUploadFormData", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientID", formValues.ClientID);
                    cmd.Parameters.AddWithValue("@NetworkType", formValues.NetworkType);
                    cmd.Parameters.AddWithValue("@ChannelID", formValues.ChannelID);
                    cmd.Parameters.AddWithValue("@ModeID", formValues.ModeID);
                    cmd.Parameters.AddWithValue("@FormData", formValues.Form);

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dtRecords);
                    }
                }
            }

            return "Post Successful";
        }
        public string PostCaseTable(CaseTableForm ClientParameters, List<AliasReconColumnsModel> PostCaseTable)
        {
            var queryString = PostCaseTable.Select(item =>
            {
                try
                {


                    if (item.CaseStatement == "")
                        return item.AliasColumn + " as " + item.AliasColumn;
                    else if (!string.IsNullOrEmpty(item.CaseStatement) && item.CaseStatement != "")
                        return item.CaseStatement + " as " + item.AliasColumn;
                    else
                        return item.AliasColumn + " as " + item.AliasColumn;
                }
                catch (Exception)
                {
                    return "Error Occurred";
                }
            }).ToList();

            var TableName = ClientParameters.Table?.TableName;
            var TableNo = ClientParameters.Table?.TableNo;

            var finalQuery = "select " + string.Join(",", queryString) + " from "; // + rawTable;

            TempDataJSON myData = new TempDataJSON
            {
                TableNo = Convert.ToInt32(TableNo),
                TableName = TableName,
                Query = finalQuery
            };

            string jsonString = JsonConvert.SerializeObject(myData);

            string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Upload", "DynamicRecon", "QueryData.json");

            if (File.Exists(filePath))
            {
                var FileData = File.ReadAllText(filePath);
                var JsonFileData = JsonConvert.DeserializeObject<QueryFormJSON>(FileData);

                if (JsonFileData != null)
                {



                    foreach (var item in JsonFileData.TempData)
                    {
                        var existingData = JsonFileData.TempData.Find(x => x.TableNo == myData.TableNo);

                        if (existingData != null)
                        {
                            // Merge properties of TempData
                            existingData.TableNo = myData.TableNo;
                            existingData.TableName = myData.TableName ?? existingData.TableName;
                            existingData.Query = myData.Query ?? existingData.Query;
                            existingData.MultiTableJOIN = myData.MultiTableJOIN ?? existingData.MultiTableJOIN;
                            existingData.WHERE = myData.WHERE ?? existingData.WHERE;
                        }
                        else
                        {
                            // Add new TempData if it doesn't exist in the existing list
                            JsonFileData.TempData.Add(myData);
                        }
                    }

                    string updatedJsonString = JsonConvert.SerializeObject(JsonFileData, Formatting.Indented);
                    File.WriteAllText(filePath, updatedJsonString);
                }
            }
            else
            {
                string newData = "[" + jsonString + "]";
                File.WriteAllText(filePath, newData);
            }




            return finalQuery;
        }
        public QueryFormJSON MergeValues(QueryFormJSON existingRoot, QueryFormJSON newValues)
        {
            // Merge properties
            existingRoot.ClientID = newValues.ClientID;
            existingRoot.ChannelID = newValues.ChannelID;
            existingRoot.ModeID = newValues.ModeID;
            existingRoot.ReconType = newValues.ReconType;

            // Merge TempData
            if (newValues.TempData != null)
            {
                foreach (var newData in newValues.TempData)
                {
                    var existingData = existingRoot.TempData.Find(x => x.TableNo == newData.TableNo);
                    if (existingData != null)
                    {
                        // Merge properties of TempData
                        existingData.TableNo = newData.TableNo;
                        existingData.TableName = newData.TableName ?? existingData.TableName;
                        existingData.Query = newData.Query ?? existingData.Query;
                        existingData.isMultiTable = newData.isMultiTable;
                        existingData.MultiTableJOIN = newData.MultiTableJOIN ?? existingData.MultiTableJOIN;
                        existingData.WHERE = newData.WHERE ?? existingData.WHERE;
                    }
                    else
                    {
                        // Add new TempData if it doesn't exist in the existing list
                        existingRoot.TempData.Add(newData);
                    }
                }
            }


            return existingRoot;
        }
        public string UpdateQueryFORM(QueryFormJSON newValues)
        {
            string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Upload", "DynamicRecon", "QueryData.json");
            try
            {

                if (File.Exists(filePath))
                {
                    var FileData = File.ReadAllText(filePath);
                    var ExistingValues = JsonConvert.DeserializeObject<QueryFormJSON>(FileData);

                    if (ExistingValues != null)
                    {
                        var JsonFileData = MergeValues(ExistingValues, newValues);
                        string updatedJsonString = JsonConvert.SerializeObject(JsonFileData, Formatting.Indented);
                        File.WriteAllText(filePath, updatedJsonString);
                    }
                    else
                    {
                        string newData = JsonConvert.SerializeObject(newValues, Formatting.Indented);
                        File.WriteAllText(filePath, newData);
                    }
                }
                else
                {
                    string newData = JsonConvert.SerializeObject(newValues, Formatting.Indented);
                    File.WriteAllText(filePath, newData);
                }



                return "Successful";

            }
            catch (Exception ex)
            {
                return ex.Message;

            }
        }
        public string GenerateJoinQuery(List<JoinTableModel> joinConfigs)
        {
            string joinQuery = "";
            for (int i = 0; i < joinConfigs.Count; i++)
            {
                JoinTableModel joinConfig = joinConfigs[i];
                string tableAlias = "T" + (i + 1);
                string joinType = i < joinConfigs.Count - 1 ? joinConfig.SelectedJoin.label.ToUpper() : "";
                string tableName = joinConfig.SelectedTable.label;

                joinQuery += $"{tableName} {tableAlias} {joinType} ";
            }
            for (int i = 0; i < joinConfigs.Count; i++)
            {
                JoinTableModel joinConfig = joinConfigs[i];
                string tableAlias = "T" + (i + 1);
                if (i < joinConfigs.Count - 1)
                {
                    joinQuery += "ON ";
                    for (int j = 0; j < joinConfig.SelectedColumns.Count; j++)
                    {
                        string columnName = joinConfig.SelectedColumns[j].Value.label;
                        joinQuery += $"{tableAlias}.{columnName} = T{i + 2}.{columnName}";

                        if (j < joinConfig.SelectedColumns.Count - 1)
                        {
                            joinQuery += " AND ";
                        }
                    }
                }

                if (i < joinConfigs.Count - 1)
                {
                    joinQuery += " ";
                }
            }

            return joinQuery;
        }
    }
    public class SQLQueryBuilder
    {
        public List<TablesQuery> BuildQueries(RootObject rootObject, DataTable dtUnmatchColumns, int ChannelID, int ModeID)
        {
            StringBuilder queries = new StringBuilder();
            List<TablesQuery> tablesQuery = new List<TablesQuery>();
            foreach (var mainJoinForm in rootObject.MainJoinForm)
            {

                string tableName = mainJoinForm.TableName.label;
                int OrderNo = mainJoinForm.OrderNo.value;
                string JOINS = mainJoinForm.JoinColumns;
                string selectColumns = BuildSelectColumns(mainJoinForm.MergeTable, dtUnmatchColumns, tableName,  ChannelID,  ModeID);
                string conditions = BuildConditions(mainJoinForm.conditions);
                string Where = conditions.Length > 0 ? "WHERE " + conditions : "";
                string query = $"\nSELECT {selectColumns} FROM {tableName} T1  {Where};";

                string[] forbiddenKeywords = { "CREATE","INSERT","UPDATE","DELETE","DROP", "TRUNCATE", "ALTER", "MASTER" };
                string[] WhitelistKeywords = { "MASTERCARD" , "'MASTER'" };

                if (forbiddenKeywords.Any(keyword => query.Contains(keyword)))
                {
                    if (WhitelistKeywords.Any(keyword => query.Contains(keyword)))
                    {

                    }
                    else
                    {
                        throw new Exception("Error: The input contains forbidden SQL keywords like DROP,CREATE, TRUNCATE,ALTER ");
                    }
                }
                TablesQuery item = new TablesQuery()
                {
                    TableName = tableName,
                    JOIN = JOINS,
                    OrderNo = OrderNo,
                    Query = query,
                };

                tablesQuery.Add(item);
                //queries.AppendLine(query);
            }



            return tablesQuery;
        }


        private string BuildSelectColumns(List<MergeTable> mergeTables, DataTable dtUnmatchColumns, string tableName, int ChannelID, int ModeID)
        {
            StringBuilder columns = new StringBuilder();

            string strColumn = string.Empty;

            string[] TableArray = new string[] { "tblPresentmentData" };

            foreach (DataRow dataRow in dtUnmatchColumns.Rows)
            {
                strColumn = Convert.ToString(dataRow["AliasColumn"]);

                MergeTable mergeTable = mergeTables.FirstOrDefault(P => P.AliasColumn == strColumn);
                
                if (mergeTable != null)
                {
                    if (!string.IsNullOrWhiteSpace(mergeTable.CaseStatement))
                    {
                        columns.Append($"{mergeTable.CaseStatement} as {mergeTable.AliasColumn}, ");
                    }
                    else
                    {
                        columns.Append($"NULL as {mergeTable.AliasColumn}, "); // Handling empty case statement
                    }
                }
                else
                {
                    if (strColumn.ToLower() == "createdby")
                    {
                        columns.Append($"@CreatedBy as {strColumn}, ");
                    }
                    else if (strColumn.ToLower() == "createdon")
                    {
                        columns.Append($" GETDATE() as {strColumn}, ");
                    }
                    else if (strColumn.ToLower() == "clientid")
                    {
                        columns.Append($" T1.{strColumn}, ");
                    }
                    else if (strColumn.ToLower() == "channelid")
                    {
                        if (TableArray.Contains(tableName))
                        {
                            columns.Append(" " + ChannelID + $" as {strColumn}, ");
                        }
                        else
                        {
                            columns.Append($" T1.{strColumn}, ");
                        }
                    }
                    else if (strColumn.ToLower() == "modeid")
                    {
                        if (TableArray.Contains(tableName))
                        {
                            columns.Append(" " + ModeID + $" as {strColumn}, ");
                        }
                        else
                        {
                            columns.Append($" T1.{strColumn}, ");
                        }
                    }
                    else if (strColumn.ToLower() == "recontype")
                    {
                        columns.Append($"@ReconType as {strColumn}, ");
                    }
                    else
                    {
                        columns.Append($"NULL as {strColumn}, ");
                    }
                }
            }             

            // Remove the last comma and space
            columns.Length -= 2;

            return columns.ToString();
        }

        private string BuildConditions(List<Conditions> conditions)
        {
            StringBuilder conditionString = new StringBuilder();

            foreach (var condition in conditions)
            {
                string Column = condition.Column.label.Replace("select", "").Trim();
                string Condition = condition.Condition.label.Replace("select", "").Trim();
                string Value = condition.Value.Trim() == "" ? "" : condition.Value.Contains("@") ? $"{condition.Value.Trim()}": $"{condition.Value.Trim()}";
                string boolean = condition.boolean.label.Replace("select", "").Trim();

                string FinalString = Column + Condition + Value + boolean;

                bool isNoCondition = FinalString.Trim().Length > 0;

                if (isNoCondition)
                    conditionString.Append($"{Column} {Condition} {Value} {boolean} ");
                else
                    conditionString.Append($"");
            }



            return conditionString.ToString();
        }
    }
}
