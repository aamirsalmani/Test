﻿using Microsoft.Extensions.Configuration;
using ASPTrace.Contracts;
using ASPTrace.Models;
using System.Data;
using Dapper;

namespace ASPTrace.Repository
{
    public class DynamicReconRepository : IDynamicRecon
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public DynamicReconRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<DynamicReconModel> GetDynamicRecon(string ClientID)
        {
            List<DynamicReconModel> dynamicReconList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                dynamicReconList = connection.Query<DynamicReconModel>("UspGetSelectedChannelType_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (dynamicReconList == null)
            {
                dynamicReconList = new List<DynamicReconModel>();
            }

            return dynamicReconList;
        }

        public List<ModeDynamicReconModel> GetModeDynamicRecon(string ClientID, int ChannelID)
        {
            List<ModeDynamicReconModel> modeDynamicReconList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                modeDynamicReconList = connection.Query<ModeDynamicReconModel>("UspGetModeTypeALLIMPS_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (modeDynamicReconList == null)
            {
                modeDynamicReconList = new List<ModeDynamicReconModel>();
            }

            return modeDynamicReconList;
        }

        public List<RunReconHistoryDynamicReconModel> GetRunReconHistoryDynamicRecon(string ClientID)
        {
            List<RunReconHistoryDynamicReconModel> runReconHistoryDynamicReconList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                runReconHistoryDynamicReconList = connection.Query<RunReconHistoryDynamicReconModel>("UspRunReconHistory_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (runReconHistoryDynamicReconList == null)
            {
                runReconHistoryDynamicReconList = new List<RunReconHistoryDynamicReconModel>();
            }

            return runReconHistoryDynamicReconList;
        }

        public List<RunReconAddDynamicReconModel> GetRunReconAddDynamicRecon(ReconStatusDynamicReconModel reconStatusDynamicReconModel)
        {
            List<RunReconAddDynamicReconModel> runReconAddDynamicReconModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FromDate", reconStatusDynamicReconModel.FromDate);
                param.Add("@ToDate", reconStatusDynamicReconModel.ToDate);
                param.Add("@Clientid", reconStatusDynamicReconModel.ClientID);
                param.Add("@ChannelID", reconStatusDynamicReconModel.ChannelID);
                param.Add("@Mode", reconStatusDynamicReconModel.Mode);
                param.Add("@user", reconStatusDynamicReconModel.User);

                runReconAddDynamicReconModelList = connection.Query<RunReconAddDynamicReconModel>("RunReconAdd", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (runReconAddDynamicReconModelList == null)
            {
                runReconAddDynamicReconModelList = new List<RunReconAddDynamicReconModel>();
            }

            return runReconAddDynamicReconModelList;
        }

    }
}
