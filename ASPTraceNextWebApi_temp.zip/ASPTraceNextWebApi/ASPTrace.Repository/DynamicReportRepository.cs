﻿using Dapper;
using Microsoft.Extensions.Configuration; 
using System.Data; 
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTrace.Repository
{
    public class DynamicReportRepository : IDynamicReport
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public DynamicReportRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<ReportTypeModel> GetReportTypeList()
        {
            List<ReportTypeModel> ReportTypeList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                ReportTypeList = connection.Query<ReportTypeModel>("uspReportTypes", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReportTypeList == null)
            {
                ReportTypeList = new List<ReportTypeModel>();
            }
            return ReportTypeList;
        }

        public List<ReportTableColumn> GetDynamicReportColumns(string ReportID)
        {
            List<ReportTableColumn> ReportColumnList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open(); 

                var param = new DynamicParameters();
                param.Add("@ReportID", ReportID);

                ReportColumnList = connection.Query<ReportTableColumn>("uspGetDynamicReportColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReportColumnList == null)
            {
                ReportColumnList = new List<ReportTableColumn>();
            }
            return ReportColumnList;
        }
    }
}
