﻿ 
using Microsoft.Extensions.Configuration;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper; 

namespace ASPTrace.Repository
{
    public class DynamicStatusConfigRepository : IDynamicStatus
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public DynamicStatusConfigRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }
        
        public List<GetStatusModelData> GetDynamicStatusData(GetStatusModel getStatusModel)
        {
            List<GetStatusModelData> GetStatusModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientId", getStatusModel.ClientID);
                param.Add("@ChannelId", getStatusModel.ChannelID);
                param.Add("@ModeId", getStatusModel.ModeID);
                param.Add("@ReconType", getStatusModel.ReconType);
                param.Add("@EJFilter", getStatusModel.EJFilter);
                param.Add("@GLFilter", getStatusModel.GLFilter);
                param.Add("@SWFilter", getStatusModel.SWFilter);
                param.Add("@NWFilter", getStatusModel.NWFilter);
                GetStatusModelList = connection.Query<GetStatusModelData>("uspGetDynamicStatusData", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (GetStatusModelList == null)
            {
                GetStatusModelList = new List<GetStatusModelData>();
            }

            return GetStatusModelList;
        }

        public List<GetFileStatusModel> GetDynamicStatusData()
        {
            List<GetFileStatusModel> GetStatusModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                GetStatusModelList = connection.Query<GetFileStatusModel>("UspGetFileStatis_StatusMaster",  commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (GetStatusModelList == null)
            {
                GetStatusModelList = new List<GetFileStatusModel>();
            }

            return GetStatusModelList;
        }

        public string SetDefaultStatus(DefaultStatusModel defaultStatusModel)
        {
            string result = "1";
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientId", defaultStatusModel.ClientID);
                param.Add("@ChannelId", defaultStatusModel.ChannelID);
                param.Add("@ModeId", defaultStatusModel.ModeID);
                param.Add("@ReconType", defaultStatusModel.ReconType);
                result = connection.ExecuteScalar<string>("uspSetDefaultClientWiseStatus", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }


        public string DeleteDynamicStatusData(GetStatusModelData getStatusModelData)
        {
            string result =  null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@ClientID", getStatusModelData.ClientID);
                param.Add("@ChannelID", getStatusModelData.ChannelID);
                param.Add("@ModeID", getStatusModelData.ModeID);
                param.Add("@ReconType", getStatusModelData.ReconType);
                param.Add("@EJStatus", getStatusModelData.EJStatus);
                param.Add("@GLStatus", getStatusModelData.GLStatus);
                param.Add("@SwitchStatus", getStatusModelData.SwitchStatus);
                param.Add("@NetWorkStatus", getStatusModelData.NetworkStatus);
                param.Add("@Remarks", getStatusModelData.Remarks);
                param.Add("@UserName", getStatusModelData.UserName);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspDeleteDynamicConfigStatusData", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }
        public string AddDynamicStatusData(GetStatusModelData getStatusModelData)
        {
            string result = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@ClientID", getStatusModelData.ClientID);
                param.Add("@ChannelID", getStatusModelData.ChannelID);
                param.Add("@ModeID", getStatusModelData.ModeID);
                param.Add("@ReconType", getStatusModelData.ReconType);
                param.Add("@EJStatus", getStatusModelData.EJStatus);
                param.Add("@GLStatus", getStatusModelData.GLStatus);
                param.Add("@SwitchStatus", getStatusModelData.SwitchStatus);
                param.Add("@NetWorkStatus", getStatusModelData.NetworkStatus);
                param.Add("@Remarks", getStatusModelData.Remarks.Trim());
                param.Add("@SettledRemarks", getStatusModelData.SettledRemarks.Trim());
                param.Add("@UserName", getStatusModelData.UserName);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspAddDynamicConfigStatusData", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }
        public string UpdateDynamicStatusData(GetStatusModelData getStatusModelData)
        {
            string result = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@ClientID", getStatusModelData.ClientID);
                param.Add("@ChannelID", getStatusModelData.ChannelID);
                param.Add("@ModeID", getStatusModelData.ModeID);
                param.Add("@ReconType", getStatusModelData.ReconType);
                param.Add("@EJStatus", getStatusModelData.EJStatus);
                param.Add("@GLStatus", getStatusModelData.GLStatus);
                param.Add("@SwitchStatus", getStatusModelData.SwitchStatus);
                param.Add("@NetWorkStatus", getStatusModelData.NetworkStatus);
                param.Add("@Remarks", getStatusModelData.Remarks.Trim());
                param.Add("@SettledRemarks", getStatusModelData.SettledRemarks.Trim());
                param.Add("@UserName", getStatusModelData.UserName);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspUpdateDynamicConfigStatusData", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }

        public string UploadExcelFile(DataTable dataTable, int clientId, int channelId, int modeId, int reconType, int InsertCount, int ErrorCount)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertExcelFileDynamicStatus";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@DATA", dataTable);
                        cmd.Parameters.AddWithValue("@clientId", clientId);
                        cmd.Parameters.AddWithValue("@channelId", channelId);
                        cmd.Parameters.AddWithValue("@modeId", modeId);
                        cmd.Parameters.AddWithValue("@reconType", reconType);
                        cmd.Parameters.AddWithValue("@UserName","Sayali");
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful " + "Lines Inserted :" + InsertCount + " Lines Failed :" +  ErrorCount ;
                    }
                }
            }
            catch (Exception ex)
            {
                return "Failed" ;
            }
        }
        public string CheckExtension(string fileExtension)
        {
            string result = null;
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    var param = new DynamicParameters();
                    param.Add("@Extension", fileExtension);
                    connection.Open();
                    result = connection.ExecuteScalar<string>("spValidateExtension", param, commandType: System.Data.CommandType.StoredProcedure);
                }
                return result;
            }
            catch (Exception ex)
            {
                return "Failed";
            }
        }
    }
}
                                                                                                                                                                                                                                                                                                                                                                                    
