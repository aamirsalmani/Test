﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;
using System.Threading.Tasks;


namespace ASPTrace.Repository
{
    public class EjErrorConfigRepository : IEjErrorConfig
    {

            private readonly IConfiguration _configuration;
            private string _connectionString = string.Empty;
            public EjErrorConfigRepository(IConfiguration configuration)
            {
                _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
            protected IDbConnection CreateConnection()
            {
                return new System.Data.SqlClient.SqlConnection(_connectionString);
            }









        //public CurrencyRegModel GetCurrencyDetails(string CurrencyID)
        //{
        //    CurrencyRegModel currencyDetails = null;
        //    using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {

        //        var param = new DynamicParameters();
        //        param.Add("@CurrencyID", CurrencyID);

        //        connection.Open();
        //        List<CurrencyRegModel> currencyList = connection.Query<CurrencyRegModel>("UspGetCurrencyData_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

        //        if (currencyList != null && currencyList.Count > 0)
        //        {
        //            currencyDetails = currencyList[0];
        //        }
        //    }

        //    if (currencyDetails == null)
        //    {
        //        currencyDetails = new CurrencyRegModel();
        //    }
        //    return currencyDetails;
        //}


        //public List<CountryRegModel> GetCountryReg()
        //{
        //    List<CountryRegModel> CountryRegList = null;
        //    using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        CountryRegList = connection.Query<CountryRegModel>("UspGetCountry_Core", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //    }

        //    if (CountryRegList == null)
        //    {
        //        CountryRegList = new List<CountryRegModel>();
        //    }
        //    else
        //    {
        //        CountryRegModel countryRegModel = new CountryRegModel();
        //        countryRegModel.Country = "Select";
        //        countryRegModel.Id = "0";
        //        CountryRegList.Insert(0, countryRegModel);
        //    }
        //    return CountryRegList;
        //}
        //public string DeleteEjErrorConfig(EjErrorConfigModelss ejErrorConfigModels)
        //{
        //    string result = string.Empty;
        //    using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        var param = new DynamicParameters();
        //        param.Add("@Mode", ejErrorConfigModels.Mode);
        //        param.Add("@SrNo", ejErrorConfigModels.SrNo);
        //        connection.Open();
        //        result = connection.ExecuteScalar<string>("spErrorCofigMaster", param, commandType: System.Data.CommandType.StoredProcedure);
        //    }
        //    return result;
        //}


        public List<EjErrorConfigModelssData> GetEjErrorListGrid()
        {
            List<EjErrorConfigModelssData> EjErrorList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                EjErrorList = connection.Query<EjErrorConfigModelssData>("spGetEjErrorConfig", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (EjErrorList == null)
            {
                EjErrorList = new List<EjErrorConfigModelssData>();
            }
            return EjErrorList;
        }

        public string EjErroraddupdate(EjErrorConfigModelssOperations ejErrorConfigModelsOps)
        {
            string result = string.Empty;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", ejErrorConfigModelsOps.Mode);  // Assuming you have a Mode field in your model
                param.Add("@SrNo", ejErrorConfigModelsOps.SrNo);
                param.Add("@ErrorCode", ejErrorConfigModelsOps.ErrorCode);   // Updated to match parameter name
                param.Add("@ErrorDescription", ejErrorConfigModelsOps.ErrorDescription); // Updated to match parameter name
                param.Add("@AtmMake", ejErrorConfigModelsOps.AtmMake); // Updated to match parameter name

                try
                {
                    connection.Open();
                    result = connection.ExecuteScalar<string>("spErrorCofigMaster", param, commandType: System.Data.CommandType.StoredProcedure);
                }
                catch (Exception ex)
                {
                    // Log or handle exception as needed
                    result = $"Error: {ex.Message}";
                }
            }

            return result;
        }
    }
}



