﻿using Microsoft.Extensions.Configuration; 
using System.Data;
using System.Data.SqlClient;
using ASPTrace.Contracts;

namespace ASPTrace.Repository
{
    public class ErrorLogRepository : IErrorLog
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public ErrorLogRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public void InsertLogs(string Msg, string ClientCode, string FormName, string FunctionName, int Lineno, string Filename, string UserName, char LogType, string connectionString)
        {
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {

                    cmd.Parameters.AddWithValue("@LogType", LogType);
                    cmd.Parameters.AddWithValue("@ClientCode", ClientCode);
                    cmd.Parameters.AddWithValue("@MachineIP", FormName);
                    cmd.Parameters.AddWithValue("@Description", Msg);
                    cmd.Parameters.AddWithValue("@UploadFilename", Filename);
                    cmd.Parameters.AddWithValue("@LineNo", Lineno);
                    cmd.Parameters.AddWithValue("@MethodName", FunctionName);
                    cmd.Parameters.AddWithValue("@UploadBy", UserName);

                    cmd.CommandText = "UspInsertLogs";
                    cmd.Connection = connection;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    connection.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void LogUnHandledError(  string errorMessage, string stackTrace, string InnerException,
                         string className, string methodName,  string userName,
                         string hostName, string ipAddress)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                SqlCommand command = new SqlCommand("uspInsertUnHandledErrorLog", connection);
                command.CommandType = CommandType.StoredProcedure;

                // Add parameters 
                command.Parameters.AddWithValue("@ErrorMessage", errorMessage);
                command.Parameters.AddWithValue("@StackTrace", stackTrace);
                command.Parameters.AddWithValue("@InnerException", InnerException);
                command.Parameters.AddWithValue("@ClassName", className);
                command.Parameters.AddWithValue("@MethodName", methodName); 
                command.Parameters.AddWithValue("@UserName", userName);
                command.Parameters.AddWithValue("@HostName", hostName);
                command.Parameters.AddWithValue("@IPAddress", ipAddress); 

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                } 
                catch (Exception ex)
                {
                    // Handle other exceptions that may occur during logging
                    Console.WriteLine("Error: " + ex.Message);
                }
            }
        }
    }
}
