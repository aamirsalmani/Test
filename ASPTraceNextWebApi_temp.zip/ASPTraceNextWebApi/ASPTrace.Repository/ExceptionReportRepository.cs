﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTrace.Repository
{
    public class ExceptionReportRepository : IExceptionsReport
    {

        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public ExceptionReportRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected System.Data.IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        List<EJMissingDataModel> IExceptionsReport.GetEJMissingData(EJMissingReportModel eJMissingModel)
        {
            {
                List<EJMissingDataModel> eJMissingReportData = null;
                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    param.Add("@clientid", eJMissingModel.ClientID);
                    param.Add("@TERMINALID", eJMissingModel.TERMINALID);
                    param.Add("@UploadStatus ", eJMissingModel.UploadStatus);
                    param.Add("@FromDateTxns", eJMissingModel.FROMDATE);
                    param.Add("@ToDateTxns", eJMissingModel.TODATE);

                    eJMissingReportData = connection.Query<EJMissingDataModel>("spGetEJMissing", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                }

                if (eJMissingReportData == null)
                {
                    eJMissingReportData = new List<EJMissingDataModel>();
                }

                return eJMissingReportData;
            }
        }

          

        DataTable IExceptionsReport.ExportCsvReportKS(RawDataInputModel rawDataInput)
        {
            try
            {
                DataTable dt = new DataTable();
                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (var cmd = new System.Data.SqlClient.SqlCommand("spGetEJMissing", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 1000000;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = rawDataInput.ClientID;
                        // Assuming cmd is your SqlCommand object and param is a Dictionary to store parameters
                        cmd.Parameters.AddWithValue("@TERMINALID", SqlDbType.Int).Value = rawDataInput.TERMINALID;
                        cmd.Parameters.AddWithValue("@UploadStatus", SqlDbType.VarChar).Value = rawDataInput.UploadStatus;
                        cmd.Parameters.AddWithValue("@FromDateTxns", SqlDbType.DateTime).Value = rawDataInput.FROMDATE ?? (object)DBNull.Value;
                        cmd.Parameters.AddWithValue("@ToDateTxns", SqlDbType.DateTime).Value = rawDataInput.TODATE ?? (object)DBNull.Value;




                        using (var sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        DataTable IExceptionsReport.ExportExcelReportKS(RawDataInputModel rawDataInput)
        {

            try
            {
                DataTable dt = new DataTable();
                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (var cmd = new System.Data.SqlClient.SqlCommand("spGetEJMissing", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 1000000;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = rawDataInput.ClientID;
                        // Assuming cmd is your SqlCommand object and param is a Dictionary to store parameters
                        cmd.Parameters.AddWithValue("@TERMINALID", SqlDbType.Int).Value = rawDataInput.TERMINALID;
                        cmd.Parameters.AddWithValue("@UploadStatus", SqlDbType.VarChar).Value = rawDataInput.UploadStatus;
                        cmd.Parameters.AddWithValue("@FromDateTxns", SqlDbType.DateTime).Value = rawDataInput.FROMDATE ?? (object)DBNull.Value;
                        cmd.Parameters.AddWithValue("@ToDateTxns", SqlDbType.DateTime).Value = rawDataInput.TODATE ?? (object)DBNull.Value;



                        using (var sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                    }
                }
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }

        }


        //    List<TerminalOptionModel> IExceptionsReport.GetTerminalOptions(string UserName)
        //{
        //        {
        //            List<TerminalOptionModel> terminalOptionModelsList = null;
        //            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //            {
        //                connection.Open();
        //                var param = new DynamicParameters();
        //                param.Add("@UserName", UserName);

        //                terminalOptionModelsList = connection.Query<TerminalOptionModel>("UspGetTerminalList_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //            }

        //            if (terminalOptionModelsList == null)
        //            {
        //                terminalOptionModelsList = new List<TerminalOptionModel>();
        //            }
        //            return terminalOptionModelsList;
        //        }

        List<TerminalOptionModel> IExceptionsReport.GetTerminalOptions(int ClientID)
        {
            List<TerminalOptionModel> terminalOptionModelsList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                terminalOptionModelsList = connection.Query<TerminalOptionModel>("GetTerminalList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (terminalOptionModelsList == null)
            {
                terminalOptionModelsList = new List<TerminalOptionModel>();
            }
            return terminalOptionModelsList;
        }



        //public List<EJMissingReportList> GetEJMissingData(EJMissingModel eJMissingModel)
        //{
        //    List<EJMissingDataModel> eJMissingReportData = null;
        //    using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();
        //        param.Add("@clientid", eJMissingModel.ClientID);
        //        param.Add("@TERMINALID", eJMissingModel.TERMINALID);
        //        param.Add("@FromDateTxns", eJMissingModel.FROMDATE);
        //        param.Add("@ToDateTxns", eJMissingModel.TODATE);

        //        eJMissingReportList = connection.Query<EJMissingDataModel>("", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //    }

        //    if (eJMissingReportList == null)
        //    {
        //        eJMissingReportList = new List<EJMissingDataModel>();
        //    }

        //    return eJMissingReportList;
        //}


    }
}
