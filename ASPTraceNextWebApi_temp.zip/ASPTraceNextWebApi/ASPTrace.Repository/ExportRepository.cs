﻿using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data; 
using System.Data.SqlClient;

namespace ASPTrace.Repository
{
    public class ExportRepository : IExport
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public ExportRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected System.Data.IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        //Unmatched Report

        public DataTable GetUnmatchedTxnsDataTable(InputReportModel unmatchedTxnsModel,string SearchText)
        {
            DataTable unmatchedTxnsReportList = new DataTable();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("uspUnmatchedTxnsDataTable", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 5000000;

                    // Adding parameters to the command
                    command.Parameters.Add(new SqlParameter("@ClientID", unmatchedTxnsModel.ClientID));
                    command.Parameters.Add(new SqlParameter("@FromDateTxns", unmatchedTxnsModel.FromDate));
                    command.Parameters.Add(new SqlParameter("@ToDateTxns", unmatchedTxnsModel.ToDate));
                    command.Parameters.Add(new SqlParameter("@ChannelID", unmatchedTxnsModel.ChannelID));
                    command.Parameters.Add(new SqlParameter("@ModeID", unmatchedTxnsModel.ModeID));
                    command.Parameters.Add(new SqlParameter("@TERMINALID", unmatchedTxnsModel.TerminalID));
                    command.Parameters.Add(new SqlParameter("@TxnType", unmatchedTxnsModel.TxnType));
                    command.Parameters.Add(new SqlParameter("@searchtext", SearchText));

                    // Using SqlDataAdapter to fill the DataTable
                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(unmatchedTxnsReportList);
                    }
                }
            }

            return unmatchedTxnsReportList;
        }

        public DataTable GetMatchedTxnsDataTable(InputReportModel matchedTxnsModel, string SearchText)
        {
            DataTable unmatchedTxnsReportList = new DataTable();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("uspSuccessfulTxnsDataTable", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 1000000;

                    // Adding parameters to the command
                    command.Parameters.Add(new SqlParameter("@ClientID", matchedTxnsModel.ClientID));
                    command.Parameters.Add(new SqlParameter("@FromDateTxns", matchedTxnsModel.FromDate));
                    command.Parameters.Add(new SqlParameter("@ToDateTxns", matchedTxnsModel.ToDate));
                    command.Parameters.Add(new SqlParameter("@ChannelID", matchedTxnsModel.ChannelID));
                    command.Parameters.Add(new SqlParameter("@ModeID", matchedTxnsModel.ModeID));
                    command.Parameters.Add(new SqlParameter("@TERMINALID", matchedTxnsModel.TerminalID));
                    command.Parameters.Add(new SqlParameter("@TxnType", matchedTxnsModel.TxnType));
                    command.Parameters.Add(new SqlParameter("@searchtext", SearchText));
                    // Using SqlDataAdapter to fill the DataTable
                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(unmatchedTxnsReportList);
                    }
                }
            }

            return unmatchedTxnsReportList;
        }

        public DataTable GetReversalTxnsDataTable(InputReportModel reversalTxnsModel)
        {
            DataTable unmatchedTxnsReportList = new DataTable();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("uspReversalTxnsDataTable", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 1000000;

                    // Adding parameters to the command
                    command.Parameters.Add(new SqlParameter("@ClientID", reversalTxnsModel.ClientID));
                    command.Parameters.Add(new SqlParameter("@FromDateTxns", reversalTxnsModel.FromDate));
                    command.Parameters.Add(new SqlParameter("@ToDateTxns", reversalTxnsModel.ToDate));
                    command.Parameters.Add(new SqlParameter("@ChannelID", reversalTxnsModel.ChannelID));
                    command.Parameters.Add(new SqlParameter("@ModeID", reversalTxnsModel.ModeID));
                    command.Parameters.Add(new SqlParameter("@TERMINALID", reversalTxnsModel.TerminalID));
                    command.Parameters.Add(new SqlParameter("@TxnType", reversalTxnsModel.TxnType));

                    // Using SqlDataAdapter to fill the DataTable
                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(unmatchedTxnsReportList);
                    }
                }
            }

            return unmatchedTxnsReportList;
        }

        public DataTable GetUnsuccessfulTxnsDataTable(InputReportModel unsuccessfulTxnsModel, string SearchText)
        {
            DataTable unsuccessfulTxnsReportList = new DataTable();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("uspUnsuccessfulTxnsDataTable", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 1000000;

                    // Adding parameters to the command
                    command.Parameters.Add(new SqlParameter("@ClientID", unsuccessfulTxnsModel.ClientID));
                    command.Parameters.Add(new SqlParameter("@FromDateTxns", unsuccessfulTxnsModel.FromDate));
                    command.Parameters.Add(new SqlParameter("@ToDateTxns", unsuccessfulTxnsModel.ToDate));
                    command.Parameters.Add(new SqlParameter("@ChannelID", unsuccessfulTxnsModel.ChannelID));
                    command.Parameters.Add(new SqlParameter("@ModeID", unsuccessfulTxnsModel.ModeID));
                    command.Parameters.Add(new SqlParameter("@TERMINALID", unsuccessfulTxnsModel.TerminalID));
                    command.Parameters.Add(new SqlParameter("@TxnType", unsuccessfulTxnsModel.TxnType));
                    command.Parameters.Add(new SqlParameter("@searchtext", SearchText));

                    // Using SqlDataAdapter to fill the DataTable
                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(unsuccessfulTxnsReportList);
                    }
                }
            }

            return unsuccessfulTxnsReportList;
        }

        public DataTable GetDuplicateTxnsDataTable(InputReportModel duplicateTxnsModel)
        {
            DataTable unmatchedTxnsReportList = new DataTable();

            try
            {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("uspDuplicateTxnsDataTable", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 1000000;

                    // Adding parameters to the command
                    command.Parameters.Add(new SqlParameter("@ClientID", duplicateTxnsModel.ClientID));
                    command.Parameters.Add(new SqlParameter("@FromDateTxns", duplicateTxnsModel.FromDate));
                    command.Parameters.Add(new SqlParameter("@ToDateTxns", duplicateTxnsModel.ToDate));
                    command.Parameters.Add(new SqlParameter("@ChannelID", duplicateTxnsModel.ChannelID));
                    command.Parameters.Add(new SqlParameter("@ModeID", duplicateTxnsModel.ModeID));
                    command.Parameters.Add(new SqlParameter("@TERMINALID", duplicateTxnsModel.TerminalID));
                    command.Parameters.Add(new SqlParameter("@TxnType", duplicateTxnsModel.TxnType));

                    // Using SqlDataAdapter to fill the DataTable
                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(unmatchedTxnsReportList);
                    }
                }
                }
            }
            catch(Exception ex)
            {

            }

            return unmatchedTxnsReportList;
        }

        public DataTable GetAdjustmentDataTable(AdjustmentTxnsModel adjustmentTxnsModel)
        {
            DataTable ReportList = new DataTable();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("UspAdjustmentTxnsReport_Core", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 1000000;

                    // Adding parameters to the command
                    command.Parameters.Add(new SqlParameter("@ClientID", adjustmentTxnsModel.ClientID));
                    command.Parameters.Add(new SqlParameter("@TR_POSTDATE", adjustmentTxnsModel.TR_POSTDATE));
                    command.Parameters.Add(new SqlParameter("@TR_ENDDATE", adjustmentTxnsModel.TR_ENDDATE));
                    command.Parameters.Add(new SqlParameter("@ReportType", adjustmentTxnsModel.ReportType)); 

                    // Using SqlDataAdapter to fill the DataTable
                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(ReportList);
                    }
                }
            }


            return ReportList;
        }

        public DataTable GetDmsTxnsDataTable(InputReportModel dmsTxnsModel)
        {
            DataTable dmsTxnsReportList = new DataTable();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("DMSTxnsReports", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Adding parameters to the command
                    command.Parameters.Add(new SqlParameter("@ClientID", dmsTxnsModel.ClientID));
                    command.Parameters.Add(new SqlParameter("@ChannelID", dmsTxnsModel.ChannelID));
                    command.Parameters.Add(new SqlParameter("@ModeID", dmsTxnsModel.ModeID));
                    command.Parameters.Add(new SqlParameter("@TERMINALID", dmsTxnsModel.TerminalID));
                    command.Parameters.Add(new SqlParameter("@FromDateTxns", dmsTxnsModel.FromDate));
                    command.Parameters.Add(new SqlParameter("@ToDateTxns", dmsTxnsModel.ToDate));
                    command.Parameters.Add(new SqlParameter("@TxnType", dmsTxnsModel.TxnType));

                    // Using SqlDataAdapter to fill the DataTable
                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dmsTxnsReportList);
                    }
                }
            }

            return dmsTxnsReportList;
        }

        //public List<dynamic> GetConsoleSetTxnsDatatable(ConsoleSetReportModel ConsoleSetModel)
        //{
        //    List<dynamic> ConsoleSetList = null;

        //    using (var connection = new SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();

        //        param.Add("@ClientID", ConsoleSetModel.ClientID);
        //        param.Add("@Channel", ConsoleSetModel.ChannelID);
        //        param.Add("@Cycle", ConsoleSetModel.Cycle);
        //        param.Add("@TR_POSTDATE", ConsoleSetModel.FromDateTxns);
        //        param.Add("@TR_ENDDATE", ConsoleSetModel.ToDateTxns);
        //        ConsoleSetList = connection.Query<dynamic>("ConsolSetRpt", param, commandTimeout: 1000000, commandType: CommandType.StoredProcedure).AsList();
        //    }

        //    if (ConsoleSetList == null)
        //    {
        //        ConsoleSetList = new List<dynamic>();
        //    }

        //    return ConsoleSetList;
        //}


        

            public DataTable GetSwitchFeeTxnsDataTable(SwitchFeeReportModel ConsoleSetModel)
        {
            // Get the list of dynamic objects from Dapper
            List<dynamic> ConsoleSetList;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ConsoleSetModel.ClientID);
                param.Add("@ChannelType", ConsoleSetModel.ChannelType);
                param.Add("@Date", ConsoleSetModel.FromDateTxns);

                ConsoleSetList = connection.Query<dynamic>(
                    "SpGetChannelFeeGST", // replace with your SP
                    param,
                    commandTimeout: 1000000,
                    commandType: CommandType.StoredProcedure
                ).AsList();
            }

            // Convert to DataTable
            DataTable dt = new DataTable();

            if (ConsoleSetList != null && ConsoleSetList.Count > 0)
            {
                // Create columns dynamically based on first object
                foreach (var key in ((IDictionary<string, object>)ConsoleSetList[0]).Keys)
                {
                    dt.Columns.Add(key);
                }

                // Fill rows
                foreach (var item in ConsoleSetList)
                {
                    var row = dt.NewRow();
                    var dict = (IDictionary<string, object>)item;
                    foreach (var key in dict.Keys)
                    {
                        row[key] = dict[key] ?? DBNull.Value;
                    }
                    dt.Rows.Add(row);
                }
            }

            return dt;
        }
        public DataTable GetConsoleSetTxnsDataTable(ConsoleSetReportModel ConsoleSetModel)
        {
            // Get the list of dynamic objects from Dapper
            List<dynamic> ConsoleSetList;
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ConsoleSetModel.ClientID);
                param.Add("@Channel", ConsoleSetModel.ChannelID);
                param.Add("@Cycle", ConsoleSetModel.Cycle);
                param.Add("@TR_POSTDATE", ConsoleSetModel.FromDateTxns);
                param.Add("@TR_ENDDATE", ConsoleSetModel.ToDateTxns);

                ConsoleSetList = connection.Query<dynamic>(
                    "ConsolSetRpt", // replace with your SP
                    param,
                    commandTimeout: 1000000,
                    commandType: CommandType.StoredProcedure
                ).AsList();
            }

            // Convert to DataTable
            DataTable dt = new DataTable();

            if (ConsoleSetList != null && ConsoleSetList.Count > 0)
            {
                // Create columns dynamically based on first object
                foreach (var key in ((IDictionary<string, object>)ConsoleSetList[0]).Keys)
                {
                    dt.Columns.Add(key);
                }

                // Fill rows
                foreach (var item in ConsoleSetList)
                {
                    var row = dt.NewRow();
                    var dict = (IDictionary<string, object>)item;
                    foreach (var key in dict.Keys)
                    {
                        row[key] = dict[key] ?? DBNull.Value;
                    }
                    dt.Rows.Add(row);
                }
            }

            return dt;
        }


        public DataTable GetSettlementTxnsDataTable(InputSettlementReportModel settlementTxnsModel)
        {
            DataTable dt = new DataTable();

            string StoredProc = "usp_ATM_Settlement_Report";

            if (settlementTxnsModel.ReportType == "1")
            {
                StoredProc = "usp_ATM_Settlement_Report";
            }
            else if (settlementTxnsModel.ReportType == "2")
            {
                StoredProc = "usp_IMPS_Settlement_Report";
            }
            else if (settlementTxnsModel.ReportType == "3")
            {
                StoredProc = "usp_UPI_Settlement_Report";
            }
            else if (settlementTxnsModel.ReportType == "4" || settlementTxnsModel.ReportType == "5" || settlementTxnsModel.ReportType == "6" || settlementTxnsModel.ReportType == "7" || settlementTxnsModel.ReportType == "8")
            {
                StoredProc = "usp_POS_Settlement_Report";
            }

            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                try
                {

                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(StoredProc, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 1000000;

                        cmd.Parameters.Add(new SqlParameter("@TR_POSTDATE", settlementTxnsModel.FromDate));
                        cmd.Parameters.Add(new SqlParameter("@TR_ENDDATE", settlementTxnsModel.ToDate));
                        cmd.Parameters.Add(new SqlParameter("@ClientID", settlementTxnsModel.ClientId));
                        if (settlementTxnsModel.ReportType == "4" || settlementTxnsModel.ReportType == "5" || settlementTxnsModel.ReportType == "6" || settlementTxnsModel.ReportType == "7" || settlementTxnsModel.ReportType == "8")
                        {
                            cmd.Parameters.Add(new SqlParameter("@SettlementType", settlementTxnsModel.ReportType));
                        }

                        using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }


                        //if (settlementTxnsModel.ReportType == "2")
                        //{
                        //    if (!dt.Columns.Contains("NPCI Outward Raw Total Amount"))
                        //        dt.Columns.Add("NPCI Outward Raw Total Amount", typeof(decimal));
                        //    if (!dt.Columns.Contains(" NPCI Outward Raw VS Settlement Outward Amount Difference"))
                        //        dt.Columns.Add("NPCI Outward Raw VS Settlement Outward Amount Difference", typeof(decimal));

                        //    // ✅ Copy value from "Beneficiary/Remitter Sub Totals_Debit"
                        //    if (dt.Columns.Contains("Beneficiary/Remitter Sub Totals_Debit"))
                        //    {
                        //        foreach (DataRow row in dt.Rows)
                        //        {
                        //            if (decimal.TryParse(row["Beneficiary/Remitter Sub Totals_Debit"]?.ToString(), out decimal val))
                        //            {
                        //                row["NPCI Outward Raw Total Amount"] = val;
                        //                row["NPCI Outward Raw VS Settlement Outward Amount Difference"] = 0;
                        //            }
                        //            else
                        //            {
                        //                row["NPCI Outward Raw Total Amount"] = 0;
                        //                row["NPCI Outward Raw VS Settlement Outward Amount Difference"] = 0;
                        //            }
                        //        }
                        //    }


                        //    if (!dt.Columns.Contains("NPCI Inward Raw Total Amount"))
                        //        dt.Columns.Add("NPCI Inward Raw Total Amount", typeof(decimal));
                        //    if (!dt.Columns.Contains(" NPCI Inward Raw VS Settlement Outward Amount Difference"))
                        //        dt.Columns.Add("NPCI Inward Raw VS Settlement Outward Amount Difference", typeof(decimal));

                        //    // ✅ Copy value from "Beneficiary/Remitter Sub Totals_Debit"
                        //    if (dt.Columns.Contains("Beneficiary/Remitter Sub Totals_Credit"))
                        //    {
                        //        foreach (DataRow row in dt.Rows)
                        //        {
                        //            if (decimal.TryParse(row["Beneficiary/Remitter Sub Totals_Credit"]?.ToString(), out decimal val))
                        //            {
                        //                row["NPCI Inward Raw Total Amount"] = val;
                        //                row["NPCI Inward Raw VS Settlement Outward Amount Difference"] = 0;
                        //            }
                        //            else
                        //            {
                        //                row["NPCI Inward Raw Total Amount"] = 0;
                        //                row["NPCI Inward Raw VS Settlement Outward Amount Difference"] = 0;
                        //            }
                        //        }
                        //    }
                        //}
                        //else if (settlementTxnsModel.ReportType == "3")
                        //{
                        //    if (!dt.Columns.Contains("NPCI Outward Raw Total Amount"))
                        //        dt.Columns.Add("NPCI Outward Raw Total Amount", typeof(decimal));
                        //    if (!dt.Columns.Contains(" NPCI Outward Raw VS Settlement Outward Amount Difference"))
                        //        dt.Columns.Add("NPCI Outward Raw VS Settlement Outward Amount Difference", typeof(decimal));

                        //    // ✅ Copy value from "Beneficiary/Remitter Sub Totals_Debit"
                        //    if (dt.Columns.Contains("Beneficiary / Remitter Sub Totals_Credit"))
                        //    {
                        //        foreach (DataRow row in dt.Rows)
                        //        {
                        //            if (decimal.TryParse(row["Beneficiary / Remitter Sub Totals_Debit"]?.ToString(), out decimal val))
                        //            {
                        //                row["NPCI Outward Raw Total Amount"] = val;
                        //                row["NPCI Outward Raw VS Settlement Outward Amount Difference"] = 0;
                        //            }
                        //            else
                        //            {
                        //                row["NPCI Outward Raw Total Amount"] = 0;
                        //                row["NPCI Outward Raw VS Settlement Outward Amount Difference"] = 0;
                        //            }
                        //        }
                        //    }

                        //    if (!dt.Columns.Contains("NPCI Inward Raw Total Amount"))
                        //        dt.Columns.Add("NPCI Inward Raw Total Amount", typeof(decimal));
                        //    if (!dt.Columns.Contains(" NPCI Inward Raw VS Settlement Outward Amount Difference"))
                        //        dt.Columns.Add("NPCI Inward Raw VS Settlement Outward Amount Difference", typeof(decimal));

                        //    // ✅ Copy value from "Beneficiary/Remitter Sub Totals_Debit"
                        //    if (dt.Columns.Contains("Beneficiary / Remitter Sub Totals_Credit"))
                        //    {
                        //        foreach (DataRow row in dt.Rows)
                        //        {
                        //            if (decimal.TryParse(row["Beneficiary / Remitter Sub Totals_Credit"]?.ToString(), out decimal val))
                        //            {
                        //                row["NPCI Inward Raw Total Amount"] = val;
                        //                row["NPCI Inward Raw VS Settlement Outward Amount Difference"] = 0;
                        //            }
                        //            else
                        //            {
                        //                row["NPCI Inward Raw Total Amount"] = 0;
                        //                row["NPCI Inward Raw VS Settlement Outward Amount Difference"] = 0;
                        //            }
                        //        }
                        //    }
                        //}
                    }

                }
                catch (Exception ex)
                {

                }
            }

            return dt;
        }


    }
}
