﻿using Microsoft.Extensions.Configuration;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;

namespace ASPTrace.Repository
{
    public class FieldRepository : IField
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public FieldRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public DataTable GetChannelModeDetailsField(string ClientID)
        {  
            DataTable dtRecords = new DataTable();
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spGetChannelModeDetails", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@ClientID", SqlDbType.BigInt).Value = ClientID;

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dtRecords);
                    }
                }
            }        
            return dtRecords;
        }


        public DataTable AddFieldConfig(AddFieldConfigModel addFieldConfigModel)
        {
            DataTable dtRecords = new DataTable();
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spAddFieldConfig", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@ClientID", addFieldConfigModel.ClientID);
                    cmd.Parameters.AddWithValue("@VendorID", addFieldConfigModel.VendorID);
                    cmd.Parameters.AddWithValue("@ChannelID", addFieldConfigModel.ChannelID);
                    cmd.Parameters.AddWithValue("@ModeID", addFieldConfigModel.ModeID);
                    cmd.Parameters.AddWithValue("@FormatID", addFieldConfigModel.FormatID);
                    cmd.Parameters.AddWithValue("@TerminalCode", addFieldConfigModel.TerminalCode);
                    cmd.Parameters.AddWithValue("@BinNo", addFieldConfigModel.BinNo);
                    cmd.Parameters.AddWithValue("@AcquirerID", addFieldConfigModel.AcquirerID);
                    cmd.Parameters.AddWithValue("@RevCode1", addFieldConfigModel.RevCode1);
                    cmd.Parameters.AddWithValue("@RevCode2", addFieldConfigModel.RevCode2);
                    cmd.Parameters.AddWithValue("@RevType", addFieldConfigModel.RevType);
                    cmd.Parameters.AddWithValue("@RevEntry", addFieldConfigModel.RevEntry);
                    cmd.Parameters.AddWithValue("@TxnDateTime", addFieldConfigModel.TxnDateTime);
                    cmd.Parameters.AddWithValue("@TxnValueDateTime", addFieldConfigModel.TxnValueDateTime);
                    cmd.Parameters.AddWithValue("@TxnPostDateTime", addFieldConfigModel.TxnPostDateTime);
                    cmd.Parameters.AddWithValue("@ATMType", addFieldConfigModel.ATMType);
                    cmd.Parameters.AddWithValue("@POSType", addFieldConfigModel.POSType);
                    cmd.Parameters.AddWithValue("@ECOMType", addFieldConfigModel.ECOMType);
                    cmd.Parameters.AddWithValue("@IMPSType", addFieldConfigModel.IMPSType);
                    cmd.Parameters.AddWithValue("@UPIType", addFieldConfigModel.UPIType);
                    cmd.Parameters.AddWithValue("@MicroATMType", addFieldConfigModel.MicroATMType);
                    cmd.Parameters.AddWithValue("@MobileRechargeType", addFieldConfigModel.MobileRechargeType);
                    cmd.Parameters.AddWithValue("@Deposit", addFieldConfigModel.Deposit);
                    cmd.Parameters.AddWithValue("@BalEnq", addFieldConfigModel.BalEnq);
                    cmd.Parameters.AddWithValue("@MiniStatement", addFieldConfigModel.MiniStatement);
                    cmd.Parameters.AddWithValue("@PinChange", addFieldConfigModel.PinChange);
                    cmd.Parameters.AddWithValue("@ChequeBookReq", addFieldConfigModel.ChequeBookReq);
                    cmd.Parameters.AddWithValue("@RespCode1", addFieldConfigModel.RespCode1);
                    cmd.Parameters.AddWithValue("@RespCode2", addFieldConfigModel.RespCode2);
                    cmd.Parameters.AddWithValue("@RespTpe", addFieldConfigModel.RespTpe);
                    cmd.Parameters.AddWithValue("@EODCode", addFieldConfigModel.EODCode);
                    cmd.Parameters.AddWithValue("@OfflineCode", addFieldConfigModel.OfflineCode);
                    cmd.Parameters.AddWithValue("@DebitCode", addFieldConfigModel.DebitCode);
                    cmd.Parameters.AddWithValue("@CreditCode", addFieldConfigModel.CreditCode);
                    cmd.Parameters.AddWithValue("@CreatedBy", addFieldConfigModel.CreatedBy);
                    if (addFieldConfigModel.TxnAmountIsDecimal == "True")
                    {
                        cmd.Parameters.AddWithValue("@TxnAmountIsDecimal", "0");
                    }
                    else if (addFieldConfigModel.TxnAmountIsDecimal == "False")
                    {
                        cmd.Parameters.AddWithValue("@TxnAmountIsDecimal", "1");
                    }
                    else if (addFieldConfigModel.TxnAmountIsDecimal == "--Select--")
                    {
                        cmd.Parameters.AddWithValue("@TxnAmountIsDecimal", " ");
                    }

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dtRecords);
                    }
                }
                return dtRecords;
            }
        }

        
        public List<VendorFieldModel> GetVendorFields(string ClientID)
        {
            List<VendorFieldModel> clientFieldModelsList = null; 
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                clientFieldModelsList = connection.Query<VendorFieldModel>("UspGetFileVendorDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<VendorFieldModel>();
            }
            return clientFieldModelsList;
        }

        public List<ChannelFieldModel> GetChannelFields(string ClientID)
        {
            List<ChannelFieldModel> clientFieldModelsList = null;  
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                clientFieldModelsList = connection.Query<ChannelFieldModel>("UspGetChannelDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<ChannelFieldModel>();
            }
            return clientFieldModelsList;
        }

        public List<ModeFieldModel> GetModeFields(string ClientID, string ChannelID)
        {
            List<ModeFieldModel> clientFieldModelsList = null; 
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                clientFieldModelsList = connection.Query<ModeFieldModel>("spGetModeDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<ModeFieldModel>();
            }
            return clientFieldModelsList;
        }

        public List<FormatIdFieldModel> GetFormatIdFields(string ClientID, string VendorID, string ChannelID, string ModeID)
        {
            List<FormatIdFieldModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@VendorID", VendorID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);

                clientFieldModelsList = connection.Query<FormatIdFieldModel>("spGetFormatID", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<FormatIdFieldModel>();
            }
            return clientFieldModelsList;
        }

        public List<FieldIdentificationDetailsModel> GetFieldIdentificationDetails(string ClientID, string VendorID, string ChannelID, string ModeID,string FormatID)
        {
            List<FieldIdentificationDetailsModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@VendorID", VendorID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@FormatID", FormatID);

                clientFieldModelsList = connection.Query<FieldIdentificationDetailsModel>("spGetFieldIdentificationDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<FieldIdentificationDetailsModel>();
            }
            return clientFieldModelsList;
        }


        public List<FieldIdentificationVendorDetailsModel> GetFieldIdentificationVendorDetails(string VendorID, string ChannelID)
        {
            List<FieldIdentificationVendorDetailsModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@VendorID", VendorID);
                param.Add("@ChannelID", ChannelID);
               
                clientFieldModelsList = connection.Query<FieldIdentificationVendorDetailsModel>("spFieldIdentificationVendorDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<FieldIdentificationVendorDetailsModel>();
            }
            return clientFieldModelsList;
        }
    }
}
