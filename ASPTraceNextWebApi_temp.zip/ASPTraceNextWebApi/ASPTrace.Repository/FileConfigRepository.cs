﻿using Microsoft.Extensions.Configuration; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using System.Data;
using Dapper;

namespace ASPTrace.Repository
{
    public class FileConfigRepository : IFileConfig
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public FileConfigRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<ClientFileConfigModel> GetClientFileConfig()
        {
            List<ClientFileConfigModel> ClientFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                ClientFileConfigModelsList = connection.Query<ClientFileConfigModel>("spGeClientDetails", null, commandType: System.Data.CommandType.StoredProcedure).AsList();

            }

            if (ClientFileConfigModelsList == null)
            {
                ClientFileConfigModelsList = new List<ClientFileConfigModel>();
            }
            return ClientFileConfigModelsList;
        }


        public List<ConfiguredFormatFileConfigModel> GetConfiguredFormatFileConfig(string ClientID)
        {
            List<ConfiguredFormatFileConfigModel> configuredFormatFileConfigList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                configuredFormatFileConfigList = connection.Query<ConfiguredFormatFileConfigModel>("spGetFileFormatClient", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (configuredFormatFileConfigList == null)
            {
                configuredFormatFileConfigList = new List<ConfiguredFormatFileConfigModel>();
            }

            return configuredFormatFileConfigList;
        }


        public List<LogTypeFileConfigModel> GetLogTypeFileConfig(string ClientID)
        {
            List<LogTypeFileConfigModel> ClientFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                ClientFileConfigModelsList = connection.Query<LogTypeFileConfigModel>("UspGetLogType_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientFileConfigModelsList == null)
            {
                ClientFileConfigModelsList = new List<LogTypeFileConfigModel>();
            }
            return ClientFileConfigModelsList;
        }

        public List<ChannelFileConfigModel> GetChannelFileConfig(string ClientID)
        {
            List<ChannelFileConfigModel> ClientFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                param.Add("@UserID", ClientID);


                ClientFileConfigModelsList = connection.Query<ChannelFileConfigModel>("UspGetChannelTypeALL_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientFileConfigModelsList == null)
            {
                ClientFileConfigModelsList = new List<ChannelFileConfigModel>();
            }
            return ClientFileConfigModelsList;
        }

        public List<ModeFileConfigModel> GetModeFileConfig(string ClientID, int ChannelID)
        {
            List<ModeFileConfigModel> ClientFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                ClientFileConfigModelsList = connection.Query<ModeFileConfigModel>("spGetModeTypeALL", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ClientFileConfigModelsList == null)
            {
                ClientFileConfigModelsList = new List<ModeFileConfigModel>();
            }
            return ClientFileConfigModelsList;
        }

        public List<VendorFileConfigModel> GetVendorFileConfig(string VendorType)
        {
            List<VendorFileConfigModel> VendorFileConfigModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@VendorType", VendorType);

                VendorFileConfigModelsList = connection.Query<VendorFileConfigModel>("UspGetVendorDetailsByType_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (VendorFileConfigModelsList == null)
            {
                VendorFileConfigModelsList = new List<VendorFileConfigModel>();
            }
            return VendorFileConfigModelsList;
        }

        public FileFormatActiveFileConfigModel GetFileFormatFileConfig(string ClientID, string ChannelID, string ModeID, string VendorID, string FileExt, string SeparatorType, string FilePrefix)
        {
            FileFormatActiveFileConfigModel fileFormatActiveFileConfigModel = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@VendorID", VendorID);
                param.Add("@FileExt", FileExt);
                param.Add("@FilePrefix", FilePrefix);
                param.Add("@SeparatorType", SeparatorType);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);

                fileFormatActiveFileConfigModel = connection.QueryFirstOrDefault<FileFormatActiveFileConfigModel>("spGetFileFormat", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            if (fileFormatActiveFileConfigModel == null)
            {
                fileFormatActiveFileConfigModel = new FileFormatActiveFileConfigModel();
            }
            return fileFormatActiveFileConfigModel;
        }
        public FileFormatActiveFileConfigModel GetFileFormatActiveFileConfig(string VendorType, string ClientID, string ChannelID, string ModeID, string VendorID)
        {
            FileFormatActiveFileConfigModel fileFormatActiveFileConfigModel = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@VendorType", VendorType);
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@VendorID", VendorID);

                fileFormatActiveFileConfigModel = connection.QueryFirstOrDefault<FileFormatActiveFileConfigModel>("spGetFileFormatActive", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            if (fileFormatActiveFileConfigModel == null)
            {
                fileFormatActiveFileConfigModel = new FileFormatActiveFileConfigModel();
            }
            return fileFormatActiveFileConfigModel;
        }

        public FileFormatActiveFileConfigModel GetFileFormatDefualtFileConfig(string FileExt, string SeparatorType, string ChannelID, string ModeID, string VendorID)
        {
            FileFormatActiveFileConfigModel fileFormatActiveFileConfigModel = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileExt", FileExt);
                param.Add("@SeparatorType", SeparatorType);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@VendorID", VendorID);

                fileFormatActiveFileConfigModel = connection.QueryFirstOrDefault<FileFormatActiveFileConfigModel>("spGetFileFormatDefualt", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            if (fileFormatActiveFileConfigModel == null)
            {
                fileFormatActiveFileConfigModel = new FileFormatActiveFileConfigModel();
            }
            return fileFormatActiveFileConfigModel;
        }

        public List<FileFormatHistoryFileConfigModel> GetFileFormatHistoryFileConfig(string VendorType, string ClientID, string ChannelID, string ModeID, string VendorID)
        {
            List<FileFormatHistoryFileConfigModel> fileFormatHistoryFileConfigList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@VendorType", VendorType);
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@VendorID", VendorID);

                fileFormatHistoryFileConfigList = connection.Query<FileFormatHistoryFileConfigModel>("spGetFileFormatHistory", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (fileFormatHistoryFileConfigList == null)
            {
                fileFormatHistoryFileConfigList = new List<FileFormatHistoryFileConfigModel>();
            }
            return fileFormatHistoryFileConfigList;
        }


        public FileFormatByFileType GetFileFormatByFileTypeFileConfig(FileFormatFileConfigModel fileFormatFileConfigModel)
        {
            FileFormatByFileType fileFormatByFileType = new FileFormatByFileType();
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@VendorType", fileFormatFileConfigModel.VendorType);
                param.Add("@ClientID", fileFormatFileConfigModel.ClientID);
                param.Add("@ChannelID", fileFormatFileConfigModel.ChannelID);
                param.Add("@ModeID", fileFormatFileConfigModel.ModeID);
                param.Add("@VendorID", fileFormatFileConfigModel.VendorID);

                fileFormatByFileType.FileFormatDetails = connection.Query<FileFormatHistoryFileConfigModel>("spGetFileFormatHistory", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                fileFormatByFileType.FileFormatDetails = connection.Query<FileFormatHistoryFileConfigModel>("spGetFileFormatActive", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (fileFormatByFileType.FileFormatDetails == null)
                {
                    fileFormatByFileType.FileFormatDetails = new List<FileFormatHistoryFileConfigModel>();
                }

                return fileFormatByFileType;
            }

        }

        public List<ConfiguredFormatFileConfigModel> InsertFileFormat(FileFormatHistoryFileConfigModel fileFormatHistoryFileConfigModel)
        {
            List<ConfiguredFormatFileConfigModel> configuredFormatFileConfigList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", fileFormatHistoryFileConfigModel.ClientID);
                param.Add("@VendorID", fileFormatHistoryFileConfigModel.VendorID);
                param.Add("@FileExt", fileFormatHistoryFileConfigModel.FileExtention);
                param.Add("@FileXML", fileFormatHistoryFileConfigModel.FormatDescriptionXml);
                param.Add("@CutOffTime", fileFormatHistoryFileConfigModel.CutOffTime);
                param.Add("@User", fileFormatHistoryFileConfigModel.CreatedBy);
                param.Add("@FilePrefix", fileFormatHistoryFileConfigModel.FilePrefix);
                param.Add("@VendorType", fileFormatHistoryFileConfigModel.VendorType);
                param.Add("@ChannelID", fileFormatHistoryFileConfigModel.ChannelID);
                param.Add("@ModeID", fileFormatHistoryFileConfigModel.ModeID);
                param.Add("@SeparatorType", fileFormatHistoryFileConfigModel.SeparatorType);
                param.Add("@StartLine", fileFormatHistoryFileConfigModel.StartIndex);
                param.Add("@EndLine", fileFormatHistoryFileConfigModel.EndIndex);

                configuredFormatFileConfigList = connection.Query<ConfiguredFormatFileConfigModel>("spInsertFileFormat", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (configuredFormatFileConfigList == null)
            {
                configuredFormatFileConfigList = new List<ConfiguredFormatFileConfigModel>();
            }

            return configuredFormatFileConfigList;
        }
    }
}
