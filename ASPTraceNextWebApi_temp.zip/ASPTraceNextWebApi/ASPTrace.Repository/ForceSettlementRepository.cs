﻿using Microsoft.Extensions.Configuration; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using System.Data;
using Dapper;


namespace ASPTrace.Repository
{
    public class ForceSettlementRepository : IForceSettlement
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public ForceSettlementRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<StatusMasterForceSettlementModel> GetStatusMasterForceSettlement()
        {
            List<StatusMasterForceSettlementModel> statusMasterForceSettlementList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                statusMasterForceSettlementList = connection.Query<StatusMasterForceSettlementModel>("UspGetStatusMaster_Core", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (statusMasterForceSettlementList == null)
            {
                statusMasterForceSettlementList = new List<StatusMasterForceSettlementModel>();
            }

            return statusMasterForceSettlementList;
        }

        public List<ClientForceSettlementDetailsModel> GetClientForceSettlementDetails(ClientForceSettlementModel clientForceSettlementModel)
        {
            List<ClientForceSettlementDetailsModel> clientForceSettlementDetailsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", clientForceSettlementModel.ClientID);
                param.Add("@ChannelID", clientForceSettlementModel.ChannelID);
                param.Add("@ModeID", clientForceSettlementModel.ModeID);
                param.Add("@GLStatus", clientForceSettlementModel.GLStatus);
                param.Add("@EJStatus", clientForceSettlementModel.EJStatus);
                param.Add("@NWStatus", clientForceSettlementModel.NWStatus);
                param.Add("@SWStatus", clientForceSettlementModel.SWStatus);
                param.Add("@FromDateTxns", clientForceSettlementModel.FromDateTxns);
                param.Add("@ToDateTxns", clientForceSettlementModel.ToDateTxns); 
                param.Add("@User", clientForceSettlementModel.User);

                clientForceSettlementDetailsList = connection.Query<ClientForceSettlementDetailsModel>("uspForceSettlementTxns_core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (clientForceSettlementDetailsList == null)
                {
                    clientForceSettlementDetailsList = new List<ClientForceSettlementDetailsModel>();
                }
                return clientForceSettlementDetailsList;
            }
        }

        public string InsertForceSettlementDetails(ForceSettledModel forceSettledModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@UnmatchedTxnIds", forceSettledModel.UnmatchedTxnIds);
                param.Add("@SettledDate", forceSettledModel.SettledDate);
                param.Add("@SettledReason", forceSettledModel.SettledReason);
                param.Add("@ReconType", forceSettledModel.ReconType);
                param.Add("@SettlementType", forceSettledModel.SettlementType);
                param.Add("@ChannelID", forceSettledModel.ChannelID);
                param.Add("@Createdby", forceSettledModel.UserName); 
                connection.Open();

                result = connection.ExecuteScalar<string>("uspInsertForceSettledTxns_core", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        //public int GetForceSettlementTxnsInsert(DataTable tblForceSettledTxns, ClientForceSettlementModel clientForceSettlementModel)
        //{
        //    int i = 0;

        //    using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {

        //        using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spInsertForceSettledTxns", con))
        //        {
        //            cmd.CommandType = CommandType.StoredProcedure;

        //            cmd.Parameters.AddWithValue("@tblForceSettledTxns", tblForceSettledTxns);
        //            cmd.Parameters.AddWithValue("@ClientID", clientForceSettlementModel.ClientID);
        //            cmd.Parameters.AddWithValue("@ChannelID", clientForceSettlementModel.ChannelID);
        //            cmd.Parameters.AddWithValue("@ModeID", clientForceSettlementModel.ModeID);
        //            cmd.Parameters.AddWithValue("@ReconType", clientForceSettlementModel.ReconType);
        //            cmd.Parameters.AddWithValue("@SettlementType", clientForceSettlementModel.SettlementType);
        //            cmd.Parameters.AddWithValue("@User", clientForceSettlementModel.User);

        //            con.Open();
        //            i = cmd.ExecuteNonQuery();
        //        }
        //    }
        //    return i;
        //}


        //public ForceSettleByReferenceNumber GetForceSettleByReferenceNumber(ForceSettledModel forceSettledModel)
        //{
        //    ForceSettleByReferenceNumber forceSettleByReferenceNumber = new ForceSettleByReferenceNumber();
        //    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();
        //        param.Add("@ClientID", forceSettledModel.ClientID);
        //        param.Add("@ChannelID", forceSettledModel.ChannelID);
        //        param.Add("@ModeID", forceSettledModel.ModeID);
        //        param.Add("@ReferenceNumber", forceSettledModel.ReferenceNumber);

        //        forceSettleByReferenceNumber.UnmatchedTxnDetails = connection.Query<UnmatchedDataModel>("UspGetUnmatchedData_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

        //    }

        //    if (forceSettleByReferenceNumber.UnmatchedTxnDetails == null)
        //    {
        //        forceSettleByReferenceNumber.UnmatchedTxnDetails = new List<UnmatchedDataModel>();
        //    }

        //    return forceSettleByReferenceNumber;
        //}

    }
}
