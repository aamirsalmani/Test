﻿using System.Data;
using Dapper;
using Microsoft.Extensions.Configuration;
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTrace.Repository
{
    public class FraudReportRepository : IFraudReport
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public FraudReportRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<FrequentReversalReportDetailsModel> GetFrequentReversalReportDetails(FraudReportModel frequentReversalReportModel)
        {
            List<FrequentReversalReportDetailsModel> frequentReversalReportList = null;

            frequentReversalReportModel.FromDate = Convert.ToDateTime(frequentReversalReportModel.FromDate).ToString("dd-MMM-yyyy");

            frequentReversalReportModel.ToDate = Convert.ToDateTime(frequentReversalReportModel.ToDate).ToString("dd-MMM-yyyy");

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_POSTDATE", frequentReversalReportModel.FromDate);
                param.Add("@TR_ENDDATE", frequentReversalReportModel.ToDate);
                param.Add("@ClientID", frequentReversalReportModel.ClientID);
                param.Add("@TerminalId", frequentReversalReportModel.TerminalId);

                frequentReversalReportList = connection.Query<FrequentReversalReportDetailsModel>("UspFrequentReversalCardnumber_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (frequentReversalReportList == null)
            {
                frequentReversalReportList = new List<FrequentReversalReportDetailsModel>();
            }

            return frequentReversalReportList;
        }


        public FrequentReversalTxnByTxnCount GetFrequentReversalTxnByTxnCount(FrequentReversalsReportModel frequentReversalReportModel)
        {
            FrequentReversalTxnByTxnCount frequentReversalTxnByTxnCount = new FrequentReversalTxnByTxnCount();

            frequentReversalReportModel.FromDate = Convert.ToDateTime(frequentReversalReportModel.FromDate).ToString("dd-MMM-yyyy");

            frequentReversalReportModel.ToDate = Convert.ToDateTime(frequentReversalReportModel.ToDate).ToString("dd-MMM-yyyy");

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", frequentReversalReportModel.ClientID);
                param.Add("@CardNumber", frequentReversalReportModel.CardNumber);
                param.Add("@TERMINALID", frequentReversalReportModel.TERMINALID);
                param.Add("@FromDateTxns", frequentReversalReportModel.FromDate);
                param.Add("@ToDateTxns", frequentReversalReportModel.ToDate);

                frequentReversalTxnByTxnCount.FrequentReversalTxnDetails = connection.Query<FrequentReversalTxnDetailsModel>("spFraudCardDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (frequentReversalTxnByTxnCount.FrequentReversalTxnDetails == null)
            {
                frequentReversalTxnByTxnCount.FrequentReversalTxnDetails = new List<FrequentReversalTxnDetailsModel>();
            }

            return frequentReversalTxnByTxnCount;
        }


        public List<HighValueTerminalTransactionsModel> GetHighValueTerminalTransactions(string ClientID, string ChannelID, string UserName)
        {
            List<HighValueTerminalTransactionsModel> highValueTerminalTransactionsModelList = null;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@UserName", UserName);

                highValueTerminalTransactionsModelList = connection.Query<HighValueTerminalTransactionsModel>("spGetTerminalDetailsChannelWise", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (highValueTerminalTransactionsModelList == null)
            {
                highValueTerminalTransactionsModelList = new List<HighValueTerminalTransactionsModel>();
            }
            return highValueTerminalTransactionsModelList;
        }


        public List<HighValueTransactionsReportModel> GetHighValueTransactionsReport(HighValueTransactionsModel highValueTransactionsModel)
        {
            List<HighValueTransactionsReportModel> highValueTransactionsReportList = null;

            highValueTransactionsModel.FromDate = Convert.ToDateTime(highValueTransactionsModel.FromDate).ToString("dd-MMM-yyyy");

            highValueTransactionsModel.ToDate = Convert.ToDateTime(highValueTransactionsModel.ToDate).ToString("dd-MMM-yyyy");

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_POSTDATE", highValueTransactionsModel.FromDate);
                param.Add("@TR_ENDDATE", highValueTransactionsModel.ToDate);
                param.Add("@ClientID", highValueTransactionsModel.ClientID);
                param.Add("@TerminalId", highValueTransactionsModel.TerminalId);

                highValueTransactionsReportList = connection.Query<HighValueTransactionsReportModel>("uspHighvaluetxnReport_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (highValueTransactionsReportList == null)
            {
                highValueTransactionsReportList = new List<HighValueTransactionsReportModel>();
            }

            return highValueTransactionsReportList;
        }


        public HighValueTransactionsOnTxnCountModel GetHighValueTransactionsOnTxnCount(HighValueTransactionModel highValueTransactionsModel)
        {
            HighValueTransactionsOnTxnCountModel highValueTransactionsOnTxnCount = new HighValueTransactionsOnTxnCountModel();

            highValueTransactionsModel.FromDate = Convert.ToDateTime(highValueTransactionsModel.FromDate).ToString("dd-MMM-yyyy");

            highValueTransactionsModel.ToDate = Convert.ToDateTime(highValueTransactionsModel.ToDate).ToString("dd-MMM-yyyy");

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", highValueTransactionsModel.ClientID);
                param.Add("@CardNumber", highValueTransactionsModel.CardNumber);
                param.Add("@TERMINALID", "ALL");
                param.Add("@FromDateTxns", highValueTransactionsModel.FromDate);
                param.Add("@ToDateTxns", highValueTransactionsModel.ToDate);

                highValueTransactionsOnTxnCount.FraudCardDetails = connection.Query<HighValueTransactionsFraudCardDetailsReportModel>("spFraudCardDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

            }

            if (highValueTransactionsOnTxnCount.FraudCardDetails == null)
            {
                highValueTransactionsOnTxnCount.FraudCardDetails = new List<HighValueTransactionsFraudCardDetailsReportModel>();
            }
            return highValueTransactionsOnTxnCount;
        }


        public List<MidnightTransactionsReportModel> GetMidnightTransactionsTxnCount(MidnightTransactionsModel midnightTransactionsModel)
        {
            List<MidnightTransactionsReportModel> midnightTransactionsTxnCountList = new List<MidnightTransactionsReportModel>();

            midnightTransactionsModel.FromDate = Convert.ToDateTime(midnightTransactionsModel.FromDate).ToString("dd-MMM-yyyy");

            midnightTransactionsModel.ToDate = Convert.ToDateTime(midnightTransactionsModel.ToDate).ToString("dd-MMM-yyyy");

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_POSTDATE", midnightTransactionsModel.FromDate);
                param.Add("@TR_ENDDATE", midnightTransactionsModel.ToDate);
                param.Add("@ClientID", midnightTransactionsModel.ClientID);
                param.Add("@TerminalId", midnightTransactionsModel.TerminalId);

                midnightTransactionsTxnCountList = connection.Query<MidnightTransactionsReportModel>("UspTransaction_done_night_switch_time_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (midnightTransactionsTxnCountList == null)
            {
                midnightTransactionsTxnCountList = new List<MidnightTransactionsReportModel>();
            }

            return midnightTransactionsTxnCountList;
        }


        public List<MultipleTxnsWithDiffTerminalModel> GetMultipleTxnsWithDiffTerminal(MultipleTxnsDiffModel multipleTxnsDiffModel)
        {
            List<MultipleTxnsWithDiffTerminalModel> multipleTxnsWithDiffTerminalList = null;

            multipleTxnsDiffModel.FromDate = Convert.ToDateTime(multipleTxnsDiffModel.FromDate).ToString("dd-MMM-yyyy");

            multipleTxnsDiffModel.ToDate = Convert.ToDateTime(multipleTxnsDiffModel.ToDate).ToString("dd-MMM-yyyy");

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_POSTDATE", multipleTxnsDiffModel.FromDate);
                param.Add("@TR_ENDDATE", multipleTxnsDiffModel.ToDate);
                param.Add("@ClientID", multipleTxnsDiffModel.ClientID);
                param.Add("@TerminalId", multipleTxnsDiffModel.TerminalID);

                multipleTxnsWithDiffTerminalList = connection.Query<MultipleTxnsWithDiffTerminalModel>("UspSameCardnumberfromdifferentlocation_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (multipleTxnsWithDiffTerminalList == null)
            {
                multipleTxnsWithDiffTerminalList = new List<MultipleTxnsWithDiffTerminalModel>();
            }

            return multipleTxnsWithDiffTerminalList;
        }


        public FraudReportDiffByTxnCount GetFraudReportDiffByTxnCount(MultipleTxnDiffModel multipleTxnsDiffModel)
        {
            FraudReportDiffByTxnCount fraudReportDiffByTxnCountList = new FraudReportDiffByTxnCount();
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", multipleTxnsDiffModel.ClientID);
                param.Add("@CardNumber", multipleTxnsDiffModel.CardNumber);
                param.Add("@TERMINALID", "ALL");
                param.Add("@FromDateTxns", multipleTxnsDiffModel.FromDate);
                param.Add("@ToDateTxns", multipleTxnsDiffModel.ToDate);


                fraudReportDiffByTxnCountList.FraudReports = connection.Query<FraudReportDiffModel>("spFraudCardDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (fraudReportDiffByTxnCountList.FraudReports == null)
            {
                fraudReportDiffByTxnCountList.FraudReports = new List<FraudReportDiffModel>();
            }

            return fraudReportDiffByTxnCountList;
        }

        public List<MultipleTxnsWithSameTerminalModel> GetMultipleTxnsWithSameTerminal(FraudReportModel multipleTxnsSameModel)
        {
            List<MultipleTxnsWithSameTerminalModel> multipleTxnsWithSameTerminalList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_POSTDATE", multipleTxnsSameModel.FromDate);
                param.Add("@TR_ENDDATE", multipleTxnsSameModel.ToDate);
                param.Add("@ClientID", multipleTxnsSameModel.ClientID);
                param.Add("@TerminalId", multipleTxnsSameModel.TerminalId);

                multipleTxnsWithSameTerminalList = connection.Query<MultipleTxnsWithSameTerminalModel>("UspSameCardnumberfromsamelocation_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (multipleTxnsWithSameTerminalList == null)
            {
                multipleTxnsWithSameTerminalList = new List<MultipleTxnsWithSameTerminalModel>();
            }

            return multipleTxnsWithSameTerminalList;
        }


        public FraudReportSameByTxnCount GetFraudReportSameByTxnCount(MultipleTxnsSameModel multipleTxnsSameModel)
        {
            FraudReportSameByTxnCount fraudReportSameByTxnCountList = new FraudReportSameByTxnCount();
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", multipleTxnsSameModel.ClientID);
                param.Add("@CardNumber", multipleTxnsSameModel.CardNumber);
                param.Add("@TERMINALID", multipleTxnsSameModel.TerminalId);
                param.Add("@FromDateTxns", multipleTxnsSameModel.FromDate);
                param.Add("@ToDateTxns", multipleTxnsSameModel.ToDate);


                fraudReportSameByTxnCountList.FraudReports = connection.Query<FraudReportSameModel>("spFraudCardDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (fraudReportSameByTxnCountList.FraudReports == null)
            {
                fraudReportSameByTxnCountList.FraudReports = new List<FraudReportSameModel>();
            }

            return fraudReportSameByTxnCountList;
        }

        public List<DuplicateRecordModel> GetDuplicateRecordsReport(InputReportModel duplicateTxnsModel)
        {
            List<DuplicateRecordModel> duplicateTxnsReportModelList = null;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", duplicateTxnsModel.ClientID);
                param.Add("@ChannelID", duplicateTxnsModel.ChannelID);
                param.Add("@LogType", duplicateTxnsModel.TxnType);
                param.Add("@FromDateTxns", duplicateTxnsModel.FromDate);
                param.Add("@ToDateTxns", duplicateTxnsModel.ToDate);

                duplicateTxnsReportModelList = connection.Query<DuplicateRecordModel>("uspGetDuplicateRecords", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (duplicateTxnsReportModelList == null)
            {
                duplicateTxnsReportModelList = new List<DuplicateRecordModel>();
            }

            return duplicateTxnsReportModelList;
        }


    }
}
