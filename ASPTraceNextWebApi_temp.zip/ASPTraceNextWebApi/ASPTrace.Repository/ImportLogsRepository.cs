﻿using Microsoft.Extensions.Configuration; 
using System.Data; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper; 

namespace ASPTrace.Repository
{
   public class ImportLogsRepository : IImportLogs
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public ImportLogsRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public int AddBranchMaster(string ClientId, DataTable dtBranch)
        {
            int rowsAffected = 0;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@tblBranchDetails", dtBranch, DbType.Object);

                param.Add("@ClientID", ClientId);
                rowsAffected = connection.Execute("spBulkInsertBranchMaster", param, commandType: System.Data.CommandType.StoredProcedure);
            }



            return rowsAffected;
        }

        public int AddTerminalMaster(string ClientId, DataTable dtTerminal)
        {
            int rowsAffected = 0;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@tblTerminalDetails", dtTerminal, DbType.Object);

                param.Add("@ClientID", ClientId);
                rowsAffected = connection.Execute("spBulkInsertTerminalMaster", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return rowsAffected;
        }

        public List<FileTypeImportLogsModel> GetFileTypeImportLogs(string ClientID)
        {
            List<FileTypeImportLogsModel> clientImportLogsModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                clientImportLogsModelsList = connection.Query<FileTypeImportLogsModel>("spGetFileType", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientImportLogsModelsList == null)
            {
                clientImportLogsModelsList = new List<FileTypeImportLogsModel>();
            }
            return clientImportLogsModelsList;
        }

        public DataTable GetFileTypeFormatById(string ClientID, string FormatID)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandText = "UspGetFileTypeByFormatId_Core";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.BigInt).Value = ClientID;
                        cmd.Parameters.AddWithValue("@FormatID", SqlDbType.BigInt).Value = FormatID;

                        connExcel.Open();
                        da.SelectCommand = cmd;
                        da.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }

        public DataTable GetCassetteInfoByTerminalId(string ClientID, string TerminalID)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandText = "uspCassetteInfoByTerminalId_Core";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = ClientID;
                        cmd.Parameters.AddWithValue("@TerminalID", SqlDbType.VarChar).Value = TerminalID;

                        connExcel.Open();
                        da.SelectCommand = cmd;
                        da.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }

        public DataTable GetFileNameNotContain(string ClientID, string FormatID)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandText = "UspGetFileNameNotContain_Core";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.BigInt).Value = ClientID;
                        cmd.Parameters.AddWithValue("@FormatID", SqlDbType.BigInt).Value = FormatID;

                        connExcel.Open();
                        da.SelectCommand = cmd;
                        da.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }
        public string GetFileQuery(int ClientID,int ChannelID,int ModeID,int VendorID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spGetFileUploadQuery";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ClientID", ClientID);
                        cmd.Parameters.AddWithValue("@ChannelID", ChannelID);
                        cmd.Parameters.AddWithValue("@ModeID", ModeID);     
                        cmd.Parameters.AddWithValue("@VendorID", VendorID);
                        System.Data.SqlClient.SqlParameter outputParameter = new System.Data.SqlClient.SqlParameter("@OutputString", SqlDbType.NVarChar, -1);
                        outputParameter.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(outputParameter);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        string outputString = outputParameter.Value.ToString();
                        connExcel.Close();
                        return outputString;
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string GLDataTableDynamic(DataTable __DataTable, string Query)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertGLDataDynamic";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblGLdata", __DataTable);
                        cmd.Parameters.AddWithValue("@Query", Query);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string SWDataTableDynamic(DataTable __DataTable,string Query)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertSWDataDynamic";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblSWdata", __DataTable);
                        cmd.Parameters.AddWithValue("@Query", Query);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string SWDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertSWData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblSWdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string AcquirerDataNPCIATM(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertNPCIAcqATM";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNWdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string AdjlogImportdata(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertATMAdjData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblDMSdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string IssuerDataNPCIATM(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertNPCIIssATM";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNWdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string EJDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertEJData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblEJdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertEJData(DataTable __DataTable, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertEJData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblEJdata", __DataTable);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID); 
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertEJMachineCounterData(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertMachineCounterData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblMachineCounter", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertEJSwitchCounterData(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertSwitchCounterData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblMachineCounter", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string AcquirerDataVISAEP745(DataTable _DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertVisaAcquirerEP745";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@tblVisaAcquirer", _DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();

                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                // _log.FunErrorLog(ex.Message.ToString(), BankCode, "MainRepository", "BFSDataBFSTable", 0, FileName, UserName, 'E');
                return "Error occrued kindly check the log file for more details";
            }
        }


        public string NEFTRTGSImportdataNPCI(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertNPCI_NEFT_RTGS";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNEFTRTGSdata", __DataTable);
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string NPCISettlementDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertNPCISettlementData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNPCIdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }


        public string IMPSAdjustmentimportlogImportdata(DataTable _DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertIMPSAdjData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblDMSdata1", _DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }


        public string IMPSSettlementDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertIMPSSettlementData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblIMPSdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string IMPSIssuerimportlogImportdata(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertIssuerIMPSData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblIssuerData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string IMPSAcquirerimportlogImportdata(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertIMPSAcquirerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblAcqData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string RefundlogImportdata(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertRefundlog";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblrefundlog", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertRefundlogs(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertPosRefundlog";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblrefundlog", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

       

        public string IssuerDataNPCIPOS(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertPOSIssuerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@POSISSUERDATA_USER", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string UPISettlementDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertUPISettlementData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblUPIdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string IssuerDataUPITable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertIssuerUPIData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblIssuerData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string UPIacquirerimportlogImportdata(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertUPIAcquirerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblAcqData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BFSDataBFSTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertNFSRData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNFSRdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string UPIDRCImportdata(DataTable __DataTable)
        {
            try
            {

                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertUPIDRC";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblupiDRC", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";

                    }
                }
            }

            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string chargebackTable(DataTable __DataTable)
        {
            try
            {

                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertchargeback";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblchargeback", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";

                    }
                }
            }

            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string NEFTRTGSImportdataBankINWARD(DataTable __DataTable)
        {
            try
            {

                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkNEFTRTGSBANKINWARD";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@neftrtgsbankinward", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";

                    }
                }
            }

            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string AcquirerDataVISA(DataTable _DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {                      
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertVisaAcquirer";
                        cmd.CommandType = CommandType.StoredProcedure; 
                        
                        cmd.Parameters.AddWithValue("@tblVisaAcquirer", _DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();

                        return "Successful";
                    }
                }
            }
            catch  
            {
                // _log.FunErrorLog(ex.Message.ToString(), BankCode, "MainRepository", "BFSDataBFSTable", 0, FileName, UserName, 'E');
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string IssuerDataVISA(DataSet _DataSet)
        {
            try
            {

                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertVISAIss";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblVISA0", _DataSet.Tables["Table1"]);
                        cmd.Parameters.AddWithValue("@tblVISA1", _DataSet.Tables["Table2"]);
                        cmd.Parameters.AddWithValue("@tblVISA3", _DataSet.Tables["Table3"]);
                        cmd.Parameters.AddWithValue("@tblVISA4", _DataSet.Tables["Table4"]);
                        cmd.Parameters.AddWithValue("@tblVISA5", _DataSet.Tables["Table5"]);
                        cmd.Parameters.AddWithValue("@tblVISA6", _DataSet.Tables["Table6"]);
                        cmd.Parameters.AddWithValue("@tblVISA7", _DataSet.Tables["Table7"]);
                        cmd.Parameters.AddWithValue("@tblVISA1020", _DataSet.Tables["Table8"]);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";

                    }
                }
            }

            catch  
            {
                return "Error occrued kindly check the log file for more details";
            }
        }


        public string AcquirerDataMASTER(DataTable _DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertMasterCardAcquirer";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@tblMasterCardAcquirer", _DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();

                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                // _log.FunErrorLog(ex.Message.ToString(), BankCode, "MainRepository", "BFSDataBFSTable", 0, FileName, UserName, 'E');
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BFSDataCommon(DataSet DS)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        if (DS.Tables[0].Rows.Count > 0)
                        {
                            cmd.Connection = connExcel;
                            cmd.CommandText = "BulkInsertBFSAcquirer";
                            cmd.CommandTimeout = 1000000;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@tblNWdata", DS.Tables[0]);
                            connExcel.Open();
                            cmd.ExecuteNonQuery();
                            connExcel.Close();
                           
                        }
                        if (DS.Tables[1].Rows.Count > 0)
                        {
                            cmd.Connection = connExcel;
                            cmd.CommandText="BulkInsertBFSIssuer";
                            cmd.CommandTimeout = 1000000;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@tblNWdata", DS.Tables[1]);
                            connExcel.Open();
                            cmd.ExecuteNonQuery();
                            connExcel.Close();
                        }
                        return "Successful";
                    }

                }
            }
            catch (Exception ex)
            {
                //_log.FunErrorLog(ex.Message.ToString(), BankCode, "MainRepository", "AcquirerDataNPCITable", 0, FileName, UserName, 'E');
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string GLDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertCBSData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblGLdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string NEFTRTGSImportdata(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkBANKNEFTRTGS";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@bankneftrtgs", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string C3Rimportdata(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertc3rfile";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblcbrdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertCBRData(DataTable __DataTable, DateTime? FileDate, string FilePath, string FileName, string UserName)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertCBRData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblcbrdata", __DataTable);
                        cmd.Parameters.AddWithValue("@FileDate", FileDate);
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@FilePath", FilePath);
                        cmd.Parameters.AddWithValue("@CreatedBy", UserName);

                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertSwapCBRDataNCR(DataTable __DataTable, DateTime? FileDate, string FilePath, string FileName, string UserName, string ClientID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertSwapCBRDataNCR";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblcbrdata", __DataTable);
                        cmd.Parameters.AddWithValue("@ClientID", ClientID);
                        cmd.Parameters.AddWithValue("@FileDate", FileDate);
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@FilePath", FilePath);
                        cmd.Parameters.AddWithValue("@CreatedBy", UserName);

                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string impsissuerimportlogImportdata(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertIssuerIMPSData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblIssuerData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch(Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string impsAdjustmentimportlogImportdata(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertIMPSAdjData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblDMSdata1", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string impsacquirerimportlogImportdata(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertIMPSAcquirerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblAcqData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertUPIAdjustment(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = conn;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertUPIAdjustmentFile";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblupiadjustment", __DataTable);
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertAEPSAcquirerData(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertAEPSAcquirerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblAcqData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertAEPSIssuerData(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertAEPSIssuerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblIssuerData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }


        public string BulkInsertAEPSSettlement(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertAEPSSettlementData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblAEPSSettlementdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertAEPSAdjustment(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertAEPSAdjustment";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblAEPSADJUSMENT", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertNETCACQUIERDATA(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertNETCACQUIERDataRAW_FastTag";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNWdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertNETCDisputeDATA(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertNETCDispute_FastTag";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@TypeAllDispute", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertNPCINETCSettlementData(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertNPCINETCSettlementData_FastTag";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNPCIdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertNpciNETCServiceFee(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertNpciNETCServiceFee_FastTag";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNPCIdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertNPCIFee(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertNpciDSRReport_FastTag";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNPCIdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string MasterT464DataTable(DataTable _DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
                {

                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = con;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertMasterAcqIssT464";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblMasterData", _DataTable);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                //_log.FunErrorLog(ex.Message.ToString(), BankCode, "FileImportDAL", "EJDataTable", 0, FileName, UserName, 'E');
                return "Error occrued kindly check the log file for more details";
            }
        }

        public int AddDisputeCHBK(DisputeAddModel disputeModel)
        {
            int rowsAffected = 0;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();


                param.Add("@clientid", disputeModel.ClientID);
                param.Add("@channelid", disputeModel.ChannelID);
                param.Add("@modeid", disputeModel.ModeID);
                param.Add("@terminalid", disputeModel.TerminalId);
                param.Add("@referenceno", disputeModel.ReferenceNo);
                param.Add("@cardno", disputeModel.CardNo);
                param.Add("@txnsvaluedt", disputeModel.TxnValueDateTime);
                param.Add("@amount", disputeModel.TxnAmount);
                param.Add("@acamount", disputeModel.ActualTxnsAmount);
                param.Add("@noofclaim", disputeModel.NoOfClaim);
                param.Add("@acctno", disputeModel.AccountNumber);
                param.Add("@contactno", disputeModel.ContactNumber);
                param.Add("@txnremark", disputeModel.Remark);
                param.Add("@createdby", disputeModel.CreatedBy);
                param.Add("@claimtype", disputeModel.ClaimType);
                param.Add("@complaintid", disputeModel.ComplaintID);
                param.Add("@claimdate", disputeModel.ClaimDate);
                param.Add("@txnssubtype", disputeModel.TxnsSubType);
                param.Add("@approvalcode", disputeModel.ApprovalCode);
                param.Add("@reasoncode", disputeModel.ReasonCode);
                param.Add("@txnskey", disputeModel.TxnsKey);
                param.Add("@cycleid", disputeModel.CycleID);
                param.Add("@filename", disputeModel.FileName);
                param.Add("@cardtype", disputeModel.CardType);
                param.Add("@cycledate", disputeModel.CycleDate);
                param.Add("@currencycode", disputeModel.CurrencyCode);

                rowsAffected = connection.Execute("SPADDDISPUTECHBK", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return rowsAffected;
        }

        public string BulkInsertBBPSNetwork(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "SpBulkInsertBBPSNetwork";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@BBPSNetworkDATA", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string TableBBPSSettlement(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertBBPSSettlement";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblBBPSSettlement", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string GLAgentLedgerBBPS(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "Proc_BulkInsertBBPSGLData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@GLDATA", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string BulkInsertSwitchFilesDataBBPS(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "SpBulkInsertSwitchDataBBPS";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@SwitchDataBBPS", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string MobiwareDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "USP_BulkInsertPayrakkamSwitchDataMobiwareTLF";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@MobiwareTLFDataBBPS", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }


        public string BulkInsertEJData_L(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertEJData_L";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblEJdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string SWDataTable_L(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertSWData_L";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblSWdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }


        public string GLDataTable_L(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertCBSData_L";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblGLdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string IssuerDataNPCIATM_L(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertNPCIIssATM_L";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNWdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }


        public string BFSDataBFSTable_L(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertNFSRData_L";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNFSRdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string IssuerDataNPCIPOS_L(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertPOSIssuerData_L";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@POSISSUERDATA_USER", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string RefundlogImportdata_L(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertRefundlog_L";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblrefundlog", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string AcquirerDataNPCIATM_L(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertNPCIAcqATM_L";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblNWdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BBPSPaySWDataTableDynamic(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "USP_BulkInsertPayrakkamSwitchDataMobiwareTLF";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@MobiwareTLFDataBBPS", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string BulkInsertGLFilesDataCycleWise(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "Proc_BulkInsertPayrakkamGLDataCycleWise";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@GLDATA", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        #region Nikhil
        public string BulkInsertPayrakkamSWDataTableCSV(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "Proc_BulkInsertPayrakkamSwitchData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@SwitchData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertPayrakkamGLDataTableCSV(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "Proc_BulkInsertPayrakkamGLData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@GLDATA", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }

        public string BulkInsertPayrakkamBBPSSettlementCSV(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertPayRakkamBBPSSettlement";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblPayBBPSSettlement", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string BulkInsertPayrakkamBBPSNetworkXML(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "SP_BulkInsertPayrakamBBPSNetwork";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@PayrakamBBPSNetworkDATA", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string BulkInsertPayrakkamFranchiseLedger(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "SP_BulkInsertPayrakkamFranchiseLedger";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@PayrakkamFranchiseLedger", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string BulkInsertPayrakkamFranchiseLedgerCycleWise(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "SP_BulkInsertPayrakkamFranchiseLedgerCycleWise";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@PayrakkamFranchiseLedger", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string BulkInsertPayrakkamIMPSAdjData(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "SP_BulkInsertPayrakkamIMPSAdjustment";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@IMPSData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string BulkInsertPayrakamAdjustmentData(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertPayrakkamAdjustmentData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblAdjdata", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        public string BulkInsertPayrakkamMATMAdjustmentData(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertPayrakkamMATMAdjustment";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@MATMADJDATA", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
        #endregion

        public string BulkInsertTimeout(DataTable _DataTable, string ClientID, string FilePath, string FileName, string UserName)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertUPIIMPSTimeout";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", _DataTable);
                        cmd.Parameters.AddWithValue("@ClientID", ClientID); 
                        cmd.Parameters.AddWithValue("@FilePath", FilePath);
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@CreatedBy", UserName);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;";
            }
        }
        public string BulkInsertDebitReversal(DataTable _DataTable, string ClientID, string FilePath, string FileName, string UserName)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertUPIDebitReversal";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", _DataTable);
                        cmd.Parameters.AddWithValue("@ClientID", ClientID);
                        cmd.Parameters.AddWithValue("@FilePath", FilePath);
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@CreatedBy", UserName);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;";
            }
        }

        public string BulkInsertGLAdjustmentALL(DataTable __DataTable, string path, string FileName, string UserName)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertGLDataAdjustment";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@FilePath", path);
                        cmd.Parameters.AddWithValue("@CreatedBy", UserName);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error occrued kindly check the log file for more details";
            }
        }
    }
}
