﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTrace.Repository
{
    public class LogFileTypeConfigRepository : ILogFileTypeConfig
    {



        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public LogFileTypeConfigRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);

        }



        public List<GetLogFileTypeconfiglist> GetLogFileTypeConfigData(GetLogFileTypeConfigModel getLogFileTypeConfigModel)
        {
            List<GetLogFileTypeconfiglist> GetLogFileTypeconfiglist = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientId", getLogFileTypeConfigModel.ClientID);
                param.Add("@ChannelId", getLogFileTypeConfigModel.ChannelID);
                param.Add("@ModeId", getLogFileTypeConfigModel.ModeID);


                GetLogFileTypeconfiglist = connection.Query<GetLogFileTypeconfiglist>("uspGetLogFileTypeconfiglist", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (GetLogFileTypeconfiglist == null)
            {
                GetLogFileTypeconfiglist = new List<GetLogFileTypeconfiglist>();
            }

            return GetLogFileTypeconfiglist;
        }


        public string AddNewLogfileTypeconfigData(LogfileTypeConfigModel addNewLogfileTypeConfigModel)
        {
            string AddNewLogfileTypeconfigData = "";
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientId", addNewLogfileTypeConfigModel.Clientid);
                param.Add("@ChannelId", addNewLogfileTypeConfigModel.Channelid);
                param.Add("@ModeId", addNewLogfileTypeConfigModel.Modeid);
                //  param.Add("@logFileType", addNewLogfileTypeConfigModel.LogFileType);
                param.Add("@tableName", addNewLogfileTypeConfigModel.TableName);
                param.Add("@FileID", addNewLogfileTypeConfigModel.FileID);
                param.Add("@networkTypeID", addNewLogfileTypeConfigModel.NetworkTypeID);
                param.Add("@isRecon", addNewLogfileTypeConfigModel.IsRecon);
                param.Add("@ID", addNewLogfileTypeConfigModel.ID);
                param.Add("@Mode", addNewLogfileTypeConfigModel.Mode);
                param.Add("@FileCount", Convert.ToInt32(addNewLogfileTypeConfigModel.FileCount));
                param.Add("@UserName", addNewLogfileTypeConfigModel.UserName);

                AddNewLogfileTypeconfigData = connection.ExecuteScalar<string>("uspLogFileTypeConfiguration", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return AddNewLogfileTypeconfigData;
        }

        public string EditLogfileTypeconfigData(LogfileTypeConfigModel editLogfileTypeConfigModel)
        {
            string UpdateLogfileTypeconfigData = "";
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientId", editLogfileTypeConfigModel.Clientid);
                param.Add("@ChannelId", editLogfileTypeConfigModel.Channelid);
                param.Add("@ModeId", editLogfileTypeConfigModel.Modeid);
                //  param.Add("@logFileType", addNewLogfileTypeConfigModel.LogFileType);
                param.Add("@tableName", editLogfileTypeConfigModel.TableName);
                param.Add("@FileID", editLogfileTypeConfigModel.FileID);
                param.Add("@networkTypeID", editLogfileTypeConfigModel.NetworkTypeID);
                param.Add("@isRecon", editLogfileTypeConfigModel.IsRecon);
                param.Add("@ID", editLogfileTypeConfigModel.ID);
                param.Add("@Mode", editLogfileTypeConfigModel.Mode);

                UpdateLogfileTypeconfigData = connection.ExecuteScalar<string>("uspLogFileTypeConfiguration", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return UpdateLogfileTypeconfigData;
        }



        public string DeleteLogFileTypeConfigData(DeleteLogFileTypeConfigModel deleteLogFileTypeConfigModel)
        {
            string result = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();  
                param.Add("@ID", deleteLogFileTypeConfigModel.ID);
                param.Add("@Mode", deleteLogFileTypeConfigModel.Mode);

                connection.Open();
                result = connection.ExecuteScalar<string>("uspLogFileTypeConfiguration", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }
        
        public LogfileTypeConfigModel GetLogTypeConfigurationDetails(int ID)
        {
            LogfileTypeConfigModel result =new LogfileTypeConfigModel();
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@ID",ID);
                connection.Open();
                result = connection.QuerySingleOrDefault<LogfileTypeConfigModel>("uspGetLogTypeByID", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            if(result == null)
            {
                result = new LogfileTypeConfigModel();
            }

            return result;
        }

    }


}
