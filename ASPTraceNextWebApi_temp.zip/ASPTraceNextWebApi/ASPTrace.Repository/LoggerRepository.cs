﻿
using Microsoft.Extensions.Configuration;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;

namespace ASPTrace.Repository
{
    public class LoggerRepository : ILogging
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public LoggerRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<UserLoginReportDataModel> GetUserLoginReport(UserLoginReportModel userLoginReportModel)
        {
            List<UserLoginReportDataModel> GetUserLoginDataList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@StartDate", userLoginReportModel.StartDate);
                param.Add("@EndDate", userLoginReportModel.EndDate);
                param.Add("@UserId", userLoginReportModel.UserId);
                GetUserLoginDataList = connection.Query<UserLoginReportDataModel>("uspGetUserLoginReportData", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (GetUserLoginDataList == null)
            {
                GetUserLoginDataList = new List<UserLoginReportDataModel>();
            }

            return GetUserLoginDataList;
        }

        public List<UserListModel> GetUserList()
        {
            List<UserListModel> UserList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                UserList = connection.Query<UserListModel>("uspGetUserList", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (UserList == null)
            {
                UserList = new List<UserListModel>();
            }

            return UserList;
        }

        public List<MenuListModel> GetMenuList()
        {
            List<MenuListModel> MenuList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                MenuList = connection.Query<MenuListModel>("uspGetMenuList", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (MenuList == null)
            {
                MenuList = new List<MenuListModel>();
            }

            return MenuList;
        }

        public string EnableMenuItem(MenuEnableModel menuEnableModel)
        {
            string result = "";
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    param.Add("@MenuName", menuEnableModel.MenuName);
                    result = connection.ExecuteScalar<string>("uspEnableDisableMenu",param , commandType: System.Data.CommandType.StoredProcedure).ToString();
                }

                if (result == null)
                {
                    result = "Error";
                }
            }
            catch (Exception ex)
            {
                return "Error";
            }

            return result;
        }

        public List<DbExceptionDataModel> GetDbExceptionList(DbExceptionModel dbExceptionModel)
        {
            List<DbExceptionDataModel> ExList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@StartDate" , dbExceptionModel.StartDate);
                param.Add("@EndDate", dbExceptionModel.EndDate);
                ExList = connection.Query<DbExceptionDataModel>("uspGetDbExceptionList",param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ExList == null)
            {
                ExList = new List<DbExceptionDataModel>();
            }

            return ExList;
        }

        public List<ErrorLogDataModel> GetErrorLogList(ErrorLogModel errorLogModel)
        {
            List<ErrorLogDataModel> ErrorList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientId",errorLogModel.ClientId);
                param.Add("@StartDate", errorLogModel.StartDate);
                param.Add("@EndDate", errorLogModel.EndDate);
                ErrorList = connection.Query<ErrorLogDataModel>("uspGetErrorLogList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ErrorList == null)
            {
                ErrorList = new List<ErrorLogDataModel>();
            }

            return ErrorList;
        }

        public List<UserActivityReportDataModel> GetUserActivityReport(UserLoginReportModel userLoginReportModel)
        {
            List<UserActivityReportDataModel> GetUserLoginDataList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@StartDate", userLoginReportModel.StartDate);
                param.Add("@EndDate", userLoginReportModel.EndDate);
                param.Add("@UserId", userLoginReportModel.UserId);
                GetUserLoginDataList = connection.Query<UserActivityReportDataModel>("uspGetUserActivityReportData", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (GetUserLoginDataList == null)
            {
                GetUserLoginDataList = new List<UserActivityReportDataModel>();
            }

            return GetUserLoginDataList;
        }

        public string InsertUserActivityReport(UserActivityReportInsertModel userLoginReportModel)
        {
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@Activity", userLoginReportModel.Activity);
                param.Add("@PageName", userLoginReportModel.PageName);
                param.Add("@UserId", userLoginReportModel.UserId);
                connection.Query<string>("uspInsertUserActivityReport", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return "Success";
        }

        public List<dynamic> GetUserAddedModifiedDetails(UserAuditReportModel usermodel)
        {
            List<dynamic> userData = null;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@StartDate", usermodel.StartDate);
                param.Add("@EndDate", usermodel.EndDate);

                userData = connection.Query<dynamic>("UserAddModify_Audit", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (userData == null)
            {
                userData = new List<dynamic>();
            }

            return userData;
        }
    }
}

