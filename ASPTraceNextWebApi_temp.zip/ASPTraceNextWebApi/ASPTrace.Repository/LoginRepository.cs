﻿using Microsoft.Extensions.Configuration;
using System.Data; 
using ASPTrace.Models;
using Dapper;
using ASPTrace.Contracts;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient; 

namespace ASPTrace.Repository
{
    public class LoginRepository : ILogin
    {
        private readonly IConfiguration _configuration;

        private string _connectionString = string.Empty;
        public LoginRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public UserClientModel GetClientCodeDetails(string UserID)
        {
            UserClientModel loginModel;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                param.Add("@Password", string.Empty);
                loginModel = connection.QueryFirstOrDefault<UserClientModel>("uspClientCodeDetails", param, commandType: CommandType.StoredProcedure);

            }

            if (loginModel == null)
            {
                loginModel = new UserClientModel();
            }
            return loginModel;
        }

        public LoginSuccessModel ValidateUser(LoginModel loginModel)
        {
            LoginSuccessModel tempLoginModel;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", loginModel.UserName);
                param.Add("@Password", loginModel.Password);
                param.Add("@ClientCode", loginModel.ClientID);
                tempLoginModel = connection.QueryFirstOrDefault<LoginSuccessModel>("Usp_GetLoginDetails_Core", param, commandType: CommandType.StoredProcedure);

            }

            if (tempLoginModel == null)
            {
                tempLoginModel = new LoginSuccessModel();
            }
            return tempLoginModel;
        }

        public int UpdateLoginCount(UserLoginCountModel loginCountModel)
        {
            int result;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", loginCountModel.UserID);
                param.Add("@LoginFailedCount", loginCountModel.LoginFailedCount);
                param.Add("@LoginAttemptCount", loginCountModel.LoginAttemptCount);

                result = connection.Execute("uspUpdateLoginCount", param, commandType: CommandType.StoredProcedure);
            }

            return result;
        }

        public LoginSuccessModel GetById(string UserID)
        {
            LoginSuccessModel loginModel;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                loginModel = connection.QueryFirstOrDefault<LoginSuccessModel>("Usp_GetuserById_Core", param, commandType: CommandType.StoredProcedure);

            }

            if (loginModel == null)
            {
                loginModel = new LoginSuccessModel();
            }
            return loginModel;
        }

        public string VERIFY_CAPTCHA(string CAPTCHACODE, string WebToken)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@CAPTCHACODE", CAPTCHACODE);
                param.Add("@WebToken", WebToken);
                result = connection.ExecuteScalar<string>("VERIFY_CAPTCHA", param, commandType: CommandType.StoredProcedure);
            }

            return result;
        }


        public CAPTCHAModel GetCAPTCHA(string UniqueId)
        {
            CAPTCHAModel cAPTCHAModel = new CAPTCHAModel();

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                try
                {
                    connection.Open();

                    cAPTCHAModel = connection.QueryFirstOrDefault<CAPTCHAModel>("uspGETCAPTCHACODE", null, commandType: CommandType.StoredProcedure);
                }
                catch (Exception ex){ }                
               
            }

            if (cAPTCHAModel == null)
            {
                cAPTCHAModel = new CAPTCHAModel();
            }
            return cAPTCHAModel;
        }

        public string DataTableToJSONWithStringBuilder(DataTable table)
        {
            var JSONString = new StringBuilder();
            if (table.Rows.Count > 0)
            {
                JSONString.Append("[");
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    JSONString.Append("{");
                    for (int j = 0; j < table.Columns.Count; j++)
                    {
                        if (j < table.Columns.Count - 1)
                        {
                            JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\":" + "\"" + table.Rows[i][j].ToString() + "\",");
                        }
                        else if (j == table.Columns.Count - 1)
                        {
                            JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\":" + "\"" + table.Rows[i][j].ToString() + "\"");
                        }
                    }
                    if (i == table.Rows.Count - 1)
                    {
                        JSONString.Append("}");
                    }
                    else
                    {
                        JSONString.Append("},");
                    }
                }
                JSONString.Append("]");
            }
            return JSONString.ToString();
        }

        public FirstLoginModel GetUserDetailsByEmailId(string EMAILID)
        {
            FirstLoginModel objModel = null;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@EMAILID", EMAILID);

                objModel = connection.QueryFirstOrDefault<FirstLoginModel>("uspGetUserDetailsByEMAIL", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return objModel;
        }

        public async Task<int> AddUserLoginHistoryAsync(UserLoginHistory userLoginHistory)
        {
            int result;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                using (var command = new System.Data.SqlClient.SqlCommand("InsertUserLoginHistory", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@UserId", userLoginHistory.UserId);
                    command.Parameters.AddWithValue("@LoginTime", userLoginHistory.LoginTime);
                    command.Parameters.AddWithValue("@IpAddress", userLoginHistory.IpAddress ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@UserAgent", userLoginHistory.UserAgent ?? (object)DBNull.Value);

                    result = await command.ExecuteNonQueryAsync();
                }
            }

            return result;
        }

        public async Task InsertUserLoginAuditAsync(LoginRequest loginRequest)
        { 

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                using (var command = new System.Data.SqlClient.SqlCommand("uspInsertUserLoginAudit", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@UserId", loginRequest.UserId);
                    command.Parameters.AddWithValue("@IpAddress", loginRequest.IpAddress ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@UserAgent", loginRequest.UserAgent ?? (object)DBNull.Value); 
                    command.Parameters.AddWithValue("@Success", loginRequest.Success);
                    command.Parameters.AddWithValue("@FailureReason", loginRequest.FailureReason ?? (object)DBNull.Value );
                    command.Parameters.AddWithValue("@WEBTOKEN", loginRequest.Webtoken);
                    if (loginRequest.RefreshToken != null)
                    {
                        command.Parameters.AddWithValue("@RefreshToken", loginRequest.RefreshToken);
                    }

                    await command.ExecuteNonQueryAsync();
                }
            } 
        }

        public async Task InsertUserLogoutAuditAsync(LogoutRequest logoutRequest)
        {

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                await connection.OpenAsync();

                using (var command = new System.Data.SqlClient.SqlCommand("uspInsertUserLogoutAudit", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@UserId", logoutRequest.UserId);
                    command.Parameters.AddWithValue("@IpAddress", logoutRequest.IpAddress ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@UserAgent", logoutRequest.UserAgent ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@WEBTOKEN", logoutRequest.Webtoken);
                    command.Parameters.AddWithValue("@RefreshToken", logoutRequest.RefreshToken);

                    await command.ExecuteNonQueryAsync();
                }
            }
        }
        public string AddRefreshToken(string UserID, DateTime ExpirationDate)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters(); ;
                param.Add("@UserId", UserID);
                param.Add("@ExpirationDate", ExpirationDate);
                result = connection.ExecuteScalar<string>("uspCreateRefreshToken", param, commandType: CommandType.StoredProcedure);
            }

            return result;
        }

        public string GetUserIdFromRefreshToken(string TokenId)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@RefreshId", TokenId);
                result = connection.ExecuteScalar<string>("uspGetRefreshToken", param, commandType: CommandType.StoredProcedure);

            }

            return result;
        }

        public string DataTableToJSONWithJSONNet(DataTable table)
        {
            string JSONString = string.Empty;
            JSONString = JsonConvert.SerializeObject(table);
            return JSONString;
        }

        public string AddOrUpdateThemes(ThemeModel themeModel)
        {
            string result = string.Empty;

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserName", themeModel.UserName);
                param.Add("@Theme", themeModel.Theme);

                result = connection.ExecuteScalar<string>("uspInsertOrUpdateUserTheme", param, commandType: CommandType.StoredProcedure);
            }

            return result;
        }
    }
}
