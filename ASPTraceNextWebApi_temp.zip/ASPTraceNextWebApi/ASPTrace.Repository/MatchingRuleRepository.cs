﻿using Microsoft.Extensions.Configuration; 
using System.Data; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;

namespace ASPTrace.Repository
{
    public class MatchingRuleRepository : IMatchingRule
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public MatchingRuleRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<ChannelMatchingModel> GetChannelMatching(string ClientID)
        {
            List<ChannelMatchingModel> clientMatchingModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                clientMatchingModelsList = connection.Query<ChannelMatchingModel>("spGetChannelModeDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientMatchingModelsList == null)
            {
                clientMatchingModelsList = new List<ChannelMatchingModel>();
            }
            return clientMatchingModelsList;
        }

        public List<ModeMatchingModel> GetModeMatching(string ClientID, string ChannelID)
        {
            List<ModeMatchingModel> clientMatchingModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                clientMatchingModelsList = connection.Query<ModeMatchingModel>("spGetMatchingMode", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientMatchingModelsList == null)
            {
                clientMatchingModelsList = new List<ModeMatchingModel>();
            }
            return clientMatchingModelsList;
        }


        public DataTable GetMatchingRuleSetForClient(string ClientID,string ChannelID, string RuleType)
        {
            DataTable dtRecords = new DataTable();
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spGetMatchingRuleSetForClient", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@ClientID", ClientID);
                    cmd.Parameters.AddWithValue("@ChannelID", ChannelID);
                    cmd.Parameters.AddWithValue("@RuleType", RuleType);

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dtRecords);
                    }
                }
            }
            return dtRecords;
        }


        public int  ChannelModeDetailsField(DataTable dtMatchingRules)
        {
            int i = 0;

            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spAddMatchingRuleConfig", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@BindMatchingRules", dtMatchingRules);

                    con.Open();
                    i = cmd.ExecuteNonQuery();
                }
            }
            return i;
        }


        public int AddMatchingRuleConfig(DataTable dtMatchingRules)
        {
            int i = 0;

            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("uspAddMatchingRuleConfig", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@BindMatchingRules", dtMatchingRules);

                    con.Open();
                    i = cmd.ExecuteNonQuery();
                }
            }
            return i;
        }

        public List<MatchingRuleSetForClient> GetMatchingListByClient(string ClientID)
        {
            List<MatchingRuleSetForClient> clientMatchingModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID); 

                clientMatchingModelsList = connection.Query<MatchingRuleSetForClient>("uspGetMatchingList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientMatchingModelsList == null)
            {
                clientMatchingModelsList = new List<MatchingRuleSetForClient>();
            }
            return clientMatchingModelsList;
        }

        public List<ModeMatchingModel> GetImportConfigModeList(string ClientID, string ChannelID)
        {
            List<ModeMatchingModel> clientMatchingModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID); 

                clientMatchingModelsList = connection.Query<ModeMatchingModel>("uspGetImportConfigMode", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientMatchingModelsList == null)
            {
                clientMatchingModelsList = new List<ModeMatchingModel>();
            }
            return clientMatchingModelsList;
        }


        public List<MatchingColumnTable> GetMatchingColumnTableList(string ClientID, string ChannelID, string ModeID)
        {
            List<MatchingColumnTable> clientMatchingModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);

                clientMatchingModelsList = connection.Query<MatchingColumnTable>("uspGetImportConfigTables", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientMatchingModelsList == null)
            {
                clientMatchingModelsList = new List<MatchingColumnTable>();
            }
            return clientMatchingModelsList;
        }

        public List<MatchingColumns> GetMatchingColumnList(string ClientID, string ChannelID, string ModeID)
        {
            List<MatchingColumns> clientMatchingModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);

                clientMatchingModelsList = connection.Query<MatchingColumns>("uspGetImportConfigTablesColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientMatchingModelsList == null)
            {
                clientMatchingModelsList = new List<MatchingColumns>();
            }
            return clientMatchingModelsList;
        }

        public List<ReconImportConfig> GetImportConfigListByClient(string ClientID)
        {
            List<ReconImportConfig> ReconImportConfigList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                ReconImportConfigList = connection.Query<ReconImportConfig>("uspGetImportConfigList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconImportConfigList == null)
            {
                ReconImportConfigList = new List<ReconImportConfig>();
            }
            return ReconImportConfigList;
        }

        public string DeleteMatchingRuleConfig(DeleteMatchingModel deleteMatchingModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@ClientID", deleteMatchingModel.ClientID);
                param.Add("@ChannelID", deleteMatchingModel.ChannelID);
                param.Add("@ModeID", deleteMatchingModel.ModeID);
                param.Add("@RuleType", deleteMatchingModel.RuleType);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspDeleteMatchingRule", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }

    }
}
