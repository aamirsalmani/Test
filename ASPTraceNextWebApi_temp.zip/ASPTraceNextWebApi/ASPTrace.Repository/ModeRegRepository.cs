﻿using Microsoft.Extensions.Configuration;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;

namespace ASPTrace.Repository
{
    public class ModeRegRepository : IModeReg
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public ModeRegRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<ModeRegModel> GetModeReg()
        {
            List<ModeRegModel> ModeRegList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                ModeRegList = connection.Query<ModeRegModel>("UspGetModeData_Core", null, commandType: System.Data.CommandType.StoredProcedure).AsList();//UspGetModetails_Core_04_April
            }

            if (ModeRegList == null)
            {
                ModeRegList = new List<ModeRegModel>();
            }
            return ModeRegList;
        }

        public string ModeRegAdd(ModeRegAddModel modeRegAddModel)

        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@ModeId", modeRegAddModel.ModeID);
                param.Add("@TransMode", modeRegAddModel.TransactionMode);
                param.Add("@CreatedBy", modeRegAddModel.CreatedBy);
                param.Add("@Mode", modeRegAddModel.Mode);
                connection.Open();

                result = connection.ExecuteScalar<string>("uspModeMaster_core", param, commandType: System.Data.CommandType.StoredProcedure);//spAddMode_05_April
            }

            return result;
        }
        public ModeRegDetcailsModel GetModeDetails(string ModeID)
        {
            ModeRegDetcailsModel modeDetails = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                var param = new DynamicParameters();
                param.Add("@ModeID", ModeID);

                connection.Open();
                List<ModeRegDetcailsModel> ModeList = connection.Query<ModeRegDetcailsModel >("uspGetModeDetailsById_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (ModeList != null && ModeList.Count > 0)
                {
                    modeDetails = ModeList[0];
                }
            }

            if (modeDetails == null)
            {
                modeDetails = new ModeRegDetcailsModel();
            }
            return modeDetails;
        }

        public string ModeRegDelete(ModeRegDeleteModel modeRegDeleteModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", modeRegDeleteModel.Mode);
                param.Add("@ModeID", modeRegDeleteModel.ModeID);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspModeMaster_core", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }
    }
}
