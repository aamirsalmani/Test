﻿using ASPTrace.Contracts;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASPTrace.Repository
{
    public class NotificationRepository : INotifications
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public NotificationRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public async Task<List<dynamic>> GetNotificationListAsync()
        {
            List<dynamic> userList;

            await using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var result = await connection.QueryAsync<dynamic>("GetNotificationsKData", commandType: CommandType.StoredProcedure);
                userList = result.AsList();
            }

            return userList ?? new List<dynamic>();
        }

        public async Task<string> SetNotificationAsReadAsync(string notificationId, string notificationType)
        {
            try
            {
                await using var connection = new SqlConnection(_connectionString);
                await connection.OpenAsync();

                var param = new DynamicParameters();
                param.Add("@ID", notificationId);
                param.Add("@Type", notificationType);

                var result = await connection.ExecuteScalarAsync<string>("MarkNotificationKS", param, commandType: CommandType.StoredProcedure);

                return result ?? "Error";
            }
            catch (Exception)
            {
                // Optional: log the exception here
                return "Error";
            }
        }

    }

}
