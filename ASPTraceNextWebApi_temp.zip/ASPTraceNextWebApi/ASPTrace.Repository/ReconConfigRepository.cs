﻿using Microsoft.Extensions.Configuration; 
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper; 
using System.Data.OleDb; 
using Excel = Microsoft.Office.Interop.Excel;

namespace ASPTrace.Repository
{
    public class ReconConfigRepository : IReconConfig
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public ReconConfigRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_configuration.GetConnectionString("TraceConnection"));
        }


        public string SubmitReconConfig(ReconImportConfigModel table )
        {
            string MSG = string.Empty;
            try
            {
                DataTable dtRecords = new DataTable();

                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spSubmitReconConfigKS", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ClientID", table.ClientID);
                        cmd.Parameters.AddWithValue("@ChannelID", table.ChannelID);
                        cmd.Parameters.AddWithValue("@ModeID", table.ModeID);
                        cmd.Parameters.AddWithValue("@ReconType", table.ReconType);
                        cmd.Parameters.AddWithValue("@TableNo", table.Table.TableNo);
                        cmd.Parameters.AddWithValue("@TableName", table.Table.TableName); 
                        cmd.Parameters.AddWithValue("@CreatedBy", table.UserName);

                        using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dtRecords);
                        }
                    }
                }

                return "Successful";
            }
            catch (Exception ex)
            {
                return ex.Message;

            }

        }

        public string RawFileUploadQuery(int ClientID, int ChannelID, int ModeID, int VendorID,int ReconType, string RawQuery, string UserName)
        {
            string MSG = string.Empty;
            try
            {
                DataTable dtRecords = new DataTable();
                string table = string.Empty;

                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spRawFileUploadQueryKS", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ClientID", ClientID);
                        cmd.Parameters.AddWithValue("@ChannelID", ChannelID);
                        cmd.Parameters.AddWithValue("@ModeID", ModeID);
                        cmd.Parameters.AddWithValue("@VendorID", VendorID);
                        cmd.Parameters.AddWithValue("@ReconType", ReconType);
                        cmd.Parameters.AddWithValue("@RawQuery", RawQuery);
                        cmd.Parameters.AddWithValue("@CreatedBy", UserName);


                        using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dtRecords);
                        }
                    }
                }

                return "Successful";
            }
            catch (Exception ex)
            {
                return ex.Message;

            }

        }
        public string DateFormatArray(int ClientID, int ChannelID, int ModeID, int VendorID, DataTable DateFormats)
        {
            string MSG = string.Empty;
            try
            {
                DataTable dtRecords = new DataTable();
                string table = string.Empty;

                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spBulkInsertDateFormatKS", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ClientID", ClientID);
                        cmd.Parameters.AddWithValue("@ChannelID", ChannelID);
                        cmd.Parameters.AddWithValue("@ModeID", ModeID);
                        cmd.Parameters.AddWithValue("@VendorID", VendorID);
                        cmd.Parameters.AddWithValue("@DateFormats", DateFormats);


                        using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dtRecords);
                        }
                    }
                }

                return "Successful";
            }
            catch (Exception ex)
            {
                return ex.Message;

            }

        }
        public string XMLConfig(int ClientID, int ChannelID, int ModeID, int VendorID, string XML, string FileData)
        {
            string MSG = string.Empty;
            try
            {
                DataTable dtRecords = new DataTable();
                string table = string.Empty;

                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spFileConfigKS", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ClientID", ClientID);
                        cmd.Parameters.AddWithValue("@ChannelID", ChannelID);
                        cmd.Parameters.AddWithValue("@ModeID", ModeID);
                        cmd.Parameters.AddWithValue("@VendorID", VendorID);
                        cmd.Parameters.AddWithValue("@XML", XML);
                        cmd.Parameters.AddWithValue("@FileData", FileData);


                        using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dtRecords);
                        }
                    }
                }

                return "Successful";
            }
            catch (Exception ex)
            {
                return ex.Message;

            }

        }

        public List<ReconTypeModel> GetReconType()
        {
            List<ReconTypeModel> ReconType = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                ReconType = connection.Query<ReconTypeModel>("spReconType", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconType == null)
            {
                ReconType = new List<ReconTypeModel>();
            }
            return ReconType;

        }

        public string ConvertNPCIExcel(string OldFilepath, string OldFileName)
        {
            string NewFileName = "";
            try
            {
                //objLogWriter.FunErrorLog(OldFilepath, objLoginEntity._ClientCode, "ImportFile.aspx", "ConvertNPCIExcel", 0, "ImportFile.aspx", objLoginEntity._UserName, 'E');
                NewFileName = OldFilepath.Replace(OldFileName, "");
                string extension = Path.GetExtension(OldFileName);
                NewFileName = NewFileName + OldFileName.Replace(extension, "") + "_New" + extension;

                string xmlPathName = OldFilepath;

                //NewFileName = @"D:\Rupali\SVN_Live\Ankita\sachinSir\files\NTSLSMU020919_1C_backup.xls";
                Excel.Application activeExcel = new Excel.Application();
                Excel.Workbook openWorkBook;
                openWorkBook = activeExcel.Workbooks.Open(xmlPathName);
                openWorkBook.SaveAs(NewFileName, Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing,
            false, false, Excel.XlSaveAsAccessMode.xlNoChange,
            Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                openWorkBook.Close();
                //objLogWriter.FunErrorLog(NewFileName, objLoginEntity._ClientCode, "INewFileName", "ConvertNPCIExcel", 0, "ImportFile.aspx", objLoginEntity._UserName, 'E');
            }
            catch
            {
                //LogWriter objLogWriter = new LogWriter();
                //  objLogWriter.FunErrorLog(ex.Message.ToString(), objLoginEntity._ClientCode, "ImportFile.aspx", "ConvertNPCIExcel", 0, "ImportFile.aspx", objLoginEntity._UserName, 'E');
                NewFileName = OldFileName;
            }

            return NewFileName;
        }



        public DataTable ExcelTable(string path)
        {
            DataTable dataTable = new DataTable();
            DataTable dt = new DataTable();
            int TotalCount = 0;

            String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
            OleDbConnection objConn;
            string extension = Path.GetExtension(path);
            DataTable dtexcelsheetname = null;

            switch (extension.ToLower())
            {

                case ".xls": 
                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1\'";
                    break;
                case ".xlsx": //Excel 07 or higher
                    connString = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = " + path + "; Extended Properties =\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                    break;
            }


            try
            {
                objConn = new OleDbConnection(connString);
                objConn.Open();
            }
            catch (Exception ex)
            {
                path = ConvertNPCIExcel(path, path);

                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                        break;
                }
                objConn = new OleDbConnection(connString);
                objConn.Open();
            }

            //OleDbConnection objConn = new OleDbConnection(connString);
            //objConn.Open();
            dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
            int j = 0;
            foreach (DataRow row in dtexcelsheetname.Rows)
            {
                DataTable dtSheet = new DataTable();
                excelSheets[j] = row["TABLE_NAME"].ToString();
                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                try
                {
                    OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);

                    da.Fill(dtSheet);

                    objConn.Close();
                }
                catch (Exception ex)
                {
                    objConn.Close();
                }

                TotalCount = dtSheet.Rows.Count;

                if (dtSheet.Rows.Count >= 1)
                {
                    dataTable = dtSheet;

                    for (int i = dataTable.Rows.Count - 1; i >= 4; i--)
                    {
                        dataTable.Rows.RemoveAt(i);
                    }

                    List<DataRow> nonDigitRows = new List<DataRow>();
                    for (int i = dataTable.Rows.Count - 1; i >= 0; i--)
                    {
                        string concatenatedString = string.Join("", dataTable.Rows[i].ItemArray);


                        bool containsDigit = concatenatedString.Any(char.IsDigit);

                        if (!containsDigit)
                        {
                            DataRow headerRow = dataTable.Rows[i];

                            // Rename the columns in the DataTable based on the values in the header row
                            for (int columnIndex = 0; columnIndex < dataTable.Columns.Count; columnIndex++)
                            {
                                dataTable.Columns[columnIndex].ColumnName = headerRow[columnIndex].ToString();
                            }

                            // Remove the header row from the DataTable (optional)
                            dataTable.Rows.Remove(headerRow);

                            for (int NonHeader = i; NonHeader >= 0; NonHeader--)
                            {
                                dataTable.Rows.RemoveAt(NonHeader);
                            }
                            break;
                        }
                    }


                }

                File.Delete(path);

                break;
            }



            //using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            //{
            //    connection.Open();

            //    // Generate the SQL CREATE TABLE statement
            //    string createTableQuery = GenerateCreateTableQuery(dataTable);

            //    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(createTableQuery, connection))
            //    {
            //        cmd.ExecuteNonQuery();
            //    }
            //}



            return dataTable;
        }

        public DataTable txtTableWithoutSeperator(string path)
        {
            DataTable dataTable = new DataTable();
            DataColumn column = new DataColumn("Data", typeof(string));
            dataTable.Columns.Add(column);
            int LineNo = 0;

            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    //string line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                    bool containsDigit = line.Any(char.IsDigit);

                    
                    
                    if (LineNo > 2)
                    {
                        break;
                    }

                    //if (!containsDigit)
                    //{

                    //}
                    //else
                    {
                        dataTable.Rows.Add(line);
                    }

                }
                catch (Exception ex)
                {


                }
            }

            return dataTable;
        }

        public DataTable txtTableWithSeperator(string path, string Seperator)
        {
            DataTable dataTable = new DataTable();
            int LineNo = 0;

            string sep = Seperator == "" ? " ":Seperator;//" ", ",", "|"
            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    string line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty).Trim();

                    bool lastRemoved = line1.Substring(line1.LastIndexOf(','), line1.Length - line1.LastIndexOf(',') ).Length < 2 ;
                    if (lastRemoved)
                    {
                        line1 = line1.Substring(0, line1.LastIndexOf(','));
                    }

                    string[] lineArr = line1.Split(new[] { sep }, StringSplitOptions.None);

                    bool containsDigit = line1.Any(char.IsDigit);

                    if (!containsDigit)
                    {
                        foreach (string columnName in lineArr)
                        {
                            DataColumn column = new DataColumn(columnName, typeof(string));
                            dataTable.Columns.Add(column);
                        }

                    }
                    else
                    {
                        if (dataTable.Columns.Count == 0 && lineArr.Length>2)
                        {
                            int count = 0;
                            foreach (string columnName in lineArr)
                            {
                                count++;
                                DataColumn column = new DataColumn("Column"+count.ToString(), typeof(string));
                                dataTable.Columns.Add(column);
                            }

                        }
                        DataRow row = dataTable.NewRow();
                        // Assign values from lineArr to the DataRow
                        for (int i = 0; i < lineArr.Length; i++)
                        {
                            row[i] = lineArr[i];
                        }

                        dataTable.Rows.Add(row);
                        if (LineNo > 5)
                        {
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {


                }
            }

            return dataTable;
        }


        private static string GenerateCreateTableQuery(DataTable dataTable)
        {
            string tableName = "SampleTable"; // Replace with your desired table name
            string createTableQuery = $"CREATE TABLE {tableName} (";

            foreach (DataColumn column in dataTable.Columns)
            {
                createTableQuery += $"{column.ColumnName} {GetSqlDataType(column.DataType)}, ";
            }

            createTableQuery = createTableQuery.TrimEnd(',', ' ') + ")";

            return createTableQuery;
        }

        // Map .NET data types to SQL data types
        private static string GetSqlDataType(Type dataType)
        {
            if (dataType == typeof(string))
                return "NVARCHAR(MAX)";
            else if (dataType == typeof(int))
                return "INT";
            // Add more data type mappings as needed

            throw new Exception($"Unsupported data type: {dataType.Name}");
        }


        public DataTable GenerateRecon(ReconQueryFields reconQueryFields)
        {


            DataTable dtRecords = new DataTable();
            string table = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spTempDataKS", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ClientID", reconQueryFields.ClientID);
                    cmd.Parameters.AddWithValue("@ChannelID", reconQueryFields.ChannelID);
                    cmd.Parameters.AddWithValue("@Mode", reconQueryFields.ModeID);
                    cmd.Parameters.AddWithValue("@ReconType", reconQueryFields.ReconType);


                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dtRecords);
                    }
                }
            }



            return dtRecords;

        }


        public DataSet tblStatusConditions(List<StatusConditionsModel> tblStatusConditions)
        {
            //DataTable dtRecords = new DataTable();
            DataSet dtRecords = new DataSet();

            DataTable table = new DataTable();
            table.Columns.Add("ClientID", typeof(string));
            table.Columns.Add("ChannelID", typeof(string));
            table.Columns.Add("ModeID", typeof(string));
            table.Columns.Add("ReconType", typeof(string));
            table.Columns.Add("TableNo", typeof(string));
            table.Columns.Add("TableName", typeof(string));
            table.Columns.Add("status", typeof(string));
            table.Columns.Add("statusCondition", typeof(string));
            table.Columns.Add("isClear", typeof(bool));


            DataTable Dtable = new DataTable();
            Dtable.Columns.Add("ClientID", typeof(string));
            Dtable.Columns.Add("ChannelID", typeof(string));
            Dtable.Columns.Add("ModeID", typeof(string));
            Dtable.Columns.Add("ReconType", typeof(string));
            Dtable.Columns.Add("TableNo", typeof(string));
            Dtable.Columns.Add("TableName", typeof(string));
            Dtable.Columns.Add("ColumnID", typeof(string));
            Dtable.Columns.Add("AliasColumn", typeof(string));
            Dtable.Columns.Add("ColumnValue", typeof(string));
            Dtable.Columns.Add("Reversal", typeof(string));
            Dtable.Columns.Add("ReversalCode", typeof(string));

            string ClientID = string.Empty;
            string ChannelID = string.Empty;
            string ModeID = string.Empty;
            string ReconType = string.Empty;

            try
            {

                foreach (var a in tblStatusConditions)
                {
                    ClientID = a.ClientID;
                    ChannelID = a.ChannelID;
                    ModeID = a.ModeID;
                    ReconType = a.ReconType;
                    TableStruct Table = a.table;
                    int TableNo = Table.TableNo;
                    string TableName = Table.TableName;

                    string status = a.status;
                    string statusCondition = a.statusCondition;
                    bool isClear = a.isClear;

                    table.Rows.Add(ClientID, ChannelID, ModeID, ReconType, TableNo, TableName, status, statusCondition, isClear);
                }



                var distinctTableNames = table.AsEnumerable()
                    .Select(row => row.Field<string>("tableName"))
                    .Distinct();

                foreach (var Table in distinctTableNames)
                {
                    string status = string.Empty;
                    string caseCondition = "case ";
                    string TableNo = string.Empty;
                    for (int k = 0; k < table.Rows.Count; k++)
                    {

                        string TableName = table.Rows[k]["TableName"].ToString();
                        string condition = table.Rows[k]["statusCondition"].ToString();
                        status = table.Rows[k]["status"].ToString();
                        if (TableName == Table)
                        {
                            //caseCondition += " when " + condition + " then " + status;
                            caseCondition = condition;
                            TableNo = table.Rows[k]["TableNo"].ToString();
                        }


                    }
                    caseCondition += " end ";
                    Dtable.Rows.Add(ClientID, ChannelID, ModeID, ReconType, TableNo, Table, 0, "Status", caseCondition, 0, "");
                }


                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spBulkColumnInsertKS", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@RawData", Dtable);


                        using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dtRecords);
                        }
                    }
                    return dtRecords;

                }
            }
            catch (Exception ex)
            {

                return null;
            }
        }
        public DataSet AddRawTableFields(List<ReconRawTableFields> RawData)
        {
            //DataTable dtRecords = new DataTable();
            DataSet dtRecords = new DataSet();

            DataTable table = new DataTable();
            table.Columns.Add("ClientID", typeof(string));
            table.Columns.Add("ChannelID", typeof(string));
            table.Columns.Add("ModeID", typeof(string));
            table.Columns.Add("ReconType", typeof(string));
            table.Columns.Add("TableNo", typeof(string));
            table.Columns.Add("TableName", typeof(string));
            table.Columns.Add("ColumnID", typeof(string));
            table.Columns.Add("AliasColumn", typeof(string));
            table.Columns.Add("ColumnValue", typeof(string));
            table.Columns.Add("Reversal", typeof(string));
            table.Columns.Add("ReversalCode", typeof(string));
            try
            {

                foreach (var a in RawData)
                {
                    string ClientID = a.ClientID;
                    string ChannelID = a.ChannelID;
                    string ModeID = a.ModeID;
                    string ReconType = a.ReconType;
                    string TableNo = a.TableNo;
                    string TableName = a.TableName;
                    string ColumnID = a.ColumnID;
                    string AliasColumn = a.AliasColumn;
                    string ColumnValue = a.ColumnValue;
                    string Reversal = a.Reversal;
                    string ReversalCode = a.ReversalCode;





                    table.Rows.Add(ClientID, ChannelID, ModeID, ReconType, TableNo, TableName, ColumnID, AliasColumn, ColumnValue, Reversal, ReversalCode);
                }



                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spBulkColumnInsertKS", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@RawData", table);


                        using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dtRecords);
                        }
                    }
                    return dtRecords;
                }
            }
            catch (Exception ex)
            {
                return null;

            }
        }
        public List<ReconTablesModel> GetReconTables(int ChannelID,int ModeID)
        {
            List<ReconTablesModel> ReconType = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);

                ReconType = connection.Query<ReconTablesModel>("spGetTables"
                    ,param
                    ,commandType: System.Data.CommandType.StoredProcedure
                    ).AsList();
            }

            if (ReconType == null)
            {
                ReconType = new List<ReconTablesModel>();
            }
            return ReconType;

        }
        public List<MasterValues> GetDateFormats()
        {
            List<MasterValues> DateFormats = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                DateFormats = connection.Query<MasterValues>("spGetDateFormats", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (DateFormats == null)
            {
                DateFormats = new List<MasterValues>();
            }
            return DateFormats;

        }
        public List<MasterValues> GetOperations()
        {
            List<MasterValues> Operations = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                Operations = connection.Query<MasterValues>("spGetOperations", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (Operations == null)
            {
                Operations = new List<MasterValues>();
            }
            return Operations;

        }
        public List<MasterValues> GetParameters()
        {
            List<MasterValues> Operations = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                Operations = connection.Query<MasterValues>("spGetParameters", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (Operations == null)
            {
                Operations = new List<MasterValues>();
            }
            return Operations;

        }

        public List<ReconColumnsModel> GetReconColumns(string Tablename)
        {
            List<ReconColumnsModel> ReconColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@Tablename", Tablename);

                ReconColumns = connection.Query<ReconColumnsModel>("spGetColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconColumns == null)
            {
                ReconColumns = new List<ReconColumnsModel>();
            }
            return ReconColumns;

        }
        public List<ReconAliasColumnsModel> GetReconAliasColumns(int ChannelID, int ModeID, int VendorType,int Type)
        {
            List<ReconAliasColumnsModel> ReconColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@VendorType", VendorType);
                param.Add("@TYPE", Type);

                ReconColumns = connection.Query<ReconAliasColumnsModel>("spGetAliasColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconColumns == null)
            {
                ReconColumns = new List<ReconAliasColumnsModel>();
            }
            return ReconColumns;

        }

        public DataTable GetChannelModeDetailsField(string ClientID)
        {
            DataTable dtRecords = new DataTable();
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spGetChannelModeDetails", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@ClientID", SqlDbType.BigInt).Value = ClientID;

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dtRecords);
                    }
                }
            }
            return dtRecords;
        }


        public DataTable AddFieldConfig(AddFieldConfigModel addFieldConfigModel)
        {
            DataTable dtRecords = new DataTable();
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("spAddFieldConfig", connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@ClientID", addFieldConfigModel.ClientID);
                    cmd.Parameters.AddWithValue("@VendorID", addFieldConfigModel.VendorID);
                    cmd.Parameters.AddWithValue("@ChannelID", addFieldConfigModel.ChannelID);
                    cmd.Parameters.AddWithValue("@ModeID", addFieldConfigModel.ModeID);
                    cmd.Parameters.AddWithValue("@FormatID", addFieldConfigModel.FormatID);
                    cmd.Parameters.AddWithValue("@TerminalCode", addFieldConfigModel.TerminalCode);
                    cmd.Parameters.AddWithValue("@BinNo", addFieldConfigModel.BinNo);
                    cmd.Parameters.AddWithValue("@AcquirerID", addFieldConfigModel.AcquirerID);
                    cmd.Parameters.AddWithValue("@RevCode1", addFieldConfigModel.RevCode1);
                    cmd.Parameters.AddWithValue("@RevCode2", addFieldConfigModel.RevCode2);
                    cmd.Parameters.AddWithValue("@RevType", addFieldConfigModel.RevType);
                    cmd.Parameters.AddWithValue("@RevEntry", addFieldConfigModel.RevEntry);
                    cmd.Parameters.AddWithValue("@TxnDateTime", addFieldConfigModel.TxnDateTime);
                    cmd.Parameters.AddWithValue("@TxnValueDateTime", addFieldConfigModel.TxnValueDateTime);
                    cmd.Parameters.AddWithValue("@TxnPostDateTime", addFieldConfigModel.TxnPostDateTime);
                    cmd.Parameters.AddWithValue("@ATMType", addFieldConfigModel.ATMType);
                    cmd.Parameters.AddWithValue("@POSType", addFieldConfigModel.POSType);
                    cmd.Parameters.AddWithValue("@ECOMType", addFieldConfigModel.ECOMType);
                    cmd.Parameters.AddWithValue("@IMPSType", addFieldConfigModel.IMPSType);
                    cmd.Parameters.AddWithValue("@UPIType", addFieldConfigModel.UPIType);
                    cmd.Parameters.AddWithValue("@MicroATMType", addFieldConfigModel.MicroATMType);
                    cmd.Parameters.AddWithValue("@MobileRechargeType", addFieldConfigModel.MobileRechargeType);
                    cmd.Parameters.AddWithValue("@Deposit", addFieldConfigModel.Deposit);
                    cmd.Parameters.AddWithValue("@BalEnq", addFieldConfigModel.BalEnq);
                    cmd.Parameters.AddWithValue("@MiniStatement", addFieldConfigModel.MiniStatement);
                    cmd.Parameters.AddWithValue("@PinChange", addFieldConfigModel.PinChange);
                    cmd.Parameters.AddWithValue("@ChequeBookReq", addFieldConfigModel.ChequeBookReq);
                    cmd.Parameters.AddWithValue("@RespCode1", addFieldConfigModel.RespCode1);
                    cmd.Parameters.AddWithValue("@RespCode2", addFieldConfigModel.RespCode2);
                    cmd.Parameters.AddWithValue("@RespTpe", addFieldConfigModel.RespTpe);
                    cmd.Parameters.AddWithValue("@EODCode", addFieldConfigModel.EODCode);
                    cmd.Parameters.AddWithValue("@OfflineCode", addFieldConfigModel.OfflineCode);
                    cmd.Parameters.AddWithValue("@DebitCode", addFieldConfigModel.DebitCode);
                    cmd.Parameters.AddWithValue("@CreditCode", addFieldConfigModel.CreditCode);
                    cmd.Parameters.AddWithValue("@CreatedBy", addFieldConfigModel.CreatedBy);
                    if (addFieldConfigModel.TxnAmountIsDecimal == "True")
                    {
                        cmd.Parameters.AddWithValue("@TxnAmountIsDecimal", "0");
                    }
                    else if (addFieldConfigModel.TxnAmountIsDecimal == "False")
                    {
                        cmd.Parameters.AddWithValue("@TxnAmountIsDecimal", "1");
                    }
                    else if (addFieldConfigModel.TxnAmountIsDecimal == "--Select--")
                    {
                        cmd.Parameters.AddWithValue("@TxnAmountIsDecimal", " ");
                    }

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dtRecords);
                    }
                }
                return dtRecords;
            }
        }

        public List<CaseOutputModel> CaseOutputList(string ClientID)
        {
            List<CaseOutputModel> CaseOutputList = null;
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    param.Add("@ClientID", ClientID);

                    CaseOutputList = connection.Query<CaseOutputModel>("GetCaseOutputList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                }

                if (CaseOutputList == null)
                {
                    CaseOutputList = new List<CaseOutputModel>();
                }
            }
            catch(Exception ex)
            {

            }
            return CaseOutputList;
        }
        public List<VendorFieldModel> GetPreset(int ClientID, int ChannelID, int ModeID)
        {
            List<VendorFieldModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ClientID);
                param.Add("@ModeID", ClientID);

                clientFieldModelsList = connection.Query<VendorFieldModel>("spGetPresetKS", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<VendorFieldModel>();
            }
            return clientFieldModelsList;
        }
        public List<VendorFieldModel> GetVendorFields(string ClientID)
        {
            List<VendorFieldModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                clientFieldModelsList = connection.Query<VendorFieldModel>("UspGetFileVendorDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<VendorFieldModel>();
            }
            return clientFieldModelsList;
        }

        public List<ChannelFieldModel> GetChannelFields(string ClientID)
        {
            List<ChannelFieldModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                clientFieldModelsList = connection.Query<ChannelFieldModel>("UspGetChannelDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<ChannelFieldModel>();
            }
            return clientFieldModelsList;
        }

        public List<ModeFieldModel> GetModeFields(string ClientID, int ChannelID)
        {
            List<ModeFieldModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                clientFieldModelsList = connection.Query<ModeFieldModel>("spGetModeDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<ModeFieldModel>();
            }
            return clientFieldModelsList;
        }

        public List<FormatIdFieldModel> GetFormatIdFields(string ClientID, string VendorID, int ChannelID, string ModeID)
        {
            List<FormatIdFieldModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@VendorID", VendorID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);

                clientFieldModelsList = connection.Query<FormatIdFieldModel>("spGetFormatID", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<FormatIdFieldModel>();
            }
            return clientFieldModelsList;
        }

        public List<FieldIdentificationDetailsModel> GetFieldIdentificationDetails(string ClientID, string VendorID, int ChannelID, string ModeID, string FormatID)
        {
            List<FieldIdentificationDetailsModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@VendorID", VendorID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@FormatID", FormatID);

                clientFieldModelsList = connection.Query<FieldIdentificationDetailsModel>("spGetFieldIdentificationDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<FieldIdentificationDetailsModel>();
            }
            return clientFieldModelsList;
        }


        public List<FieldIdentificationVendorDetailsModel> GetFieldIdentificationVendorDetails(string VendorID, int ChannelID)
        {
            List<FieldIdentificationVendorDetailsModel> clientFieldModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@VendorID", VendorID);
                param.Add("@ChannelID", ChannelID);

                clientFieldModelsList = connection.Query<FieldIdentificationVendorDetailsModel>("spFieldIdentificationVendorDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientFieldModelsList == null)
            {
                clientFieldModelsList = new List<FieldIdentificationVendorDetailsModel>();
            }
            return clientFieldModelsList;
        }

        public List<ReconTablesModel> GetReconTableList(int ChannelID, int ModeID)
        {
            List<ReconTablesModel> ReconTables = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);

                ReconTables = connection.Query<ReconTablesModel>("uspGetReconTables", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconTables == null)
            {
                ReconTables = new List<ReconTablesModel>();
            }
            return ReconTables;

        }

        public List<ChannelOptionModel> GetChannelOptions(string ClientID)
        {
            List<ChannelOptionModel> clientOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                clientOptionModelsList = connection.Query<ChannelOptionModel>("uspGetChannelForRecon", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientOptionModelsList == null)
            {
                clientOptionModelsList = new List<ChannelOptionModel>();
            }
            return clientOptionModelsList;
        }

        public List<ModeOptionModel> GetModeOptions(string ClientID, string ChannelID)
        {
            List<ModeOptionModel> clientOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                clientOptionModelsList = connection.Query<ModeOptionModel>("uspGetModeForRecon", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientOptionModelsList == null)
            {
                clientOptionModelsList = new List<ModeOptionModel>();
            }
            return clientOptionModelsList;
        }

        public string AddUpdateReconImportConfig(ReconConfigModel reconConfigModel, ReconConfigTableModel reconConfigTableModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", reconConfigModel.ClientID);
                param.Add("@ChannelID", reconConfigModel.ChannelID);
                param.Add("@ModeID", reconConfigModel.ModeID);
                param.Add("@ReconType", reconConfigModel.ReconType);
                param.Add("@Table1", reconConfigTableModel.Table1);
                param.Add("@Table2", reconConfigTableModel.Table2);
                param.Add("@Table3", reconConfigTableModel.Table3);
                param.Add("@Table4", reconConfigTableModel.Table4); 
                param.Add("@CreatedBy", reconConfigModel.UserName);
                result = connection.ExecuteScalar<string>("uspAddUpdateReconConfig", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public List<DynamicReconConfig> GetReconConfigGrid(string ClientID, string ChannelID, string ModeID, string ReconType)
        {
            List<DynamicReconConfig> clientOptionModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@ReconType", ReconType);

                clientOptionModelsList = connection.Query<DynamicReconConfig>("uspDynamicReconConfigGrid", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (clientOptionModelsList == null)
            {
                clientOptionModelsList = new List<DynamicReconConfig>();
            }
            return clientOptionModelsList;
        }

        public string GetSelectedTables(string ClientID, string ChannelID, string ModeID, string ReconType)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);
                param.Add("@ModeID", ModeID);
                param.Add("@ReconType", ReconType); 
                result = connection.ExecuteScalar<string>("uspGetSelectedReconTables", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public string AddUpdateReconFileConfig(DynamicImportFileModel reconConfigModel, string FileName, string FilePath , string OriginalFileName)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", reconConfigModel.ClientID);
                param.Add("@ConfigID", reconConfigModel.ConfigID);
                param.Add("@VendorID", reconConfigModel.VendorID);
                param.Add("@TableName", reconConfigModel.TableName);
                param.Add("@FileName", FileName);
                param.Add("@FilePath", FilePath);
                param.Add("@OriginalFileName", OriginalFileName); 
                param.Add("@CreatedBy", reconConfigModel.UserName);
                result = connection.ExecuteScalar<string>("uspAddUpdateDynamicReconFileConfig", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public DynamicImportFileConfigModel GetDynamicImportFileConfig(string FileConfigID)
        {
            DynamicImportFileConfigModel dynamicImportFileConfigModel = null; 
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                List<DynamicImportFileConfigModel> FileConfigList = connection.Query<DynamicImportFileConfigModel>("uspGetDynamicReconFileConfig", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (FileConfigList != null && FileConfigList.Count > 0)
                {
                    dynamicImportFileConfigModel = FileConfigList[0];
                }
            }

            if (dynamicImportFileConfigModel == null)
            {
                dynamicImportFileConfigModel = new DynamicImportFileConfigModel();
            }

            return dynamicImportFileConfigModel;
        }

        public List<ReconAliasColumnsModel> GetXMLSchemaColumn(string FileConfigID)
        {
            List<ReconAliasColumnsModel> ReconColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                ReconColumns = connection.Query<ReconAliasColumnsModel>("uspGetXMLSchemaColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconColumns == null)
            {
                ReconColumns = new List<ReconAliasColumnsModel>();
            }
            return ReconColumns;

        }

        public string GetConfiguredColumnString(string FileConfigID)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID); 
                result = connection.ExecuteScalar<string>("uspGetConfiguredXMLColumnString", param, commandType: System.Data.CommandType.StoredProcedure);
            } 
            return result;
        }

        public string GetConfiguredRawColumnString(string FileConfigID)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);
                result = connection.ExecuteScalar<string>("uspGetConfiguredRawColumnString", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }

        public string UpdateMappedColumnString(DynamicFileMappedColumn reconConfigModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", reconConfigModel.FileConfigID); 
                param.Add("@MappedColumnString", reconConfigModel.MappedColumnString); 
                result = connection.ExecuteScalar<string>("uspUpdateMappedColumnString", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public ConfiguredColumnJsonString GetConfiguredColumnJsonString(string FileConfigID)
        {
            ConfiguredColumnJsonString configuredColumnJsonString = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                List<ConfiguredColumnJsonString> FileConfigList = connection.Query<ConfiguredColumnJsonString>("uspGetConfiguredColumnJsonString", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (FileConfigList != null && FileConfigList.Count > 0)
                {
                    configuredColumnJsonString = FileConfigList[0];
                }
            }

            if (configuredColumnJsonString == null)
            {
                configuredColumnJsonString = new ConfiguredColumnJsonString();
            }

            return configuredColumnJsonString;
        }

        public DynamicFileConfigDataModel GetDynamicReconFileConfigData(string FileConfigID)
        {
            DynamicFileConfigDataModel dynamicImportFileConfigModel = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                List<DynamicFileConfigDataModel> FileConfigList = connection.Query<DynamicFileConfigDataModel>("uspGetReconFileConfigData", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (FileConfigList != null && FileConfigList.Count > 0)
                {
                    dynamicImportFileConfigModel = FileConfigList[0];
                }
            }

            if (dynamicImportFileConfigModel == null)
            {
                dynamicImportFileConfigModel = new DynamicFileConfigDataModel();
            }

            return dynamicImportFileConfigModel;
        }

        public List<ReconAliasColumnsModel> GetRawTableSelectedColumns(string FileConfigID)
        {
            List<ReconAliasColumnsModel> ReconColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                ReconColumns = connection.Query<ReconAliasColumnsModel>("uspGetRawTableSelectedColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconColumns == null)
            {
                ReconColumns = new List<ReconAliasColumnsModel>();
            }
            return ReconColumns;

        }

        public List<RawTableColumn> GetRawTableAllColumns(string FileConfigID)
        {
            List<RawTableColumn> ReconColumns = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);

                ReconColumns = connection.Query<RawTableColumn>("uspGetRawTableColumns", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReconColumns == null)
            {
                ReconColumns = new List<RawTableColumn>();
            }
            return ReconColumns;

        }

        public string UpdateQueryXMLString(DynamicFileXMLModel reconConfigModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", reconConfigModel.FileConfigID);
                param.Add("@XMLString", reconConfigModel.XMLString);
                param.Add("@QueryString", reconConfigModel.QueryString);
                param.Add("@RawColumnString", reconConfigModel.RawColumnString);
                param.Add("@MappedColumnString", reconConfigModel.MappedColumnString);
                result = connection.ExecuteScalar<string>("uspUpdateQueryandXML", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public DateTimeFormat GetDateTimeFormat(string FileConfigID, string TableName)
        {
            DateTimeFormat configuredColumnJsonString = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", FileConfigID);
                param.Add("@TableName", TableName);

                List<DateTimeFormat> FormatList = connection.Query<DateTimeFormat>("uspGetDateTimeFormatString", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (FormatList != null && FormatList.Count > 0)
                {
                    configuredColumnJsonString = FormatList[0];
                }
            }

            if (configuredColumnJsonString == null)
            {
                configuredColumnJsonString = new DateTimeFormat();
            }

            return configuredColumnJsonString;
        }

        public string UpdateDateTimeFormat(DateTimeFormat dateTimeFormat)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FileConfigID", dateTimeFormat.FileConfigID);
                param.Add("@TableName", dateTimeFormat.TableName);
                param.Add("@TxnDateTimeDateFormat", dateTimeFormat.TxnDateTimeDateFormat);
                param.Add("@TxnValueDateTimeDateFormat", dateTimeFormat.TxnValueDateTimeDateFormat);
                param.Add("@TxnPostDateTimeDateFormat", dateTimeFormat.TxnPostDateTimeDateFormat);
                param.Add("@FileDateFormat", dateTimeFormat.FileDateFormat);
                result = connection.ExecuteScalar<string>("uspUpdateDateTimeFormatFileConfig", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }
    }
}
