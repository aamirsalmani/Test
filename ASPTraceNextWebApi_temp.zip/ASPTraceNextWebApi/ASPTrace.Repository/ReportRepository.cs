﻿ 
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;
using Microsoft.Extensions.Configuration; 
using Microsoft.Office.Interop.Excel;
using Newtonsoft.Json;
using System.Data; 
using System.Data;
using System.Data.SqlClient;

namespace ASPTrace.Repository
{
    public class ReportRepository : IReport
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public ReportRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }


        //Unmatched Report
        public PaginatedResult GetUnmatchedTxnsReport(DailyReportInputReportModel unmatchedTxnsModel, int pageNumber, int pageSize)
        {
            List<dynamic> unmatchedTxnsReportList;
            int totalRecords;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", unmatchedTxnsModel.ClientID);
                param.Add("@ChannelID", unmatchedTxnsModel.ChannelID);
                param.Add("@ModeID", unmatchedTxnsModel.ModeID);
                param.Add("@TERMINALID", unmatchedTxnsModel.TerminalID);
                param.Add("@FromDateTxns", unmatchedTxnsModel.FromDate);
                param.Add("@ToDateTxns", unmatchedTxnsModel.ToDate);
                param.Add("@TxnType", unmatchedTxnsModel.TxnType);
                param.Add("@PageNumber", pageNumber);  // New pagination parameter
                param.Add("@PageSize", pageSize);      // New pagination parameter
                param.Add("@search", unmatchedTxnsModel.search);
                param.Add("@TotalRecords", dbType: DbType.Int32, direction: ParameterDirection.Output);  // Output param for total record count

                unmatchedTxnsReportList = connection.Query<dynamic>("uspUnmatchedTxnsReport", param, commandTimeout: 1000000, commandType: CommandType.StoredProcedure).AsList();
                //unmatchedTxnsReportList = connection.Query<dynamic>("uspUnmatchedTxnsReport_testing", param, commandTimeout: 1000000, commandType: CommandType.StoredProcedure).AsList();

                // Retrieve the total record count from the output parameter
                totalRecords = param.Get<int>("@TotalRecords");
            }

            return new PaginatedResult
            {
                Data = unmatchedTxnsReportList,
                TotalRecords = totalRecords
            };
        }

        //public List<dynamic> GetUnmatchedTxnsReport(InputReportModel unmatchedTxnsModel)
        //{
        //    List<dynamic> unmatchedTxnsReportList = null;
        //    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();
        //        param.Add("@ClientID", unmatchedTxnsModel.ClientID);
        //        param.Add("@FromDateTxns", unmatchedTxnsModel.FromDate);
        //        param.Add("@ToDateTxns", unmatchedTxnsModel.ToDate);
        //        param.Add("@ChannelID", unmatchedTxnsModel.ChannelID);
        //        param.Add("@ModeID", unmatchedTxnsModel.ModeID);
        //        param.Add("@TERMINALID", unmatchedTxnsModel.TerminalID);
        //        param.Add("@TxnType", unmatchedTxnsModel.TxnType);

        //        unmatchedTxnsReportList = connection.Query<dynamic>("uspUnmatchedTxnsReport", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //    }

        //    if (unmatchedTxnsReportList == null)
        //    {
        //        unmatchedTxnsReportList = new List<dynamic>();
        //    }

        //    return unmatchedTxnsReportList;
        //}

        public TxnByReferenceNumber GetUnmatchedTxnByReferenceNumberReport(InputReferenceNumberModel unmatchedTxnsModel)
        {
            TxnByReferenceNumber unmatchedTxnByReferenceNumber = new TxnByReferenceNumber();
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ReferenceNumber", unmatchedTxnsModel.ReferenceNumber);
                param.Add("@TERMINALID", unmatchedTxnsModel.TerminalID);
                param.Add("@ClientID", unmatchedTxnsModel.ClientID);


                // Add timeout (e.g., 120 seconds)
                int commandTimeout = 60;

                unmatchedTxnByReferenceNumber.EJTxnDetails = connection.Query<TxnDetailsModel>(
                    "spEJTxnDetails",
                    param,
                    commandType: System.Data.CommandType.StoredProcedure,
                    commandTimeout: commandTimeout
                ).AsList();

                param.Add("@ChannelID", unmatchedTxnsModel.ChannelID);
                param.Add("@ModeID", unmatchedTxnsModel.ModeID);
                //param.Add("@Txnsdatetime", unmatchedTxnsModel.TxnsDateTime);

                unmatchedTxnByReferenceNumber.GLTxnDetails = connection.Query<TxnDetailsModel>(
                    "spGLTxnDetails",
                    param,
                    commandType: System.Data.CommandType.StoredProcedure,
                    commandTimeout: commandTimeout
                ).AsList();

                unmatchedTxnByReferenceNumber.SWTxnDetails = connection.Query<TxnDetailsModel>(
                    "spSWTxnDetails",
                    param,
                    commandType: System.Data.CommandType.StoredProcedure,
                    commandTimeout: commandTimeout
                ).AsList();

                unmatchedTxnByReferenceNumber.NWTxnDetails = connection.Query<TxnDetailsModel>(
                    "UspUnmatchedNWTxnDetails",
                    param,
                    commandType: System.Data.CommandType.StoredProcedure,
                    commandTimeout: commandTimeout
                ).AsList();
            }

            if (unmatchedTxnByReferenceNumber.EJTxnDetails == null)
            {
                unmatchedTxnByReferenceNumber.EJTxnDetails = new List<TxnDetailsModel>();
            }

            if (unmatchedTxnByReferenceNumber.GLTxnDetails == null)
            {
                unmatchedTxnByReferenceNumber.GLTxnDetails = new List<TxnDetailsModel>();
            }

            if (unmatchedTxnByReferenceNumber.NWTxnDetails == null)
            {
                unmatchedTxnByReferenceNumber.NWTxnDetails = new List<TxnDetailsModel>();
            }

            if (unmatchedTxnByReferenceNumber.SWTxnDetails == null)
            {
                unmatchedTxnByReferenceNumber.SWTxnDetails = new List<TxnDetailsModel>();
            }

            return unmatchedTxnByReferenceNumber;
        }

        //public TxnByReferenceNumber GetUnmatchedTxnByReferenceNumberReport(InputReferenceNumberModel unmatchedTxnsModel)
        //{
        //    TxnByReferenceNumber unmatchedTxnByReferenceNumber = new TxnByReferenceNumber();
        //    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();
        //        param.Add("@ReferenceNumber", unmatchedTxnsModel.ReferenceNumber);
        //        param.Add("@TERMINALID", unmatchedTxnsModel.TerminalID);
        //        param.Add("@ClientID", unmatchedTxnsModel.ClientID);

        //        unmatchedTxnByReferenceNumber.EJTxnDetails = connection.Query<TxnDetailsModel>("spEJTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

        //        param.Add("@ChannelID", unmatchedTxnsModel.ChannelID);
        //        param.Add("@ModeID", unmatchedTxnsModel.ModeID);
        //        param.Add("@Txnsdatetime", unmatchedTxnsModel.TxnsDateTime);

        //        unmatchedTxnByReferenceNumber.GLTxnDetails = connection.Query<TxnDetailsModel>("spGLTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //        unmatchedTxnByReferenceNumber.SWTxnDetails = connection.Query<TxnDetailsModel>("spSWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

        //        unmatchedTxnByReferenceNumber.NWTxnDetails = connection.Query<TxnDetailsModel>("UspUnmatchedNWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //    }

        //    if (unmatchedTxnByReferenceNumber.EJTxnDetails == null)
        //    {
        //        unmatchedTxnByReferenceNumber.EJTxnDetails = new List<TxnDetailsModel>();
        //    }

        //    if (unmatchedTxnByReferenceNumber.GLTxnDetails == null)
        //    {
        //        unmatchedTxnByReferenceNumber.GLTxnDetails = new List<TxnDetailsModel>();
        //    }

        //    if (unmatchedTxnByReferenceNumber.NWTxnDetails == null)
        //    {
        //        unmatchedTxnByReferenceNumber.NWTxnDetails = new List<TxnDetailsModel>();
        //    }

        //    if (unmatchedTxnByReferenceNumber.SWTxnDetails == null)
        //    {
        //        unmatchedTxnByReferenceNumber.SWTxnDetails = new List<TxnDetailsModel>();
        //    }

        //    return unmatchedTxnByReferenceNumber;
        //}

        public TxnDetailsByReferenceNumber GetTxnsReportByReferenceNumber(InputReferenceNumberModel unmatchedTxnsModel)
        {
            TxnDetailsByReferenceNumber unmatchedTxnByReferenceNumber = new TxnDetailsByReferenceNumber();
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ReferenceNumber", unmatchedTxnsModel.ReferenceNumber);
                param.Add("@TerminalId", unmatchedTxnsModel.TerminalID);
                param.Add("@ClientID", unmatchedTxnsModel.ClientID);
                param.Add("@TxnsDateTime", unmatchedTxnsModel.TxnsDateTime);

                param.Add("@Channel", unmatchedTxnsModel.ChannelID);
                param.Add("@Mode", unmatchedTxnsModel.ModeID);

                unmatchedTxnByReferenceNumber.GLTxnDetails = connection.Query<dynamic>("uspGLTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                unmatchedTxnByReferenceNumber.SWTxnDetails = connection.Query<dynamic>("uspSWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                unmatchedTxnByReferenceNumber.NWTxnDetails = connection.Query<dynamic>("uspNWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                unmatchedTxnByReferenceNumber.EJTxnDetails = connection.Query<dynamic>("uspEJTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            return unmatchedTxnByReferenceNumber;
        }


        //Matched Report
        public PaginatedResult GetMatchedTxnsReport(DailyReportInputReportModel matchedTxnsModel, int pageNumber, int pageSize)
        {
            List<dynamic> matchedTxnsReportList = null;
            int totalRecords;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", matchedTxnsModel.ClientID);
                param.Add("@ChannelID", matchedTxnsModel.ChannelID);
                param.Add("@ModeID", matchedTxnsModel.ModeID);
                param.Add("@TERMINALID", matchedTxnsModel.TerminalID);
                param.Add("@FromDateTxns", matchedTxnsModel.FromDate);
                param.Add("@ToDateTxns", matchedTxnsModel.ToDate);
                param.Add("@TxnType", matchedTxnsModel.TxnType);
                param.Add("@PageNumber", pageNumber);  // New pagination parameter
                param.Add("@PageSize", pageSize);      // New pagination parameter
                param.Add("@search", matchedTxnsModel.search);
                param.Add("@TotalRecords", dbType: DbType.Int32, direction: ParameterDirection.Output);

                matchedTxnsReportList = connection.Query<dynamic>("uspSuccessfulTxnsReport", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
                totalRecords = param.Get<int>("@TotalRecords");
            }

            return new PaginatedResult
            {
                Data = matchedTxnsReportList,
                TotalRecords = totalRecords
            };
        }


        //Reversal Report

        public PaginatedResult GetReversalTxnsReport(DailyReportInputReportModel reversalTxnsModel, int pageNumber, int pageSize)
        {
            List<dynamic> reversalTxnsReportList = null;
            int totalRecords;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", reversalTxnsModel.ClientID);
                param.Add("@FromDateTxns", reversalTxnsModel.FromDate);
                param.Add("@ToDateTxns", reversalTxnsModel.ToDate);
                param.Add("@ChannelID", reversalTxnsModel.ChannelID);
                param.Add("@ModeID", reversalTxnsModel.ModeID);
                param.Add("@TERMINALID", reversalTxnsModel.TerminalID);
                param.Add("@TxnType", reversalTxnsModel.TxnType);
                param.Add("@PageNumber", pageNumber);  // New pagination parameter
                param.Add("@PageSize", pageSize);      // New pagination parameter
                param.Add("@search", reversalTxnsModel.search);
                param.Add("@TotalRecords", dbType: DbType.Int32, direction: ParameterDirection.Output);

                reversalTxnsReportList = connection.Query<dynamic>("uspReversalTxnsReport", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();

                totalRecords = param.Get<int>("@TotalRecords");
            }

            if (reversalTxnsReportList == null)
            {
                reversalTxnsReportList = new List<dynamic>();
            }

            return new PaginatedResult
            {
                Data = reversalTxnsReportList,
                TotalRecords = totalRecords
            };
        }


        //Unsuccessful Report

        public PaginatedResult GetUnsuccessfulTxnsReport(DailyReportInputReportModel unsuccessfulTxnsModel, int pageNumber, int pageSize)
        {
            List<dynamic> unsuccessfulTxnsReportList = null;
            int totalRecords;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", unsuccessfulTxnsModel.ClientID);
                param.Add("@FromDateTxns", unsuccessfulTxnsModel.FromDate);
                param.Add("@ToDateTxns", unsuccessfulTxnsModel.ToDate);
                param.Add("@ChannelID", unsuccessfulTxnsModel.ChannelID);
                param.Add("@ModeID", unsuccessfulTxnsModel.ModeID);
                param.Add("@TERMINALID", unsuccessfulTxnsModel.TerminalID);
                param.Add("@TxnType", unsuccessfulTxnsModel.TxnType);
                param.Add("@PageNumber", pageNumber);  // New pagination parameter
                param.Add("@PageSize", pageSize);      // New pagination parameter
                param.Add("@search", unsuccessfulTxnsModel.search);
                param.Add("@TotalRecords", dbType: DbType.Int32, direction: ParameterDirection.Output);

                unsuccessfulTxnsReportList = connection.Query<dynamic>("uspUnsuccessfulTxnsReport", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
                totalRecords = param.Get<int>("@TotalRecords");

            }

            return new PaginatedResult
            {
                Data = unsuccessfulTxnsReportList,
                TotalRecords = totalRecords
            };

        }


        //Duplicate Report

        public PaginatedResult GetDuplicateTxnsReport(DailyReportInputReportModel duplicateTxnsModel, int pageNumber, int pageSize)
        {
            List<dynamic> duplicateTxnsReportModelList = null;
            int totalRecords;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", duplicateTxnsModel.ClientID);
                param.Add("@ChannelID", duplicateTxnsModel.ChannelID);
                param.Add("@ModeID", duplicateTxnsModel.ModeID);
                param.Add("@TERMINALID", duplicateTxnsModel.TerminalID);
                param.Add("@FromDateTxns", duplicateTxnsModel.FromDate);
                param.Add("@ToDateTxns", duplicateTxnsModel.ToDate);
                param.Add("@TxnType", duplicateTxnsModel.TxnType);
                param.Add("@PageNumber", pageNumber);  // New pagination parameter
                param.Add("@PageSize", pageSize);      // New pagination parameter
                param.Add("@search", duplicateTxnsModel.search);
                param.Add("@TotalRecords", dbType: DbType.Int32, direction: ParameterDirection.Output);

                duplicateTxnsReportModelList = connection.Query<dynamic>("uspDuplicateTxnsReport", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
                totalRecords = param.Get<int>("@TotalRecords");
            }

            if (duplicateTxnsReportModelList == null)
            {
                duplicateTxnsReportModelList = new List<dynamic>();
            }

            return new PaginatedResult
            {
                Data = duplicateTxnsReportModelList,
                TotalRecords = totalRecords
            };

        }

        //Pos Dms Report

        public List<dynamic> GetPosDmsTxnsReports(DailyReportInputReportModel dmsTxnsModel)
        {
            List<dynamic> DmsTxnsReportModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", dmsTxnsModel.ClientID);
                param.Add("@ChannelID", dmsTxnsModel.ChannelID);
                param.Add("@ModeID", dmsTxnsModel.ModeID);
                param.Add("@TERMINALID", dmsTxnsModel.TerminalID);
                param.Add("@FromDateTxns", dmsTxnsModel.FromDate);
                param.Add("@ToDateTxns", dmsTxnsModel.ToDate);
                param.Add("@TxnType", dmsTxnsModel.TxnType);

                DmsTxnsReportModelList = connection.Query<dynamic>("DMSTxnsReports", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (DmsTxnsReportModelList == null)
            {
                DmsTxnsReportModelList = new List<dynamic>();
            }

            return DmsTxnsReportModelList;
        }

        //Adjustment Report

        public List<AdjustmentTerminalDetailsModel> GetAdjustmentTerminalDetails(string UserName, string ClientID)
        {
            List<AdjustmentTerminalDetailsModel> AdjustmentTerminalDetailsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserName", UserName);
                param.Add("@ClientID", ClientID);

                AdjustmentTerminalDetailsModelList = connection.Query<AdjustmentTerminalDetailsModel>("spGetTerminalDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (AdjustmentTerminalDetailsModelList == null)
            {
                AdjustmentTerminalDetailsModelList = new List<AdjustmentTerminalDetailsModel>();
            }
            return AdjustmentTerminalDetailsModelList;
        }

        public List<AdjustmentModeModel> GetAdjustmentMode(string ClientID, string ChannelID)
        {
            List<AdjustmentModeModel> AdjustmentModeModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                AdjustmentModeModelList = connection.Query<AdjustmentModeModel>("spGetModeTypeALL", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (AdjustmentModeModelList == null)
            {
                AdjustmentModeModelList = new List<AdjustmentModeModel>();
            }
            return AdjustmentModeModelList;
        }

        public List<AdjustmentTxnsReportModel> GetAdjustmentTxnsReport(AdjustmentTxnsModel adjustmentTxnsModel)
        {
            List<AdjustmentTxnsReportModel> AdjustmentTxnsReportModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", adjustmentTxnsModel.ClientID);
                param.Add("@TR_POSTDATE", adjustmentTxnsModel.TR_POSTDATE);
                param.Add("@TR_ENDDATE", adjustmentTxnsModel.TR_ENDDATE);
                param.Add("@ReportType", adjustmentTxnsModel.ReportType);
                param.Add("@UserName", adjustmentTxnsModel.UserName);

                AdjustmentTxnsReportModelList = connection.Query<AdjustmentTxnsReportModel>("UspAdjustmentTxnsReport_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (AdjustmentTxnsReportModelList == null)
            {
                AdjustmentTxnsReportModelList = new List<AdjustmentTxnsReportModel>();
            }
            return AdjustmentTxnsReportModelList;
        }

        public List<FileStatusReportDetailsModel> GetFileStatusReportDetails(FileStatusReportModel fileStatusReportModel)
        {
            List<FileStatusReportDetailsModel> FileStatusReportDetailsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", fileStatusReportModel.ClientID);
                param.Add("@FileType", fileStatusReportModel.FileType);
                param.Add("@ChannelID", fileStatusReportModel.ChannelID);
                param.Add("@TR_POSTDATE", fileStatusReportModel.TR_POSTDATE);
                param.Add("@TR_ENDDATE", fileStatusReportModel.TR_ENDDATE);

                FileStatusReportDetailsModelList = connection.Query<FileStatusReportDetailsModel>("USpFileUploadStatusReport_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (FileStatusReportDetailsModelList == null)
            {
                FileStatusReportDetailsModelList = new List<FileStatusReportDetailsModel>();
            }
            return FileStatusReportDetailsModelList;
        }

        //Dispense Unmatched Report

        //public List<DispenseUnmatchedReportModel> GetDispenseUnmatchedReport(DispenseUnmatchedModel dispenseUnmatchedModel)
        //{
        //    List<DispenseUnmatchedReportModel> dispenseUnmatchedReportModelList = null;
        //    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();
        //        param.Add("@ClientID", dispenseUnmatchedModel.ClientID);
        //        param.Add("@ChannelID", dispenseUnmatchedModel.ChannelID);
        //        param.Add("@ModeID", dispenseUnmatchedModel.ModeID);
        //        param.Add("@TERMINALID", dispenseUnmatchedModel.TERMINALID);
        //        param.Add("@Type", dispenseUnmatchedModel.Type);
        //        param.Add("@FromDateTxns", dispenseUnmatchedModel.FromDateTxns);
        //        param.Add("@ToDateTxns", dispenseUnmatchedModel.ToDateTxns);


        //        dispenseUnmatchedReportModelList = connection.Query<DispenseUnmatchedReportModel>("spDispenseUnmatchedTxnsReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //    }

        //    if (dispenseUnmatchedReportModelList == null)
        //    {
        //        dispenseUnmatchedReportModelList = new List<DispenseUnmatchedReportModel>();
        //    }

        //    return dispenseUnmatchedReportModelList;
        //}


        //public DispenseUnmatchedReportByReferenceNumberClick GetDispenseUnmatchedReportByReferenceNumberClick(DispenseUnmatchedModel dispenseUnmatchedModel)
        //{
        //    DispenseUnmatchedReportByReferenceNumberClick dispenseUnmatchedReportByReferenceNumberClick = new DispenseUnmatchedReportByReferenceNumberClick();
        //    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();
        //        param.Add("@ReferenceNumber", dispenseUnmatchedModel.ReferenceNumber);
        //        param.Add("@TERMINALID", dispenseUnmatchedModel.TERMINALID);
        //        param.Add("@ClientID", dispenseUnmatchedModel.ClientID);

        //        dispenseUnmatchedReportByReferenceNumberClick.EJTxnDetails = connection.Query<DispenseUnmatchedDetailsModel>("spEJTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //        dispenseUnmatchedReportByReferenceNumberClick.GLTxnDetails = connection.Query<DispenseUnmatchedDetailsModel>("spGLTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //        dispenseUnmatchedReportByReferenceNumberClick.SWTxnDetails = connection.Query<DispenseUnmatchedDetailsModel>("spSWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

        //        param.Add("@Channel", dispenseUnmatchedModel.ChannelID);
        //        param.Add("@Mode", dispenseUnmatchedModel.ModeID);

        //        dispenseUnmatchedReportByReferenceNumberClick.NWTxnDetails = connection.Query<DispenseUnmatchedDetailsModel>("UspNWTxnDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //    }

        //    if (dispenseUnmatchedReportByReferenceNumberClick.EJTxnDetails == null)
        //    {
        //        dispenseUnmatchedReportByReferenceNumberClick.EJTxnDetails = new List<DispenseUnmatchedDetailsModel>();
        //    }

        //    if (dispenseUnmatchedReportByReferenceNumberClick.GLTxnDetails == null)
        //    {
        //        dispenseUnmatchedReportByReferenceNumberClick.GLTxnDetails = new List<DispenseUnmatchedDetailsModel>();
        //    }

        //    if (dispenseUnmatchedReportByReferenceNumberClick.NWTxnDetails == null)
        //    {
        //        dispenseUnmatchedReportByReferenceNumberClick.NWTxnDetails = new List<DispenseUnmatchedDetailsModel>();
        //    }

        //    if (dispenseUnmatchedReportByReferenceNumberClick.SWTxnDetails == null)
        //    {
        //        dispenseUnmatchedReportByReferenceNumberClick.SWTxnDetails = new List<DispenseUnmatchedDetailsModel>();
        //    }

        //    return dispenseUnmatchedReportByReferenceNumberClick;
        //}

        List<TerminalOptModel> IReport.GetTerminalOptions(int ClientID)
        {
            List<TerminalOptModel> terminalOptionModelsList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                terminalOptionModelsList = connection.Query<TerminalOptModel>("GetTerminalList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (terminalOptionModelsList == null)
            {
                terminalOptionModelsList = new List<TerminalOptModel>();
            }
            return terminalOptionModelsList;
        }



        public List<dynamic> GetSwitchFeeReportDetails(SwitchFeeModel SwitchFeeModel)
        {
            List<dynamic> SwitchFeeModelList = null;

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                param.Add("@ClientID", SwitchFeeModel.ClientID);
                param.Add("@ChannelType", SwitchFeeModel.ChannelID);
                param.Add("@Date", SwitchFeeModel.FromDateTxns);
                SwitchFeeModelList = connection.Query<dynamic>("SpGetChannelFeeGST", param, commandTimeout: 1000000, commandType: CommandType.StoredProcedure).AsList();
            }

            if (SwitchFeeModelList == null)
            {
                SwitchFeeModelList = new List<dynamic>();
            }

            return SwitchFeeModelList;
        }

        public List<dynamic> GetConsoleSetReportDetails(ConsoleSetModel ConsoleSetModel)
        {
            List<dynamic> ConsoleSetList = null;

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                param.Add("@ClientID", ConsoleSetModel.ClientID);
                param.Add("@Channel", ConsoleSetModel.ChannelID);
                param.Add("@Cycle", ConsoleSetModel.Cycle);
                param.Add("@TR_POSTDATE", ConsoleSetModel.FromDateTxns);
                param.Add("@TR_ENDDATE", ConsoleSetModel.ToDateTxns);
                ConsoleSetList = connection.Query<dynamic>("ConsolSetRpt", param, commandTimeout: 1000000, commandType: CommandType.StoredProcedure).AsList();
            }

            if (ConsoleSetList == null)
            {
                ConsoleSetList = new List<dynamic>();
            }

            return ConsoleSetList;
        }
        public List<DispenseSummaryDetailsModel> GetDispenseSummaryDetails(DispenseSummaryModel dispenseSummaryModel)
        {
            List<DispenseSummaryDetailsModel> dispenseSummaryList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", dispenseSummaryModel.ClientID);
                param.Add("@ChannelID", dispenseSummaryModel.ChannelID);
                param.Add("@ModeID", dispenseSummaryModel.ModeID);
                param.Add("@TERMINALID", dispenseSummaryModel.TERMINALID);
                param.Add("@FromDateTxns", dispenseSummaryModel.FromDateTxns);
                param.Add("@ToDateTxns", dispenseSummaryModel.ToDateTxns);
                // param.Add("@TxnType", dispenseSummaryModel.TxnType);

                dispenseSummaryList = connection.Query<DispenseSummaryDetailsModel>("USP_GetDispenseSummaryReport", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (dispenseSummaryList == null)
            {
                dispenseSummaryList = new List<DispenseSummaryDetailsModel>();
            }

            return dispenseSummaryList;
        }

        //Siddhant Insert Summary job
        public string InsertDispenseSummaryJob(InsertDispenseSummaryModel dispenseSummaryModel)
        {
            string result = string.Empty;

            try
            {
                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    connection.Open();

                    var param = new DynamicParameters();
                    param.Add("@ClientID", dispenseSummaryModel.ClientID);
                    param.Add("@ChannelID", dispenseSummaryModel.ChannelID);
                    param.Add("@ModeID", dispenseSummaryModel.ModeID);
                    param.Add("@TERMINALID", dispenseSummaryModel.TERMINALID);
                    param.Add("@FromDateTxns", dispenseSummaryModel.FromDateTxns);
                    param.Add("@ToDateTxns", dispenseSummaryModel.ToDateTxns);
                    param.Add("@UserName", dispenseSummaryModel.UserName);

                    // Assuming the stored procedure returns a single string message
                    result = connection.ExecuteScalar<string>(
                        "uspRefreshDispenseSummaryReport",
                        param,
                        commandTimeout: 1000000,
                        commandType: System.Data.CommandType.StoredProcedure
                    );
                }
            }
            catch (Exception ex)
            {
                // Optionally handle or log the error
                result = $"Error: {ex.Message}";
            }

            return result ?? string.Empty;
        }



        public List<DispenseUnmatchedReportModel> GetDispenseUnmatchedReport(DispenseUnmatchedModel dispenseUnmatchedModel)
        {
            List<DispenseUnmatchedReportModel> dispenseUnmatchedReportModelList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", dispenseUnmatchedModel.ClientID);
                param.Add("@ChannelID", dispenseUnmatchedModel.ChannelID);
                param.Add("@ModeID", dispenseUnmatchedModel.ModeID);
                param.Add("@TERMINALID", dispenseUnmatchedModel.TERMINALID);
                param.Add("@Type", dispenseUnmatchedModel.Type);
                param.Add("@FromDateTxns", dispenseUnmatchedModel.FromDateTxns);
                param.Add("@ToDateTxns", dispenseUnmatchedModel.ToDateTxns);


                dispenseUnmatchedReportModelList = connection.Query<DispenseUnmatchedReportModel>("spDispenseUnmatchedTxnsReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (dispenseUnmatchedReportModelList == null)
            {
                dispenseUnmatchedReportModelList = new List<DispenseUnmatchedReportModel>();
            }

            return dispenseUnmatchedReportModelList;
        }


        public DispenseUnmatchedReportByReferenceNumberClick GetDispenseUnmatchedReportByReferenceNumberClick(DispenseUnmatchedReferenceNumberModel dispenseUnmatchedModel)
        {
            DispenseUnmatchedReportByReferenceNumberClick dispenseUnmatchedReportByReferenceNumberClick = new DispenseUnmatchedReportByReferenceNumberClick();
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ReferenceNumber", dispenseUnmatchedModel.ReferenceNumber);
                param.Add("@TERMINALID", dispenseUnmatchedModel.TERMINALID);
                param.Add("@ClientID", dispenseUnmatchedModel.ClientID);
                param.Add("@Channel", dispenseUnmatchedModel.ChannelID);
                param.Add("@Mode", dispenseUnmatchedModel.ModeID);
                dispenseUnmatchedReportByReferenceNumberClick.EJTxnDetails = connection.Query<DispenseUnmatchedDetailsModel>("spEJTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                dispenseUnmatchedReportByReferenceNumberClick.GLTxnDetails = connection.Query<DispenseUnmatchedDetailsModel>("spDispenseGLTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                dispenseUnmatchedReportByReferenceNumberClick.SWTxnDetails = connection.Query<DispenseUnmatchedDetailsModel>("spDispenseSWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();



                dispenseUnmatchedReportByReferenceNumberClick.NWTxnDetails = connection.Query<DispenseUnmatchedDetailsModel>("UspDispenseNWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (dispenseUnmatchedReportByReferenceNumberClick.EJTxnDetails == null)
            {
                dispenseUnmatchedReportByReferenceNumberClick.EJTxnDetails = new List<DispenseUnmatchedDetailsModel>();
            }

            if (dispenseUnmatchedReportByReferenceNumberClick.GLTxnDetails == null)
            {
                dispenseUnmatchedReportByReferenceNumberClick.GLTxnDetails = new List<DispenseUnmatchedDetailsModel>();
            }

            if (dispenseUnmatchedReportByReferenceNumberClick.NWTxnDetails == null)
            {
                dispenseUnmatchedReportByReferenceNumberClick.NWTxnDetails = new List<DispenseUnmatchedDetailsModel>();
            }

            if (dispenseUnmatchedReportByReferenceNumberClick.SWTxnDetails == null)
            {
                dispenseUnmatchedReportByReferenceNumberClick.SWTxnDetails = new List<DispenseUnmatchedDetailsModel>();
            }

            return dispenseUnmatchedReportByReferenceNumberClick;
        }


        public List<dynamic> GetALLTTUMReportDetailsList(AllTTUMReportModelNew allTTUMReportModel)
        {
            List<dynamic> aTMTtumReportList = null;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", allTTUMReportModel.ClientID);
                param.Add("@ChannelID", allTTUMReportModel.ChannelID);
                param.Add("@ModeID", allTTUMReportModel.ModeID);
                param.Add("@NetworkID", allTTUMReportModel.NetworkID);
                param.Add("@CurrencyType", allTTUMReportModel.CurrencyType);
                param.Add("@TTUMReportType", allTTUMReportModel.TTUMReportType);
                param.Add("@ToDateTxns", allTTUMReportModel.ToDateTxns);
                param.Add("@FromDateTxns", allTTUMReportModel.FromDateTxns);
                param.Add("@Status", allTTUMReportModel.Status);
                param.Add("@UserRole", allTTUMReportModel.UserRole);

                aTMTtumReportList = connection.Query<dynamic>("UspTTUMREPORT_CoreNew", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (aTMTtumReportList == null)
            {
                aTMTtumReportList = new List<dynamic>();
            }

            return aTMTtumReportList;
        }

        //public List<dynamic> GetALLTTUMReportDetailsList(AllTTUMReportModelNew allTTUMReportModel)
        //{
        //    List<dynamic> aTMTtumReportList = null;

        //    using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();
        //        param.Add("@ClientID", allTTUMReportModel.ClientID);
        //        param.Add("@ChannelID", allTTUMReportModel.ChannelID);
        //        param.Add("@ModeID", allTTUMReportModel.ModeID);
        //        param.Add("@NetworkID", allTTUMReportModel.NetworkID);
        //        //param.Add("@CurrencyType", allTTUMReportModel.CurrencyType);
        //        param.Add("@TTUMReportType", allTTUMReportModel.TTUMReportType);
        //        param.Add("@ToDateTxns", allTTUMReportModel.ToDateTxns);
        //        param.Add("@FromDateTxns", allTTUMReportModel.FromDateTxns);
        //        //param.Add("@Status", allTTUMReportModel.Status);
        //        // param.Add("@UserRole", allTTUMReportModel.UserRole);

        //        aTMTtumReportList = connection.Query<dynamic>("UpiImpsDisputeTTUM", param, commandType: System.Data.CommandType.StoredProcedure).AsList();//UspTTUMREPORT_CoreNew
        //    }

        //    if (aTMTtumReportList == null)
        //    {
        //        aTMTtumReportList = new List<dynamic>();
        //    }

        //    return aTMTtumReportList;
        //}

        public System.Data.DataTable GetALLTTUMReportDataTable(AllTTUMReportModelNew allTTUMReportModel)
        {
            System.Data.DataTable dt = new System.Data.DataTable();

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("UspTTUMREPORT_CoreNew", connection))
                {

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 1000000;

                    cmd.Parameters.AddWithValue("@ClientID", allTTUMReportModel.ClientID);
                    cmd.Parameters.AddWithValue("@ChannelID", allTTUMReportModel.ChannelID);
                    cmd.Parameters.AddWithValue("@ModeID", allTTUMReportModel.ModeID);
                    cmd.Parameters.AddWithValue("@NetworkID", allTTUMReportModel.NetworkID);
                    cmd.Parameters.AddWithValue("@CurrencyType", allTTUMReportModel.CurrencyType);
                    cmd.Parameters.AddWithValue("@TTUMReportType", allTTUMReportModel.TTUMReportType);
                    cmd.Parameters.AddWithValue("@ToDateTxns", allTTUMReportModel.ToDateTxns);
                    cmd.Parameters.AddWithValue("@FromDateTxns", allTTUMReportModel.FromDateTxns);
                    cmd.Parameters.AddWithValue("@Status", allTTUMReportModel.Status);
                    cmd.Parameters.AddWithValue("@UserRole", allTTUMReportModel.UserRole);

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                }
            }


            return dt;
        }

        public string UpdateCheckedDataNew(UpdateNewCheckerModel updateCheckerModel)
        {
            try
            {
                var idList = updateCheckerModel.CheckedID.Select(id => new { Id = id }).ToList();
                var table = new System.Data.DataTable();
                table.Columns.Add("Id", typeof(int));

                foreach (var item in idList)
                {
                    table.Rows.Add(item.Id);
                }
                string Result = "";

                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    param.Add("@ClientID", updateCheckerModel.ClientID);
                    param.Add("@ChannelID", updateCheckerModel.ChannelID);
                    param.Add("@ModeID", updateCheckerModel.ModeID);
                    param.Add("@NetworkID", updateCheckerModel.NetworkID);
                    param.Add("@CurrencyType", updateCheckerModel.CurrencyType);
                    param.Add("@TTUMReportType", updateCheckerModel.TTUMReportType);
                    param.Add("@ToDateTxns", updateCheckerModel.ToDateTxns);
                    param.Add("@FromDateTxns", updateCheckerModel.FromDateTxns);
                    param.Add("@UserName", updateCheckerModel.UserName);
                    param.Add("@UserRole", updateCheckerModel.UserRole);
                    param.Add("@CheckerRemarks", updateCheckerModel.CheckerRemarks);
                    param.Add("@CheckedID", table.AsTableValuedParameter("dbo.IdList"));

                    Result = connection.Query<string>("UsphandleChecker_coreNew", param, commandType: System.Data.CommandType.StoredProcedure).ToString();
                    return Result;
                }
            }
            catch (Exception ex) { return null; }
        }


        public List<dynamic> ExportCheckedExcelReport(AllTTUMReportModelNew allTTUMReportModel)
        {
            List<dynamic> aTMTtumReportList = null;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", allTTUMReportModel.ClientID);
                param.Add("@ChannelID", allTTUMReportModel.ChannelID);
                param.Add("@ModeID", allTTUMReportModel.ModeID);
                param.Add("@NetworkID", allTTUMReportModel.NetworkID);
                param.Add("@CurrencyType", allTTUMReportModel.CurrencyType);
                param.Add("@TTUMReportType", allTTUMReportModel.TTUMReportType);
                param.Add("@ToDateTxns", allTTUMReportModel.ToDateTxns);
                param.Add("@FromDateTxns", allTTUMReportModel.FromDateTxns);
                param.Add("@Status", allTTUMReportModel.Status);
                param.Add("@UserRole", allTTUMReportModel.UserRole);

                aTMTtumReportList = connection.Query<dynamic>("UspTTUMREPORT_CoreNewExport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (aTMTtumReportList == null)
            {
                aTMTtumReportList = new List<dynamic>();
            }

            return aTMTtumReportList;
        }


        public List<dynamic> GetCreditAdjustmentTTUM(NPCIAllTTUMReportModel allTTUMReportModel)
        {
            List<dynamic> aTMTtumReportList = null;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", allTTUMReportModel.ClientID);
                param.Add("@ChannelID", allTTUMReportModel.ChannelID);
                param.Add("@ModeID", allTTUMReportModel.ModeID);
                param.Add("@NetworkID", allTTUMReportModel.NetworkID);
                param.Add("@CurrencyType", allTTUMReportModel.CurrencyType);
                param.Add("@TTUMReportType", allTTUMReportModel.TTUMReportType);
                param.Add("@ToDateTxns", allTTUMReportModel.ToDateTxns);
                param.Add("@FromDateTxns", allTTUMReportModel.FromDateTxns);
                param.Add("@CheckerStatus", allTTUMReportModel.CheckerStatus);

                aTMTtumReportList = connection.Query<dynamic>("UspTTUMREPORTCreditAdjustment_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (aTMTtumReportList == null)
            {
                aTMTtumReportList = new List<dynamic>();
            }

            return aTMTtumReportList;
        }

        public List<CreditAdjustmentTTUMData> UpdateCheckedData(UpdateCheckerModel updateCheckerModel, System.Data.DataTable dataTable)
        {
            try
            {
                List<CreditAdjustmentTTUMData> aTMTtumReportList = null;

                using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    connection.Open();
                    var param = new DynamicParameters();
                    param.Add("@ClientID", updateCheckerModel.ClientID);
                    param.Add("@ChannelID", updateCheckerModel.ChannelID);
                    param.Add("@ModeID", updateCheckerModel.ModeID);
                    param.Add("@NetworkID", updateCheckerModel.NetworkID);
                    param.Add("@CurrencyType", updateCheckerModel.CurrencyType);
                    param.Add("@TTUMReportType", updateCheckerModel.TTUMReportType);
                    param.Add("@ToDateTxns", updateCheckerModel.ToDateTxns);
                    param.Add("@FromDateTxns", updateCheckerModel.FromDateTxns);
                    param.Add("@UserName", updateCheckerModel.UserName);
                    param.Add("@CheckerRemarks", updateCheckerModel.CheckerRemarks);
                    param.Add("@ReportItems", dataTable.AsTableValuedParameter("dbo.CreditAdjustmentType"));

                    aTMTtumReportList = connection.Query<CreditAdjustmentTTUMData>("UsphandleChecker_core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                }
                if (aTMTtumReportList == null)
                {
                    aTMTtumReportList = new List<CreditAdjustmentTTUMData>();
                }

                return aTMTtumReportList;
            }
            catch (Exception ex) { return null; }
        }


        public List<SettelmentTTUMReport> GetSettelmentTTUMReport(AllTTUMReportModelNew allTTUMReportModel)
        {
            List<SettelmentTTUMReport> aTMTtumReportList = null;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", allTTUMReportModel.ClientID);
                param.Add("@ChannelID", allTTUMReportModel.ChannelID);
                param.Add("@ModeID", allTTUMReportModel.ModeID);
                param.Add("@NetworkID", allTTUMReportModel.NetworkID);
                param.Add("@CurrencyType", allTTUMReportModel.CurrencyType);
                param.Add("@ToDateTxns", allTTUMReportModel.ToDateTxns);
                param.Add("@FromDateTxns", allTTUMReportModel.FromDateTxns);
                param.Add("@Status", allTTUMReportModel.Status);
                param.Add("@UserRole", allTTUMReportModel.UserRole);

                aTMTtumReportList = connection.Query<SettelmentTTUMReport>("UspSettelmentTTUMREPORT_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (aTMTtumReportList == null)
            {
                aTMTtumReportList = new List<SettelmentTTUMReport>();
            }

            return aTMTtumReportList;
        }

        public List<TipsAndSurTTUMReport> GetTipsAndSurchargeTTUMReport(AllTTUMReportModelNew allTTUMReportModel)
        {
            List<TipsAndSurTTUMReport> aTMTtumReportList = null;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", allTTUMReportModel.ClientID);
                param.Add("@ChannelID", allTTUMReportModel.ChannelID);
                param.Add("@ModeID", allTTUMReportModel.ModeID);
                param.Add("@NetworkID", allTTUMReportModel.NetworkID);
                param.Add("@CurrencyType", allTTUMReportModel.CurrencyType);
                param.Add("@ToDateTxns", allTTUMReportModel.ToDateTxns);
                param.Add("@FromDateTxns", allTTUMReportModel.FromDateTxns);

                aTMTtumReportList = connection.Query<TipsAndSurTTUMReport>("UspTipsAndSurTTUMREPORT_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (aTMTtumReportList == null)
            {
                aTMTtumReportList = new List<TipsAndSurTTUMReport>();
            }

            return aTMTtumReportList;
        }
        //-------------------------------------------------nk----------------------------------------------//

        public List<ATMTtumReportDetailsModel> GetATMTtumReportDetails(ATMTtumReportModel aTMTtumReportModel)
        {
            List<ATMTtumReportDetailsModel> aTMTtumReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", aTMTtumReportModel.ClientID);
                param.Add("@FromDateTxns", aTMTtumReportModel.FromDateTxns);
                param.Add("@ToDateTxns", aTMTtumReportModel.ToDateTxns);

                aTMTtumReportList = connection.Query<ATMTtumReportDetailsModel>("Proc_ATMTTUMREPORT_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (aTMTtumReportList == null)
            {
                aTMTtumReportList = new List<ATMTtumReportDetailsModel>();
            }

            return aTMTtumReportList;
        }


        public List<ATMChargesReportDetailsModel> GetATMChargesReportDetails(ATMChargesReportModel aTMChargesReportModel)
        {
            List<ATMChargesReportDetailsModel> aTMChargesReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_POSTDATE", aTMChargesReportModel.TR_POSTDATE);
                param.Add("@TR_ENDDATE", aTMChargesReportModel.TR_ENDDATE);
                param.Add("@ClientID", aTMChargesReportModel.ClientID);
                param.Add("@TxnMode", aTMChargesReportModel.TxnMode);

                aTMChargesReportList = connection.Query<ATMChargesReportDetailsModel>("Proc_NPCI_Settlement", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (aTMChargesReportList == null)
            {
                aTMChargesReportList = new List<ATMChargesReportDetailsModel>();
            }

            return aTMChargesReportList;
        }

        public List<IMPSSettlementReportDetailsModel> GetIMPSSettlementReportDetails(IMPSSettlementReportModel iMPSSettlementReportModel)
        {
            List<IMPSSettlementReportDetailsModel> iMPSSettlementReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_POSTDATE", iMPSSettlementReportModel.TR_POSTDATE);
                param.Add("@TR_ENDDATE", iMPSSettlementReportModel.TR_ENDDATE);
                param.Add("@ClientID", iMPSSettlementReportModel.ClientID);

                iMPSSettlementReportList = connection.Query<IMPSSettlementReportDetailsModel>("Proc_IMPS_Settlement_New", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (iMPSSettlementReportList == null)
            {
                iMPSSettlementReportList = new List<IMPSSettlementReportDetailsModel>();
            }

            return iMPSSettlementReportList;
        }


        public System.Data.DataTable GetIMPSSettlementReport(IMPSSettlementReportModel iMPSSettlementReportModel)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("Proc_IMPS_Settlement_New", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@TR_POSTDATE", SqlDbType.DateTime).Value = iMPSSettlementReportModel.TR_POSTDATE;
                    cmd.Parameters.AddWithValue("@TR_ENDDATE", SqlDbType.DateTime).Value = iMPSSettlementReportModel.TR_ENDDATE;
                    cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = iMPSSettlementReportModel.ClientID;

                    using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                }
            }

            return dt;
        }

        public List<IssuerTransactionTTUMReportDetailsModel> GetIssuerTransactionTTUMReportDetails(IssuerTransactionTTUMReportModel issuerTransactionTTUMReportModel)
        {
            List<IssuerTransactionTTUMReportDetailsModel> issuerTransactionTTUMReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", issuerTransactionTTUMReportModel.ClientID);
                param.Add("@ChannelID", issuerTransactionTTUMReportModel.ChannelID);
                param.Add("@ModeID", issuerTransactionTTUMReportModel.ModeID);
                param.Add("@FromDateTxns", issuerTransactionTTUMReportModel.FromDate);
                param.Add("@ToDateTxns", issuerTransactionTTUMReportModel.ToDate);

                issuerTransactionTTUMReportList = connection.Query<IssuerTransactionTTUMReportDetailsModel>("UspAutoReversalNotHappened_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (issuerTransactionTTUMReportList == null)
            {
                issuerTransactionTTUMReportList = new List<IssuerTransactionTTUMReportDetailsModel>();
            }

            return issuerTransactionTTUMReportList;
        }

        public List<ReasonWiseSummaryReportDetailsModel> GetReasonWiseSummaryReportDetails(ReasonWiseSummaryReportModel reasonWiseSummaryReportModel)
        {
            List<ReasonWiseSummaryReportDetailsModel> reasonWiseReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", reasonWiseSummaryReportModel.ClientID);
                param.Add("@ChannelID", reasonWiseSummaryReportModel.ChannelID);
                param.Add("@ModeID", reasonWiseSummaryReportModel.ModeID);
                param.Add("@FromDateTxns", reasonWiseSummaryReportModel.FromDate);
                param.Add("@ToDateTxns", reasonWiseSummaryReportModel.ToDate);

                reasonWiseReportList = connection.Query<ReasonWiseSummaryReportDetailsModel>("spReasonWiseSummaryReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (reasonWiseReportList == null)
            {
                reasonWiseReportList = new List<ReasonWiseSummaryReportDetailsModel>();
            }

            return reasonWiseReportList;
        }

        public List<POSTtumReportDetailsModel> GetPOSTtumReportDetails(POSTtumReportModel pOSTtumReportModel)
        {
            List<POSTtumReportDetailsModel> pOSTtumReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", pOSTtumReportModel.ClientID);
                param.Add("@FromDateTxns", pOSTtumReportModel.FromDateTxns);
                param.Add("@ToDateTxns", pOSTtumReportModel.ToDateTxns);

                pOSTtumReportList = connection.Query<POSTtumReportDetailsModel>("Proc_POSTTUMREPORT_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (pOSTtumReportList == null)
            {
                pOSTtumReportList = new List<POSTtumReportDetailsModel>();
            }

            return pOSTtumReportList;
        }

        public List<POSSettlementReportDetailsModel> GetPOSSettlementReportDetails(POSSettlementReportModel pOSSettlementReportModel)
        {
            List<POSSettlementReportDetailsModel> pOSSettlementReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", pOSSettlementReportModel.ClientID);
                param.Add("@SettlementType", pOSSettlementReportModel.SettlementType);
                param.Add("@TR_POSTDATE", pOSSettlementReportModel.TR_POSTDATE);
                param.Add("@TR_ENDDATE", pOSSettlementReportModel.TR_ENDDATE);

                pOSSettlementReportList = connection.Query<POSSettlementReportDetailsModel>("spPOSSettlementReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (pOSSettlementReportList == null)
            {
                pOSSettlementReportList = new List<POSSettlementReportDetailsModel>();
            }

            return pOSSettlementReportList;
        }

        public List<RefundCashbackTTUMReportDetailsModel> GetRefundCashbackTTUMReportDetails(RefundCashbackTTUMReportModel refundCashbackTTUMReportModel)
        {
            List<RefundCashbackTTUMReportDetailsModel> refundCashbackTTUMReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", refundCashbackTTUMReportModel.ClientID);
                param.Add("@FromDateTxns", refundCashbackTTUMReportModel.FromDate);
                param.Add("@ToDateTxns", refundCashbackTTUMReportModel.ToDate);

                refundCashbackTTUMReportList = connection.Query<RefundCashbackTTUMReportDetailsModel>("UspRefundAndCashbackTTUM_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (refundCashbackTTUMReportList == null)
            {
                refundCashbackTTUMReportList = new List<RefundCashbackTTUMReportDetailsModel>();
            }

            return refundCashbackTTUMReportList;
        }


        public List<RefundTxnsReportDetailsModel> GetRefundTxnsReportDetails(RefundTxnsReportModel refundTxnsReportModel)
        {
            List<RefundTxnsReportDetailsModel> refundTxnsReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", refundTxnsReportModel.ClientID);
                param.Add("@FROMDATE", refundTxnsReportModel.FROMDATE);
                param.Add("@TODATE", refundTxnsReportModel.TODATE);

                refundTxnsReportList = connection.Query<RefundTxnsReportDetailsModel>("spRefundTxnsReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (refundTxnsReportList == null)
            {
                refundTxnsReportList = new List<RefundTxnsReportDetailsModel>();
            }

            return refundTxnsReportList;
        }

        public List<PendingAcqEntryReportDetailsModel> GetPendingAcqEntryReportDetails(PendingAcqEntryReportModel pendingAcqEntryReportModel)
        {
            List<PendingAcqEntryReportDetailsModel> pendingAcqEntryReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", pendingAcqEntryReportModel.ClientID);
                param.Add("@FromDateTxns", pendingAcqEntryReportModel.FromDate);
                param.Add("@ToDateTxns", pendingAcqEntryReportModel.ToDate);

                pendingAcqEntryReportList = connection.Query<PendingAcqEntryReportDetailsModel>("UspNoDatainGL_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (pendingAcqEntryReportList == null)
            {
                pendingAcqEntryReportList = new List<PendingAcqEntryReportDetailsModel>();
            }

            return pendingAcqEntryReportList;
        }

        public List<SettledTransactionsReportDetailsModel> GetSettledTransactionsReport(SettledTransactionsReportModel settledTransactionsReportModel)
        {
            List<SettledTransactionsReportDetailsModel> settledTransactionsReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", settledTransactionsReportModel.ClientID);
                param.Add("@ChannelID", settledTransactionsReportModel.ChannelID);
                param.Add("@ModeID", settledTransactionsReportModel.ModeID);
                param.Add("@TERMINALID", settledTransactionsReportModel.TERMINALID);
                param.Add("@FromDateTxns", settledTransactionsReportModel.FromDate);
                param.Add("@ToDateTxns", settledTransactionsReportModel.ToDate);
                param.Add("@TxnType", settledTransactionsReportModel.TxnType);

                settledTransactionsReportList = connection.Query<SettledTransactionsReportDetailsModel>("UspSettlementTxns_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (settledTransactionsReportList == null)
            {
                settledTransactionsReportList = new List<SettledTransactionsReportDetailsModel>();
            }

            return settledTransactionsReportList;
        }


        public SettledTransactionsReportByReferenceNumber GetSettledTransactionsReportByReferenceNumber(SettledTransactionsReportModel settledTransactionsReportModel)
        {
            SettledTransactionsReportByReferenceNumber settledTransactionsReportByReferenceNumber = new SettledTransactionsReportByReferenceNumber();
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ReferenceNumber", settledTransactionsReportModel.ReferenceNumber);
                param.Add("@TERMINALID", settledTransactionsReportModel.TERMINALID);
                param.Add("@ClientID", settledTransactionsReportModel.ClientID);

                settledTransactionsReportByReferenceNumber.EJTxnDetails = connection.Query<SettledTransactionsReportDetails1Model>("spEJTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                settledTransactionsReportByReferenceNumber.GLTxnDetails = connection.Query<SettledTransactionsReportDetails1Model>("spGLTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                settledTransactionsReportByReferenceNumber.SWTxnDetails = connection.Query<SettledTransactionsReportDetails1Model>("spSWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                param.Add("@Channel", settledTransactionsReportModel.ChannelID);
                param.Add("@Mode", settledTransactionsReportModel.ModeID);

                settledTransactionsReportByReferenceNumber.NWTxnDetails = connection.Query<SettledTransactionsReportDetails1Model>("UspNWTxnDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (settledTransactionsReportByReferenceNumber.EJTxnDetails == null)
            {
                settledTransactionsReportByReferenceNumber.EJTxnDetails = new List<SettledTransactionsReportDetails1Model>();
            }

            if (settledTransactionsReportByReferenceNumber.GLTxnDetails == null)
            {
                settledTransactionsReportByReferenceNumber.GLTxnDetails = new List<SettledTransactionsReportDetails1Model>();
            }

            if (settledTransactionsReportByReferenceNumber.NWTxnDetails == null)
            {
                settledTransactionsReportByReferenceNumber.NWTxnDetails = new List<SettledTransactionsReportDetails1Model>();
            }

            if (settledTransactionsReportByReferenceNumber.SWTxnDetails == null)
            {
                settledTransactionsReportByReferenceNumber.SWTxnDetails = new List<SettledTransactionsReportDetails1Model>();
            }

            return settledTransactionsReportByReferenceNumber;
        }

        public List<SuccessfulAmountCountReportDetailsModel> GetSuccessfulAmountCountReportDetails(SuccessfulAmountCountReportModel successfulAmountCountReportModel)
        {
            List<SuccessfulAmountCountReportDetailsModel> successfulAmountCountReportDetailsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FromDateTxns", successfulAmountCountReportModel.FromDateTxns);
                param.Add("@ToDateTxns", successfulAmountCountReportModel.ToDateTxns);

                successfulAmountCountReportDetailsList = connection.Query<SuccessfulAmountCountReportDetailsModel>("UspASPALLBANKSCOUNT_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (successfulAmountCountReportDetailsList == null)
            {
                successfulAmountCountReportDetailsList = new List<SuccessfulAmountCountReportDetailsModel>();
            }

            return successfulAmountCountReportDetailsList;
        }

        public List<UPISettlementReportDetailsModel> GetUPISettlementReportDetails(UPISettlementReportModel uPISettlementReportModel)
        {
            List<UPISettlementReportDetailsModel> uPISettlementReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@TR_POSTDATE", uPISettlementReportModel.TR_POSTDATE);
                param.Add("@TR_ENDDATE", uPISettlementReportModel.TR_ENDDATE);
                param.Add("@ClientID", uPISettlementReportModel.ClientID);

                uPISettlementReportList = connection.Query<UPISettlementReportDetailsModel>("Proc_UPI_Settlement", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (uPISettlementReportList == null)
            {
                uPISettlementReportList = new List<UPISettlementReportDetailsModel>();
            }

            return uPISettlementReportList;
        }

        //public List<BankSettlementReportDetailsModel> GetBankSettlementReportDetails(BankReportModel bankSettlementReportModel)
        //{
        //    List<BankSettlementReportDetailsModel> bankSettlementReportList = null;
        //    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();
        //        param.Add("@TR_POSTDATE", bankSettlementReportModel.TR_POSTDATE);
        //        param.Add("@TR_ENDDATE", bankSettlementReportModel.TR_ENDDATE);
        //        param.Add("@ClientID", bankSettlementReportModel.ClientID);
        //        bankSettlementReportList = connection.Query<BankSettlementReportDetailsModel>("Proc_Bank_SettlementUjjwal_Backup", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //    }

        //    if (bankSettlementReportList == null)
        //    {
        //        bankSettlementReportList = new List<BankSettlementReportDetailsModel>();
        //    }

        //    return bankSettlementReportList;
        //}

        public List<TipsAndSurchargeDetailsModel> GetTipsAndSurchargeDetails(TipsAndSurchargeModel tipsAndSurchargeModel)
        {
            List<TipsAndSurchargeDetailsModel> tipsAndSurchargeList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", tipsAndSurchargeModel.ClientID);
                param.Add("@FromDateTxns", tipsAndSurchargeModel.FromDate);
                param.Add("@ToDateTxns", tipsAndSurchargeModel.ToDate);

                tipsAndSurchargeList = connection.Query<TipsAndSurchargeDetailsModel>("UspTipsAndSurcharge_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (tipsAndSurchargeList == null)
            {
                tipsAndSurchargeList = new List<TipsAndSurchargeDetailsModel>();
            }

            return tipsAndSurchargeList;
        }

        public List<IMPSTTUMReportDetailsModel> GetIMPSTTUMReportDetails(IMPSTTUMReportModel iMPTTUMReportModel)
        {
            List<IMPSTTUMReportDetailsModel> iMPTTUMReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", iMPTTUMReportModel.ClientID);
                param.Add("@FromDateTxns", iMPTTUMReportModel.FromDate);
                param.Add("@ToDateTxns", iMPTTUMReportModel.ToDate);

                iMPTTUMReportList = connection.Query<IMPSTTUMReportDetailsModel>("Proc_IMPSTTUMDATAREPORTALLC_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (iMPTTUMReportList == null)
            {
                iMPTTUMReportList = new List<IMPSTTUMReportDetailsModel>();
            }

            return iMPTTUMReportList;
        }

        public List<IMPSTTUMInsertReportDetailsModel> GetIMPSTTUMInsertReportDetails(IMPSTTUMInsertReportModel iMPTTUMInsertReportModel)
        {
            List<IMPSTTUMInsertReportDetailsModel> iMPTTUMInsertReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", iMPTTUMInsertReportModel.ClientID);
                param.Add("@FromDateTxns", iMPTTUMInsertReportModel.FromDate);
                param.Add("@ToDateTxns", iMPTTUMInsertReportModel.ToDate);

                iMPTTUMInsertReportList = connection.Query<IMPSTTUMInsertReportDetailsModel>("Proc_InsertIMPSTTUM_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (iMPTTUMInsertReportList == null)
            {
                iMPTTUMInsertReportList = new List<IMPSTTUMInsertReportDetailsModel>();
            }

            return iMPTTUMInsertReportList;
        }

        //public List<DispenseSummaryDetailsModel> GetDispenseSummaryDetails(DispenseSummaryModel dispenseSummaryModel)
        //{
        //    List<DispenseSummaryDetailsModel> dispenseSummaryList = null;
        //    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //            connection.Open();
        //            var param = new DynamicParameters();
        //            param.Add("@ClientID", dispenseSummaryModel.ClientID);
        //            param.Add("@ChannelID", dispenseSummaryModel.ChannelID);
        //            param.Add("@ModeID", dispenseSummaryModel.ModeID);
        //            param.Add("@TERMINALID", dispenseSummaryModel.TERMINALID);
        //            param.Add("@FromDateTxns", dispenseSummaryModel.FromDateTxns);
        //            param.Add("@ToDateTxns", dispenseSummaryModel.ToDateTxns);
        //            param.Add("@TxnType", dispenseSummaryModel.TxnType);

        //            dispenseSummaryList = connection.Query<DispenseSummaryDetailsModel>("uspGetDispenseSummaryReport", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //        }

        //    if (dispenseSummaryList == null)
        //    {
        //        dispenseSummaryList = new List<DispenseSummaryDetailsModel>();
        //    }

        //    return dispenseSummaryList;
        //}

        public List<TxnCountDetailsModel> GetTxnCountDetails(TxnCountModel txnCountModel)
        {
            List<TxnCountDetailsModel> txnCountList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                var param = new DynamicParameters();
                param.Add("@ClientID", txnCountModel.ClientID);
                param.Add("@ChannelID", txnCountModel.ChannelID);
                param.Add("@ModeID", txnCountModel.ModeID);
                param.Add("@TERMINALID", txnCountModel.TERMINALID);
                param.Add("@FromDateTxns", txnCountModel.FromDate);
                param.Add("@ToDateTxns", txnCountModel.ToDate);

                txnCountList = connection.Query<TxnCountDetailsModel>("spTransactionCountSummaryReport", param, commandTimeout: 1000000, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (txnCountList == null)
            {
                txnCountList = new List<TxnCountDetailsModel>();
            }

            return txnCountList;
        }

        //Unsuccessful Txns Report 

        public List<UnsuccessfulTxnsGridReportModel> GetUnsuccessfulTxnsGridReport(UnSuccessfulTxnsModel unSuccessfulTxnsModel)
        {
            List<UnsuccessfulTxnsGridReportModel> unsuccessfulTxnsGridReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", unSuccessfulTxnsModel.ClientID);
                param.Add("@ChannelID", unSuccessfulTxnsModel.ChannelID);
                param.Add("@ModeID", unSuccessfulTxnsModel.ModeID);
                param.Add("@TERMINALID", unSuccessfulTxnsModel.TerminalID);
                param.Add("@FromDateTxns", unSuccessfulTxnsModel.FromDate);
                param.Add("@ToDateTxns", unSuccessfulTxnsModel.ToDate);
                param.Add("@TxnType", unSuccessfulTxnsModel.TxnType);

                unsuccessfulTxnsGridReportList = connection.Query<UnsuccessfulTxnsGridReportModel>("uspUnsuccessfulTxnsReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (unsuccessfulTxnsGridReportList == null)
            {
                unsuccessfulTxnsGridReportList = new List<UnsuccessfulTxnsGridReportModel>();
            }

            return unsuccessfulTxnsGridReportList;
        }


        public UnsuccessfulTxnsByReferenceNumber GetUnsuccessfulTxnsByReferenceNumberReport(UnSuccessfulTxnsModel unSuccessfulTxnsModel)
        {
            UnsuccessfulTxnsByReferenceNumber unsuccessfulTxnsByReferenceNumber = new UnsuccessfulTxnsByReferenceNumber();
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ReferenceNumber", unSuccessfulTxnsModel.ReferenceNumber);
                param.Add("@TERMINALID", unSuccessfulTxnsModel.TerminalID);
                param.Add("@ClientID", unSuccessfulTxnsModel.ClientID);

                unsuccessfulTxnsByReferenceNumber.EJTxnDetails = connection.Query<UnsuccessfulTxnsDetailsModel>("spEJTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                unsuccessfulTxnsByReferenceNumber.GLTxnDetails = connection.Query<UnsuccessfulTxnsDetailsModel>("spGLTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                unsuccessfulTxnsByReferenceNumber.SWTxnDetails = connection.Query<UnsuccessfulTxnsDetailsModel>("spSWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                param.Add("@Channel", unSuccessfulTxnsModel.ChannelID);
                param.Add("@Mode", unSuccessfulTxnsModel.ModeID);

                unsuccessfulTxnsByReferenceNumber.NWTxnDetails = connection.Query<UnsuccessfulTxnsDetailsModel>("UspNWTxnDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (unsuccessfulTxnsByReferenceNumber.EJTxnDetails == null)
            {
                unsuccessfulTxnsByReferenceNumber.EJTxnDetails = new List<UnsuccessfulTxnsDetailsModel>();
            }

            if (unsuccessfulTxnsByReferenceNumber.GLTxnDetails == null)
            {
                unsuccessfulTxnsByReferenceNumber.GLTxnDetails = new List<UnsuccessfulTxnsDetailsModel>();
            }

            if (unsuccessfulTxnsByReferenceNumber.NWTxnDetails == null)
            {
                unsuccessfulTxnsByReferenceNumber.NWTxnDetails = new List<UnsuccessfulTxnsDetailsModel>();
            }

            if (unsuccessfulTxnsByReferenceNumber.SWTxnDetails == null)
            {
                unsuccessfulTxnsByReferenceNumber.SWTxnDetails = new List<UnsuccessfulTxnsDetailsModel>();
            }

            return unsuccessfulTxnsByReferenceNumber;
        }

        public List<UPI_TTUM_DisputeModel> GetUPITTUMDisputeReportDetails(TTUMReportModel iMPTTUMReportModel)
        {
            List<UPI_TTUM_DisputeModel> iMPTTUMReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", iMPTTUMReportModel.ClientID);
                param.Add("@FromDateTxns", iMPTTUMReportModel.FromDate);
                param.Add("@ToDateTxns", iMPTTUMReportModel.ToDate);

                iMPTTUMReportList = connection.Query<UPI_TTUM_DisputeModel>("usp_GetUPITTUM_Dispute_Report", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (iMPTTUMReportList == null)
            {
                iMPTTUMReportList = new List<UPI_TTUM_DisputeModel>();
            }

            return iMPTTUMReportList;
        }

        public List<UPI_TTUM_DisputeModel> GetIMPSTTUMDisputeReportDetails(TTUMReportModel iMPTTUMReportModel)
        {
            List<UPI_TTUM_DisputeModel> iMPTTUMReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", iMPTTUMReportModel.ClientID);
                param.Add("@FromDateTxns", iMPTTUMReportModel.FromDate);
                param.Add("@ToDateTxns", iMPTTUMReportModel.ToDate);

                iMPTTUMReportList = connection.Query<UPI_TTUM_DisputeModel>("usp_GetIMPSTTUM_Dispute_Report", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (iMPTTUMReportList == null)
            {
                iMPTTUMReportList = new List<UPI_TTUM_DisputeModel>();
            }

            return iMPTTUMReportList;
        }

        public List<TIMEOUTModel> GetTIMEOUTReportDetails(TTUMReportModel iMPTTUMReportModel)
        {
            List<TIMEOUTModel> TIMEOUT_List = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", iMPTTUMReportModel.ClientID);
                param.Add("@FromDateTxns", iMPTTUMReportModel.FromDate);
                param.Add("@ToDateTxns", iMPTTUMReportModel.FromDate);
                param.Add("@TxnMode", iMPTTUMReportModel.TTUMType);

                TIMEOUT_List = connection.Query<TIMEOUTModel>("usp_GetIMPSUPI_TIMEOUT_Transaction", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (TIMEOUT_List == null)
            {
                TIMEOUT_List = new List<TIMEOUTModel>();
            }

            return TIMEOUT_List;
        }

        public List<NPCIBulkModel> Get_NPCI_BULK_UPLOAD_Report(TTUMReportModel iMPTTUMReportModel)
        {
            List<NPCIBulkModel> TIMEOUT_List = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", iMPTTUMReportModel.ClientID);
                param.Add("@FromDateTxns", iMPTTUMReportModel.FromDate);
                param.Add("@ToDateTxns", iMPTTUMReportModel.FromDate);
                param.Add("@TxnMode", iMPTTUMReportModel.TTUMType);

                TIMEOUT_List = connection.Query<NPCIBulkModel>("usp_IMPS_UPI_TIMEOUTTransaction_BULKNPCI", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (TIMEOUT_List == null)
            {
                TIMEOUT_List = new List<NPCIBulkModel>();
            }

            return TIMEOUT_List;
        }

        public List<NPCIBulkModel> GetDrcReportDetails(TTUMReportModel iMPTTUMReportModel)
        {
            List<NPCIBulkModel> DRC_List = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", iMPTTUMReportModel.ClientID);
                param.Add("@FromDateTxns", iMPTTUMReportModel.FromDate);
                param.Add("@ToDateTxns", iMPTTUMReportModel.FromDate);
                param.Add("@TxnMode", iMPTTUMReportModel.TTUMType);

                DRC_List = connection.Query<NPCIBulkModel>("usp_GetUPI_DRC_Report", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (DRC_List == null)
            {
                DRC_List = new List<NPCIBulkModel>();
            }

            return DRC_List;
        }


        public List<dynamic> GetCashTallyReportDetail(CashTallyReportModel cashTallyReportModel)
        {
            List<dynamic> CashTallyReport = null;

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", cashTallyReportModel.ClientID);
                param.Add("@FromDate", cashTallyReportModel.FromDateTxns);
                param.Add("@ToDate", cashTallyReportModel.ToDateTxns);

                CashTallyReport = connection.Query<dynamic>("spCashTallyReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (CashTallyReport == null)
            {
                CashTallyReport = new List<dynamic>();
            }

            return CashTallyReport;
        }



        public List<dynamic> GetCashTallyUnmatchedReport(DispenseUnmatchedModel dispenseUnmatchedModel)
        {
            List<dynamic> UnmatchedReportModelList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", dispenseUnmatchedModel.ClientID);
                param.Add("@ChannelID", dispenseUnmatchedModel.ChannelID);
                param.Add("@ModeID", dispenseUnmatchedModel.ModeID);
                param.Add("@TERMINALID", dispenseUnmatchedModel.TERMINALID);
                param.Add("@Type", dispenseUnmatchedModel.Type);
                param.Add("@FromDateTxns", dispenseUnmatchedModel.FromDateTxns);
                param.Add("@ToDateTxns", dispenseUnmatchedModel.ToDateTxns);


                UnmatchedReportModelList = connection.Query<dynamic>("CashTallyDifferenceReport", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (UnmatchedReportModelList == null)
            {
                UnmatchedReportModelList = new List<dynamic>();
            }

            return UnmatchedReportModelList;
        }

        public List<DispenseSummaryJobGridModel> GetDispenseSummaryJobDetails(GetDispenseSummaryJob dispenseSummaryModel)
        {
            List<DispenseSummaryJobGridModel> DispenseSummaryJobGridReportList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", dispenseSummaryModel.ClientID);
                param.Add("@ChannelID", dispenseSummaryModel.ChannelID);
                param.Add("@ModeID", dispenseSummaryModel.ModeID);
                param.Add("@FromDateTxns", dispenseSummaryModel.FromDateTxns);
                param.Add("@ToDateTxns", dispenseSummaryModel.ToDateTxns);
                //param.Add("@TxnType", dispenseSummaryModel.TxnType);

                DispenseSummaryJobGridReportList = connection.Query<DispenseSummaryJobGridModel>("GET_DispenseSummaryJob", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (DispenseSummaryJobGridReportList == null)
            {
                DispenseSummaryJobGridReportList = new List<DispenseSummaryJobGridModel>();
            }

            return DispenseSummaryJobGridReportList;
        }


        //public TxnByReferenceNumber GetUnmatchedTxnByTerminalNumberReport(InputTerminalModel unmatchedTxnsModel)
        //{
        //    TxnByReferenceNumber unmatchedTxnByReferenceNumber = new TxnByReferenceNumber();
        //    using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
        //    {
        //        connection.Open();
        //        var param = new DynamicParameters();
        //        param.Add("@ClientID", unmatchedTxnsModel.ClientID);
        //        param.Add("@TERMINALID", unmatchedTxnsModel.TERMINALID);
        //        param.Add("@")
        //        unmatchedTxnByReferenceNumber.EJTxnDetails = connection.Query<TxnDetailsModel>("spEJTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

        //        unmatchedTxnByReferenceNumber.GLTxnDetails = connection.Query<TxnDetailsModel>("spGLTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //        unmatchedTxnByReferenceNumber.SWTxnDetails = connection.Query<TxnDetailsModel>("spSWTxnDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

        //        unmatchedTxnByReferenceNumber.NWTxnDetails = connection.Query<TxnDetailsModel>("UspNWTxnDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
        //    }

        //    if (unmatchedTxnByReferenceNumber.EJTxnDetails == null)
        //    {
        //        unmatchedTxnByReferenceNumber.EJTxnDetails = new List<TxnDetailsModel>();
        //    }

        //    if (unmatchedTxnByReferenceNumber.GLTxnDetails == null)
        //    {
        //        unmatchedTxnByReferenceNumber.GLTxnDetails = new List<TxnDetailsModel>();
        //    }

        //    if (unmatchedTxnByReferenceNumber.NWTxnDetails == null)
        //    {
        //        unmatchedTxnByReferenceNumber.NWTxnDetails = new List<TxnDetailsModel>();
        //    }

        //    if (unmatchedTxnByReferenceNumber.SWTxnDetails == null)
        //    {
        //        unmatchedTxnByReferenceNumber.SWTxnDetails = new List<TxnDetailsModel>();
        //    }

        //    return unmatchedTxnByReferenceNumber;
        //}



    }
}