﻿using Microsoft.Extensions.Configuration;
using ASPTrace.Contracts;
using ASPTrace.Models;
using System.Data;
using Dapper;

namespace ASPTrace.Repository
{
    public class RoleCreationRepository : IRoleCreation
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;

        public RoleCreationRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }


        public List<RoleCreationModel> GetRole(string ClientID)
        {
            List<RoleCreationModel> RoleCreationModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                RoleCreationModelList = connection.Query<RoleCreationModel>("spGetRoleDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (RoleCreationModelList == null)
            {
                RoleCreationModelList = new List<RoleCreationModel>();
            }

            return RoleCreationModelList;
        }


        public List<RoleMenuAccessModel> GetRoleAccessRights(string ClientID, string RoleID)
        {
            List<RoleMenuAccessModel> RoleAccessRightsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@RoleID", RoleID);

                RoleAccessRightsModelList = connection.Query<RoleMenuAccessModel>("uspGetRoleAccessRights", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (RoleAccessRightsModelList == null)
            {
                RoleAccessRightsModelList = new List<RoleMenuAccessModel>();
            }

            return RoleAccessRightsModelList;
        }

        public List<RoleMenuModel> GetRoleAccessRightsCore(string RoleID)
        {
            List<RoleMenuModel> RoleAccessRightsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters(); 
                param.Add("@RoleID", RoleID);

                RoleAccessRightsModelList = connection.Query<RoleMenuModel>("uspGetRoleAccessRightsCore", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (RoleAccessRightsModelList == null)
            {
                RoleAccessRightsModelList = new List<RoleMenuModel>();
            }

            return RoleAccessRightsModelList;
        }

        public string RoleAddUpdate(RoleDetailsRegModel roleDetailsRegModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", roleDetailsRegModel.Mode);
                param.Add("@RoleID", roleDetailsRegModel.RoleID);
                param.Add("@ClientID", roleDetailsRegModel.ClientID);
                param.Add("@RoleName", roleDetailsRegModel.RoleName);
                param.Add("@HomePage", roleDetailsRegModel.HomePage);
                param.Add("@CreatedBy", roleDetailsRegModel.CreatedBy);
                connection.Open();
                result = connection.ExecuteScalar<string>("spRoleMaster", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public string AddUpdateRole(RoleDetailsRegModel roleDetailsRegModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", roleDetailsRegModel.Mode);
                param.Add("@RoleID", roleDetailsRegModel.RoleID);
                param.Add("@ClientID", roleDetailsRegModel.ClientID);
                param.Add("@RoleName", roleDetailsRegModel.RoleName);
                param.Add("@HomePage", roleDetailsRegModel.HomePage);
                param.Add("@UserType", roleDetailsRegModel.UserType);
                param.Add("@CreatedBy", roleDetailsRegModel.CreatedBy);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspAddUpdateRoleMaster", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public string AddUpdateRoleCore(RoleDetailsModel roleDetailsRegModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", roleDetailsRegModel.Mode);
                param.Add("@RoleID", roleDetailsRegModel.RoleID);
                param.Add("@RoleName", roleDetailsRegModel.RoleName);
                param.Add("@RoleMenus", roleDetailsRegModel.RoleMenus);
                param.Add("@ReportMenuString", roleDetailsRegModel.ReportMenuString);
                param.Add("@UserType", roleDetailsRegModel.UserType);
                param.Add("@CreatedBy", roleDetailsRegModel.CreatedBy);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspAddUpdateRoleMasterCore", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public RoleDetailsRegModel GetRoleDetails(string ClientID,string RoleID)
        {
            RoleDetailsRegModel RoleDetails = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@RoleID", RoleID);

                connection.Open();
                List<RoleDetailsRegModel> RoleList = connection.Query<RoleDetailsRegModel>("UspGetRoleData_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (RoleList != null && RoleList.Count > 0)
                {
                    RoleDetails = RoleList[0];
                }
            }

            if (RoleDetails == null)
            {
                RoleDetails = new RoleDetailsRegModel();
            }
            return RoleDetails;
        }

        public RoleDetailsModel GetRoleDetails(string RoleID)
        {
            RoleDetailsModel RoleDetails = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                var param = new DynamicParameters(); 
                param.Add("@RoleID", RoleID);

                connection.Open();
                List<RoleDetailsModel> RoleList = connection.Query<RoleDetailsModel>("uspGetRoleDetailsCore", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (RoleList != null && RoleList.Count > 0)
                {
                    RoleDetails = RoleList[0];
                }
            }

            if (RoleDetails == null)
            {
                RoleDetails = new RoleDetailsModel();
            }
            return RoleDetails;
        }

        public int AssignRoleAccessRights(AssignRoleAccessRightsModel assignRoleAccessRightsModel)
        {
            int result = 0;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@RoleID", assignRoleAccessRightsModel.RoleID);
                param.Add("@ClientID", assignRoleAccessRightsModel.ClientID);
                param.Add("@Menustring", assignRoleAccessRightsModel.Menustring);
                param.Add("@Username", assignRoleAccessRightsModel.CreatedBy);
                connection.Open();
                result = connection.Execute("spAssignRoleAccessRights", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public int AssignRoleMenuAccessRights(AssignRoleMenuAccessRightsModel assignRoleAccessRightsModel)
        {
            int result = 0;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@RoleID", assignRoleAccessRightsModel.RoleID);
                param.Add("@ClientID", assignRoleAccessRightsModel.ClientID);
                param.Add("@Menustring", assignRoleAccessRightsModel.Menustring);
                param.Add("@DownloadMenustring", assignRoleAccessRightsModel.DownloadReportMenustring);
                param.Add("@Username", assignRoleAccessRightsModel.CreatedBy);
                connection.Open();
                result = connection.Execute("uspAssignRoleMenuAccessRights", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }


        public List<MenuAccessModel> GetMenuAccess(string UserID, string RoleID, string MenuLevel, string ClientID)
        {
            List<MenuAccessModel> MenuAccessModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                param.Add("@RoleID", RoleID);
                param.Add("@MenuLevel", MenuLevel);
                param.Add("@ClientID", ClientID);

                MenuAccessModelList = connection.Query<MenuAccessModel>("spGetMenuAccess", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (MenuAccessModelList == null)
            {
                MenuAccessModelList = new List<MenuAccessModel>();
            }

            return MenuAccessModelList;
        }

        public string DeleteRoleReg(DeleteRoleModel roleDetailsRegModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", roleDetailsRegModel.Mode);
                param.Add("@RoleID", roleDetailsRegModel.RoleID);
                connection.Open();
                result = connection.ExecuteScalar<string>("UspDeleteRoleMaster_Core", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }


        public List<RoleListModel> GetRoleAccessGrid(UserFilterModel2 userModel)
        {
            List<RoleListModel> RoleList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@Status", userModel.Status);
                param.Add("@UserId", userModel.UserID);

                RoleList = connection.Query<RoleListModel>("uspGetRoleGridCore", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (RoleList == null)
            {
                RoleList = new List<RoleListModel>();
            }

            return RoleList;
        }

        public string ActionTakenByChecker(ActionModel nModel)
        {
            string result = "";
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    var param = new DynamicParameters();
                    param.Add("@RoleID", nModel.TrnID); 
                    param.Add("@CheckerId", nModel.UserName);
                    param.Add("@Remarks", nModel.Remarks);
                    param.Add("@Action", nModel.Action);

                    connection.Open();
                    result = connection.ExecuteScalar<string>("usp_UpdateRoleStatusByChecker", param, commandType: System.Data.CommandType.StoredProcedure);
                }
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }
        }

        public string DeleteRoleCore(DeleteRoleModel roleDetailsRegModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", roleDetailsRegModel.Mode);
                param.Add("@RoleID", roleDetailsRegModel.RoleID);
                connection.Open();
                result = connection.ExecuteScalar<string>("uspAddUpdateRoleMasterCore", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }

        public string DeleteTempRoleCore(ActionModel nModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters(); 
                param.Add("@RoleID", nModel.TrnID);
                param.Add("@CheckerId", nModel.UserName);
                param.Add("@Remarks", nModel.Remarks);
                param.Add("@Action", nModel.Action);

                connection.Open();
                result = connection.ExecuteScalar<string>("uspDeleteTempRoleCore", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }

        public string EditApprovedRole(UserFilterModel2 userModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@RoleId", userModel.UserID);
                param.Add("@CreatedBy", userModel.Status);

                result = connection.ExecuteScalar<string>("usp_EditApprovedRole", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

    }
}
