﻿ 
using Microsoft.Extensions.Configuration; 
using System.Data; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;
using System.Data.SqlClient;

namespace ASPTrace.Repository
{
    public class RunReconProcessRepository : IRunReconProcess
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public RunReconProcessRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<ChannelRunReconProcessModel> GetChannelRunReconProcess(string ClientID)
        {
            List<ChannelRunReconProcessModel> channelRunReconProcessList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                channelRunReconProcessList = connection.Query<ChannelRunReconProcessModel>("UspGetSelectedChannelType_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (channelRunReconProcessList == null)
            {
                channelRunReconProcessList = new List<ChannelRunReconProcessModel>();
            }

            return channelRunReconProcessList;
        }
        public List<ModeRunReconProcessModel> GetModeRunReconProcess(string ClientID, int ChannelID)
        {
            List<ModeRunReconProcessModel> modeRunReconProcessList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@ChannelID", ChannelID);

                modeRunReconProcessList = connection.Query<ModeRunReconProcessModel>("UspGetModeTypeALLIMPS_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (modeRunReconProcessList == null)
            {
                modeRunReconProcessList = new List<ModeRunReconProcessModel>();
            }

            return modeRunReconProcessList;
        }

        public List<RunReconHistoryRunReconProcessModel> GetRunReconHistoryRunReconProcess(string ClientID, string ChannelID, string ModeId)
        {
            List<RunReconHistoryRunReconProcessModel> runReconHistoryRunReconProcessList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@Clientid", ClientID);
                param.Add("@ChannelId",ChannelID);
                param.Add("@ModeId", ModeId);

                runReconHistoryRunReconProcessList = connection.Query<RunReconHistoryRunReconProcessModel>("UspRunReconHistory_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (runReconHistoryRunReconProcessList == null)
            {
                runReconHistoryRunReconProcessList = new List<RunReconHistoryRunReconProcessModel>();
            }

            return runReconHistoryRunReconProcessList;
        }

        public List<RunReconAddRunReconProcessModel> GetRunReconAddRunReconProcess(ReconStatusRunReconProcessModel reconStatusRunReconProcessModel)
        {
            List<RunReconAddRunReconProcessModel> runReconAddRunReconProcessModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FromDate", reconStatusRunReconProcessModel.FromDate);
                param.Add("@ToDate", reconStatusRunReconProcessModel.ToDate);
                param.Add("@Clientid", reconStatusRunReconProcessModel.ClientID);
                param.Add("@ChannelID", reconStatusRunReconProcessModel.ChannelID);
                param.Add("@Mode", reconStatusRunReconProcessModel.ModeID);
                param.Add("@user", reconStatusRunReconProcessModel.User);

                runReconAddRunReconProcessModelList = connection.Query<RunReconAddRunReconProcessModel>("RunReconAdd", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (runReconAddRunReconProcessModelList == null)
            {
                runReconAddRunReconProcessModelList = new List<RunReconAddRunReconProcessModel>();
            }

            return runReconAddRunReconProcessModelList;
        }

        public List<dynamic> GetRunReconFileStatusList(ReconFileStatusProcessModel reconFileStatusProcessModel)
        {
            List<dynamic> reconFileStatusListModel = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FromDate", reconFileStatusProcessModel.Fromdate);
                param.Add("@ToDate", reconFileStatusProcessModel.Todate);
                param.Add("@ClientID", reconFileStatusProcessModel.ClientID);
                param.Add("@ChannelID", reconFileStatusProcessModel.ChannelID);
                param.Add("@ModeID", reconFileStatusProcessModel.ModeID);
                param.Add("@CreatedDate", reconFileStatusProcessModel.CreatedDate);


                reconFileStatusListModel = connection.Query<dynamic>("spGetRunReconStatus", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
                }

            if (reconFileStatusListModel == null)
            {
                reconFileStatusListModel = new List<dynamic>();
            }

            return reconFileStatusListModel;
        }

        public string ConfirmRunReconAdd(ReconStatusRunReconProcessModel reconStatusRunReconProcessModel)
        {
            string Result = string.Empty;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FromDate", reconStatusRunReconProcessModel.FromDate);
                param.Add("@ToDate", reconStatusRunReconProcessModel.ToDate);
                param.Add("@ClientID", reconStatusRunReconProcessModel.ClientID);
                param.Add("@ChannelID", reconStatusRunReconProcessModel.ChannelID);
                param.Add("@ModeID", reconStatusRunReconProcessModel.ModeID);
                param.Add("@user", reconStatusRunReconProcessModel.User);

                Result = connection.ExecuteScalar<string>("RunReconAdd_core", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            if (Result == null)
            {
                Result = "";
            }

            return Result;
        }

        public string ForceRunRecon(ForceRunReconRequest model)
        {
            string result = string.Empty;

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FromDate", model.FromDate);
                param.Add("@ToDate", model.ToDate);
                param.Add("@Clientid", model.ClientId);
                param.Add("@ChannelID", model.ChannelId);
                param.Add("@ModeID", model.ModeId);
                param.Add("@ForceRemarks", model.ForceRemarks ?? string.Empty);
                param.Add("@user", model.User);

                result = connection.ExecuteScalar<string>(
                    "sp_ForceRunRecon",
                    param,
                    commandType: CommandType.StoredProcedure
                );
            }

            return result ?? string.Empty;
        }

        public RunReconFileStatus GetDefaultFileUploadCount(ReconFileStatusListModel defaultFileCountProcessModel)
        {
            List<dynamic> DefaultFileUploadCountList = null;
            string jsonString = "";
            int isRecon = 0;

            RunReconFileStatus runReconFileStatus = new RunReconFileStatus();

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FromDate", defaultFileCountProcessModel.Fromdate);
                param.Add("@ToDate", defaultFileCountProcessModel.Todate);
                param.Add("@ClientID", defaultFileCountProcessModel.ClientID);
                param.Add("@ChannelID", defaultFileCountProcessModel.ChannelID);
                param.Add("@ModeID", defaultFileCountProcessModel.ModeID);
                param.Add("@IsRecon", dbType: DbType.Int32, direction: ParameterDirection.Output);
                DefaultFileUploadCountList = connection.Query<dynamic>("uspGetFileStatusCount", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                isRecon = param.Get<int>("@IsRecon");
            }

            if (DefaultFileUploadCountList == null)
            {
                DefaultFileUploadCountList = new List<dynamic>();
            }
            else
            {
                jsonString = System.Text.Json.JsonSerializer.Serialize(DefaultFileUploadCountList);
            }

            runReconFileStatus.JsonString = jsonString;
            runReconFileStatus.ReconStatus = isRecon;

            return runReconFileStatus;
        }


        public List<dynamic> GetTtumReportJobGrid(NPCIReportModel nPCIReportModel)
        {
            List<dynamic> UnmatchedReportModelList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", nPCIReportModel.ClientID);
                param.Add("@ChannelID", nPCIReportModel.ChannelID);
                param.Add("@ReportType", nPCIReportModel.ReportType);
                param.Add("@FromDateTxns", nPCIReportModel.FromDateTxns);
                param.Add("@ToDateTxns", nPCIReportModel.ToDateTxns);
                param.Add("@UserID", nPCIReportModel.UserName);


                UnmatchedReportModelList = connection.Query<dynamic>("uspGetTtumReportJobGrid", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (UnmatchedReportModelList == null)
            {
                UnmatchedReportModelList = new List<dynamic>();
            }

            return UnmatchedReportModelList;
        }

        public string AddTtumReportJob(NPCIReportModel nPCIReportModel)
        {
            string affectedRows = string.Empty ;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", nPCIReportModel.ClientID);
                param.Add("@ChannelID", nPCIReportModel.ChannelID);
                param.Add("@ReportType", nPCIReportModel.ReportType);
                param.Add("@FromDateTxns", nPCIReportModel.FromDateTxns);
                param.Add("@ToDateTxns", nPCIReportModel.ToDateTxns);
                param.Add("@CreatedBy", nPCIReportModel.UserName);

                affectedRows = connection.ExecuteScalar<string>("usp_addTtumReportJobEntry", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return affectedRows;
        }

        public List<dynamic> GetReportGrid(NPCIReportModel nPCIReportModel)
        {
            List<dynamic> ReportList = null;
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", nPCIReportModel.ClientID);
                param.Add("@ChannelID", nPCIReportModel.ChannelID);
                param.Add("@ReportType", nPCIReportModel.ReportType);
                param.Add("@FromDateTxns", nPCIReportModel.FromDateTxns);
                param.Add("@ToDateTxns", nPCIReportModel.ToDateTxns);
                param.Add("@UserID", nPCIReportModel.UserName);
                param.Add("@Remarks", nPCIReportModel.Remark);

                ReportList = connection.Query<dynamic>("uspGetReportData", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ReportList == null)
            {
                ReportList = new List<dynamic>();
            }

            return ReportList;
        }

        public DataTable GetReportDataTable(NPCIReportModel nPCIReportModel)
        {
            DataTable dtReport = new DataTable();

            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new System.Data.SqlClient.SqlCommand("uspGetReportDataTable", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 5000000;
                    // Adding parameters to the command  
                    command.Parameters.Add(new SqlParameter("@ClientID", nPCIReportModel.ClientID));
                    command.Parameters.Add(new SqlParameter("@ChannelID", nPCIReportModel.ChannelID));
                    command.Parameters.Add(new SqlParameter("@ReportType", nPCIReportModel.ReportType));
                    command.Parameters.Add(new SqlParameter("@FromDateTxns", nPCIReportModel.FromDateTxns));
                    command.Parameters.Add(new SqlParameter("@ToDateTxns", nPCIReportModel.ToDateTxns));
                    command.Parameters.Add(new SqlParameter("@UserID", nPCIReportModel.UserName));
                    command.Parameters.Add(new SqlParameter("@Remarks", nPCIReportModel.Remark));

                    // Using SqlDataAdapter to fill the DataTable
                    using (var adapter = new System.Data.SqlClient.SqlDataAdapter(command))
                    {
                        adapter.Fill(dtReport);
                    }
                }
            }

            return dtReport;
        }

        public string UpdateStatusByMaker(NPCIReportModel nPCIReportModel)
        {
            string result = "";
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    var param = new DynamicParameters();
                    param.Add("@ClientID", nPCIReportModel.ClientID);
                    param.Add("@ChannelID", nPCIReportModel.ChannelID);
                    param.Add("@ReportType", nPCIReportModel.ReportType);
                    param.Add("@FromDateTxns", nPCIReportModel.FromDateTxns);
                    param.Add("@ToDateTxns", nPCIReportModel.ToDateTxns);
                    param.Add("@UserId", nPCIReportModel.UserName);
                    param.Add("@Remarks", nPCIReportModel.Remark);

                    connection.Open();
                    result = connection.ExecuteScalar<string>("usp_UpdateStatusByMaker", param, commandType: System.Data.CommandType.StoredProcedure);
                }
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }
        }
        public string UpdateStatusByChecker(NPCIReportModel nPCIReportModel)
        {
            string result = "";
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    var param = new DynamicParameters();
                    param.Add("@ClientID", nPCIReportModel.ClientID);
                    param.Add("@ChannelID", nPCIReportModel.ChannelID);
                    param.Add("@ReportType", nPCIReportModel.ReportType);
                    param.Add("@FromDateTxns", nPCIReportModel.FromDateTxns);
                    param.Add("@ToDateTxns", nPCIReportModel.ToDateTxns);
                    param.Add("@UserId", nPCIReportModel.UserName);
                    param.Add("@Remarks", nPCIReportModel.Remark);

                    connection.Open();
                    result = connection.ExecuteScalar<string>("usp_UpdateStatusByChecker", param, commandType: System.Data.CommandType.StoredProcedure);
                }
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }
        }

        public string DeleteTransaction(DeleteReportModel nPCIReportModel)
        {
            string result = "";
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    var param = new DynamicParameters();
                    param.Add("@DeleteId", nPCIReportModel.DeleteId);
                    param.Add("@UserId", nPCIReportModel.UserName); 
                    param.Add("@Role", nPCIReportModel.Role);

                    connection.Open();
                    result = connection.ExecuteScalar<string>("usp_RemoveTransaction", param, commandType: System.Data.CommandType.StoredProcedure);
                }
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }
        }

        public string GetCheckerMakerStatus(NPCIReportModel nPCIReportModel)
        {
            string result = "";
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    var param = new DynamicParameters();
                    param.Add("@ClientID", nPCIReportModel.ClientID);
                    param.Add("@ChannelID", nPCIReportModel.ChannelID);
                    param.Add("@ReportType", nPCIReportModel.ReportType);
                    param.Add("@FromDateTxns", nPCIReportModel.FromDateTxns);
                    param.Add("@ToDateTxns", nPCIReportModel.ToDateTxns);
                    param.Add("@UserId", nPCIReportModel.UserName);
                    param.Add("@Remarks", nPCIReportModel.Remark);

                    connection.Open();
                    result = connection.ExecuteScalar<string>("uspGetReportStatus", param, commandType: System.Data.CommandType.StoredProcedure);
                }
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }
        }

        public string GetUploadedFileList(ReconFileStatusListModel defaultFileCountProcessModel, string Filetype)
        {
            List<dynamic> UploadedFileList = null;
            string jsonString = "";
            using (var connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FromDate", defaultFileCountProcessModel.Fromdate);
                param.Add("@ToDate", defaultFileCountProcessModel.Todate);
                param.Add("@ClientID", defaultFileCountProcessModel.ClientID);
                param.Add("@ChannelID", defaultFileCountProcessModel.ChannelID);
                param.Add("@ModeID", defaultFileCountProcessModel.ModeID);
                param.Add("@FileType", Filetype);

                UploadedFileList = connection.Query<dynamic>("GetUploadedFileList", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (UploadedFileList == null)
            {
                UploadedFileList = new List<dynamic>();
            }
            else
            {
                jsonString = System.Text.Json.JsonSerializer.Serialize(UploadedFileList);
            }

            return jsonString;
        }
    }
}