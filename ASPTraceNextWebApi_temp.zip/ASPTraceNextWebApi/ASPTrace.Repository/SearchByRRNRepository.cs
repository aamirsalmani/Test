﻿using Microsoft.Extensions.Configuration;  
using System.Data; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;

namespace ASPTrace.Repository
{
  public class SearchByRRNRepository:ISearchByRRN
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public SearchByRRNRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        
        public List<SearchByRRNDetailsModel> GetSearchByRRNDetails(SearchByRRNModel searchByRRNModel)
        {
            List<SearchByRRNDetailsModel> searchByRRNDetailsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", searchByRRNModel.ClientID);
                param.Add("@ReferenceNo", searchByRRNModel.ReferenceNo);
                param.Add("@TERMINALID", searchByRRNModel.TERMINALID);
                param.Add("@FromDateTxns", searchByRRNModel.FromDate);
                param.Add("@ToDateTxns", searchByRRNModel.ToDate);
    

                searchByRRNDetailsModelList = connection.Query<SearchByRRNDetailsModel>("spSearchByRRN", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (searchByRRNDetailsModelList == null)
            {
                searchByRRNDetailsModelList = new List<SearchByRRNDetailsModel>();
            }

            return searchByRRNDetailsModelList;
        }

    }
}
