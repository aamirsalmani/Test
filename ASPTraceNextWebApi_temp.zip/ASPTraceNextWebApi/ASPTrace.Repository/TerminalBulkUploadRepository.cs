﻿using Microsoft.Extensions.Configuration; 
using System.Data; 
using ASPTrace.Contracts; 
using Dapper;

namespace ASPTrace.Repository
{
   public class TerminalBulkUploadRepository:ITerminalBulkUpload
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;

        public TerminalBulkUploadRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public int AddTerminalBulkUploadMaster(string ClientID, DataTable dtTerminal)
        {
            int rowsAffected = 0;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@tblTerminalRegDetails", dtTerminal, DbType.Object);
                param.Add("@ClientID", ClientID);
                rowsAffected = connection.Execute("spBulkInsertTerminalMaster_Core", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return rowsAffected;
        }
    }
}
