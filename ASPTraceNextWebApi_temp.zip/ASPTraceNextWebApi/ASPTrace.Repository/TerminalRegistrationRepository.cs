﻿using Microsoft.Extensions.Configuration; 
using System.Data; 
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;

namespace ASPTrace.Repository
{
    public class TerminalRegistrationRepository:ITerminalRegistration
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public TerminalRegistrationRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<TerminalConfigMaster> GetTerminalMasterGridData()
        {
            List<TerminalConfigMaster> TerminalConfigMasterList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                TerminalConfigMasterList = connection.Query<TerminalConfigMaster>("usp_TerminalList_core", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (TerminalConfigMasterList == null)
            {
                TerminalConfigMasterList = new List<TerminalConfigMaster>();
            }

            return TerminalConfigMasterList;
        }

        public string CheckTerminalIDExists(string ID , string TerminalID)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ID", ID);
                param.Add("@TerminalID", TerminalID);
                
                result = connection.ExecuteScalar<string>("uspCheckTermID_core", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public List<TerminalState> GetTerminalState()
        {
            List<TerminalState> TerminalStateList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                TerminalStateList = connection.Query<TerminalState>("spGetStateMaster", commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (TerminalStateList == null)
            {
                TerminalStateList = new List<TerminalState>();
            }

            return TerminalStateList;
        }

        public List<StateDistrictModel> GetDistrictOptions(string StateID)
        {
            List<StateDistrictModel> stateDistrictModelsList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@StateID", Convert.ToInt32(StateID));

                stateDistrictModelsList = connection.Query<StateDistrictModel>("UspGetDistrictALL_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (stateDistrictModelsList == null)
            {
                stateDistrictModelsList = new List<StateDistrictModel>();
            }
            return stateDistrictModelsList;
        }


        public TerminalRegConfigMaster GetTerminalRegConfigMasterData(string ID)
        {
            TerminalRegConfigMaster terminalRegConfigMaster = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ID", ID);

                List<TerminalRegConfigMaster> TerminalRegConfigMasterList = connection.Query<TerminalRegConfigMaster>("usp_TerminalDetails_core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (TerminalRegConfigMasterList != null && TerminalRegConfigMasterList.Count > 0)
                {
                    terminalRegConfigMaster = TerminalRegConfigMasterList[0];
                }
            }

            if (terminalRegConfigMaster == null)
            {
                terminalRegConfigMaster = new TerminalRegConfigMaster();
            }

            return terminalRegConfigMaster;
        }

        public List<VendorMaster> GetVendorMaster()
        {
            List<VendorMaster> VendorMasterList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                VendorMasterList = connection.Query<VendorMaster>("spGetVendor", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (VendorMasterList == null)
            {
                VendorMasterList = new List<VendorMaster>();
            }
            return VendorMasterList;
        }

        public List<LocationTypeMaster> GetLocationTypeMaster()
        {
            List<LocationTypeMaster> LocationTypeMasterList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                LocationTypeMasterList = connection.Query<LocationTypeMaster>("spGetLocationType", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (LocationTypeMasterList == null)
            {
                LocationTypeMasterList = new List<LocationTypeMaster>();
            }
            return LocationTypeMasterList;
        }

        public List<ATMMakeTypeMaster> GetATMMakeTypeMaster()
        {
            List<ATMMakeTypeMaster> ATMMakeTypeMasterList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                ATMMakeTypeMasterList = connection.Query<ATMMakeTypeMaster>("spGetATMMakeType", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ATMMakeTypeMasterList == null)
            {
                ATMMakeTypeMasterList = new List<ATMMakeTypeMaster>();
            }
            return ATMMakeTypeMasterList;
        }

        public List<SiteTypeMaster> GetSiteTypeMaster()
        {
            List<SiteTypeMaster> SiteTypeMasterList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                SiteTypeMasterList = connection.Query<SiteTypeMaster>("spGetSiteType", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (SiteTypeMasterList == null)
            {
                SiteTypeMasterList = new List<SiteTypeMaster>();
            }
            return SiteTypeMasterList;
        }

        public List<SiteClassMaster> GetSiteClassMaster()
        {
            List<SiteClassMaster> SiteClassMasterList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                SiteClassMasterList = connection.Query<SiteClassMaster>("spGetSiteClass", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (SiteClassMasterList == null)
            {
                SiteClassMasterList = new List<SiteClassMaster>();
            }
            return SiteClassMasterList;
        }

        public List<TerminalTypeMaster> GetTerminalTypeMaster()
        {
            List<TerminalTypeMaster> TerminalTypeMasterList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();

                TerminalTypeMasterList = connection.Query<TerminalTypeMaster>("spGetTerminalType", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (TerminalTypeMasterList == null)
            {
                TerminalTypeMasterList = new List<TerminalTypeMaster>();
            }
            return TerminalTypeMasterList;
        }
        public List<BranchMaster> GetBranchMaster(string ClientID)
        {
            List<BranchMaster> BranchMasterList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                BranchMasterList = connection.Query<BranchMaster>("spGetBranchDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (BranchMasterList == null)
            {
                BranchMasterList = new List<BranchMaster>();
            }
            return BranchMasterList;
        }


        public int AddUpdateTerminalMaster(TerminalConfigMasterNew terminalConfigMasterNew)
        {
            int rowsAffected = 0;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                param.Add("@ClientID", terminalConfigMasterNew.ClientID);
                param.Add("@Mode", terminalConfigMasterNew.Mode);
                param.Add("@VendorID", terminalConfigMasterNew.VendorID);
                param.Add("@BranchCode", terminalConfigMasterNew.BranchCode);
                param.Add("@TerminalID", terminalConfigMasterNew.TerminalID);
                param.Add("@TerminalLocation", terminalConfigMasterNew.TerminalLocation);
                param.Add("@StateID", terminalConfigMasterNew.StateID);
                param.Add("@DistrictID", terminalConfigMasterNew.DistrictID);
                param.Add("@LocationTypeID", terminalConfigMasterNew.LocationTypeID);
                param.Add("@ATMMakeTypeID", terminalConfigMasterNew.ATMMakeTypeID);
                param.Add("@SiteTypeID", terminalConfigMasterNew.SiteTypeID);
                param.Add("@SiteClassID", terminalConfigMasterNew.SiteClassID);
                param.Add("@GLAccountNo", terminalConfigMasterNew.GLAccountNo);
                param.Add("@TerminalTypeID", terminalConfigMasterNew.TerminalTypeID);
                param.Add("@ContactNo", terminalConfigMasterNew.ContactNo);
                param.Add("@EmailID", terminalConfigMasterNew.EmailID);
                param.Add("@ConcernPerson", terminalConfigMasterNew.ConcernPerson);
                param.Add("@Cassette1", terminalConfigMasterNew.Cassette1);
                param.Add("@Cassette2", terminalConfigMasterNew.Cassette2);
                param.Add("@Cassette3", terminalConfigMasterNew.Cassette3);
                param.Add("@Cassette4", terminalConfigMasterNew.Cassette4);
                param.Add("@Cassette5", terminalConfigMasterNew.Cassette5);
                param.Add("@Cassette6", terminalConfigMasterNew.Cassette6);
                param.Add("@CassetteCurrencyCode1", terminalConfigMasterNew.CassetteCurrencyCode1);
                param.Add("@CassetteCurrencyCode2", terminalConfigMasterNew.CassetteCurrencyCode2);
                param.Add("@CassetteCurrencyCode3", terminalConfigMasterNew.CassetteCurrencyCode3);
                param.Add("@CassetteCurrencyCode4", terminalConfigMasterNew.CassetteCurrencyCode4);
                param.Add("@CassetteCurrencyCode5", terminalConfigMasterNew.CassetteCurrencyCode5);
                param.Add("@CassetteCurrencyCode6", terminalConfigMasterNew.CassetteCurrencyCode6);
                param.Add("@IsActive", terminalConfigMasterNew.IsActive);
                param.Add("@IsCassetteSwap", terminalConfigMasterNew.IsCassetteSwap);
                param.Add("@FileName", terminalConfigMasterNew.FileName);
                param.Add("@FilePath", terminalConfigMasterNew.FilePath);
                param.Add("@UserName", terminalConfigMasterNew.UserName);

                rowsAffected = connection.Execute("spTerminalConfigMaster", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return rowsAffected;
        }


        public string TerminalRegDelete(TerminalRegDeleteModel terminalRegDeleteModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", terminalRegDeleteModel.Mode);
                param.Add("@ID", terminalRegDeleteModel.ID);
                connection.Open();
                result = connection.ExecuteScalar<string>("UspDeleteTerminalMaster_Core", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }
    }
}
