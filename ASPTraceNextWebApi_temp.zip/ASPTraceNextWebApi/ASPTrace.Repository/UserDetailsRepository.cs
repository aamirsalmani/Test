﻿using Microsoft.Extensions.Configuration;
using ASPTrace.Contracts;
using ASPTrace.Models;
using System.Data;
using Dapper;
using Microsoft.Office.Interop.Excel;

namespace ASPTrace.Repository
{
    public class UserDetailsRepository : IUserDetails
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;

        public UserDetailsRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }

        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<UserClientDetailsModel> GetUserClientDetails()
        {
            List<UserClientDetailsModel> userClientDetailsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                userClientDetailsModelList = connection.Query<UserClientDetailsModel>("spGeClientDetails_Core", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (userClientDetailsModelList == null)
            {
                userClientDetailsModelList = new List<UserClientDetailsModel>();
            }
            

            return userClientDetailsModelList;
        }


        public List<UserRoleDetailsModel> GetUserRoleDetails(string ClientID)
        {
            List<UserRoleDetailsModel> userRoleDetailsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                userRoleDetailsModelList = connection.Query<UserRoleDetailsModel>("spGetRoleDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (userRoleDetailsModelList == null)
            {
                userRoleDetailsModelList = new List<UserRoleDetailsModel>();
            }
            return userRoleDetailsModelList;
        }

        public List<UserBranchDetailsModel> GetUserBranchDetails(string ClientID)
        {
            List<UserBranchDetailsModel> userBranchDetailsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);

                userBranchDetailsModelList = connection.Query<UserBranchDetailsModel>("spGetBranchDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (userBranchDetailsModelList == null)
            {
                userBranchDetailsModelList = new List<UserBranchDetailsModel>();
            }
            return userBranchDetailsModelList;
        }


        public List<UserBranchcodePopDetailsModel> GetUserBranchcodePopDetails(string ClientID, string BranchCode)
        {
            List<UserBranchcodePopDetailsModel> userBranchcodePopDetailsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@BranchCode", BranchCode);

                userBranchcodePopDetailsModelList = connection.Query<UserBranchcodePopDetailsModel>("spGetBranchcodePopDetails", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (userBranchcodePopDetailsModelList == null)
            {
                userBranchcodePopDetailsModelList = new List<UserBranchcodePopDetailsModel>();
            }
            return userBranchcodePopDetailsModelList;
        }


        public List<UserDetailsGridModel> GetUserDetailsGrid(UserFilterModel userDetailsModel)
        {
            List<UserDetailsGridModel> userDetailsGridModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", userDetailsModel.ClientID);
                param.Add("@BranchID", userDetailsModel.BranchID);
                param.Add("@RoleID", userDetailsModel.RoleID);
                param.Add("@UserId", userDetailsModel.UserID);

                userDetailsGridModelList = connection.Query<UserDetailsGridModel>("spGetUserDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (userDetailsGridModelList == null)
            {
                userDetailsGridModelList = new List<UserDetailsGridModel>();
            }
            return userDetailsGridModelList;
        }
         
        public List<UserDetailsGridModel> GetUsers(UserFilterModel2 userDetailsModel)
        {
            List<UserDetailsGridModel> userDetailsGridModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters(); 
                param.Add("@Status", userDetailsModel.Status);
                param.Add("@UserId", userDetailsModel.UserID);

                userDetailsGridModelList = connection.Query<UserDetailsGridModel>("uspGetUsersCore", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (userDetailsGridModelList == null)
            {
                userDetailsGridModelList = new List<UserDetailsGridModel>();
            }
            return userDetailsGridModelList;
        }

        public List<RoleOptionModel> GetUserRoles()
        {
            List<RoleOptionModel> userRoleList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open(); 

                userRoleList = connection.Query<RoleOptionModel>("uspGetRoles", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (userRoleList == null)
            {
                userRoleList = new List<RoleOptionModel>();
            }
            return userRoleList;
        }

        public List<UserResetPasswordModel> GetUserResetPassword(GetUserResetPassModel userDetailsModel)
        {
            List<UserResetPasswordModel> userResetPasswordModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", userDetailsModel.ClientID);
                param.Add("@UserID", userDetailsModel.UserID);
                param.Add("@ConfirmPassword", userDetailsModel.ConfirmPassword);
                param.Add("@NewSalt", userDetailsModel.NewSalt);
                param.Add("@CreatedBy", userDetailsModel.CreatedBy);

                userResetPasswordModelList = connection.Query<UserResetPasswordModel>("spResetPassword", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (userResetPasswordModelList == null)
            {
                userResetPasswordModelList = new List<UserResetPasswordModel>();
            }
            return userResetPasswordModelList;
        }


        public string CreateUser(UserDetailsModel userDetailsModel, string Salt)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FirstName", userDetailsModel.FirstName);
                param.Add("@LastName", userDetailsModel.LastName);
                param.Add("@UserID", userDetailsModel.UserID);
                param.Add("@Password", userDetailsModel.ConfirmPassword);
                param.Add("@RoleID", userDetailsModel.RoleID);
                param.Add("@BranchID", userDetailsModel.BranchID);
                param.Add("@ClientID", userDetailsModel.ClientID);
                param.Add("@BranchTerminalID", userDetailsModel.BranchTerminalID);
                param.Add("@EmailID", userDetailsModel.EmailID);
                param.Add("@ContactNo", userDetailsModel.ContactNo);
                param.Add("@CreatedBy", userDetailsModel.CreatedBy);
                param.Add("@SecurityQ", string.Empty);
                param.Add("@SecurityA  ", string.Empty);
                param.Add("@Salt", Salt);
                result = connection.ExecuteScalar<string>("UspAddUser_Core", param, commandType: System.Data.CommandType.StoredProcedure);
            }

             
            return result;
        }

        public string CreateUserCore(UserDetailsModel userDetailsModel, string Salt)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();

                param.Add("@ClientID", userDetailsModel.ClientID);
                param.Add("@UserID", userDetailsModel.UserID);
                param.Add("@FirstName", userDetailsModel.FirstName);
                param.Add("@LastName", userDetailsModel.LastName);
                param.Add("@Password", userDetailsModel.ConfirmPassword);
                param.Add("@RoleID", userDetailsModel.RoleID);
                param.Add("@BranchID", userDetailsModel.BranchID);
                param.Add("@BranchTerminalID", userDetailsModel.BranchTerminalID);
                param.Add("@EmailID", userDetailsModel.EmailID);
                param.Add("@ContactNo", userDetailsModel.ContactNo);
                param.Add("@CreatedBy", userDetailsModel.CreatedBy); 
                param.Add("@Salt", Salt);
                param.Add("@ChannelModeJsonString", userDetailsModel.ChannelModeConfig); 
                result = connection.ExecuteScalar<string>("uspAddUserDetailsCore", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public string DeleteUser(DeleteUserModel userDetailsModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@USERNAME", userDetailsModel.UserID);
                param.Add("@ClientID", userDetailsModel.ClientID);
                param.Add("@DeletedBy", userDetailsModel.DeletedBy);

                result = connection.ExecuteScalar<string>("spadduserdelete", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            if (result == null)
            {
                result = string.Empty;
            }

            return result;
        }

        public string UpdateChangePassword(PasswordModel passwordModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@ClientCode", passwordModel.ClientCode);
                param.Add("@UserID", passwordModel.UserID);
                param.Add("@OldPassword", passwordModel.OldPassword);
                param.Add("@ConfirmPassword", passwordModel.ConfirmPassword);
                param.Add("@NewSalt", passwordModel.NewSalt);
                param.Add("@CreatedBy", passwordModel.CreatedBy);

                connection.Open();
                result = connection.ExecuteScalar<string>("uspUpdateNewPassword", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }

        public string GetClientCodeByUserName(string UserID)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);

                result = connection.ExecuteScalar<string>("uspGetClientCodeByUserIdCore", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }


        public PasswordHistoryModel GetLastPasswords(string UserID, string ClientCode)
        {
            PasswordHistoryModel passwordHistoryModel = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                param.Add("@ClientCode", ClientCode);

                List<PasswordHistoryModel> PwdList = connection.Query<PasswordHistoryModel>("spGetLastPasswords", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (PwdList != null && PwdList.Count > 0)
                {
                    passwordHistoryModel = PwdList[0];
                }
            }

            if (passwordHistoryModel == null)
            {
                passwordHistoryModel = new PasswordHistoryModel();
            }

            return passwordHistoryModel;
        }

        public string CheckUserId(string UserID, string ClientID)
        {
            string output = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                param.Add("@ClientID", ClientID);

                output = connection.ExecuteScalar<string>("Usp_CheckUserID_Core", param, commandType: System.Data.CommandType.StoredProcedure);

                if (output == null)
                {
                    output = string.Empty;
                }

            }
            return output;
        }

        public UpdateDetailsModel GetUserDetail(string UserID)
        {
            UpdateDetailsModel userDetailsModel = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID); 

                List<UpdateDetailsModel> userList = connection.Query<UpdateDetailsModel>("Usp_GetUserDetails_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (userList != null && userList.Count > 0)
                {
                    userDetailsModel = userList[0];
                }
            }

            if (userDetailsModel == null)
            {
                userDetailsModel = new UpdateDetailsModel();
            }

            return userDetailsModel;
        }

        public UpdateDetailsModel GetUserData(UserFilterModel2 userModel)
        {
            UpdateDetailsModel userDetailsModel = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@Status", userModel.Status);
                param.Add("@UserID", userModel.UserID);

                List<UpdateDetailsModel> userList = connection.Query<UpdateDetailsModel>("uspGetUserDataCore", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (userList != null && userList.Count > 0)
                {
                    userDetailsModel = userList[0];
                }
            }

            if (userDetailsModel == null)
            {
                userDetailsModel = new UpdateDetailsModel();
            }

            return userDetailsModel;
        }


        public string UpdateUser(UpdateUserModel userDetailsModel)
        {
            string result = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@FirstName", userDetailsModel.FirstName);
                param.Add("@LastName", userDetailsModel.LastName);
                param.Add("@UserID", userDetailsModel.UserID); 
                param.Add("@RoleID", userDetailsModel.RoleID);
                param.Add("@BranchID", userDetailsModel.BranchID); 
                param.Add("@EmailID", userDetailsModel.EmailID);
                param.Add("@ContactNo", userDetailsModel.ContactNo); 
                result = connection.ExecuteScalar<string>("Usp_UpdateUser_Core", param, commandType: System.Data.CommandType.StoredProcedure);
            }


            return result;
        }

        public List<RoleAccessRightsModel> GetRoleAccessRights(RoleAccessList userDetailsModel)
        {
            List<RoleAccessRightsModel> RoleAccessRightsModelList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", userDetailsModel.ClientID);
                param.Add("@UserID", userDetailsModel.UserID);

                RoleAccessRightsModelList = connection.Query<RoleAccessRightsModel>("uspGetUserAccessRights_core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (RoleAccessRightsModelList == null)
            {
                RoleAccessRightsModelList = new List<RoleAccessRightsModel>();
            }

            return RoleAccessRightsModelList;
        }

        public int AssignRoleAccessRights(AssignRoleAccessModel assignRoleAccessRightsModel)
        {
            int result = 0;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@UserID", assignRoleAccessRightsModel.Username);
                param.Add("@ClientID", assignRoleAccessRightsModel.ClientID);
                param.Add("@Menustring", assignRoleAccessRightsModel.Menustring);
                param.Add("@Username", assignRoleAccessRightsModel.CreatedBy);
                connection.Open();
                result = connection.Execute("spAssignUserAccessRights", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public string GetUserEmailId(string UserID, string ClientID)
        {
            string output = string.Empty;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserID", UserID);
                param.Add("@ClientID", ClientID);

                output = connection.ExecuteScalar<string>("Usp_getUserEmailID_Core", param, commandType: System.Data.CommandType.StoredProcedure);

                if (output == null)
                {
                    output = string.Empty;
                }

            }
            return output;
        }

        public List<UserClientChannelModeDetails> GetUserChannelModeConfiguration(string ClientID, string UserId)
        {
            List<UserClientChannelModeDetails> ChannelDataList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", ClientID);
                param.Add("@UserId", UserId);

                ChannelDataList = connection.Query<UserClientChannelModeDetails>("uspGetUserChannelModeConfig", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ChannelDataList == null)
            {
                ChannelDataList = new List<UserClientChannelModeDetails>();
            }

            return ChannelDataList;
        }

        public List<UserChannelModeDetails> GetClientIDChannelModeConfiguration(RoleAccessList roleAccess)
        {
            List<UserChannelModeDetails> ChannelDataList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", roleAccess.ClientID);
                param.Add("@UserId", roleAccess.UserID);

                ChannelDataList = connection.Query<UserChannelModeDetails>("uspGetClientChannelModeGrid", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ChannelDataList == null)
            {
                ChannelDataList = new List<UserChannelModeDetails>();
            }

            return ChannelDataList;
        }

        public List<ClientBranchDetailsModel> GetClientBranches(RoleAccessList roleAccess)
        {
            List<ClientBranchDetailsModel> ChannelDataList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ClientID", roleAccess.ClientID);
                param.Add("@UserId", roleAccess.UserID);

                ChannelDataList = connection.Query<ClientBranchDetailsModel>("uspGetClientBranchGrid", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (ChannelDataList == null)
            {
                ChannelDataList = new List<ClientBranchDetailsModel>();
            }

            return ChannelDataList;
        }

        public string DeleteTempUser(ActionModel nModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@UserId", nModel.TrnID);
                param.Add("@CheckerId", nModel.UserName);
                param.Add("@Remarks", nModel.Remarks);
                param.Add("@Action", nModel.Action);

                result = connection.ExecuteScalar<string>("uspDeletetempUserCore", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public string EditApprovedUser(UserFilterModel2 userModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@CreatedBy", userModel.Status);
                param.Add("@UserID", userModel.UserID); 

                result = connection.ExecuteScalar<string>("usp_EditApprovedUser", param, commandType: System.Data.CommandType.StoredProcedure);
            } 

            return result;
        }


        public int AddUserChannelMode(UserClientChannelModeDetails channelModeDetail)
        {
            int rowsAffected = 0;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                var param = new DynamicParameters();
                param.Add("@ChannelID", channelModeDetail.ChannelID);
                param.Add("@UserId", channelModeDetail.UserID);
                param.Add("@ModeID", channelModeDetail.ModeID);
                param.Add("@ClientID", channelModeDetail.ClientID);
                param.Add("@Username", channelModeDetail.CreatedBy);

                rowsAffected = connection.Execute("uspUpdateUserChannelModeDetails", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return rowsAffected;
        }

        public int AddClientDetails(ClientConfigMaster objReg)
        {
            int result = 0;

            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();             

                 param.Add("@Mode", objReg.Mode);
                 param.Add("@ClientCode", objReg.ClientCode);
                 param.Add("@ClientName", objReg.ClientName);
                 param.Add("@Address", objReg.Address);
                 param.Add("@ContactNo", objReg.ContactNo);

                 param.Add("@EmailID", objReg.EmailID);
                 param.Add("@ConcernPerson", objReg.ConcernPerson);
                 param.Add("@CPEmailID", objReg.CPEmailID);
                 param.Add("@CPContactNo", objReg.CPContactNo);

                 param.Add("@IsBank", objReg.IsBank);
                 param.Add("@CountryID", objReg.CountryID);
                 param.Add("@CurrencyID", objReg.CurrencyID);
                 param.Add("@DomainID", objReg.DomainID);
                 param.Add("@ModuleID", objReg.ModuleID);

                 param.Add("@FTP_IP", objReg.FTP_IP);
                 param.Add("@FTPUserName", objReg.FTPUserName);
                 param.Add("@FTPPassword", objReg.FTPPassword);
                 param.Add("@FTPPort", objReg.FTPPort);

                 param.Add("@ClientLogo", objReg.ClientLogo);
                 param.Add("@UserLimit", objReg.UserLimit);
                 param.Add("@TerminalCount", objReg.TerminalCount);
                 param.Add("@ReportTime", objReg.ReportCutoffTime);
                 param.Add("@UserName", objReg.Createdby);
                 param.Add("@Colorcode", objReg.Colorcode);

                connection.Open();
                result = connection.Execute("spClientConfigMaster", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public string ActionTakenByChecker(ActionModel nModel)
        {
            string result = "";
            try
            {
                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    var param = new DynamicParameters();
                    param.Add("@UserId", nModel.TrnID);
                    param.Add("@CheckerId", nModel.UserName);
                    param.Add("@Remarks", nModel.Remarks);
                    param.Add("@Action", nModel.Action);

                    connection.Open();
                    result = connection.ExecuteScalar<string>("usp_UpdateUserStatusByChecker", param, commandType: System.Data.CommandType.StoredProcedure);
                }
                return result;
            }
            catch (Exception ex)
            {
                return result;
            }
        }

    }
}
