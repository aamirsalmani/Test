﻿using Microsoft.Extensions.Configuration;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Dapper;

namespace ASPTrace.Repository
{
    public class VendorRegRepository : IVendorReg
    {
        private readonly IConfiguration _configuration;
        private string _connectionString = string.Empty;
        public VendorRegRepository(IConfiguration configuration)
        {
            _configuration = configuration;

            string EMEK1 = _configuration.GetSection("AppSettings:EMekKey1").Value;
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            string EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            bool IsEncryption = System.Convert.ToBoolean(this._configuration.GetSection("AppSettings:IsEncryption").Value);

            _connectionString = IsEncryption ? Utility.AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMEK1, EMEK2) : _configuration.GetConnectionString("TraceConnection");
        }
        protected IDbConnection CreateConnection()
        {
            return new System.Data.SqlClient.SqlConnection(_connectionString);
        }

        public List<VendorRegModel> GetVendorReg()
        {
            List<VendorRegModel> VendorRegList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                VendorRegList = connection.Query<VendorRegModel>("UspGetVendorDetails_Core", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (VendorRegList == null)
            {
                VendorRegList = new List<VendorRegModel>();
            }
            return VendorRegList;
        }


       public string VendorRegAdd(VendorRegDetailsModel vendorRegDetailsModel)

        {
            string result = string.Empty;

                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", vendorRegDetailsModel.Mode);
                param.Add("@VendorID", vendorRegDetailsModel.VendorID);
                param.Add("@VendorName", vendorRegDetailsModel.VendorName);
                param.Add("@VendorTypeID", vendorRegDetailsModel.VendorTypeID);
                param.Add("@CreatedBy", vendorRegDetailsModel.CreatedBy);
                param.Add("@Vendor", vendorRegDetailsModel.Vendor);
                connection.Open();
               
                result = connection.ExecuteScalar<string>("spVendorMaster", param, commandType: System.Data.CommandType.StoredProcedure);
            }

            return result;
        }

        public List<VendorRegUpdateModel> GetVendorRegUpdateModel(VendorRegDetailsModel vendorRegDetailsModel)
        {
            List<VendorRegUpdateModel> VendorRegUpdateList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", vendorRegDetailsModel.Mode);
                param.Add("@VendorID", vendorRegDetailsModel.VendorID);
                param.Add("@VendorName", vendorRegDetailsModel.VendorName);
                param.Add("@VendorTypeID", vendorRegDetailsModel.VendorTypeID);
                param.Add("@CreatedBy", vendorRegDetailsModel.CreatedBy);
                param.Add("@Vendor", vendorRegDetailsModel.Vendor);

                connection.Open();
                VendorRegUpdateList = connection.Query<VendorRegUpdateModel>("spVendorMaster", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (VendorRegUpdateList == null)
            {
                VendorRegUpdateList = new List<VendorRegUpdateModel>();
            }
            return VendorRegUpdateList;
        }

        public VendorRegModel GetVendorDetails(int VendorID)
        {
            VendorRegModel vendorDetails = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {

                var param = new DynamicParameters();
                param.Add("@VendorID", VendorID);

                connection.Open();
                List<VendorRegModel> VendorList = connection.Query<VendorRegModel>("UspGetVendorData_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();

                if (VendorList != null && VendorList.Count > 0)
                {
                    vendorDetails = VendorList[0];
                }
            }

            if (vendorDetails == null)
            {
                vendorDetails = new VendorRegModel();
            }
            return vendorDetails;
        }


        public List<VendorRegDeleteModel> GetVendorRegDelete(VendorRegDetailsModel vendorRegDetailsModel)
        {
            List<VendorRegDeleteModel> VendorRegDeleteList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", vendorRegDetailsModel.Mode);
                param.Add("@VendorID", vendorRegDetailsModel.VendorID);
                

                connection.Open();
                VendorRegDeleteList = connection.Query<VendorRegDeleteModel>("UspDeleteVendorMaster_Core", param, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (VendorRegDeleteList == null)
            {
                VendorRegDeleteList = new List<VendorRegDeleteModel>();
            }
            return VendorRegDeleteList;
        }

        public string VendorRegDelete(VendorRegDeleteModel vendorRegDeleteModel)
        {
            string result = string.Empty;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                var param = new DynamicParameters();
                param.Add("@Mode", vendorRegDeleteModel.Mode);
                param.Add("@VendorID", Convert.ToInt32(vendorRegDeleteModel.VendorID));
                connection.Open();
                result = connection.ExecuteScalar<string>("UspDeleteVendorMaster_Core", param, commandType: System.Data.CommandType.StoredProcedure);
            }
            return result;
        }


        public List<VendorTypeModel> GetVendorType()
        {
            List<VendorTypeModel> VendorTypeList = null;
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                connection.Open();
                VendorTypeList = connection.Query<VendorTypeModel>("UspGetVendorType_Core", null, commandType: System.Data.CommandType.StoredProcedure).AsList();
            }

            if (VendorTypeList == null)
            {
                VendorTypeList = new List<VendorTypeModel>();
            }
            return VendorTypeList;
        }
    }
}
