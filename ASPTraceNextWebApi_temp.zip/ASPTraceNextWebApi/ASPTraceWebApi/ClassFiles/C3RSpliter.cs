﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using ImportData;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Utility;

namespace ASPTraceWebApi
{
    public enum enumCIT : int
    {
        SECURE_VALUE = 0,
        WSG = 1,
        CMS = 2,
        SIPL = 3,
        WBS = 4,
        HCMS = 5,
        SVIL = 6
    }
    public class C3RSpliter
    {
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
       // BulkImports bulkimports;
        public C3RSpliter(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
           // bulkimports = new BulkImports(_connectionString, " ", " ");
        }

        public DataTable SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("MSP", typeof(string));
            _DataTable.Columns.Add("FeederBranchAC", typeof(string));
            _DataTable.Columns.Add("FeederBranchID", typeof(string));
            _DataTable.Columns.Add("FeederBranchName", typeof(string));
            _DataTable.Columns.Add("LoadUnloadCRA", typeof(string));
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(DateTime));
            _DataTable.Columns.Add("OpeningBalance50", typeof(string));
            _DataTable.Columns.Add("OpeningBalance100", typeof(string));
            _DataTable.Columns.Add("OpeningBalance200", typeof(string));
            _DataTable.Columns.Add("OpeningBalance500", typeof(string));    //TYP
            _DataTable.Columns.Add("OpeningBalance1000", typeof(string));
            _DataTable.Columns.Add("OpeningBalance2000", typeof(string));
            _DataTable.Columns.Add("TotalOpeningBalance", typeof(string));


            _DataTable.Columns.Add("TotalDispensed50", typeof(string));
            _DataTable.Columns.Add("TotalDispensed100", typeof(string));
            _DataTable.Columns.Add("TotalDispensed200", typeof(string));   //TYP
            _DataTable.Columns.Add("TotalDispensed500", typeof(string));
            _DataTable.Columns.Add("TotalDispensed1000", typeof(string));
            _DataTable.Columns.Add("TotalDispensed2000", typeof(string));
            _DataTable.Columns.Add("TotalDispensed", typeof(string));


            _DataTable.Columns.Add("BalancebeforeEOD50", typeof(string));
            _DataTable.Columns.Add("BalancebeforeEOD100", typeof(string));
            _DataTable.Columns.Add("BalancebeforeEOD200", typeof(string));   //TYP
            _DataTable.Columns.Add("BalancebeforeEOD500", typeof(string));
            _DataTable.Columns.Add("BalancebeforeEOD1000", typeof(string));
            _DataTable.Columns.Add("BalancebeforeEOD2000", typeof(string));
            _DataTable.Columns.Add("TotalBalancebeforeEOD", typeof(string));



            _DataTable.Columns.Add("CashReplenishLoading50", typeof(string));
            _DataTable.Columns.Add("CashReplenishLoading100", typeof(string));
            _DataTable.Columns.Add("CashReplenishLoading200", typeof(string));   //TYP
            _DataTable.Columns.Add("CashReplenishLoading500", typeof(string));
            _DataTable.Columns.Add("CashReplenishLoading1000", typeof(string));
            _DataTable.Columns.Add("CashReplenishLoading2000", typeof(string));
            _DataTable.Columns.Add("TotalCashReplenishLoading", typeof(string));


            _DataTable.Columns.Add("CashbroughtBackUnloading50", typeof(string));
            _DataTable.Columns.Add("CashbroughtBackUnloading100", typeof(string));
            _DataTable.Columns.Add("CashbroughtBackUnloading200", typeof(string));   //TYP
            _DataTable.Columns.Add("CashbroughtBackUnloading500", typeof(string));
            _DataTable.Columns.Add("CashbroughtBackUnloading1000", typeof(string));
            _DataTable.Columns.Add("CashbroughtBackUnloading2000", typeof(string));
            _DataTable.Columns.Add("TotalCashbroughtBackUnloading", typeof(string));


            _DataTable.Columns.Add("BalanceafterEOD50", typeof(string));
            _DataTable.Columns.Add("BalanceafterEOD100", typeof(string));
            _DataTable.Columns.Add("BalanceafterEOD200", typeof(string));   //TYP
            _DataTable.Columns.Add("BalanceafterEOD500", typeof(string));
            _DataTable.Columns.Add("BalanceafterEOD1000", typeof(string));
            _DataTable.Columns.Add("BalanceafterEOD2000", typeof(string));
            _DataTable.Columns.Add("TotalBalanceafterEOD", typeof(string));



            _DataTable.Columns.Add("Overage50", typeof(string));
            _DataTable.Columns.Add("Overage100", typeof(string));
            _DataTable.Columns.Add("Overage200", typeof(string));   //TYP
            _DataTable.Columns.Add("Overage500", typeof(string));
            _DataTable.Columns.Add("Overage1000", typeof(string));
            _DataTable.Columns.Add("Overage2000", typeof(string));
            _DataTable.Columns.Add("TotalOverage", typeof(string));


            _DataTable.Columns.Add("Shortage50", typeof(string));
            _DataTable.Columns.Add("Shortage100", typeof(string));
            _DataTable.Columns.Add("Shortage200", typeof(string));   //TYP
            _DataTable.Columns.Add("Shortage500", typeof(string));
            _DataTable.Columns.Add("Shortage1000", typeof(string));
            _DataTable.Columns.Add("Shortage2000", typeof(string));
            _DataTable.Columns.Add("TotalShortage", typeof(string));


            _DataTable.Columns.Add("SwitchBalanceBeforeReplenish50", typeof(string));
            _DataTable.Columns.Add("SwitchBalanceBeforeReplenish100", typeof(string));
            _DataTable.Columns.Add("SwitchBalanceBeforeReplenish200", typeof(string));   //TYP
            _DataTable.Columns.Add("SwitchBalanceBeforeReplenish500", typeof(string));
            _DataTable.Columns.Add("SwitchBalanceBeforeReplenish1000", typeof(string));
            _DataTable.Columns.Add("SwitchBalanceBeforeReplenish2000", typeof(string));
            _DataTable.Columns.Add("TotalSwitchBalanceBeforeReplenish", typeof(string));

            _DataTable.Columns.Add("SwitchBalanceAfterReplenish50", typeof(string));
            _DataTable.Columns.Add("SwitchBalanceAfterReplenish100", typeof(string));
            _DataTable.Columns.Add("SwitchBalanceAfterReplenish200", typeof(string));   //TYP
            _DataTable.Columns.Add("SwitchBalanceAfterReplenish500", typeof(string));
            _DataTable.Columns.Add("SwitchBalanceAfterReplenish1000", typeof(string));
            _DataTable.Columns.Add("SwitchBalanceAfterReplenish2000", typeof(string));
            _DataTable.Columns.Add("TotalSwitchBalanceAfterReplenish", typeof(string));

            _DataTable.Columns.Add("LastTxnNo", typeof(string));
            _DataTable.Columns.Add("REMARKS", typeof(string));

            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;

            try
            {
                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
                string TERMINALID = string.Empty;
                string MSP = string.Empty;
                string FeederBranchAC = string.Empty;
                string FeederBranchID = string.Empty;

                string date = string.Empty;

                string time = string.Empty;

                DateTime TxnsDateTime;

                string FeederBranchName = string.Empty;
                string LoadUnloadCRA = string.Empty;

                string OpeningBalance50 = string.Empty;
                string OpeningBalance100 = string.Empty;
                string OpeningBalance200 = string.Empty;
                string OpeningBalance500 = string.Empty;
                string OpeningBalance1000 = string.Empty;
                string OpeningBalance2000 = string.Empty;
                string TotalOpeningBalance = string.Empty;

                string TotalDispensed50 = string.Empty;
                string TotalDispensed100 = string.Empty;
                string TotalDispensed200 = string.Empty;
                string TotalDispensed500 = string.Empty;
                string TotalDispensed1000 = string.Empty;
                string TotalDispensed2000 = string.Empty;
                string TotalDispensed = string.Empty;

                string BalancebeforeEOD50 = string.Empty;
                string BalancebeforeEOD100 = string.Empty;
                string BalancebeforeEOD200 = string.Empty;
                string BalancebeforeEOD500 = string.Empty;
                string BalancebeforeEOD1000 = string.Empty;
                string BalancebeforeEOD2000 = string.Empty;
                string TotalBalancebeforeEOD = string.Empty;


                string CashReplenishLoading50 = string.Empty;
                string CashReplenishLoading100 = string.Empty;
                string CashReplenishLoading200 = string.Empty;
                string CashReplenishLoading500 = string.Empty;
                string CashReplenishLoading1000 = string.Empty;
                string CashReplenishLoading2000 = string.Empty;
                string TotalCashReplenishLoading = string.Empty;

                string CashbroughtBackUnloading50 = string.Empty;
                string CashbroughtBackUnloading100 = string.Empty;
                string CashbroughtBackUnloading200 = string.Empty;
                string CashbroughtBackUnloading500 = string.Empty;
                string CashbroughtBackUnloading1000 = string.Empty;
                string CashbroughtBackUnloading2000 = string.Empty;
                string TotalCashbroughtBackUnloading = string.Empty;

                string BalanceafterEOD50 = string.Empty;
                string BalanceafterEOD100 = string.Empty;
                string BalanceafterEOD200 = string.Empty;
                string BalanceafterEOD500 = string.Empty;
                string BalanceafterEOD1000 = string.Empty;
                string BalanceafterEOD2000 = string.Empty;
                string TotalBalanceafterEOD = string.Empty;


                string Overage50 = string.Empty;
                string Overage100 = string.Empty;
                string Overage200 = string.Empty;
                string Overage500 = string.Empty;
                string Overage1000 = string.Empty;
                string Overage2000 = string.Empty;
                string TotalOverage = string.Empty;


                string Shortage50 = string.Empty;
                string Shortage100 = string.Empty;
                string Shortage200 = string.Empty;
                string Shortage500 = string.Empty;
                string Shortage1000 = string.Empty;
                string Shortage2000 = string.Empty;
                string TotalShortage = string.Empty;


                string SwitchBalanceBeforeReplenish50 = string.Empty;
                string SwitchBalanceBeforeReplenish100 = string.Empty;
                string SwitchBalanceBeforeReplenish200 = string.Empty;
                string SwitchBalanceBeforeReplenish500 = string.Empty;
                string SwitchBalanceBeforeReplenish1000 = string.Empty;
                string SwitchBalanceBeforeReplenish2000 = string.Empty;
                string TotalSwitchBalanceBeforeReplenish = string.Empty;


                string SwitchBalanceAfterReplenish50 = string.Empty;
                string SwitchBalanceAfterReplenish100 = string.Empty;
                string SwitchBalanceAfterReplenish200 = string.Empty;
                string SwitchBalanceAfterReplenish500 = string.Empty;
                string SwitchBalanceAfterReplenish1000 = string.Empty;
                string SwitchBalanceAfterReplenish2000 = string.Empty;
                string TotalSwitchBalanceAfterReplenish = string.Empty;


                string LastTxnNo = string.Empty;
                string REMARKS = string.Empty;



                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = "Provider = Microsoft.ACE.OLEDB.12.0;" +
                   "Data Source = " + path + "; Extended Properties=Excel 8.0;";
                // String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                //"Data Source=" + SwitchFilePath + ";Extended Properties=Excel 8.0;";
                string extension = Path.GetExtension(path);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + " ; Extended Properties =\"Excel 8.0;HDR=Yes;IMEX=1\";";
                        // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + SwitchFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = " + path + "; Extended Properties =\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        // connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + SwitchFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        break;
                }
                objConn = new OleDbConnection(connString);
                objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null); 

                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(dtexcelsheetname.Rows[0]["TABLE_NAME"]).Replace("'", "") + "]";


                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dtfillsheet1 = new DataTable();
                da.Fill(dtfillsheet1);

                objConn.Close();

                TotalCount = dtfillsheet1.Rows.Count;
                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {
                    try

                    {


                        TERMINALID = dtfillsheet1.Rows[i][1].ToString();
                        MSP = dtfillsheet1.Rows[i][2].ToString();
                        FeederBranchAC = dtfillsheet1.Rows[i][3].ToString();
                        FeederBranchID = dtfillsheet1.Rows[i][4].ToString().Trim();

                        FeederBranchName = dtfillsheet1.Rows[i][5].ToString();
                        LoadUnloadCRA = dtfillsheet1.Rows[i][6].ToString();
                        date = dtfillsheet1.Rows[i][7].ToString();
                        time = dtfillsheet1.Rows[i][8].ToString();
                        string timestamp = date.Substring(8, 2).ToString() + "-" + date.Substring(3, 2).ToString() + "-" + date.Substring(0, 2).ToString() + " " + time + ":" + "00";
                        DateTime _datetime = DateTime.ParseExact(timestamp, "yy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                        // TxnsDateTime = Convert.ToDateTime(dtfillsheet1.Rows[i][7].ToString());
                        OpeningBalance50 = dtfillsheet1.Rows[i][9].ToString();
                        OpeningBalance100 = dtfillsheet1.Rows[i][10].ToString();
                        OpeningBalance200 = dtfillsheet1.Rows[i][11].ToString();
                        OpeningBalance500 = dtfillsheet1.Rows[i][12].ToString(); //C
                        OpeningBalance1000 = dtfillsheet1.Rows[i][13].ToString(); //
                        OpeningBalance2000 = dtfillsheet1.Rows[i][14].ToString(); //R
                        TotalOpeningBalance = dtfillsheet1.Rows[i][15].ToString(); //

                        TotalDispensed50 = dtfillsheet1.Rows[i][16].ToString();  //
                        TotalDispensed100 = dtfillsheet1.Rows[i][17].ToString();
                        TotalDispensed200 = dtfillsheet1.Rows[i][18].ToString();
                        TotalDispensed500 = dtfillsheet1.Rows[i][19].ToString(); //C
                        TotalDispensed1000 = dtfillsheet1.Rows[i][20].ToString(); //
                        TotalDispensed2000 = dtfillsheet1.Rows[i][21].ToString(); //R
                        TotalDispensed = dtfillsheet1.Rows[i][22].ToString(); //

                        BalancebeforeEOD50 = dtfillsheet1.Rows[i][23].ToString();  //
                        BalancebeforeEOD100 = dtfillsheet1.Rows[i][24].ToString();
                        BalancebeforeEOD200 = dtfillsheet1.Rows[i][25].ToString();
                        BalancebeforeEOD500 = dtfillsheet1.Rows[i][26].ToString(); //C
                        BalancebeforeEOD1000 = dtfillsheet1.Rows[i][27].ToString(); //
                        BalancebeforeEOD2000 = dtfillsheet1.Rows[i][28].ToString(); //R
                        TotalBalancebeforeEOD = dtfillsheet1.Rows[i][29].ToString(); //

                        CashReplenishLoading50 = dtfillsheet1.Rows[i][30].ToString();  //
                        CashReplenishLoading100 = dtfillsheet1.Rows[i][31].ToString();
                        CashReplenishLoading200 = dtfillsheet1.Rows[i][32].ToString();
                        CashReplenishLoading500 = dtfillsheet1.Rows[i][33].ToString(); //C
                        CashReplenishLoading1000 = dtfillsheet1.Rows[i][34].ToString(); //
                        CashReplenishLoading2000 = dtfillsheet1.Rows[i][35].ToString(); //R
                        TotalCashReplenishLoading = dtfillsheet1.Rows[i][36].ToString(); //

                        CashbroughtBackUnloading50 = dtfillsheet1.Rows[i][37].ToString();  //
                        CashbroughtBackUnloading100 = dtfillsheet1.Rows[i][38].ToString();
                        CashbroughtBackUnloading200 = dtfillsheet1.Rows[i][39].ToString();
                        CashbroughtBackUnloading500 = dtfillsheet1.Rows[i][40].ToString(); //C
                        CashbroughtBackUnloading1000 = dtfillsheet1.Rows[i][41].ToString(); //
                        CashbroughtBackUnloading2000 = dtfillsheet1.Rows[i][42].ToString(); //R
                        TotalCashbroughtBackUnloading = dtfillsheet1.Rows[i][43].ToString(); //



                        BalanceafterEOD50 = dtfillsheet1.Rows[i][44].ToString();  //
                        BalanceafterEOD100 = dtfillsheet1.Rows[i][45].ToString();
                        BalanceafterEOD200 = dtfillsheet1.Rows[i][46].ToString();
                        BalanceafterEOD500 = dtfillsheet1.Rows[i][47].ToString(); //C
                        BalanceafterEOD1000 = dtfillsheet1.Rows[i][48].ToString(); //
                        BalanceafterEOD2000 = dtfillsheet1.Rows[i][49].ToString(); //R
                        TotalBalanceafterEOD = dtfillsheet1.Rows[i][50].ToString(); //

                        Overage50 = dtfillsheet1.Rows[i][51].ToString();  //
                        Overage100 = dtfillsheet1.Rows[i][52].ToString();
                        Overage200 = dtfillsheet1.Rows[i][53].ToString();
                        Overage500 = dtfillsheet1.Rows[i][54].ToString(); //C
                        Overage1000 = dtfillsheet1.Rows[i][55].ToString(); //
                        Overage2000 = dtfillsheet1.Rows[i][56].ToString(); //R
                        TotalOverage = dtfillsheet1.Rows[i][57].ToString(); //

                        Shortage50 = dtfillsheet1.Rows[i][58].ToString();  //
                        Shortage100 = dtfillsheet1.Rows[i][59].ToString();
                        Shortage200 = dtfillsheet1.Rows[i][60].ToString();
                        Shortage500 = dtfillsheet1.Rows[i][61].ToString(); //C
                        Shortage1000 = dtfillsheet1.Rows[i][62].ToString(); //
                        Shortage2000 = dtfillsheet1.Rows[i][63].ToString(); //R
                        TotalShortage = dtfillsheet1.Rows[i][64].ToString(); //

                        SwitchBalanceBeforeReplenish50 = dtfillsheet1.Rows[i][65].ToString();  //
                        SwitchBalanceBeforeReplenish100 = dtfillsheet1.Rows[i][66].ToString();
                        SwitchBalanceBeforeReplenish200 = dtfillsheet1.Rows[i][67].ToString();
                        SwitchBalanceBeforeReplenish500 = dtfillsheet1.Rows[i][68].ToString(); //C
                        SwitchBalanceBeforeReplenish1000 = dtfillsheet1.Rows[i][69].ToString(); //
                        SwitchBalanceBeforeReplenish2000 = dtfillsheet1.Rows[i][70].ToString(); //R
                        TotalSwitchBalanceBeforeReplenish = dtfillsheet1.Rows[i][71].ToString(); //

                        SwitchBalanceAfterReplenish50 = dtfillsheet1.Rows[i][72].ToString();  //
                        SwitchBalanceAfterReplenish100 = dtfillsheet1.Rows[i][73].ToString();
                        SwitchBalanceAfterReplenish200 = dtfillsheet1.Rows[i][74].ToString();
                        SwitchBalanceAfterReplenish500 = dtfillsheet1.Rows[i][75].ToString(); //C
                        SwitchBalanceAfterReplenish1000 = dtfillsheet1.Rows[i][76].ToString(); //
                        SwitchBalanceAfterReplenish2000 = dtfillsheet1.Rows[i][77].ToString(); //R
                        TotalSwitchBalanceAfterReplenish = dtfillsheet1.Rows[i][78].ToString(); //

                        LastTxnNo = dtfillsheet1.Rows[i][79].ToString();  //AgentType2
                        REMARKS = dtfillsheet1.Rows[i][80].ToString();  //AgentType2



                        _DataTable.Rows.Add(ClientID, TERMINALID, MSP, FeederBranchAC, FeederBranchID, FeederBranchName, LoadUnloadCRA, _datetime, OpeningBalance50, OpeningBalance100, OpeningBalance200, OpeningBalance500, OpeningBalance1000
                                       , OpeningBalance2000, TotalOpeningBalance, TotalDispensed50, TotalDispensed100, TotalDispensed200, TotalDispensed500, TotalDispensed1000, TotalDispensed2000
                                        , TotalDispensed, BalancebeforeEOD50, BalancebeforeEOD100, BalancebeforeEOD200, BalancebeforeEOD500, BalancebeforeEOD1000, BalancebeforeEOD2000, TotalBalancebeforeEOD
                                       , CashReplenishLoading50, CashReplenishLoading100, CashReplenishLoading200, CashReplenishLoading500, CashReplenishLoading1000, CashReplenishLoading2000
                                        , TotalCashReplenishLoading, CashbroughtBackUnloading50, CashbroughtBackUnloading100, CashbroughtBackUnloading200, CashbroughtBackUnloading500, CashbroughtBackUnloading1000, CashbroughtBackUnloading2000
                                       , TotalCashbroughtBackUnloading, BalanceafterEOD50, BalanceafterEOD100, BalanceafterEOD200, BalanceafterEOD500, BalanceafterEOD1000, BalanceafterEOD2000
                                       , TotalBalanceafterEOD, Overage50, Overage100, Overage200, Overage500, Overage1000, Overage2000, TotalOverage, Shortage50, Shortage100, Shortage200, Shortage500, Shortage1000, Shortage2000, TotalShortage
                                       , SwitchBalanceBeforeReplenish50, SwitchBalanceBeforeReplenish100, SwitchBalanceBeforeReplenish200, SwitchBalanceBeforeReplenish500, SwitchBalanceBeforeReplenish1000, SwitchBalanceBeforeReplenish2000, TotalSwitchBalanceBeforeReplenish
                                        , SwitchBalanceAfterReplenish50, SwitchBalanceAfterReplenish100, SwitchBalanceAfterReplenish200, SwitchBalanceAfterReplenish500, SwitchBalanceAfterReplenish1000, SwitchBalanceAfterReplenish2000, TotalSwitchBalanceAfterReplenish
                                        , LastTxnNo, REMARKS, System.DateTime.Now, System.DateTime.Now, UserName, UserName);

                        LineNo++;
                        TotalCount++;
                        InsertCount++;

                        TERMINALID = string.Empty;
                        MSP = string.Empty;
                        FeederBranchAC = string.Empty;
                        FeederBranchID = string.Empty;
                        FeederBranchName = string.Empty;
                        LoadUnloadCRA = string.Empty;

                        OpeningBalance50 = string.Empty;
                        OpeningBalance100 = string.Empty;
                        OpeningBalance200 = string.Empty;
                        OpeningBalance500 = string.Empty;
                        OpeningBalance1000 = string.Empty;
                        OpeningBalance2000 = string.Empty;
                        TotalOpeningBalance = string.Empty;
                        TotalDispensed50 = string.Empty;
                        TotalDispensed100 = string.Empty;
                        TotalDispensed200 = string.Empty;
                        TotalDispensed500 = string.Empty;
                        TotalDispensed1000 = string.Empty;
                        TotalDispensed2000 = string.Empty;
                        TotalDispensed = string.Empty;
                        BalancebeforeEOD50 = string.Empty;
                        BalancebeforeEOD100 = string.Empty;
                        BalancebeforeEOD200 = string.Empty;
                        BalancebeforeEOD500 = string.Empty;
                        BalancebeforeEOD1000 = string.Empty;
                        BalancebeforeEOD2000 = string.Empty;
                        TotalBalancebeforeEOD = string.Empty;
                        CashReplenishLoading50 = string.Empty;
                        CashReplenishLoading100 = string.Empty;
                        CashReplenishLoading200 = string.Empty;
                        CashReplenishLoading500 = string.Empty;
                        CashReplenishLoading1000 = string.Empty;
                        CashReplenishLoading2000 = string.Empty;
                        TotalCashReplenishLoading = string.Empty;
                        CashbroughtBackUnloading50 = string.Empty;
                        CashbroughtBackUnloading100 = string.Empty;
                        CashbroughtBackUnloading200 = string.Empty;
                        CashbroughtBackUnloading500 = string.Empty;
                        CashbroughtBackUnloading1000 = string.Empty;
                        CashbroughtBackUnloading2000 = string.Empty;
                        TotalCashbroughtBackUnloading = string.Empty;
                        BalanceafterEOD50 = string.Empty;
                        BalanceafterEOD100 = string.Empty;
                        BalanceafterEOD200 = string.Empty;
                        BalanceafterEOD500 = string.Empty;
                        BalanceafterEOD1000 = string.Empty;
                        BalanceafterEOD2000 = string.Empty;
                        TotalBalanceafterEOD = string.Empty;
                        Overage50 = string.Empty;
                        Overage100 = string.Empty;
                        Overage200 = string.Empty;
                        Overage500 = string.Empty;
                        Overage1000 = string.Empty;
                        Overage2000 = string.Empty;
                        TotalOverage = string.Empty;
                        Shortage50 = string.Empty;
                        Shortage100 = string.Empty;
                        Shortage200 = string.Empty;
                        Shortage500 = string.Empty;
                        Shortage1000 = string.Empty;
                        Shortage2000 = string.Empty;
                        TotalShortage = string.Empty;
                        SwitchBalanceBeforeReplenish50 = string.Empty;
                        SwitchBalanceBeforeReplenish100 = string.Empty;
                        SwitchBalanceBeforeReplenish200 = string.Empty;
                        SwitchBalanceBeforeReplenish500 = string.Empty;
                        SwitchBalanceBeforeReplenish1000 = string.Empty;
                        SwitchBalanceBeforeReplenish2000 = string.Empty;
                        TotalSwitchBalanceBeforeReplenish = string.Empty;
                        SwitchBalanceAfterReplenish50 = string.Empty;
                        SwitchBalanceAfterReplenish100 = string.Empty;
                        SwitchBalanceAfterReplenish200 = string.Empty;
                        SwitchBalanceAfterReplenish500 = string.Empty;
                        SwitchBalanceAfterReplenish1000 = string.Empty;
                        SwitchBalanceAfterReplenish2000 = string.Empty;
                        TotalSwitchBalanceAfterReplenish = string.Empty;
                        LastTxnNo = string.Empty;
                        REMARKS = string.Empty;
                        InsertCount++;

                    }




                    catch (Exception ex)
                    {


                    }


                }




                if (_DataTable.Rows.Count == 0)
                {


                }

            }

            catch (Exception ex)
            {


            }
            //LineError = ErrorLine;
            //(LineNo - _DataTable.Rows.Count );
            return _DataTable;
        }

        public DataTable SplitData_FIS_SWAP(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            #region Declration & Initialisation of datatable and varables
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(DateTime));
            _DataTable.Columns.Add("BANK", typeof(string));
            _DataTable.Columns.Add("BANKLOCATION", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("LOCATION", typeof(string));
            _DataTable.Columns.Add("CASHFILLNO", typeof(string));
            _DataTable.Columns.Add("Machine_OPBALANCE", typeof(float));
            _DataTable.Columns.Add("Machine_DISPENSE", typeof(float));
            _DataTable.Columns.Add("Machine_REMANING", typeof(float));
            _DataTable.Columns.Add("Machine_LOADING", typeof(float));
            _DataTable.Columns.Add("Machine_CLOSING", typeof(float));
            _DataTable.Columns.Add("Machine_DIVERTED", typeof(float));
            _DataTable.Columns.Add("CASH_Removed", typeof(float));
            _DataTable.Columns.Add("Physical_CASSETTE", typeof(float));
            _DataTable.Columns.Add("Physical_REMANING", typeof(float));
            _DataTable.Columns.Add("Physical_LOADING", typeof(float));
            _DataTable.Columns.Add("Physical_CLOSING", typeof(float));
            _DataTable.Columns.Add("Switch_OPBALANCE", typeof(float));
            _DataTable.Columns.Add("Switch_DISPENSE", typeof(float));
            _DataTable.Columns.Add("Switch_REMANING", typeof(float));
            _DataTable.Columns.Add("Switch_LOADING", typeof(float));
            _DataTable.Columns.Add("Switch_CLOSING", typeof(float));
            _DataTable.Columns.Add("Switch_INCREASE", typeof(float));
            _DataTable.Columns.Add("Switch_DECREASE", typeof(float));
            _DataTable.Columns.Add("OVG", typeof(float));
            _DataTable.Columns.Add("SHTG", typeof(float));
            _DataTable.Columns.Add("PURGE_BIN", typeof(float));
            _DataTable.Columns.Add("CASH_DUMP", typeof(float));
            _DataTable.Columns.Add("PrevClosing", typeof(float));
            _DataTable.Columns.Add("REMARK", typeof(string));
            _DataTable.Columns.Add("IsSettled", typeof(int));
            _DataTable.Columns.Add("STATUS", typeof(string));
            _DataTable.Columns.Add("CashLoadSettledOn", typeof(DateTime));
            _DataTable.Columns.Add("CashLoadSettledAmount", typeof(float));
            _DataTable.Columns.Add("OVGSettledOn", typeof(DateTime));
            _DataTable.Columns.Add("OVGSettledAmount", typeof(float));
            _DataTable.Columns.Add("SHTGSettledOn", typeof(DateTime));
            _DataTable.Columns.Add("SHTGSettledAmount", typeof(float));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("Deno", typeof(string));
            _DataTable.Columns.Add("CIT", typeof(string));
            _DataTable.Columns.Add("IsSwap", typeof(bool));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("EOD", typeof(int));
            _DataTable.Columns.Add("MainRemark", typeof(string));
            _DataTable.Columns.Add("BitIsRemoved", typeof(int));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;


            string strFile = path;
            string sheetName = "Sheet1";
            string column = string.Empty;
            string value = string.Empty;
            DataTable dtexcelsheetname = null;
            DataSet dtexcelSet = new DataSet();

            DataTable dts = new DataTable(sheetName);

            string DBConnectionstring = string.Empty;

            try
            {
                string strConnectionString = ""; 

                string relativePath = _configuration["AppSettings:MekKey2Path"];
                AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
                AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim(); 


                bool IsEncryption = System.Convert.ToBoolean(_configuration.GetValue<string>("AppSettings:IsEncryption"));

                DBConnectionstring = IsEncryption ? AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), AesEncryption.EMEK1, AesEncryption.EMEK2) : _configuration.GetConnectionString("TraceConnection");

                strConnectionString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0 Xml;HDR=NO;IMEX=1'", strFile);

                OleDbConnection objConn = new OleDbConnection(strConnectionString);

                objConn.Open();

                //, new object[] { null, null, "Sheet1$" }
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                for (int i = 0; i < dtexcelsheetname.Rows.Count; i++)
                {

                    try
                    {
                        DataTable SHT = new DataTable();
                        sheetName = dtexcelsheetname.Rows[i]["TABLE_NAME"].ToString();  //.Replace("$","")
                        OleDbDataAdapter SQLAdapter = new OleDbDataAdapter();

                        string sql = "SELECT * FROM [" + sheetName + "]  ";

                        OleDbCommand selectCMD = new OleDbCommand(sql, objConn);

                        SQLAdapter.SelectCommand = selectCMD;

                        SQLAdapter.Fill(SHT);

                        objConn.Close();

                        dtexcelSet.Tables.Add(SHT);
                    }
                    catch (Exception ex)
                    {

                    }
                    finally
                    {
                        objConn.Close();
                    }



                }

            }
            catch (Exception ex)
            {

            }

            int Col_Machine_OPBALANCE_50 = 10;
            int Col_Machine_OPBALANCE_100 = 11;
            int Col_Machine_OPBALANCE_200 = 12;
            int Col_Machine_OPBALANCE_500 = 13;
            int Col_Machine_OPBALANCE_1000 = 14;
            int Col_Machine_OPBALANCE_2000 = 15;
            int Col_Machine_OPBALANCE_Total = 16;
            int Col_Machine_DISPENSE_50 = 17;
            int Col_Machine_DISPENSE_100 = 18;
            int Col_Machine_DISPENSE_200 = 19;
            int Col_Machine_DISPENSE_500 = 20;
            int Col_Machine_DISPENSE_1000 = 21;
            int Col_Machine_DISPENSE_2000 = 22;
            int Col_Machine_DISPENSE_Total = 23;
            int Col_Machine_REMANING_50 = 38;
            int Col_Machine_REMANING_100 = 39;
            int Col_Machine_REMANING_200 = 40;
            int Col_Machine_REMANING_500 = 41;
            int Col_Machine_REMANING_1000 = 42;
            int Col_Machine_REMANING_2000 = 43;
            int Col_Machine_REMANING_Total = 44;
            int Col_Machine_LOADING_50 = 45;
            int Col_Machine_LOADING_100 = 46;
            int Col_Machine_LOADING_200 = 47;
            int Col_Machine_LOADING_500 = 48;
            int Col_Machine_LOADING_1000 = 49;
            int Col_Machine_LOADING_2000 = 50;
            int Col_Machine_LOADING_Total = 51;
            int Col_Machine_CLOSING_50 = 59;
            int Col_Machine_CLOSING_100 = 60;
            int Col_Machine_CLOSING_200 = 61;
            int Col_Machine_CLOSING_500 = 62;
            int Col_Machine_CLOSING_1000 = 63;
            int Col_Machine_CLOSING_2000 = 64;
            int Col_Machine_CLOSING_Total = 65;
            int Col_Machine_DIVERTED_50 = 31;
            int Col_Machine_DIVERTED_100 = 32;
            int Col_Machine_DIVERTED_200 = 33;
            int Col_Machine_DIVERTED_500 = 34;
            int Col_Machine_DIVERTED_1000 = 35;
            int Col_Machine_DIVERTED_2000 = 36;
            int Col_Machine_DIVERTED_Total = 37;
            int Col_Cash_Removed_50 = 52;
            int Col_Cash_Removed_100 = 53;
            int Col_Cash_Removed_200 = 54;
            int Col_Cash_Removed_500 = 55;
            int Col_Cash_Removed_1000 = 56;
            int Col_Cash_Removed_2000 = 57;
            int Col_Cash_Removed_Total = 58;
            int Col_Physical_CASSETTE_50 = 66;
            int Col_Physical_CASSETTE_100 = 67;
            int Col_Physical_CASSETTE_200 = 68;
            int Col_Physical_CASSETTE_500 = 69;
            int Col_Physical_CASSETTE_1000 = 70;
            int Col_Physical_CASSETTE_2000 = 71;
            int Col_Physical_CASSETTE_Total = 72;
            int Col_Physical_REMANING_50 = 80;
            int Col_Physical_REMANING_100 = 81;
            int Col_Physical_REMANING_200 = 82;
            int Col_Physical_REMANING_500 = 83;
            int Col_Physical_REMANING_1000 = 84;
            int Col_Physical_REMANING_2000 = 85;
            int Col_Physical_REMANING_Total = 86;
            int Col_Physical_LOADING_50 = 94;
            int Col_Physical_LOADING_100 = 95;
            int Col_Physical_LOADING_200 = 96;
            int Col_Physical_LOADING_500 = 97;
            int Col_Physical_LOADING_1000 = 98;
            int Col_Physical_LOADING_2000 = 99;
            int Col_Physical_LOADING_Total = 100;
            int Col_Physical_CLOSING_50 = 101;
            int Col_Physical_CLOSING_100 = 102;
            int Col_Physical_CLOSING_200 = 103;
            int Col_Physical_CLOSING_500 = 104;
            int Col_Physical_CLOSING_1000 = 105;
            int Col_Physical_CLOSING_2000 = 106;
            int Col_Physical_CLOSING_Total = 107;
            int Col_Switch_OPBALANCE_50 = 108;
            int Col_Switch_OPBALANCE_100 = 109;
            int Col_Switch_OPBALANCE_200 = 110;
            int Col_Switch_OPBALANCE_500 = 111;
            int Col_Switch_OPBALANCE_1000 = 112;
            int Col_Switch_OPBALANCE_2000 = 113;
            int Col_Switch_OPBALANCE_Total = 108;
            int Col_Switch_DISPENSE_50 = 115;
            int Col_Switch_DISPENSE_100 = 116;
            int Col_Switch_DISPENSE_200 = 117;
            int Col_Switch_DISPENSE_500 = 118;
            int Col_Switch_DISPENSE_1000 = 119;
            int Col_Switch_DISPENSE_2000 = 120;
            int Col_Switch_DISPENSE_Total = 121;
            int Col_Switch_REMANING_50 = 122;
            int Col_Switch_REMANING_100 = 123;
            int Col_Switch_REMANING_200 = 124;
            int Col_Switch_REMANING_500 = 125;
            int Col_Switch_REMANING_1000 = 126;
            int Col_Switch_REMANING_2000 = 127;
            int Col_Switch_REMANING_Total = 128;
            int Col_Switch_LOADING_50 = 129;
            int Col_Switch_LOADING_100 = 130;
            int Col_Switch_LOADING_200 = 131;
            int Col_Switch_LOADING_500 = 132;
            int Col_Switch_LOADING_1000 = 133;
            int Col_Switch_LOADING_2000 = 134;
            int Col_Switch_LOADING_Total = 135;
            int Col_Switch_CLOSING_50 = 157;
            int Col_Switch_CLOSING_100 = 158;
            int Col_Switch_CLOSING_200 = 159;
            int Col_Switch_CLOSING_500 = 160;
            int Col_Switch_CLOSING_1000 = 161;
            int Col_Switch_CLOSING_2000 = 162;
            int Col_Switch_CLOSING_Total = 163;
            int Col_OVG_50 = 164;
            int Col_OVG_100 = 165;
            int Col_OVG_200 = 166;
            int Col_OVG_500 = 167;
            int Col_OVG_1000 = 168;
            int Col_OVG_2000 = 169;
            int Col_OVG_Total = 170;
            int Col_SHTG_50 = 171;
            int Col_SHTG_100 = 172;
            int Col_SHTG_200 = 173;
            int Col_SHTG_500 = 174;
            int Col_SHTG_1000 = 175;
            int Col_SHTG_2000 = 176;
            int Col_SHTG_Total = 177;
            int Col_Switch_INCREASE_50 = 129;
            int Col_Switch_INCREASE_100 = 130;
            int Col_Switch_INCREASE_200 = 131;
            int Col_Switch_INCREASE_500 = 132;
            int Col_Switch_INCREASE_1000 = 133;
            int Col_Switch_INCREASE_2000 = 134;
            int Col_Switch_INCREASE_Total = 135;
            int Col_Switch_DECREASE_50 = 136;
            int Col_Switch_DECREASE_100 = 137;
            int Col_Switch_DECREASE_200 = 138;
            int Col_Switch_DECREASE_500 = 139;
            int Col_Switch_DECREASE_1000 = 140;
            int Col_Switch_DECREASE_2000 = 141;
            int Col_Switch_DECREASE_Total = 142;
            int Col_PURGE_BIN_50 = 31;
            int Col_PURGE_BIN_100 = 32;
            int Col_PURGE_BIN_200 = 33;
            int Col_PURGE_BIN_500 = 34;
            int Col_PURGE_BIN_1000 = 35;
            int Col_PURGE_BIN_2000 = 36;
            int Col_PURGE_BIN_Total = 37;
            int Col_REMARK = 7;
            int Col_LOCATION = 8;
            int Col_Status = 178;
            int Col_CIT = 9;

            Dictionary<string, int> columnPositions = new Dictionary<string, int>()
                            {
                            {"Col_Machine_OPBALANCE_50",10},
                            {"Col_Machine_OPBALANCE_100",11},
                            {"Col_Machine_OPBALANCE_200",12},
                            {"Col_Machine_OPBALANCE_500",13},
                            {"Col_Machine_OPBALANCE_1000",14},
                            {"Col_Machine_OPBALANCE_2000",15},
                            {"Col_Machine_OPBALANCE_Total",16},
                            {"Col_Machine_DISPENSE_50",17},
                            {"Col_Machine_DISPENSE_100",18},
                            {"Col_Machine_DISPENSE_200",19},
                            {"Col_Machine_DISPENSE_500",20},
                            {"Col_Machine_DISPENSE_1000",21},
                            {"Col_Machine_DISPENSE_2000",22},
                            {"Col_Machine_DISPENSE_Total",23},
                            {"Col_Machine_REMANING_50",38},
                            {"Col_Machine_REMANING_100",39},
                            {"Col_Machine_REMANING_200",40},
                            {"Col_Machine_REMANING_500",41},
                            {"Col_Machine_REMANING_1000",42},
                            {"Col_Machine_REMANING_2000",43},
                            {"Col_Machine_REMANING_Total",44},
                            {"Col_Machine_LOADING_50",45},
                            {"Col_Machine_LOADING_100",46},
                            {"Col_Machine_LOADING_200",47},
                            {"Col_Machine_LOADING_500",48},
                            {"Col_Machine_LOADING_1000",49},
                            {"Col_Machine_LOADING_2000",50},
                            {"Col_Machine_LOADING_Total",51},
                            {"Col_Machine_CLOSING_50",59},
                            {"Col_Machine_CLOSING_100",60},
                            {"Col_Machine_CLOSING_200",61},
                            {"Col_Machine_CLOSING_500",62},
                            {"Col_Machine_CLOSING_1000",63},
                            {"Col_Machine_CLOSING_2000",64},
                            {"Col_Machine_CLOSING_Total",65},
                            {"Col_Machine_DIVERTED_50",31},
                            {"Col_Machine_DIVERTED_100",32},
                            {"Col_Machine_DIVERTED_200",33},
                            {"Col_Machine_DIVERTED_500",34},
                            {"Col_Machine_DIVERTED_1000",35},
                            {"Col_Machine_DIVERTED_2000",36},
                            {"Col_Machine_DIVERTED_Total",37},
                            {"Col_Cash_Removed_50",52},
                            {"Col_Cash_Removed_100",53},
                            {"Col_Cash_Removed_200",54},
                            {"Col_Cash_Removed_500",55},
                            {"Col_Cash_Removed_1000",56},
                            {"Col_Cash_Removed_2000",57},
                            {"Col_Cash_Removed_Total",58},
                            {"Col_Physical_CASSETTE_50",66},
                            {"Col_Physical_CASSETTE_100",67},
                            {"Col_Physical_CASSETTE_200",68},
                            {"Col_Physical_CASSETTE_500",69},
                            {"Col_Physical_CASSETTE_1000",70},
                            {"Col_Physical_CASSETTE_2000",71},
                            {"Col_Physical_CASSETTE_Total",72},
                            {"Col_Physical_REMANING_50",80},
                            {"Col_Physical_REMANING_100",81},
                            {"Col_Physical_REMANING_200",82},
                            {"Col_Physical_REMANING_500",83},
                            {"Col_Physical_REMANING_1000",84},
                            {"Col_Physical_REMANING_2000",85},
                            {"Col_Physical_REMANING_Total",86},
                            {"Col_Physical_LOADING_50",94},
                            {"Col_Physical_LOADING_100",95},
                            {"Col_Physical_LOADING_200",96},
                            {"Col_Physical_LOADING_500",97},
                            {"Col_Physical_LOADING_1000",98},
                            {"Col_Physical_LOADING_2000",99},
                            {"Col_Physical_LOADING_Total",100},
                            {"Col_Physical_CLOSING_50",101},
                            {"Col_Physical_CLOSING_100",102},
                            {"Col_Physical_CLOSING_200",103},
                            {"Col_Physical_CLOSING_500",104},
                            {"Col_Physical_CLOSING_1000",105},
                            {"Col_Physical_CLOSING_2000",106},
                            {"Col_Physical_CLOSING_Total",107},
                            {"Col_Switch_OPBALANCE_50",108},
                            {"Col_Switch_OPBALANCE_100",109},
                            {"Col_Switch_OPBALANCE_200",110},
                            {"Col_Switch_OPBALANCE_500",111},
                            {"Col_Switch_OPBALANCE_1000",112},
                            {"Col_Switch_OPBALANCE_2000",113},
                            {"Col_Switch_OPBALANCE_Total",108},
                            {"Col_Switch_DISPENSE_50",115},
                            {"Col_Switch_DISPENSE_100",116},
                            {"Col_Switch_DISPENSE_200",117},
                            {"Col_Switch_DISPENSE_500",118},
                            {"Col_Switch_DISPENSE_1000",119},
                            {"Col_Switch_DISPENSE_2000",120},
                            {"Col_Switch_DISPENSE_Total",121},
                            {"Col_Switch_REMANING_50",122},
                            {"Col_Switch_REMANING_100",123},
                            {"Col_Switch_REMANING_200",124},
                            {"Col_Switch_REMANING_500",125},
                            {"Col_Switch_REMANING_1000",126},
                            {"Col_Switch_REMANING_2000",127},
                            {"Col_Switch_REMANING_Total",128},
                            {"Col_Switch_LOADING_50",129},
                            {"Col_Switch_LOADING_100",130},
                            {"Col_Switch_LOADING_200",131},
                            {"Col_Switch_LOADING_500",132},
                            {"Col_Switch_LOADING_1000",133},
                            {"Col_Switch_LOADING_2000",134},
                            {"Col_Switch_LOADING_Total",135},
                            {"Col_Switch_CLOSING_50",157},
                            {"Col_Switch_CLOSING_100",158},
                            {"Col_Switch_CLOSING_200",159},
                            {"Col_Switch_CLOSING_500",160},
                            {"Col_Switch_CLOSING_1000",161},
                            {"Col_Switch_CLOSING_2000",162},
                            {"Col_Switch_CLOSING_Total",163},
                            {"Col_OVG_50",164},
                            {"Col_OVG_100",165},
                            {"Col_OVG_200",166},
                            {"Col_OVG_500",167},
                            {"Col_OVG_1000",168},
                            {"Col_OVG_2000",169},
                            {"Col_OVG_Total",170},
                            {"Col_SHTG_50",171},
                            {"Col_SHTG_100",172},
                            {"Col_SHTG_200",173},
                            {"Col_SHTG_500",174},
                            {"Col_SHTG_1000",175},
                            {"Col_SHTG_2000",176},
                            {"Col_SHTG_Total",177},
                            {"Col_Switch_INCREASE_50",129},
                            {"Col_Switch_INCREASE_100",130},
                            {"Col_Switch_INCREASE_200",131},
                            {"Col_Switch_INCREASE_500",132},
                            {"Col_Switch_INCREASE_1000",133},
                            {"Col_Switch_INCREASE_2000",134},
                            {"Col_Switch_INCREASE_Total",135},
                            {"Col_Switch_DECREASE_50",136},
                            {"Col_Switch_DECREASE_100",137},
                            {"Col_Switch_DECREASE_200",138},
                            {"Col_Switch_DECREASE_500",139},
                            {"Col_Switch_DECREASE_1000",140},
                            {"Col_Switch_DECREASE_2000",141},
                            {"Col_Switch_DECREASE_Total",142},
                            {"Col_PURGE_BIN_50",31},
                            {"Col_PURGE_BIN_100",32},
                            {"Col_PURGE_BIN_200",33},
                            {"Col_PURGE_BIN_500",34},
                            {"Col_PURGE_BIN_1000",35},
                            {"Col_PURGE_BIN_2000",36},
                            {"Col_PURGE_BIN_Total",37}
                            };

            #region Declaration and intialisation for sheet columns

            DateTime? TR_TIMESTAMP = null;
            string BANK = string.Empty;
            string BANKLOCATION = string.Empty;
            string Col_Zone = string.Empty;
            string REGION = string.Empty;
            int Col_TerminalID = 4;
            int Col_PrevClosing = -1;
            string Col_Deno = string.Empty;
            string CIT = string.Empty;


            string TERMINALID = string.Empty;
            string LOCATION = string.Empty;
            string CASHFILLNO = string.Empty;
            double? Machine_OPBALANCE = 0;
            double? Machine_DISPENSE = 0;
            double? Machine_REMANING = 0;
            double? Machine_LOADING = 0;
            double? Machine_CLOSING = 0;
            double? Machine_DIVERTED = 0;
            double? CASH_Removed = 0;
            double? Prev_Machine_CLOSING = 0;
            double? Physical_CASSETTE = 0;
            double? Physical_REMANING = 0;
            double? Physical_LOADING = 0;
            double? Physical_CLOSING = 0;
            double? Switch_OPBALANCE = 0;
            double? Switch_DISPENSE = 0;
            double? Switch_REMANING = 0;
            double? Switch_LOADING = 0;
            double? Switch_CLOSING = 0;
            double? CASH_DUMP = 0;
            double? OVG = 0;
            double? SHTG = 0;
            double? Switch_INCREASE = 0;
            double? Switch_DECREASE = 0;
            double? PURGE_BIN = 0;
            string REMARK = string.Empty;
            int IsSettled = 0;
            int IsSwap = 0;
            DateTime? ABRGENERATED_DATE = null;
            string STATUS = string.Empty;
            string ABR_BATCHID = string.Empty;
            DateTime? CashLoadSettledOn = null;
            double? CashLoadSettledAmount = 0;
            DateTime? OVGSettledOn = null;
            double? OVGSettledAmount = 0;
            DateTime? SHTGSettledOn = null;
            double? SHTGSettledAmount = 0;
            string Deno = string.Empty;

            int EOD = 0;
            string MainRemark = string.Empty;
            int BitIsRemoved = 0;
            string date = string.Empty;
            string time = string.Empty;

            double? T_Machine_OPBALANCE = 0;
            double? T_Machine_DISPENSE = 0;
            double? T_Machine_REMANING = 0;
            double? T_Machine_LOADING = 0;
            double? T_Machine_CLOSING = 0;
            double? T_Machine_DIVERTED = 0;
            double? T_CASH_REMOVED = 0;
            double? T_Physical_REMANING = 0;
            double? T_Physical_CASSETTE = 0;
            double? T_OVG = 0;
            double? T_SHTG = 0;
            double? T_PURGE_BIN = 0;


            double? T_Switch_DISPENSE = 0;
            double? T_Switch_REMANING = 0;
            double? T_Switch_LOADING = 0;
            double? T_Switch_CLOSING = 0;

            double? T_Switch_OPBALANCE = 0;
            double? T_Physical_LOADING = 0;
            double? T_Physical_CLOSING = 0;
            #endregion

            try
            {


                
                int j = 0;
                #endregion

                for (int i = 0; i < dtexcelSet.Tables.Count; i++)
                {

                    DataTable dtSheet = dtexcelSet.Tables[i];
                    //////////////  Splitter/////////////
                    //if (dtSheet.Rows[0][6].ToString().Contains("UBI"))
                    {
                       
                        

                        //if (FileName.Contains("CMS")) { CIT = "CMS"; }
                        //else if ((FileName.Contains("Securevalue") || FileName.Contains("Secure"))) { CIT = "Securevalue"; } //SECUREVALUE
                        //else if ((FileName.Contains("WSG"))) { CIT = "WSG"; }
                        //else if ((FileName.Contains("SIPL"))) { CIT = "SIPL"; }
                        //else { CIT = "PPM"; }

                        if (dtSheet.Rows.Count > 1)
                        {

                            TR_TIMESTAMP = null;
                            BANK = string.Empty;
                            BANKLOCATION = string.Empty;
                            Col_Zone = string.Empty;
                            REGION = string.Empty;
                            Col_TerminalID = 4;
                            Col_PrevClosing = -1;
                            Col_Deno = string.Empty;
                            CIT = string.Empty;


                            TERMINALID = string.Empty;
                            LOCATION = string.Empty;
                            CASHFILLNO = string.Empty;
                            Machine_OPBALANCE = 0;
                            Machine_DISPENSE = 0;
                            Machine_REMANING = 0;
                            Machine_LOADING = 0;
                            Machine_CLOSING = 0;
                            Machine_DIVERTED = 0;
                            CASH_Removed = 0;
                            Prev_Machine_CLOSING = 0;
                            Physical_CASSETTE = 0;
                            Physical_REMANING = 0;
                            Physical_LOADING = 0;
                            Physical_CLOSING = 0;
                            Switch_OPBALANCE = 0;
                            Switch_DISPENSE = 0;
                            Switch_REMANING = 0;
                            Switch_LOADING = 0;
                            Switch_CLOSING = 0;
                            CASH_DUMP = 0;
                            OVG = 0;
                            SHTG = 0;
                            Switch_INCREASE = 0;
                            Switch_DECREASE = 0;
                            PURGE_BIN = 0;
                            REMARK = string.Empty;
                            IsSettled = 0;
                            IsSwap = 0;
                            ABRGENERATED_DATE = null;
                            STATUS = string.Empty;
                            ABR_BATCHID = string.Empty;
                            CashLoadSettledOn = null;
                            CashLoadSettledAmount = 0;
                            OVGSettledOn = null;
                            OVGSettledAmount = 0;
                            SHTGSettledOn = null;
                            SHTGSettledAmount = 0;
                            Deno = string.Empty;

                            EOD = 0;
                            MainRemark = string.Empty;
                            BitIsRemoved = 0;
                            date = string.Empty;
                            time = string.Empty;

                            T_Machine_OPBALANCE = 0;
                            T_Machine_DISPENSE = 0;
                            T_Machine_REMANING = 0;
                            T_Machine_LOADING = 0;
                            T_Machine_CLOSING = 0;
                            T_Machine_DIVERTED = 0;
                            T_CASH_REMOVED = 0;
                            T_Physical_REMANING = 0;
                            T_Physical_CASSETTE = 0;
                            T_OVG = 0;
                            T_SHTG = 0;
                            T_PURGE_BIN = 0;


                            T_Switch_DISPENSE = 0;
                            T_Switch_REMANING = 0;
                            T_Switch_LOADING = 0;
                            T_Switch_CLOSING = 0;

                            T_Switch_OPBALANCE = 0;
                            T_Physical_LOADING = 0;
                            T_Physical_CLOSING = 0;


                            BANK = "UBI";

                            TotalCount = dtSheet.Rows.Count;

                            for (int k = 1; k < dtSheet.Rows.Count; k++)
                            {

                                CASHFILLNO = k.ToString();
                                {
                                    try
                                    {
                                        if (BANK == "")
                                        {
                                            BANK = "UBI";
                                        }

                                        if (dtSheet.Rows[k][5].ToString() != "")
                                        {
                                            LOCATION = dtSheet.Rows[k][5].ToString() == "" ? LOCATION : dtSheet.Rows[k][5].ToString();

                                        }

                                        if (dtSheet.Rows[k][6].ToString() != "")
                                        {
                                            if (dtSheet.Rows[k][6].ToString() != "")
                                            {

                                                if (dtSheet.Rows[k][6].ToString().Contains(":"))
                                                {
                                                    time = dtSheet.Rows[k][6].ToString() == "" ? time : dtSheet.Rows[k][6].ToString();
                                                }

                                                if (Regex.Replace(time, "[A-Za-z]", "").Trim() == "")
                                                {
                                                    time = dtSheet.Rows[k][6].ToString();
                                                    CIT = dtSheet.Rows[k][8].ToString();
                                                }
                                            }
                                        }

                                        if (dtSheet.Rows[k][Col_TerminalID].ToString() != "")
                                        {
                                            TERMINALID = dtSheet.Rows[k][Col_TerminalID].ToString();
                                        }
                                        if (dtSheet.Rows[k][Col_CIT].ToString() != "")
                                        {
                                            CIT = dtSheet.Rows[k][Col_CIT].ToString();
                                        }

                                        if (dtSheet.Rows[k][3].ToString().Trim() != "" && dtSheet.Rows[k][3].ToString().Trim() != "G-DATE")
                                        {
                                            //date = dtSheet.Rows[k][3].ToString() == "" ? date : dtSheet.Rows[k][3].ToString();
                                            date = dtSheet.Rows[k][3].ToString().Replace("/", "-");
                                            //date = dtSheet.Rows[k][3].ToString() == "" ? date : dtSheet.Rows[k][3].ToString().Replace("/", "-");


                                            //DBLog.InsertLogs("DATE: " + date,  ClientCode,  "SplitterMaximusCBR.cs", "SplitData", LineNo, FileName, UserName, 'E', DBConnectionstring);


                                            try
                                            {
                                                date = DateTime.ParseExact(date, new[] { "dd-MMM-yy", "dd-MMM-yyyy", "dd-MM-yyyy", "dd-MM-yy HH:mm", "dd-MMM-yyyy HH:mm", "dd-MM-yyyy H:mm", "dd-MM-yyyy HH:mm", "dd-MM-yy HH:mm:ss", "dd-MMM-yyyy HH:mm:ss", "dd-MM-yyyy H:mm:ss", "dd-MM-yyyy HH:mm:ss" }, null, DateTimeStyles.None).Date.ToString("dd-MM-yyyy");
                                            }
                                            catch (Exception ex)
                                            {
                                                date = DateTime.ParseExact(date, new[] { "MM-dd-yy", "MMM-dd-yyyy", "MM-dd-yyyy", "MM-dd-yy HH:mm", "MMM-dd-yyyy HH:mm", "MM-dd-yyyy H:mm", "MM-dd-yyyy HH:mm", "MM-dd-yy HH:mm:ss", "MMM-dd-yyyy HH:mm:ss", "dd-MM-yyyy H:mm:ss", "dd-MM-yyyy HH:mm:ss" }, null, DateTimeStyles.None).Date.ToString("dd-MM-yyyy");
                                            }

                                        }
                                        if (!string.IsNullOrEmpty(TERMINALID) && !TERMINALID.Trim().Equals("ATM Id") && !TERMINALID.Trim().Equals("Particulars") && !TERMINALID.Trim().Equals("0"))
                                        {
                                            string dateTime = date + " " + time;
                                            if (dateTime.ToString().Trim() != "" && dateTime.ToString().Trim() != "G-DATE Time")
                                            {
                                                try
                                                {
                                                    TR_TIMESTAMP = DateTime.ParseExact(dateTime, new[] { "dd-MM-yy HH:mm", "dd-MMM-yyyy HH:mm", "dd-MM-yyyy H:mm", "dd-MM-yyyy HH:mm", "dd-MM-yy HH:mm:ss", "dd-MMM-yyyy HH:mm:ss", "dd-MM-yyyy H:mm:ss", "dd-MM-yyyy HH:mm:ss" }, null, DateTimeStyles.None);
                                                    //DBLog.InsertLogs("TR_TIMESTAMP: " + TR_TIMESTAMP, "NCR", "SplitterMaximusCBR.cs", "SplitData", LineNo, FileName, UserName, 'E', DBConnectionstring);
                                                }
                                                catch (Exception ex)
                                                {
                                                    TR_TIMESTAMP = Convert.ToDateTime(dateTime);

                                                }
                                            }

                                            BANKLOCATION = dtSheet.Rows[k][8].ToString() == "" ? BANKLOCATION : dtSheet.Rows[k][8].ToString();

                                            {
                                                List<string> denominations = new List<string>() { "100", "200", "500", "2000", "TOTAL" };
                                                foreach (string deno in denominations)
                                                {
                                                    foreach (KeyValuePair<string, int> kvp in columnPositions)
                                                    {
                                                        if (kvp.Key.EndsWith("_" + deno))
                                                        {

                                                            string columnName = kvp.Key;
                                                            int columnPosition = kvp.Value;

                                                            double columnValue = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][columnPosition]).Trim().Replace("-", "") == "" ? "0" :
                                                                Convert.ToString(dtSheet.Rows[k][columnPosition]).Trim().Replace("-", ""));


                                                            if (columnName.Contains("Col_Machine_OPBALANCE"))
                                                            {
                                                                Machine_OPBALANCE = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Machine_OPBALANCE += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Machine_REMANING"))
                                                            {
                                                                Machine_REMANING = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Machine_REMANING += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Machine_DISPENSE"))
                                                            {
                                                                Machine_DISPENSE = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Machine_DISPENSE += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Machine_LOADING"))
                                                            {
                                                                Machine_LOADING = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Machine_LOADING += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Machine_CLOSING"))
                                                            {
                                                                Machine_CLOSING = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Machine_CLOSING += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Machine_DIVERTED"))
                                                            {
                                                                Machine_DIVERTED = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Machine_DIVERTED += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Cash_Removed"))
                                                            {
                                                                CASH_Removed = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_CASH_REMOVED += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Physical_CASSETTE"))
                                                            {
                                                                Physical_CASSETTE = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Physical_CASSETTE += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Physical_REMANING"))
                                                            {
                                                                Physical_REMANING = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Physical_REMANING += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Physical_LOADING"))
                                                            {
                                                                Physical_LOADING = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Physical_LOADING += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Physical_CLOSING"))
                                                            {
                                                                Physical_CLOSING = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Physical_CLOSING += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Switch_OPBALANCE"))
                                                            {
                                                                Switch_OPBALANCE = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Switch_OPBALANCE += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Switch_DISPENSE"))
                                                            {
                                                                Switch_DISPENSE = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Switch_DISPENSE += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Switch_REMANING"))
                                                            {
                                                                Switch_REMANING = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Switch_REMANING += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Switch_LOADING"))
                                                            {
                                                                Switch_LOADING = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Switch_LOADING += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Switch_CLOSING"))
                                                            {
                                                                Switch_CLOSING = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_Switch_CLOSING += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_OVG"))
                                                            {
                                                                OVG = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_OVG += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_SHTG"))
                                                            {
                                                                SHTG = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_SHTG += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Switch_INCREASE"))
                                                            {
                                                                Switch_INCREASE = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) Switch_INCREASE += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_Switch_DECREASE"))
                                                            {
                                                                Switch_DECREASE = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) Switch_DECREASE += columnValue;
                                                            }
                                                            else if (columnName.Contains("Col_PURGE_BIN"))
                                                            {
                                                                PURGE_BIN = columnValue;
                                                                if (!deno.ToUpper().Equals("TOTAL")) T_PURGE_BIN += columnValue;
                                                            }
                                                        }
                                                    }
                                                    REMARK = Convert.ToString(dtSheet.Rows[k][Col_REMARK]).Equals(string.Empty) ? REMARK : Convert.ToString(dtSheet.Rows[k][Col_REMARK]);


                                                    IsSettled = 0;
                                                    STATUS = dtSheet.Rows[k][Col_Status].ToString().Trim() == "" ? STATUS : dtSheet.Rows[k][Col_Status].ToString().Trim();

                                                    EOD = 1;
                                                    BitIsRemoved = 0;

                                                    if (Convert.ToString(deno).ToUpper().Equals("TOTAL"))
                                                    {
                                                        Machine_OPBALANCE = T_Machine_OPBALANCE;
                                                        Machine_DISPENSE = T_Machine_DISPENSE;
                                                        Machine_REMANING = T_Machine_REMANING;
                                                        Machine_LOADING = T_Machine_LOADING;
                                                        Machine_LOADING = T_Machine_LOADING;
                                                        Machine_CLOSING = T_Machine_CLOSING;
                                                        Physical_REMANING = T_Physical_REMANING;


                                                        Physical_CASSETTE = T_Physical_CASSETTE;
                                                        Physical_LOADING = T_Physical_LOADING;
                                                        Physical_CLOSING = T_Physical_CLOSING;
                                                        OVG = T_OVG;
                                                        SHTG = T_SHTG;
                                                        PURGE_BIN = T_PURGE_BIN;
                                                        Switch_DISPENSE = T_Switch_DISPENSE;
                                                        Switch_REMANING = T_Switch_REMANING;
                                                        Switch_LOADING = T_Switch_LOADING;
                                                        Switch_CLOSING = T_Switch_CLOSING;
                                                        Switch_OPBALANCE = T_Switch_OPBALANCE;

                                                        Machine_DIVERTED = T_Machine_DIVERTED;
                                                        CASH_Removed = T_CASH_REMOVED;

                                                        T_Physical_CASSETTE = 0;
                                                        T_Machine_DIVERTED = 0;
                                                        T_CASH_REMOVED = 0;

                                                        T_Machine_OPBALANCE = 0;
                                                        T_Machine_DISPENSE = 0;
                                                        T_Machine_REMANING = 0;
                                                        T_Machine_LOADING = 0;
                                                        T_Machine_CLOSING = 0;
                                                        T_Physical_REMANING = 0;
                                                        T_Physical_LOADING = 0;
                                                        T_Physical_CLOSING = 0;
                                                        T_OVG = 0;
                                                        T_SHTG = 0;
                                                        T_PURGE_BIN = 0;
                                                        T_Switch_DISPENSE = 0;
                                                        T_Switch_REMANING = 0;
                                                        T_Switch_LOADING = 0;
                                                        T_Switch_CLOSING = 0;
                                                        T_Switch_OPBALANCE = 0;


                                                    }

                                                    _DataTable.Rows.Add(TR_TIMESTAMP, BANK, BANKLOCATION, TERMINALID, LOCATION, CASHFILLNO,
                                                        Machine_OPBALANCE, Machine_DISPENSE, Machine_REMANING, Machine_LOADING, Machine_CLOSING, Machine_DIVERTED, CASH_Removed,
                                                        Physical_CASSETTE, Physical_REMANING, Physical_LOADING, Physical_CLOSING, Switch_OPBALANCE, Switch_DISPENSE, Switch_REMANING, Switch_LOADING, Switch_CLOSING, Switch_INCREASE, Switch_DECREASE, OVG, SHTG, PURGE_BIN, CASH_DUMP, Prev_Machine_CLOSING, REMARK, IsSettled, STATUS, CashLoadSettledOn,
                                                        CashLoadSettledAmount, OVGSettledOn, OVGSettledAmount, SHTGSettledOn, SHTGSettledAmount, System.DateTime.Now, System.DateTime.Now, deno, CIT, IsSwap, FileName, EOD, MainRemark, BitIsRemoved);


                                                } 

                                                #region Reset datatable variables to 0
                                                Machine_OPBALANCE = 0;
                                                Machine_DISPENSE = 0;
                                                Machine_REMANING = 0;
                                                Machine_LOADING = 0;
                                                Machine_CLOSING = 0;
                                                Physical_REMANING = 0;
                                                Physical_LOADING = 0;
                                                Physical_CLOSING = 0;
                                                Switch_OPBALANCE = 0;
                                                Switch_DISPENSE = 0;
                                                Switch_REMANING = 0;
                                                Switch_LOADING = 0;
                                                Switch_CLOSING = 0;
                                                CASH_DUMP = 0;
                                                OVG = 0;
                                                SHTG = 0;
                                                Switch_INCREASE = 0;
                                                Switch_DECREASE = 0;
                                                PURGE_BIN = 0;
                                                IsSettled = 0;
                                                ABRGENERATED_DATE = null;
                                                CashLoadSettledOn = null;
                                                CashLoadSettledAmount = 0;
                                                OVGSettledOn = null;
                                                OVGSettledAmount = 0;
                                                SHTGSettledOn = null;
                                                SHTGSettledAmount = 0;
                                                if (Convert.ToString(Deno).ToUpper().Equals("TOTAL")) TERMINALID = string.Empty;
                                                Deno = string.Empty;
                                                EOD = 0;
                                                MainRemark = string.Empty;
                                                BitIsRemoved = 0;
                                                Prev_Machine_CLOSING = 0;

                                                #endregion

                                            }


                                        }
                                    }

                                    catch (Exception ex)
                                    {
                                        //DBLog.InsertLogs("CIT: " + CIT + " --> " + Convert.ToString(ex.Message) + "-" + ex.StackTrace.ToString(), "NCR", "SplitterMaximusCBR.cs", "SplitData", LineNo, FileName, UserName, 'E', DBConnectionstring);
                                    }
                                }


                                j++;
                            }
                        }
                        //break;
                    }

                }

            }
            catch (Exception ex)
            {
                DBLog.InsertLogs("FINAL CATCH" + ex.Message.ToString() + "-" + ex.StackTrace.ToString(), ClientCode, GetLocalIPAddress() , currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', DBConnectionstring);
               // DBLog.InsertLogs("FINAL CATCH" + ex.Message.ToString() + "-" + ex.StackTrace.ToString(), "NCR", "SplitterMaximusCBR.cs", "SplitData", LineNo, FileName, UserName, 'E', DBConnectionstring);
            }

            InsertCount = _DataTable.Rows.Count;

            return _DataTable;
        }

        public DataTable SplitData_FIS(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string BankId)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            #region Declration & Initialisation of datatable and varables
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(DateTime));
            _DataTable.Columns.Add("BANK", typeof(string));
            _DataTable.Columns.Add("BANKLOCATION", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("LOCATION", typeof(string));
            _DataTable.Columns.Add("CASHFILLNO", typeof(string));
            _DataTable.Columns.Add("M_OPBALANCE", typeof(float));
            _DataTable.Columns.Add("M_DISPENSE", typeof(float));
            _DataTable.Columns.Add("M_REMANING", typeof(float));
            _DataTable.Columns.Add("M_LOADING", typeof(float));
            _DataTable.Columns.Add("M_CLOSING", typeof(float));
            _DataTable.Columns.Add("P_REMANING", typeof(float));
            _DataTable.Columns.Add("P_LOADING", typeof(float));
            _DataTable.Columns.Add("P_CLOSING", typeof(float));
            _DataTable.Columns.Add("S_OPBALANCE", typeof(float));
            _DataTable.Columns.Add("S_DISPENSE", typeof(float));
            _DataTable.Columns.Add("S_REMANING", typeof(float));
            _DataTable.Columns.Add("S_LOADING", typeof(float));
            _DataTable.Columns.Add("S_CLOSING", typeof(float));
            _DataTable.Columns.Add("CASH_DUMP", typeof(float));
            _DataTable.Columns.Add("OVG", typeof(float));
            _DataTable.Columns.Add("SHTG", typeof(float));
            _DataTable.Columns.Add("S_INCREASE", typeof(float));
            _DataTable.Columns.Add("S_DECREASE", typeof(float));
            _DataTable.Columns.Add("PURGE_BIN", typeof(float));
            _DataTable.Columns.Add("REMARK", typeof(string));
            _DataTable.Columns.Add("IsSettled", typeof(int));
            _DataTable.Columns.Add("ABRGENERATED_DATE", typeof(DateTime));
            _DataTable.Columns.Add("STATUS", typeof(string));
            _DataTable.Columns.Add("CashLoadSettledOn", typeof(DateTime));
            _DataTable.Columns.Add("CashLoadSettledAmount", typeof(float));
            _DataTable.Columns.Add("OVGSettledOn", typeof(DateTime));
            _DataTable.Columns.Add("OVGSettledAmount", typeof(float));
            _DataTable.Columns.Add("SHTGSettledOn", typeof(DateTime));
            _DataTable.Columns.Add("SHTGSettledAmount", typeof(float));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("Deno", typeof(string));
            _DataTable.Columns.Add("CIT", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("EOD", typeof(int));
            _DataTable.Columns.Add("MainRemark", typeof(string));
            _DataTable.Columns.Add("BitIsRemoved", typeof(int));
            _DataTable.Columns.Add("PrevClosing", typeof(float));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0; 


            string strFile = path;
            string sheetName = "Sheet1";
            string column = string.Empty;
            string value = string.Empty;
            DataTable dtexcelsheetname = null;
            DataSet dtexcelSet = null;

            string DBConnectionstring = string.Empty;

            DataTable dtSheet = new DataTable(sheetName);



            try
            {
                string strConnectionString = ""; 

                bool IsEncryption = System.Convert.ToBoolean(_configuration.GetValue<string>("AppSettings:IsEncryption"));
                string EMekKey1 = _configuration["AppSettings:EMekKey1"];
                string relativePath = _configuration["AppSettings:MekKey2Path"];
                string EMekKey2 = File.ReadAllText(relativePath).Trim();

                DBConnectionstring = IsEncryption ? AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMekKey1, EMekKey2) : _configuration.GetConnectionString("TraceConnection");

                strConnectionString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0 Xml;HDR=NO;IMEX=1'", strFile);


                OleDbConnection objConn = new OleDbConnection(strConnectionString);

                objConn.Open();

                //, new object[] { null, null, "Sheet1$" }
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                sheetName = dtexcelsheetname.Rows[0]["TABLE_NAME"].ToString();  //.Replace("$","")
                OleDbDataAdapter SQLAdapter = new OleDbDataAdapter();

                string sql = "SELECT * FROM [" + sheetName + "]  ";

                OleDbCommand selectCMD = new OleDbCommand(sql, objConn);

                SQLAdapter.SelectCommand = selectCMD;

                SQLAdapter.Fill(dtSheet);

                objConn.Close();

            }

            catch (Exception e)
            {
                try
                {
                    String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                    OleDbConnection objConn = new OleDbConnection(connString);
                    string extension = Path.GetExtension(FileName);
                    switch (extension.ToLower())
                    {

                        case ".xls": //Excel 97-03
                            // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FileName + ";Extended Properties='Excel 8.0;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text'";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileName + ";Extended Properties='Excel 12.0;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text'";
                            break;

                    }

                    try
                    {
                        objConn = new OleDbConnection(connString);
                        objConn.Open();
                    }
                    catch
                    {
                        switch (extension.ToLower())
                        {


                            case ".xls": //Excel 97-03
                                connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FileName + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0\";";
                                break;
                            case ".xlsx": //Excel 07 or higher
                                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileName + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                                break;
                        }
                        objConn = new OleDbConnection(connString);
                        objConn.Open();
                    }

                    dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                    OleDbDataAdapter SQLAdapter = new OleDbDataAdapter();

                    string sql = "SELECT * FROM [" + sheetName + "$]  ";

                    OleDbCommand selectCMD = new OleDbCommand(sql, objConn);

                    SQLAdapter.SelectCommand = selectCMD;

                    SQLAdapter.Fill(dtSheet);

                    objConn.Close();
                }
                catch (Exception ex)
                {

                }



            }


            try
            {


                
                int j = 0;
                #endregion

                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    #region Fill sheet data in datatable
                    //excelSheets[j] = row["TABLE_NAME"].ToString();
                    //string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]) + "]";

                    //OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    //OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    //DataTable dtSheet = new DataTable();
                    //try
                    //{
                    //    da.Fill(dtSheet);
                    //    objConn.Close();
                    //}
                    //catch (Exception ex)
                    //{
                    //    objLogWriter.FunErrorLog(ex.Message.ToString() + "-" + ex.StackTrace.ToString(), "NCR", "SplitterMaximusCBR.cs", " objConn.Close()", LineNo, FileName, UserName, 'E');
                    //    objConn.Close();
                    //}

                    //// ----< To get total value with help of spread sheet >------//
                    //if (extension.ToLower().Equals(".xlsx"))
                    //    dtSheet = ExtractExcel(path, FileName);
                    #endregion


                    //////////////  Splitter/////////////
                    //if (dtSheet.Rows[0][6].ToString().Contains("UBI"))
                    {
                         
                       

                        //if (FileName.Contains("CMS")) { CIT = "CMS"; }
                        //else if ((FileName.Contains("Securevalue") || FileName.Contains("Secure"))) { CIT = "Securevalue"; } //SECUREVALUE
                        //else if ((FileName.Contains("WSG"))) { CIT = "WSG"; }
                        //else if ((FileName.Contains("SIPL"))) { CIT = "SIPL"; }
                        //else { CIT = "PPM"; }

                        if (dtSheet.Rows.Count > 1)
                        {
                            #region Declaration and intialisation for sheet columns
                            DateTime? TR_TIMESTAMP = null;
                            string BANK = string.Empty;
                            //CIT = "CMS";// !string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[1][14])) ? Convert.ToString(dtSheet.Rows[1][14]) : CIT; //-----< Added by Nelson 31-12-2021
                            BANK = "UBI";//!string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[1][9])) ? Convert.ToString(dtSheet.Rows[1][9]) : BANK; //-----< Added by Nelson 31-12-2021
                            string BANKLOCATION = string.Empty;
                            int Col_Zone = 2;
                            int Col_TerminalID = 3;
                            int Col_PrevClosing = 27;
                            int Col_Deno = 7;
                            int Col_M_OPBALANCE = 9;
                            int Col_M_DISPENSE = 11;
                            int Col_M_REMANING = 19;
                            int Col_M_LOADING = 21;
                            int Col_M_CLOSING = 23;
                            int Col_P_REMANING = -1;
                            int Col_P_LOADING = -1;
                            int Col_P_CLOSING = -1;
                            int Col_S_OPBALANCE = -1;
                            int Col_S_DISPENSE = -1;
                            int Col_S_REMANING = -1;
                            int Col_S_LOADING = -1;
                            int Col_S_CLOSING = -1;
                            int Col_CASH_DUMP = -1;
                            int Col_OVG = 15;
                            int Col_SHTG = 17;
                            int Col_S_INCREASE = -1;
                            int Col_S_DECREASE = -1;
                            int Col_PURGE_BIN = 13;
                            int Col_REMARK = 25;
                            int Col_Status = 28;

                            string TERMINALID = string.Empty;
                            string LOCATION = string.Empty;
                            string CASHFILLNO = string.Empty;
                            double? M_OPBALANCE = 0;
                            double? M_DISPENSE = 0;
                            double? M_REMANING = 0;
                            double? M_LOADING = 0;
                            double? M_CLOSING = 0;
                            double? Prev_M_CLOSING = 0;
                            double? P_REMANING = 0;
                            double? P_LOADING = 0;
                            double? P_CLOSING = 0;
                            double? S_OPBALANCE = 0;
                            double? S_DISPENSE = 0;
                            double? S_REMANING = 0;
                            double? S_LOADING = 0;
                            double? S_CLOSING = 0;
                            double? CASH_DUMP = 0;
                            double? OVG = 0;
                            double? SHTG = 0;
                            double? S_INCREASE = 0;
                            double? S_DECREASE = 0;
                            double? PURGE_BIN = 0;
                            string REMARK = string.Empty;
                            int IsSettled = 0;
                            DateTime? ABRGENERATED_DATE = null;
                            string STATUS = string.Empty;
                            string ABR_BATCHID = string.Empty;
                            DateTime? CashLoadSettledOn = null;
                            double? CashLoadSettledAmount = 0;
                            DateTime? OVGSettledOn = null;
                            double? OVGSettledAmount = 0;
                            DateTime? SHTGSettledOn = null;
                            double? SHTGSettledAmount = 0;
                            string Deno = string.Empty;

                            int EOD = 0;
                            string MainRemark = string.Empty;
                            int BitIsRemoved = 0;
                            string date = string.Empty;
                            string time = string.Empty;
                            string CIT = string.Empty;

                            double? T_M_OPBALANCE = 0;
                            double? T_M_DISPENSE = 0;
                            double? T_M_REMANING = 0;
                            double? T_M_LOADING = 0;
                            double? T_M_CLOSING = 0;
                            double? T_P_REMANING = 0;
                            double? T_OVG = 0;
                            double? T_SHTG = 0;
                            double? T_PURGE_BIN = 0;

                            double? T_S_DISPENSE = 0;
                            double? T_S_REMANING = 0;
                            double? T_S_LOADING = 0;
                            double? T_S_CLOSING = 0;

                            double? T_S_OPBALANCE = 0;
                            double? T_P_LOADING = 0;
                            double? T_P_CLOSING = 0;
                            #endregion

                            TotalCount = dtSheet.Rows.Count;

                            for (int k = 0; k < dtSheet.Rows.Count; k++)
                            {
                                LineNo++;
                                if (LineNo <= 3)
                                {
                                    if (dtSheet.Rows[k][0].ToString().ToUpper().Contains("DATE"))
                                    {
                                        date = dtSheet.Rows[k][1].ToString() == "" ? date : dtSheet.Rows[k][1].ToString();
                                        try
                                        {
                                            date = DateTime.ParseExact(date, new[] { "dd-MMM-yy", "dd-MMM-yyyy", "dd-MM-yyyy" }, null, DateTimeStyles.None).Date.ToString("dd-MM-yyyy");
                                        }
                                        catch (Exception ex)
                                        {
                                            date = Convert.ToDateTime(date).Date.ToString("dd-MM-yyyy");

                                        }

                                    }
                                    continue;
                                }

                                #region SECURE VALUE or CMS or WSG splitter

                                {
                                    try
                                    {
                                        //if (dtSheet.Rows[k][3].ToString().ToUpper().Contains("DATE"))
                                        //{
                                        //    date = dtSheet.Rows[k][4].ToString() == "" ? date : dtSheet.Rows[k][4].ToString();
                                        //}
                                        //if (dtSheet.Rows[k][9].ToString() != "")
                                        //{
                                        //    BANK = dtSheet.Rows[k][10].ToString() == "" ? date : dtSheet.Rows[k][10].ToString();
                                        //}
                                        if (BANK == "")
                                        {
                                            BANK = "UBI";
                                        }

                                        if (dtSheet.Rows[k][2].ToString() != "")
                                        {
                                            LOCATION = dtSheet.Rows[k][2].ToString() == "" ? LOCATION : dtSheet.Rows[k][2].ToString();
                                            //LOCATION = dtSheet.Rows[k][2].ToString() == "" ? LOCATION : dtSheet.Rows[k][2].ToString();
                                        }

                                        if (dtSheet.Rows[k][5].ToString() != "")
                                        {
                                            if (dtSheet.Rows[k][5].ToString() != "")//&& dtSheet.Rows[k][3].ToString() != "DATE"
                                            {
                                                //if (dtSheet.Rows[k][5].ToString().Contains(":"))
                                                //{
                                                //    double time1 = Convert.ToDouble(dtSheet.Rows[k][3]);
                                                //    double time2 = time1 * 24;
                                                //    int tt = (int)time2;
                                                //    time = Convert.ToString(tt + ":00");
                                                //}
                                                if (dtSheet.Rows[k][5].ToString().Contains(":"))
                                                {
                                                    time = dtSheet.Rows[k][5].ToString() == "" ? time : dtSheet.Rows[k][5].ToString();
                                                }
                                                //time = dtSheet.Rows[k][3].ToString() == "" && dtSheet.Rows[k][3].ToString() != "DATE" ? time : dtSheet.Rows[k][3].ToString();
                                                else
                                                {
                                                    time = dtSheet.Rows[k][5].ToString();
                                                }
                                                if (Regex.Replace(time, "[A-Za-z]", "").Trim() == "")
                                                {
                                                    time = dtSheet.Rows[k][6].ToString();
                                                    CIT = dtSheet.Rows[k][5].ToString();
                                                }
                                            }
                                        }
                                        if (dtSheet.Rows[k][Col_TerminalID].ToString() != "")
                                        {
                                            TERMINALID = dtSheet.Rows[k][Col_TerminalID].ToString();
                                        }
                                        //else //if (dtSheet.Rows[k][1].ToString() == "" && dtSheet.Rows[k - 1][5].ToString() == "Total" && dtSheet.Rows[k - 1][1].ToString() == "")
                                        //{
                                        //    TERMINALID = string.Empty;
                                        //    Deno = string.Empty;
                                        //}

                                        if (!string.IsNullOrEmpty(TERMINALID) && !TERMINALID.Trim().Equals("ATM Id") && !TERMINALID.Trim().Equals("Particulars") && !TERMINALID.Trim().Equals("0"))
                                        {
                                            //TR_TIMESTAMP = Convert.ToDateTime(date + " " + time);
                                            string dateTime = date + " " + time;
                                            try
                                            {
                                                TR_TIMESTAMP = DateTime.ParseExact(dateTime, new[] { "dd-MM-yy HH:mm", "dd-MMM-yyyy HH:mm", "dd-MM-yyyy H:mm", "dd-MM-yyyy HH:mm" }, null, DateTimeStyles.None);
                                            }
                                            catch
                                            {
                                                TR_TIMESTAMP = Convert.ToDateTime(dateTime);

                                            }

                                            //BANK = FileName.Substring(0, 3); //
                                            BANKLOCATION = dtSheet.Rows[k][Col_Zone].ToString() == "" ? BANKLOCATION : dtSheet.Rows[k][Col_Zone].ToString();

                                            //LOCATION = dtSheet.Rows[k][2].ToString() == "" ? LOCATION : dtSheet.Rows[k][2].ToString();
                                            Deno = dtSheet.Rows[k][Col_Deno].ToString();

                                            Prev_M_CLOSING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][Col_PrevClosing]).Trim().Replace("-", "") == "" ? "0" :
                                                Convert.ToString(dtSheet.Rows[k][Col_PrevClosing]).Trim().Replace("-", ""));

                                            #region Assigning denomnation wise counters from sheet datatable
                                            /////////////Journal//////////////
                                            M_OPBALANCE = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][Col_M_OPBALANCE]).Trim().Replace("-", "") == "" ? "0" :
                                                Convert.ToString(dtSheet.Rows[k][Col_M_OPBALANCE]).Trim().Replace("-", ""));
                                            if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_M_OPBALANCE += M_OPBALANCE;
                                            M_REMANING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][Col_M_REMANING]).Trim().Replace("-", "") == "" ? "0" :
                                                Convert.ToString(dtSheet.Rows[k][Col_M_REMANING]).Trim().Replace("-", ""));
                                            if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_M_REMANING += M_REMANING;
                                            //M_DISPENSE = M_OPBALANCE - M_REMANING;
                                            M_DISPENSE = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][Col_M_DISPENSE]).Trim().Replace("-", "") == "" ? "0" :
                                                Convert.ToString(dtSheet.Rows[k][Col_M_DISPENSE]).Trim().Replace("-", ""));
                                            if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_M_DISPENSE += M_DISPENSE;
                                            M_LOADING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][Col_M_LOADING]).Trim().Replace("-", "") == "" ? "0" :
                                                Convert.ToString(dtSheet.Rows[k][Col_M_LOADING]).Trim().Replace("-", ""));
                                            if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_M_LOADING += M_LOADING;
                                            M_CLOSING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][Col_M_CLOSING]).Trim().Replace("-", "") == "" ? "0" :
                                                Convert.ToString(dtSheet.Rows[k][Col_M_CLOSING]).Trim().Replace("-", ""));
                                            //M_CLOSING = M_REMANING + M_LOADING;
                                            if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_M_CLOSING += M_CLOSING;

                                            ///////////Physical////////////////
                                            //P_REMANING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][6]).Trim().Replace("-", "") == "" ? "0" :
                                            //    Convert.ToString(dtSheet.Rows[k][6]).Trim().Replace("-", ""));
                                            //if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_P_REMANING += P_REMANING;

                                            //P_LOADING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][9]).Trim().Replace("-", "") == "" ? "0" :
                                            //  Convert.ToString(dtSheet.Rows[k][9]).Trim().Replace("-", ""));
                                            //if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_P_LOADING += P_LOADING;

                                            //P_CLOSING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][10]).Trim().Replace("-", "") == "" ? "0" :
                                            //  Convert.ToString(dtSheet.Rows[k][10]).Trim().Replace("-", ""));
                                            //if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_P_CLOSING += P_CLOSING;

                                            /////////////Admin /////////////////
                                            //S_OPBALANCE = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][20]).Trim().Replace("-", "") == "" ? "0" :
                                            //    Convert.ToString(dtSheet.Rows[k][20]).Trim().Replace("-", ""));
                                            //if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_S_OPBALANCE += S_OPBALANCE;
                                            //S_DISPENSE = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][21]).Trim().Replace("-", "") == "" ? "0" :
                                            //    Convert.ToString(dtSheet.Rows[k][21]).Trim().Replace("-", ""));
                                            //if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_S_DISPENSE += S_DISPENSE;
                                            //S_REMANING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][22]).Trim().Replace("-", "") == "" ? "0" :
                                            //    Convert.ToString(dtSheet.Rows[k][22]).Trim().Replace("-", ""));
                                            //if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_S_REMANING += S_REMANING;

                                            //S_INCREASE = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][24]).Trim().Replace("-", "") == "" ? "0" :
                                            // Convert.ToString(dtSheet.Rows[k][24]).Trim().Replace("-", ""));
                                            //if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_S_CLOSING += S_CLOSING;

                                            //S_DECREASE = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][25]).Trim().Replace("-", "") == "" ? "0" :
                                            //  Convert.ToString(dtSheet.Rows[k][25]).Trim().Replace("-", ""));
                                            //if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_S_CLOSING += S_CLOSING;

                                            //S_CLOSING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][26]).Trim().Replace("-", "") == "" ? "0" :
                                            //    Convert.ToString(dtSheet.Rows[k][26]).Trim().Replace("-", ""));
                                            //if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_S_CLOSING += S_CLOSING;

                                            //S_LOADING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][28]).Trim().Replace("-", "") == "" ? "0" :
                                            //    Convert.ToString(dtSheet.Rows[k][28]).Trim().Replace("-", ""));
                                            //if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_S_LOADING += S_LOADING;

                                            OVG = dtSheet.Rows[k][Col_OVG].ToString().Trim().Replace("-", "") == "" ? OVG : Convert.ToDouble(dtSheet.Rows[k][Col_OVG].ToString().Trim().Replace("-", "") == "" ? "0" : dtSheet.Rows[k][Col_OVG].ToString().Trim().Replace("-", ""));
                                            if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_OVG += OVG;
                                            SHTG = dtSheet.Rows[k][Col_SHTG].ToString().Trim().Replace("-", "") == "" ? SHTG : Convert.ToDouble(dtSheet.Rows[k][Col_SHTG].ToString().Trim().Replace("-", "") == "" ? "0" : dtSheet.Rows[k][Col_SHTG].ToString().Trim().Replace("-", ""));
                                            if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_SHTG += SHTG;

                                            PURGE_BIN = dtSheet.Rows[k][Col_PURGE_BIN].ToString().Trim().Replace("-", "") == "" ? PURGE_BIN : Convert.ToDouble(dtSheet.Rows[k][Col_PURGE_BIN].ToString().Trim().Replace("-", "") == "" ? "0" : dtSheet.Rows[k][Col_PURGE_BIN].ToString().Trim().Replace("-", ""));
                                            if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL")) T_PURGE_BIN += PURGE_BIN;

                                            REMARK = Convert.ToString(dtSheet.Rows[k][Col_REMARK]).Equals(string.Empty) ? REMARK : Convert.ToString(dtSheet.Rows[k][Col_REMARK]);
                                            #endregion

                                            IsSettled = 0;
                                            STATUS = dtSheet.Rows[k][Col_Status].ToString().Trim() == "" ? STATUS : dtSheet.Rows[k][Col_Status].ToString().Trim();

                                            EOD = 1;
                                            BitIsRemoved = 0;

                                            if (Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                                            {
                                                M_OPBALANCE = T_M_OPBALANCE;
                                                M_DISPENSE = T_M_DISPENSE;
                                                M_REMANING = T_M_REMANING;
                                                M_LOADING = T_M_LOADING;
                                                M_CLOSING = T_M_CLOSING;
                                                P_REMANING = T_P_REMANING;

                                                P_LOADING = T_P_LOADING;
                                                P_CLOSING = T_P_CLOSING;
                                                OVG = T_OVG;
                                                SHTG = T_SHTG;
                                                PURGE_BIN = T_PURGE_BIN;
                                                S_DISPENSE = T_S_DISPENSE;
                                                S_REMANING = T_S_REMANING;
                                                S_LOADING = T_S_LOADING;
                                                S_CLOSING = T_S_CLOSING;
                                                S_OPBALANCE = T_S_OPBALANCE;

                                                T_M_OPBALANCE = 0;
                                                T_M_DISPENSE = 0;
                                                T_M_REMANING = 0;
                                                T_M_LOADING = 0;
                                                T_M_CLOSING = 0;
                                                T_P_REMANING = 0;
                                                T_P_LOADING = 0;
                                                T_P_CLOSING = 0;
                                                T_OVG = 0;
                                                T_SHTG = 0;
                                                T_PURGE_BIN = 0;
                                                T_S_DISPENSE = 0;
                                                T_S_REMANING = 0;
                                                T_S_LOADING = 0;
                                                T_S_CLOSING = 0;
                                                T_S_OPBALANCE = 0;

                                                //Deno = string.Empty;
                                            }

                                            _DataTable.Rows.Add(TR_TIMESTAMP, BANK, BANKLOCATION, TERMINALID, LOCATION, CASHFILLNO, M_OPBALANCE, M_DISPENSE, M_REMANING, M_LOADING, M_CLOSING,
                                                P_REMANING, P_LOADING, P_CLOSING, S_OPBALANCE, S_DISPENSE, S_REMANING, S_LOADING, S_CLOSING, CASH_DUMP, OVG, SHTG, S_INCREASE, S_DECREASE, PURGE_BIN, REMARK, IsSettled, ABRGENERATED_DATE, STATUS, CashLoadSettledOn,
                                                CashLoadSettledAmount, OVGSettledOn, OVGSettledAmount, SHTGSettledOn, SHTGSettledAmount, System.DateTime.Now, System.DateTime.Now, Deno, CIT, FileName, EOD, MainRemark, BitIsRemoved, Prev_M_CLOSING);
                                            InsertCount++;

                                            #region Reset datatable variables to 0
                                            M_OPBALANCE = 0;
                                            M_DISPENSE = 0;
                                            M_REMANING = 0;
                                            M_LOADING = 0;
                                            M_CLOSING = 0;
                                            P_REMANING = 0;
                                            P_LOADING = 0;
                                            P_CLOSING = 0;
                                            S_OPBALANCE = 0;
                                            S_DISPENSE = 0;
                                            S_REMANING = 0;
                                            S_LOADING = 0;
                                            S_CLOSING = 0;
                                            CASH_DUMP = 0;
                                            OVG = 0;
                                            SHTG = 0;
                                            S_INCREASE = 0;
                                            S_DECREASE = 0;
                                            PURGE_BIN = 0;
                                            IsSettled = 0;
                                            ABRGENERATED_DATE = null;
                                            CashLoadSettledOn = null;
                                            CashLoadSettledAmount = 0;
                                            OVGSettledOn = null;
                                            OVGSettledAmount = 0;
                                            SHTGSettledOn = null;
                                            SHTGSettledAmount = 0;
                                            if (Convert.ToString(Deno).ToUpper().Equals("TOTAL")) TERMINALID = string.Empty;
                                            Deno = string.Empty;
                                            EOD = 0;
                                            MainRemark = string.Empty;
                                            BitIsRemoved = 0;
                                            Prev_M_CLOSING = 0;

                                            #endregion
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        DBLog.InsertLogs("CIT: " + CIT + " --> " + Convert.ToString(ex.Message) + "-" + ex.StackTrace.ToString(), "NCR", GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', DBConnectionstring);
                                    }
                                }
                                #endregion

                                j++;
                            }
                        }
                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString() + "-" + ex.StackTrace.ToString(), "NCR", GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', DBConnectionstring);
            }
            return _DataTable;
        }
        public DataTable SplitData_INDUSIND_CMS(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            #region Declration & Initialisation of datatable and varables
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(DateTime));
            _DataTable.Columns.Add("CIT", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("Bank", typeof(string));
            _DataTable.Columns.Add("ATMLOCATION", typeof(string));
            _DataTable.Columns.Add("REMARK", typeof(string));
            _DataTable.Columns.Add("Deno", typeof(string));
            _DataTable.Columns.Add("M_OPBALANCE", typeof(float));
            _DataTable.Columns.Add("M_DISPENSE", typeof(float));
            _DataTable.Columns.Add("M_REMANING", typeof(float));
            _DataTable.Columns.Add("M_LOADING", typeof(float));
            _DataTable.Columns.Add("M_CLOSING", typeof(float));
            _DataTable.Columns.Add("P_REMANING", typeof(float));
            _DataTable.Columns.Add("P_LOADING", typeof(float));
            _DataTable.Columns.Add("P_CLOSING", typeof(float));
            _DataTable.Columns.Add("S_OPBALANCE", typeof(float));
            _DataTable.Columns.Add("S_DISPENSE", typeof(float));
            _DataTable.Columns.Add("S_REMANING", typeof(float));
            _DataTable.Columns.Add("S_LOADING", typeof(float));
            _DataTable.Columns.Add("S_CLOSING", typeof(float));
            _DataTable.Columns.Add("CASH_DUMP", typeof(float));
            _DataTable.Columns.Add("OVG", typeof(float));
            _DataTable.Columns.Add("SHTG", typeof(float)); 
            _DataTable.Columns.Add("PURGE_BIN", typeof(float)); 
            _DataTable.Columns.Add("Swap", typeof(string)); 

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;

            string BANKLOCATION = string.Empty;
            string TERMINALID = string.Empty;
            string LOCATION = string.Empty;
            string CASHFILLNO = string.Empty;
            double? M_OPBALANCE = 0;
            double? M_DISPENSE = 0;
            double? M_REMANING = 0;
            double? M_LOADING = 0;
            double? M_CLOSING = 0;
            double? P_REMANING = 0;
            double? P_LOADING = 0;
            double? P_CLOSING = 0;
            double? S_OPBALANCE = 0;
            double? S_DISPENSE = 0;
            double? S_REMANING = 0;
            double? S_LOADING = 0;
            double? S_CLOSING = 0;
            double? CASH_DUMP = 0;
            double? OVG = 0;
            double? SHTG = 0;
            double? S_INCREASE = 0;
            double? S_DECREASE = 0;
            double? PURGE_BIN = 0;
            string REMARK = string.Empty;
            int IsSettled = 0;
            DateTime? ABRGENERATED_DATE = null;
            string STATUS = string.Empty;
            string ABR_BATCHID = string.Empty;
            DateTime? CashLoadSettledOn = null;
            double? CashLoadSettledAmount = 0;
            DateTime? OVGSettledOn = null;
            double? OVGSettledAmount = 0;
            DateTime? SHTGSettledOn = null;
            double? SHTGSettledAmount = 0;
            string Deno = string.Empty;
            double? M_REMANING_Swap = 0;

            int EOD = 0;
            string MainRemark = string.Empty;
            int BitIsRemoved = 0;
            string time = string.Empty;

            double? T_M_OPBALANCE = 0;
            double? T_M_DISPENSE = 0;
            double? T_M_REMANING = 0;
            double? T_M_LOADING = 0;
            double? T_M_CLOSING = 0;
            double? T_OVG = 0;
            double? T_SHTG = 0;
            double? T_PURGE_BIN = 0;

            DateTime? TR_TIMESTAMP = null;
            string BANK = string.Empty;
            string date = string.Empty;

            string Swap = string.Empty;

            string CIT = string.Empty;
            int Cycle = 5, loop = 0;

            string SwappedTerminal = string.Empty;
            string SwappedDate = string.Empty;
            DataTable dsWriter = null;
            #endregion

            string Connectionstring = string.Empty; 

            try
            {
                bool IsEncryption = System.Convert.ToBoolean(_configuration.GetValue<string>("AppSettings:IsEncryption"));
                string EMekKey1 = _configuration["AppSettings:EMekKey1"];
                string relativePath = _configuration["AppSettings:MekKey2Path"];
                string EMekKey2 = File.ReadAllText(relativePath).Trim();

                Connectionstring = IsEncryption ? AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMekKey1, EMekKey2) : _configuration.GetConnectionString("TraceConnection");

                DataTable dtSheet = new DataTable();

                for (int sheet = 1; sheet <= 2; sheet++)
                {

                    if (sheet == 1)
                    {
                        Swap = "I";
                        dtSheet = ExtractExcel(path, FileName, 0);
                    }
                    else if (sheet == 2)
                    {
                        Swap = "II";
                        dtSheet = ExtractExcel(path, FileName, 1);
                        Cycle = 5; loop = 0;
                    }



                    TotalCount = TotalCount + dtSheet.Rows.Count;


                    if (FileName.Contains("CMS")) { CIT = "CMS"; }
                    else if ((FileName.Contains("WSG"))) { CIT = "WSG"; }
                    else if ((FileName.Contains("SIPL"))) { CIT = "SIPL"; }
                    else if ((FileName.Contains("SVIL"))) { CIT = "SVIL"; }

                    if (dtSheet.Rows.Count > 1)
                    {
                        #region Declaration and intialisation for sheet columns

                        date =
                            !string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[3][1]))
                            ? Convert.ToString(dtSheet.Rows[3][1])
                            : !string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[1][1]))
                            ? Convert.ToString(dtSheet.Rows[1][1])
                            : date;
                        CIT = !string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[4][1])) ? Convert.ToString(dtSheet.Rows[4][1]) : CIT;
                        BANK =
                            !string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[5][1]))
                            ? Convert.ToString(dtSheet.Rows[5][1])
                            : !string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[3][0]))
                            ? Convert.ToString(dtSheet.Rows[3][0]).Split(' ')[0]
                            : BANK;




                        #endregion

                        for (int k = 8; k < dtSheet.Rows.Count; k++)
                        {
                            LineNo++;

                            #region Reset datatable variables to 0
                            M_OPBALANCE = 0;
                            M_DISPENSE = 0;
                            M_REMANING = 0;
                            M_LOADING = 0;
                            M_CLOSING = 0;
                            P_REMANING = 0;
                            P_LOADING = 0;
                            P_CLOSING = 0;
                            S_OPBALANCE = 0;
                            S_DISPENSE = 0;
                            S_REMANING = 0;
                            S_LOADING = 0;
                            S_CLOSING = 0;
                            CASH_DUMP = 0;
                            OVG = 0;
                            SHTG = 0;
                            S_INCREASE = 0;
                            S_DECREASE = 0;
                            PURGE_BIN = 0;
                            IsSettled = 0;
                            ABRGENERATED_DATE = null;
                            CashLoadSettledOn = null;
                            CashLoadSettledAmount = 0;
                            OVGSettledOn = null;
                            OVGSettledAmount = 0;
                            SHTGSettledOn = null;
                            SHTGSettledAmount = 0;
                            if (Convert.ToString(Deno).ToUpper().Equals("TOTAL")) TERMINALID = string.Empty;
                            //if (Convert.ToString(Deno).ToUpper().Equals("TOTAL")) Cycle = 0;
                            if (Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                            {
                                T_M_OPBALANCE = 0;
                                T_M_DISPENSE = 0;
                                T_M_REMANING = 0;
                                T_M_LOADING = 0;
                                T_M_CLOSING = 0;
                                //T_P_REMANING = 0;
                                T_OVG = 0;
                                T_SHTG = 0;
                                T_PURGE_BIN = 0;
                            }

                            Deno = string.Empty;
                            EOD = 0;
                            MainRemark = string.Empty;
                            BitIsRemoved = 0;
                            SwappedTerminal = string.Empty;
                            #endregion

                            loop = loop == 6 ? 0 : loop;

                            #region CMS or SIPL splitter
                            if (
                                    (Convert.ToString(enumCIT.CMS).Equals(Convert.ToString(dtSheet.Rows[4][1]))
                                    || Convert.ToString(enumCIT.SIPL).Equals(Convert.ToString(dtSheet.Rows[4][1]))
                                    || Convert.ToString(enumCIT.SVIL).Equals(Convert.ToString(dtSheet.Rows[4][1]))
                                    )
                                    &&
                                    ((!string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k + Cycle][2]))
                                    && !Convert.ToString(dtSheet.Rows[k + Cycle][2]).Equals("0")
                                    )
                                    ||
                                    (!string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k - loop][3]))
                                    && !Convert.ToString(dtSheet.Rows[k - loop][3]).Equals("0")
                                    ))
                                )
                            {
                                try
                                {

                                    LOCATION = dtSheet.Rows[k + Cycle][1].ToString() == "" ? LOCATION : dtSheet.Rows[k + Cycle][1].ToString();

                                    TERMINALID = dtSheet.Rows[k + Cycle][2].ToString();

                                    BANKLOCATION = dtSheet.Rows[k + Cycle][3].ToString() == "" ? BANKLOCATION : dtSheet.Rows[k + Cycle][3].ToString();

                                    REMARK = Convert.ToString(dtSheet.Rows[k + Cycle][4]).Equals(string.Empty) ? REMARK : Convert.ToString(dtSheet.Rows[k + Cycle][4]);

                                    time = dtSheet.Rows[k + Cycle][5].ToString() == "" ? time : dtSheet.Rows[k + Cycle][5].ToString();



                                    Cycle = Cycle == 0 ? 6 : Cycle;

                                    TR_TIMESTAMP = Convert.ToDateTime(date + " " + time);

                                    Deno = dtSheet.Rows[k][6].ToString();                                   

                                    dsWriter = objCommon.GetTerminalSwappedDetail(ClientCode,TERMINALID);

                                    if (dsWriter != null && dsWriter.Rows.Count > 0)
                                    {
                                        SwappedTerminal = Convert.ToString(dsWriter.Rows[0]["Swapped"]);

                                        SwappedDate = Convert.ToString(dsWriter.Rows[0]["SwappedDate"]);
                                    }

                                    dsWriter = null;

                                    #region Assigning denomnation wise counters from sheet datatable

                                    M_OPBALANCE = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][7]).Trim().Replace("-", "") == "" ? "0" :
                                        Convert.ToString(dtSheet.Rows[k][7]).Trim().Replace("-", ""));
                                    if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                                    {
                                        M_OPBALANCE = M_OPBALANCE * Convert.ToDouble(Deno);
                                        T_M_OPBALANCE += M_OPBALANCE;
                                    }

                                    M_DISPENSE = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][9]).Trim().Replace("-", "") == "" ? "0" :
                                        Convert.ToString(dtSheet.Rows[k][9]).Trim().Replace("-", ""));
                                    if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                                    {
                                        M_DISPENSE = M_DISPENSE * Convert.ToDouble(Deno);
                                        T_M_DISPENSE += M_DISPENSE;
                                    }

                                    PURGE_BIN = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][11]).Trim().Replace("-", "") == "" ? "0" :
                                        Convert.ToString(dtSheet.Rows[k][11]).Trim().Replace("-", ""));
                                    if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                                    {
                                        PURGE_BIN = PURGE_BIN * Convert.ToDouble(Deno);
                                        T_PURGE_BIN += PURGE_BIN;
                                    }

                                    OVG = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][13]).Trim().Replace("-", "") == "" ? "0" :
                                        Convert.ToString(dtSheet.Rows[k][13]).Trim().Replace("-", ""));
                                    if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                                    {
                                        OVG = OVG * Convert.ToDouble(Deno);
                                        T_OVG += OVG;
                                    }

                                    SHTG = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][15]).Trim().Replace("-", "") == "" ? "0" :
                                        Convert.ToString(dtSheet.Rows[k][15]).Trim().Replace("-", ""));
                                    if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                                    {
                                        SHTG = SHTG * Convert.ToDouble(Deno);
                                        T_SHTG += SHTG;
                                    }

                                    //M_REMANING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][17]).Trim().Replace("-", "") == "" ? "0" :
                                    //    Convert.ToString(dtSheet.Rows[k][17]).Trim().Replace("-", ""));

                                    M_REMANING = M_OPBALANCE - M_DISPENSE + OVG - SHTG;
                                    if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                                    {
                                        //M_REMANING = M_REMANING * Convert.ToDouble(Deno);
                                        T_M_REMANING += M_REMANING;
                                    }

                                    M_LOADING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][19]).Trim() == "" ? "0" :
                                        Convert.ToString(dtSheet.Rows[k][19]).Trim().Trim(new[] { '(', ')' }));
                                    if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                                    {
                                        M_LOADING = M_LOADING * Convert.ToDouble(Deno);
                                        T_M_LOADING += M_LOADING;
                                    }

                                    //M_CLOSING = Convert.ToDouble(Convert.ToString(dtSheet.Rows[k][21]).Trim().Replace("-", "") == "" ? "0" :
                                    //    Convert.ToString(dtSheet.Rows[k][21]).Trim().Replace("-", "").Trim(new[] { '(', ')' }));

                                    M_CLOSING = M_LOADING + M_REMANING;
                                    if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                                    {
                                        //M_CLOSING = M_CLOSING * Convert.ToDouble(Deno);
                                        T_M_CLOSING += M_CLOSING;
                                    }

                                  

                                    #endregion

                                    IsSettled = 0;
                                    EOD = 1;
                                    BitIsRemoved = 0;

                                    if (SwappedTerminal == "CS" && Swap == "II" && Convert.ToDateTime(TR_TIMESTAMP) < Convert.ToDateTime(SwappedDate))
                                    {
                                        var query = _DataTable.AsEnumerable().Where(r => r.Field<string>("TERMINALID") == TERMINALID);

                                        InsertCount = InsertCount - query.ToList().Count;

                                        foreach (var row in query.ToList())
                                        {
                                            row.Delete();
                                        }
                                        _DataTable.AcceptChanges();
                                    }
                                    else
                                    {
                                        if (!Convert.ToString(Deno).ToUpper().Equals("TOTAL"))
                                            _DataTable.Rows.Add(ClientCode, TR_TIMESTAMP, CIT.Trim(), TERMINALID.Trim(), BANK.Trim(), LOCATION.Trim(), REMARK.Trim(), Deno, M_OPBALANCE, M_DISPENSE, M_REMANING, M_LOADING, M_CLOSING,
                                                P_REMANING, P_LOADING, P_CLOSING, S_OPBALANCE, S_DISPENSE, S_REMANING, S_LOADING, S_CLOSING, CASH_DUMP, OVG, SHTG, PURGE_BIN, Swap);
                                        else
                                            _DataTable.Rows.Add(ClientCode, TR_TIMESTAMP, CIT.Trim(), TERMINALID.Trim(), BANK.Trim(), LOCATION.Trim(), REMARK.Trim(), Deno, T_M_OPBALANCE, T_M_DISPENSE, T_M_REMANING, T_M_LOADING, T_M_CLOSING,
                                            P_REMANING, P_LOADING, P_CLOSING, S_OPBALANCE, S_DISPENSE, S_REMANING, S_LOADING, S_CLOSING, CASH_DUMP, T_OVG, T_SHTG, T_PURGE_BIN, Swap);
                                        InsertCount++;
                                    }

                                   
                                }
                                catch (Exception ex)
                                { 
                                   // DBLog.InsertLogs("CIT: " + CIT + " --> " + Convert.ToString(ex.Message) + "-" + ex.StackTrace.ToString(), ClientCode, "C3RSpliter.cs", "SplitData_INDUSIND_CMS", LineNo, FileName, UserName, 'E', Connectionstring);
                                    DBLog.InsertLogs("CIT: " + CIT + " --> " + Convert.ToString(ex.Message) + "-" + ex.StackTrace.ToString(), ClientCode, GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', Connectionstring);
                                }
                                if (Cycle > 0) Cycle--;
                                if (loop < 6) loop++;
                            }
                            else
                            {
                                k += 5;
                                Cycle = 0;
                                loop = 5;
                            }
                            #endregion


                        }
                    }

                }


            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString() + "-" + ex.StackTrace.ToString(), ClientCode, GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', Connectionstring);
            }
            return _DataTable;
        }

        public System.Data.DataTable ExtractExcel(string fullPath, string FileName, int Index)
        {
            LogWriter _log = new LogWriter();
            System.Data.DataTable dtExcel = new System.Data.DataTable();
            try
            {
                var excelFileToImport = Directory.GetFiles(Path.GetDirectoryName(fullPath), FileName, System.IO.SearchOption.AllDirectories);
                FileInfo info = new FileInfo(FileName);
                //OpenSettings openSettings = new OpenSettings();
                //if (info.Extension.Equals(".xls")) 
                //    openSettings.MarkupCompatibilityProcessSettings = new MarkupCompatibilityProcessSettings(MarkupCompatibilityProcessMode.ProcessAllParts, FileFormatVersions.None);
                //else
                //    openSettings.MarkupCompatibilityProcessSettings = new MarkupCompatibilityProcessSettings(MarkupCompatibilityProcessMode.ProcessAllParts, FileFormatVersions.Office2010);
                using (SpreadsheetDocument doc = SpreadsheetDocument.Open(excelFileToImport[0], false))
                {
                    //Sheet sheet = doc.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();
                    Sheet sheet = (Sheet)doc.WorkbookPart.Workbook.Sheets.ChildElements.ElementAt(Index);
                    Worksheet titlesWorksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;
                    IEnumerable<Row> rows = titlesWorksheet.GetFirstChild<SheetData>().Descendants<Row>();
                    try
                    {
                        foreach (Cell cell in rows.ElementAt(10))
                        {
                            dtExcel.Columns.Add(GetCellValue(doc, cell)); // this will include 2nd row a header row
                        }
                    }
                    catch (Exception)
                    {
                        try
                        {
                            dtExcel = new System.Data.DataTable();
                            foreach (Cell cell in rows.ElementAt(8))
                            {
                                dtExcel.Columns.Add(GetCellValue(doc, cell)); // this will include 2nd row a header row
                            }
                        }
                        catch (Exception)
                        {
                            dtExcel = new System.Data.DataTable();
                            string loop = "0", cellvalue = string.Empty;
                            foreach (Cell cell in rows.ElementAt(8))
                            {
                                dtExcel.Columns.Add(loop);  // this will include 2nd row a header row
                                loop = Convert.ToString(Convert.ToInt32(loop) + 1);
                            }
                        }
                    }
                    //for (int i = 0; i < rows.Count(); i++)
                    //{
                    //    dtExcel.Columns.Add(string.Empty);
                    //}
                    foreach (Row row in rows)
                    {
                        if (row.RowIndex.Value > 1) //this will exclude first two rows
                        {
                            System.Data.DataRow tempRow = dtExcel.NewRow();
                            int columnIndex = 0;
                            try
                            {
                                foreach (Cell cell in row.Descendants<Cell>())
                                {
                                    int cellColumnIndex = (int)GetColumnIndexFromName(GetColumnName(cell.CellReference));
                                    cellColumnIndex--; //zero based index
                                    if (columnIndex < cellColumnIndex)
                                    {
                                        do
                                        {
                                            tempRow[columnIndex] = ""; //Insert blank data here;
                                            columnIndex++;
                                        }
                                        while (columnIndex < cellColumnIndex);
                                    }
                                    tempRow[columnIndex] = GetCellValue(doc, cell);



                                    columnIndex++;
                                }
                            }
                            catch (Exception)
                            {
                            }
                            dtExcel.Rows.Add(tempRow);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }



            return dtExcel;
        }

        public static string GetCellValue(SpreadsheetDocument document, Cell cell)
        {
            SharedStringTablePart stringTablePart = document.WorkbookPart.SharedStringTablePart;
            if (cell.CellValue == null)
            {
                return "";
            }
            string value = cell.CellValue.InnerXml;
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return stringTablePart.SharedStringTable.ChildElements[Int32.Parse(value)].InnerText;
            }
            else
            {
                return value;
            }
        }

        public static int? GetColumnIndexFromName(string columnName)
        {
            //return columnIndex;
            string name = columnName;
            int number = 0;
            int pow = 1;
            for (int i = name.Length - 1; i >= 0; i--)
            {
                number += (name[i] - 'A' + 1) * pow;
                pow *= 26;
            }
            return number;
        }

        public static string GetColumnName(string cellReference)
        {
            // Create a regular expression to match the column name portion of the cell name.
            Regex regex = new Regex("[A-Za-z]+");
            Match match = regex.Match(cellReference);
            return match.Value;
        }


        //Get Local IP Address
        public string GetLocalIPAddress()
        {
            string localIP = string.Empty;

            try
            {
                var host = Dns.GetHostEntry(Dns.GetHostName());

                foreach (var ip in host.AddressList)
                {
                    // Check for IPv4 address and exclude loopback address
                    if (ip.AddressFamily == AddressFamily.InterNetwork)
                    {
                        localIP = ip.ToString();
                        break;
                    }
                }

                if (string.IsNullOrEmpty(localIP))
                {
                    throw new Exception("No IPv4 address found for the machine.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            return localIP;
        }


    }
}
