﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ASPTraceWebApi
{
   
    public class ChargebackFileSplitercs : ProcesschargebackLogSpliter
    {
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;

         
        public ChargebackFileSplitercs(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        public DataTable ChargebackFileSpliter(string FilePath, string FileName, DataTable dt, string UserName, string ClientCode, string ConnectionString, out int InsertCount, out int TotalCount)
        {
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();
            try
            {
                _DataTable.Columns.Add("ClientID", typeof(int));
                _DataTable.Columns.Add("TR_TIMESTAMP", typeof(DateTime));
                _DataTable.Columns.Add("DTTXN", typeof(string));
                _DataTable.Columns.Add("BIN", typeof(string));
                _DataTable.Columns.Add("PID", typeof(string));
                _DataTable.Columns.Add("CARDNUMBER", typeof(string));
                _DataTable.Columns.Add("REFERENCENO", typeof(string));
                _DataTable.Columns.Add("TERMINALID", typeof(string));
                _DataTable.Columns.Add("MCC", typeof(string));

                _DataTable.Columns.Add("ISSUERBANK", typeof(string));
                _DataTable.Columns.Add("STATUS", typeof(string));
                _DataTable.Columns.Add("APPROVEDCODE", typeof(string));
                _DataTable.Columns.Add("TRANSACTIONAMT", typeof(string));
                _DataTable.Columns.Add("TRANSACTIONAMT1", typeof(string));
                _DataTable.Columns.Add("TRANSACTIONAMT2", typeof(string));
                _DataTable.Columns.Add("REFUNDAMT", typeof(string));
                _DataTable.Columns.Add("REMARKS", typeof(string));
                _DataTable.Columns.Add("FileDate", typeof(DateTime));
                _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
                _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
                _DataTable.Columns.Add("CreatedBy", typeof(string));
                _DataTable.Columns.Add("ModifiedBy", typeof(string));
                //_DataTable.Columns.Add("Filename", typeof(string));
                _DataTable = ProcessLogSplitercharge(FilePath, dt, _DataTable, UserName, ClientCode, FileName, ConnectionString, out InsertCount, out TotalCount);

            }
            catch (Exception ex)
            {
                variable();
                //_log.FunErrorLog(EX.Message.ToString(), BankCode, "SwitchFileSplitercs", "ATMSwitchFIleSpliter", 0, FileName, UserName, 'E');
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');

            }
            return _DataTable;
        }


    }
}
