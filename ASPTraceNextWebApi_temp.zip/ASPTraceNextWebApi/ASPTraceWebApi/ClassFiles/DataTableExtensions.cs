﻿
using Newtonsoft.Json; 
using System.Data;


namespace ASPTraceWebApi.ClassFiles
{
    public static class DataTableExtensions
    {
        public static string ToJson(this DataTable dataTable)
        {
            var rows = new List<Dictionary<string, object>>();

            foreach (DataRow row in dataTable.Rows)
            {
                var dict = new Dictionary<string, object>();

                foreach (DataColumn col in dataTable.Columns)
                {
                    //string columnName = col.ColumnName;
                    // Convert the first character to lowercase
                    //string newColumnName = Char.ToLower(columnName[0]) + columnName.Substring(1);
                    // Convert types to JSON-compatible types
                    dict[col.ColumnName] = ConvertToJsonCompatible(row[col]);
                }

                rows.Add(dict);
            }

            return JsonConvert.SerializeObject(rows);
        }

        private static object ConvertToJsonCompatible(object value)
        {
            // Convert System.Type to string representation
            if (value is Type typeValue)
            {
                return typeValue.FullName;
            }
            // Add other type conversions as needed

            // Default case
            return value;
        }
    }

}
