﻿using System.Data.OleDb;
using System.Data; 
using System;
using Utility;
using System.IO;
using System.Globalization;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Linq;
using ImportData;
using System.Reflection;

namespace ASPTraceWebApi
{
    public class ESAF_Splitter
    {
        private readonly string _MekKey1;
        private readonly string _MekKey2;
        private readonly string _connectionString;
        BulkImports bulkimports;
        public ESAF_Splitter(string connectionString, string EMekKey1, string EMekKey2)
        {
            _connectionString = connectionString;
            _MekKey1 = EMekKey1;
            _MekKey2 = EMekKey2;
            bulkimports = new BulkImports(_connectionString, _MekKey1, _MekKey2);
        }

        public DataTable Splitter_TIMEOUT_IMPS(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnAmount", typeof(decimal));
            _DataTable.Columns.Add("AccountNumber", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("Remarks", typeof(string));
            _DataTable.Columns.Add("TxnType", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;

            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            DataTable dtexcelsheetname = null;
            try
            {
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                OleDbConnection objConn = new OleDbConnection(connString);
                string extension = Path.GetExtension(path);


                switch (extension.ToLower())
                {

                    case ".xls": //Excel 97-03
                                 // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                    case ".xlsx": //Excel 07 or higher
                                  //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;

                }

                try
                {
                    objConn = new OleDbConnection(connString);

                    if (objConn.State == ConnectionState.Open)
                    {
                        objConn.Close();
                    }

                    objConn.Open();

                }
                catch
                {
                    switch (extension.ToLower())
                    {
                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }

                    try
                    {
                        objConn = new OleDbConnection(connString);
                        if (objConn.State == ConnectionState.Open)
                        {
                            objConn.Close();
                        }

                        objConn.Open();
                    }
                    catch
                    {
                        switch (extension.ToLower())
                        {
                            case ".xls": //Excel 97-03
                                         // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                                connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                break;
                            case ".xlsx": //Excel 07 or higher
                                          //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                break;
                        }
                        try
                        {
                            objConn = new OleDbConnection(connString);
                            if (objConn.State == ConnectionState.Open)
                            {
                                objConn.Close();
                            }
                            objConn.Open();
                        }
                        catch
                        {
                            switch (extension.ToLower())
                            {
                                case ".xls": //Excel 97-03 xls
                                    connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                                    break;
                                case ".xlsx": //Excel 07 or higher xlsx
                                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                                    break;
                            }

                            try
                            {
                                objConn = new OleDbConnection(connString);
                                if (objConn.State == ConnectionState.Open)
                                {
                                    objConn.Close();
                                }
                                objConn.Open();
                            }
                            catch
                            {
                                switch (extension.ToLower())
                                {

                                    case ".xls": //Excel 97-03
                                                 // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                        break;
                                    case ".xlsx": //Excel 07 or higher
                                                  //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                        break;
                                }
                                objConn = new OleDbConnection(connString);
                                objConn.Open();
                            }

                        }
                    }

                }

                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                
                int j = 0;
                foreach (DataRow row in dtexcelsheetname.Rows)
                { 
                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";

                    OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataTable dtSheet = new DataTable();
                    da.Fill(dtSheet);
                    objConn.Close();

                    if (dtSheet.Rows.Count > 1)
                    {

                        int Incr = 1;
                        string ReferenceNumber = string.Empty;
                        string TxnAmount = "0";
                        string AccountNumber = string.Empty;
                        string Cycle = string.Empty;
                        string Remarks = string.Empty;
                        string TxnType = string.Empty;
                        string TxnDateTime = string.Empty;

                        DateTime? TxnsDateTime = null;

                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            Incr = 1;

                            TxnAmount = "0";
                            ReferenceNumber = string.Empty;
                            AccountNumber = string.Empty;
                            Cycle = string.Empty;
                            Remarks = string.Empty;
                            TxnType = string.Empty;

                            try
                            {

                                if (ds.Tables[0].Rows[0]["ReferenceNumber"].ToString() != "0")
                                {
                                    ReferenceNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReferenceNumber"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnAmount"].ToString() != "0")
                                {
                                    TxnAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnAmount"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["AccountNumber"].ToString() != "0")
                                {
                                    AccountNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AccountNumber"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsDateTime"].ToString() != "0")
                                {
                                    TxnDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsDateTime"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Cycle"].ToString() != "0")
                                {
                                    Cycle = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Cycle"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Remarks"].ToString() != "")
                                {
                                    Remarks = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Remarks"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnType"].ToString() != "")
                                {
                                    TxnType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnType"].ToString()) - Incr].ToString();
                                }

                                TxnAmount = Utility.Common.IsNumeric(TxnAmount) ? TxnAmount : "0";

                                TxnsDateTime = DateTime.ParseExact(TxnDateTime, new[] { "yyyy/MM/dd", "dd/MM/yyyy" }, null, DateTimeStyles.None);

                            }
                            catch (Exception ex)
                            {
                                ErrorCount++;
                                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            }
                            LineNo++;

                            if (TxnsDateTime != null)
                                _DataTable.Rows.Add(ReferenceNumber, TxnAmount, AccountNumber, Cycle, TxnsDateTime, Remarks, TxnType);

                            InsertCount++;
                            j++;
                        }
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "NPCIIMPS.cs", "SplitData", LineNo, FileName, UserName, 'E');
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;

        }

        public DataTable Splitter_DebitReversal(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("TXNUID", typeof(string));
            _DataTable.Columns.Add("TXNType", typeof(string));
            _DataTable.Columns.Add("TXNDate", typeof(string));
            _DataTable.Columns.Add("TXNTime", typeof(string));
            _DataTable.Columns.Add("TXNDateTime", typeof(DateTime));
            _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("RRN", typeof(string));
            _DataTable.Columns.Add("STAN", typeof(string));
            _DataTable.Columns.Add("Remitter", typeof(string));
            _DataTable.Columns.Add("Beneficiary", typeof(string));
            _DataTable.Columns.Add("BeneficiaryMobile", typeof(string));
            _DataTable.Columns.Add("RemitterNumber", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("UTXNID", typeof(string));
            _DataTable.Columns.Add("PayerPSP", typeof(string));
            _DataTable.Columns.Add("PayeePSP", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;


            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();

            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            string[] colFields = null;
            string line1 = string.Empty; 

            try
            {

                DataSet ds = new DataSet();
                ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));


                if (TotalCountArray.Count() > 1)
                {

                    int Incr = 1;
                    string TXNUID = string.Empty;
                    string TXNType = string.Empty;
                    string TXNDate = string.Empty;
                    string TXNTime = string.Empty;
                    string TxnDateTime = string.Empty;
                    string SettlementDate = string.Empty;
                    string ResponseCode = string.Empty;
                    string RRN = string.Empty;
                    string STAN = string.Empty;
                    string Remitter = string.Empty;
                    string Beneficiary = string.Empty;
                    string BeneficiaryNo = string.Empty;
                    string RemitterNumber = string.Empty;
                    string TxnAmount = "0";
                    string UTXNID = string.Empty;
                    string PayerPSP = string.Empty;
                    string PayeePSP = string.Empty;
                    Incr = 1;

                    DateTime? TxnsDateTime = null;
                    DateTime? SettlementDateTime = null;

                    foreach (string line in File.ReadAllLines(path))
                    {

                        LineNo++; 

                        TXNUID = string.Empty;
                        TXNType = string.Empty;
                        TXNDate = string.Empty;
                        TXNTime = string.Empty;
                        TxnDateTime = string.Empty;
                        SettlementDate = string.Empty;
                        ResponseCode = string.Empty;
                        RRN = string.Empty;
                        STAN = string.Empty;
                        Remitter = string.Empty;
                        Beneficiary = string.Empty;
                        BeneficiaryNo = string.Empty;
                        RemitterNumber = string.Empty;
                        TxnAmount = "0";
                        UTXNID = string.Empty;
                        PayerPSP = string.Empty;
                        PayeePSP = string.Empty;

                        TxnsDateTime = null;
                        SettlementDateTime = null;

                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            colFields = line1.Split(new string[] { "," }, StringSplitOptions.None);


                            if (ds.Tables[0].Rows[0]["TXNUID"].ToString() != "0")
                            {
                                TXNUID = colFields[int.Parse(ds.Tables[0].Rows[0]["TXNUID"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["TXNType"].ToString() != "0")
                            {
                                TXNType = colFields[int.Parse(ds.Tables[0].Rows[0]["TXNType"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["TXNDate"].ToString() != "0")
                            {
                                TXNDate = colFields[int.Parse(ds.Tables[0].Rows[0]["TXNDate"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["TXNTime"].ToString() != "0")
                            {
                                TXNTime = colFields[int.Parse(ds.Tables[0].Rows[0]["TXNTime"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["SettlementDate"].ToString() != "0")
                            {
                                SettlementDate = colFields[int.Parse(ds.Tables[0].Rows[0]["SettlementDate"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["ResponseCode"].ToString() != "")
                            {
                                ResponseCode = colFields[int.Parse(ds.Tables[0].Rows[0]["ResponseCode"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["RRN"].ToString() != "")
                            {
                                RRN = colFields[int.Parse(ds.Tables[0].Rows[0]["RRN"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["STAN"].ToString() != "")
                            {
                                STAN = colFields[int.Parse(ds.Tables[0].Rows[0]["STAN"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["Remitter"].ToString() != "")
                            {
                                Remitter = colFields[int.Parse(ds.Tables[0].Rows[0]["Remitter"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["Beneficiary"].ToString() != "")
                            {
                                Beneficiary = colFields[int.Parse(ds.Tables[0].Rows[0]["Beneficiary"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["BeneficiaryNo"].ToString() != "")
                            {
                                BeneficiaryNo = colFields[int.Parse(ds.Tables[0].Rows[0]["BeneficiaryNo"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["RemitterNumber"].ToString() != "0")
                            {
                                RemitterNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["RemitterNumber"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["Amount"].ToString() != "0")
                            {
                                TxnAmount = colFields[int.Parse(ds.Tables[0].Rows[0]["Amount"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["UTXNID"].ToString() != "0")
                            {
                                UTXNID = colFields[int.Parse(ds.Tables[0].Rows[0]["UTXNID"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["PayerPSP"].ToString() != "0")
                            {
                                PayerPSP = colFields[int.Parse(ds.Tables[0].Rows[0]["PayerPSP"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["PayeePSP"].ToString() != "0")
                            {
                                PayeePSP = colFields[int.Parse(ds.Tables[0].Rows[0]["PayeePSP"].ToString()) - Incr].ToString();
                            }

                            TxnAmount = Utility.Common.IsNumeric(TxnAmount) ? TxnAmount : "0";

                            TxnDateTime = TXNDate + " " + TXNTime;

                            TxnsDateTime = DateTime.ParseExact(TxnDateTime, new[] { "d/M/yyyy H:mm:ss", "dd/MM/yyyy HH:mm:ss" }, null, DateTimeStyles.None);

                            SettlementDateTime = DateTime.ParseExact(SettlementDate, new[] { "d/M/yyyy", "d/M/yy" }, null, DateTimeStyles.None);

                            ResponseCode = ResponseCode.Trim().Replace("'", "");
                            RRN = RRN.Trim().Replace("'", "");
                            Beneficiary = Beneficiary.Trim().Replace("'", "");
                            BeneficiaryNo = BeneficiaryNo.Trim().Replace("'", "");
                            RemitterNumber = RemitterNumber.Trim().Replace("'", "");

                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                        LineNo++;

                        if (TxnsDateTime != null)
                            _DataTable.Rows.Add(
                                TXNUID,
                                TXNType,
                                TXNDate,
                                TXNTime,
                                TxnsDateTime,
                                SettlementDateTime,
                                ResponseCode,
                                RRN,
                                STAN,
                                Remitter,
                                Beneficiary,
                                BeneficiaryNo,
                                RemitterNumber,
                                TxnAmount,
                                UTXNID,
                                PayerPSP,
                                PayeePSP
                                );

                        InsertCount++;


                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "NPCIIMPS.cs", "SplitData", LineNo, FileName, UserName, 'E');
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;

        }

        public DataTable Splitter_TimeOutCases(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("TXNUID", typeof(string));
            _DataTable.Columns.Add("TXNType", typeof(string));
            _DataTable.Columns.Add("TXNDate", typeof(string));
            _DataTable.Columns.Add("TXNTime", typeof(string));
            _DataTable.Columns.Add("TXNDateTime", typeof(DateTime));
            _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("RRN", typeof(string));
            _DataTable.Columns.Add("STAN", typeof(string));
            _DataTable.Columns.Add("Remitter", typeof(string));
            _DataTable.Columns.Add("Beneficiary", typeof(string));
            _DataTable.Columns.Add("BeneficiaryMobile", typeof(string));
            _DataTable.Columns.Add("RemitterNumber", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("UTXNID", typeof(string));
            _DataTable.Columns.Add("PayerPSP", typeof(string));
            _DataTable.Columns.Add("PayeePSP", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;


            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();

            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            string[] colFields = null;
            string line1 = string.Empty;

            try
            {

                DataSet ds = new DataSet();
                ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));


                if (TotalCountArray.Count() > 1)
                {

                    int Incr = 1;
                    string TXNUID = string.Empty;
                    string TXNType = string.Empty;
                    string TXNDate = string.Empty;
                    string TXNTime = string.Empty;
                    string TxnDateTime = string.Empty;
                    string SettlementDate = string.Empty;
                    string ResponseCode = string.Empty;
                    string RRN = string.Empty;
                    string STAN = string.Empty;
                    string Remitter = string.Empty;
                    string Beneficiary = string.Empty;
                    string BeneficiaryNo = string.Empty;
                    string RemitterNumber = string.Empty;
                    string TxnAmount = "0";
                    string UTXNID = string.Empty;
                    string PayerPSP = string.Empty;
                    string PayeePSP = string.Empty;
                    Incr = 1;

                    DateTime? TxnsDateTime = null;
                    DateTime? SettlementDateTime = null;

                    foreach (string line in File.ReadAllLines(path))
                    {

                        LineNo++;

                        TXNUID = string.Empty;
                        TXNType = string.Empty;
                        TXNDate = string.Empty;
                        TXNTime = string.Empty;
                        TxnDateTime = string.Empty;
                        SettlementDate = string.Empty;
                        ResponseCode = string.Empty;
                        RRN = string.Empty;
                        STAN = string.Empty;
                        Remitter = string.Empty;
                        Beneficiary = string.Empty;
                        BeneficiaryNo = string.Empty;
                        RemitterNumber = string.Empty;
                        TxnAmount = "0";
                        UTXNID = string.Empty;
                        PayerPSP = string.Empty;
                        PayeePSP = string.Empty;

                        TxnsDateTime = null;
                        SettlementDateTime = null;

                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            colFields = line1.Split(new string[] { "," }, StringSplitOptions.None);


                            if (ds.Tables[0].Rows[0]["TXNUID"].ToString() != "0")
                            {
                                TXNUID = colFields[int.Parse(ds.Tables[0].Rows[0]["TXNUID"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["TXNType"].ToString() != "0")
                            {
                                TXNType = colFields[int.Parse(ds.Tables[0].Rows[0]["TXNType"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["TXNDate"].ToString() != "0")
                            {
                                TXNDate = colFields[int.Parse(ds.Tables[0].Rows[0]["TXNDate"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["TXNTime"].ToString() != "0")
                            {
                                TXNTime = colFields[int.Parse(ds.Tables[0].Rows[0]["TXNTime"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["SettlementDate"].ToString() != "0")
                            {
                                SettlementDate = colFields[int.Parse(ds.Tables[0].Rows[0]["SettlementDate"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["ResponseCode"].ToString() != "")
                            {
                                ResponseCode = colFields[int.Parse(ds.Tables[0].Rows[0]["ResponseCode"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["RRN"].ToString() != "")
                            {
                                RRN = colFields[int.Parse(ds.Tables[0].Rows[0]["RRN"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["STAN"].ToString() != "")
                            {
                                STAN = colFields[int.Parse(ds.Tables[0].Rows[0]["STAN"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["Remitter"].ToString() != "")
                            {
                                Remitter = colFields[int.Parse(ds.Tables[0].Rows[0]["Remitter"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["Beneficiary"].ToString() != "")
                            {
                                Beneficiary = colFields[int.Parse(ds.Tables[0].Rows[0]["Beneficiary"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["BeneficiaryNo"].ToString() != "")
                            {
                                BeneficiaryNo = colFields[int.Parse(ds.Tables[0].Rows[0]["BeneficiaryNo"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["RemitterNumber"].ToString() != "0")
                            {
                                RemitterNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["RemitterNumber"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["Amount"].ToString() != "0")
                            {
                                TxnAmount = colFields[int.Parse(ds.Tables[0].Rows[0]["Amount"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["UTXNID"].ToString() != "0")
                            {
                                UTXNID = colFields[int.Parse(ds.Tables[0].Rows[0]["UTXNID"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["PayerPSP"].ToString() != "0")
                            {
                                PayerPSP = colFields[int.Parse(ds.Tables[0].Rows[0]["PayerPSP"].ToString()) - Incr].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["PayeePSP"].ToString() != "0")
                            {
                                PayeePSP = colFields[int.Parse(ds.Tables[0].Rows[0]["PayeePSP"].ToString()) - Incr].ToString();
                            }

                            TxnAmount = Utility.Common.IsNumeric(TxnAmount) ? TxnAmount : "0";

                            TxnDateTime = TXNDate + " " + TXNTime;

                            TxnsDateTime = DateTime.ParseExact(TxnDateTime, new[] { "d/M/yyyy H:mm:ss", "dd/MM/yyyy HH:mm:ss" }, null, DateTimeStyles.None);

                            SettlementDateTime = DateTime.ParseExact(SettlementDate, new[] { "d/M/yyyy", "d/M/yy" }, null, DateTimeStyles.None);

                            ResponseCode = ResponseCode.Trim().Replace("'", "");
                            RRN = RRN.Trim().Replace("'", "");
                            Beneficiary = Beneficiary.Trim().Replace("'", "");
                            BeneficiaryNo = BeneficiaryNo.Trim().Replace("'", "");
                            RemitterNumber = RemitterNumber.Trim().Replace("'", "");

                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                        LineNo++;

                        if (TxnsDateTime != null)
                            _DataTable.Rows.Add(
                                TXNUID,
                                TXNType,
                                TXNDate,
                                TXNTime,
                                TxnsDateTime,
                                SettlementDateTime,
                                ResponseCode,
                                RRN,
                                STAN,
                                Remitter,
                                Beneficiary,
                                BeneficiaryNo,
                                RemitterNumber,
                                TxnAmount,
                                UTXNID,
                                PayerPSP,
                                PayeePSP
                                );

                        InsertCount++;


                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "NPCIIMPS.cs", "SplitData", LineNo, FileName, UserName, 'E');
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;

        }

    }
}
