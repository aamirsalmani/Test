﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;

namespace ASPTraceWebApi
{

    public class IMPSIssuerFileSplitter
    {

        

        Utility.DateTimeConverter objDateTimeConverter = new Utility.DateTimeConverter();
        System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");

        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public IMPSIssuerFileSplitter(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        public DataTable SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {

            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifyBy", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataSet DT = new DataSet();
            string[] arrLines;
            string m_RecordData = string.Empty;
            decimal AMT;
            //string EMekKey1 = ConfigurationSettings.AppSettings["EMekKey1"].ToString();
            //string EMekKey2 = ConfigurationSettings.AppSettings["EMekKey2"].ToString();
            //string StrCon = DAL.Comman.ConnectionString(); //ConfigurationSettings.AppSettings["con"].ToString();
            //ConfigurationDAL objConfigurationDAL = new ConfigurationDAL();
            //DataSet dsDEK = objConfigurationDAL.GetEncryptedDEK();
            //DataSet dsCardNetwork = objConfigurationDAL.GetCardNetwork();

            //AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            //AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            //string DEK = AesEncryption.DecryptEncryptedDEK(dsDEK.Tables[0].Rows[0]["TMK_LMK"].ToString(), AesEncryption.ClearMEK2);
            //

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            try
            {

                arrLines = File.ReadAllLines(path, Encoding.Default);
                int totalrecords = arrLines.Length;
                string Cycle = FileName.Substring(15, 1).ToString();
                string FD = FileName.Substring(8, 2).ToString() + "-" + FileName.Substring(10, 2).ToString() + "-" + FileName.Substring(12, 2).ToString();
                DateTime FileDate = DateTime.ParseExact(FD, "dd-MM-yy", CultureInfo.InvariantCulture);


                for (int i = 0; i < totalrecords; i++)
                {
                    try
                    {
                        m_RecordData = arrLines[i];
                        string Participant_ID = m_RecordData.Substring(0, 2).Trim();
                        string Transaction_Type = m_RecordData.Substring(3, 2).Trim();
                        string From_Account_Type = m_RecordData.Substring(5, 2).Trim();
                        string To_Account_Type = m_RecordData.Substring(7, 2).Trim();
                        string Transaction_Serial_Number = m_RecordData.Substring(9, 12).Trim();
                        string Response_Code = m_RecordData.Substring(21, 2).Trim();
                        string PAN_Number = m_RecordData.Substring(23, 19).Trim();
                        string Member_Number = m_RecordData.Substring(42, 1).Trim();
                        string Approval_Number = m_RecordData.Substring(43, 6).Trim();
                        string System_Trace_Audit_Number = m_RecordData.Substring(49, 12).Trim();
                        int auditno = 0;
                        if (!int.TryParse(System_Trace_Audit_Number, out auditno))
                        {
                            System_Trace_Audit_Number = "0";
                        }

                        string Transaction_Date = m_RecordData.Substring(61, 6).Trim();
                        string Transaction_Time = m_RecordData.Substring(67, 6).Trim();

                        string timestamp = Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + "-" + Transaction_Date.Substring(4, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                        DateTime _datetime = DateTime.ParseExact(timestamp, "yy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

                        string Merchant_Category_Code_ = m_RecordData.Substring(73, 4).Trim();
                        if (Merchant_Category_Code_.Trim() == "")
                        {
                            Merchant_Category_Code_ = "0";
                        }
                        string Card_Acceptor_Settlement_Date = m_RecordData.Substring(77, 6).Trim();
                        if (Card_Acceptor_Settlement_Date.Trim() == "")
                        {
                            Card_Acceptor_Settlement_Date = "0";
                        }
                        string Card_Acceptor_ID = m_RecordData.Substring(83, 15).Trim();
                        string Card_Acceptor_Terminal_ID = m_RecordData.Substring(98, 8).Trim();
                        string Card_Acceptor_Terminal_Location = m_RecordData.Substring(106, 40).Trim();
                        string Acquirer_ID = m_RecordData.Substring(146, 11).Trim();
                        string Network_ID = m_RecordData.Substring(157, 3).Trim();
                        string Account_1_Number = m_RecordData.Substring(160, 19).Trim();
                        string Account_1_Branch_ID = m_RecordData.Substring(179, 10).Trim();
                        string Account_2_Number = m_RecordData.Substring(189, 19).Trim();
                        string Account_2_Branch_ID = m_RecordData.Substring(208, 10).Trim();
                        string Transaction_Currency_Code = m_RecordData.Substring(218, 3).Trim();
                        //Eliminated Last two digit

                        string Transaction_Amount = m_RecordData.Substring(221, 15).Trim();
                        if (Transaction_Amount.Trim() == "")
                        {
                            Transaction_Amount = "0";
                        }
                        //try
                        //{
                        //    if ((ClientID == 12 && ModeID == 4) || (ClientID == 37 && ModeID == 4))
                        //    {
                        //        AMT = decimal.Parse(Transaction_Amount);
                        //        decimal AMT1 = (AMT / 100);
                        //        Transaction_Amount = Convert.ToString(AMT1);
                        //    }
                        //    else
                        //    {
                        //        Transaction_Amount = m_RecordData.Substring(221, 15).Trim();
                        //    }
                        //}
                        //catch (Exception)
                        //{


                        //}


                        string Actual_Transaction_Amount = m_RecordData.Substring(236, 13).Trim();
                        if (Actual_Transaction_Amount.Trim() == "")
                        {
                            Actual_Transaction_Amount = "0";
                        }
                        //***********//
                        string Transaction_Activity_Fee = m_RecordData.Substring(251, 15).Trim();
                        if (Transaction_Activity_Fee.Trim() == "")
                        {
                            Transaction_Activity_Fee = "0";
                        }
                        string Issuer_Settlement_Currency_Code = m_RecordData.Substring(266, 3).Trim();
                        string Issuer_Settlement_Amount = m_RecordData.Substring(269, 13).Trim();
                        if (Issuer_Settlement_Amount.Trim() == "")
                        {
                            Issuer_Settlement_Amount = "0";
                        }
                        string Issuer_Settlement_Fee = m_RecordData.Substring(284, 15).Trim();
                        if (Issuer_Settlement_Fee.Trim() == "")
                        {
                            Issuer_Settlement_Fee = "0";
                        }
                        string Issuer_Settlement_Processing_Fee = m_RecordData.Substring(299, 15).Trim();
                        if (Issuer_Settlement_Processing_Fee.Trim() == "")
                        {
                            Issuer_Settlement_Processing_Fee = "0";
                        }
                        string Cardholder_Billing_Currency_Code = m_RecordData.Substring(314, 3).Trim();
                        string Cardholder_Billing_Amount = m_RecordData.Substring(317, 15).Trim();
                        if (Cardholder_Billing_Amount.Trim() == "")
                        {
                            Cardholder_Billing_Amount = "0";
                        }
                        string Cardholder_Billing_Activity_Fee = m_RecordData.Substring(332, 15).Trim();
                        if (Cardholder_Billing_Activity_Fee.Trim() == "")
                        {
                            Cardholder_Billing_Activity_Fee = "0";
                        }
                        string Cardholder_Billing_Processing_Fee = m_RecordData.Substring(347, 15).Trim();
                        if (Cardholder_Billing_Processing_Fee.Trim() == "")
                        {
                            Cardholder_Billing_Processing_Fee = "0";
                        }
                        string Cardholder_Billing_Service_Fee = m_RecordData.Substring(362, 15).Trim();
                        if (Cardholder_Billing_Service_Fee.Trim() == "")
                        {
                            Cardholder_Billing_Service_Fee = "0";
                        }
                        string Transaction_Issuer_Conversion_Rate = m_RecordData.Substring(377, 15).Trim();
                        if (Transaction_Issuer_Conversion_Rate.Trim() == "")
                        {
                            Transaction_Issuer_Conversion_Rate = "0";
                        }
                        string Transaction_Cardholder_Conversion_Rate = m_RecordData.Substring(392, 15).Trim();
                        if (Transaction_Cardholder_Conversion_Rate.Trim() == "")
                        {
                            Transaction_Cardholder_Conversion_Rate = "0";
                        }

                        _DataTable.Rows.Add(ClientID, Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code,
                                        PAN_Number, Member_Number, Approval_Number, System_Trace_Audit_Number, _datetime, Transaction_Time, Merchant_Category_Code_,
                                        Card_Acceptor_Settlement_Date, Card_Acceptor_ID, Card_Acceptor_Terminal_ID, Card_Acceptor_Terminal_Location, Acquirer_ID, Network_ID,
                                        Account_1_Number, Account_1_Branch_ID, Account_2_Number, Account_2_Branch_ID, Transaction_Currency_Code, Transaction_Amount,
                                        Actual_Transaction_Amount, Transaction_Activity_Fee, Issuer_Settlement_Currency_Code, Issuer_Settlement_Amount, Issuer_Settlement_Fee,
                                        Issuer_Settlement_Processing_Fee, Cardholder_Billing_Currency_Code, Cardholder_Billing_Amount, Cardholder_Billing_Activity_Fee,
                                        Cardholder_Billing_Processing_Fee, Cardholder_Billing_Service_Fee, Transaction_Issuer_Conversion_Rate, Transaction_Cardholder_Conversion_Rate,
                                        System.DateTime.Now, System.DateTime.Now, UserName, UserName, Cycle, FileName, FileDate, path);

                        LineNo++;
                    }
                    catch (Exception ex)
                    {
                        InsertCount--;

                    }

                }


                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;

                }


            }
            catch (Exception ex)
            {
                InsertCount--;

            }

            return _DataTable;

        }

        public DataTable SplitData2(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifyBy", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));


            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            //string EMekKey1 = ConfigurationSettings.AppSettings["EMekKey1"].ToString();
            //string EMekKey2 = ConfigurationSettings.AppSettings["EMekKey2"].ToString();
            //string StrCon = DAL.Comman.ConnectionString(); //ConfigurationSettings.AppSettings["con"].ToString();
            //ConfigurationDAL objConfigurationDAL = new ConfigurationDAL();
            //DataSet dsDEK = objConfigurationDAL.GetEncryptedDEK();
            //DataSet dsCardNetwork = objConfigurationDAL.GetCardNetwork();

            //AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            //AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            //string DEK = AesEncryption.DecryptEncryptedDEK(dsDEK.Tables[0].Rows[0]["TMK_LMK"].ToString(), AesEncryption.ClearMEK2);
            //

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            // bool TxnAmountIsDecimal = Convert.ToBoolean(dt.Rows[0]["TxnAmountIsDecimal"]);
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            //DateTime? Transaction_Date = null;

            string strFileName = Path.GetFileNameWithoutExtension(path);
            string FD = strFileName.Substring(strFileName.Length - 9);
            string[] FDA = FD.Split('_', '.');
            DateTime FileDate = DateTime.ParseExact(FDA[0], "ddMMyy", CultureInfo.InvariantCulture);
            string Cycle = FDA[1].ToString();
            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);
                    //string Cycle = FileName.Substring(15, 1).ToString();
                    //string FD = FileName.Substring(8, 2).ToString() + "-" + FileName.Substring(10, 2).ToString() + "-" + FileName.Substring(12, 2).ToString();
                    //DateTime FileDate = DateTime.ParseExact(FD, "MM-dd-yy", CultureInfo.InvariantCulture);
                    string[] SplitArr = line1.Split(',');
                    int Incr = 1;

                    string Participant_ID = SplitArr[0];
                    string Transaction_Type = SplitArr[1];
                    string From_Account_Type = SplitArr[2];
                    string To_Account_Type = SplitArr[3];
                    string Transaction_Serial_Number = SplitArr[4];
                    string Response_Code = SplitArr[5];
                    string PAN_Number = SplitArr[6];
                    string MEMNUMBER = string.Empty;
                    string Approval_Number = SplitArr[7];
                    string STAUDITNO = "0";
                    //Transaction_Date = DateTime.ParseExact(SplitArr[8], "yyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None);
                    //string Transaction_Time = SplitArr[9];
                    string Transaction_Date = SplitArr[8];
                    string Transaction_Time = SplitArr[9];
                    string timestamp = Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + "-" + Transaction_Date.Substring(4, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                    DateTime Transaction_Date1 = DateTime.ParseExact(timestamp, "yy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

                    string Merchant_Category_Code = SplitArr[10];
                    string CARDACCEPTSETDATE = SplitArr[13];
                    string Card_Acceptor_ID = SplitArr[11];
                    string CARDACCEPTTERMINALID = string.Empty;
                    string CARDACCEPTERTERLOCATION = string.Empty;
                    string Acquirer_ID = SplitArr[12];
                    string NETWORKID = string.Empty;
                    string Ben_Account_Number = SplitArr[18];
                    string Bene_IFSC_CODE = SplitArr[17];
                    string REM_ACCOUNT_NUMBER = SplitArr[20];
                    string REM_IFSC_CODE = SplitArr[19];
                    string Transaction_Currency_Code = SplitArr[14];
                    string Transaction_Amount = SplitArr[15];
                    string ACCTUALTRANAMOUNT = SplitArr[15];
                    string TRANSACCVITYFEE = "0";
                    string ISSUERSETCURRENCYCODE = string.Empty;
                    string ISSURESETAMOUNT = "0";
                    string ISSUERSETFEE = "0";
                    string ISSURESETPROCFEE = "0";
                    string CARDHOLDERBILLCURNCCODE = string.Empty;
                    string CARDHOLDERBILLAMOUNT = "0";
                    string CARDHOLDERBILACTFEE = "0";
                    string CARDHOLDERBILPROFEE = "0";
                    string CARDHOLDERBILSRVICEFEE = "0";
                    string TRAN_ISSUERCONVERSRATE = "0";
                    string TRANS_CARDHOLDERCONVERRATE = "0";

                    _DataTable.Rows.Add(ClientID, Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code, PAN_Number, MEMNUMBER,
                                       Approval_Number, STAUDITNO, Transaction_Date1, Transaction_Time, Merchant_Category_Code, CARDACCEPTSETDATE, Card_Acceptor_ID, CARDACCEPTTERMINALID, CARDACCEPTERTERLOCATION,
                                       Acquirer_ID, NETWORKID, Ben_Account_Number, Bene_IFSC_CODE, REM_ACCOUNT_NUMBER, REM_IFSC_CODE, Transaction_Currency_Code, Transaction_Amount, ACCTUALTRANAMOUNT,
                                       TRANSACCVITYFEE, ISSUERSETCURRENCYCODE, ISSURESETAMOUNT, ISSUERSETFEE, ISSURESETPROCFEE, CARDHOLDERBILLCURNCCODE, CARDHOLDERBILLAMOUNT, CARDHOLDERBILACTFEE, CARDHOLDERBILPROFEE,
                                       CARDHOLDERBILSRVICEFEE, TRAN_ISSUERCONVERSRATE, TRANS_CARDHOLDERCONVERRATE,
                                        System.DateTime.Now, System.DateTime.Now, UserName, UserName, Cycle, FileName, FileDate, path,null,null);

                    LineNo++;
                    InsertCount++;
                }
                catch (Exception ex)
                {

                    InsertCount--;

                }


            }

            return _DataTable;

        }
       

    }
}
