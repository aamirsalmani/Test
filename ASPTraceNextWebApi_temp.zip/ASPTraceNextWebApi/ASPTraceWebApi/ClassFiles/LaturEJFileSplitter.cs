﻿using ImportData;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using Utility;

namespace ASPTraceWebApi
{
    public class LaturEJFileSplitter
{
        private readonly string _MekKey1;
        private readonly string _MekKey2;
        private readonly string _connectionString;
        BulkImports bulkimports;
        public LaturEJFileSplitter(string connectionString, string EMekKey1, string EMekKey2)
        {
            _connectionString = connectionString;
            _MekKey1 = EMekKey1;
            _MekKey2 = EMekKey2;
            bulkimports = new BulkImports(_connectionString, _MekKey1, _MekKey2);
        }

        internal int GetIndex(string[] aryLines, int StartIndex, string searchStr)
        {
            int idx = -1;
            try
            {
                if (aryLines != null && aryLines.Length > 0)
                {
                    bool found = false;
                    for (idx = StartIndex; idx < aryLines.Length; idx++)
                    {
                        if (aryLines[idx].Contains(searchStr))
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        idx = -1;
                }
            }
            catch { }
            return idx;
        }
        internal static string RemoveAdditionalChars(string input)
        {
            input = input.Trim().ToUpper();
            string pattern = "\\s+";
            string replacement = " ";
            Regex rgx = new Regex(pattern);
            string result = rgx.Replace(input, replacement);
            return result;
        }

        public DataTable SplitEJData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTimeConverter objDateTimeConverter = new DateTimeConverter();
            System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");
            
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("CustAccountNo", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("RequestAmount", typeof(string));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("Amount2", typeof(decimal));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            _DataTable.Columns.Add("OPCode", typeof(string));
            _DataTable.Columns.Add("ErrorCode", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("NotesPresented1", typeof(string));
            _DataTable.Columns.Add("NotesPresented2", typeof(string));
            _DataTable.Columns.Add("NotesPresented3", typeof(string));
            _DataTable.Columns.Add("NotesPresented4", typeof(string));
            _DataTable.Columns.Add("Denomination1", typeof(string));
            _DataTable.Columns.Add("Denomination2", typeof(string));
            _DataTable.Columns.Add("Denomination3", typeof(string));
            _DataTable.Columns.Add("Denomination4", typeof(string));
            _DataTable.Columns.Add("Dispensed1", typeof(string));
            _DataTable.Columns.Add("Dispensed2", typeof(string));
            _DataTable.Columns.Add("Dispensed3", typeof(string));
            _DataTable.Columns.Add("Dispensed4", typeof(string));
            _DataTable.Columns.Add("Rejected1", typeof(string));
            _DataTable.Columns.Add("Rejected2", typeof(string));
            _DataTable.Columns.Add("Rejected3", typeof(string));
            _DataTable.Columns.Add("Rejected4", typeof(string));
            _DataTable.Columns.Add("Remaining1", typeof(string));
            _DataTable.Columns.Add("Remaining2", typeof(string));
            _DataTable.Columns.Add("Remaining3", typeof(string));
            _DataTable.Columns.Add("Remaining4", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("NoOfDuplicate", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;

            DataTable dsDEK = Utility.Common.GetEncryptedDEK(_connectionString);
            DataSet dsCardNetwork = Utility.Common.GetCardNetwork(_connectionString);

            
            
            
            

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;


            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string CustAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            decimal TxnsAmount = 0;
            decimal ReqAmount = 0;
            string Amount1 = "0";
            string Amount2 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string AuthCode = string.Empty;

            string CurrencyCode = "356";
            string CustBalance = "0";

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string line = string.Empty;
            string line1 = string.Empty;
            string ResponseCode = string.Empty;
            string EJResult = string.Empty;
            string ErrorCode = string.Empty;
            string Opcode = string.Empty;
            string ECardNumber = string.Empty;
            string StrDateTime = string.Empty;
            string StrTime = string.Empty;

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            string tempCardNumber = string.Empty;
            int ModeID = 0;
            //int ChannelID;
            DateTime? TxnsDateTimeMain = null;

            DateTime? FileDate = null;
            try
            {
                FileDate = DateTime.ParseExact(FileName.Substring(FileName.IndexOf("_") + 1, 8).Trim(), "yyyyMMdd", CultureInfo.InvariantCulture);
            }
            catch
            {

            }

            bool card = false;
            bool Terminal = false;
            bool Acquirer = false;
            bool Rev1 = false;
            bool Rev2 = false;
            bool ATM = false;
            bool CDM = false;
            bool POS = false;
            bool ECOM = false;
            bool IMPS = false;
            bool UPI = false;
            bool MicroATM = false;
            bool MobileRecharge = false;
            bool BAL = false;
            bool MS = false;
            bool PC = false;
            bool CB = false;
            bool RCA1 = false;
            bool RCA2 = false;
            //bool MC = false;
            //bool VC = false;
            bool OC = false;
            bool D = false;
            bool C = false;

            string SplitType = ",";
            string[] TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] AcquirerIDArray = dt.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode1Array = dt.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode2Array = dt.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ReversalType = dt.Rows[0]["ReversalType"].ToString();
            string[] ATMType = dt.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CDMType = dt.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] POSType = dt.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ECOMType = dt.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] IMPType = dt.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] UPIType = dt.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MicroATMType = dt.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MobileRechargeType = dt.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BalanceEnquiry = dt.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MiniStatement = dt.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] PinChange = dt.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ChequeBookReq = dt.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ResponseType = dt.Rows[0]["ResponseType"].ToString();
            string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ResponseCode2Array = dt.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] OfflineCode = dt.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnDateTime = dt.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnPostDateTime = dt.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] DebitCode = dt.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CreditCode = dt.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);



            string[] Notes = new string[4];
            string[] Denominations = new string[5];
            string[] Dispenseds = new string[5];
            string[] Rejecteds = new string[5];
            string[] Remainings = new string[5];

            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;

            string Denomination1 = string.Empty;
            string Denomination2 = string.Empty;
            string Denomination3 = string.Empty;
            string Denomination4 = string.Empty;

            bool CassetteFetch = false;

            int i = 0;

            for (int j = 0; j <= TotalCount; j++)
            {
                try
                {
                    StartIndex = Utility.Common.GetIndex(TotalCountArray, j, "TRANSACTION START");
                    EndIndex = Utility.Common.GetIndex(TotalCountArray, StartIndex + 1, "TRANSACTION END");

                    ReqAmount = 0;
                    //TerminalID = string.Empty;
                    AcquirerID = string.Empty;
                    ReferenceNumber = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsDate = string.Empty;
                    TxnsTime = string.Empty;
                    TxnsAmount = 0;
                    Amount1 = "0";
                    Amount2 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;

                    CustBalance = "0";
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    ResponseCode = string.Empty;
                    EJResult = string.Empty;
                    ErrorCode = string.Empty;
                    Opcode = string.Empty;
                    ECardNumber = string.Empty;
                    CardType = string.Empty;
                    TxnsStatus = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    DebitCreditType = string.Empty;


                    Denomination1 = string.Empty;
                    Denomination2 = string.Empty;
                    Denomination3 = string.Empty;
                    Denomination4 = string.Empty;

                    Array.Clear(Notes, 0, Notes.Length);
                    Array.Clear(Dispenseds, 0, Dispenseds.Length);
                    Array.Clear(Denominations, 0, Denominations.Length);
                    Array.Clear(Rejecteds, 0, Rejecteds.Length);
                    Array.Clear(Remainings, 0, Remainings.Length);
                    

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex + 1; k <= EndIndex - 1; k++)
                        {

                            try
                            {

                                LineNo++;

                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = RemoveAdditionalChars(line);

                                if (EJResult.Contains("REF NO"))
                                {
                                    string[] Arr_REFNO = EJResult.Split(':');

                                    int V = Arr_REFNO.Length;


                                    if (V == 2)
                                    {
                                        ReferenceNumber = Arr_REFNO[1].Trim();
                                        AuthCode = Arr_REFNO[1].Trim();

                                        if (ReferenceNumber == "214317002904")
                                        {
                                        }
                                    }
                                }

                                if (EJResult.Contains("ATM NO"))
                                {
                                    TerminalID = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("CARD NO"))
                                {
                                    string[] CARD_AUTH = EJResult.Split(':');
                                    int P = CARD_AUTH.Length;
                                    if (P == 2)
                                    {
                                        CardNumber = CARD_AUTH[1].Trim();
                                    }
                                }

                                else if (EJResult.ToUpper().Contains("AMOUNT") && EJResult.Contains("ENTERED"))
                                {
                                    ReqAmount = Convert.ToDecimal(Regex.Match(EJResult.Substring(EJResult.IndexOf("AMOUNT") + 6).Trim(), @"\d+").Value);
                                }
                                else if (EJResult.Contains("OPCODE"))
                                {
                                    Opcode = EJResult.Substring(EJResult.IndexOf("=") + 1).Trim();
                                }


                                if (EJResult.Contains("DATE"))  // || TotalCountArray[k - 1].ToString().Contains("/")
                                {
                                    StrDateTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsDate = StrDateTime;
                                }

                                if (EJResult.Contains("TIME") && !(EJResult.Contains("Timeout")) && !(EJResult.Contains("TIMEOUT")) && !(EJResult.Contains("PRESENT TIMER EXPIRED"))) //|| TotalCountArray[k - 1].ToString().Contains("/")                                   
                                {
                                    StrTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsTime = StrTime;
                                }

                                else if (EJResult.Contains("DATE") && EJResult.Contains("TIME"))
                                {
                                    TxnsDate = EJResult.Substring(4, EJResult.IndexOf("TIME") - 4).Trim();
                                    TxnsTime = EJResult.Substring(EJResult.IndexOf("TIME") + 4).Trim();
                                }
                                else if (EJResult.Contains("DATE"))
                                {
                                    TxnsDate = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("TIME"))
                                {
                                    TxnsTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("A/C NO"))
                                {
                                    CustAccountNo = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("TRANSTYPE"))
                                {
                                    TxnsSubType = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("RESP CODE"))
                                {
                                    ResponseCode = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("WDL AMT"))
                                {
                                    TxnsAmount = Convert.ToDecimal(EJResult.Substring(EJResult.IndexOf(":") + 1).Trim());
                                }
                                else if (EJResult.Contains("BALANCE"))
                                {
                                    CustBalance = Convert.ToDecimal(Regex.Match(EJResult.Substring(EJResult.IndexOf(":") + 1).Trim(), @"\d+(?:\.\d+)").Value).ToString();

                                }
                                else if (EJResult.Contains("NOTES STACKED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES STACKED";
                                }
                                else if (EJResult.Contains("NOTES PRESENTED"))
                                {
                                    Notes = EJResult.Substring(EJResult.IndexOf("PRESENTED") + 10).Trim().Split(',');
                                    TxnsPerticulars = TxnsPerticulars + " NOTES PRESENTED";
                                }
                                else if (EJResult.Contains("NOTES TAKEN"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES TAKEN";
                                    TxnsStatus = "Sucessfull";
                                }
                                else if (EJResult.Contains("NOTES DEPOSITED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES DEPOSITED";

                                    TxnsAmount = TotalCountArray[k + 6].Contains("TOTAL") ? Utility.Common.ExtractDecimal(TotalCountArray[k + 6]) : 0;
                                }
                                else if (EJResult.Contains("DENOMINATION"))
                                {
                                    Denominations = EJResult.Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("DISPENSED"))
                                {
                                    if (EJResult.Contains("DISPENSED NOTES :PRESENT"))
                                    {
                                        Notes = new string[4];
                                        Notes[0] = TotalCountArray[k + 1].Substring(TotalCountArray[k + 1].IndexOf("=") + 1).Trim();
                                        Notes[1] = TotalCountArray[k + 2].Substring(TotalCountArray[k + 2].IndexOf("=") + 1).Trim();
                                        Notes[2] = TotalCountArray[k + 3].Substring(TotalCountArray[k + 3].IndexOf("=") + 1).Trim();
                                        Notes[3] = TotalCountArray[k + 4].Substring(TotalCountArray[k + 4].IndexOf("=") + 1).Trim();
                                    }

                                    Dispenseds = EJResult.Split(' ');

                                    if (Dispenseds.Length != 5)
                                    {
                                        Dispenseds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REMAINING"))
                                {
                                    Remainings = EJResult.Split(' ');

                                    if (Remainings.Length != 5)
                                    {
                                        Remainings = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REJECTED"))
                                {
                                    Rejecteds = EJResult.Split(' ');

                                    if (Rejecteds.Length != 5)
                                    {
                                        Rejecteds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REJECT COUNT"))
                                {
                                    Rejecteds = EJResult.Replace("[", ",").Replace("]", "").Split(',');

                                    if (Rejecteds.Length != 5)
                                    {
                                        Rejecteds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REMAIN COUNT"))
                                {
                                    Remainings = EJResult.Replace("[", ",").Replace("]", "").Split(',');

                                    if (Remainings.Length != 5)
                                    {
                                        Remainings = new string[5];
                                    }
                                }
                                //else if (EJResult.Contains("PICKUP COUNT"))
                                //{
                                //    Notes = EJResult.Replace("PICKUP COUNT [", "").Replace("]", "").Split(',');

                                //    if (Notes.Length != 4)
                                //    {
                                //        Notes = new string[4];
                                //    }
                                //}
                                else if (EJResult.Contains("DISPENSE COUNT"))
                                {
                                    Dispenseds = EJResult.Replace("[", ",").Replace("]", "").Split(',');

                                    if (Dispenseds.Length != 5)
                                    {
                                        Dispenseds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("NO FUNDS AVAILABLE"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ERROR"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("UNABLE TO PROCESS"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("POWER-UP/RESET"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("LIMIT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ENTER LESSER AMOUNT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ENTER AMOUNT MULTIPLE OF"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("INCORRECT PIN"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("SECURITY KEY VOILATION"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("PIN RETRIES EXCEEDED"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("INVALID TRANSACTION"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("DO NOT HONOUR"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("NO FROM ACCOUNT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("(1*"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }

                                j = EndIndex;
                            }
                            catch
                            {
                                j = EndIndex;
                            }
                        }
                    }
                    #region StanderedFields

                    ReversalFlag = false;
                    TxnsStatus = string.Empty;
                    DebitCreditType = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    CardType = string.Empty;

                    TxnsDateTimeMain = null;

                    card = false;
                    Terminal = false;
                    Acquirer = false;
                    Rev1 = false;
                    Rev2 = false;
                    ATM = false;
                    CDM = false;
                    POS = false;
                    ECOM = false;
                    IMPS = false;
                    UPI = false;
                    MicroATM = false;
                    MobileRecharge = false;
                    BAL = false;
                    MS = false;
                    PC = false;
                    CB = false;
                    RCA1 = false;
                    RCA2 = false;
                    //MC = false;
                    //VC = false;
                    OC = false;
                    D = false;
                    C = false;

                    if (CardNumber != "")
                    {
                        if (CardNumber.Substring(0, 1) == "4")
                        {
                            CardType = "VISA";
                        }
                        else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                        {
                            CardType = "MASTER";
                        }
                        else if (CardNumber.Substring(0, 2) == "62")
                        {
                            CardType = "CUP";
                        }
                        else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                        {
                            CardType = "RuPay";
                        }
                        else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                        {
                            CardType = "Maestro";
                        }
                    }


                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        try
                        {
                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + " " + TxnsTime, TxnDateTime, CultureInfo.InvariantCulture, DateTimeStyles.None);
                        }
                        catch
                        {

                        }

                    }

                    if (TerminalID.Length > 0 && !CassetteFetch)
                    {
                        DataTable dataTable = Utility.Common.GetCassetteInfoByTerminalId(_connectionString, ClientCode, TerminalID);

                        if (dataTable != null && dataTable.Rows.Count > 0)
                        {
                            Cassette1 = Convert.ToString(dataTable.Rows[0]["Cassette1"]);
                            Cassette2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                            Cassette3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                            Cassette4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);

                        }

                        dataTable = null;
                        CassetteFetch = true;
                    }


                    if (FileDate == null)
                    {
                        FileDate = TxnsDateTimeMain;
                    }

                    if (CassetteFetch)
                    {
                        //if (Notes != null && Notes.Length == 4)
                        //{
                        //    Denomination1 = Cassette1.Length == 0 ? Notes[0] : Convert.ToString(Convert.ToDecimal(Cassette1) * Convert.ToDecimal(Notes[0]));
                        //    Denomination2 = Cassette2.Length == 0 ? Notes[1] : Convert.ToString(Convert.ToDecimal(Cassette2) * Convert.ToDecimal(Notes[1]));
                        //    Denomination3 = Cassette3.Length == 0 ? Notes[2] : Convert.ToString(Convert.ToDecimal(Cassette3) * Convert.ToDecimal(Notes[2]));
                        //    Denomination4 = Cassette4.Length == 0 ? Notes[3] : Convert.ToString(Convert.ToDecimal(Cassette4) * Convert.ToDecimal(Notes[3]));
                        //}
                        //else
                        //{
                        //    Denomination1 = Notes[0];
                        //    Denomination2 = Notes[1];
                        //    Denomination3 = Notes[2];
                        //    Denomination4 = Notes[3];
                        //}

                        Denomination1 = Cassette1.Length == 0 ? "0" : Cassette1;
                        Denomination2 = Cassette2.Length == 0 ? "0" : Cassette2;
                        Denomination3 = Cassette3.Length == 0 ? "0" : Cassette3;
                        Denomination4 = Cassette4.Length == 0 ? "0" : Cassette4;
                    }
                    else
                    {
                        Denomination1 = "0";
                        Denomination2 = "0";
                        Denomination3 = "0";
                        Denomination4 = "0";
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                                break;
                            }
                        }
                    }


                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                                break;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                            {
                                card = true;
                                break;
                            }
                        }
                    }



                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                                break;
                            }
                        }
                    }
                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                                break;
                            }
                        }
                        for (i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                                break;
                            }
                        }
                    }




                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                    break;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                    break;
                                }
                            }
                        }

                        //if (POSType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < POSType.Length; i++)
                        //    {
                        //        if (POSType[i].ToString() == TxnsSubType)
                        //        {
                        //            POS = true;
                        //        }
                        //    }
                        //}
                        //if (ECOMType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < ECOMType.Length; i++)
                        //    {
                        //        if (ECOMType[i].ToString() == TxnsSubType)
                        //        {
                        //            ECOM = true;
                        //        }
                        //    }
                        //}

                        //if (IMPType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < IMPType.Length; i++)
                        //    {
                        //        if (IMPType[i].ToString() == TxnsSubType)
                        //        {
                        //            IMPS = true;
                        //        }
                        //    }
                        //}

                        //if (UPIType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < UPIType.Length; i++)
                        //    {
                        //        if (UPIType[i].ToString() == TxnsSubType)
                        //        {
                        //            UPI = true;
                        //        }
                        //    }
                        //}

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType)
                                {
                                    MicroATM = true;
                                    break;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                    break;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType)
                                {
                                    ATM = true;
                                    break;
                                }
                            }
                        }

                        //if (POSType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < POSType.Length; i++)
                        //    {
                        //        if (POSType[i].ToString() == ChannelType)
                        //        {
                        //            POS = true;
                        //        }
                        //    }
                        //}
                        //if (ECOMType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < ECOMType.Length; i++)
                        //    {
                        //        if (ECOMType[i].ToString() == ChannelType)
                        //        {
                        //            ECOM = true;
                        //        }
                        //    }
                        //}

                        //if (IMPType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < IMPType.Length; i++)
                        //    {
                        //        if (IMPType[i].ToString() == ChannelType)
                        //        {
                        //            IMPS = true;
                        //        }
                        //    }
                        //}

                        //if (UPIType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < UPIType.Length; i++)
                        //    {
                        //        if (UPIType[i].ToString() == ChannelType)
                        //        {
                        //            UPI = true;
                        //        }
                        //    }
                        //}

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType)
                                {
                                    MicroATM = true;
                                    break;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                    break;
                                }
                            }
                        }
                    }


                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                                break;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                                break;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                                break;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                                break;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                                break;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                                break;
                            }
                        }

                        for (i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode)
                            {
                                RCA2 = true;
                                break;
                            }
                        }
                    }


                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() == "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                                break;
                            }
                        }
                    }



                    if (DebitCode[0].ToString() != "")
                    {
                        for (i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                                break;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                                break;
                            }
                        }
                    }


                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    if (AcquirerID == string.Empty || AcquirerID == "")
                    {
                        if (Terminal == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        else if (Terminal == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        else if (Terminal == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }
                    else
                    {
                        if (Acquirer == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        else if (Acquirer == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        else if (Acquirer == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }

                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    if (RCA1 == true || RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }
                    else
                    {
                        TxnsStatus = "Unsucessfull";
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    else if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                    }
                    else if (POS)
                    {
                        TxnsSubTypeMain = "Purchase";
                    }
                    else if (ECOM)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (IMPS)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (MicroATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    else if (MobileRecharge)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (UPI)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }
                    else if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }
                    else if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }
                    else if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }


                    if (BAL || MS || PC || CB)
                    {
                        TxnsType = "Non-Financial";
                    }
                    else
                    {
                        TxnsType = "Financial";
                    }
                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    #endregion InitilizedField


                    //#endregion StanderedFields

                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }

                    if (CardNumber != "")
                    {
                        string dummy = "XXXXXXXXXX";
                        tempCardNumber = CardNumber;

                        CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);

                        ReserveField5 = ReserveField5.Replace(tempCardNumber, CardNumber);
                    }

                    if (ReserveField5.Length >= 3900)
                    {
                        ReserveField5 = ReserveField5.Substring(0, 3900);
                    }

                    CustBalance = CustBalance == "" ? "0" : CustBalance;
                    Amount1 = Amount1 == "" ? "0" : Amount1;
                    Amount2 = Amount2 == "" ? "0" : Amount2;

                    if (TxnsDateTimeMain != null && ReferenceNumber != "")
                    {
                        _DataTable.Rows.Add(
                                        ClientID
                                        , (int)TxnsChannelID.ATM
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , CardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , Convert.ToDecimal(CustBalance)
                                        , TxnsDateTimeMain
                                        , TxnsAmount
                                        , ReqAmount
                                        , Convert.ToDecimal(Amount1)
                                        , Convert.ToDecimal(Amount2)
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubTypeMain
                                        , TxnsEntryType
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , AuthCode
                                        , CurrencyCode
                                        , Opcode
                                        , ErrorCode
                                        , ReversalFlag
                                        , Notes[0]
                                        , Notes[1]
                                        , Notes[2]
                                        , Notes[3]
                                        , Denomination1
                                        , Denomination2
                                        , Denomination3
                                        , Denomination4
                                        , Dispenseds[1]
                                        , Dispenseds[2]
                                        , Dispenseds[3]
                                        , Dispenseds[4]
                                        , Rejecteds[1]
                                        , Rejecteds[2]
                                        , Rejecteds[3]
                                        , Rejecteds[4]
                                        , Remainings[1]
                                        , Remainings[2]
                                        , Remainings[3]
                                        , Remainings[4]
                                        , ReserveField1
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , 0
                                        , FileName
                                        , path
                                        , FileDate
                                        , DateTime.Now
                                        , DateTime.Now
                                        , UserName
                                        , ""
                                        , ECardNumber.Trim()
                                        );

                    }


                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }
            return _DataTable;
        }
    }
}
