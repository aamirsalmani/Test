﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using Utility;
using Excel = Microsoft.Office.Interop.Excel;

namespace ASPTraceWebApi
{
    public class LaturGLFileSplitter
    {
        Utility.DateTimeConverter objDateTimeConverter = new Utility.DateTimeConverter();
        System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");

        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public LaturGLFileSplitter(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }
        public DataTable SplitGLData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode, DataTable _DataTable)
        {
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;

            
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            
            

            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            string[] arrLines;
            string m_RecordData = string.Empty;
            string FileName1 = Path.GetFileNameWithoutExtension(path);
            string FileDate = FileName.Substring(FileName1.Length - 6, 6);
            string MM = FileDate.Substring(2, 2);
            try
            {
                string ChannelID = string.Empty;
                string TerminalID = string.Empty;
                string ModeID = string.Empty;
                string AcquirerID = string.Empty;
                string ReferenceNumber = string.Empty;
                string CardNumber = string.Empty;
                string CardType = string.Empty;
                string TxnsStatus = string.Empty;
                string TxnsType = string.Empty;
                string TxnsSubTypeMain = string.Empty;
                string TxnsEntryType = string.Empty;
                string CustAccountNo = string.Empty;
                string InterchangeAccountNo = string.Empty;
                string ATMAccountNo = string.Empty;
                string TxnsDateTime = string.Empty;
                string TxnsDate = string.Empty;
                string TxnsTime = string.Empty;
                string TxnsAmount = "0";
                string Amount1 = "0";
                string Amount2 = "0";
                string Amount3 = "0";
                string ChannelType = string.Empty;
                //string TxnsSubType = string.Empty;
                string TxnsNumber = string.Empty;
                string TxnsPerticulars = string.Empty;
                string DrCrType = string.Empty;
                string ResponseCode1 = string.Empty;
                string ResponseCode2 = string.Empty;
                string ReversalCode1 = string.Empty;
                string ReversalCode2 = string.Empty;
                string TxnsPostDateTime = string.Empty;
                string TxnsValueDateTime = string.Empty;
                string AuthCode = string.Empty;
                string ProcessingCode = string.Empty;
                string FeeAmount = "0";
                string CurrencyCode = string.Empty;
                string CustBalance = "0";
                string InterchangeBalance = "0";
                string ATMBalance = "0";
                string BranchCode = string.Empty;
                string ReserveField1 = string.Empty;
                string ReserveField2 = string.Empty;
                string ReserveField3 = string.Empty;
                string ReserveField4 = string.Empty;
                string ReserveField5 = string.Empty;
                string NoOfDuplicate = string.Empty;
                string ECardNumber = string.Empty;
                string acc_temp = string.Empty;
                string acc_temp1 = string.Empty;
                string acc_temp2 = string.Empty;
                string GLHead = string.Empty;
                string Perticulars = string.Empty;
                string Terminal = string.Empty;

                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1\'";

                string extension = Path.GetExtension(path);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1\'";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        break;
                }

                objConn = new OleDbConnection(connString);
                objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null); 

                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(dtexcelsheetname.Rows[0]["TABLE_NAME"]).Replace("'", "") + "]";

                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dtfillsheet1 = new DataTable();
                da.Fill(dtfillsheet1);


                objConn.Close();
                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {
                    try
                    {
                        dtfillsheet1.Rows[i][6].ToString();
                        ReferenceNumber = dtfillsheet1.Rows[i][8].ToString();
                        GLHead = dtfillsheet1.Rows[i][6].ToString();
                        Perticulars = dtfillsheet1.Rows[i][8].ToString();
                        Terminal = dtfillsheet1.Rows[i][3].ToString();

                        if (GLHead.Contains("ABB"))
                        {
                            string[] pathnamearray = ReferenceNumber.Split(':');
                            ChannelID = "1";
                            ModeID = "1";
                            ReserveField1 = "O";
                            TxnsSubTypeMain = "Withdrawl";
                            ReferenceNumber = pathnamearray[6].Substring(0, 12).Trim();
                            AuthCode = ReferenceNumber.Substring(6, 6).Trim();
                            CardNumber = pathnamearray[5].ToString().Trim();
                            TerminalID = pathnamearray[2].Trim();
                            ResponseCode1 = "00";

                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);
                            }

                            if (CardNumber != "")
                            {
                                string dummy = "XXXXXXXXXX";
                                CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();

                            }

                            TxnsDateTime = dtfillsheet1.Rows[i][1].ToString();
                            TxnsPostDateTime = dtfillsheet1.Rows[i][2].ToString();
                            TxnsValueDateTime = dtfillsheet1.Rows[i][4].ToString();
                            TxnsStatus = "Sucessfull";
                            TxnsType = "Financial";
                            TxnsEntryType = "Auto";

                            if (pathnamearray[3].Length == 3)
                                acc_temp1 = pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 2)
                                acc_temp1 = "0" + pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 1)
                                acc_temp1 = "00" + pathnamearray[3].Trim();

                            acc_temp2 = pathnamearray[4].Trim();
                            string[] temp = acc_temp2.Split('/');

                            if (temp[0].Length == 3)
                                acc_temp = temp[0].Trim() + "0";
                            if (temp[0].Length == 2)
                                acc_temp = temp[0].Trim() + "00";

                            if (temp[1].Length == 8)
                                CustAccountNo = temp[1].Trim();
                            if (temp[1].Length == 7)
                                CustAccountNo = "0" + temp[1].Trim();
                            if (temp[1].Length == 6)
                                CustAccountNo = "00" + temp[1].Trim();
                            if (temp[1].Length == 5)
                                CustAccountNo = "000" + temp[1].Trim();
                            if (temp[1].Length == 4)
                                CustAccountNo = "0000" + temp[1].Trim();
                            if (temp[1].Length == 3)
                                CustAccountNo = "00000" + temp[1].Trim();
                            if (temp[1].Length == 2)
                                CustAccountNo = "000000" + temp[1].Trim();
                            if (temp[1].Length == 1)
                                CustAccountNo = "0000000" + temp[1].Trim();

                            CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;
                        }
                        else if (GLHead.Contains("ATMOTH"))
                        {
                            ChannelID = "2";
                            ModeID = "3";
                            ReserveField1 = "I";
                            TxnsSubTypeMain = "Purchase";
                            ReferenceNumber = dtfillsheet1.Rows[i][7].ToString();
                            TxnsDateTime = dtfillsheet1.Rows[i][1].ToString();
                            TxnsPostDateTime = dtfillsheet1.Rows[i][2].ToString();
                            TxnsValueDateTime = dtfillsheet1.Rows[i][4].ToString();
                            TxnsStatus = "Sucessfull";
                            TxnsType = "Financial";
                            TxnsEntryType = "Auto";
                            ResponseCode1 = "00";

                            string[] pathnamearray = ReferenceNumber.Split('/');
                            if (pathnamearray[3].Length == 3)
                                acc_temp1 = pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 2)
                                acc_temp1 = "0" + pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 1)
                                acc_temp1 = "00" + pathnamearray[3].Trim();

                            if (pathnamearray[4].Length == 3)
                                acc_temp = pathnamearray[4].Trim() + "0";
                            if (pathnamearray[4].Length == 2)
                                acc_temp = pathnamearray[4].Trim() + "00";

                            if (pathnamearray[5].Length == 8)
                                CustAccountNo = pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 7)
                                CustAccountNo = "0" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 6)
                                CustAccountNo = "00" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 5)
                                CustAccountNo = "000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 4)
                                CustAccountNo = "0000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 3)
                                CustAccountNo = "00000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 2)
                                CustAccountNo = "000000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 1)
                                CustAccountNo = "0000000" + pathnamearray[5].Trim();

                            CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;

                        }
                        else if (GLHead.Contains("CA") && Terminal.Contains("ATM"))
                        {
                            string[] pathnamearray = ReferenceNumber.Split(':');
                            ChannelID = "1";
                            ModeID = "1";
                            ReserveField1 = "O";
                            TxnsSubTypeMain = "Withdrawl";
                            ReferenceNumber = pathnamearray[4].Substring(0, 12).Trim();
                            AuthCode = ReferenceNumber.Substring(6, 6).Trim();
                            CardNumber = pathnamearray[3].ToString().Trim();
                            TerminalID = pathnamearray[1].ToString().Trim();
                            ResponseCode1 = "00";
                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);
                            }

                            if (CardNumber != "")
                            {
                                string dummy = "XXXXXXXXXX";
                                CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();

                            }

                            TxnsDateTime = dtfillsheet1.Rows[i][1].ToString();
                            TxnsPostDateTime = dtfillsheet1.Rows[i][2].ToString();
                            TxnsValueDateTime = dtfillsheet1.Rows[i][4].ToString();
                            TxnsStatus = "Sucessfull";
                            TxnsType = "Financial";
                            TxnsEntryType = "Auto";
                            ResponseCode1 = "00";
                            if (ReferenceNumber.Contains("Rev"))
                            {
                                if (pathnamearray[3].Length == 3)
                                    acc_temp1 = pathnamearray[3].Trim();
                                if (pathnamearray[3].Length == 2)
                                    acc_temp1 = "0" + pathnamearray[3].Trim();
                                if (pathnamearray[3].Length == 1)
                                    acc_temp1 = "00" + pathnamearray[3].Trim();
                                acc_temp2 = pathnamearray[6].Trim();
                                string[] temp1 = acc_temp2.Split('/');
                                if (temp1[0].Length == 3)
                                    acc_temp = temp1[0].Trim() + "0";
                                if (temp1[0].Length == 2)
                                    acc_temp = temp1[0].Trim() + "00";

                                if (temp1[1].Length == 8)
                                    CustAccountNo = temp1[1].Trim();
                                if (temp1[1].Length == 7)
                                    CustAccountNo = "0" + temp1[1].Trim();
                                if (temp1[1].Length == 6)
                                    CustAccountNo = "00" + temp1[1].Trim();
                                if (temp1[1].Length == 5)
                                    CustAccountNo = "000" + temp1[1].Trim();
                                if (temp1[1].Length == 4)
                                    CustAccountNo = "0000" + temp1[1].Trim();
                                if (temp1[1].Length == 3)
                                    CustAccountNo = "00000" + temp1[1].Trim();
                                if (temp1[1].Length == 2)
                                    CustAccountNo = "000000" + temp1[1].Trim();
                                if (temp1[1].Length == 1)
                                    CustAccountNo = "0000000" + temp1[1].Trim();
                                CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;
                            }

                            else
                            {
                                if (pathnamearray[2].Length == 3)
                                    acc_temp1 = pathnamearray[2].Trim();
                                if (pathnamearray[2].Length == 2)
                                    acc_temp1 = "0" + pathnamearray[2].Trim();
                                if (pathnamearray[2].Length == 1)
                                    acc_temp1 = "00" + pathnamearray[2].Trim();
                                acc_temp2 = pathnamearray[5].Trim();
                                string[] temp = acc_temp2.Split('/');
                                if (temp[0].Length == 3)
                                    acc_temp = temp[0].Trim() + "0";
                                if (temp[0].Length == 2)
                                    acc_temp = temp[0].Trim() + "00";

                                if (temp[1].Length == 8)
                                    CustAccountNo = temp[1].Trim();
                                if (temp[1].Length == 7)
                                    CustAccountNo = "0" + temp[1].Trim();
                                if (temp[1].Length == 6)
                                    CustAccountNo = "00" + temp[1].Trim();
                                if (temp[1].Length == 5)
                                    CustAccountNo = "000" + temp[1].Trim();
                                if (temp[1].Length == 4)
                                    CustAccountNo = "0000" + temp[1].Trim();
                                if (temp[1].Length == 3)
                                    CustAccountNo = "00000" + temp[1].Trim();
                                if (temp[1].Length == 2)
                                    CustAccountNo = "000000" + temp[1].Trim();
                                if (temp[1].Length == 1)
                                    CustAccountNo = "0000000" + temp[1].Trim();
                                CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;
                            }
                        }
                        else if (GLHead.Contains("CA") && Terminal.Contains("ABB") && ReferenceNumber.Contains("ATM"))
                        {
                            ChannelID = "1";
                            ModeID = "3";
                            ReserveField1 = "I";
                            TxnsSubTypeMain = "Withdrawl";
                            ReferenceNumber = dtfillsheet1.Rows[i][7].ToString();
                            TxnsDateTime = dtfillsheet1.Rows[i][1].ToString();
                            TxnsPostDateTime = dtfillsheet1.Rows[i][2].ToString();
                            TxnsValueDateTime = dtfillsheet1.Rows[i][4].ToString();
                            TxnsStatus = "Sucessfull";
                            TxnsType = "Financial";
                            TxnsEntryType = "Auto";
                            ResponseCode1 = "00";

                            string[] pathnamearray = ReferenceNumber.Split('/');
                            if (pathnamearray[3].Length == 3)
                                acc_temp1 = pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 2)
                                acc_temp1 = "0" + pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 1)
                                acc_temp1 = "00" + pathnamearray[3].Trim();

                            if (pathnamearray[4].Length == 3)
                                acc_temp = pathnamearray[4].Trim() + "0";
                            if (pathnamearray[4].Length == 2)
                                acc_temp = pathnamearray[4].Trim() + "00";

                            if (pathnamearray[5].Length == 8)
                                CustAccountNo = pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 7)
                                CustAccountNo = "0" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 6)
                                CustAccountNo = "00" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 5)
                                CustAccountNo = "000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 4)
                                CustAccountNo = "0000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 3)
                                CustAccountNo = "00000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 2)
                                CustAccountNo = "000000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 1)
                                CustAccountNo = "0000000" + pathnamearray[5].Trim();

                            CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;
                        }
                        else if (GLHead.Contains("CA") && Terminal.Contains("ABB") && ReferenceNumber.Contains("POS"))
                        {
                            ChannelID = "2";
                            ModeID = "3";
                            ReserveField1 = "I";
                            TxnsSubTypeMain = "Purchase";
                            ReferenceNumber = dtfillsheet1.Rows[i][7].ToString();
                            TxnsDateTime = dtfillsheet1.Rows[i][1].ToString();
                            TxnsPostDateTime = dtfillsheet1.Rows[i][2].ToString();
                            TxnsValueDateTime = dtfillsheet1.Rows[i][4].ToString();
                            TxnsStatus = "Sucessfull";
                            TxnsType = "Financial";
                            TxnsEntryType = "Auto";
                            ResponseCode1 = "00";

                            string[] pathnamearray = ReferenceNumber.Split('/');
                            if (pathnamearray[3].Length == 3)
                                acc_temp1 = pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 2)
                                acc_temp1 = "0" + pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 1)
                                acc_temp1 = "00" + pathnamearray[3].Trim();

                            if (pathnamearray[4].Length == 3)
                                acc_temp = pathnamearray[4].Trim() + "0";
                            if (pathnamearray[4].Length == 2)
                                acc_temp = pathnamearray[4].Trim() + "00";

                            if (pathnamearray[5].Length == 8)
                                CustAccountNo = pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 7)
                                CustAccountNo = "0" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 6)
                                CustAccountNo = "00" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 5)
                                CustAccountNo = "000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 4)
                                CustAccountNo = "0000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 3)
                                CustAccountNo = "00000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 2)
                                CustAccountNo = "000000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 1)
                                CustAccountNo = "0000000" + pathnamearray[5].Trim();

                            CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;
                        }
                        else if (GLHead.Contains("NFS") && Terminal.Contains("ATM") && ReferenceNumber.Contains("ACQ"))
                        {
                            string[] pathnamearray = ReferenceNumber.Split(':');
                            ChannelID = "1";
                            ModeID = "2";
                            ReserveField1 = "A";
                            TxnsSubTypeMain = "Withdrawl";
                            ReferenceNumber = pathnamearray[4].Substring(0, 12).Trim();
                            AuthCode = ReferenceNumber.Substring(6, 6).Trim();
                            TerminalID = pathnamearray[1].Trim();
                            CardNumber = pathnamearray[3].ToString().Trim();
                            ResponseCode1 = "00";
                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);
                            }

                            if (CardNumber != "")
                            {
                                string dummy = "XXXXXXXXXX";
                                CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();

                            }

                            TxnsDateTime = dtfillsheet1.Rows[i][1].ToString();
                            TxnsPostDateTime = dtfillsheet1.Rows[i][2].ToString();
                            TxnsValueDateTime = dtfillsheet1.Rows[i][4].ToString();
                            TxnsStatus = "Sucessfull";
                            TxnsType = "Financial";
                            TxnsEntryType = "Auto";

                            if (ReferenceNumber.Contains("Rev"))
                            {
                                if (pathnamearray[3].Length == 3)
                                    acc_temp1 = pathnamearray[3].Trim();
                                if (pathnamearray[3].Length == 2)
                                    acc_temp1 = "0" + pathnamearray[3].Trim();
                                if (pathnamearray[3].Length == 1)
                                    acc_temp1 = "00" + pathnamearray[3].Trim();
                                acc_temp2 = pathnamearray[6].Trim();
                                string[] temp = acc_temp2.Split('/');
                                if (temp[0].Length == 3)
                                    acc_temp = temp[0].Trim() + "0";
                                if (temp[0].Length == 2)
                                    acc_temp = temp[0].Trim() + "00";

                                if (temp[1].Length == 8)
                                    CustAccountNo = temp[1].Trim();
                                if (temp[1].Length == 7)
                                    CustAccountNo = "0" + temp[1].Trim();
                                if (temp[1].Length == 6)
                                    CustAccountNo = "00" + temp[1].Trim();
                                if (temp[1].Length == 5)
                                    CustAccountNo = "000" + temp[1].Trim();
                                if (temp[1].Length == 4)
                                    CustAccountNo = "0000" + temp[1].Trim();
                                if (temp[1].Length == 3)
                                    CustAccountNo = "00000" + temp[1].Trim();
                                if (temp[1].Length == 2)
                                    CustAccountNo = "000000" + temp[1].Trim();
                                if (temp[1].Length == 1)
                                    CustAccountNo = "0000000" + temp[1].Trim();
                                CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;

                            }
                            else
                            {
                                if (pathnamearray[2].Length == 3)
                                    acc_temp1 = pathnamearray[2].Trim();
                                if (pathnamearray[2].Length == 2)
                                    acc_temp1 = "0" + pathnamearray[2].Trim();
                                if (pathnamearray[2].Length == 1)
                                    acc_temp1 = "00" + pathnamearray[2].Trim();
                                acc_temp2 = pathnamearray[5].Trim();
                                string[] temp = acc_temp2.Split('/');
                                if (temp[0].Length == 3)
                                    acc_temp = temp[0].Trim() + "0";
                                if (temp[0].Length == 2)
                                    acc_temp = temp[0].Trim() + "00";

                                if (temp[1].Length == 8)
                                    CustAccountNo = temp[1].Trim();
                                if (temp[1].Length == 7)
                                    CustAccountNo = "0" + temp[1].Trim();
                                if (temp[1].Length == 6)
                                    CustAccountNo = "00" + temp[1].Trim();
                                if (temp[1].Length == 5)
                                    CustAccountNo = "000" + temp[1].Trim();
                                if (temp[1].Length == 4)
                                    CustAccountNo = "0000" + temp[1].Trim();
                                if (temp[1].Length == 3)
                                    CustAccountNo = "00000" + temp[1].Trim();
                                if (temp[1].Length == 2)
                                    CustAccountNo = "000000" + temp[1].Trim();
                                if (temp[1].Length == 1)
                                    CustAccountNo = "0000000" + temp[1].Trim();
                                CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;
                            }
                        }
                        else if (GLHead.Contains("NFS") && Terminal.Contains("ABB") && ReferenceNumber.Contains("ATM"))
                        {
                            ChannelID = "1";
                            ModeID = "3";
                            ReserveField1 = "I";
                            TxnsSubTypeMain = "Withdrawl";
                            ReferenceNumber = dtfillsheet1.Rows[i][7].ToString();
                            TxnsDateTime = dtfillsheet1.Rows[i][1].ToString();
                            TxnsPostDateTime = dtfillsheet1.Rows[i][2].ToString();
                            TxnsValueDateTime = dtfillsheet1.Rows[i][4].ToString();
                            TxnsStatus = "Sucessfull";
                            TxnsType = "Financial";
                            TxnsEntryType = "Auto";
                            ResponseCode1 = "00";

                            string[] pathnamearray = ReferenceNumber.Split('/');
                            if (pathnamearray[3].Length == 3)
                                acc_temp1 = pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 2)
                                acc_temp1 = "0" + pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 1)
                                acc_temp1 = "00" + pathnamearray[3].Trim();

                            if (pathnamearray[4].Length == 3)
                                acc_temp = pathnamearray[4].Trim() + "0";
                            if (pathnamearray[4].Length == 2)
                                acc_temp = pathnamearray[4].Trim() + "00";

                            if (pathnamearray[5].Length == 8)
                                CustAccountNo = pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 7)
                                CustAccountNo = "0" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 6)
                                CustAccountNo = "00" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 5)
                                CustAccountNo = "000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 4)
                                CustAccountNo = "0000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 3)
                                CustAccountNo = "00000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 2)
                                CustAccountNo = "000000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 1)
                                CustAccountNo = "0000000" + pathnamearray[5].Trim();

                            CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;
                        }
                        else if (GLHead.Contains("SB") && Terminal.Contains("ATM"))
                        {
                            string[] pathnamearray = ReferenceNumber.Split(':');
                            ChannelID = "1";
                            ModeID = "1";
                            ReserveField1 = "O";
                            TxnsSubTypeMain = "Withdrawl";
                            ReferenceNumber = pathnamearray[4].Substring(0, 12).Trim();
                            AuthCode = ReferenceNumber.Substring(6, 6).Trim();
                            CardNumber = pathnamearray[3].ToString().Trim();
                            TerminalID = pathnamearray[1].ToString().Trim();
                            ResponseCode1 = "00";
                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);
                            }

                            if (CardNumber != "")
                            {
                                string dummy = "XXXXXXXXXX";
                                CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();

                            }

                            TxnsDateTime = dtfillsheet1.Rows[i][1].ToString();
                            TxnsPostDateTime = dtfillsheet1.Rows[i][2].ToString();
                            TxnsValueDateTime = dtfillsheet1.Rows[i][4].ToString();
                            TxnsStatus = "Sucessfull";
                            TxnsType = "Financial";
                            TxnsEntryType = "Auto";

                            if (ReferenceNumber.Contains("Rev"))
                            {
                                if (pathnamearray[3].Length == 3)
                                    acc_temp1 = pathnamearray[3].Trim();
                                if (pathnamearray[3].Length == 2)
                                    acc_temp1 = "0" + pathnamearray[3].Trim();
                                if (pathnamearray[3].Length == 1)
                                    acc_temp1 = "00" + pathnamearray[3].Trim();
                                acc_temp2 = pathnamearray[6].Trim();
                                string[] temp = acc_temp2.Split('/');
                                if (temp[0].Length == 3)
                                    acc_temp = temp[0].Trim() + "0";
                                if (temp[0].Length == 2)
                                    acc_temp = temp[0].Trim() + "00";

                                if (temp[1].Length == 8)
                                    CustAccountNo = temp[1].Trim();
                                if (temp[1].Length == 7)
                                    CustAccountNo = "0" + temp[1].Trim();
                                if (temp[1].Length == 6)
                                    CustAccountNo = "00" + temp[1].Trim();
                                if (temp[1].Length == 5)
                                    CustAccountNo = "000" + temp[1].Trim();
                                if (temp[1].Length == 4)
                                    CustAccountNo = "0000" + temp[1].Trim();
                                if (temp[1].Length == 3)
                                    CustAccountNo = "00000" + temp[1].Trim();
                                if (temp[1].Length == 2)
                                    CustAccountNo = "000000" + temp[1].Trim();
                                if (temp[1].Length == 1)
                                    CustAccountNo = "0000000" + temp[1].Trim();
                                CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;

                            }
                            else
                            {
                                if (pathnamearray[2].Length == 3)
                                    acc_temp1 = pathnamearray[2].Trim();
                                if (pathnamearray[2].Length == 2)
                                    acc_temp1 = "0" + pathnamearray[2].Trim();
                                if (pathnamearray[2].Length == 1)
                                    acc_temp1 = "00" + pathnamearray[2].Trim();
                                acc_temp2 = pathnamearray[5].Trim();
                                string[] temp = acc_temp2.Split('/');
                                if (temp[0].Length == 3)
                                    acc_temp = temp[0].Trim() + "0";
                                if (temp[0].Length == 2)
                                    acc_temp = temp[0].Trim() + "00";

                                if (temp[1].Length == 8)
                                    CustAccountNo = temp[1].Trim();
                                if (temp[1].Length == 7)
                                    CustAccountNo = "0" + temp[1].Trim();
                                if (temp[1].Length == 6)
                                    CustAccountNo = "00" + temp[1].Trim();
                                if (temp[1].Length == 5)
                                    CustAccountNo = "000" + temp[1].Trim();
                                if (temp[1].Length == 4)
                                    CustAccountNo = "0000" + temp[1].Trim();
                                if (temp[1].Length == 3)
                                    CustAccountNo = "00000" + temp[1].Trim();
                                if (temp[1].Length == 2)
                                    CustAccountNo = "000000" + temp[1].Trim();
                                if (temp[1].Length == 1)
                                    CustAccountNo = "0000000" + temp[1].Trim();
                                CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;
                            }

                        }
                        else if (GLHead.Contains("SB") && Terminal.Contains("ABB") && ReferenceNumber.Contains("ATM"))
                        {
                            ChannelID = "1";
                            ModeID = "3";
                            ReserveField1 = "I";
                            TxnsSubTypeMain = "Withdrawl";
                            ReferenceNumber = dtfillsheet1.Rows[i][7].ToString();
                            TxnsDateTime = dtfillsheet1.Rows[i][1].ToString();
                            TxnsPostDateTime = dtfillsheet1.Rows[i][2].ToString();
                            TxnsValueDateTime = dtfillsheet1.Rows[i][4].ToString();
                            TxnsStatus = "Sucessfull";
                            TxnsType = "Financial";
                            TxnsEntryType = "Auto";
                            ResponseCode1 = "00";

                            string[] pathnamearray = ReferenceNumber.Split('/');
                            if (pathnamearray[3].Length == 3)
                                acc_temp1 = pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 2)
                                acc_temp1 = "0" + pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 1)
                                acc_temp1 = "00" + pathnamearray[3].Trim();

                            if (pathnamearray[4].Length == 3)
                                acc_temp = pathnamearray[4].Trim() + "0";
                            if (pathnamearray[4].Length == 2)
                                acc_temp = pathnamearray[4].Trim() + "00";

                            if (pathnamearray[5].Length == 8)
                                CustAccountNo = pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 7)
                                CustAccountNo = "0" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 6)
                                CustAccountNo = "00" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 5)
                                CustAccountNo = "000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 4)
                                CustAccountNo = "0000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 3)
                                CustAccountNo = "00000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 2)
                                CustAccountNo = "000000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 1)
                                CustAccountNo = "0000000" + pathnamearray[5].Trim();

                            CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;
                        }
                        else if (GLHead.Contains("SB") && Terminal.Contains("ABB") && ReferenceNumber.Contains("POS"))
                        {
                            ChannelID = "2";
                            ModeID = "3";
                            ReserveField1 = "I";
                            TxnsSubTypeMain = "Purchase";
                            ReferenceNumber = dtfillsheet1.Rows[i][7].ToString();
                            TxnsDateTime = dtfillsheet1.Rows[i][1].ToString();
                            TxnsPostDateTime = dtfillsheet1.Rows[i][2].ToString();
                            TxnsValueDateTime = dtfillsheet1.Rows[i][4].ToString();
                            TxnsStatus = "Sucessfull";
                            TxnsType = "Financial";
                            TxnsEntryType = "Auto";
                            ResponseCode1 = "00";

                            string[] pathnamearray = ReferenceNumber.Split('/');
                            if (pathnamearray[3].Length == 3)
                                acc_temp1 = pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 2)
                                acc_temp1 = "0" + pathnamearray[3].Trim();
                            if (pathnamearray[3].Length == 1)
                                acc_temp1 = "00" + pathnamearray[3].Trim();

                            if (pathnamearray[4].Length == 3)
                                acc_temp = pathnamearray[4].Trim() + "0";
                            if (pathnamearray[4].Length == 2)
                                acc_temp = pathnamearray[4].Trim() + "00";

                            if (pathnamearray[5].Length == 8)
                                CustAccountNo = pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 7)
                                CustAccountNo = "0" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 6)
                                CustAccountNo = "00" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 5)
                                CustAccountNo = "000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 4)
                                CustAccountNo = "0000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 3)
                                CustAccountNo = "00000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 2)
                                CustAccountNo = "000000" + pathnamearray[5].Trim();
                            if (pathnamearray[5].Length == 1)
                                CustAccountNo = "0000000" + pathnamearray[5].Trim();

                            CustAccountNo = acc_temp1 + acc_temp + "     " + CustAccountNo;
                        }

                        TxnsAmount = dtfillsheet1.Rows[i][9].ToString();
                        DrCrType = dtfillsheet1.Rows[i][5].ToString();

                        _DataTable.Rows.Add(ClientID
                                          , ChannelID
                                          , ModeID
                                          , TerminalID
                                          , ReferenceNumber
                                          , CardNumber.Trim()
                                          , CardType
                                          , CustAccountNo
                                          , InterchangeAccountNo
                                          , ATMAccountNo
                                          , TxnsDateTime
                                          , Convert.ToDecimal(TxnsAmount)
                                          , Convert.ToDecimal(Amount1)
                                          , Convert.ToDecimal(Amount2)
                                          , Convert.ToDecimal(Amount3)
                                          , TxnsStatus
                                          , TxnsType
                                          , TxnsSubTypeMain
                                          , TxnsEntryType
                                          , TxnsNumber
                                          , TxnsPerticulars
                                          , DrCrType
                                          , ResponseCode1
                                          , 0
                                          , TxnsPostDateTime
                                          , TxnsValueDateTime
                                          , AuthCode
                                          , ProcessingCode
                                          , Convert.ToDecimal(FeeAmount)
                                          , CurrencyCode
                                          , Convert.ToDecimal(CustBalance)
                                          , Convert.ToDecimal(InterchangeBalance)
                                          , Convert.ToDecimal(ATMBalance)
                                          , BranchCode
                                          , ReserveField1
                                          , ReserveField2
                                          , ReserveField3
                                          , ReserveField4
                                          , ReserveField5
                                          , RevEntryLeg
                                          , 0
                                          , FileName
                                          , path
                                          , null
                                          , DateTime.Now
                                          , DateTime.Now
                                          , UserName
                                          , ""
                                          , ECardNumber.Trim());

                        TerminalID = string.Empty;
                        AcquirerID = string.Empty;
                        ReferenceNumber = string.Empty;
                        CardNumber = string.Empty;
                        CustAccountNo = string.Empty;
                        InterchangeAccountNo = string.Empty;
                        ATMAccountNo = string.Empty;
                        TxnsDateTime = string.Empty;
                        TxnsDate = string.Empty;
                        TxnsTime = string.Empty;
                        TxnsAmount = "0";
                        Amount1 = "0";
                        Amount2 = "0";
                        Amount3 = "0";
                        ChannelType = string.Empty;
                        TxnsSubTypeMain = string.Empty;
                        TxnsNumber = string.Empty;
                        TxnsPerticulars = string.Empty;
                        DrCrType = string.Empty;
                        ResponseCode1 = string.Empty;
                        ResponseCode2 = string.Empty;
                        ReversalCode1 = string.Empty;
                        ReversalCode2 = string.Empty;
                        TxnsPostDateTime = string.Empty;
                        TxnsValueDateTime = string.Empty;
                        AuthCode = string.Empty;
                        ProcessingCode = string.Empty;
                        FeeAmount = "0";
                        CurrencyCode = string.Empty;
                        CustBalance = "0";
                        InterchangeBalance = "0";
                        ATMBalance = "0";
                        BranchCode = string.Empty;
                        ReserveField1 = string.Empty;
                        ReserveField2 = string.Empty;
                        ReserveField3 = string.Empty;
                        ReserveField4 = string.Empty;
                        ReserveField5 = string.Empty;
                        NoOfDuplicate = string.Empty;
                        ECardNumber = string.Empty;

                        InsertCount++;
                        LineNo++;
                    }
                    catch (Exception ex)
                    {
                        InsertCount--;
                        objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');

                    }

                }


                if (_DataTable.Rows.Count == 0 || _DataTable.Rows.Count == 0)
                {
                    objCommon.InsertLogs("Transaction not found", ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');

                }


            }
            catch (Exception ex)
            {
                InsertCount--;
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');

            }
            TotalCount = InsertCount;

            return _DataTable;
        }

    }
}
