﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using ASPTrace.Contracts;
using ASPTrace.Models; 
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;

namespace ASPTraceWebApi
{



    public class LoginLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogin _objlogin;

        public LoginLoggingMiddleware(RequestDelegate next, ILogin objlogin)
        {
            _next = next;
            _objlogin = objlogin;
        }

        public async Task Invoke(HttpContext context)
        {

            if (context.User.Identity.IsAuthenticated)
            {
                var userId = context.User.Identity.Name;
                var ipAddress = context.Connection.RemoteIpAddress?.ToString();
                var userAgent = context.Request.Headers["User-Agent"].ToString();
                var loginTime = DateTime.UtcNow;

                using (var scope = context.RequestServices.CreateScope())
                {
                    var loginHistory = new UserLoginHistory
                    {
                        UserId = userId,
                        LoginTime = loginTime,
                        IpAddress = ipAddress,
                        UserAgent = userAgent
                    };

                    await _objlogin.AddUserLoginHistoryAsync(loginHistory);
                }
            }

            await _next(context);
        }


        private bool IsLoggingNeeded(HttpContext context)
        {
            // Example: Log only for specific endpoints like login
            return context.Request.Path.StartsWithSegments("/api/Login/ValidateUser");
        }

        private async Task<string> CaptureRequestBody(HttpRequest request)
        {
            request.EnableBuffering(); // Enable buffering to allow multiple reads of the body

            using (var reader = new StreamReader(request.Body, encoding: Encoding.UTF8, detectEncodingFromByteOrderMarks: false, bufferSize: 1024, leaveOpen: true))
            {
                string body = await reader.ReadToEndAsync();
                request.Body.Position = 0; // Reset the request body stream position
                return body;
            }
        }
    }

    public class ErrorLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger _logger;
        private readonly IErrorLog _IErrorLog;

        public ErrorLoggingMiddleware(RequestDelegate next, ILogger<ErrorLoggingMiddleware> logger, IErrorLog errorLog)
        {
            _next = next;
            _logger = logger;
            _IErrorLog = errorLog;
        }

        public async Task Invoke(HttpContext context)
        {
            string UserId = string.Empty;
            string ipAddress = string.Empty;
            string userAgent = string.Empty;
            string InnerException = string.Empty;
            try
            {
                ipAddress = context.Connection.RemoteIpAddress?.ToString();
                userAgent = context.Request.Headers["User-Agent"].ToString();

                if (context.User.Identity.IsAuthenticated)
                {
                    UserId = context.User.Identity.Name;
                }

                await _next(context);
            }
            catch (Exception ex)
            {
                if (ex.InnerException != null)
                {
                    InnerException = String.Concat(ex.InnerException.StackTrace, ex.InnerException.Message);
                }
                _IErrorLog.LogUnHandledError(ex.Message, ex.StackTrace, InnerException, "ErrorLoggingMiddleware", "Invoke", UserId, userAgent, ipAddress);
            }
        }
    }
}