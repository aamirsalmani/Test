﻿using MassTransit;
using Microsoft.AspNetCore.SignalR;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
namespace ASPTraceWebApi.ClassFiles
{    
    
    public class NotificationHub : Hub
    {
        public async Task SendNotification(string message)
        {
            await Clients.All.SendAsync("ReceiveNotification", message);
        }
    }


    //public class NotificationEventConsumer : IConsumer<NotificationEvent>
    //{
    //    private readonly IHubContext<NotificationHub> _hubContext;
    //    public NotificationEventConsumer(IHubContext<NotificationHub> hubContext)
    //    {
    //        _hubContext = hubContext;
    //    }

    //    public async Task Consume(ConsumeContext<NotificationEvent> context)
    //    {
    //        var notificationEvent = context.Message;

    //        // Send notification via SignalR to all clients
    //        await _hubContext.Clients.All.SendAsync("ReceiveNotification", notificationEvent);                        

    //    }
    //}

    //public class NotificationEventConsumer : IConsumer<NotificationEvent>
    //{
    //    private readonly NotificationService _notificationService;

    //    public NotificationEventConsumer(NotificationService notificationService)
    //    {
    //        _notificationService = notificationService;
    //    }

    //    public async Task Consume(ConsumeContext<NotificationEvent> context)
    //    {
    //        await _notificationService.SendNotificationAsync(context.Message.Message);
    //    }
    //}

    public class NotificationEventConsumer : INotificationDispatcher
    {
        private readonly NotificationService _notificationService;

        public NotificationEventConsumer(NotificationService notificationService)
        {
            _notificationService = notificationService;
        }

        public async Task HandleNotification(NotificationEvent notificationEvent)
        {
            //  Send notification directly via SignalR
            await _notificationService.SendNotificationAsync(notificationEvent.Message);
        }
    }


    public class NotificationService
    {
        private readonly IHubContext<NotificationHub> _hubContext;

        public NotificationService(IHubContext<NotificationHub> hubContext)
        {
            _hubContext = hubContext;
        }

        public async Task SendNotificationAsync(string message)
        {
            await _hubContext.Clients.All.SendAsync("ReceiveNotification", message);
        }
    }

    public class NotificationBackgroundService : BackgroundService
    {
        private readonly NotificationService _notificationService;

        public NotificationBackgroundService(NotificationService notificationService)
        {
            _notificationService = notificationService;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await _notificationService.SendNotificationAsync("Background notification test!");
                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken); // Every 5 minutes
            }
        }
    }

}
