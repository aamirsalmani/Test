﻿using System.Data.OleDb;
using System.Data;
using System.Text.RegularExpressions;
using System.Text;
using System;
using Utility;
using System.IO;
using System.Globalization;
using ImportData;
using System.Reflection;

namespace ASPTraceWebApi
{
    public class PayrakkamSplitter
    {
        private readonly string _MekKey1;
        private readonly string _MekKey2;
        private readonly string _connectionString;
        BulkImports bulkimports;
        public PayrakkamSplitter(string connectionString, string EMekKey1, string EMekKey2)
        {
            _connectionString = connectionString;
            _MekKey1 = EMekKey1;
            _MekKey2 = EMekKey2;
            bulkimports = new BulkImports(_connectionString, _MekKey1, _MekKey2);
        }

        //Payrakam BBPS Static spliter
        public DataTable SwitchFileMobiware_TLFSpliter(string FilePath, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string BankCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            LogWriter _log = new LogWriter();
            InsertCount = 0;
            TotalCount = 0;

            DataTable _DataTable = new DataTable();
            try
            {
                _DataTable.Columns.Add("MessageType", typeof(string));
                _DataTable.Columns.Add("orgId", typeof(string));
                _DataTable.Columns.Add("RefId", typeof(string));
                _DataTable.Columns.Add("MessageId", typeof(string));
                _DataTable.Columns.Add("TxnRefId", typeof(string));
                _DataTable.Columns.Add("ClientRequestId", typeof(string));
                _DataTable.Columns.Add("CustMobileNo", typeof(string));
                _DataTable.Columns.Add("CustomerInfo", typeof(string));
                _DataTable.Columns.Add("AgentId", typeof(string));
                _DataTable.Columns.Add("AgentChannel", typeof(string));
                _DataTable.Columns.Add("AgentInfo", typeof(string));
                _DataTable.Columns.Add("PartnerId", typeof(string));
                _DataTable.Columns.Add("PartnerName", typeof(string));
                _DataTable.Columns.Add("BillerId", typeof(string));
                _DataTable.Columns.Add("BillerName", typeof(string));
                _DataTable.Columns.Add("BillerCategory", typeof(string));
                _DataTable.Columns.Add("BillInfo", typeof(string));
                _DataTable.Columns.Add("ApprovelRefNo", typeof(string));
                _DataTable.Columns.Add("ResponseCode", typeof(string));
                _DataTable.Columns.Add("ResponseReason", typeof(string));
                _DataTable.Columns.Add("BillerResponseInfo", typeof(string));
                _DataTable.Columns.Add("AdditionalInfo", typeof(string));
                _DataTable.Columns.Add("PaymentMode", typeof(string));
                _DataTable.Columns.Add("QuickPay", typeof(string));
                _DataTable.Columns.Add("SplitPay", typeof(string));
                _DataTable.Columns.Add("Amount", typeof(decimal));
                _DataTable.Columns.Add("Currency", typeof(string));
                _DataTable.Columns.Add("CustConvFee", typeof(decimal));
                _DataTable.Columns.Add("PaymentChannel", typeof(string));
                _DataTable.Columns.Add("PaymentInfo", typeof(string));
                _DataTable.Columns.Add("TransactionType", typeof(string));
                _DataTable.Columns.Add("TxnDateTime", typeof(DateTime));
                _DataTable.Columns.Add("PayBy", typeof(string));
                _DataTable.Columns.Add("ComplianceReason", typeof(string));
                _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
                _DataTable.Columns.Add("CreatedBy", typeof(string));
                _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
                _DataTable.Columns.Add("ModifiedBy", typeof(string));
                _DataTable.Columns.Add("FileName", typeof(string));
                _DataTable.Columns.Add("FilePath", typeof(string));

                int LineNo = 0;
                InsertCount = 0;
                TotalCount = 0;
                int ErrorCount = 0;
                DataSet DT = new DataSet();
                string[] arrLines;
                string[] split;
                string sLine = string.Empty;
                string sLine1 = string.Empty;
                string sLine2 = string.Empty;
                string FORCEMATCH = string.Empty;
                string cycle = string.Empty;
                int startindex = 0;
                int endindex = 0;
                string Line2 = string.Empty;

                try
                {
                    arrLines = File.ReadAllLines(FilePath, Encoding.Default);
                    int totalrecords = arrLines.Length;
                    for (int i = 0; i < totalrecords; i++)
                    {
                        try
                        {
                            sLine = arrLines[i];
                            TotalCount = File.ReadAllLines(FilePath).Length - 1;
                            sLine2 = Regex.Replace(sLine, @"(\{""[^}]*?\})|(\[{[^]]*?}\])", m => m.Value.Replace(",", "|"));
                            sLine2 = sLine2.Replace("},{", "}{");
                            split = sLine2.Replace("\"", "").Split(',');

                            string orgId = string.Empty;
                            string RefId = string.Empty;
                            string MessageId = string.Empty;
                            string TxnRefId = string.Empty;
                            string MessageType = string.Empty;
                            string ClientRequestId = string.Empty;
                            string CustMobileNo = string.Empty;
                            string CustomerInfo = string.Empty;
                            string AgentId = string.Empty;
                            string AgentChannel = string.Empty;
                            string AgentInfo1 = string.Empty;
                            string AgentInfo2 = string.Empty;
                            string AgentInfo = string.Empty;
                            string PartnerId = string.Empty;
                            string PartnerName = string.Empty;
                            string BillerId = string.Empty;
                            string BillerName = string.Empty;
                            string BillerCategory = string.Empty;
                            string BillInfo = string.Empty;
                            string ApprovelRefNo = string.Empty;
                            string ResponseCode = string.Empty;
                            string ResponseReason = string.Empty;
                            string BillerResponseInfo = string.Empty;
                            string AdditionalInfo = string.Empty;
                            string PaymentMode = string.Empty;
                            string QuickPay = string.Empty;
                            string SplitPay = string.Empty;
                            decimal Amount = 0;
                            string Currency = string.Empty;
                            decimal CustConvFee = 0;
                            string PaymentChannel = string.Empty;
                            string PaymentInfo = string.Empty;
                            string TransactionType = string.Empty;
                            DateTime? TxnDateTime = null;
                            string PayBy = string.Empty;
                            string ComplianceReason = string.Empty;


                            MessageType = split[0].Trim();
                            orgId = split[1].Trim();
                            RefId = split[2].Trim();
                            MessageId = split[3].Trim();
                            TxnRefId = split[4].Trim();
                            ClientRequestId = split[5].Trim();
                            CustMobileNo = split[6].Trim();
                            CustomerInfo = split[7].Trim().Replace("|", ",").Trim();
                            AgentId = split[8].Trim();
                            AgentChannel = split[9].Trim();
                            AgentInfo = split[10].Trim().Replace("|", ",").Trim();
                            PartnerId = split[11].Trim();
                            PartnerName = split[12].Trim();
                            BillerId = split[13].Trim();
                            BillerName = split[14].Trim();
                            BillerCategory = split[15].Trim();
                            BillInfo = split[16].Trim().Replace("|", ",").Trim();
                            ApprovelRefNo = split[17].Trim();
                            ResponseCode = split[18].Trim();
                            ResponseReason = split[19].Trim();
                            BillerResponseInfo = split[20].Trim().Replace("|", ",").Trim();
                            AdditionalInfo = split[21].Replace("|", ",").Trim();
                            PaymentMode = split[22].Trim();
                            QuickPay = split[23].Trim();
                            SplitPay = split[24].Trim();
                            Amount = Convert.ToDecimal(split[25].Trim());
                            Currency = split[26].Trim();
                            CustConvFee = Convert.ToDecimal(split[27].Trim());
                            PaymentChannel = split[28].Trim();
                            PaymentInfo = split[29].Trim().Replace("|", ",").Trim();
                            TransactionType = split[30].Trim();
                            TxnDateTime = DateTime.ParseExact(split[31].Trim(), new[] { "yy-MM-dd HH:mm:ss", "dd/MM/yyyy", "yyyy-MM-dd HH:mm:ss" }, null, System.Globalization.DateTimeStyles.None);
                            PayBy = split[32].Trim();
                            ComplianceReason = split[33].Trim();


                            _DataTable.Rows.Add(
                                           MessageType,
                                                orgId,
                                                RefId,
                                                MessageId,
                                                TxnRefId,
                                                ClientRequestId,
                                                CustMobileNo,
                                                CustomerInfo,
                                                AgentId,
                                                AgentChannel,
                                                AgentInfo,
                                                PartnerId,
                                                PartnerName,
                                                BillerId,
                                                BillerName,
                                                BillerCategory,
                                                BillInfo,
                                                ApprovelRefNo,
                                                ResponseCode,
                                                ResponseReason,
                                                BillerResponseInfo,
                                                AdditionalInfo,
                                                PaymentMode,
                                                QuickPay,
                                                SplitPay,
                                                Amount,
                                                Currency,
                                                CustConvFee,
                                                PaymentChannel,
                                                PaymentInfo,
                                                TransactionType,
                                                TxnDateTime,
                                                PayBy,
                                                ComplianceReason,
                                                System.DateTime.Now,
                                                UserName,
                                                null,
                                                "",
                                                FileName,
                                                FilePath
                                              );

                            LineNo++;
                            InsertCount++;
                            TotalCount++;
                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                        }
                    }

                    if (_DataTable.Rows.Count == 0)
                    {
                        InsertCount = _DataTable.Rows.Count;
                    }
                }
                catch (Exception ex)
                {
                    DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }

            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, 0, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;
        }

        //Payrakam GL Cycle Wise Splitter
        public DataTable GLFilesSProcessCycleWise(string FilePath, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string BankCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            LogWriter objLogWriter = new LogWriter();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();
            try
            {
                _DataTable.Columns.Add("Channel", typeof(string));
                _DataTable.Columns.Add("AgentID", typeof(string));
                _DataTable.Columns.Add("AgentName", typeof(string));
                _DataTable.Columns.Add("TxnType", typeof(string));
                _DataTable.Columns.Add("RRN", typeof(string));
                _DataTable.Columns.Add("SourceTxnID", typeof(string));
                _DataTable.Columns.Add("MasterRefNo", typeof(string));
                _DataTable.Columns.Add("PartnerReferenceNumber", typeof(string));
                _DataTable.Columns.Add("ChannelPartnerRefNo", typeof(string));
                _DataTable.Columns.Add("UTR", typeof(string));
                _DataTable.Columns.Add("TxnDate", typeof(DateTime));
                _DataTable.Columns.Add("TxnTime", typeof(string));
                _DataTable.Columns.Add("TxnDateTime", typeof(string));
                _DataTable.Columns.Add("SettledDate", typeof(DateTime));
                _DataTable.Columns.Add("SettledTime", typeof(string));
                _DataTable.Columns.Add("RequestDate", typeof(DateTime));
                _DataTable.Columns.Add("RequestTime", typeof(string));
                _DataTable.Columns.Add("Status", typeof(string));
                _DataTable.Columns.Add("TxnFlag", typeof(string));
                _DataTable.Columns.Add("OpeningBalance", typeof(decimal));
                _DataTable.Columns.Add("TxnAmount", typeof(decimal));
                _DataTable.Columns.Add("ServiceChargesCCF", typeof(decimal));
                _DataTable.Columns.Add("BaseAmount", typeof(decimal));
                _DataTable.Columns.Add("GST", typeof(decimal));
                _DataTable.Columns.Add("GrosAmount", typeof(decimal));
                _DataTable.Columns.Add("ClosingBalance", typeof(decimal));
                _DataTable.Columns.Add("Narration", typeof(string));
                _DataTable.Columns.Add("Remarks", typeof(string));
                _DataTable.Columns.Add("TerminalId", typeof(string));
                _DataTable.Columns.Add("FranchiseID", typeof(string));
                _DataTable.Columns.Add("FranchiseName", typeof(string));
                _DataTable.Columns.Add("ClientID", typeof(string));
                _DataTable.Columns.Add("ClientName", typeof(string));
                _DataTable.Columns.Add("NPCIReferenceNumber", typeof(string));
                _DataTable.Columns.Add("ApproverRemarks", typeof(string));
                _DataTable.Columns.Add("BCAccountNumber", typeof(string));
                _DataTable.Columns.Add("IFSCCode", typeof(string));
                _DataTable.Columns.Add("AccName", typeof(string));
                _DataTable.Columns.Add("Cycle", typeof(string));
                _DataTable.Columns.Add("FileDate", typeof(DateTime));
                _DataTable.Columns.Add("CreatedOn", typeof(string));
                _DataTable.Columns.Add("CreatedBy", typeof(string));
                _DataTable.Columns.Add("ModifyOn", typeof(string));
                _DataTable.Columns.Add("ModifyBy", typeof(string));
                _DataTable.Columns.Add("FileName", typeof(string));
                _DataTable.Columns.Add("FilePath", typeof(string));

                int LineNo = 0;
                InsertCount = 0;
                TotalCount = 0;

                int ErrorCount = 0;
                DataSet DT = new DataSet();
                string[] arrLines;
                string[] split;
                int j = 0;
                string sLine = string.Empty;
                string sLine1 = string.Empty;
                string sLine2 = string.Empty;
                string FORCEMATCH = string.Empty;
                string cycle = string.Empty;
                int startindex = 0;
                int endindex = 0;
                string Line2 = string.Empty;

                try
                {

                    DataTable dtexcelsheetname = null;

                    String connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                    OleDbConnection objConn = new OleDbConnection(connString);
                    string extension = Path.GetExtension(FilePath);
                    try
                    {
                        objConn = new OleDbConnection(connString);
                        if (objConn.State == ConnectionState.Open)
                        {
                            objConn.Close();
                        }
                        objConn.Open();
                    }
                    catch (Exception ex)
                    {
                        DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                    dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    

                    foreach (DataRow row in dtexcelsheetname.Rows)
                    { 
                        string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                        OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        DataTable dtSheet = new DataTable();
                        da.Fill(dtSheet);
                        objConn.Close();
                        TotalCount = TotalCount + dtSheet.Rows.Count;
                        if (dtSheet.Rows.Count > 1)
                        {
                            for (int k = 1; k < dtSheet.Rows.Count; k++)
                            {
                                string Channel = string.Empty;
                                string AgentID = string.Empty;
                                string AgentName = string.Empty;
                                string TxnType = string.Empty;
                                string RRN = string.Empty;
                                string SourceTxnID = string.Empty;
                                string MasterRefNo = string.Empty;
                                string PartnerReferenceNumber = string.Empty;
                                string ChannelPartnerRefNo = string.Empty;
                                string UTR = string.Empty;
                                DateTime? TxnDate = null;
                                string TxnTime = string.Empty;
                                DateTime? TxnDateTime = null;
                                DateTime? SettledDate = null;
                                string SettledTime = string.Empty;
                                DateTime? RequestDate = null;
                                string RequestTime = string.Empty;
                                string IFSCCode = string.Empty;
                                string AccName = string.Empty;
                                string Cycle = string.Empty;
                                DateTime? FileDate = null;
                                string Status = string.Empty;
                                string TxnFlag = string.Empty;
                                decimal? OpeningBalance = 0;
                                decimal? TxnAmount = 0;
                                decimal? ServiceChargesCCF = 0;
                                decimal? BaseAmount = 0;
                                decimal? GST = 0;
                                decimal? GrosAmount = 0;
                                decimal? ClosingBalance = 0;
                                string Narration = string.Empty;
                                string Remarks = string.Empty;
                                string TerminalId = string.Empty;
                                string FranchiseID = string.Empty;
                                string FranchiseName = string.Empty;
                                string ClientID = string.Empty;
                                string ClientName = string.Empty;
                                string NPCIReferenceNumber = string.Empty;
                                string ApproverRemarks = string.Empty;
                                string BCAccountNumber = string.Empty;

                                try
                                {
                                    if (dtSheet.Rows[k][1].ToString().Contains("DMT"))
                                    {
                                        Channel = "IMPS";
                                    }
                                    else
                                    {
                                        Channel = string.IsNullOrEmpty(dtSheet.Rows[k][1].ToString()) || Convert.ToString(dtSheet.Rows[k][1]).Equals("NULL") ? null : dtSheet.Rows[k][1].ToString();
                                    }
                                    AgentID = string.IsNullOrEmpty(dtSheet.Rows[k][2].ToString()) || Convert.ToString(dtSheet.Rows[k][2]).Equals("NULL") ? null : dtSheet.Rows[k][2].ToString();
                                    AgentName = string.IsNullOrEmpty(dtSheet.Rows[k][3].ToString()) || Convert.ToString(dtSheet.Rows[k][3]).Equals("NULL") ? null : dtSheet.Rows[k][3].ToString();
                                    TxnType = string.IsNullOrEmpty(dtSheet.Rows[k][4].ToString()) || Convert.ToString(dtSheet.Rows[k][4]).Equals("NULL") ? null : dtSheet.Rows[k][4].ToString();
                                    RRN = string.IsNullOrEmpty(dtSheet.Rows[k][5].ToString()) || Convert.ToString(dtSheet.Rows[k][5]).Equals("NULL") ? null : dtSheet.Rows[k][5].ToString();
                                    SourceTxnID = string.IsNullOrEmpty(dtSheet.Rows[k][6].ToString()) || Convert.ToString(dtSheet.Rows[k][6]).Equals("NULL") ? null : dtSheet.Rows[k][6].ToString();
                                    MasterRefNo = string.IsNullOrEmpty(dtSheet.Rows[k][7].ToString()) || Convert.ToString(dtSheet.Rows[k][7]).Equals("NULL") ? null : dtSheet.Rows[k][7].ToString();
                                    PartnerReferenceNumber = string.IsNullOrEmpty(dtSheet.Rows[k][8].ToString()) || Convert.ToString(dtSheet.Rows[k][8]).Equals("NULL") ? null : dtSheet.Rows[k][8].ToString();
                                    ChannelPartnerRefNo = string.IsNullOrEmpty(dtSheet.Rows[k][9].ToString()) || Convert.ToString(dtSheet.Rows[k][9]).Equals("NULL") ? null : dtSheet.Rows[k][9].ToString();
                                    UTR = string.IsNullOrEmpty(dtSheet.Rows[k][10].ToString()) || Convert.ToString(dtSheet.Rows[k][10]).Equals("NULL") ? null : dtSheet.Rows[k][10].ToString();
                                    TxnDate = DateTime.ParseExact(dtSheet.Rows[k][11].ToString().Trim(), "dd/MM/yyyy", null);
                                    objLogWriter.FunErrorLog("TxnDate conversion" + TxnDate, BankCode, "PayrakkamMATMSplitterProcess.cs", "GLFilesProcessCycleWise", LineNo, "GLFilesSProcessCycleWise", UserName, 'T');
                                    TxnTime = string.IsNullOrEmpty(dtSheet.Rows[k][12].ToString()) || Convert.ToString(dtSheet.Rows[k][12]).Equals("NULL") ? null : dtSheet.Rows[k][12].ToString();
                                    objLogWriter.FunErrorLog("TxnTime" + TxnTime, BankCode, "PayrakkamMATMSplitterProcess.cs", "GLFilesProcessCycleWise", LineNo, "GLFilesSProcessCycleWise", UserName, 'T');
                                    string Date = dtSheet.Rows[k][11].ToString().Trim();
                                    objLogWriter.FunErrorLog("Date " + Date, BankCode, "PayrakkamMATMSplitterProcess.cs", "GLFilesProcessCycleWise", LineNo, "GLFilesSProcessCycleWise", UserName, 'T');
                                    string TxnDatetimes = Date + " " + TxnTime;
                                    TxnDateTime = DateTime.ParseExact(TxnDatetimes, "dd/MM/yyyy HH:mm:ss", null);
                                    objLogWriter.FunErrorLog("TxnDateTime conversion" + TxnDateTime, BankCode, "PayrakkamMATMSplitterProcess.cs", "GLFilesProcessCycleWise", LineNo, "GLFilesSProcessCycleWise", UserName, 'T');

                                    if (dtSheet.Rows[k][13].ToString().Replace("'", "").Trim() != "")
                                    {
                                        SettledDate = DateTime.ParseExact(dtSheet.Rows[k][13].ToString().Trim(), "dd/MM/yyyy", null);
                                        objLogWriter.FunErrorLog("SettledDate conversion" + SettledDate, BankCode, "PayrakkamMATMSplitterProcess.cs", "GLFilesProcessCycleWise", LineNo, "GLFilesSProcessCycleWise", UserName, 'T');
                                    }
                                    else
                                    {
                                        SettledDate = null;
                                        objLogWriter.FunErrorLog("SettledDate" + SettledDate, BankCode, "PayrakkamMATMSplitterProcess.cs", "GLFilesProcessCycleWise", LineNo, "GLFilesSProcessCycleWise", UserName, 'T');
                                    }
                                    SettledTime = string.IsNullOrEmpty(dtSheet.Rows[k][14].ToString()) || Convert.ToString(dtSheet.Rows[k][14]).Equals("NULL") ? null : dtSheet.Rows[k][14].ToString();


                                    if (dtSheet.Rows[k][15].ToString().Replace("NULL", "").Trim() != "")
                                    {
                                        SettledDate = DateTime.ParseExact(dtSheet.Rows[k][15].ToString().Trim(), "dd/MM/yyyy", null);
                                        objLogWriter.FunErrorLog("RequestDate Conversion" + RequestDate, BankCode, "PayrakkamMATMSplitterProcess.cs", "GLFilesProcessCycleWise", LineNo, "GLFilesSProcessCycleWise", UserName, 'T');
                                    }
                                    else
                                    {
                                        RequestDate = null;
                                        objLogWriter.FunErrorLog("RequestDate" + RequestDate, BankCode, "PayrakkamMATMSplitterProcess.cs", "GLFilesProcessCycleWise", LineNo, "GLFilesSProcessCycleWise", UserName, 'T');
                                    }
                                    RequestTime = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][16])) || Convert.ToString(dtSheet.Rows[k][16]).Equals("NULL") ? null : Convert.ToString(dtSheet.Rows[k][16].ToString());
                                    objLogWriter.FunErrorLog("RequestTime" + RequestTime, BankCode, "PayrakkamMATMSplitterProcess.cs", "GLFilesProcessCycleWise", LineNo, "GLFilesSProcessCycleWise", UserName, 'T');
                                    Status = dtSheet.Rows[k][17].ToString().Trim();
                                    TxnFlag = dtSheet.Rows[k][18].ToString().Trim();
                                    OpeningBalance = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][19])) || Convert.ToString(dtSheet.Rows[k][19]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][19]));
                                    TxnAmount = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][20])) || Convert.ToString(dtSheet.Rows[k][20]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][20]));
                                    ServiceChargesCCF = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][21])) || Convert.ToString(dtSheet.Rows[k][21]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][21]));
                                    BaseAmount = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][22])) || Convert.ToString(dtSheet.Rows[k][22]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][22]));
                                    GST = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][23])) || Convert.ToString(dtSheet.Rows[k][23]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][23]));
                                    GrosAmount = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][24])) || Convert.ToString(dtSheet.Rows[k][24]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][24]));
                                    ClosingBalance = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][25])) || Convert.ToString(dtSheet.Rows[k][25]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][25]));
                                    Narration = dtSheet.Rows[k][26].ToString().Trim();
                                    Remarks = dtSheet.Rows[k][27].ToString().Trim();
                                    TerminalId = dtSheet.Rows[k][28].ToString().Trim();
                                    FranchiseID = dtSheet.Rows[k][29].ToString().Trim();
                                    FranchiseName = dtSheet.Rows[k][30].ToString().Trim();
                                    ClientID = dtSheet.Rows[k][31].ToString().Trim();
                                    ClientName = dtSheet.Rows[k][32].ToString().Trim();
                                    NPCIReferenceNumber = dtSheet.Rows[k][33].ToString().Trim();
                                    ApproverRemarks = dtSheet.Rows[k][34].ToString().Trim();
                                    BCAccountNumber = dtSheet.Rows[k][35].ToString().Trim();
                                    IFSCCode = dtSheet.Rows[k][36].ToString().Trim();
                                    AccName = dtSheet.Rows[k][37].ToString().Trim();
                                    Cycle = dtSheet.Rows[k][38].ToString().Trim();
                                    FileDate = DateTime.ParseExact(dtSheet.Rows[k][39].ToString().Trim(), "dd-MM-yyyy HH:mm:ss", null);
                                }

                                catch (Exception ex)
                                {
                                    objLogWriter.FunErrorLog(ex.Message.ToString(), BankCode, "ASP_Switch_Spliter.cs", "GLFilesProcessCycleWise", LineNo, "GLFilesSProcessCycleWise", UserName, 'E');
                                }

                                LineNo++;

                                _DataTable.Rows.Add(
                                                       Channel,
                                                       AgentID,
                                                       AgentName,
                                                       TxnType,
                                                       RRN,
                                                       SourceTxnID,
                                                       MasterRefNo,
                                                       PartnerReferenceNumber,
                                                       ChannelPartnerRefNo,
                                                       UTR,
                                                       TxnDate,
                                                       TxnTime,
                                                       TxnDateTime,
                                                       SettledDate,
                                                       SettledTime,
                                                       RequestDate,
                                                       RequestTime,
                                                       Status,
                                                       TxnFlag,
                                                       OpeningBalance,
                                                       TxnAmount,
                                                       ServiceChargesCCF,
                                                       BaseAmount,
                                                       GST,
                                                       GrosAmount,
                                                       ClosingBalance,
                                                       Narration,
                                                       Remarks,
                                                       TerminalId,
                                                       FranchiseID,
                                                       FranchiseName,
                                                       ClientID,
                                                       ClientName,
                                                       NPCIReferenceNumber,
                                                       ApproverRemarks,
                                                       BCAccountNumber,
                                                       IFSCCode,
                                                       AccName,
                                                       Cycle,
                                                       FileDate,
                                                       System.DateTime.Now,
                                                       UserName,
                                                       null,
                                                       "",
                                                       FileName,
                                                       FilePath
                                                   );

                                InsertCount++;

                            }
                        }
                        j++;
                    }
                    if (_DataTable.Rows.Count > 0)
                    {
                        InsertCount = _DataTable.Rows.Count;
                    }
                }
                catch (Exception ex)
                {
                    DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }


            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, 0, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;
        }

        public DataTable PayrakkamFranchiseLedger(string FilePath, string FileName, string UserName, string BankCode, out int InsertCount, out int TotalCount)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            string ConnectionString = string.Empty;
            string ErrorMessage = string.Empty;
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            try
            {
                _DataTable.Columns.Add("ClientID", typeof(string));
                _DataTable.Columns.Add("ClientName", typeof(string));
                _DataTable.Columns.Add("TerminalId", typeof(string));
                _DataTable.Columns.Add("Channel", typeof(string));
                _DataTable.Columns.Add("TxnID", typeof(string));
                _DataTable.Columns.Add("SourceTxnID", typeof(string));
                _DataTable.Columns.Add("UTR", typeof(string));
                _DataTable.Columns.Add("TxnType", typeof(string));
                _DataTable.Columns.Add("TxnDate", typeof(DateTime));
                _DataTable.Columns.Add("SettledDate", typeof(DateTime));
                _DataTable.Columns.Add("RequestDate", typeof(DateTime));
                _DataTable.Columns.Add("OpeningBalance", typeof(Decimal));
                _DataTable.Columns.Add("TxnAmount", typeof(Decimal));
                _DataTable.Columns.Add("ServiceCharges", typeof(Decimal));
                _DataTable.Columns.Add("BaseAmount", typeof(Decimal));
                _DataTable.Columns.Add("GST", typeof(Decimal));
                _DataTable.Columns.Add("GrosAmount", typeof(Decimal));
                _DataTable.Columns.Add("ClosingBalance", typeof(Decimal));
                _DataTable.Columns.Add("TxnStatus", typeof(string));
                _DataTable.Columns.Add("TxnFlag", typeof(string));
                _DataTable.Columns.Add("TxnDescription", typeof(string));
                _DataTable.Columns.Add("Remarks", typeof(string));
                _DataTable.Columns.Add("ZOMName", typeof(string));
                _DataTable.Columns.Add("FranchiseID", typeof(string));
                _DataTable.Columns.Add("FranchiseName", typeof(string));
                _DataTable.Columns.Add("FranchiseCompanyName", typeof(string));
                _DataTable.Columns.Add("AccountNumber", typeof(string));
                _DataTable.Columns.Add("IFSCCode", typeof(string));
                _DataTable.Columns.Add("AgentId", typeof(string));
                _DataTable.Columns.Add("AgentName", typeof(string));
                _DataTable.Columns.Add("PartnerReferenceNumber", typeof(string));
                _DataTable.Columns.Add("ApproverRemarks", typeof(string));
                _DataTable.Columns.Add("Reservefield1", typeof(string));
                _DataTable.Columns.Add("Reservefield2", typeof(string));
                _DataTable.Columns.Add("FileName", typeof(string));
                _DataTable.Columns.Add("FileDate", typeof(DateTime));
                _DataTable.Columns.Add("FilePath", typeof(string));
                _DataTable.Columns.Add("Createdby", typeof(string));
                _DataTable.Columns.Add("Createdon", typeof(DateTime));
                _DataTable.Columns.Add("Modifiedby", typeof(string));
                _DataTable.Columns.Add("Modifiedon", typeof(DateTime));
                _DataTable.Columns.Add("Cycle", typeof(string));

                InsertCount = 0;
                TotalCount = 0;
                DataSet ds = new DataSet();
                InsertCount = 0;
                TotalCount = 0;


                string[] TotalCountArray = File.ReadAllLines(FilePath);
                TotalCount = TotalCountArray.Length;

                DataTable dtexcelsheetname = null;
                try
                {
                    String connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                    OleDbConnection objConn = new OleDbConnection(connString);
                    string extension = Path.GetExtension(FilePath);


                    try
                    {
                        objConn = new OleDbConnection(connString);
                        if (objConn.State == ConnectionState.Open)
                        {
                            objConn.Close();
                        }

                        objConn.Open();
                    }

                    catch (Exception ex)
                    {
                        ErrorMessage = ex.Message;
                        DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                    dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    
                    int j = 0;

                    foreach (DataRow row in dtexcelsheetname.Rows)
                    { 
                        string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                        //string sht = dr[2].ToString().Replace("'", "");

                        OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        DataTable dtSheet = new DataTable();
                        da.Fill(dtSheet);
                        objConn.Close();

                        if (dtSheet.Rows.Count > 1 && dtSheet.Rows[0][0] != "Franchise Ledger Report")
                        {
                            for (int k = 1; k < dtSheet.Rows.Count; k++)
                            {
                                try
                                {

                                    string ClientID = string.Empty; string ClientName = string.Empty; string TerminalId = string.Empty; string Channel = string.Empty;
                                    string TxnID = string.Empty; string SourceTxnID = string.Empty; string UTR = string.Empty; string TxnType = string.Empty;
                                    DateTime? TxnDate = null; DateTime? SettledDate = null; DateTime? RequestDate = null; Decimal OpeningBalance = 0; Decimal TxnAmount = 0;
                                    Decimal ServiceCharges = 0; Decimal BaseAmount = 0; Decimal GST = 0; Decimal GrosAmount = 0; Decimal ClosingBalance = 0;
                                    string TxnStatus = string.Empty; string TxnFlag = string.Empty; string TxnDescription = string.Empty; string Remarks = string.Empty; string ZOMName = string.Empty; string FranchiseID = string.Empty;
                                    string FranchiseName = string.Empty; string FranchiseCompanyName = string.Empty; string AccountNumber = string.Empty; string IFSCCode = string.Empty; string AgentId = string.Empty; string AgentName = string.Empty;
                                    string PartnerReferenceNumber = string.Empty; string ApproverRemarks = string.Empty; string Reservefield1 = string.Empty; string Reservefield2 = string.Empty; DateTime? FileDate = null;
                                    string Createdby = string.Empty; DateTime? Createdon = null; string Modifiedby = string.Empty; DateTime? Modifiedon = null; string FileDate1 = string.Empty;
                                    string Cycle = string.Empty;

                                    ClientID = dtSheet.Rows[k][29].ToString();
                                    ClientName = dtSheet.Rows[k][30].ToString();
                                    TerminalId = dtSheet.Rows[k][20].ToString();
                                    Channel = dtSheet.Rows[k][1].ToString();
                                    TxnID = dtSheet.Rows[k][2].ToString().Trim();
                                    SourceTxnID = dtSheet.Rows[k][3].ToString().Trim();
                                    UTR = dtSheet.Rows[k][4].ToString().Trim();
                                    TxnType = dtSheet.Rows[k][5].ToString().Trim();

                                    //TxnDate = dtSheet.Rows[k][6].ToString() != "" ? DateTime.ParseExact(dtSheet.Rows[k][6].ToString().Trim(), new[] { "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss" }, CultureInfo.InvariantCulture, DateTimeStyles.None) : TxnDate;
                                    //SettledDate = dtSheet.Rows[k][7].ToString().Trim() != "" ? DateTime.ParseExact(dtSheet.Rows[k][7].ToString().Trim(), new[] { "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss" }, CultureInfo.InvariantCulture, DateTimeStyles.None) : SettledDate;
                                    //RequestDate = dtSheet.Rows[k][8].ToString().Trim() != "" ? DateTime.ParseExact(dtSheet.Rows[k][8].ToString().Trim(), new[] { "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss" }, CultureInfo.InvariantCulture, DateTimeStyles.None) : RequestDate;

                                    TxnDate = dtSheet.Rows[k][6].ToString().Trim() != "" ? DateTime.ParseExact(dtSheet.Rows[k][6].ToString().Trim(), "dd/MM/yyyy HH:mm:ss", null) : TxnDate;
                                    SettledDate = dtSheet.Rows[k][7].ToString().Trim() != "" ? DateTime.ParseExact(dtSheet.Rows[k][7].ToString().Trim(), "dd/MM/yyyy HH:mm:ss", null) : SettledDate;
                                    RequestDate = dtSheet.Rows[k][8].ToString().Trim() != "" ? DateTime.ParseExact(dtSheet.Rows[k][8].ToString().Trim(), "dd/MM/yyyy HH:mm:ss", null) : RequestDate;

                                    OpeningBalance = dtSheet.Rows[k][9].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][9].ToString().Trim()) : 0;
                                    TxnAmount = dtSheet.Rows[k][10].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][10].ToString().Trim()) : 0;
                                    ServiceCharges = dtSheet.Rows[k][11].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][11].ToString().Trim()) : 0;
                                    BaseAmount = dtSheet.Rows[k][12].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][12].ToString().Trim()) : 0;
                                    GST = dtSheet.Rows[k][13].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][13].ToString().Trim()) : 0;
                                    GrosAmount = dtSheet.Rows[k][14].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][14].ToString().Trim()) : 0;
                                    ClosingBalance = dtSheet.Rows[k][15].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][15].ToString().Trim()) : 0;
                                    TxnStatus = dtSheet.Rows[k][16].ToString().Trim();
                                    TxnFlag = dtSheet.Rows[k][17].ToString().Trim();
                                    TxnDescription = dtSheet.Rows[k][18].ToString().Trim();
                                    Remarks = dtSheet.Rows[k][19].ToString().Trim();
                                    ZOMName = dtSheet.Rows[k][21].ToString().Trim();
                                    FranchiseID = dtSheet.Rows[k][22].ToString().Trim();
                                    FranchiseName = dtSheet.Rows[k][23].ToString().Trim();
                                    FranchiseCompanyName = dtSheet.Rows[k][24].ToString().Trim();
                                    AccountNumber = dtSheet.Rows[k][25].ToString().Trim();
                                    IFSCCode = dtSheet.Rows[k][26].ToString().Trim();
                                    AgentId = dtSheet.Rows[k][27].ToString().Trim();
                                    AgentName = dtSheet.Rows[k][28].ToString().Trim();
                                    PartnerReferenceNumber = dtSheet.Rows[k][31].ToString().Trim();
                                    ApproverRemarks = dtSheet.Rows[k][32].ToString().Trim();

                                    FileDate1 = FileName.Substring(24, 10).Trim();
                                    FileDate = DateTime.ParseExact(FileDate1.Trim(), new[] { "dd/MM/yyyy", "dd-MM-yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None);


                                    _DataTable.Rows.Add(
                                                           ClientID
                                                           , ClientName
                                                           , TerminalId
                                                           , Channel
                                                           , TxnID
                                                           , SourceTxnID
                                                           , UTR
                                                           , TxnType
                                                           , TxnDate
                                                           , SettledDate
                                                           , RequestDate
                                                           , OpeningBalance
                                                           , TxnAmount
                                                           , ServiceCharges
                                                           , BaseAmount
                                                           , GST
                                                           , GrosAmount
                                                           , ClosingBalance
                                                           , TxnStatus
                                                           , TxnFlag
                                                           , TxnDescription
                                                           , Remarks
                                                           , ZOMName
                                                           , FranchiseID
                                                           , FranchiseName
                                                           , FranchiseCompanyName
                                                           , AccountNumber
                                                           , IFSCCode
                                                           , AgentId
                                                           , AgentName
                                                           , PartnerReferenceNumber
                                                           , ApproverRemarks
                                                           , Reservefield1
                                                           , Reservefield2
                                                           , FileName
                                                           , FileDate
                                                           , FilePath
                                                           , UserName
                                                           , System.DateTime.Now
                                                           , ""
                                                           , null
                                                           , Cycle

                                                          );
                                    InsertCount++;
                                }
                                catch (Exception ex)
                                {
                                    ErrorMessage = ex.Message;
                                    DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                                }
                            }
                        }
                        j++;
                    }
                }
                catch (Exception ex)
                {
                    ErrorMessage = ex.Message;
                    DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;
        }

        public DataTable PayrakkamFranchiseLedgerCycleWise(string FilePath, string FileName, string UserName, string BankCode, out int InsertCount, out int TotalCount)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            string ConnectionString = string.Empty;
            string ErrorMessage = string.Empty;
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            try
            {
                _DataTable.Columns.Add("ClientID", typeof(string));
                _DataTable.Columns.Add("ClientName", typeof(string));
                _DataTable.Columns.Add("TerminalId", typeof(string));
                _DataTable.Columns.Add("Channel", typeof(string));
                _DataTable.Columns.Add("TxnID", typeof(string));
                _DataTable.Columns.Add("SourceTxnID", typeof(string));
                _DataTable.Columns.Add("UTR", typeof(string));
                _DataTable.Columns.Add("TxnType", typeof(string));
                _DataTable.Columns.Add("TxnDate", typeof(DateTime));
                _DataTable.Columns.Add("SettledDate", typeof(DateTime));
                _DataTable.Columns.Add("RequestDate", typeof(DateTime));
                _DataTable.Columns.Add("OpeningBalance", typeof(Decimal));
                _DataTable.Columns.Add("TxnAmount", typeof(Decimal));
                _DataTable.Columns.Add("ServiceCharges", typeof(Decimal));
                _DataTable.Columns.Add("BaseAmount", typeof(Decimal));
                _DataTable.Columns.Add("GST", typeof(Decimal));
                _DataTable.Columns.Add("GrosAmount", typeof(Decimal));
                _DataTable.Columns.Add("ClosingBalance", typeof(Decimal));
                _DataTable.Columns.Add("TxnStatus", typeof(string));
                _DataTable.Columns.Add("TxnFlag", typeof(string));
                _DataTable.Columns.Add("TxnDescription", typeof(string));
                _DataTable.Columns.Add("Remarks", typeof(string));
                _DataTable.Columns.Add("ZOMName", typeof(string));
                _DataTable.Columns.Add("FranchiseID", typeof(string));
                _DataTable.Columns.Add("FranchiseName", typeof(string));
                _DataTable.Columns.Add("FranchiseCompanyName", typeof(string));
                _DataTable.Columns.Add("AccountNumber", typeof(string));
                _DataTable.Columns.Add("IFSCCode", typeof(string));
                _DataTable.Columns.Add("AgentId", typeof(string));
                _DataTable.Columns.Add("AgentName", typeof(string));
                _DataTable.Columns.Add("PartnerReferenceNumber", typeof(string));
                _DataTable.Columns.Add("ApproverRemarks", typeof(string));
                _DataTable.Columns.Add("Reservefield1", typeof(string));
                _DataTable.Columns.Add("Reservefield2", typeof(string));
                _DataTable.Columns.Add("FileName", typeof(string));
                _DataTable.Columns.Add("FileDate", typeof(DateTime));
                _DataTable.Columns.Add("FilePath", typeof(string));
                _DataTable.Columns.Add("Createdby", typeof(string));
                _DataTable.Columns.Add("Createdon", typeof(DateTime));
                _DataTable.Columns.Add("Modifiedby", typeof(string));
                _DataTable.Columns.Add("Modifiedon", typeof(DateTime));
                _DataTable.Columns.Add("Cycle", typeof(string));

                InsertCount = 0;
                TotalCount = 0;
                DataSet ds = new DataSet();

                InsertCount = 0;
                TotalCount = 0;

                string[] TotalCountArray = File.ReadAllLines(FilePath);
                TotalCount = TotalCountArray.Length;

                DataTable dtexcelsheetname = null;
                try
                {
                    String connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                    OleDbConnection objConn = new OleDbConnection(connString);
                    string extension = Path.GetExtension(FilePath);


                    try
                    {
                        objConn = new OleDbConnection(connString);
                        if (objConn.State == ConnectionState.Open)
                        {
                            objConn.Close();
                        }

                        objConn.Open();
                    }

                    catch (Exception ex)
                    {
                        ErrorMessage = ex.Message;
                        DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }


                    dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    
                    int j = 0;

                    foreach (DataRow row in dtexcelsheetname.Rows)
                    { 
                        string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                        //string sht = dr[2].ToString().Replace("'", "");

                        OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        DataTable dtSheet = new DataTable();
                        da.Fill(dtSheet);
                        objConn.Close();

                        if (dtSheet.Rows.Count > 1 && dtSheet.Rows[0][0] != "Franchise Ledger Report")
                        {
                            for (int k = 1; k < dtSheet.Rows.Count; k++)
                            {
                                try
                                {

                                    string ClientID = string.Empty; string ClientName = string.Empty; string TerminalId = string.Empty; string Channel = string.Empty;
                                    string TxnID = string.Empty; string SourceTxnID = string.Empty; string UTR = string.Empty; string TxnType = string.Empty;
                                    DateTime? TxnDate = null; DateTime? SettledDate = null; DateTime? RequestDate = null; Decimal OpeningBalance = 0; Decimal TxnAmount = 0;
                                    Decimal ServiceCharges = 0; Decimal BaseAmount = 0; Decimal GST = 0; Decimal GrosAmount = 0; Decimal ClosingBalance = 0;
                                    string TxnStatus = string.Empty; string TxnFlag = string.Empty; string TxnDescription = string.Empty; string Remarks = string.Empty; string ZOMName = string.Empty; string FranchiseID = string.Empty;
                                    string FranchiseName = string.Empty; string FranchiseCompanyName = string.Empty; string AccountNumber = string.Empty; string IFSCCode = string.Empty; string AgentId = string.Empty; string AgentName = string.Empty;
                                    string PartnerReferenceNumber = string.Empty; string ApproverRemarks = string.Empty; string Reservefield1 = string.Empty; string Reservefield2 = string.Empty; DateTime? FileDate = null;
                                    string Createdby = string.Empty; DateTime? Createdon = null; string Modifiedby = string.Empty; DateTime? Modifiedon = null; string FileDate1 = string.Empty; string Cycle = string.Empty;


                                    ClientID = dtSheet.Rows[k][29].ToString();
                                    ClientName = dtSheet.Rows[k][30].ToString();
                                    TerminalId = dtSheet.Rows[k][20].ToString();
                                    Channel = dtSheet.Rows[k][1].ToString();
                                    TxnID = dtSheet.Rows[k][2].ToString().Trim();
                                    SourceTxnID = dtSheet.Rows[k][3].ToString().Trim();
                                    UTR = dtSheet.Rows[k][4].ToString().Trim();
                                    TxnType = dtSheet.Rows[k][5].ToString().Trim();

                                    //TxnDate = dtSheet.Rows[k][6].ToString() != "" ? DateTime.ParseExact(dtSheet.Rows[k][6].ToString().Trim(), new[] { "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss" }, CultureInfo.InvariantCulture, DateTimeStyles.None) : TxnDate;
                                    //SettledDate = dtSheet.Rows[k][7].ToString().Trim() != "" ? DateTime.ParseExact(dtSheet.Rows[k][7].ToString().Trim(), new[] { "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss" }, CultureInfo.InvariantCulture, DateTimeStyles.None) : SettledDate;
                                    //RequestDate = dtSheet.Rows[k][8].ToString().Trim() != "" ? DateTime.ParseExact(dtSheet.Rows[k][8].ToString().Trim(), new[] { "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss" }, CultureInfo.InvariantCulture, DateTimeStyles.None) : RequestDate;

                                    TxnDate = dtSheet.Rows[k][6].ToString().Trim() != "" ? DateTime.ParseExact(dtSheet.Rows[k][6].ToString().Trim(), "dd/MM/yyyy HH:mm:ss", null) : TxnDate;
                                    SettledDate = dtSheet.Rows[k][7].ToString().Trim() != "" ? DateTime.ParseExact(dtSheet.Rows[k][7].ToString().Trim(), "dd/MM/yyyy HH:mm:ss", null) : SettledDate;
                                    RequestDate = dtSheet.Rows[k][8].ToString().Trim() != "" ? DateTime.ParseExact(dtSheet.Rows[k][8].ToString().Trim(), "dd/MM/yyyy HH:mm:ss", null) : RequestDate;

                                    OpeningBalance = dtSheet.Rows[k][9].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][9].ToString().Trim()) : 0;
                                    TxnAmount = dtSheet.Rows[k][10].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][10].ToString().Trim()) : 0;
                                    ServiceCharges = dtSheet.Rows[k][11].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][11].ToString().Trim()) : 0;
                                    BaseAmount = dtSheet.Rows[k][12].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][12].ToString().Trim()) : 0;
                                    GST = dtSheet.Rows[k][13].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][13].ToString().Trim()) : 0;
                                    GrosAmount = dtSheet.Rows[k][14].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][14].ToString().Trim()) : 0;
                                    ClosingBalance = dtSheet.Rows[k][15].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][15].ToString().Trim()) : 0;
                                    TxnStatus = dtSheet.Rows[k][16].ToString().Trim();
                                    TxnFlag = dtSheet.Rows[k][17].ToString().Trim();
                                    TxnDescription = dtSheet.Rows[k][18].ToString().Trim();
                                    Remarks = dtSheet.Rows[k][19].ToString().Trim();
                                    ZOMName = dtSheet.Rows[k][21].ToString().Trim();
                                    FranchiseID = dtSheet.Rows[k][22].ToString().Trim();
                                    FranchiseName = dtSheet.Rows[k][23].ToString().Trim();
                                    FranchiseCompanyName = dtSheet.Rows[k][24].ToString().Trim();
                                    AccountNumber = dtSheet.Rows[k][25].ToString().Trim();
                                    IFSCCode = dtSheet.Rows[k][26].ToString().Trim();
                                    AgentId = dtSheet.Rows[k][27].ToString().Trim();
                                    AgentName = dtSheet.Rows[k][28].ToString().Trim();
                                    PartnerReferenceNumber = dtSheet.Rows[k][31].ToString().Trim();
                                    ApproverRemarks = dtSheet.Rows[k][32].ToString().Trim();
                                    Cycle = dtSheet.Rows[k][33].ToString().Trim();
                                    //FileDate1 = FileName.Substring(24, 10).Trim();
                                    //FileDate = DateTime.ParseExact(FileDate1.Trim(), new[] { "dd/MM/yyyy", "dd-MM-yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None);
                                    //FileDate = Convert.ToDateTime(dtSheet.Rows[k][34].ToString().Trim());
                                    FileDate = DateTime.ParseExact(dtSheet.Rows[k][34].ToString().Trim().Trim(), "dd-MM-yyyy HH:mm:ss", null);

                                    _DataTable.Rows.Add(
                                                           ClientID
                                                           , ClientName
                                                           , TerminalId
                                                           , Channel
                                                           , TxnID
                                                           , SourceTxnID
                                                           , UTR
                                                           , TxnType
                                                           , TxnDate
                                                           , SettledDate
                                                           , RequestDate
                                                           , OpeningBalance
                                                           , TxnAmount
                                                           , ServiceCharges
                                                           , BaseAmount
                                                           , GST
                                                           , GrosAmount
                                                           , ClosingBalance
                                                           , TxnStatus
                                                           , TxnFlag
                                                           , TxnDescription
                                                           , Remarks
                                                           , ZOMName
                                                           , FranchiseID
                                                           , FranchiseName
                                                           , FranchiseCompanyName
                                                           , AccountNumber
                                                           , IFSCCode
                                                           , AgentId
                                                           , AgentName
                                                           , PartnerReferenceNumber
                                                           , ApproverRemarks
                                                           , Reservefield1
                                                           , Reservefield2
                                                           , FileName
                                                           , FileDate
                                                           , FilePath
                                                           , UserName
                                                           , System.DateTime.Now
                                                           , ""
                                                           , null
                                                           , Cycle


                                                          );
                                    InsertCount++;

                                }
                                catch (Exception ex)
                                {
                                    ErrorMessage = ex.Message;
                                    DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                                }
                            }
                        }
                        j++;
                    }
                }

                catch (Exception ex)
                {
                    ErrorMessage = ex.Message;
                    DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;
        }

        public DataTable PayrakamBBPSNetwork(string FilePath, string FileName, string UserName, string BankCode, out int InsertCount, out int TotalCount)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            int LineNo = 0;
            string ErrorMessage = string.Empty;
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            try
            {
                _DataTable.Columns.Add("MSGId", typeof(string));
                _DataTable.Columns.Add("RefId", typeof(string));
                _DataTable.Columns.Add("OrigRefId", typeof(string));
                _DataTable.Columns.Add("MTI", typeof(string));
                _DataTable.Columns.Add("ReferenceId", typeof(string));
                _DataTable.Columns.Add("TxnType", typeof(string));
                _DataTable.Columns.Add("TxnsDate", typeof(DateTime));
                _DataTable.Columns.Add("CustomerOUId", typeof(string));
                _DataTable.Columns.Add("AgentId", typeof(string));
                _DataTable.Columns.Add("ResponseCode", typeof(string));
                _DataTable.Columns.Add("CurrencyCode", typeof(string));
                _DataTable.Columns.Add("TxnAmount", typeof(Decimal));
                _DataTable.Columns.Add("CustomerConvenienceFee", typeof(Decimal));
                _DataTable.Columns.Add("CustomerOUSwitchingFee", typeof(Decimal));
                _DataTable.Columns.Add("BillerFee", typeof(Decimal));
                _DataTable.Columns.Add("PenaltyFee", typeof(Decimal));
                _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
                _DataTable.Columns.Add("PaymentChannel", typeof(string));
                _DataTable.Columns.Add("PaymentMode", typeof(string));
                _DataTable.Columns.Add("CustomerOUCountMonth", typeof(int));
                _DataTable.Columns.Add("BillerId", typeof(string));
                _DataTable.Columns.Add("BillerCategory", typeof(string));
                _DataTable.Columns.Add("SplitPay", typeof(string));
                _DataTable.Columns.Add("CustomerMobileNumber", typeof(string));
                _DataTable.Columns.Add("Reversal", typeof(string));
                _DataTable.Columns.Add("Decline", typeof(string));
                _DataTable.Columns.Add("CasProcessed", typeof(string));
                _DataTable.Columns.Add("SettlementCycleId", typeof(string));
                _DataTable.Columns.Add("CustomerConvenienceFeeCGST", typeof(Decimal));
                _DataTable.Columns.Add("CustomerConvenienceFeeIGST", typeof(Decimal));
                _DataTable.Columns.Add("CustomerConvenienceFeeSUTGST", typeof(Decimal));
                _DataTable.Columns.Add("BillerFeeCGST", typeof(Decimal));
                _DataTable.Columns.Add("BillerFeeIGST", typeof(Decimal));
                _DataTable.Columns.Add("BillerFeeSUTGST", typeof(Decimal));
                _DataTable.Columns.Add("CustomerOUSwitchingFeeCGST", typeof(Decimal));
                _DataTable.Columns.Add("CustomerOUSwitchingFeeIGST", typeof(Decimal));
                _DataTable.Columns.Add("CustomerOUSwitchingFeeSUTGST", typeof(Decimal));
                _DataTable.Columns.Add("PenaltyFeeCGST", typeof(Decimal));
                _DataTable.Columns.Add("PenaltyFeeIGST", typeof(Decimal));
                _DataTable.Columns.Add("PenaltyFeeSUTGST", typeof(Decimal));
                _DataTable.Columns.Add("OffUsPay", typeof(string));
                _DataTable.Columns.Add("CouCustConvFee", typeof(Decimal));
                _DataTable.Columns.Add("Remarks", typeof(string));
                _DataTable.Columns.Add("IsSettled", typeof(int));
                _DataTable.Columns.Add("IsRemoved", typeof(int));
                _DataTable.Columns.Add("Reservefield1", typeof(string));
                _DataTable.Columns.Add("Reservefield2", typeof(string));
                _DataTable.Columns.Add("FileName", typeof(string));
                _DataTable.Columns.Add("FileDate", typeof(DateTime));
                _DataTable.Columns.Add("FilePath", typeof(string));
                _DataTable.Columns.Add("Createdby", typeof(string));
                _DataTable.Columns.Add("Createdon", typeof(DateTime));
                _DataTable.Columns.Add("Modifyby", typeof(string));
                _DataTable.Columns.Add("Modifyon", typeof(DateTime));

                InsertCount = 0;
                TotalCount = 0;
                DataSet ds = new DataSet();
                try
                {
                    string MSGId = string.Empty;
                    string RefId = string.Empty;
                    string OrigRefId = string.Empty;
                    string MTI = string.Empty;
                    string ReferenceId = string.Empty;
                    string TxnType = string.Empty;
                    DateTime? TxnsDate = null;
                    string CustomerOUId = string.Empty;
                    string AgentId = string.Empty;
                    string ResponseCode = string.Empty;
                    string CurrencyCode = string.Empty;
                    Decimal TxnAmount = 0;
                    Decimal CustomerConvenienceFee = 0;
                    Decimal CustomerOUSwitchingFee = 0;
                    Decimal BillerFee = 0;
                    Decimal PenaltyFee = 0;
                    DateTime? TxnsDateTime = null;
                    string PaymentChannel = string.Empty;
                    string PaymentMode = string.Empty;
                    int CustomerOUCountMonth = 0;
                    string BillerId = string.Empty;
                    string BillerCategory = string.Empty;
                    string SplitPay = string.Empty;
                    string CustomerMobileNumber = string.Empty;
                    string Reversal = string.Empty;
                    string Decline = string.Empty;
                    string CasProcessed = string.Empty;
                    string SettlementCycleId = string.Empty;
                    Decimal CustomerConvenienceFeeCGST = 0;
                    Decimal CustomerConvenienceFeeIGST = 0;
                    Decimal CustomerConvenienceFeeSUTGST = 0;
                    Decimal BillerFeeCGST = 0;
                    Decimal BillerFeeIGST = 0;
                    Decimal BillerFeeSUTGST = 0;
                    Decimal CustomerOUSwitchingFeeCGST = 0;
                    Decimal CustomerOUSwitchingFeeIGST = 0;
                    Decimal CustomerOUSwitchingFeeSUTGST = 0;
                    Decimal PenaltyFeeCGST = 0;
                    Decimal PenaltyFeeIGST = 0;
                    Decimal PenaltyFeeSUTGST = 0;
                    string OffUsPay = string.Empty;
                    Decimal CouCustConvFee = 0;
                    string Remarks = string.Empty;
                    int IsSettled = 0;
                    int IsRemoved = 0;
                    string Reservefield1 = string.Empty;
                    string Reservefield2 = string.Empty;
                    DateTime? FileDate = null;
                    string CreatedBy = string.Empty;
                    DateTime? CreatedOn = null;
                    string ModifiedBy = string.Empty;
                    DateTime? ModifiedOn = null;

                    int LineNum = 0;
                    string arrLines;
                    arrLines = File.ReadAllText(FilePath, Encoding.Default);


                    ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(arrLines)));

                    if (ds.Tables["transactions"].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables["transactions"].Rows.Count; i++)
                        {
                            try
                            {
                                MSGId = ds.Tables["transactions"].Rows[i]["msgId"].ToString().Trim();
                                RefId = ds.Tables["transactions"].Rows[i]["refId"].ToString().Trim();
                                OrigRefId = ds.Tables["transactions"].Rows[i]["origRefId"].ToString().Trim();
                                MTI = ds.Tables["transactions"].Rows[i]["mti"].ToString().Trim();
                                ReferenceId = ds.Tables["transactions"].Rows[i]["txnReferenceId"].ToString().Trim();
                                TxnType = ds.Tables["transactions"].Rows[i]["txnType"].ToString().Trim();
                                TxnsDate = DateTime.ParseExact(ds.Tables["transactions"].Rows[i]["txnDate"].ToString().Trim(), new[] { "yyyy-MM-dd", "yyyy/MM/dd" }, CultureInfo.InvariantCulture, DateTimeStyles.None);
                                CustomerOUId = ds.Tables["transactions"].Rows[i]["customerOUId"].ToString().Trim();
                                AgentId = ds.Tables["transactions"].Rows[i]["agentId"].ToString().Trim();
                                ResponseCode = ds.Tables["transactions"].Rows[i]["responseCode"].ToString().Trim();
                                CurrencyCode = ds.Tables["transactions"].Rows[i]["txnCurrencyCode"].ToString().Trim();

                                TxnAmount = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["txnAmount"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["txnAmount"].ToString().Trim());
                                CustomerConvenienceFee = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["customerConvenienceFee"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["customerConvenienceFee"].ToString().Trim());
                                CustomerOUSwitchingFee = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["customerOUSwitchingFee"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["customerOUSwitchingFee"].ToString().Trim());
                                BillerFee = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["billerFee"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["billerFee"].ToString().Trim());
                                PenaltyFee = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["penaltyFee"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["penaltyFee"].ToString().Trim());
                                TxnsDateTime = DateTime.ParseExact(ds.Tables["transactions"].Rows[i]["clearingTimestamp"].ToString().Trim(), "yyyy-MM-ddTHH:mm:sszzz", CultureInfo.InvariantCulture, DateTimeStyles.None);

                                PaymentChannel = ds.Tables["transactions"].Rows[i]["paymentChannel"].ToString().Trim();
                                PaymentMode = ds.Tables["transactions"].Rows[i]["paymentMode"].ToString().Trim();
                                CustomerOUCountMonth = int.Parse(ds.Tables["transactions"].Rows[i]["customerOUCountMonth"].ToString().Trim());
                                BillerId = ds.Tables["transactions"].Rows[i]["billerId"].ToString().Trim();
                                BillerCategory = ds.Tables["transactions"].Rows[i]["billerCategory"].ToString().Trim();
                                SplitPay = ds.Tables["transactions"].Rows[i]["splitPay"].ToString().Trim();
                                CustomerMobileNumber = ds.Tables["transactions"].Rows[i]["customerMobileNumber"].ToString().Trim();
                                Reversal = ds.Tables["transactions"].Rows[i]["reversal"].ToString().Trim();
                                Decline = ds.Tables["transactions"].Rows[i]["decline"].ToString().Trim();
                                CasProcessed = ds.Tables["transactions"].Rows[i]["casProcessed"].ToString().Trim();
                                SettlementCycleId = ds.Tables["transactions"].Rows[i]["settlementCycleId"].ToString().Trim();

                                CustomerConvenienceFeeCGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["CustomerConvenienceFeeCGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["CustomerConvenienceFeeCGST"].ToString().Trim());
                                CustomerConvenienceFeeIGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["customerConvenienceFeeIGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["customerConvenienceFeeIGST"].ToString().Trim());
                                CustomerConvenienceFeeSUTGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["customerConvenienceFeeSUTGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["customerConvenienceFeeSUTGST"].ToString().Trim());
                                BillerFeeCGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["billerFeeCGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["billerFeeCGST"].ToString().Trim());
                                BillerFeeIGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["billerFeeIGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["billerFeeIGST"].ToString().Trim());
                                BillerFeeSUTGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["billerFeeSUTGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["billerFeeSUTGST"].ToString().Trim());
                                CustomerOUSwitchingFeeCGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["customerOUSwitchingFeeCGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["customerOUSwitchingFeeCGST"].ToString().Trim());
                                CustomerOUSwitchingFeeIGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["customerOUSwitchingFeeIGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["customerOUSwitchingFeeIGST"].ToString().Trim());
                                CustomerOUSwitchingFeeSUTGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["customerOUSwitchingFeeSUTGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["customerOUSwitchingFeeSUTGST"].ToString().Trim());
                                PenaltyFeeCGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["penaltyFeeCGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["penaltyFeeCGST"].ToString().Trim());
                                PenaltyFeeIGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["penaltyFeeIGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["penaltyFeeIGST"].ToString().Trim());
                                PenaltyFeeSUTGST = Convert.ToDecimal(ds.Tables["transactions"].Rows[i]["penaltyFeeSUTGST"].ToString().Trim() == "" ? "0" : ds.Tables["transactions"].Rows[i]["penaltyFeeSUTGST"].ToString().Trim());

                                OffUsPay = ds.Tables["transactions"].Rows[i]["offUsPay"].ToString().Trim();
                                CouCustConvFee = Convert.ToDecimal("" == "" ? "0" : ds.Tables["transactions"].Rows[i]["couCustConvFee"].ToString().Trim());
                                Remarks = ds.Tables["transactions"].Rows[i]["remarks"].ToString().Trim();
                                IsSettled = 0;
                                IsRemoved = 0;
                                string FileDate1 = FileName.Substring(9, 8).Trim();
                                FileDate = DateTime.ParseExact(FileDate1, new[] { "yyyyMMdd" }, CultureInfo.InvariantCulture, DateTimeStyles.None);

                                _DataTable.Rows.Add(
                                                     MSGId,
                                                     RefId,
                                                     OrigRefId,
                                                     MTI,
                                                     ReferenceId,
                                                     TxnType,
                                                     TxnsDate,
                                                     CustomerOUId,
                                                     AgentId,
                                                     ResponseCode,
                                                     CurrencyCode,
                                                     TxnAmount,
                                                     CustomerConvenienceFee,
                                                     CustomerOUSwitchingFee,
                                                     BillerFee,
                                                     PenaltyFee,
                                                     TxnsDateTime,
                                                     PaymentChannel,
                                                     PaymentMode,
                                                     CustomerOUCountMonth,
                                                     BillerId,
                                                     BillerCategory,
                                                     SplitPay,
                                                     CustomerMobileNumber,
                                                     Reversal,
                                                     Decline,
                                                     CasProcessed,
                                                     SettlementCycleId,
                                                     CustomerConvenienceFeeCGST,
                                                     CustomerConvenienceFeeIGST,
                                                     CustomerConvenienceFeeSUTGST,
                                                     BillerFeeCGST,
                                                     BillerFeeIGST,
                                                     BillerFeeSUTGST,
                                                     CustomerOUSwitchingFeeCGST,
                                                     CustomerOUSwitchingFeeIGST,
                                                     CustomerOUSwitchingFeeSUTGST,
                                                     PenaltyFeeCGST,
                                                     PenaltyFeeIGST,
                                                     PenaltyFeeSUTGST,
                                                     OffUsPay,
                                                     CouCustConvFee,
                                                     Remarks,
                                                     IsSettled,
                                                     IsRemoved,
                                                     Reservefield1,
                                                     Reservefield2,
                                                     FileName,
                                                     FileDate,
                                                     FilePath,
                                                     UserName,
                                                     System.DateTime.Now,
                                                     "",
                                                     null
                                                     );

                                InsertCount++;
                                TotalCount = InsertCount;
                            }
                            catch (Exception ex)
                            {
                                ErrorMessage = ex.Message;
                                DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ErrorMessage = ex.Message;
                    DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

                }



            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message;
                DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

            }
            return _DataTable;
        }

        public DataTable AdjustmentFilesSpliter(string FilePath, string FileName, string UserName, string BankCode, out int InsertCount, out int TotalCount)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            string ConnectionString = string.Empty;
            string ErrorMessage = string.Empty;
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();
            try
            {
                if (FileName.Contains("IMPS"))
                {
                    _DataTable.Columns.Add("Txnuid", typeof(string));
                    _DataTable.Columns.Add("Uid", typeof(string));
                    _DataTable.Columns.Add("Adjdate", typeof(DateTime));
                    _DataTable.Columns.Add("Adjtype", typeof(string));
                    _DataTable.Columns.Add("Remitter", typeof(string));
                    _DataTable.Columns.Add("Beneficiery", typeof(string));
                    _DataTable.Columns.Add("Response", typeof(string));
                    _DataTable.Columns.Add("Txndate", typeof(DateTime));
                    _DataTable.Columns.Add("Txntime", typeof(string));
                    _DataTable.Columns.Add("RRN", typeof(string));
                    _DataTable.Columns.Add("Terminalid", typeof(string));
                    _DataTable.Columns.Add("BenMobileNo", typeof(string));
                    _DataTable.Columns.Add("RemMobileNo", typeof(string));
                    _DataTable.Columns.Add("Chbdate", typeof(DateTime));
                    _DataTable.Columns.Add("Chbref", typeof(string));
                    _DataTable.Columns.Add("Txnamount", typeof(string));
                    _DataTable.Columns.Add("Adjamount", typeof(string));
                    _DataTable.Columns.Add("RemFee", typeof(string));
                    _DataTable.Columns.Add("BenFee", typeof(string));
                    _DataTable.Columns.Add("BenFeeSW", typeof(string));
                    _DataTable.Columns.Add("Adjfee", typeof(string));
                    _DataTable.Columns.Add("Npcifee", typeof(string));
                    _DataTable.Columns.Add("RemfeeGST", typeof(string));
                    _DataTable.Columns.Add("BenfeeGST", typeof(string));
                    _DataTable.Columns.Add("NpciGST", typeof(string));
                    _DataTable.Columns.Add("Adjref", typeof(string));
                    _DataTable.Columns.Add("Bankadjref", typeof(string));
                    _DataTable.Columns.Add("Adjproof", typeof(string));
                    _DataTable.Columns.Add("CustComp", typeof(string));
                    _DataTable.Columns.Add("AdjRaiseTime", typeof(string));
                    _DataTable.Columns.Add("OrigChannel", typeof(string));
                    _DataTable.Columns.Add("AdjSettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("ReasonCode", typeof(string));
                    _DataTable.Columns.Add("ComplaintNumber", typeof(string));
                    _DataTable.Columns.Add("ComplaintClosedReason", typeof(string));
                    _DataTable.Columns.Add("Remark", typeof(string));
                    _DataTable.Columns.Add("Cycle", typeof(string));
                    _DataTable.Columns.Add("Filedate", typeof(DateTime));
                    _DataTable.Columns.Add("FileName", typeof(string));
                    _DataTable.Columns.Add("FilePath", typeof(string));
                    _DataTable.Columns.Add("Createdon", typeof(DateTime));
                    _DataTable.Columns.Add("Createdby", typeof(string));
                    _DataTable.Columns.Add("Modifyon", typeof(DateTime));
                    _DataTable.Columns.Add("Modifyby", typeof(string));
                    //_DataTable = IMPSAdjFileProcess(FilePath, _DataTable, UserName, BankCode, FileName, ConnectionString, out InsertCount, out TotalCount);

                    if (FileName.Contains(".xls") || FileName.Contains(".xlsx") || FileName.Contains(".XLS") || FileName.Contains(".XLSX"))
                    {
                        int LineNo = 0;
                        InsertCount = 0;
                        TotalCount = 0;
                        DataSet ds = new DataSet();
                        try
                        {
                            String connString = "";
                            DataTable dtexcelsheetname = null;
                            if (FileName.Contains(".XLSX") || FileName.Contains(".xlsx"))
                            {
                                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + "; Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                            }
                            else
                            {
                                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            }
                            OleDbConnection objConn = new OleDbConnection(connString);
                            string extension = Path.GetExtension(FilePath);


                            try
                            {
                                objConn = new OleDbConnection(connString);
                                if (objConn.State == ConnectionState.Open)
                                {
                                    objConn.Close();
                                }

                                objConn.Open();
                            }
                            catch (Exception ex)
                            {
                                ErrorMessage = ex.Message;
                                DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            }
                            dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            
                            int j = 0;

                            foreach (DataRow row in dtexcelsheetname.Rows)
                            { 
                                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                                DataTable dtSheet = new DataTable();
                                da.Fill(dtSheet);
                                objConn.Close();
                                if (dtSheet.Rows.Count > 1)
                                {
                                    DateTime? Date;

                                    Date = null;
                                    string[] Filesplit = FileName.Split('_');
                                    string DateArray = FileName.Substring(11, 6).ToString();
                                    for (int k = 1; k < dtSheet.Rows.Count; k++)
                                    {

                                        string Txnuid = string.Empty;
                                        string Uid = string.Empty;
                                        DateTime? Adjdate = null;
                                        string Adjtype = string.Empty;
                                        string Remitter = string.Empty;
                                        string Beneficiery = string.Empty;
                                        string Response = string.Empty;
                                        DateTime? Txndate = null;
                                        string Txntime = string.Empty;
                                        string RRN = string.Empty;
                                        string Terminalid = string.Empty;
                                        string BenMobileNo = string.Empty;
                                        string RemMobileNo = string.Empty;
                                        DateTime? Chbdate = null;
                                        string Chbref = string.Empty;
                                        string Txnamount = string.Empty;
                                        string Adjamount = string.Empty;
                                        string RemFeeBenFee = string.Empty;
                                        string BenFeeSW = string.Empty;
                                        string Adjfee = string.Empty;
                                        string Npcifee = string.Empty;
                                        string RemfeeGST = string.Empty;
                                        string BenfeeGST = string.Empty;
                                        string NpciGST = string.Empty;
                                        string Adjref = string.Empty;
                                        string Bankadjref = string.Empty;
                                        string Adjproof = string.Empty;
                                        string CustComp = string.Empty;
                                        string AdjRaiseTime = string.Empty;
                                        string OrigChannel = string.Empty;
                                        DateTime? AdjSettlementDate = null;
                                        string ReasonCode = string.Empty;
                                        string ComplaintNumber = string.Empty;
                                        string ComplaintClosedReason = string.Empty;
                                        string Remark = string.Empty;
                                        string Cycle = string.Empty;
                                        DateTime? Filedate = null;
                                        string RemFee = string.Empty;
                                        string BenFee = string.Empty;

                                        try
                                        {
                                            Txnuid = dtSheet.Rows[k][0].ToString().Trim().Replace("=", "").Replace("\"", "");
                                            Uid = dtSheet.Rows[k][1].ToString().Trim().Replace("=", "").Replace("\"", "");
                                            Adjdate = DateTime.ParseExact(dtSheet.Rows[k][2].ToString().Trim(), "dd-MM-yyyy", CultureInfo.InvariantCulture);
                                            Adjtype = dtSheet.Rows[k][3].ToString().Trim();
                                            Remitter = dtSheet.Rows[k][4].ToString().Trim();
                                            Beneficiery = dtSheet.Rows[k][5].ToString().Trim();
                                            Response = dtSheet.Rows[k][6].ToString().Trim().Replace("=", "").Replace("\"", "");
                                            //Txndate = dtSheet.Rows[k][7].ToString().Trim();

                                            string TxnDate1 = dtSheet.Rows[k][7].ToString().Trim().Replace("'", "");
                                            Txntime = dtSheet.Rows[k][8].ToString().Trim();

                                            string TxnDateTime = TxnDate1 + " " + Txntime;
                                            Txndate = DateTime.ParseExact(TxnDateTime.Trim(), "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);

                                            RRN = dtSheet.Rows[k][9].ToString().Trim().Replace("'", "");
                                            Terminalid = dtSheet.Rows[k][10].ToString().Trim();
                                            BenMobileNo = dtSheet.Rows[k][11].ToString().Trim().Replace("'", "");
                                            RemMobileNo = dtSheet.Rows[k][12].ToString().Trim().Replace("'", "");
                                            if (Convert.ToString(dtSheet.Rows[k][13]).Trim().Length == 10)
                                                Chbdate = DateTime.ParseExact(dtSheet.Rows[k][13].ToString().Trim(), "dd-MM-yyyy", CultureInfo.InvariantCulture);
                                            //dtSheet.Rows[k][13].ToString().Trim();
                                            Chbref = dtSheet.Rows[k][14].ToString().Trim();
                                            Txnamount = dtSheet.Rows[k][15].ToString().Trim();
                                            Adjamount = dtSheet.Rows[k][16].ToString().Trim();
                                            RemFee = dtSheet.Rows[k][17].ToString().Trim();
                                            BenFee = dtSheet.Rows[k][18].ToString().Trim();
                                            BenFeeSW = dtSheet.Rows[k][19].ToString().Trim();
                                            Adjfee = dtSheet.Rows[k][20].ToString().Trim();
                                            Npcifee = dtSheet.Rows[k][21].ToString().Trim();
                                            RemfeeGST = dtSheet.Rows[k][22].ToString().Trim();
                                            BenfeeGST = dtSheet.Rows[k][23].ToString().Trim();
                                            NpciGST = dtSheet.Rows[k][24].ToString().Trim();
                                            Adjref = dtSheet.Rows[k][25].ToString().Trim();
                                            Bankadjref = dtSheet.Rows[k][26].ToString().Trim().Replace("'", "");
                                            Adjproof = dtSheet.Rows[k][27].ToString().Trim();
                                            CustComp = dtSheet.Rows[k][28].ToString().Trim();
                                            AdjRaiseTime = dtSheet.Rows[k][29].ToString().Trim();
                                            OrigChannel = dtSheet.Rows[k][30].ToString().Trim();
                                            if (Convert.ToString(dtSheet.Rows[k][31]).Trim().Length == 10)
                                                AdjSettlementDate = DateTime.ParseExact(dtSheet.Rows[k][31].ToString().Trim(), "dd-MM-yyyy", CultureInfo.InvariantCulture);
                                            ReasonCode = dtSheet.Rows[k][32].ToString().Trim();
                                            ComplaintNumber = dtSheet.Rows[k][33].ToString().Trim();
                                            ComplaintClosedReason = dtSheet.Rows[k][34].ToString().Trim();
                                            Remark = dtSheet.Rows[k][35].ToString().Trim();
                                        }
                                        catch (Exception ex)
                                        {
                                        }
                                        LineNo++;

                                        _DataTable.Rows.Add(
                                                               Txnuid
                                                              , Uid
                                                              , Adjdate
                                                              , Adjtype
                                                              , Remitter
                                                              , Beneficiery
                                                              , Response
                                                              , Txndate
                                                              , Txntime
                                                              , RRN
                                                              , Terminalid
                                                              , BenMobileNo
                                                              , RemMobileNo
                                                              , Chbdate
                                                              , Chbref
                                                              , Txnamount
                                                              , Adjamount
                                                              , RemFee
                                                              , BenFee
                                                              , BenFeeSW
                                                              , Adjfee
                                                              , Npcifee
                                                              , RemfeeGST
                                                              , BenfeeGST
                                                              , NpciGST
                                                              , Adjref
                                                              , Bankadjref
                                                              , Adjproof
                                                              , CustComp
                                                              , AdjRaiseTime
                                                              , OrigChannel
                                                              , AdjSettlementDate
                                                              , ReasonCode
                                                              , ComplaintNumber
                                                              , ComplaintClosedReason
                                                              , Remark
                                                              , Cycle
                                                              , Filedate
                                                              , FileName
                                                              , FilePath
                                                              , System.DateTime.Now
                                                              , UserName
                                                              , System.DateTime.Now
                                                              , UserName
                                                           );

                                        InsertCount++;

                                    }
                                }
                                j++;
                            }
                            if (_DataTable.Rows.Count > 0)
                            {
                                InsertCount = _DataTable.Rows.Count;
                            }
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                    else
                    {
                        int LineNo = 0;
                        InsertCount = 0;
                        TotalCount = 0;
                        //DataSet DT = new DataSet();
                        DataTable dtSheet = new DataTable();
                        string[] arrLines;
                        string[] split;
                        //string m_RecordData = string.Empty;
                        string sLine = string.Empty;
                        //string sLine1 = string.Empty;
                        //string sLine2 = string.Empty;
                        //string FORCEMATCH = string.Empty;
                        //string cycle = string.Empty;

                        DateTime? Date;
                        string Txnuid = string.Empty;
                        string TxnType = string.Empty;
                        string Uid = string.Empty;
                        DateTime? Adjdate = null;
                        string Adjtype = string.Empty;
                        string ACQ = string.Empty;
                        string ISR = string.Empty;
                        string Response = string.Empty;
                        DateTime? TxnDate = null;
                        string TxnTime = string.Empty;
                        string RRN = string.Empty;
                        string ATMID = string.Empty;
                        string CardNo = string.Empty;
                        DateTime? ChbDate = null;
                        string ChbRef = string.Empty;
                        decimal? TxnAmount = 0;
                        decimal? AdjAmount = 0;
                        decimal? ACQFee = 0;
                        decimal? ISSFee = 0;
                        decimal? ISSFeeSW = 0;
                        decimal? NpciFee = 0;
                        decimal? AcqFeeTax = 0;
                        decimal? IssFeeTax = 0;
                        decimal? NpciTAX = 0;
                        string AdjRef = string.Empty;
                        string BankAdjRef = string.Empty;
                        string AdjProof = string.Empty;
                        string ReasonDesc = string.Empty;
                        string Pincode = string.Empty;
                        string ATMLocation = string.Empty;
                        string MultiDisputeGroup = string.Empty;
                        string FCQM = string.Empty;
                        DateTime? AdjSettlementDate = null;
                        string CustomerPenalty = string.Empty;
                        string AdjTime = string.Empty;
                        string Cycle = string.Empty;
                        DateTime? TATExpiryDate = null;
                        decimal? AcqSTLAmount = 0;
                        string AcqCC = string.Empty;
                        string PanEntryMode = string.Empty;
                        string ServiceCode = string.Empty;
                        string CardDataInputCapability = string.Empty;
                        string MCCCode = string.Empty;
                        string ComplaintNumber = string.Empty;
                        string ComplaintClosedReason = string.Empty;
                        string Remark = string.Empty;
                        try
                        {
                            arrLines = File.ReadAllLines(FilePath, Encoding.Default);
                            int totalrecords = arrLines.Length;
                            //for (int i = 0; i < totalrecords; i++)
                            for (int i = 0; i < totalrecords; i++)
                            {

                                try
                                {
                                    sLine = arrLines[i];
                                    split = sLine.Split(',');

                                    Txnuid = split[0].ToString().Trim().Replace("'", "");
                                    //TxnType = split[1].ToString().Trim();
                                    Uid = split[1].ToString().Trim().Replace("'", "");
                                    Adjdate = DateTime.ParseExact(split[2].ToString().Trim(), new[] { "dd-MM-yyyy" }, null, System.Globalization.DateTimeStyles.None);
                                    Adjtype = split[3].ToString().Trim();
                                    ACQ = split[4].ToString().Trim();
                                    ISR = split[5].ToString().Trim();
                                    Response = split[6].ToString().Trim().Replace("'", "");

                                    TxnTime = split[8].ToString().Trim().Replace("'", "");

                                    string TxnDate1 = split[7].ToString().Trim().Replace("'", "");
                                    string TxnDateTime = TxnDate1 + " " + TxnTime;
                                    TxnDate = DateTime.ParseExact(TxnDateTime.Trim(), new[] { "dd-MM-yyyy HH:mm:ss" }, null, System.Globalization.DateTimeStyles.None);

                                    RRN = split[9].ToString().Trim().Replace("'", "");
                                    ATMID = split[10].ToString().Trim();
                                    CardNo = split[11].ToString().Trim().Replace("'", "");
                                    if (split[12].ToString().Trim() == "")
                                    {
                                        ChbDate = null;
                                    }
                                    else
                                        ChbDate = DateTime.ParseExact(split[12].ToString().Trim(), new[] { "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                    ChbRef = split[13].ToString().Trim();
                                    TxnAmount = Convert.ToDecimal(split[14].ToString().Trim());
                                    AdjAmount = Convert.ToDecimal(split[15].ToString().Trim());
                                    ACQFee = Convert.ToDecimal(split[16].ToString().Trim());
                                    ISSFee = Convert.ToDecimal(split[17].ToString().Trim());
                                    ISSFeeSW = Convert.ToDecimal(split[18].ToString().Trim());
                                    NpciFee = Convert.ToDecimal(split[19].ToString().Trim());
                                    AcqFeeTax = Convert.ToDecimal(split[20].ToString().Trim());
                                    IssFeeTax = Convert.ToDecimal(split[21].ToString().Trim());
                                    NpciTAX = Convert.ToDecimal(split[22].ToString().Trim());
                                    AdjRef = split[23].ToString().Trim();
                                    BankAdjRef = split[24].ToString().Trim();
                                    AdjProof = split[25].ToString().Trim();
                                    ReasonDesc = split[26].ToString().Trim();
                                    Pincode = split[27].ToString().Trim();
                                    ATMLocation = split[28].ToString().Trim();
                                    MultiDisputeGroup = split[29].ToString().Trim();
                                    FCQM = split[30].ToString().Trim();
                                    if (split[32].ToString().Trim() == "")
                                    {
                                        AdjSettlementDate = null;
                                    }
                                    else
                                        AdjSettlementDate = DateTime.ParseExact(split[32].ToString().Trim(), new[] { "dd-MM-yyyy", "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                    CustomerPenalty = split[31].ToString().Trim();
                                    AdjTime = split[33].ToString().Trim();
                                    Cycle = split[34].ToString().Trim();
                                    if (split[35].ToString().Trim() == "")
                                    {
                                        TATExpiryDate = null;
                                    }
                                    else
                                        TATExpiryDate = DateTime.ParseExact(split[35].ToString().Trim(), new[] { "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                    if (split[36].ToString().Trim() == "")
                                    {
                                        AcqSTLAmount = 0;
                                    }
                                    else
                                        AcqSTLAmount = Convert.ToDecimal(split[36].ToString().Trim());
                                    AcqCC = "";
                                    PanEntryMode = "";
                                    ServiceCode = "";
                                    CardDataInputCapability = "";
                                    MCCCode = "";
                                    ComplaintNumber = "";
                                    ComplaintClosedReason = "";
                                    Remark = "";

                                    _DataTable.Rows.Add(
                                                         Txnuid
                                                        , TxnType
                                                        , Uid
                                                        , Adjdate
                                                        , Adjtype
                                                        , ACQ
                                                        , ISR
                                                        , Response
                                                        , TxnDate
                                                        , TxnTime
                                                        , RRN
                                                        , ATMID
                                                        , CardNo
                                                        , ChbDate
                                                        , ChbRef
                                                        , TxnAmount
                                                        , AdjAmount
                                                        , ACQFee
                                                        , ISSFee
                                                        , ISSFeeSW
                                                        , NpciFee
                                                        , AcqFeeTax
                                                        , IssFeeTax
                                                        , NpciTAX
                                                        , AdjRef
                                                        , BankAdjRef
                                                        , AdjProof
                                                        , ReasonDesc
                                                        , Pincode
                                                        , ATMLocation
                                                        , MultiDisputeGroup
                                                        , FCQM
                                                        , AdjSettlementDate
                                                        , CustomerPenalty
                                                        , AdjTime
                                                        , Cycle
                                                        , TATExpiryDate
                                                        , AcqSTLAmount
                                                        , AcqCC
                                                        , PanEntryMode
                                                        , ServiceCode
                                                        , CardDataInputCapability
                                                        , MCCCode
                                                        , ComplaintNumber
                                                        , ComplaintClosedReason
                                                        , Remark
                                                        , System.DateTime.Now
                                                        , UserName
                                                        , null
                                                        , ""
                                                        , FileName
                                                        , FilePath


                                                       );

                                    LineNo++;
                                    InsertCount++;
                                    TotalCount++;
                                }
                                catch (Exception ex)
                                {

                                }
                            }

                            if (_DataTable.Rows.Count == 0)
                            {
                                // objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessPayrakkamIMPS.CS", "IMPSAdjFileProcessCSV", LineNo, FileName, UserName, 'E');
                            }
                        }
                        catch (Exception ex)
                        {
                            // objLogWriter.FunErrorLog(ex.Message.ToString(), BankCode, "ProcessPayrakkamIMPS.CS", "IMPSAdjFileProcessCSV", 0, "SwitchFileSMobiware_TLFSpliter", UserName, 'E');
                        }

                    }
                }

                else if (FileName.Contains("EBU"))
                {
                    _DataTable.Columns.Add("txnuid", typeof(string));
                    _DataTable.Columns.Add("uid", typeof(string));
                    _DataTable.Columns.Add("AdjDate", typeof(DateTime));
                    _DataTable.Columns.Add("AdjType", typeof(string));
                    _DataTable.Columns.Add("Acquirer", typeof(string));
                    _DataTable.Columns.Add("Issuer", typeof(string));
                    _DataTable.Columns.Add("Response", typeof(string));
                    _DataTable.Columns.Add("TxnDate", typeof(DateTime));
                    _DataTable.Columns.Add("TxnTime", typeof(string));
                    _DataTable.Columns.Add("RRN", typeof(string));
                    _DataTable.Columns.Add("TerminalID", typeof(string));
                    _DataTable.Columns.Add("CardNo", typeof(string));
                    _DataTable.Columns.Add("ChbDate", typeof(DateTime));
                    _DataTable.Columns.Add("ChbRef", typeof(string));
                    _DataTable.Columns.Add("TxnAmount", typeof(decimal));
                    _DataTable.Columns.Add("AdjAmount", typeof(decimal));
                    _DataTable.Columns.Add("Acq_Fee", typeof(decimal));
                    _DataTable.Columns.Add("Iss_Fee", typeof(decimal));
                    _DataTable.Columns.Add("Acq_FeeSW", typeof(decimal));
                    _DataTable.Columns.Add("Iss_FeeSW", typeof(decimal));
                    _DataTable.Columns.Add("AdjFee", typeof(decimal));
                    _DataTable.Columns.Add("NPCIFee", typeof(decimal));
                    _DataTable.Columns.Add("AcqFeeGST", typeof(decimal));
                    _DataTable.Columns.Add("IssFeeGST", typeof(decimal));
                    _DataTable.Columns.Add("NPCIFeeGST", typeof(decimal));
                    _DataTable.Columns.Add("AdjRef", typeof(string));
                    _DataTable.Columns.Add("BankAdjRef", typeof(string));
                    _DataTable.Columns.Add("AdjProof", typeof(string));
                    _DataTable.Columns.Add("TrnCode", typeof(string));
                    _DataTable.Columns.Add("Adjraisedby", typeof(string));
                    _DataTable.Columns.Add("Adjreceivedby", typeof(string));
                    _DataTable.Columns.Add("OriginatingChannel", typeof(string));
                    _DataTable.Columns.Add("AdjustmentSettledate", typeof(DateTime));
                    _DataTable.Columns.Add("Reasoncode", typeof(string));
                    _DataTable.Columns.Add("ComplaintNumber", typeof(string));
                    _DataTable.Columns.Add("ComplaintClosedReason", typeof(string));
                    _DataTable.Columns.Add("Remarks", typeof(string));
                    _DataTable.Columns.Add("FileName", typeof(string));
                    _DataTable.Columns.Add("FilePath", typeof(string));
                    _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));
                    _DataTable.Columns.Add("ModifyOn", typeof(DateTime));
                    _DataTable.Columns.Add("ModifyBy", typeof(string));


                    int LineNo = 0;
                    InsertCount = 0;
                    TotalCount = 0;

                    DataSet ds = new DataSet();
                    try
                    {
                        OleDbConnection objConn = null;
                        DataTable dtexcelsheetname = null;
                        String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                        "Data Source=" + FilePath + ";Extended Properties=Excel 8.0;";
                        string extension = Path.GetExtension(FilePath);
                        if (FileName.Contains(".XLSX") || FileName.Contains(".xlsx"))
                        {
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + "; Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        }
                        else
                        {
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                        }
                        try
                        {
                            objConn = new OleDbConnection(connString);
                            objConn.Open();
                        }
                        catch (Exception ex)
                        {
                        }

                        dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                        int j = 0;

                        try
                        {
                            foreach (DataRow row in dtexcelsheetname.Rows)
                            {
                                excelSheets[j] = row["TABLE_NAME"].ToString();
                                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                                DataTable dtSheet1 = new DataTable();
                                da.Fill(dtSheet1);
                                objConn.Close();
                                if (dtSheet1.Rows.Count > 1)
                                {
                                    for (int k = 1; k < dtSheet1.Rows.Count; k++)
                                    {
                                        string txnuid = string.Empty;
                                        string uid = string.Empty;
                                        DateTime? AdjDate = null;
                                        string AdjType = string.Empty;
                                        string Acquirer = string.Empty;
                                        string Issuer = string.Empty;
                                        string Response = string.Empty;
                                        DateTime? TxnDate = null;
                                        string TxnTime = string.Empty;
                                        string RRN = string.Empty;
                                        string TerminalID = string.Empty;
                                        string CardNo = string.Empty;
                                        DateTime? ChbDate = null;
                                        string ChbRef = string.Empty;
                                        decimal TxnAmount = 0;
                                        decimal AdjAmount = 0;
                                        decimal Acq_Fee = 0;
                                        decimal Iss_Fee = 0;
                                        decimal Acq_FeeSW = 0;
                                        decimal Iss_FeeSW = 0;
                                        decimal AdjFee = 0;
                                        decimal NPCIFee = 0;
                                        decimal AcqFeeGST = 0;
                                        decimal IssFeeGST = 0;
                                        decimal NPCIFeeGST = 0;
                                        string AdjRef = string.Empty;
                                        string BankAdjRef = string.Empty;
                                        string AdjProof = string.Empty;
                                        string TrnCode = string.Empty;
                                        string Adjraisedby = string.Empty;
                                        string Adjreceivedby = string.Empty;
                                        string OriginatingChannel = string.Empty;
                                        DateTime? AdjustmentSettledate = null;
                                        string Reasoncode = string.Empty;
                                        string ComplaintNumber = string.Empty;
                                        string ComplaintClosedReason = string.Empty;
                                        string Remarks = string.Empty;
                                        string Filename = string.Empty;
                                        string Filepath = string.Empty;
                                        try
                                        {
                                            txnuid = dtSheet1.Rows[k][0].ToString().Replace("'", "");
                                            uid = dtSheet1.Rows[k][1].ToString().Trim().Replace("'", ""); ;
                                            //AdjDate = DateTime.ParseExact(dtSheet1.Rows[k][2].ToString().Trim().ToString().Replace("'", ""), "dd-MM-yyyy", null);//Commented by Nimmi 2023-04-12

                                            AdjDate = DateTime.ParseExact(dtSheet1.Rows[k][2].ToString().Trim().ToString().Replace("'", ""), new[] { "dd-MM-yyyy", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd hh:mm:ss", "yyyy-MM-dd hh:mm:ss", "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy HH:mm", "dd-MM-yyyy hh:mm:ss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                            AdjType = dtSheet1.Rows[k][3].ToString().Trim().Replace("'", "");
                                            Acquirer = dtSheet1.Rows[k][4].ToString().Trim().Replace("'", "");
                                            Issuer = dtSheet1.Rows[k][5].ToString().Trim().Replace("'", ""); ;
                                            Response = dtSheet1.Rows[k][6].ToString().Trim().Replace("'", "");

                                            //TxnDate = DateTime.ParseExact(dtSheet1.Rows[k][7].ToString().Trim().Replace("'", ""), "dd-MM-yyyy", null);//Commented By Nimmi 2023-04-12

                                            TxnTime = dtSheet1.Rows[k][8].ToString().Trim().Replace("'", "");
                                            string TxnDate1 = dtSheet1.Rows[k][7].ToString().Trim().Replace("'", "");
                                            string TxnDateTime = TxnDate1 + "" + TxnTime;
                                            TxnDate = DateTime.ParseExact(TxnDateTime.Trim(), new[] { "dd-MM-yyyy hh:mm:ss tt", "dd-MM-yyyy HH:mm:ss tt", "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);

                                            RRN = dtSheet1.Rows[k][9].ToString().Trim().Replace("'", "");
                                            TerminalID = dtSheet1.Rows[k][10].ToString().Trim().Replace("'", "");
                                            CardNo = dtSheet1.Rows[k][11].ToString().Trim().Replace("'", "");
                                            ChbDate = DateTime.ParseExact(dtSheet1.Rows[k][12].ToString().Trim().ToString().Replace("'", ""), new[] { "dd-MM-yyyy", "dd-MM-yyyy hh:mm:ss tt", "dd-MM-yyyy HH:mm:ss tt", "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                            ChbRef = dtSheet1.Rows[k][13].ToString().Trim();
                                            TxnAmount = Convert.ToDecimal(dtSheet1.Rows[k][14].ToString().Trim().Replace("'", ""));
                                            AdjAmount = Convert.ToDecimal(dtSheet1.Rows[k][15].ToString().Trim().Replace("'", ""));
                                            Acq_Fee = Convert.ToDecimal(dtSheet1.Rows[k][16].ToString().Trim().Replace("'", ""));
                                            Iss_Fee = Convert.ToDecimal(dtSheet1.Rows[k][17].ToString().Trim().Replace("'", ""));
                                            Acq_FeeSW = Convert.ToDecimal(dtSheet1.Rows[k][18].ToString().Trim().Replace("'", ""));
                                            Iss_FeeSW = Convert.ToDecimal(dtSheet1.Rows[k][19].ToString().Trim().Replace("'", ""));
                                            AdjFee = Convert.ToDecimal(dtSheet1.Rows[k][20].ToString().Trim().Replace("'", ""));
                                            NPCIFee = Convert.ToDecimal(dtSheet1.Rows[k][21].ToString().Trim().Replace("'", ""));
                                            AcqFeeGST = Convert.ToDecimal(dtSheet1.Rows[k][22].ToString().Trim().Replace("'", ""));
                                            IssFeeGST = Convert.ToDecimal(dtSheet1.Rows[k][23].ToString().Trim().Replace("'", ""));
                                            NPCIFeeGST = Convert.ToDecimal(dtSheet1.Rows[k][24].ToString().Trim().Replace("'", ""));
                                            AdjRef = dtSheet1.Rows[k][25].ToString().Trim().Replace("'", "");
                                            BankAdjRef = dtSheet1.Rows[k][26].ToString().Trim().Replace("'", "");
                                            AdjProof = dtSheet1.Rows[k][27].ToString().Trim().Replace("'", "");
                                            TrnCode = dtSheet1.Rows[k][28].ToString().Trim().Replace("'", "");
                                            Adjraisedby = dtSheet1.Rows[k][29].ToString().Trim().Replace("'", "");
                                            Adjreceivedby = dtSheet1.Rows[k][30].ToString().Trim().Replace("'", "");
                                            OriginatingChannel = dtSheet1.Rows[k][31].ToString().Trim().Replace("'", "");
                                            AdjustmentSettledate = DateTime.ParseExact(dtSheet1.Rows[k][32].ToString().Trim().Replace("'", ""), new[] { "dd-MM-yyyy", "dd-MM-yyyy hh:mm:ss tt", "dd-MM-yyyy HH:mm:ss tt", "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                            Reasoncode = dtSheet1.Rows[k][33].ToString().Trim().Replace("'", "");
                                            ComplaintNumber = dtSheet1.Rows[k][34].ToString().Trim().Replace("'", "");
                                            ComplaintClosedReason = dtSheet1.Rows[k][35].ToString().Trim().Replace("'", "");
                                            Remarks = dtSheet1.Rows[k][36].ToString().Trim().Replace("'", "");
                                            Filename = FileName;
                                            Filepath = FilePath;
                                        }
                                        catch (Exception ex)
                                        {
                                            //_FileImport.FileImportLog("Chargeback File", BankCode, FileName, System.DateTime.Now, UserName, LineNo, InsertCount, TotalCount, "Unsuccessful", ex.Message, ConnectionString);
                                        }
                                        LineNo++;

                                        _DataTable.Rows.Add(
                                                              txnuid
                                                             , uid
                                                             , AdjDate
                                                             , AdjType
                                                             , Acquirer
                                                             , Issuer
                                                             , Response
                                                             , TxnDate
                                                             , TxnTime
                                                             , RRN
                                                             , TerminalID
                                                             , CardNo
                                                             , ChbDate
                                                             , ChbRef
                                                             , TxnAmount
                                                             , AdjAmount
                                                             , Acq_Fee
                                                             , Iss_Fee
                                                             , Acq_FeeSW
                                                             , Iss_FeeSW
                                                             , AdjFee
                                                             , NPCIFee
                                                             , AcqFeeGST
                                                             , IssFeeGST
                                                             , NPCIFeeGST
                                                             , AdjRef
                                                             , BankAdjRef
                                                             , AdjProof
                                                             , TrnCode
                                                             , Adjraisedby
                                                             , Adjreceivedby
                                                             , OriginatingChannel
                                                             , AdjustmentSettledate
                                                             , Reasoncode
                                                             , ComplaintNumber
                                                             , ComplaintClosedReason
                                                             , Remarks
                                                             , Filename
                                                             , Filepath
                                                             , System.DateTime.Now
                                                             , UserName
                                                             , null
                                                             , ""
                                                           );

                                        InsertCount++;

                                    }
                                }
                                j++;
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorMessage = ex.Message;
                            DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                        if (_DataTable.Rows.Count > 0)
                        {
                            InsertCount = _DataTable.Rows.Count;
                        }
                    }
                    catch (Exception ex)
                    {
                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    }
                }

                else
                {


                    _DataTable.Columns.Add("Txnuid", typeof(string));
                    _DataTable.Columns.Add("TxnType", typeof(string));
                    _DataTable.Columns.Add("Uid", typeof(string));
                    _DataTable.Columns.Add("Adjdate", typeof(DateTime));
                    _DataTable.Columns.Add("Adjtype", typeof(string));
                    _DataTable.Columns.Add("ACQ", typeof(string));
                    _DataTable.Columns.Add("ISR", typeof(string));
                    _DataTable.Columns.Add("Response", typeof(string));
                    _DataTable.Columns.Add("TxnDate", typeof(DateTime));
                    _DataTable.Columns.Add("TxnTime", typeof(string));
                    _DataTable.Columns.Add("RRN", typeof(string));
                    _DataTable.Columns.Add("ATMID", typeof(string));
                    _DataTable.Columns.Add("CardNo", typeof(string));
                    _DataTable.Columns.Add("ChbDate", typeof(DateTime));
                    _DataTable.Columns.Add("ChbRef", typeof(string));
                    _DataTable.Columns.Add("TxnAmount", typeof(Decimal));
                    _DataTable.Columns.Add("AdjAmount", typeof(Decimal));
                    _DataTable.Columns.Add("ACQFee", typeof(Decimal));
                    _DataTable.Columns.Add("ISSFee", typeof(Decimal));
                    _DataTable.Columns.Add("ISSFeeSW", typeof(Decimal));
                    _DataTable.Columns.Add("NpciFee", typeof(Decimal));
                    _DataTable.Columns.Add("AcqFeeTax", typeof(Decimal));
                    _DataTable.Columns.Add("IssFeeTax", typeof(Decimal));
                    _DataTable.Columns.Add("NpciTAX", typeof(Decimal));
                    _DataTable.Columns.Add("AdjRef", typeof(string));
                    _DataTable.Columns.Add("BankAdjRef", typeof(string));
                    _DataTable.Columns.Add("AdjProof", typeof(string));
                    _DataTable.Columns.Add("ReasonDesc", typeof(string));
                    _DataTable.Columns.Add("Pincode", typeof(string));
                    _DataTable.Columns.Add("ATMLocation", typeof(string));
                    _DataTable.Columns.Add("MultiDisputeGroup", typeof(string));
                    _DataTable.Columns.Add("FCQM", typeof(string));
                    _DataTable.Columns.Add("AdjSettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("CustomerPenalty", typeof(string));
                    _DataTable.Columns.Add("AdjTime", typeof(string));
                    _DataTable.Columns.Add("Cycle", typeof(string));
                    _DataTable.Columns.Add("TATExpiryDate", typeof(DateTime));
                    _DataTable.Columns.Add("AcqSTLAmount", typeof(Decimal));
                    _DataTable.Columns.Add("AcqCC", typeof(string));
                    _DataTable.Columns.Add("PanEntryMode", typeof(string));
                    _DataTable.Columns.Add("ServiceCode", typeof(string));
                    _DataTable.Columns.Add("CardDataInputCapability", typeof(string));
                    _DataTable.Columns.Add("MCCCode", typeof(string));
                    _DataTable.Columns.Add("ComplaintNumber", typeof(string));
                    _DataTable.Columns.Add("ComplaintClosedReason", typeof(string));
                    _DataTable.Columns.Add("Remark", typeof(string));
                    _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));
                    _DataTable.Columns.Add("ModifyOn", typeof(DateTime));
                    _DataTable.Columns.Add("ModifyBy", typeof(string));
                    _DataTable.Columns.Add("FileName", typeof(string));
                    _DataTable.Columns.Add("FilePath", typeof(string));

                    //_DataTable = AdjustmentFileProcess(FilePath, _DataTable, UserName, BankCode, FileName, ConnectionString, out InsertCount, out TotalCount);

                    if (FileName.Contains(".xls") || FileName.Contains(".xlsx") || FileName.Contains(".XLS") || FileName.Contains(".XLSX"))
                    {
                        int LineNo = 0;
                        InsertCount = 0;
                        TotalCount = 0;
                        DataSet ds = new DataSet();
                        try
                        {
                            String connString = "";
                            DataTable dtexcelsheetname = null;
                            if (FileName.Contains(".XLSX") || FileName.Contains(".xlsx"))
                            {
                                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + "; Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                            }
                            else
                            {
                                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            }
                            OleDbConnection objConn = new OleDbConnection(connString);
                            string extension = Path.GetExtension(FilePath);


                            try
                            {
                                objConn = new OleDbConnection(connString);
                                if (objConn.State == ConnectionState.Open)
                                {
                                    objConn.Close();
                                }

                                objConn.Open();
                            }
                            catch (Exception ex)
                            {
                                ErrorMessage = ex.Message;
                                DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            }


                            dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                            int j = 0;

                            foreach (DataRow row in dtexcelsheetname.Rows)
                            {
                                excelSheets[j] = row["TABLE_NAME"].ToString();
                                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                                DataTable dtSheet = new DataTable();
                                da.Fill(dtSheet);
                                objConn.Close();
                                if (dtSheet.Rows.Count > 1)
                                {
                                    for (int k = 1; k < dtSheet.Rows.Count; k++)
                                    {
                                        string Txnuid = string.Empty;
                                        string TxnType = string.Empty;
                                        string Uid = string.Empty;
                                        DateTime? Adjdate = null;
                                        string Adjtype = string.Empty;
                                        string ACQ = string.Empty;
                                        string ISR = string.Empty;
                                        string Response = string.Empty;
                                        DateTime? TxnDate = null;
                                        string TxnTime = string.Empty;
                                        string RRN = string.Empty;
                                        string ATMID = string.Empty;
                                        string CardNo = string.Empty;
                                        DateTime? ChbDate = null;
                                        string ChbRef = string.Empty;
                                        decimal? TxnAmount = 0;
                                        decimal? AdjAmount = 0;
                                        decimal? ACQFee = 0;
                                        decimal? ISSFee = 0;
                                        decimal? ISSFeeSW = 0;
                                        decimal? NpciFee = 0;
                                        decimal? AcqFeeTax = 0;
                                        decimal? IssFeeTax = 0;
                                        decimal? NpciTAX = 0;
                                        string AdjRef = string.Empty;
                                        string BankAdjRef = string.Empty;
                                        string AdjProof = string.Empty;
                                        string ReasonDesc = string.Empty;
                                        string Pincode = string.Empty;
                                        string ATMLocation = string.Empty;
                                        string MultiDisputeGroup = string.Empty;
                                        string FCQM = string.Empty;
                                        DateTime? AdjSettlementDate = null;
                                        string CustomerPenalty = string.Empty;
                                        string AdjTime = string.Empty;
                                        string Cycle = string.Empty;
                                        DateTime? TATExpiryDate = null;
                                        decimal? AcqSTLAmount = 0;
                                        string AcqCC = string.Empty;
                                        string PanEntryMode = string.Empty;
                                        string ServiceCode = string.Empty;
                                        string CardDataInputCapability = string.Empty;
                                        string MCCCode = string.Empty;
                                        string ComplaintNumber = string.Empty;
                                        string ComplaintClosedReason = string.Empty;
                                        string Remark = string.Empty;
                                        TotalCount = dtSheet.Rows.Count;


                                        try
                                        {
                                            Txnuid = dtSheet.Rows[k][0].ToString().Trim().Replace("'", "");
                                            TxnType = dtSheet.Rows[k][1].ToString().Trim();
                                            Uid = dtSheet.Rows[k][2].ToString().Trim().Replace("'", "");
                                            Adjdate = DateTime.ParseExact(dtSheet.Rows[k][3].ToString().Trim(), new[] { "dd-MM-yyyy", "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                            Adjtype = dtSheet.Rows[k][4].ToString().Trim();
                                            ACQ = dtSheet.Rows[k][5].ToString().Trim();
                                            ISR = dtSheet.Rows[k][6].ToString().Trim();
                                            Response = dtSheet.Rows[k][7].ToString().Trim().Replace("'", "");

                                            TxnTime = dtSheet.Rows[k][9].ToString().Trim().Replace("'", "");

                                            string TxnDate1 = dtSheet.Rows[k][8].ToString().Trim().Replace("'", "");
                                            string TxnDateTime = TxnDate1 + " " + TxnTime;
                                            TxnDate = DateTime.ParseExact(TxnDateTime.Trim(), new[] { "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss tt", "dd-MM-yyyy HH:mm:ss tt", "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);

                                            RRN = dtSheet.Rows[k][10].ToString().Trim().Replace("'", "");
                                            ATMID = dtSheet.Rows[k][11].ToString().Trim();
                                            CardNo = dtSheet.Rows[k][12].ToString().Trim().Replace("'", "");
                                            if (dtSheet.Rows[k][13].ToString().Trim() == "--")
                                            {
                                                ChbDate = null;
                                            }
                                            else
                                                ChbDate = DateTime.ParseExact(dtSheet.Rows[k][13].ToString().Trim(), new[] { "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                            ChbRef = dtSheet.Rows[k][14].ToString().Trim();
                                            TxnAmount = Convert.ToDecimal(dtSheet.Rows[k][15].ToString().Trim());
                                            AdjAmount = Convert.ToDecimal(dtSheet.Rows[k][16].ToString().Trim());
                                            ACQFee = Convert.ToDecimal(dtSheet.Rows[k][17].ToString().Trim());
                                            ISSFee = Convert.ToDecimal(dtSheet.Rows[k][18].ToString().Trim());
                                            ISSFeeSW = Convert.ToDecimal(dtSheet.Rows[k][19].ToString().Trim());
                                            NpciFee = Convert.ToDecimal(dtSheet.Rows[k][20].ToString().Trim());
                                            AcqFeeTax = Convert.ToDecimal(dtSheet.Rows[k][21].ToString().Trim());
                                            IssFeeTax = Convert.ToDecimal(dtSheet.Rows[k][22].ToString().Trim());
                                            NpciTAX = Convert.ToDecimal(dtSheet.Rows[k][23].ToString().Trim());
                                            AdjRef = dtSheet.Rows[k][24].ToString().Trim();
                                            BankAdjRef = dtSheet.Rows[k][25].ToString().Trim();
                                            AdjProof = dtSheet.Rows[k][26].ToString().Trim();
                                            ReasonDesc = dtSheet.Rows[k][27].ToString().Trim();
                                            Pincode = dtSheet.Rows[k][28].ToString().Trim();
                                            ATMLocation = dtSheet.Rows[k][29].ToString().Trim().Replace("'", "");
                                            MultiDisputeGroup = dtSheet.Rows[k][30].ToString().Trim();
                                            FCQM = dtSheet.Rows[k][31].ToString().Trim();
                                            AdjSettlementDate = DateTime.ParseExact(dtSheet.Rows[k][32].ToString().Trim(), new[] { "dd-MM-yyyy", "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                            CustomerPenalty = dtSheet.Rows[k][33].ToString().Trim();
                                            AdjTime = dtSheet.Rows[k][34].ToString().Trim();
                                            Cycle = dtSheet.Rows[k][35].ToString().Trim();
                                            if (dtSheet.Rows[k][36].ToString().Trim() == "")
                                            {
                                                TATExpiryDate = null;
                                            }
                                            else
                                                TATExpiryDate = DateTime.ParseExact(dtSheet.Rows[k][36].ToString().Trim(), new[] { "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                            AcqSTLAmount = Convert.ToDecimal(dtSheet.Rows[k][37].ToString().Trim());
                                            AcqCC = dtSheet.Rows[k][38].ToString().Trim();
                                            PanEntryMode = dtSheet.Rows[k][39].ToString().Trim();
                                            ServiceCode = dtSheet.Rows[k][40].ToString().Trim();
                                            CardDataInputCapability = dtSheet.Rows[k][41].ToString().Trim();
                                            MCCCode = dtSheet.Rows[k][42].ToString().Trim();
                                            ComplaintNumber = dtSheet.Rows[k][43].ToString().Trim();
                                            ComplaintClosedReason = dtSheet.Rows[k][44].ToString().Trim();
                                            Remark = dtSheet.Rows[k][45].ToString().Trim();
                                        }

                                        catch (Exception ex)
                                        {

                                        }
                                        LineNo++;

                                        _DataTable.Rows.Add(
                                                               Txnuid
                                                             , TxnType
                                                             , Uid
                                                             , Adjdate
                                                             , Adjtype
                                                             , ACQ
                                                             , ISR
                                                             , Response
                                                             , TxnDate
                                                             , TxnTime
                                                             , RRN
                                                             , ATMID
                                                             , CardNo
                                                             , ChbDate
                                                             , ChbRef
                                                             , TxnAmount
                                                             , AdjAmount
                                                             , ACQFee
                                                             , ISSFee
                                                             , ISSFeeSW
                                                             , NpciFee
                                                             , AcqFeeTax
                                                             , IssFeeTax
                                                             , NpciTAX
                                                             , AdjRef
                                                             , BankAdjRef
                                                             , AdjProof
                                                             , ReasonDesc
                                                             , Pincode
                                                             , ATMLocation
                                                             , MultiDisputeGroup
                                                             , FCQM
                                                             , AdjSettlementDate
                                                             , CustomerPenalty
                                                             , AdjTime
                                                             , Cycle
                                                             , TATExpiryDate
                                                             , AcqSTLAmount
                                                             , AcqCC
                                                             , PanEntryMode
                                                             , ServiceCode
                                                             , CardDataInputCapability
                                                             , MCCCode
                                                             , ComplaintNumber
                                                             , ComplaintClosedReason
                                                             , Remark
                                                             , System.DateTime.Now
                                                             , UserName
                                                             , null
                                                             , ""
                                                             , FileName
                                                             , FilePath
                                                           );

                                        InsertCount++;

                                    }
                                }
                                j++;
                            }
                            if (_DataTable.Rows.Count > 0)
                            {
                                InsertCount = _DataTable.Rows.Count;
                            }
                        }
                        catch (Exception ex)
                        {
                            //  objLogWriter.FunErrorLog(ex.Message.ToString(), BankCode, "PayrakkamMATMSplitterProcess.cs", "AdjustmentFileProcess", LineNo, "Payrakkam_MATM", UserName, 'E');
                        }
                    }
                    else
                    {
                        int LineNo = 0;
                        InsertCount = 0;
                        TotalCount = 0;
                        //DataSet DT = new DataSet();
                        DataTable dtSheet = new DataTable();
                        string[] arrLines;
                        string[] split;
                        //string m_RecordData = string.Empty;
                        string sLine = string.Empty;
                        //string sLine1 = string.Empty;
                        //string sLine2 = string.Empty;
                        //string FORCEMATCH = string.Empty;
                        //string cycle = string.Empty;

                        DateTime? Date;
                        string Txnuid = string.Empty;
                        string TxnType = string.Empty;
                        string Uid = string.Empty;
                        DateTime? Adjdate = null;
                        string Adjtype = string.Empty;
                        string ACQ = string.Empty;
                        string ISR = string.Empty;
                        string Response = string.Empty;
                        DateTime? TxnDate = null;
                        string TxnTime = string.Empty;
                        string RRN = string.Empty;
                        string ATMID = string.Empty;
                        string CardNo = string.Empty;
                        DateTime? ChbDate = null;
                        string ChbRef = string.Empty;
                        decimal? TxnAmount = 0;
                        decimal? AdjAmount = 0;
                        decimal? ACQFee = 0;
                        decimal? ISSFee = 0;
                        decimal? ISSFeeSW = 0;
                        decimal? NpciFee = 0;
                        decimal? AcqFeeTax = 0;
                        decimal? IssFeeTax = 0;
                        decimal? NpciTAX = 0;
                        string AdjRef = string.Empty;
                        string BankAdjRef = string.Empty;
                        string AdjProof = string.Empty;
                        string ReasonDesc = string.Empty;
                        string Pincode = string.Empty;
                        string ATMLocation = string.Empty;
                        string MultiDisputeGroup = string.Empty;
                        string FCQM = string.Empty;
                        DateTime? AdjSettlementDate = null;
                        string CustomerPenalty = string.Empty;
                        string AdjTime = string.Empty;
                        string Cycle = string.Empty;
                        DateTime? TATExpiryDate = null;
                        decimal? AcqSTLAmount = 0;
                        string AcqCC = string.Empty;
                        string PanEntryMode = string.Empty;
                        string ServiceCode = string.Empty;
                        string CardDataInputCapability = string.Empty;
                        string MCCCode = string.Empty;
                        string ComplaintNumber = string.Empty;
                        string ComplaintClosedReason = string.Empty;
                        string Remark = string.Empty;
                        try
                        {
                            arrLines = File.ReadAllLines(FilePath, Encoding.Default);
                            int totalrecords = arrLines.Length;
                            //for (int i = 0; i < totalrecords; i++)
                            for (int i = 0; i < totalrecords; i++)
                            {

                                try
                                {
                                    sLine = arrLines[i];
                                    split = sLine.Split(',');

                                    Txnuid = split[0].ToString().Trim().Replace("'", "");
                                    //TxnType = split[1].ToString().Trim();
                                    Uid = split[1].ToString().Trim().Replace("'", "");
                                    Adjdate = DateTime.ParseExact(split[2].ToString().Trim(), new[] { "dd-MM-yyyy" }, null, System.Globalization.DateTimeStyles.None);
                                    Adjtype = split[3].ToString().Trim();
                                    ACQ = split[4].ToString().Trim();
                                    ISR = split[5].ToString().Trim();
                                    Response = split[6].ToString().Trim().Replace("'", "");

                                    TxnTime = split[8].ToString().Trim().Replace("'", "");

                                    string TxnDate1 = split[7].ToString().Trim().Replace("'", "");
                                    string TxnDateTime = TxnDate1 + " " + TxnTime;
                                    TxnDate = DateTime.ParseExact(TxnDateTime.Trim(), new[] { "dd-MM-yyyy HH:mm:ss" }, null, System.Globalization.DateTimeStyles.None);

                                    RRN = split[9].ToString().Trim().Replace("'", "");
                                    ATMID = split[10].ToString().Trim();
                                    CardNo = split[11].ToString().Trim().Replace("'", "");
                                    if (split[12].ToString().Trim() == "")
                                    {
                                        ChbDate = null;
                                    }
                                    else
                                        ChbDate = DateTime.ParseExact(split[12].ToString().Trim(), new[] { "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                    ChbRef = split[13].ToString().Trim();
                                    TxnAmount = Convert.ToDecimal(split[14].ToString().Trim());
                                    AdjAmount = Convert.ToDecimal(split[15].ToString().Trim());
                                    ACQFee = Convert.ToDecimal(split[16].ToString().Trim());
                                    ISSFee = Convert.ToDecimal(split[17].ToString().Trim());
                                    ISSFeeSW = Convert.ToDecimal(split[18].ToString().Trim());
                                    NpciFee = Convert.ToDecimal(split[19].ToString().Trim());
                                    AcqFeeTax = Convert.ToDecimal(split[20].ToString().Trim());
                                    IssFeeTax = Convert.ToDecimal(split[21].ToString().Trim());
                                    NpciTAX = Convert.ToDecimal(split[22].ToString().Trim());
                                    AdjRef = split[23].ToString().Trim();
                                    BankAdjRef = split[24].ToString().Trim();
                                    AdjProof = split[25].ToString().Trim();
                                    ReasonDesc = split[26].ToString().Trim();
                                    Pincode = split[27].ToString().Trim();
                                    ATMLocation = split[28].ToString().Trim();
                                    MultiDisputeGroup = split[29].ToString().Trim();
                                    FCQM = split[30].ToString().Trim();
                                    if (split[32].ToString().Trim() == "")
                                    {
                                        AdjSettlementDate = null;
                                    }
                                    else
                                        AdjSettlementDate = DateTime.ParseExact(split[32].ToString().Trim(), new[] { "dd-MM-yyyy", "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                    CustomerPenalty = split[31].ToString().Trim();
                                    AdjTime = split[33].ToString().Trim();
                                    Cycle = split[34].ToString().Trim();
                                    if (split[35].ToString().Trim() == "")
                                    {
                                        TATExpiryDate = null;
                                    }
                                    else
                                        TATExpiryDate = DateTime.ParseExact(split[35].ToString().Trim(), new[] { "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);
                                    if (split[36].ToString().Trim() == "")
                                    {
                                        AcqSTLAmount = 0;
                                    }
                                    else
                                        AcqSTLAmount = Convert.ToDecimal(split[36].ToString().Trim());
                                    AcqCC = "";
                                    PanEntryMode = "";
                                    ServiceCode = "";
                                    CardDataInputCapability = "";
                                    MCCCode = "";
                                    ComplaintNumber = "";
                                    ComplaintClosedReason = "";
                                    Remark = "";

                                    _DataTable.Rows.Add(
                                                         Txnuid
                                                        , TxnType
                                                        , Uid
                                                        , Adjdate
                                                        , Adjtype
                                                        , ACQ
                                                        , ISR
                                                        , Response
                                                        , TxnDate
                                                        , TxnTime
                                                        , RRN
                                                        , ATMID
                                                        , CardNo
                                                        , ChbDate
                                                        , ChbRef
                                                        , TxnAmount
                                                        , AdjAmount
                                                        , ACQFee
                                                        , ISSFee
                                                        , ISSFeeSW
                                                        , NpciFee
                                                        , AcqFeeTax
                                                        , IssFeeTax
                                                        , NpciTAX
                                                        , AdjRef
                                                        , BankAdjRef
                                                        , AdjProof
                                                        , ReasonDesc
                                                        , Pincode
                                                        , ATMLocation
                                                        , MultiDisputeGroup
                                                        , FCQM
                                                        , AdjSettlementDate
                                                        , CustomerPenalty
                                                        , AdjTime
                                                        , Cycle
                                                        , TATExpiryDate
                                                        , AcqSTLAmount
                                                        , AcqCC
                                                        , PanEntryMode
                                                        , ServiceCode
                                                        , CardDataInputCapability
                                                        , MCCCode
                                                        , ComplaintNumber
                                                        , ComplaintClosedReason
                                                        , Remark
                                                        , System.DateTime.Now
                                                        , UserName
                                                        , null
                                                        , ""
                                                        , FileName
                                                        , FilePath


                                                       );

                                    LineNo++;
                                    InsertCount++;
                                    TotalCount++;
                                }
                                catch (Exception ex)
                                {

                                }
                            }

                            if (_DataTable.Rows.Count == 0)
                            {
                                //  objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessPayrakkamIMPS.CS", "IMPSAdjFileProcessCSV", LineNo, FileName, UserName, 'E');
                            }

                        }
                        catch (Exception ex)
                        {
                            DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, 0, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;
        }

      
    }
}
