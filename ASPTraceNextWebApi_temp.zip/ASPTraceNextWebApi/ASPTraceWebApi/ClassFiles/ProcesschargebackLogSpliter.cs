﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ASPTraceWebApi
{
    public class ProcesschargebackLogSpliter
    {
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;

        public ProcesschargebackLogSpliter()
        {

        }

        public ProcesschargebackLogSpliter(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        //DAlayer _FileImport = new DAlayer();
        string TerminalID = string.Empty;
        string ReferenceNumber = string.Empty;
        string CardNumber = string.Empty;
        string AccountNumber = string.Empty;
        DateTime TxnsDateTime;
        double Amount;
        string ResponseCode = string.Empty;
        string TxnsType = string.Empty;
        string TxnsSubType = string.Empty;
        string TxnsAgentTypeone = string.Empty;
        string TxnsAgentTypetwo = string.Empty;
        string DATETIME = string.Empty;
        string Reversalcode = string.Empty;

        internal void variable()
        {
            TerminalID = string.Empty;
            ReferenceNumber = string.Empty;
            CardNumber = string.Empty;
            Amount = 0;
            ResponseCode = string.Empty;
            TxnsType = string.Empty;
            TxnsSubType = string.Empty;
            TxnsAgentTypeone = string.Empty;
            TxnsAgentTypetwo = string.Empty;
            DATETIME = string.Empty;
            Reversalcode = string.Empty;
            AccountNumber = string.Empty;

        }

        protected DataTable ProcessLogSplitercharge(string FilePath, DataTable dt1, DataTable _DataTable, string UserName, string ClientCode, string FileName, string ConnectionString, out int InsertCount, out int TotalCount)
        {
            int LineNo = 0;

            string FileName1 = Path.GetFileNameWithoutExtension(FilePath);
            string FileDt = FileName1.Substring(9, 8);
            string MM = FileDt.Substring(2, 2);

            DataSet ds = new DataSet();
            string LogType = dt1.Rows[0]["FileName"].ToString();
            string xmlFile = dt1.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt1.Rows[0]["RevEntryLeg"].ToString();
            //ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt1.Rows[0]["ClientID"].ToString());
            InsertCount = 0;
            TotalCount = 0;
            try
            {//NEW 
                DateTime TR_TIMESTAMP;
                string DTTXN = string.Empty;
                string BIN = string.Empty;
                string PID = string.Empty;
                string CARDNUMBER = string.Empty;

                double Amount;
                string REFERENCENO = string.Empty;
                string TERMINALID = string.Empty;
                string MCC = string.Empty;
                string ISSUERBANK = string.Empty;
                string STATUS = string.Empty;
                string APPROVEDCODE = string.Empty;
                string TRANSACTIONAMT = string.Empty;
                string TRANSACTIONAMT1 = string.Empty;
                string TRANSACTIONAMT2 = string.Empty;
                string REFUNDAMT = string.Empty;
                DateTime FileDate;
                string REMARKS = string.Empty;

                // DataTable csvData = new DataTable();

                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                "Data Source=" + FilePath + ";Extended Properties=Excel 8.0;";
                string extension = Path.GetExtension(FilePath);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        break;
                }
                objConn = new OleDbConnection(connString);
                objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                

                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(dtexcelsheetname.Rows[0]["TABLE_NAME"]).Replace("'", "") + "]";
                //string sht = dr[2].ToString().Replace("'", "");

                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dtfillsheet1 = new DataTable();
                da.Fill(dtfillsheet1);

                //dtfillsheet1.Rows.RemoveAt(0);
                //dtfillsheet1.Rows.RemoveAt(dtfillsheet1.Rows.Count-1);
                objConn.Close();

                TotalCount = dtfillsheet1.Rows.Count;
                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {


                    try
                    {



                        TR_TIMESTAMP = Convert.ToDateTime(dtfillsheet1.Rows[i][0].ToString()); //TR_TIMESTAMP
                        DTTXN = dtfillsheet1.Rows[i][1].ToString().Trim();
                        BIN = dtfillsheet1.Rows[i][2].ToString().Trim();
                        PID = dtfillsheet1.Rows[i][3].ToString().Trim();
                        CARDNUMBER = dtfillsheet1.Rows[i][4].ToString().Trim();
                        REFERENCENO = dtfillsheet1.Rows[i][5].ToString().Trim();
                        TERMINALID = dtfillsheet1.Rows[i][6].ToString().Trim();
                        MCC = dtfillsheet1.Rows[i][7].ToString().Trim();
                        ISSUERBANK = dtfillsheet1.Rows[i][8].ToString().Trim();
                        STATUS = dtfillsheet1.Rows[i][9].ToString().Trim();
                        APPROVEDCODE = dtfillsheet1.Rows[i][10].ToString().Trim();

                        TRANSACTIONAMT = dtfillsheet1.Rows[i][11].ToString().Trim();
                        TRANSACTIONAMT1 = dtfillsheet1.Rows[i][12].ToString().Trim();
                        TRANSACTIONAMT2 = dtfillsheet1.Rows[i][13].ToString().Trim();
                        REFUNDAMT = dtfillsheet1.Rows[i][14].ToString().Trim();
                        REMARKS = dtfillsheet1.Rows[i][15].ToString().Trim();
                        string temp = FileDt.Substring(0, 2) + "/" + FileDt.Substring(2, 2) + "/" + FileDt.Substring(4, 4);
                        FileDate = DateTime.ParseExact(temp, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                        _DataTable.Rows.Add(ClientID, TR_TIMESTAMP, DTTXN, BIN, PID, CARDNUMBER,
                                REFERENCENO, TERMINALID, MCC, ISSUERBANK, STATUS, APPROVEDCODE, TRANSACTIONAMT,
                                TRANSACTIONAMT1, TRANSACTIONAMT2, REFUNDAMT, REMARKS, FileDate, System.DateTime.Now, System.DateTime.Now,
                                UserName, UserName);

                        InsertCount++;


                    }

                    catch (Exception ex)
                    { 
                        //_log.FunErrorLog(EX.Message.ToString(), BankCode, "ProcesschargebackLogSpliter", "ProcessLogSplitercharge", LineNo, FileName, UserName, 'E');
                        objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                        // variable();
                    }
                }
                if (_DataTable.Rows.Count == 0)
                {
                    InsertCount--;
                    //_log.FunErrorLog("Transaction not found", BankCode, "ProcesschargebackLogSpliter", "ProcessLogSplitercharge", LineNo, FileName, UserName, 'E');
                    objCommon.InsertLogs("Transaction not found", ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    // variable();
                }
            }
            catch (Exception ex)
            { 
                //_log.FunErrorLog(EX.Message.ToString(), BankCode, "ProcesschargebackLogSpliter", "ProcessLogSplitercharge", LineNo, FileName, UserName, 'E');
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                //  variable();
            }
            return _DataTable;
        }



        protected DataTable ProcessLogSpliterBDB(string SwitchFilePath, DataTable _DataTable, string UserName, string ClientCode, string FileName) //sachin
        {
            
            int LineNo = 0;
            try
            {
                DataTable csvData = new DataTable();
                DataTable dtfillsheet1 = new DataTable();
                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                "Data Source=" + FileName + ";Extended Properties=Excel 8.0;";
                string extension = Path.GetExtension(SwitchFilePath);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FileName + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FileName + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        break;
                }
                objConn = new OleDbConnection(connString);
                objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                

                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(dtexcelsheetname.Rows[0]["TABLE_NAME"]).Replace("'", "") + "]";
                //string sht = dr[2].ToString().Replace("'", "");

                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dtfillsheet1);

                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {

                    LineNo++;
                    // MSGTYPE = dtfillsheet1.Rows[i][0].ToString();
                    //PAN = SwitchReq[1].ToString();
                    AccountNumber = dtfillsheet1.Rows[i][15].ToString().Trim();
                    Reversalcode = dtfillsheet1.Rows[i][4].ToString();
                    ResponseCode = dtfillsheet1.Rows[i][12].ToString();
                    Amount = Convert.ToDouble(dtfillsheet1.Rows[i][5].ToString());
                    TxnsDateTime = Convert.ToDateTime(dtfillsheet1.Rows[i][7].ToString());
                    ReferenceNumber = dtfillsheet1.Rows[i][10].ToString();
                    TerminalID = dtfillsheet1.Rows[i][13].ToString();
                    //TERMLOC = dtfillsheet1.Rows[i][14].ToString();
                    TxnsType = dtfillsheet1.Rows[i][1].ToString();
                    //STATUS = dtfillsheet1.Rows[i][18].ToString();
                    TxnsSubType = dtfillsheet1.Rows[i][3].ToString();

                    _DataTable.Rows.Add(TerminalID, ReferenceNumber, CardNumber, AccountNumber, TxnsDateTime, ResponseCode, Amount, TxnsType, TxnsSubType, Reversalcode, System.DateTime.Now, System.DateTime.Now, UserName, UserName);
                    variable();
                }

                if (_DataTable.Rows.Count == 0)
                {
                    //_log.FunErrorLog("Transaction not found", BankCode, "ProcessGLLogSpliter", "ProcessLogSpliterBDB", LineNo, FileName, UserName, 'E');
                    objCommon.InsertLogs("Transaction not found", ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                }


            }
            catch (Exception ex)
            {
                _DataTable.Rows.Clear();
                //_log.FunErrorLog(EX.Message.ToString(), BankCode, "ProcessSwitchLogSpliter", "ProcessLogSpliterBDB", LineNo, FileName, UserName, 'E');
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                variable();
            }
            return _DataTable;
        }


    }
}
