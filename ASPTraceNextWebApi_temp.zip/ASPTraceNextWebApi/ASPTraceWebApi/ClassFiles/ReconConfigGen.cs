﻿
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Globalization;
using System.Xml;
using System.Text.RegularExpressions;
using ASPTrace.Models;
using System.Text;

namespace ASPTraceWebApi
{
    public class ReconConfigGen
    {


        Utility.DateTimeConverter objDateTimeConverter = new Utility.DateTimeConverter();
        System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");

        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public ReconConfigGen(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        public static string FormatSQLQueries(string sqlQueries)
        {
            // Split the SQL queries by semicolon
            string[] queryArray = sqlQueries.Split(";");

            // Format each query individually
            for (int i = 0; i < queryArray.Length; i++)
            {
                queryArray[i] = FormatSQLQuery(queryArray[i]);
            }

            // Join the queries back together with semicolons
            sqlQueries = string.Join(";", queryArray);

            return sqlQueries;
        }
        public static string BaseQuery(dynamic Fields)
        {

            #region Query


            string Query = $@"
CREATE PROCEDURE [dbo].[sp{Fields.ChannelNameKS}{Fields.ModeNameKS}UnmatchedTxns]                          
(                          
@ClientID NVARCHAR(50)                           
,@TERMINALID NVARCHAR(50)--- = 0                                                        
,@TR_POSTDATE  DATETIME-- =null                            
,@TR_ENDDATE  DATETIME-- =null                             
,@user nvarchar(100)-- =null                            
,@output nvarchar(max) output                                                     
)                          
AS                          
Begin                          
SET NOCOUNT ON                          
BEGIN TRY                          
if(@TERMINALID='-- All --')                          
set @TERMINALID='0'                          
                          
declare                           
@JoinCond nvarchar(max),                           
@JoinCond1 nvarchar(max),                          
@JoinCond2 nvarchar(max),                           
@SettleJoin nvarchar(max),                          
@MainJoin nvarchar(max),                          
@ForceSettledOnusCond nvarchar(max),                          
@ForceSettledAcqCond nvarchar(max),                          
@SQLONUS nvarchar(max),                          
@SQLACQ nvarchar(max),  
@SELECTCOLM nvarchar(max)   
                          
select @JoinCond = stuff((select ' AND ' + ' SW.' + quotename(ColumnName) + ' = GL.' + quotename(ColumnName) from MatchingRuleMaster                         
where ClientID = @ClientID and ChannelID IN (1,5) and ModeID like '%1,2%' and IsRemoved = 0 and RuleType = 1  FOR XML PATH('')), 1,5, '')                          
                          
select @JoinCond1 = stuff((select ' AND ' + 'COALESCE(SW.' + quotename(ColumnName) + ' , GL.' + quotename(ColumnName) + ' )' + ' = NW.' + quotename(ColumnName)                         
from MatchingRuleMaster where ClientID = @ClientID and ChannelID IN (1,5) and ModeID like '%1,2%' and IsRemoved = 0 and RuleType = 1  FOR XML PATH('')), 1,5, '')                          
                          
select @JoinCond2 = stuff((select ' AND ' + 'COALESCE(SW.' + quotename(ColumnName) + ' , GL.' + quotename(ColumnName) + ' , NW.' + quotename(ColumnName) + ' )' + ' = EJ.' + quotename(ColumnName)                         
from MatchingRuleMaster where ClientID = @ClientID and ChannelID IN (1,5) and ModeID like '%1,2%' and IsRemoved = 0 and RuleType = 1  FOR XML PATH('')), 1,5, '')                          
                          
select @MainJoin = stuff((select ' AND ' + ' s.' + quotename(ColumnName) + ' = t.' + quotename(ColumnName) from MatchingRuleMaster where ClientID = @ClientID                         
and ChannelID IN (1,5) and ModeID like '%1,2%' and IsRemoved = 0 and RuleType = 1  FOR XML PATH('')), 1,5, '')                       
                      
select @SettleJoin = stuff((select ' AND ' + ' s.' + quotename(ColumnName) + ' = t.' + quotename(ColumnName) from MatchingRuleMaster where ClientID = @ClientID                         
and ChannelID IN (1,5) and ModeID like '%1,2%' and IsRemoved = 0 and RuleType = 2  FOR XML PATH('')), 1,5, '')                          
                          
select @ForceSettledOnusCond = stuff((select ' AND ' + quotename(TableName) + '=' +  TxnStatus from ForceSettlementRuleMaster                       
where ClientId = @ClientID and ChannelID IN (1,5) and ModeID = 1 and IsRemoved = 0 FOR XML PATH('')), 1,5, '')                          
                      
select @ForceSettledAcqCond = stuff((select ' AND ' + quotename(TableName) + '=' +  TxnStatus  from ForceSettlementRuleMaster                      
where ClientId = @ClientID and ChannelID IN (1,5) and ModeID = 2 and IsRemoved = 0 FOR XML PATH('')), 1,5, '')                          
             
                        
                          
print '@JoinCond:- ' + @JoinCond             
print '@JoinCond1:- ' +  @JoinCond1                          
print '@JoinCond2:- ' +  @JoinCond2                          
print '@SettleJoin:- ' + @SettleJoin                          
print '@MainJoin:- ' + @MainJoin                          
print '@ForceSettledOnusCond:- ' + @ForceSettledOnusCond                          
print '@ForceSettledAcqCond:- ' + @ForceSettledAcqCond               
                          
---------------------------------------------------------------------------Declare Globle Variable---------------------------------------------------------------------------------------------------------------------------------------------------------    
  
   
      
         
                           
                                     
declare                                                              
 @FROMDATE datetime                                                              
,@TODATE datetime                             
,@FROM datetime                          
 ,@FROMDATE1 NVARCHAR(50)                                                            
,@TODATE1 NVARCHAR(50)                           
,@CUTOFFTIME NVARCHAR(50) = '22:59:59.999'  -- Daily Switch Cutoff Time                                                              
,@DAYS INT = -1  -- Previous Day's                                                            
,@TB_DATE1 VARCHAR(20) ,@TB_LUNO1 VARCHAR(20),@TB_AMOUNT1 VARCHAR(20),@TB_CARDNUMBER1 VARCHAR(20)                                                        
,@COUNT INT= 0                                                        
,@INCREMENTOR INT = 0                          
SET @FROM = DATEADD(DD ,@DAYS,CONVERT(DATETIME, LEFT(CONVERT(NVARCHAR, @TR_POSTDATE, 113),12)+ @CUTOFFTIME,113))                            
SET @FROMDATE = DATEADD(DD ,@DAYS,CONVERT(DATETIME, LEFT(CONVERT(NVARCHAR, @TR_POSTDATE, 113),12)+ @CUTOFFTIME,113))                                                            
SET @TODATE = DATEADD(DD ,@DAYS,CONVERT(DATETIME, LEFT(CONVERT(NVARCHAR, @TR_ENDDATE, 113),12)+@CUTOFFTIME,113))                          
SET @FROMDATE1 = DATEADD(DD ,@DAYS,CONVERT(DATETIME, LEFT(CONVERT(NVARCHAR, @TR_POSTDATE, 113),12)+ @CUTOFFTIME,113))                                                            
SET @TODATE1 = DATEADD(DD ,@DAYS,CONVERT(DATETIME, LEFT(CONVERT(NVARCHAR, @TR_ENDDATE, 113),12)+@CUTOFFTIME,113))                          
                            
PRINT @FROMDATE1                          
PRINT @TODATE1                          
                          
declare @No_Of_Days INT=DATEDIFF(Day,@FROMDATE,@TODATE)                          
--PRINT @No_Of_Days                          
                          
WHILE (@COUNT <= @No_Of_Days)                          
BEGIN                          
SET @COUNT=@COUNT+1                          
SET @TR_POSTDATE=DATEADD(day,@INCREMENTOR,CONVERT(DATETIME, LEFT(CONVERT(NVARCHAR, @TR_POSTDATE, 113),12)))                          
SET @INCREMENTOR=1                          
PRINT @INCREMENTOR                          
SET @FROMDATE = DATEADD(DD ,@DAYS,CONVERT(DATETIME, LEFT(CONVERT(NVARCHAR, @TR_POSTDATE, 113),12)+ @CUTOFFTIME,113))                                                            
SET @TODATE = CONVERT(DATETIME, LEFT(CONVERT(NVARCHAR, @TR_POSTDATE, 113),12)+@CUTOFFTIME,113)                           
print @FROMDATE                          
print @TODATE                          
                            
IF OBJECT_ID('tempdb..#TMPUnmatchedTxns' ) IS NOT NULL DROP TABLE #TMPUnmatchedTxns;                          
IF OBJECT_ID('tempdb..#GLNonReversal' ) IS NOT NULL DROP TABLE #GLNonReversal;                          
IF OBJECT_ID('tempdb..#GLReversal' ) IS NOT NULL DROP TABLE #GLReversal;                          
IF OBJECT_ID('tempdb..#SWNonReversal' ) IS NOT NULL DROP TABLE #SWNonReversal;                          
IF OBJECT_ID('tempdb..#SWReversal' ) IS NOT NULL DROP TABLE #SWReversal;                          
IF OBJECT_ID('tempdb..#NPCIAcquirer' ) IS NOT NULL DROP TABLE #NPCIAcquirer;                          
IF OBJECT_ID('tempdb..#EJData' ) IS NOT NULL DROP TABLE #EJData;                          
IF OBJECT_ID('tempdb..#SwitchData' ) IS NOT NULL DROP TABLE #SwitchData;                          
IF OBJECT_ID('tempdb..#GLData' ) IS NOT NULL DROP TABLE #GLData;                  
IF OBJECT_ID('tempdb..#TMPUnmatchedTxnsFinal' ) IS NOT NULL DROP TABLE #TMPUnmatchedTxnsFinal;                          
IF OBJECT_ID('tempdb..#NWS' ) IS NOT NULL DROP TABLE #NWS;                          
IF OBJECT_ID('tempdb..#NWR' ) IS NOT NULL DROP TABLE #NWR;                          
IF OBJECT_ID('tempdb..#NWMS' ) IS NOT NULL DROP TABLE #NWMS;                          
IF OBJECT_ID('tempdb..#NWMR' ) IS NOT NULL DROP TABLE #NWMR;                          
IF OBJECT_ID('tempdb..#NWUS' ) IS NOT NULL DROP TABLE #NWUS;                          
IF OBJECT_ID('tempdb..#NWUR' ) IS NOT NULL DROP TABLE #NWUR;                          
--IF OBJECT_ID('tempdb..#NWVS' ) IS NOT NULL DROP TABLE #NWVS;                          
--IF OBJECT_ID('tempdb..#NWVR' ) IS NOT NULL DROP TABLE #NWVR;                          
IF OBJECT_ID('tempdb..##TempForceSettledTxnsOnus' ) IS NOT NULL DROP TABLE ##TempForceSettledTxnsOnus;                          
IF OBJECT_ID('tempdb..##TempForceSettledTxnsAcq' ) IS NOT NULL DROP TABLE ##TempForceSettledTxnsAcq;                           
                          
---------------------------------------------------------------------------Unmatched Temp Table--------------------------------------------------------------------------------------------------------------------------------------------------              
  
    
     
         
          
            
                          
Create table #TMPUnmatchedTxns                          
(                          
ClientID bigint,                          
ChannelID bigint,                          
ModeID bigint,                          
TerminalId nvarchar(250),                          
ReferenceNumber nvarchar(250),                          
CardNumber nvarchar(max),                        
CardType nvarchar(150),                          
TxnsDateTime datetime,                          
TxnsAmount decimal(18,2),                          
ActualTxnsAmount decimal(18,2),                          
GLStatus bigint,                          
EJStatus bigint,                          
NWStatus bigint,                          
SWStatus bigint,                          
ReconType nvarchar(100),                          
CustAccountNo nvarchar(150),                          
ATMAccountNo nvarchar(150),                          
TxnsType nvarchar(250),                          
TxnsSubType nvarchar(250),                          
TxnsEntryType nvarchar(250)                          
)                          
                  
  
   
-------------------------------------------------------------------------------Set SQL Query with Dynamic join-----------------------------------------------------------------------------------------------------------------------------                    
     
                          
                               
                          
  
{Fields.TempTablesBlockKS}                       
    
      
select * from  #TMPUnmatchedTxns --where ReferenceNumber in('104608003953')                          
-----------------------------------------------------------------------------Final Temp with Debit_Credit Status---------------------------------------------------------------------------------------------------------------------------                    
  
   
      
       
                          
select  ClientID, ChannelID, ModeID, TERMINALID, ReferenceNumber, CARDNUMBER, CardType, cast(TxnsDateTime as date) as TxnsDateTime, TxnsAmount,                      
ActualTxnsAmount, GLStatus, EJStatus, NWStatus, SWStatus, ReconType, CustAccountNo, ATMAccountNo, TxnsType, TxnsSubType, TxnsEntryType,                          
                          
case when GLSTATUS =1 and EJSTATUS <> 1 then 'C'                          
     when GLSTATUS not in (1,9) and EJSTATUS = 1 then 'D'                          
     when GLSTATUS = 9 and EJSTATUS <> 1 then 'D'                          
     when GLSTATUS = 1 and EJSTATUS = 1 then 'OK' end as DebitCredit,                          
                               
case when GLSTATUS = 1 and EJSTATUS <> 1 then Cast(ModeID as nvarchar(50))+'->'+'CWD/'+ ReferenceNumber +'/'+CARDNUMBER                          
     when GLSTATUS not in (1,9) and EJSTATUS = 1 then Cast(ModeID as nvarchar(50))+'->'+'CWD/'+ReferenceNumber+'/'+CARDNUMBER                          
     when GLSTATUS = 9 and EJSTATUS <> 1 then Cast(ModeID as nvarchar(50))+'->'+'Credit/'+ReferenceNumber+'/'+CARDNUMBER                          
     when GLSTATUS = 1 and EJSTATUS = 1 then 'NOT REQUIRED' end as TransactionParticulars,                          
  TxnsDateTime as TxnsValueDateTime                          
into #TMPUnmatchedTxnsFinal                           
from #TMPUnmatchedTxns where ReferenceNumber !=''                          

   
----------------------------------Insert Duplicate Records-----------------------------  
  
  
  
Exec('  
delete t from #TMPUnmatchedTxnsFinal t   
inner join DuplicateTxns s   
on 1=1 AND ' + @SettleJoin)  
  
  
select @SELECTCOLM = (select stuff((select quotename(ColumnName) + ','  from MatchingRuleMaster                         
where ClientID = @ClientID and ChannelID IN (1,5) and ModeID like '%1,2%' and IsRemoved = 0 and RuleType = 1  FOR XML PATH('')), 1,0, '')      )  
  
select @SELECTCOLM = (select substring(@SELECTCOLM, 1, (len(@SELECTCOLM) - 1)))  
  
Exec('  
insert into DuplicateTxns  
   select   
   SW.ClientID,  
   SW.ChannelID,  
   SW.ModeID,  
   SW.TERMINALID,  
   SW.ReferenceNumber,  
   SW.CARDNUMBER,  
   SW.CardType,  
   SW.TxnsValueDateTime,  
   SW.TxnsDateTime,  
   SW.TxnsAmount,  
   SW.ActualTxnsAmount,  
   SW.GLStatus,  
   SW.EJStatus,  
   SW.NWStatus,  
   SW.SWStatus,  
   SW.ReconType,  
   SW.CustAccountNo,  
   SW.ATMAccountNo,  
   null,  
   SW.TxnsType,  
   SW.TxnsSubType,  
   SW.TxnsEntryType,  
   null,  
   0,  
   null,  
   null,  
   null,  
   null,  
   0,  
   null,  
   ''' + @user + ''',  
   GETDATE(),  
   null,  
   null from #TMPUnmatchedTxnsFinal SW inner join (  
select ' + @SELECTCOLM + '  
from #TMPUnmatchedTxnsFinal   
group by ' + @SELECTCOLM + '  
having count(1)>1) GL   
on 1=1  AND ' + @JoinCond  
)  
  
Exec('  
delete SW from #TMPUnmatchedTxnsFinal SW inner join (  
select ' + @SELECTCOLM + '  
from #TMPUnmatchedTxnsFinal   
group by ' + @SELECTCOLM + '  
having count(1)>1) GL   
on 1=1  AND ' + @JoinCond  
)  
  
-------------------------------------------------------------------------------------  
  
  
  
-------------------------------------------------------------------------Update Status of Txn in Manual Settled Table-----------------------------------------------------------------------------------------------------------                          
                          
Exec (                          
'                          
MERGE INTO ForceSettledTxns AS t                          
    USING #TMPUnmatchedTxnsFinal AS s                              
        ON t.ClientID = s.ClientID AND '  + @SettleJoin +                           
    'and  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.ModeID in (1,2) and t.ClientID = ' + @ClientID + '                          
    WHEN MATCHED THEN                          
   UPDATE                           
       set                          
       t.ModifiedOn=GETDATE(),                          
    t.ModifiedBy=''' + @user + ''',          
 t.GLStatus = case when (t.GLStatus <> s.GLSTATUS) AND (t.GLStatus <> 1) AND (s.GLSTATUS <> 3)                          
                      then s.GLSTATUS                          
                      else t.GLStatus                            
                      end,                          
    t.NWStatus = case when (t.NWStatus <> s.NWStatus) AND (t.NWStatus <> 1) AND (s.NWStatus <> 3)                           
                      then s.NWStatus                          
                      else t.NWStatus                          
                      end,                          
    t.SWStatus = case when (t.SWStatus <> s.SWSTATUS) AND (t.SWStatus <> 1) AND (s.SWStatus <> 3)                           
                      then s.SWStatus                          
                      else t.SWStatus                          
                      end,                          
    t.EJStatus = case when (t.EJStatus <> s.EJSTATUS) AND (t.EJStatus <> 1) AND (s.EJSTATUS <> 3)                           
                      then s.EJStatus                          
                      else t.EJStatus                          
                      end,                          
    t.CustAccountNo=case when t.CustAccountNo IS NULL THEN s.CustAccountNo ELSE t.CustAccountNo END,                          
    t.CardNumber=case when t.CardNumber IS NULL THEN s.CardNumber ELSE t.CardNumber END ;'                          
)                          
                          
Exec (                          
'DELETE t FROM #TMPUnmatchedTxnsFinal t inner join ForceSettledTxns s                           
   ON t.ClientID = s.ClientID AND '  + @SettleJoin +                           
    'and  s.TxnsSubType =''Withdrawal''  and s.ChannelID IN (1,5) and s.ModeID in (1,2) and s.ClientID = ' + @ClientID + '                          
'                          
)                          
                          
---------------------------------------------------------------------------Update Status of Txn in Unmatched Table-----------------------------------------------------------------------------------------------------------------------                      
  
    
Exec (                          
'                          
MERGE INTO UnmatchedTxns AS t                          
    USING #TMPUnmatchedTxnsFinal AS s                              
        ON t.ClientID = s.ClientID AND '  + @SettleJoin + --t.Terminalid = s.Terminalid AND t.ReferenceNumber = s.ReferenceNumber AND t.TxnsAmount = s.TxnsAmount                          
    'and  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and isnull(s.ModeID,0) in (1,2,0) and t.ClientID = ' + @ClientID + '                 
    WHEN MATCHED THEN                          
   UPDATE                           
       set                          
       t.ModifiedOn=GETDATE(),                          
    t.ModifiedBy=''' + @user + ''',                               
    t.GLStatus = case when (t.GLStatus <> s.GLSTATUS) AND (t.GLStatus <> 1) AND (s.GLSTATUS <> 3)                          
                      then s.GLSTATUS                          
 else t.GLStatus                            
                      end,                          
    t.NWStatus= case  when (t.NWStatus <> s.NWStatus) AND (t.NWStatus <> 1) AND (s.NWStatus <> 3)                           
                      then s.NWStatus                          
                      else t.NWStatus                          
                      end,                          
    t.SWStatus = case when (t.SWStatus <> s.SWSTATUS) AND (t.SWStatus <> 1) AND (s.SWStatus <> 3)                           
                      then s.SWStatus                          
                      else t.SWStatus                          
                      end,                          
    t.EJStatus = case when (t.EJStatus <> s.EJSTATUS) AND (t.EJStatus <> 1) AND (s.EJSTATUS <> 3)                           
                      then s.EJStatus                          
                      else t.EJStatus                          
                      end,                          
    t.CustAccountNo=case when t.CustAccountNo IS NULL THEN s.CustAccountNo ELSE t.CustAccountNo END,                          
    t.ModeID = case when t.ModeID IS NULL THEN s.ModeID ELSE t.ModeID END,                          
    t.CardNumber=case when t.CardNumber IS NULL THEN s.CardNumber ELSE t.CardNumber END,             
    t.TxnsValueDateTime = case when s.SWSTATUS is not null then s.TxnsValueDateTime end,            
    t.TxnsDateTime =  case when s.SWSTATUS is not null then Cast(s.TxnsDateTime as date) end;'                          
)                          
                          
--------------------------------------------------------------------------------Record Settled Process-----------------------------------------------------------------------------------------------------------------------------------------------------    
       
                       
Exec (                           
' MERGE INTO UnmatchedTxns AS t                          
  USING #TMPUnmatchedTxnsFinal AS s                              
      ON t.ClientID = s.ClientID AND '  + @SettleJoin +                          
   ' and  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID  IN (1,5) and s.ModeID in (1,2) and t.ClientID = ' + @ClientID + '                          
    WHEN MATCHED AND ((t.NWStatus in(1,10))                            
                 AND  (t.EJStatus in(1,10))                            
                 AND  (t.GLStatus =1)                          
                 AND  (t.SWStatus =1)                          
         ) THEN                          
      Update  set t.SettledRemarks=''Settled'',                          
 t.TxnRemarks = ''Successful'',                          
                  t.ModifiedOn=GETDATE(),                          
                  t.SettledBy=''Application'',                     
                  t.OnSettled=s.TxnsValueDateTime,                           
                  t.DrCrType=''OK'',                          
                  t.TxnsParticulars=''NOT REQUIRED'',                          
                  t.IsSettled=1,                          
                  t.Aging=0;'                          
)                          
                          
Exec (                           
'MERGE INTO UnmatchedTxns AS t                          
USING #TMPUnmatchedTxnsFinal AS s                              
      ON t.ClientID = s.ClientID AND '  + @SettleJoin +                          
   'and  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID  IN (1,5) and s.ModeID in (1,2) and t.ClientID = ' + @ClientID + '                          
    WHEN MATCHED AND ((t.NWStatus in (4,10))                            
                 AND  (t.EJStatus in (2,3,10))                            
                 AND  (t.GLStatus in (3,4))                          
       AND  (t.SWSTATUS = 4)                          
         ) THEN                          
      Update  set t.SettledRemarks=''Settled'',                          
                  t.TxnRemarks = ''Reversal'',                          
                  t.ModifiedOn=GETDATE(),                          
                  t.SettledBy=''Application'',                          
                  t.OnSettled=s.TxnsValueDateTime,                           
                  t.DrCrType=''OK'',                          
     t.TxnsParticulars=''NOT REQUIRED'',                          
                  t.IsSettled=1,                          
                  t.Aging=0;'                          
)                          
                          
Exec (                           
'MERGE INTO UnmatchedTxns AS t                          
  USING #TMPUnmatchedTxnsFinal AS s                              
      ON t.ClientID = s.ClientID AND '  + @SettleJoin +                          
   'and  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.ModeID in (1,2) and t.ClientID = ' + @ClientID + '                          
    WHEN MATCHED AND ((t.EJStatus in (2,10,3))                           
        AND (t.NWStatus in (2,3))                           
        AND (t.GLStatus in (2,3))                          
        AND (t.SWSTATUS in (2,3))                          
         ) THEN                          
      Update  set t.SettledRemarks=''Settled'',                          
                  t.TxnRemarks = ''Unsuccessful'',                          
                  t.ModifiedOn=GETDATE(),                          
                  t.SettledBy=''Application'',                          
                  t.OnSettled=s.TxnsValueDateTime,                           
                  t.DrCrType=''OK'',                          
                  t.TxnsParticulars=''NOT REQUIRED'',                          
                  t.IsSettled=1,                          
                  t.Aging=0;'                          
)                          
                 
                          
EXEC( 'MERGE INTO UnmatchedTxns AS t                          
  USING #TMPUnmatchedTxnsFinal AS s                              
      ON t.ClientID = s.ClientID AND '  + @SettleJoin +                          
   'and  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and t.ClientID = ' + @ClientID + '                      
    WHEN MATCHED AND ((  s.ModeID = 2                          
        AND (t.NWStatus = 5)                            
        AND (t.GLStatus =5)                          
         )                          
      OR                          
      ( s.ModeID = 1                          
        AND (t.SWStatus = 5)                            
        AND (t.GLStatus =5)                          
         ))                          
       THEN                          
      Update  set t.SettledRemarks=''Settled'',                          
                  t.TxnRemarks = ''Partial Reversal'',                          
                  t.ModifiedOn=GETDATE(),                          
  t.SettledBy=''Application'',                          
                  t.OnSettled=s.TxnsValueDateTime,                           
                  t.DrCrType=''OK'',                          
                  t.TxnsParticulars=''NOT REQUIRED'',                          
                  t.IsSettled=1,                          
                  t.Aging=0;'                          
)                          
                        
Exec (                          
'DELETE t FROM #TMPUnmatchedTxnsFinal t inner join UnmatchedTxns s                           
   ON t.ClientID = s.ClientID AND '  + @SettleJoin +                           
    'and  s.TxnsSubType =''Withdrawal''  and s.ChannelID IN (1,5) and s.ModeID in (1,2) and s.ClientID = ' + @ClientID + '                          
'                          
)                          
                        
---------------------------------------------------------------------------------Status Update -----------------------------------------------------------------------------------------------------------------------------                          
Exec (                          
'                          
DECLARE @T TABLE(ID nvarchar(40))                          
MERGE INTO SuccessfulTxns AS t                          
    USING #TMPUnmatchedTxnsFinal AS s                              
        ON t.ClientID = s.ClientID AND '  + @SettleJoin + --t.Terminalid = s.Terminalid AND t.ReferenceNumber = s.ReferenceNumber AND t.TxnsAmount = s.TxnsAmount                          
    'and  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.ModeID in (1,2) and t.ClientID = ' + @ClientID + '                          
    WHEN MATCHED THEN                          
   UPDATE        
       set                          
       t.ModifiedOn=GETDATE(),                          
    t.ModifiedBy=''' + @user + ''',                               
    t.GLStatus = case when (t.GLStatus <> s.GLSTATUS) AND (t.GLStatus <> 1) AND (s.GLSTATUS <> 3)                          
                      then s.GLSTATUS                          
                      else t.GLStatus                            
                      end,                          
    t.NWStatus= case  when (t.NWStatus <> s.NWStatus) AND (t.NWStatus <> 1) AND (s.NWStatus <> 3)                           
                      then s.NWStatus                          
                      else t.NWStatus                          
                      end,                          
    t.SWStatus = case when (t.SWStatus <> s.SWSTATUS) AND (t.SWStatus <> 1) AND (s.SWStatus <> 3)                       
                   then s.SWStatus                          
          else t.SWStatus                          
                      end,                          
    t.EJStatus = case when (t.EJStatus <> s.EJSTATUS) AND (t.EJStatus <> 1) AND (s.EJSTATUS <> 3)                           
                      then s.EJStatus                          
                      else t.EJStatus                          
                      end,                          
    t.CustAccountNo=case when t.CustAccountNo IS NULL THEN s.CustAccountNo ELSE t.CustAccountNo END,                       
    t.CardNumber=case when t.CardNumber IS NULL THEN s.CardNumber ELSE t.CardNumber END                           
    OUTPUT s.referencenumber into @T ;                           
    DELETE temp from #TMPUnmatchedTxnsFinal temp inner join @T t on T.id=TEMP.ReferenceNumber '                   
)                          
                          
Exec (                          
'                          
MERGE INTO ReversalTxns AS t                          
    USING #TMPUnmatchedTxnsFinal AS s                              
        ON t.ClientID = s.ClientID AND '  + @SettleJoin + --t.Terminalid = s.Terminalid AND t.ReferenceNumber = s.ReferenceNumber AND t.TxnsAmount = s.TxnsAmount                          
    'and  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.ModeID in (1,2) and t.ClientID = ' + @ClientID + '                          
    WHEN MATCHED THEN                          
   UPDATE                           
       set                          
       t.ModifiedOn=GETDATE(),                          
    t.ModifiedBy=''' + @user + ''',                               
    t.GLStatus = case when (t.GLStatus <> s.GLSTATUS) AND (t.GLStatus <> 1) AND (s.GLSTATUS <> 3)                          
                      then s.GLSTATUS                          
                      else t.GLStatus                            
                      end,                          
     t.NWStatus= case  when (t.NWStatus <> s.NWStatus) AND (t.NWStatus <> 1) AND (s.NWStatus <> 3)                           
                       then s.NWStatus                          
                       else t.NWStatus                          
                       end,                          
    t.SWStatus = case when (t.SWStatus <> s.SWSTATUS) AND (t.SWStatus <> 1) AND (s.SWStatus <> 3)                           
                      then s.SWStatus                          
                      else t.SWStatus                          
                      end,                          
    t.EJStatus = case when (t.EJStatus <> s.EJSTATUS) AND (t.EJStatus <> 1) AND (s.EJSTATUS <> 3)                           
                      then s.EJStatus                          
                      else t.EJStatus                          
                      end,               
    t.CustAccountNo=case when t.CustAccountNo IS NULL THEN s.CustAccountNo ELSE t.CustAccountNo END,                          
    t.CardNumber=case when t.CardNumber IS NULL THEN s.CardNumber ELSE t.CardNumber END ;'                          
)                          
                          
Exec (                          
'                          
MERGE INTO unsuccessfulTxns AS t                          
    USING #TMPUnmatchedTxnsFinal AS s                              
        ON t.ClientID = s.ClientID AND '  + @SettleJoin + --t.Terminalid = s.Terminalid AND t.ReferenceNumber = s.ReferenceNumber AND t.TxnsAmount = s.TxnsAmount                          
    'and  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.ModeID in (1,2) and t.ClientID = ' + @ClientID + '                          
    WHEN MATCHED THEN                          
   UPDATE                         
       set                          
       t.ModifiedOn=GETDATE(),                          
    t.ModifiedBy=''' + @user + ''',                               
    t.GLStatus = case when (t.GLStatus <> s.GLSTATUS) AND (t.GLStatus <> 1) AND (s.GLSTATUS <> 3)                          
                      then s.GLSTATUS                          
                      else t.GLStatus                            
                      end,                     
    t.NWStatus= case  when (t.NWStatus <> s.NWStatus) AND (t.NWStatus <> 1) AND (s.NWStatus <> 3)                           
                      then s.NWStatus                          
                      else t.NWStatus                          
                      end,                          
    t.SWStatus = case when (t.SWStatus <> s.SWSTATUS) AND (t.SWStatus <> 1) AND (s.SWStatus <> 3)                           
                      then s.SWStatus                          
                      else t.SWStatus                 
                      end,                          
    t.EJStatus = case when (t.EJStatus <> s.EJSTATUS) AND (t.EJStatus <> 1) AND (s.EJSTATUS <> 3)                           
                      then s.EJStatus                          
                      else t.EJStatus                          
                      end,                          
    t.CustAccountNo=case when t.CustAccountNo IS NULL THEN s.CustAccountNo ELSE t.CustAccountNo END,                          
    t.CardNumber=case when t.CardNumber IS NULL THEN s.CardNumber ELSE t.CardNumber END ;'                          
)        
  
------------------------------------delete exsiting record----------------------  
  
Exec (  
'DELETE t FROM #TMPUnmatchedTxnsFinal t inner join SuccessfulTxns s    
   ON t.ClientID = s.ClientID AND '  + @SettleJoin +    
    ' and  s.TxnsSubType =''Withdrawal'' and s.ChannelID IN (1,5)  and s.ModeID  in (1,2)   and s.ClientID = ' + @ClientID + '  
'  
)  
  
  
Exec (  
'DELETE t FROM #TMPUnmatchedTxnsFinal t inner join ReversalTxns s    
   ON t.ClientID = s.ClientID AND '  + @SettleJoin +    
    ' and  s.TxnsSubType =''Withdrawal'' and s.ChannelID IN (1,5)  and s.ModeID  in (1,2)   and s.ClientID = ' + @ClientID + '  
'  
)  
  
Exec (  
'DELETE t FROM #TMPUnmatchedTxnsFinal t inner join UnsuccessfulTxns s    
   ON t.ClientID = s.ClientID AND '  + @SettleJoin +    
    ' and  s.TxnsSubType =''Withdrawal'' and s.ChannelID IN (1,5)  and s.ModeID  in (1,2)   and s.ClientID = ' + @ClientID + '  
'  
)  
  
Exec (  
'DELETE t FROM UnmatchedTxns t inner join DuplicateTxns s    
   ON t.ClientID = s.ClientID AND '  + @SettleJoin +    
    ' and  s.TxnsSubType =''Withdrawal'' and s.ChannelID IN (1,5)  and s.ModeID  in (1,2)   and s.ClientID = ' + @ClientID + '  
'  
)  
  
-----------------------------------------------------------------------------------------  
  
  
---------------------------------------------------------------------------Successful ATM txn Data-----------------------------------------------------------------------------------------------------------------------------                          
EXEC (                          
'MERGE INTO SuccessfulTxns AS t                          
    USING #TMPUnmatchedTxnsFinal AS s    
                          
        ON t.ClientID = s.ClientID AND '  + @MainJoin +                          
   'AND  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.ModeID in (1,2)                           
   AND (s.GLSTATUS = 1 AND s.EJSTATUS IN (1,10) AND s.NWStatus IN (1,10) and s.SWSTATUS = 1) and t.ClientID = ' + @ClientID + '                          
                          
    WHEN MATCHED THEN                          
  UPDATE set  t.[ModifiedOn]=GETDATE(),                          
     t.[ModifiedBy]= ''' + @user +'''          
                               
    WHEN NOT MATCHED AND (s.GLSTATUS  = 1 AND s.EJSTATUS IN (1,10) AND s.NWStatus IN (1,10) and s.SWSTATUS  = 1  and s.ChannelID IN (1,5) and s.ModeID in (1,2)) THEN                           
        INSERT VALUES                           
  (                          
  s.ClientID,                          
  s.ChannelID,                          
  s.ModeID,                          
  s.TERMINALID,                          
  s.ReferenceNumber,                          
  s.CARDNUMBER,                          
  s.CardType,                          
  s.TxnsValueDateTime,                          
  s.TxnsDateTime,                          
  s.TxnsAmount,                          
  s.ActualTxnsAmount,                          
  s.GLStatus,                          
  s.EJStatus,                          
  s.NWStatus,                          
  s.SWStatus,                          
  s.ReconType,                          
  s.CustAccountNo,                          
  s.ATMAccountNo,                          
  ''OK'',                          
  s.TxnsType,                          
  s.TxnsSubType,                          
  s.TxnsEntryType,                          
  null,                          
  0,                          
  null,                          
  null,                          
  null,                   
  null,                          
  0,                          
  null,                          
  ''' + @user +''',                          
  GETDATE(),                          
  null,                          
  null);'                          
)                          
                        
-------------------------------------------------------------------------------------Reversal ATM txn Data-----------------------------------------------------------------------------------------------------------------------------                       
  
   
EXEC (                          
'MERGE INTO ReversalTxns AS t                          
    USING #TMPUnmatchedTxnsFinal AS s                              
                          
      ON t.ClientID = s.ClientID AND '  + @MainJoin +                          
   'AND  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.ModeID in (1,2)                           
   AND (s.GLSTATUS in (3,4) AND s.EJSTATUS in (2,3,10) AND s.NWStatus in (4,10) and s.SWSTATUS = 4) and t.ClientID = ' + @ClientID + '                          
                          
    WHEN MATCHED THEN                          
 UPDATE set  t.[ModifiedOn]=GETDATE(),                          
    t.[ModifiedBy]=''' + @user +'''                          
                          
   WHEN NOT MATCHED AND (s.GLSTATUS in (3,4) AND s.EJSTATUS in (2,3,10) AND s.NWStatus in (4,10) and  s.SWSTATUS = 4 AND s.ChannelID IN (1,5) and s.ModeID in (1,2)) THEN                           
                                 
        INSERT VALUES                           
  (                          
  s.ClientID,                          
  s.ChannelID,                          
  s.ModeID,                          
  s.TERMINALID,                          
  s.ReferenceNumber,                          
  s.CARDNUMBER,                          
  s.CardType,                          
  s.TxnsValueDateTime,                          
  s.TxnsDateTime,                          
  s.TxnsAmount,                
  s.ActualTxnsAmount,                          
  s.GLStatus,                          
  s.EJStatus,                          
  s.NWStatus,                          
  s.SWStatus,                          
  s.ReconType,                     
  s.CustAccountNo,                          
  s.ATMAccountNo,                          
  ''OK'',                          
  s.TxnsType,                          
  s.TxnsSubType,                          
  s.TxnsEntryType,                          
  null,             
  0,                          
  null,                          
  null,                          
  null,                          
  null,                          
  0,                          
  null,                          
  ''' + @user +''',                          
  GETDATE(),                          
  null,                          
  null);'                          
)                          
                        
--------------------------------------------------------------------------------------Unsuccessful ATM txn Data-------------------------------------------------------------------------------------------------------                          
EXEC(                          
'MERGE INTO UnsuccessfulTxns AS t                          
    USING #TMPUnmatchedTxnsFinal AS s                              
                          
        ON t.ClientID = s.ClientID AND '  + @MainJoin +                          
   ' AND  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.ModeID in (1,2)  and t.ClientID = ' + @ClientID + '                          
   AND ((s.ChannelID = 1 and s.GLSTATUS in (2,3) AND s.EJSTATUS in (2,10,3) AND s.NWStatus IN (2,10,3) and s.SWSTATUS in (2,3,4)) OR                          
        (s.ChannelID = 5 and s.GLSTATUS in (2,3) AND s.EJSTATUS IN (2,10,3) AND s.NWStatus IN (2,10,3) and s.SWSTATUS in (2,3,4)))                          
                             
    WHEN MATCHED THEN                          
 UPDATE set  t.[ModifiedOn]=GETDATE(),                          
    t.[ModifiedBy]=''' + @user +'''                          
                          
   WHEN NOT MATCHED AND (s.GLSTATUS in (2,3) AND s.EJSTATUS in (2,10,3) AND s.NWStatus IN (2,10,3) and  s.SWSTATUS in (2,3,4) AND s.ChannelID IN (1,5) and s.ModeID in (1,2)) THEN                           
        INSERT VALUES                           
  (                          
  s.ClientID,                          
  s.ChannelID,                          
  s.ModeID,                          
  s.TERMINALID,                          
  s.ReferenceNumber,                          
  s.CARDNUMBER,                         
  s.CardType,                          
  s.TxnsValueDateTime,                          
  s.TxnsDateTime,                          
  s.TxnsAmount,                          
  s.ActualTxnsAmount,                          
  s.GLStatus,                          
  s.EJStatus,                          
  s.NWStatus,                          
  s.SWStatus,                     
  s.ReconType,                          
  s.CustAccountNo,                          
  s.ATMAccountNo,                          
  ''OK'',                          
  s.TxnsType,                          
  s.TxnsSubType,                          
  s.TxnsEntryType,                          
  null,                          
  0,                          
  null,                          
  null,                          
  null,                          
  null,                          
  0,                          
  null,                          
  ''' + @user +''',                          
  GETDATE(),                          
  null,                          
  null);'                          
)                          
--------------------------------------------------------------------------Delete Condition from Temp Table-----------------------------------------------------------------------------------------------------------------                           
DELETE FROM #TMPUnmatchedTxnsFinal where                           
 ModeID = 1 AND ChannelID = 1 AND GLSTATUS = 1 AND EJSTATUS = 1 AND SWSTATUS = 1 OR                            
 ModeID = 1 AND ChannelID = 1 AND GLSTATUS in (2,3) AND EJSTATUS in (2,3) AND SWSTATUS in (2,3,4)  OR                            
 ModeID = 1 AND ChannelID = 1 AND GLSTATUS = 4 AND EJSTATUS = 2 AND SWSTATUS = 4                          
                          
DELETE FROM #TMPUnmatchedTxnsFinal where                           
 ModeID = 1 AND ChannelID = 5 AND GLSTATUS = 1  AND SWSTATUS = 1 OR                            
 ModeID = 1 AND ChannelID = 5 AND GLSTATUS in (2,3)  AND SWSTATUS in (2,3)  OR                            
 ModeID = 1 AND ChannelID = 5 AND GLSTATUS = 4  AND SWSTATUS = 4                          
                          
DELETE FROM #TMPUnmatchedTxnsFinal where                           
 ModeID = 2 AND ChannelID = 1 AND GLSTATUS = 1 AND EJSTATUS = 1 AND NWSTATUS = 1 AND SWSTATUS = 1 OR                            
 ModeID = 2 AND ChannelID = 1 AND GLSTATUS in (2,3) AND EJSTATUS in (2,3) AND NWSTATUS in (2,3) AND SWSTATUS in (2,3,4)  OR                            
 ModeID = 2 AND ChannelID = 1 AND GLSTATUS in (3,4) AND EJSTATUS = 2 AND NWSTATUS = 4 AND SWSTATUS = 4                          
                          
DELETE FROM #TMPUnmatchedTxnsFinal where                           
 ModeID = 2 AND ChannelID = 5 AND GLSTATUS = 1 AND NWSTATUS = 1 AND SWSTATUS = 1 OR                            
 ModeID = 2 AND ChannelID = 5 AND GLSTATUS in (2,3) AND NWSTATUS in (2,3) AND SWSTATUS in (2,3)  OR                            
 ModeID = 2 AND ChannelID = 5 AND GLSTATUS = 4 AND NWSTATUS = 4 AND SWSTATUS = 4                          
                          
----------------------------------------------------------------------------Update/Insert Unmatch Txns Process------------------------------------------------------------------------------------------------------------------                          
Exec (                           
                          
'MERGE INTO UnmatchedTxns AS t                          
    USING #TMPUnmatchedTxnsFinal AS s                              
        ON t.ClientID = s.ClientID AND '  + @MainJoin +                          
  ' and  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.ModeID in (1,2) and t.ClientID = ' + @ClientID + '                          
    WHEN MATCHED THEN                          
   UPDATE set                           
         t.CustAccountNo = s.CustAccountNo,                          
         t.TxnsParticulars = s.TransactionParticulars,                          
         t.ModifiedOn = GETDATE(),                          
         t.[ModifiedBy]=''' + @user +                          
 ''' WHEN NOT MATCHED THEN                           
        INSERT VALUES                           
  (s.ClientID,                          
   s.ChannelID,                          
   s.ModeID,                          
   s.TERMINALID,                          
   s.ReferenceNumber,                          
   s.CARDNUMBER,                          
   s.CardType,                          
   s.TxnsValueDateTime,                        
   s.TxnsDateTime,                          
   s.TxnsAmount,                          
   s.ActualTxnsAmount,                          
   s.GLStatus,                          
   s.EJStatus,                          
   s.NWStatus,                          
   s.SWStatus,                          
   s.ReconType,                          
   s.CustAccountNo,                          
   s.ATMAccountNo,                          
   s.DebitCredit,                          
   s.TxnsType,                          
   s.TxnsSubType,                          
   s.TxnsEntryType,                          
   null,                          
   0,                          
   null,                          
   null,          
   null,                          
   null,                          
   0,                          
   s.TransactionParticulars,                          
  ''' + @user + ''' ,                           
   GETDATE(),                          
   null,                          
   null);'                          
)                          
-------------------------------------------------------------------------------Update Successful Txn Data from Unmatched Txn Data---------------------------------------------------------------------------------------------------                          
                          
EXEC ( 'MERGE INTO SuccessfulTxns AS t                          
    USING UnmatchedTxns AS s                              
                          
     ON t.ClientID = s.ClientID AND ' + @SettleJoin +                          
     ' AND  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5)and s.ModeID in (1,2) and s.IsSettled = 1                       
       AND t.ClientID = ' + @ClientID + ' and s.ClientID = ' + @ClientID + '                          
       AND (s.GLSTATUS = 1 AND s.EJSTATUS in (1,10) AND s.NWStatus IN (1,10) and s.SWSTATUS = 1)                          
                          
      WHEN MATCHED THEN                          
        UPDATE set t.[ModifiedOn]=GETDATE(),                          
                   t.[ModifiedBy]= ''' + @user + '''                          
                          
   WHEN NOT MATCHED AND (s.GLSTATUS = 1 AND s.EJSTATUS in (1,10) AND s.NWStatus IN (1,10) and s.SWSTATUS  = 1 and s.IsSettled = 1 AND s.ChannelID IN (1,5) and s.ModeID in (1,2)) THEN                           
   INSERT VALUES                           
   (                          
     s.ClientID,                          
     s.ChannelID,                          
     s.ModeID,                          
     s.TERMINALID,                          
     s.ReferenceNumber,                          
     s.CARDNUMBER,                          
     s.CardType,                          
     s.TxnsValueDateTime,                          
     s.TxnsDateTime,                          
     s.TxnsAmount,                          
     s.ActualTxnsAmount,                          
     s.GLStatus,                          
     s.EJStatus,                          
     s.NWStatus,                          
     s.SWStatus,                          
     s.ReconType,                          
     s.CustAccountNo,                          
     s.ATMAccountNo,                          
     ''OK'',                          
     s.TxnsType,                          
     s.TxnsSubType,                          
     s.TxnsEntryType,                          
     s.TxnRemarks,                          
s.IsSettled,                          
     s.OnSettled,                          
     s.SettledRemarks,                          
     s.SettledBy,                          
     s.Aging,                          
     s.IsRemoved,                          
     s.TxnsParticulars,                          
     ''' + @user + ''',                          
     GETDATE(),                          
     null,                          
     null);'                          
    )                          
                          
EXEC('MERGE INTO ReversalTxns AS t                          
    USING UnmatchedTxns AS s                              
                          
        ON t.ClientID = s.ClientID AND ' + @SettleJoin +                          
   ' AND  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.IsSettled = 1  and t.ClientID = ' + @ClientID + ' and s.ClientID = ' + @ClientID + '                          
   AND ((s.GLSTATUS in (3,4) AND s.EJSTATUS  in (2,3,10) AND s.NWStatus IN (4,10) and s.SWSTATUS = 4 and s.ModeID in (1,2))                           
   OR (s.GLSTATUS = 5 and s.NWStatus = 5 and s.ModeID = 2)                          
   OR (s.GLSTATUS = 5 and s.SWStatus = 5 and s.ModeID = 1)                          
   )                           
                          
    WHEN MATCHED THEN                          
 UPDATE set  t.[ModifiedOn]=GETDATE(),                          
    t.[ModifiedBy]=''' + @user + '''                          
             
   WHEN NOT MATCHED AND (((s.GLSTATUS in (3,4) AND s.EJSTATUS in (2,3,10) AND s.NWStatus IN (4,10) and s.SWSTATUS = 4 and s.ModeID in (1,2) and s.IsSettled = 1)                           
         OR (s.GLSTATUS = 5 and s.NWStatus = 5 and s.ModeID = 2 and s.IsSettled = 1)                          
         OR (s.GLSTATUS = 5 and s.SWStatus = 5 and s.ModeID = 1 and s.IsSettled = 1)) AND s.ChannelID IN (1,5) and s.ModeID in (1,2)) THEN                           
        INSERT VALUES                           
  (                          
  s.ClientID,                          
  s.ChannelID,                          
  s.ModeID,                          
  s.TERMINALID,                          
  s.ReferenceNumber,                          
  s.CARDNUMBER,                          
  s.CardType,                          
  s.TxnsValueDateTime,                          
 s.TxnsDateTime,                          
  s.TxnsAmount,                          
  s.ActualTxnsAmount,                          
  s.GLStatus,                          
  s.EJStatus,                          
  s.NWStatus,                          
  s.SWStatus,                          
  s.ReconType,                          
  s.CustAccountNo,                          
  s.ATMAccountNo,                          
  ''OK'',                          
  s.TxnsType,                          
  s.TxnsSubType,                          
  s.TxnsEntryType,                          
  s.TxnRemarks,                          
  s.IsSettled,                          
  s.OnSettled,                          
  s.SettledRemarks,                          
  s.SettledBy,                          
  s.Aging,                          
  s.IsRemoved,                          
  s.TxnsParticulars,                          
  ''' + @user + ''',                          
  GETDATE(),                          
  null,                          
  null);'                          
)                          
                          
EXEC ( 'MERGE INTO UnsuccessfulTxns AS t                          
    USING UnmatchedTxns AS s                              
                          
        ON t.ClientID = s.ClientID AND ' + @SettleJoin +                          
   ' AND  s.TxnsSubType =''Withdrawal'' and s.TxnsEntryType = ''Auto'' and s.ChannelID IN (1,5) and s.ModeID in (1,2)                       
   and s.IsSettled = 1 and t.ClientID = ' + @ClientID + ' and s.ClientID = ' + @ClientID + '                          
   AND (s.GLSTATUS in (2,3) AND s.EJSTATUS in (2,3,10) and s.SWSTATUS in (2,3,4))                          
                          
    WHEN MATCHED THEN                          
 UPDATE set  t.[ModifiedOn]=GETDATE(),                          
    t.[ModifiedBy]= ''' + @user + '''                          
                          
   WHEN NOT MATCHED AND (s.GLSTATUS  in (2,3) AND s.EJSTATUS in (2,3,10) and s.SWSTATUS in (2,3,4) and s.IsSettled = 1 AND s.ChannelID IN (1,5) and s.ModeID in (1,2)) THEN                           
        INSERT VALUES                           
  (                          
  s.ClientID,                          
  s.ChannelID,                          
  s.ModeID,                          
  s.TERMINALID,                          
  s.ReferenceNumber,                          
  s.CARDNUMBER,                          
  s.CardType,                          
  s.TxnsValueDateTime,                          
  s.TxnsDateTime,                          
  s.TxnsAmount,                          
  s.ActualTxnsAmount,                          
  s.GLStatus,                          
  s.EJStatus,             
  s.NWStatus,                          
  s.SWStatus,                          
  s.ReconType,                          
  s.CustAccountNo,                          
  s.ATMAccountNo,                          
  ''OK'',                          
  s.TxnsType,                          
  s.TxnsSubType,                          
  s.TxnsEntryType,                          
  s.TxnRemarks,                          
  s.IsSettled,                          
  s.OnSettled,                          
  s.SettledRemarks,                          
  s.SettledBy,                          
  s.Aging,                          
  s.IsRemoved,                          
  s.TxnsParticulars,                          
  ''' + @user + ''',                          
  GETDATE(),                          
  null,                          
  null);'                          
)                          
-------------------------------------------------------------------------------------Force Settled Transactions------------------------------------------------------------------------------------------- -----                          
                
                          
if(@ForceSettledOnusCond is NOT NULL)                          
                          
begin                          
 SET @SQLOnus = 'SELECT c1.ClientID, c1.ChannelID, c1.ModeID, c1.TerminalId, c1.ReferenceNumber, c1.CardNumber, CardType, c1.TxnsValueDateTime, TxnsDateTime, c1.TxnsAmount, c1.ActualTxnsAmount,                      
 GLStatus, EJStatus, NWStatus, SWStatus, c1.ReconType, CustAccountNo, ATMAccountNo, DrCrType, TxnsType, c1.TxnsSubType, TxnsEntryType, ''ForceSettled ''+ c2.RuleType as TxnRemarks,                      
 1 as IsSettled, OnSettled, c2.SettlementType as SettledRemarks, SettledBy, Aging, c1.IsRemoved, TxnsParticulars, c1.CreatedBy, c1.CreatedOn, c1.ModifiedBy, c1.ModifiedOn                      
 into ##TempForceSettledTxnsOnus FROM UnmatchedTxns c1 RIGHT JOIN ForceSettlementRuleMaster c2                           
 on ltrim(rtrim(c1.ClientID)) = ltrim(rtrim(C2.ClientID)) and ltrim(rtrim(c1.ChannelID)) = ltrim(rtrim(C2.ChannelID))                          
 and c1.ModeID = c2.ModeID where cast(c1.TxnsValueDateTime as date) >= ''' + @FROMDATE1 + ''' and cast(c1.TxnsValueDateTime as date) < ''' + @TODATE1  + ''' and                          
 c1.ClientID  = ''' + @ClientID + ''' and c1.ChannelID IN (1,5) and c1.ModeId = 1  AND ' + @ForceSettledOnusCond                          
                          
--PRINT '@SQLOnus:- ' + @SQLOnus                          
                 
Execute sp_Executesql @SQLOnus                          
                          
INSERT INTO ForceSettledTxns                           
 SELECT DISTINCT  ClientID, ChannelID, ModeID, TerminalId, ReferenceNumber, CardNumber, CardType, TxnsValueDateTime, TxnsDateTime, TxnsAmount, ActualTxnsAmount, GLStatus, EJStatus, NWStatus,                       
 SWStatus, ReconType, CustAccountNo, ATMAccountNo, DrCrType, TxnsType, TxnsSubType, TxnsEntryType, TxnRemarks, IsSettled, getdate() as OnSettled, SettledRemarks, 'Application', Aging,                      
 IsRemoved, TxnsParticulars, CreatedBy, CreatedOn, @user, getdate(),Reason  from  ##TempForceSettledTxnsOnus                          
                          
delete c1 from UnmatchedTxns c1 INNER JOIN ##TempForceSettledTxnsOnus c2 on ltrim(rtrim(c1.TerminalID)) = ltrim(rtrim(C2.TerminalID))                       
and ltrim(rtrim(c1.ReferenceNumber)) = ltrim(rtrim(C2.ReferenceNumber))                          
and c1.TxnsValueDateTime = c2.TxnsValueDateTime and c1.TxnsAmount = c2.TxnsAmount                           
and c1.ReconType = c2.ReconType and c1.TxnsSubType =c2.TxnsSubType                          
                          
END                          
                 
if(@ForceSettledAcqCond is NOT NULL)                          
                          
BEGIN                          
 SET @SQLACQ = 'SELECT  c1.ClientID, c1.ChannelID, c1.ModeID, c1.TerminalId, c1.ReferenceNumber, c1.CardNumber, CardType, c1.TxnsValueDateTime, TxnsDateTime, c1.TxnsAmount, c1.ActualTxnsAmount,                       
 GLStatus, EJStatus, NWStatus, SWStatus, c1.ReconType, CustAccountNo, ATMAccountNo, DrCrType, TxnsType, c1.TxnsSubType, TxnsEntryType, ''ForceSettled ''+ c2.RuleType as TxnRemarks, 1 as IsSettled,                       
 OnSettled, c2.SettlementType as SettledRemarks, SettledBy, Aging, c1.IsRemoved, TxnsParticulars, c1.CreatedBy, c1.CreatedOn, c1.ModifiedBy, c1.ModifiedOn  into  ##TempForceSettledTxnsAcq                      
 FROM UnmatchedTxns  c1 RIGHT JOIN ForceSettlementRuleMaster c2                           
 on ltrim(rtrim(c1.ClientID)) = ltrim(rtrim(C2.ClientID)) and ltrim(rtrim(c1.ChannelID)) = ltrim(rtrim(C2.ChannelID))                          
 and c1.ModeID = c2.ModeID where cast(c1.TxnsValueDateTime as date) >= ''' + @FROMDATE1 + ''' and cast(c1.TxnsValueDateTime as date)  < ''' + @TODATE1  + '''                          
 and c1.ClientID = ''' + @ClientID + ''' and c1.ChannelID  IN (1,5) and c1.ModeId = 2 AND '  + @ForceSettledAcqCond                           
                            
--print @SQLACQ                          
                          
Execute sp_Executesql @SQLACQ                          
                          
INSERT INTO ForceSettledTxns                           
  SELECT DISTINCT  ClientID, ChannelID, ModeID, TerminalId, ReferenceNumber, CardNumber, CardType, TxnsValueDateTime, TxnsDateTime, TxnsAmount, ActualTxnsAmount, GLStatus, EJStatus, NWStatus,                       
  SWStatus, ReconType, CustAccountNo, ATMAccountNo, DrCrType, TxnsType, TxnsSubType, TxnsEntryType, TxnRemarks, IsSettled, getdate() as OnSettled, SettledRemarks, 'Application', Aging, IsRemoved,                       
  TxnsParticulars, CreatedBy, CreatedOn, @user, getdate(),Reason from   ##TempForceSettledTxnsAcq                          
                          
delete c1 from UnmatchedTxns c1 INNER JOIN  ##TempForceSettledTxnsAcq c3 on ltrim(rtrim(c1.TerminalID)) = ltrim(rtrim(c3.TerminalID))                      
and ltrim(rtrim(c1.ReferenceNumber)) = ltrim(rtrim(c3.ReferenceNumber))                          
and c1.TxnsValueDateTime = c3.TxnsValueDateTime and c1.TxnsAmount = c3.TxnsAmount                           
and c1.ReconType = c3.ReconType and c1.TxnsSubType =c3.TxnsSubType                          
                           
END                            
-----------------------------------------------------------------------------Delete Condition from UnmatchedTxn Table-------------------------------------------------------------------------------------------                           
                          
DELETE FROM UnmatchedTxns where                           
ClientId = @ClientID AND ChannelID IN (1,5) AND  ModeID = 1 AND GLSTATUS = 1 AND EJSTATUS = 1 AND SWSTATUS = 1 OR                            
ClientId = @ClientID AND ChannelID IN (1,5) AND  ModeID = 1 AND GLSTATUS = 4 AND EJSTATUS in (2,3) AND SWSTATUS = 4 OR                          
ClientId = @ClientID AND ChannelID IN (1,5) AND  ModeID = 1 AND GLSTATUS in (2,3) AND EJSTATUS in (2,3) AND SWSTATUS in (2,3,4) OR                          
ClientId = @ClientID AND ChannelID IN (1,5) AND  ModeID = 1 AND GLSTATUS = 5  AND SWSTATUS = 5                          
                                    
DELETE FROM UnmatchedTxns where                             
ClientId = @ClientID AND ChannelID IN (1,5) AND  ModeID = 2 AND GLSTATUS = 1 AND EJSTATUS = 1 AND NWSTATUS = 1 AND SWSTATUS = 1 OR                            
ClientId = @ClientID AND ChannelID IN (1,5) AND  ModeID = 2 AND GLSTATUS in (3,4) AND EJSTATUS in (2,3,10) AND NWSTATUS in (4,10) AND SWSTATUS = 4  OR                            
ClientId = @ClientID AND ChannelID IN (1,5) AND  ModeID = 2 AND GLSTATUS in (2,3) AND EJSTATUS in (2,3) AND NWSTATUS in (2,3) AND SWSTATUS in (2,3,4) OR                           
ClientId = @ClientID AND ChannelID IN (1,5) AND  ModeID = 2 AND GLSTATUS = 5 AND NWSTATUS = 5                          
                          
END                       
SET @output= 'Onus Acquirer Successful | '                          
PRINT @output                          
END TRY                   
                          
BEGIN CATCH                            
DECLARE @ErrorNumber INT = ERROR_NUMBER();                          
DECLARE @ErrorLine INT = ERROR_LINE();                          
DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();                          
DECLARE @ErrorSeverity INT = ERROR_SEVERITY();                          
DECLARE @ErrorState INT = ERROR_STATE();                          
PRINT @ErrorNumber                          
PRINT @ErrorLine                          
PRINT @ErrorMessage                          
PRINT @ErrorSeverity                          
PRINT @ErrorState                          
SET @output= 'Onus Acquirer Error | '                            
PRINT @output                          
END CATCH;                          
                          
END ";
            #endregion Query

            return Query;
        }

        public static List<ReconRawTableFields> ColumnsExtract(dynamic Data)
        {
            DataTable dt = new DataTable();
            string inputString = Data.ValData;
            string TableName = Data.ValTableName;
            string TableNo = Data.ValTableNo;
            string ReconType = Data.ValReconTypeID;

            inputString = Regex.Replace(inputString, @"\bselect\b", "", RegexOptions.IgnoreCase).Trim();

            string[] inputSplit = Regex.Split(inputString, @"\bfrom\b", RegexOptions.IgnoreCase);

            //string TableName = inputSplit[1].Split(new[] { " " },StringSplitOptions.RemoveEmptyEntries)[0].Trim();


            // Extract column names from the first part of the input string
            string[][] splitInput = inputSplit[0]
                                                .Split(',')
                                                .Select(s =>
                                                {
                                                    int index = s.ToLower().LastIndexOf(" as ");
                                                    if (index < 0)
                                                    {
                                                        return new string[] { s.Trim(), s.Trim() };
                                                    }
                                                    else
                                                    {
                                                        return new string[] { s.Substring(0, index).Trim(), s.Substring(index + 4).Trim().Replace("[", "").Replace("]", "") };
                                                    }
                                                })
                                                .ToArray();


            // Initialize a table with column names and values
            Dictionary<string, string> table = new Dictionary<string, string>();
            List<ReconRawTableFields> TableDetails = new List<ReconRawTableFields>();
            int k = 0;
            foreach (string[] pair in splitInput)
            {
                k++;
                string columnName = pair[0].Trim();
                string columnAlias = pair[1].Trim();
                ReconRawTableFields fields = new ReconRawTableFields
                {
                    TableNo = TableNo,
                    TableName = TableName,
                    ColumnID = (k).ToString(),
                    AliasColumn = columnAlias,
                    ColumnValue = columnName,
                    ReconType = ReconType
                };
                TableDetails.Add(fields);
            }



            return TableDetails;
        }
        public static string GenerateCaseWhen(string columnName, List<string> aliases)
        {
            string caseWhen = "CASE";
            foreach (string alias in aliases)
            {
                caseWhen += $"\n WHEN {alias}.{columnName} IS NOT NULL THEN {alias}.{columnName}";
            }
            caseWhen += $" END AS {columnName} \n";
            return caseWhen;
        }

        public static string GenerateTempJOIN(string columnName, List<string> aliases)
        {
            string caseWhen = "CASE";
            foreach (string alias in aliases)
            {
                caseWhen += $"\n WHEN {alias}.{columnName} IS NOT NULL THEN {alias}.{columnName}";
            }
            caseWhen += $" END AS {columnName} \n";
            return caseWhen;
        }

        public static string TempUnmatched(List<string> aliases, string RawQuery, List<List<ReconRawTableFields>> TablesList)
        {
            string sql = string.Empty;
            string val = TablesList[0][0].ReconType;
            string ReconType = string.Empty;
            switch (val)
            {
                case "2": ReconType = "2-WAY"; break;
                case "3": ReconType = "3-WAY"; break;
                case "4": ReconType = "4-WAY"; break;
                case "5": ReconType = "5-WAY"; break;
                default:
                    ReconType = ""; break;

            }
            sql += $@"
     
 
exec                           
(                           
                       
  'Insert into #TMPUnmatchedTxns                          
    Select    
";

            string[] arr = { "ClientID", "ChannelID", "ModeID", "TerminalID", "ReferenceNumber", "CardNumber"
                    , "CardType", "TxnsDateTime1", "TxnsAmount", "ActualTxnsAmount", "ACCOUNTNO", "ATMAccountNo"
                    , "TxnsType", "TxnsSubType", "TxnsEntryType"
            };
            //aliases = new List<string> { "EJ", "SW", "NW", "GL" };
            foreach (List<ReconRawTableFields> Table in TablesList)
            {

                foreach (var Col in Table)
                {
                    string columnName = Col.AliasColumn;
                    if (Array.IndexOf(arr, columnName) != -1)
                    {
                        sql += GenerateCaseWhen(columnName, aliases) + ',';
                    }
                }
                break;
            }
            sql += "\n" + ReconType + @"  AS ReconType ";
            string fromBlock = string.Empty;
            int Count = 0;
            foreach (List<ReconRawTableFields> Table in TablesList)
            {

                if (fromBlock == "")
                {
                    fromBlock = "from \n";
                }
                else
                {
                    fromBlock += " FULL OUTER JOIN ";

                }
                string TableN = Table[0].TableName;
                string Alias = string.Empty;
                if (TableN.ToLower().Contains("ejdata")) Alias = "EJ ";
                if (TableN.ToLower().Contains("switchdata")) Alias = "SW ";
                if (TableN.ToLower().Contains("gldata")) Alias = "GL ";
                fromBlock += $@" ( select * from #{TableN} ){Alias}";
                if (Count > 0)
                {
                    fromBlock += $" ON ' + @JoinCond{Count.ToString()} \n";
                    if (Count < TablesList.Count - 1) fromBlock += $" + '";
                }
                Count++;
            }
            sql += fromBlock + ")";






            string Query = sql;

            return Query;
        }

        public static string ReconQueryConstructorKS(ReconQueryFields addReconQueryFields, ReconQueryBlocks ReconQueryBlocks, List<List<ReconRawTableFields>> TablesList)
        {

            #region TempUnmatched Generation
            List<string> aliases = new List<string> { };
            string TempTablesBlock = string.Empty;
            string Block = string.Empty;
            if (ReconQueryBlocks.RawTable1 != null)
            {
                Block = ReconQueryBlocks.RawTable1;
                if (Block.ToUpper().Contains("SW")) aliases.Add("SW");
                if (Block.ToUpper().Contains("GL")) aliases.Add("GL");
                if (Block.ToUpper().Contains("EJ")) aliases.Add("EJ");
                if (!Block.ToUpper().Contains("GL") && !Block.ToUpper().Contains("SW") && !Block.ToUpper().Contains("EJ")) aliases.Add("T1");

                TempTablesBlock += $@"
                    {Block}
                ";
            }
            if (ReconQueryBlocks.RawTable2 != null)
            {
                Block = ReconQueryBlocks.RawTable2;
                if (Block.ToUpper().Contains("SW")) aliases.Add("SW");
                if (Block.ToUpper().Contains("GL")) aliases.Add("GL");
                if (Block.ToUpper().Contains("EJ")) aliases.Add("EJ");
                if (!Block.ToUpper().Contains("GL") && !Block.ToUpper().Contains("SW") && !Block.ToUpper().Contains("EJ")) aliases.Add("T2");
                TempTablesBlock += $@"
                    {Block}
                ";
            }
            if (ReconQueryBlocks.RawTable3 != null)
            {
                Block = ReconQueryBlocks.RawTable3;
                if (Block.ToUpper().Contains("SW")) aliases.Add("SW");
                if (Block.ToUpper().Contains("GL")) aliases.Add("GL");
                if (Block.ToUpper().Contains("EJ")) aliases.Add("EJ");
                if (!Block.ToUpper().Contains("GL") && !Block.ToUpper().Contains("SW") && !Block.ToUpper().Contains("EJ")) aliases.Add("T3");
                TempTablesBlock += $@"
                    {Block}
                ";
            }
            if (ReconQueryBlocks.RawTable4 != null)
            {
                Block = ReconQueryBlocks.RawTable4;
                if (Block.ToUpper().Contains("SW")) aliases.Add("SW");
                if (Block.ToUpper().Contains("GL")) aliases.Add("GL");
                if (Block.ToUpper().Contains("EJ")) aliases.Add("EJ");
                if (!Block.ToUpper().Contains("GL") && !Block.ToUpper().Contains("SW") && !Block.ToUpper().Contains("EJ")) aliases.Add("T4");
                TempTablesBlock += $@"
                    {Block}
                ";
            }
            if (ReconQueryBlocks.RawTable5 != null)
            {
                Block = ReconQueryBlocks.RawTable5;
                if (Block.ToUpper().Contains("SW")) aliases.Add("SW");
                if (Block.ToUpper().Contains("GL")) aliases.Add("GL");
                if (Block.ToUpper().Contains("EJ")) aliases.Add("EJ");
                if (!Block.ToUpper().Contains("GL") && !Block.ToUpper().Contains("SW") && !Block.ToUpper().Contains("EJ")) aliases.Add("T5");
                TempTablesBlock += $@"
                    {Block}
                ";
            }



            TempTablesBlock += TempUnmatched(aliases, TempTablesBlock, TablesList);

            #endregion TempUnmatched Generation

            object Fields = new
            {
                ChannelNameKS = addReconQueryFields.ChannelName,
                ModeNameKS = addReconQueryFields.ModeName
                ,
                TempTablesBlockKS = TempTablesBlock
            };

            string Query = BaseQuery(Fields);

            WriteSQL(Query);

            return Query;
        }
        public static string WriteSQL(string sqlQueries)
        {
            string outputFilePath = @"D:\output.sql";

            // Format the SQL queries
            //sqlQueries = FormatSQLQueries(sqlQueries);

            // Write the formatted SQL queries to the output file
            File.WriteAllText(outputFilePath, sqlQueries);

            return outputFilePath;
        }

        public static string WrapperBlock(string sqlQuery, string TableName)
        {
            string WrapperBlock = string.Empty;
            if (!sqlQuery.ToLower().Contains("gldata") && !sqlQuery.ToLower().Contains("switchdata"))
            {

                WrapperBlock = $@"
select  * into #{TableName} from                          
(                          
{sqlQuery}                         
and TxnsAmount <> '0.00'
){TableName}  ";


            }


            return WrapperBlock;
        }
        public static string ReversalMergeBlock(string sqlQuery)
        {
            string MergedBlock = string.Empty;
            string QReversal = string.Empty;
            if (sqlQuery.ToLower().Contains("from gldata"))
            {
                QReversal = sqlQuery.Replace("WHERE", "WHERE REVERSALFLAG = 1 AND ");

                sqlQuery = $@"
select  * into #GLNonReversal from                          
(                          
{sqlQuery}                         
and TxnsAmount <> '0.00'
)GLNonReversal  ";

                QReversal = $@"
select  * into #GLReversal from                          
(                          
{QReversal}                       
)GLReversal  
";
                MergedBlock = $@"
{sqlQuery}
{QReversal}
select case when gls.ClientID is not null then gls.ClientID  else glr.ClientID end ClientID ,                          
       case when gls.ChannelID is not null then gls.ChannelID  else glr.ChannelID end ChannelID ,                          
       case when gls.ModeID is not null then gls.ModeID  else glr.ModeID end ModeID ,                          
       case when gls.TerminalId is not null then gls.TerminalId  else glr.TerminalId end TerminalId ,                          
       case when gls.TxnsDateTime is not null then gls.TxnsDateTime  else glr.TxnsDateTime END as TxnsDateTime,                          
       case when gls.TxnsDateTime1 is not null then gls.TxnsDateTime1  else glr.TxnsDateTime1  END as TxnsDateTime1,                          
       case when gls.ReferenceNumber is not null then gls.ReferenceNumber  else glr.ReferenceNumber end ReferenceNumber ,              
       case when gls.CardNumber is not null then gls.CardNumber  else glr.CardNumber end CardNumber ,                          
       case when gls.CustAccountNo is not null then gls.CustAccountNo  else glr.CustAccountNo end ACCOUNTNO ,                          
       case when gls.CardType is not null then gls.CardType  else glr.CardType end CardType ,                          
       case when gls.ATMAccountNo is not null then gls.ATMAccountNo  else glr.ATMAccountNo end ATMAccountNo ,                          
       case when gls.TxnsType is not null then gls.TxnsType  else glr.TxnsType end TxnsType ,                          
       case when gls.TxnsSubType is not null then gls.TxnsSubType  else glr.TxnsSubType end TxnsSubType ,                          
       case when gls.TxnsEntryType is not null then gls.TxnsEntryType  else glr.TxnsEntryType end TxnsEntryType ,                          
       case when gls.TxnsAmount  = glr.TxnsAmount then gls.TxnsAmount                           
            when gls.TxnsAmount is not null and glr.TxnsAmount is null then gls.TxnsAmount                           
            when gls.TxnsAmount is null and glr.TxnsAmount is not null then glr.TxnsAmount                           
            when gls.TxnsAmount <> glr.TxnsAmount then gls.TxnsAmount  else 0                           
            end TxnsAmount,                          
       case when gls.TxnsAmount  = glr.TxnsAmount then gls.TxnsAmount                           
            when gls.TxnsAmount is not null and glr.TxnsAmount is null then gls.TxnsAmount                           
            when gls.TxnsAmount is null and glr.TxnsAmount is not null then glr.TxnsAmount                           
            when gls.TxnsAmount <> glr.TxnsAmount then abs(gls.TxnsAmount - glr.TxnsAmount) else 0                           
            end ActualTxnsAmount,                          
       case when gls.TxnsAmount  = glr.TxnsAmount and gls.ResponseCode = '00' and glr.ResponseCode = '00' and glr.RevEntryLeg = 2 then 4                           
            when gls.TxnsAmount is not null and glr.TxnsAmount is null and gls.ResponseCode = '00' then 1                           
            when gls.TxnsAmount is null and glr.TxnsAmount is not null  and glr.ResponseCode = '00' and glr.RevEntryLeg = 1 then 4                          
            when gls.TxnsAmount is null and glr.TxnsAmount is not null  and glr.ResponseCode = '00' and glr.RevEntryLeg = 2 then 9                          
            when gls.TxnsAmount <> glr.TxnsAmount and gls.ResponseCode = '00' and glr.ResponseCode = '00' and glr.RevEntryLeg = 2 then 5 else 2                           
            end GLStatus                          
into #GLData                          
from #GLNonReversal gls                           
full outer join #GLReversal glr                           
on gls.ReferenceNumber = glr.ReferenceNumber                            
and gls.TerminalId = glr.TerminalId                       
and gls.TxnsDateTime = glr.TxnsDateTime 
";

            }

            if (sqlQuery.ToLower().Contains("from switch"))
            {
                QReversal = sqlQuery.Replace("WHERE", "WHERE REVERSALFLAG = 1 AND ");

                sqlQuery = $@"
select  * into #SWNonReversal from                          
(                          
{sqlQuery}                         
and TxnsAmount <> '0.00'
)SWNonReversal  ";

                QReversal = $@"
select  * into #SWReversal from                          
(                          
{QReversal}                       
)SWReversal  
";
                MergedBlock = $@"
{sqlQuery}
{QReversal}
                              
select case when Sws.ClientID is not null then Sws.ClientID  else SWr.ClientID end ClientID ,                          
       case when Sws.ChannelID is not null then Sws.ChannelID  else SWr.ChannelID end ChannelID ,                          
       case when Sws.ModeID is not null then Sws.ModeID  else SWr.ModeID end ModeID ,                          
       case when Sws.TerminalId is not null then Sws.TerminalId  else SWr.TerminalId end TerminalId ,                          
       case when Sws.TxnsDateTime is not null then Sws.TxnsDateTime else SWr.TxnsDateTime END as TxnsDateTime,                          
       case when Sws.TxnsDateTime1 is not null then Sws.TxnsDateTime1 else SWr.TxnsDateTime1 END as TxnsDateTime1,                          
       case when Sws.ReferenceNumber is not null then Sws.ReferenceNumber  else SWr.ReferenceNumber end ReferenceNumber ,                          
       case when Sws.CardNumber is not null then Sws.CardNumber  else SWr.CardNumber end CardNumber ,                          
       case when Sws.CustAccountNo is not null then Sws.CustAccountNo  else SWr.CustAccountNo end ACCOUNTNO ,                          
       case when Sws.CardType is not null then Sws.CardType  else SWr.CardType end CardType ,                          
       case when Sws.ATMAccountNo is not null then Sws.ATMAccountNo  else SWr.ATMAccountNo end ATMAccountNo ,                          
       case when Sws.TxnsType is not null then Sws.TxnsType  else SWr.TxnsType end TxnsType ,                          
       case when Sws.TxnsSubType is not null then Sws.TxnsSubType  else SWr.TxnsSubType end TxnsSubType ,                          
       case when Sws.TxnsEntryType is not null then Sws.TxnsEntryType  else SWr.TxnsEntryType end TxnsEntryType ,                          
       case when Sws.TxnsAmount  = SWr.TxnsAmount then Sws.TxnsAmount                           
            when Sws.TxnsAmount is not null and SWr.TxnsAmount is null then Sws.TxnsAmount                           
            when Sws.TxnsAmount is null and SWr.TxnsAmount is not null then SWr.TxnsAmount                           
            when Sws.TxnsAmount <> SWr.TxnsAmount then abs(Sws.TxnsAmount - SWr.TxnsAmount) else 0                           
            end ActualTxnsAmount,                          
       case when Sws.TxnsAmount  = SWr.TxnsAmount then Sws.TxnsAmount                           
            when Sws.TxnsAmount is not null and SWr.TxnsAmount is null then Sws.TxnsAmount                           
            when Sws.TxnsAmount is null and SWr.TxnsAmount is not null then SWr.TxnsAmount                           
            when Sws.TxnsAmount <> SWr.TxnsAmount then Sws.TxnsAmount else 0                           
            end TxnsAmount,                          
       case when Sws.TxnsAmount = SWr.TxnsAmount and Sws.ResponseCode = '00' and Swr.ResponseCode = '00' and SWr.RevEntryLeg = 2  then 4                           
            when Sws.TxnsAmount is not null and SWr.TxnsAmount is null and Sws.ResponseCode = '00' then 1                           
          when Sws.TxnsAmount is null and SWr.TxnsAmount is not null  and SWr.ResponseCode = '00' and SWr.RevEntryLeg = 1 then 4                          
            when Sws.TxnsAmount is null and SWr.TxnsAmount is not null and SWr.ResponseCode = '00' and SWr.RevEntryLeg = 2 then 9                          
            when Sws.TxnsAmount <> SWr.TxnsAmount and Sws.ResponseCode = '00' and Swr.ResponseCode = '00' and SWr.RevEntryLeg = 2 then 5                           
            else 2                           
            end SWStatus                          
 into #SwitchData                          
from #SWNonReversal Sws full outer join #SWReversal SWr on Sws.ReferenceNumber = SWr.ReferenceNumber                            
and Sws.TerminalId = SWr.TerminalId                           
and cast (Sws.TxnsDateTime as date) = cast (SWr.TxnsDateTime as date)  
";

            }


            return MergedBlock;
        }
        public static string FormatSQLQuery(string sqlQuery)
        {
            // Remove leading and trailing white space
            sqlQuery = sqlQuery.Trim();

            // Remove extra spaces between words or characters
            sqlQuery = Regex.Replace(sqlQuery, @"\s+", " ");

            // Add a new line after each keyword
            string[] keywords = { "SELECT", "FROM", "WHERE", "GROUP BY", "HAVING", "ORDER BY", "LIMIT", "END", "CASE WHEN" };
            foreach (string keyword in keywords)
            {
                string pattern = $@"\b{keyword}\b";
                if (keyword.ToUpper().Contains("CASE WHEN"))
                {
                    pattern = $@"{keyword}\b";
                }
                sqlQuery = Regex.Replace(sqlQuery, pattern, $"\n{keyword}", RegexOptions.IgnoreCase);
            }

            // Split the query by commas
            string[] words = sqlQuery.Split(',');

            // Add a new line after every 10 words following the SELECT keyword
            bool shouldAddNewline = false;
            int wordCount = 0;
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Contains("SELECT", StringComparison.OrdinalIgnoreCase))
                {
                    shouldAddNewline = true;
                    wordCount = 0;
                }

                if (shouldAddNewline && !string.IsNullOrWhiteSpace(words[i]))
                {
                    wordCount++;
                    if (wordCount > 5)
                    {
                        words[i] = $"\n{words[i]}";
                        wordCount = 0;
                    }
                }
            }

            // Join the words back together with commas
            sqlQuery = string.Join(",", words);

            // Indent each line by four spaces
            sqlQuery = Regex.Replace(sqlQuery, @"^(.*)$", "    $1", RegexOptions.Multiline);

            return sqlQuery;
        }
        public DataTable SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("TxnUID", typeof(string));
            _DataTable.Columns.Add("TxnType", typeof(string));
            _DataTable.Columns.Add("UID", typeof(string));
            _DataTable.Columns.Add("AdjDate", typeof(DateTime));
            _DataTable.Columns.Add("AdjType", typeof(string));
            _DataTable.Columns.Add("AcquirerBank", typeof(string));
            _DataTable.Columns.Add("IssuerBank", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("TxnDateTime", typeof(DateTime));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TerminalID", typeof(string));
            _DataTable.Columns.Add("CardNo", typeof(string));
            _DataTable.Columns.Add("ChargebackDate", typeof(DateTime));
            _DataTable.Columns.Add("ChargebackRemarks", typeof(string));
            _DataTable.Columns.Add("TxnAmount", typeof(decimal));
            _DataTable.Columns.Add("AdjAmount", typeof(decimal));
            _DataTable.Columns.Add("ACQFee", typeof(decimal));
            _DataTable.Columns.Add("ISSFee", typeof(decimal));
            _DataTable.Columns.Add("ISSFeeSW", typeof(decimal));
            //_DataTable.Columns.Add("AdjFee", typeof(decimal));
            _DataTable.Columns.Add("NPCIFee", typeof(decimal));
            _DataTable.Columns.Add("AcqFeeTax", typeof(decimal));
            _DataTable.Columns.Add("IssFeetax", typeof(decimal));
            _DataTable.Columns.Add("NPCITax", typeof(decimal));
            _DataTable.Columns.Add("AdjRef", typeof(string));
            _DataTable.Columns.Add("BankAdjRef", typeof(string));
            _DataTable.Columns.Add("AdjProof", typeof(string));
            _DataTable.Columns.Add("reasondesc", typeof(string));
            _DataTable.Columns.Add("PinCode", typeof(string));
            _DataTable.Columns.Add("TerminalLocation", typeof(string));
            _DataTable.Columns.Add("MultiDisputeGroup", typeof(string));
            _DataTable.Columns.Add("FCQM", typeof(string));
            _DataTable.Columns.Add("ADJSettlementdate", typeof(DateTime));
            _DataTable.Columns.Add("CustomerPenalty", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("TATExpDate", typeof(DateTime));
            _DataTable.Columns.Add("ACQSTLAmount", typeof(string));
            _DataTable.Columns.Add("AcqCC", typeof(string));
            _DataTable.Columns.Add("PanEntryMode", typeof(string));
            _DataTable.Columns.Add("ServiceCode", typeof(string));
            _DataTable.Columns.Add("CardDataInputCapability", typeof(string));
            _DataTable.Columns.Add("MCCCode", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));


            InsertCount = 0;
            TotalCount = 0;
            try
            {
                string Txnuid = string.Empty;
                string Uid = string.Empty;
                string TxnType = string.Empty;
                DateTime AdjDate;
                string AdjType = string.Empty;
                string AcquirerBank = string.Empty;
                string IssuerBank = string.Empty;
                string ResponseCode = string.Empty;
                DateTime TxnDateTime;
                string ReferenceNumber = string.Empty;
                string TerminalID = string.Empty;
                string CardNo = string.Empty;
                DateTime? ChargebackDate = null;
                string ChargebackRemarks = string.Empty;
                decimal TxnAmount = 0;
                decimal AdjAmount = 0;
                decimal ACQFee = 0;
                decimal ISSFee = 0;
                decimal ISSFeeSW = 0;
                //decimal AdjFee = 0;
                decimal NPCIFee = 0;
                decimal AcqFeeTax = 0;
                decimal IssFeetax = 0;
                decimal NPCITax = 0;
                string AdjRef = string.Empty;
                string BankAdjRef = string.Empty;
                string AdjProof = string.Empty;
                string reasondesc = string.Empty;
                string PinCode = string.Empty;
                string TermLoc = string.Empty;
                string MultDisGroup = string.Empty;
                string FCQM = string.Empty;
                DateTime? ADJSettlementdate = null;
                string CustPenalty = string.Empty;
                string Cycle = string.Empty;
                DateTime? TatExpDate = null;
                string ACQSTLAmt = string.Empty;
                string AcqCC = string.Empty;
                string PEMode = string.Empty;
                string ServiceCode = string.Empty;
                string CarddataInputCap = string.Empty;
                string MCCCode = string.Empty;
                string CreatedBy = string.Empty;
                //DateTime CreatedOn;
                string DtTime = string.Empty;
                string Dt = string.Empty;
                string DtAdj = string.Empty;
                string DtSettle = string.Empty;
                string ModifiedBy = string.Empty;
                string d1 = string.Empty;
                string d2 = string.Empty;
                string date1 = string.Empty;
                //DateTime ModifiedOn;
                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

                //OleDbConnection objConn = null;
                //DataTable dtexcelsheetname = null;
                //String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                //"Data Source=" + path + ";Extended Properties=Excel 8.0;";
                //string extension = Path.GetExtension(path);
                //switch (extension.ToLower())
                //{
                //    case ".xls": //Excel 97-03
                //        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";";
                //        break;
                //    case ".xlsx": //Excel 07 or higher
                //        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                //        break;
                //}
                //objConn = new OleDbConnection(connString);
                //objConn.Open();
                //dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                //String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                //int j = 0;
                //foreach (DataRow row in dtexcelsheetname.Rows)
                //{
                //    excelSheets[j] = row["TABLE_NAME"].ToString();
                //    j++;
                //}

                //string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                ////string sht = dr[2].ToString().Replace("'", "");

                //OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                //OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                //DataTable dtfillsheet1 = new DataTable();
                //da.Fill(dtfillsheet1); 
                //objConn.Close();

                string conString = this._configuration.GetConnectionString("ExcelConString");

                conString = string.Format(conString, path);

                DataTable dtexcelsheetname = null;
                //int j = 0;
                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }



                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {
                    DataTable dtfillsheet1 = new DataTable();

                    using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                    {
                        using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                        {
                            using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                            {
                                //Read Data from First Sheet.
                                cmdExcelSheet.Connection = connExcelSheet;
                                connExcelSheet.Open();
                                cmdExcelSheet.CommandText = "SELECT * From [" + dtexcelsheetname.Rows[0]["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                odaExcelSheet.SelectCommand = cmdExcelSheet;
                                odaExcelSheet.Fill(dtfillsheet1);
                                connExcelSheet.Close();
                            }
                        }
                    }

                    TotalCount = dtfillsheet1.Rows.Count;

                    if (dtfillsheet1 != null && dtfillsheet1.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                        {
                            try
                            {
                                string txnid = dtfillsheet1.Rows[i][0].ToString();
                                Txnuid = txnid.Replace("'", "");
                                TxnType = dtfillsheet1.Rows[i][1].ToString();
                                string uid = dtfillsheet1.Rows[i][2].ToString();
                                Uid = uid.Replace("'", "");
                                string adjdate = dtfillsheet1.Rows[i][3].ToString();
                                AdjDate = DateTime.ParseExact(adjdate.ToString(), "dd-MM-yyyy", null);
                                AdjType = dtfillsheet1.Rows[i][4].ToString();
                                AcquirerBank = dtfillsheet1.Rows[i][5].ToString();
                                IssuerBank = dtfillsheet1.Rows[i][6].ToString();
                                string Resp = dtfillsheet1.Rows[i][7].ToString();
                                ResponseCode = Resp.Replace("'", "");
                                d1 = dtfillsheet1.Rows[i][8].ToString();
                                d2 = dtfillsheet1.Rows[i][9].ToString();
                                date1 = d1 + " " + d2;
                                TxnDateTime = DateTime.ParseExact(date1.ToString(), "dd-MM-yyyy HH:mm:ss", null);
                                string Refno = dtfillsheet1.Rows[i][10].ToString();
                                ReferenceNumber = Refno.Replace("'", "");
                                TerminalID = dtfillsheet1.Rows[i][11].ToString();
                                string CardNum = dtfillsheet1.Rows[i][12].ToString();
                                CardNo = CardNum.Replace("'", "");
                                string ChargebackDate1 = dtfillsheet1.Rows[i][13].ToString();
                                if (ChargebackDate1.Contains("--"))
                                {
                                    ChargebackDate = null;
                                }
                                else
                                {
                                    ChargebackDate = dtfillsheet1.Rows[i][13].ToString().Contains('-') == true ? (DateTime.ParseExact(dtfillsheet1.Rows[i][13].ToString(), "dd-MM-yyyy", null)) : ChargebackDate;
                                }

                                string chbref = dtfillsheet1.Rows[i][14].ToString();
                                ChargebackRemarks = chbref.Replace("'", "");
                                TxnAmount = Convert.ToDecimal(dtfillsheet1.Rows[i][15].ToString());
                                AdjAmount = Convert.ToDecimal(dtfillsheet1.Rows[i][16].ToString());
                                ACQFee = Convert.ToDecimal(dtfillsheet1.Rows[i][17].ToString());
                                ISSFee = Convert.ToDecimal(dtfillsheet1.Rows[i][18].ToString());
                                ISSFeeSW = Convert.ToDecimal(dtfillsheet1.Rows[i][19].ToString());
                                NPCIFee = Convert.ToDecimal(dtfillsheet1.Rows[i][20].ToString());
                                AcqFeeTax = Convert.ToDecimal(dtfillsheet1.Rows[i][21].ToString());
                                IssFeetax = Convert.ToDecimal(dtfillsheet1.Rows[i][22].ToString());
                                NPCITax = Convert.ToDecimal(dtfillsheet1.Rows[i][23].ToString());
                                AdjRef = dtfillsheet1.Rows[i][24].ToString();
                                BankAdjRef = dtfillsheet1.Rows[i][25].ToString();
                                AdjProof = dtfillsheet1.Rows[i][26].ToString();
                                reasondesc = dtfillsheet1.Rows[i][27].ToString();
                                PinCode = dtfillsheet1.Rows[i][28].ToString();
                                string ATMLoc = dtfillsheet1.Rows[i][29].ToString();
                                TermLoc = ATMLoc.Replace("'", "");
                                MultDisGroup = dtfillsheet1.Rows[i][30].ToString();
                                FCQM = dtfillsheet1.Rows[i][31].ToString();
                                ADJSettlementdate = dtfillsheet1.Rows[i][32].ToString().Contains('-') == true ? (DateTime.ParseExact(dtfillsheet1.Rows[i][32].ToString(), "dd-MM-yyyy", null)) : ADJSettlementdate;
                                CustPenalty = dtfillsheet1.Rows[i][33].ToString();
                                Cycle = dtfillsheet1.Rows[i][35].ToString();
                                TatExpDate = dtfillsheet1.Rows[i][36].ToString().Contains('-') == true ? (DateTime.ParseExact(dtfillsheet1.Rows[i][36].ToString(), "dd-MM-yyyy", null)) : TatExpDate;
                                ACQSTLAmt = dtfillsheet1.Rows[i][37].ToString();
                                AcqCC = dtfillsheet1.Rows[i][38].ToString();
                                PEMode = dtfillsheet1.Rows[i][39].ToString();
                                ServiceCode = dtfillsheet1.Rows[i][40].ToString();
                                CarddataInputCap = dtfillsheet1.Rows[i][41].ToString();
                                MCCCode = dtfillsheet1.Rows[i][42].ToString();



                                _DataTable.Rows.Add(ClientID, Txnuid, TxnType, Uid, AdjDate, AdjType, AcquirerBank, IssuerBank, ResponseCode, TxnDateTime, ReferenceNumber, TerminalID,
                                        CardNo, ChargebackDate, ChargebackRemarks, TxnAmount, AdjAmount, ACQFee, ISSFee, ISSFeeSW, NPCIFee, AcqFeeTax, IssFeetax,
                                        NPCITax, AdjRef, BankAdjRef, AdjProof, reasondesc, PinCode, TermLoc, MultDisGroup, FCQM, ADJSettlementdate, CustPenalty,
                                        Cycle, TatExpDate, ACQSTLAmt, AcqCC, PEMode, ServiceCode, CarddataInputCap, MCCCode, UserName, System.DateTime.Now, UserName, System.DateTime.Now);
                                InsertCount++;


                            }
                            catch
                            {
                                //_DataTable.Rows.Clear();
                                //_log.FunErrorLog(EX.Message.ToString(), BankCode, "ProcessSwitchLogSpliter", "ProcessLogSpliterBOB", LineNo, FileName, UserName, 'E');
                                // variable();
                            }
                        }
                    }
                }
                if (_DataTable.Rows.Count == 0)
                {
                    InsertCount--;
                    //objCommon.InsertLogs ("Transaction not found", BankCode, "ProcessGLLogSpliter", "ProcessLogSpliterBOB", LineNo, FileName, UserName, 'E');
                    // variable();
                }
            }
            catch
            {
                //_DataTable.Rows.Clear();
                //objCommon.InsertLogs(EX.Message.ToString(), BankCode, "ProcessSwitchLogSpliter", "ProcessLogSpliterBOB", LineNo, FileName, UserName, 'E');
                //  variable();
            }
            return _DataTable;
        }
    }

    
}
