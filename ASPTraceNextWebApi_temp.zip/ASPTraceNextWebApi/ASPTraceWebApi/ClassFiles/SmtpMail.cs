﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace ASPTraceWebApi.ClassFiles
{
    public class SmtpMail
    { 
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public SmtpMail(IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        { 
            _configuration = Configuration;
            objCommon = _Common;
        }

        public bool SendEmail(EmailModel model)
        {
            bool SendEmail = false;
            try
            {
                using (MailMessage mm = new MailMessage(this._configuration.GetValue<string>("AppSettings:SenderEmail"), model.To))
                {
                    mm.Subject = model.Subject;
                    mm.Body = model.Body;
                    if (model.Attachment != null && model.Attachment.Length > 0)
                    {
                        string fileName = System.IO.Path.GetFileName(model.Attachment.FileName);
                        mm.Attachments.Add(new Attachment(model.Attachment.OpenReadStream(), fileName));
                    }
                    mm.IsBodyHtml = true;
                    using (SmtpClient smtp = new SmtpClient())
                    {
                        NetworkCredential networkCredential = new NetworkCredential(this._configuration.GetValue<string>("AppSettings:SenderEmail"), this._configuration.GetValue<string>("AppSettings:SenderEmailPassword"));
                        smtp.Host = this._configuration.GetValue<string>("AppSettings:SmtpHost");
                        smtp.Port = Convert.ToInt16(this._configuration.GetValue<string>("AppSettings:SmtpPort"));
                        smtp.EnableSsl = true;
                        smtp.Credentials = (ICredentialsByHost)networkCredential;
                        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                        smtp.Send(mm);
                    }
                }
            }
            catch (Exception ex)
            {
                objCommon.InsertLogs(ex.Message.ToString(), "", "SmtpMail.cs", "SendEmail", 0, "", "", 'E');
            }

            return SendEmail;
        }
    }

    public class EmailModel
    { 
        public string To { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public Microsoft.AspNetCore.Http.IFormFile Attachment { get; set; } 
    }
}
