﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml;
using Utility;
using ASPTrace.Models;
using System.Text.Json;
using ImportData;
using System.Reflection;
using DocumentFormat.OpenXml.Math;
using System.Text;

namespace ASPTraceWebApi.ClassFiles
{
    public class Splitter
    {
        private readonly string _MekKey1;
        private readonly string _MekKey2;
        private readonly string _connectionString;
        BulkImports bulkImports;
        public Splitter(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            _MekKey1 = MekKey1;
            _MekKey2 = MekKey2;
            bulkImports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        public DataTable Splitter_GL_Adjustment_Delimiter_Dynamic_old(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            string Description = string.Empty;
            string Typemode = string.Empty;
            string ErrorMessage = string.Empty;

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(decimal));
            _DataTable.Columns.Add("ChannelID", typeof(string));
            _DataTable.Columns.Add("ModeID", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("DEBIT_AMOUNT", typeof(decimal));
            _DataTable.Columns.Add("CREDIT_AMOUNT", typeof(decimal));
            _DataTable.Columns.Add("BALANCE", typeof(string));
            _DataTable.Columns.Add("Closing_BALANCE", typeof(decimal));
            _DataTable.Columns.Add("Ntr_Of_Bal", typeof(string));
            _DataTable.Columns.Add("Batch_Seq", typeof(string));
            _DataTable.Columns.Add("Status", typeof(decimal));



            {
                string NtrOfBal = string.Empty;
                string Closing_BAL = string.Empty;

                string[] ArrayGLLines;
                // string[] scolumn = null;
                int i = 0;
                ArrayGLLines = File.ReadAllLines(path, System.Text.Encoding.Default);
                int totalrecords = ArrayGLLines.Length;
                while (totalrecords > i)
                {
                    TotalCount++;

                    string LBRCODE = string.Empty;
                    string PRDACCTID = string.Empty;
                    string ACTUALDAT = string.Empty;
                    string SYSTRACENUM = string.Empty;
                    string ACCOUNTNUM = string.Empty;
                    string CARDNUM = string.Empty;
                    string BRBATCH = string.Empty;
                    string BRSETNUM = string.Empty;
                    string BRENTRYDA = string.Empty;
                    string TOBRCODE = string.Empty;
                    string TOBRBATCH = string.Empty;
                    string TOBRSETNUM = string.Empty;
                    string TOBRENTRY = string.Empty;
                    string TRANSTYPE = string.Empty;
                    string ENTRYTYPE = string.Empty;
                    string TRANSTIME = string.Empty;
                    string DRCR = string.Empty;
                    string AMOUNT = string.Empty;
                    string MAINACCTNUM = string.Empty;
                    string PROCESS_CODE = string.Empty;
                    string SYS_TRACENUM = string.Empty;
                    string TERMINAL_ID = string.Empty;
                    string FRM_ACNO = string.Empty;
                    string AUTH_ID = string.Empty;
                    string RRN = string.Empty;
                    string REFERENCENO = string.Empty;
                    string ACQ_INSTITUCODE = string.Empty;
                    string TERMINAL_LOC = string.Empty;
                    string CARD_NUMBER = string.Empty;
                    string LEDGER_BAL = string.Empty;
                    string NET_BAL = string.Empty;
                    DateTime TxnsDateTime;
                    DateTime FileDate;
                    string TRANSDATE = string.Empty;
                    string RESPONSE_CODE = string.Empty;
                    string REVERSAL_CASE = string.Empty;
                    string LOROMODE = string.Empty;
                    //sLine = ArrayGLLines[i];
                    DateTime? actualdate1 = null;
                    DateTime? TRANSDATE1 = null;
                    //***************************************************************************
                    string STAN_N = string.Empty;
                    string RR_NO = string.Empty;
                    string STATION_ID = string.Empty;
                    string TXN_TI = string.Empty;
                    string TXN_TI1 = string.Empty;
                    string _DateTime = string.Empty;
                    DateTime TERMDT;//= string.Empty;
                    DateTime TERMDT1;
                    string TRAN_C = string.Empty;
                    string BANCS_JOU = string.Empty;
                    string CUSTOMER_NO = string.Empty;
                    string CARD_NO = string.Empty;
                    string TRAN_AMOUNT = string.Empty;
                    string sline = string.Empty;
                    string Atm_Pos = string.Empty;
                    string CORR_JOUR = string.Empty;
                    string PSRLNO = string.Empty;
                    string TXNTYPE = string.Empty;
                    double DebitAmt = 0;
                    double CreditAmt = 0;
                    string BAL = string.Empty;
                    string BatchSeq = string.Empty;
                    int Status = 0;
                    int ModeID = 0;
                    int ChannelID = 0;
                    //string LOROMODE = string.Empty;                       
                    //*****************************************************************************************************************************************
                    try
                    {

                        sline = ArrayGLLines[i];
                        Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
                        String[] SplitArr = CSVParser.Split(sline);
                        int len = SplitArr.Count();

                        if (len == 6 && SplitArr[5].ToString() != "OPN_BAL")
                        {
                            CreditAmt = 0;
                            DebitAmt = 0;
                            Description = "Opening Balance";
                            TXNTYPE = SplitArr[2].ToString();

                            if (TXNTYPE.Contains("UPI Inward"))
                            {
                                ChannelID = 7;
                                Typemode = "UPI Inward";
                                ModeID = 4;
                            }
                            else if (TXNTYPE.Contains("UPI Outward"))
                            {
                                ChannelID = 7;
                                Typemode = "UPI Outward";
                                ModeID = 5;
                            }
                            else if (TXNTYPE.Contains("ATM") || TXNTYPE.Contains("NFS ATM"))
                            {
                                ChannelID = 1;
                                Typemode = "ATM";
                            }
                            else if (TXNTYPE.Contains("POS") || TXNTYPE.Contains("NFS - POS") || TXNTYPE.Contains("NFS-POS-adjustment"))
                            {
                                ChannelID = 2;
                                Typemode = "POS";
                            }
                            else if (TXNTYPE.Contains("IMPS Inward") || TXNTYPE.Contains("IMPS network Inward"))
                            {
                                ChannelID = 4;
                                Typemode = "IMPS Inward";
                                ModeID = 4;
                            }
                            else if (TXNTYPE.Contains("IMPS Outward") || TXNTYPE.Contains("IMPS network outward"))
                            {
                                ChannelID = 4;
                                Typemode = "IMPS Outward";
                                ModeID = 5;
                            }
                            else if (TXNTYPE.Contains("BBPS") || TXNTYPE.Contains("BBPS Adjustment Account"))
                            {
                                ChannelID = 17;
                                Typemode = "BBPS Adjustment";
                            }

                            TXNTYPE = Typemode;
                            TxnsDateTime = Convert.ToDateTime(DateTime.ParseExact(SplitArr[3].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture));
                            BAL = SplitArr[5].ToString().Replace("CR", "").Replace("DR", "").Trim();
                            BAL = BAL.Replace("-", "").Replace("\"", "");
                            _DataTable.Rows.Add(56, ChannelID, ModeID, TxnsDateTime, REFERENCENO.Replace("\"", ""), Description, Convert.ToDecimal(DebitAmt), Convert.ToDecimal(CreditAmt), BAL, Convert.ToDecimal(Closing_BAL), NtrOfBal, BatchSeq, 0);
                        }

                        else if (len == 7 && SplitArr[5].ToString() != "Closing_Bal")
                        {
                            CreditAmt = 0;
                            DebitAmt = 0;
                            Description = SplitArr[1].ToString().Replace("\"", "");
                            string[] tmpimps = Description.Split('/');



                            if (Typemode == "IMPS Inward" || Typemode == "IMPS Outward")
                            {
                                ChannelID = 4;

                                //string strRef = "";
                                //decimal number;
                                if (tmpimps.Length > 2)
                                {
                                    if (tmpimps[0].ToString().Contains("IMPS") && tmpimps[1].ToString().Contains("P2A"))
                                    {
                                        ModeID = 4;
                                        REFERENCENO = tmpimps[2].Trim();
                                    }
                                    else if (tmpimps[0].ToString().Contains("IMPS") && tmpimps[1].ToString().Contains("P2P"))
                                    {
                                        ModeID = 4;
                                        REFERENCENO = tmpimps[2].Trim();
                                    }
                                    else
                                    {
                                        ModeID = 5;
                                        REFERENCENO = tmpimps[1].Trim();
                                    }

                                    if ((tmpimps[0].ToString().Contains("Reversal IMPS")))
                                    {
                                        Status = 4;
                                    }
                                    else
                                    {
                                        Status = 1;
                                    }
                                }


                                else
                                {
                                    if (tmpimps[0].ToLower().Contains("ret") || tmpimps[0].ToLower().Contains("rev") || Typemode == "IMPS Outward")
                                    {
                                        //REFERENCENO = tmpimps[0].Trim().Substring(tmpimps[0].Length - 6, 6);
                                        REFERENCENO = Regex.Replace(tmpimps[0].Trim(), "[^0-9]+", string.Empty);
                                    }
                                    else
                                    {
                                        //REFERENCENO = tmpimps[0].Trim().Substring(0,6);
                                        REFERENCENO = Regex.Replace(tmpimps[0].Trim(), "[^0-9]+", string.Empty);
                                    }
                                }


                            }


                            else if (Typemode == "UPI Inward" || Typemode == "UPI Outward")
                            {
                                ChannelID = 7;
                                //REFERENCENO = tmpimps[1].Trim();
                                REFERENCENO = tmpimps[1].Trim().Replace("\"", "");

                                if (SplitArr[6].ToString().Replace("\"", "").Equals("DR"))
                                {
                                    ModeID = 4;
                                }
                                else if (SplitArr[6].Replace("\"", "").ToString().Equals("CR"))
                                {
                                    ModeID = 5;
                                }


                                if ((tmpimps[0].ToString().Replace("\"", "").Contains("REVUPI")))
                                {
                                    Status = 4;
                                }
                                else
                                {
                                    Status = 1;
                                }
                            }

                            else if (Typemode == "ATM")
                            {
                                ChannelID = 1;

                                DebitAmt = Convert.ToDouble(SplitArr[2].ToString().Replace(",", "").Replace("\"", ""));
                                CreditAmt = Convert.ToDouble(SplitArr[3].ToString().Replace(",", "").Replace("\"", ""));

                                Description = SplitArr[1].ToString();
                                string[] tmpatm = Description.Split('-');
                                if (DebitAmt > 0)
                                {
                                    REFERENCENO = tmpatm[1].Trim();
                                }
                                else if (CreditAmt != 0)
                                {
                                    REFERENCENO = tmpatm[0].Trim();
                                }
                                //REFERENCENO = tmpatm[1].Trim();
                            }

                            else if (Typemode == "POS")
                            {
                                ChannelID = 2;
                                ModeID = 3;

                                DebitAmt = Convert.ToDouble(SplitArr[2].ToString().Replace(",", "").Replace("\"", ""));
                                CreditAmt = Convert.ToDouble(SplitArr[3].ToString().Replace(",", "").Replace("\"", ""));

                                Description = SplitArr[1].ToString();
                                // string[] tmpatm = Description.Split('-');//commented by Nimmi
                                if (DebitAmt > 0)
                                {
                                    // REFERENCENO = tmpatm[1].Trim();//commented by Nimmi
                                    REFERENCENO = Description;
                                }
                                else if (CreditAmt > 0)
                                {
                                    //REFERENCENO = tmpatm[0].Trim();//commented by Nimmi
                                    REFERENCENO = Description;
                                }
                                //REFERENCENO = tmpatm[1].Trim();
                            }

                            else if (Typemode == "BBPS Adjustment")
                            {

                                ChannelID = 17;

                                DebitAmt = Convert.ToDouble(SplitArr[2].ToString().Replace(",", "").Replace("\"", ""));
                                CreditAmt = Convert.ToDouble(SplitArr[3].ToString().Replace(",", "").Replace("\"", ""));
                                Description = SplitArr[1].ToString();
                                string[] tmpatm = null;
                                if (Description.Contains("-"))
                                {
                                    tmpatm = Description.Split('-');
                                    if (DebitAmt > 0)
                                    {
                                        //REFERENCENO = tmpatm[0].Trim();
                                        REFERENCENO = Description;
                                    }
                                    else if (CreditAmt != 0)
                                    {
                                        //REFERENCENO = SplitArr[1].ToString();
                                        REFERENCENO = Description;
                                    }
                                }
                                else
                                {
                                    tmpatm = Description.Split('/');
                                    if (DebitAmt > 0)
                                    {
                                        REFERENCENO = tmpatm[1].Trim();
                                    }
                                    else if (CreditAmt != 0)
                                    {
                                        REFERENCENO = SplitArr[1].ToString();
                                    }
                                }
                            }

                            TXNTYPE = Typemode;
                            TxnsDateTime = Convert.ToDateTime(DateTime.ParseExact(SplitArr[0].ToString().Replace("\"", ""), "dd/MM/yyyy", CultureInfo.InvariantCulture));
                            DebitAmt = Convert.ToDouble(SplitArr[2].ToString().Replace(",", "").Replace("\"", ""));
                            CreditAmt = Convert.ToDouble(SplitArr[3].ToString().Replace(",", "").Replace("\"", ""));
                            BAL = SplitArr[5].ToString().Replace(",", "").Replace("CR", "").Replace("DR", "").Trim();
                            BAL = BAL.Replace("-", "").Replace("\"", "");
                            Closing_BAL = SplitArr[5].ToString().Replace(",", "").Replace("CR", "").Replace("DR", "").Trim();
                            Closing_BAL = Closing_BAL.Replace("-", "").Replace("\"", "");
                            NtrOfBal = SplitArr[6].ToString().Replace("\"", "");
                            _DataTable.Rows.Add(56, ChannelID, ModeID, TxnsDateTime, REFERENCENO.Replace("\"", ""), Description, Convert.ToDecimal(DebitAmt), Convert.ToDecimal(CreditAmt), BAL, Convert.ToDecimal(Closing_BAL), NtrOfBal, BatchSeq, Status);



                            if (totalrecords == TotalCount)
                            {
                                CreditAmt = 0;
                                DebitAmt = 0;
                                Description = "Closing Balance";
                                REFERENCENO = "";
                                TXNTYPE = Typemode;
                                TxnsDateTime = Convert.ToDateTime(DateTime.ParseExact(SplitArr[0].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture));
                                BAL = SplitArr[5].ToString().Replace(",", "").Replace("CR", "").Replace("DR", "").Trim();
                                BAL = BAL.Replace("-", "").Replace("\"", "");
                                _DataTable.Rows.Add(56, ChannelID, ModeID, TxnsDateTime, REFERENCENO.Replace("\"", ""), Description, Convert.ToDecimal(DebitAmt), Convert.ToDecimal(CreditAmt), BAL, Convert.ToDecimal(Closing_BAL), NtrOfBal, BatchSeq, Status);
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    i++;
                }
            }

            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;
        }



        public DataTable SplitterUPIAcquirer(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNO", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));

            _DataTable.Columns.Add("UMN", typeof(string));//new column
            _DataTable.Columns.Add("InitiationMode", typeof(string));
            _DataTable.Columns.Add("PurposeCode", typeof(string));
            _DataTable.Columns.Add("PayerCode", typeof(string));
            _DataTable.Columns.Add("PayerVPA", typeof(string));
            _DataTable.Columns.Add("PayeeCode", typeof(string));
            _DataTable.Columns.Add("PayeeMCC", typeof(string));
            _DataTable.Columns.Add("RemCode", typeof(string));
            _DataTable.Columns.Add("REMIFSCCODE", typeof(string));
            _DataTable.Columns.Add("RemitterAccountType", typeof(string));
            _DataTable.Columns.Add("BeneCode", typeof(string));
            _DataTable.Columns.Add("BENIIFSCCODE", typeof(string));
            _DataTable.Columns.Add("BeneAccountType", typeof(string));
            _DataTable.Columns.Add("BENEACCOUNTNUMBER", typeof(string));

            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataSet DT = new DataSet();
            string[] arrLines;
            string m_RecordData = string.Empty;

            //
            //

            //
            //
            //
            //

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());


            try
            {
                string sLine = string.Empty;
                string Cycle = string.Empty;
                string FD = string.Empty;
                arrLines = File.ReadAllLines(path, Encoding.Default);
                int totalrecords = arrLines.Length;
                if (FileName.Contains("MERCHANT"))
                {
                    Cycle = FileName.Substring(31, 1).ToString();
                    FD = FileName.Substring(24, 2).ToString() + "-" + FileName.Substring(26, 2).ToString() + "-" + FileName.Substring(28, 2).ToString();
                }
                else
                {
                    Cycle = FileName.Substring(23, 1).ToString();
                    FD = FileName.Substring(16, 2).ToString() + "-" + FileName.Substring(18, 2).ToString() + "-" + FileName.Substring(20, 2).ToString();
                }
                DateTime FileDate = DateTime.ParseExact(FD, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture);

                string Participant_ID = string.Empty;
                string Transaction_Type = string.Empty;
                string From_Account_Type = string.Empty; ;
                string To_Account_Type = string.Empty;
                string Transaction_Serial_Number = string.Empty;
                string Response_Code = string.Empty;
                string PAN_Number = string.Empty;
                string Member_Number = string.Empty;
                string Approval_Number = string.Empty;
                string System_Trace_Audit_Number = string.Empty;
                string Transaction_Date = string.Empty;
                //DateTime  Transaction_Date ;//= string.Empty;
                string Transaction_Time = string.Empty;
                string Merchant_Category_Code = string.Empty;
                string Card_Acceptor_Settlement_Date = string.Empty;
                string Card_Acceptor_ID = string.Empty;
                string Card_Acceptor_Terminal_ID = string.Empty;
                string Card_Acceptor_Terminal_Location = string.Empty;
                string Acquirer_ID = string.Empty;
                string Acquirer_Settlement_Date = string.Empty;
                string Transaction_Currency_code = string.Empty;
                string Transaction_Amount = string.Empty;
                string Actual_Transaction_Amount = string.Empty;
                string Transaction_Acitivity_fee = string.Empty;
                string Acquirer_settlement_Currency_Code = string.Empty;
                string Acquirer_settlement_Amount = string.Empty;
                string Acquirer_Settlement_Fee = string.Empty;
                string Acquirer_settlement_processing_fee = string.Empty;
                string Transaction_Acquirer_Conversion_Rate = string.Empty;

                int FORCEMATCH = 0;
                string UMN = string.Empty;
                string Initiation_Mode = string.Empty;
                string Purpose_Code = string.Empty;
                string Payer_Code = string.Empty;
                string Payer_VPA = string.Empty;
                string Payee_Code = string.Empty;
                string Payee_MCC = string.Empty;
                string Rem_Code = string.Empty;
                string REM_IFSC_CODE = string.Empty;
                string Remitter_Account_Type = string.Empty;
                string Bene_Code = string.Empty;
                string BENI_IFSC_CODE = string.Empty;
                string Bene_Account_Type = string.Empty;
                string BENE_ACCOUNT_NUMBER = string.Empty;

                string CardScheme = string.Empty;
                string IssuingNetwork = "NPCI";

                DateTime _datetime;

                for (int i = 0; i < totalrecords; i++)
                {
                    try
                    {
                        LineNo++;
                        TotalCount++;
                        Participant_ID = string.Empty;
                        Transaction_Type = string.Empty;
                        From_Account_Type = string.Empty; ;
                        To_Account_Type = string.Empty;
                        Transaction_Serial_Number = string.Empty;
                        Response_Code = string.Empty;
                        PAN_Number = string.Empty;
                        Member_Number = string.Empty;
                        Approval_Number = string.Empty;
                        System_Trace_Audit_Number = string.Empty;
                        Transaction_Date = string.Empty;
                        //DateTime  Transaction_Date ;//= string.Empty;
                        Transaction_Time = string.Empty;
                        Merchant_Category_Code = string.Empty;
                        Card_Acceptor_Settlement_Date = string.Empty;
                        Card_Acceptor_ID = string.Empty;
                        Card_Acceptor_Terminal_ID = string.Empty;
                        Card_Acceptor_Terminal_Location = string.Empty;
                        Acquirer_ID = string.Empty;
                        Acquirer_Settlement_Date = string.Empty;
                        Transaction_Currency_code = string.Empty;
                        Transaction_Amount = string.Empty;
                        Actual_Transaction_Amount = string.Empty;
                        Transaction_Acitivity_fee = string.Empty;
                        Acquirer_settlement_Currency_Code = string.Empty;
                        Acquirer_settlement_Amount = string.Empty;
                        Acquirer_Settlement_Fee = string.Empty;
                        Acquirer_settlement_processing_fee = string.Empty;
                        Transaction_Acquirer_Conversion_Rate = string.Empty;

                        FORCEMATCH = 0;
                        UMN = string.Empty;
                        Initiation_Mode = string.Empty;
                        Purpose_Code = string.Empty;
                        Payer_Code = string.Empty;
                        Payer_VPA = string.Empty;
                        Payee_Code = string.Empty;
                        Payee_MCC = string.Empty;
                        Rem_Code = string.Empty;
                        REM_IFSC_CODE = string.Empty;
                        Remitter_Account_Type = string.Empty;
                        Bene_Code = string.Empty;
                        BENI_IFSC_CODE = string.Empty;
                        Bene_Account_Type = string.Empty;
                        BENE_ACCOUNT_NUMBER = string.Empty;

                        sLine = arrLines[i];

                        if (FileName.Contains("MERCHANT"))
                        {
                            //sLine = arrLines[i];
                            //string[] m_RecordData = csvReader.ReadFields();
                            Participant_ID = sLine.Substring(0, 3).Trim();
                            Transaction_Type = sLine.Substring(3, 2).Trim();
                            From_Account_Type = sLine.Substring(5, 2).Trim();
                            To_Account_Type = sLine.Substring(7, 2).Trim();
                            Transaction_Serial_Number = sLine.Substring(9, 12).Trim();
                            Response_Code = sLine.Substring(21, 2).Trim();
                            PAN_Number = sLine.Substring(23, 19).Trim();
                            Member_Number = sLine.Substring(61, 1).Trim();
                            Approval_Number = sLine.Substring(42, 19).Trim();
                            System_Trace_Audit_Number = sLine.Substring(68, 12).Trim();
                            Transaction_Date = sLine.Substring(80, 6).Trim();
                            Transaction_Time = sLine.Substring(86, 6).Trim();

                            string timestamp = Transaction_Date.Substring(4, 2).ToString() + "-" + Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                            _datetime = DateTime.ParseExact(timestamp, "yy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);

                            Merchant_Category_Code = sLine.Substring(92, 4).Trim();

                            Card_Acceptor_Settlement_Date = sLine.Substring(96, 6).Trim();
                            Card_Acceptor_ID = sLine.Substring(102, 15).Trim();
                            Card_Acceptor_Terminal_ID = sLine.Substring(117, 8).Trim();
                            Card_Acceptor_Terminal_Location = sLine.Substring(125, 40).Trim();
                            Acquirer_ID = sLine.Substring(165, 11).Trim();
                            Acquirer_Settlement_Date = sLine.Substring(176, 6).Trim();
                            Transaction_Currency_code = sLine.Substring(182, 3).Trim();
                            Transaction_Amount = sLine.Substring(190, 10).Trim();
                            Actual_Transaction_Amount = sLine.Substring(190, 8).Trim();
                            Transaction_Acitivity_fee = sLine.Substring(196, 15).Trim();
                            Acquirer_settlement_Currency_Code = sLine.Substring(215, 3).Trim();
                            Acquirer_settlement_Amount = sLine.Substring(230, 13).Trim();
                            Acquirer_Settlement_Fee = sLine.Substring(248, 15).Trim();
                            Acquirer_settlement_processing_fee = sLine.Substring(263, 15).Trim();
                            Transaction_Acquirer_Conversion_Rate = sLine.Substring(278, 15).Trim();

                        }
                        else
                        {
                            Participant_ID = sLine.Substring(0, 3).Trim();
                            Transaction_Type = sLine.Substring(3, 2).Trim();
                            From_Account_Type = sLine.Substring(5, 2).Trim();
                            To_Account_Type = sLine.Substring(7, 2).Trim();
                            Transaction_Serial_Number = sLine.Substring(9, 12).Trim();
                            Response_Code = sLine.Substring(21, 2).Trim();
                            PAN_Number = sLine.Substring(23, 19).Trim();
                            Member_Number = sLine.Substring(42, 1).Trim();
                            Approval_Number = sLine.Substring(43, 6).Trim();
                            System_Trace_Audit_Number = sLine.Substring(49, 12).Trim();
                            Transaction_Date = sLine.Substring(61, 6).Trim();
                            Transaction_Time = sLine.Substring(67, 6).Trim();

                            string timestamp = Transaction_Date.Substring(4, 2).ToString() + "-" + Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                            _datetime = DateTime.ParseExact(timestamp, "yy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);

                            Merchant_Category_Code = sLine.Substring(73, 4).Trim();

                            Card_Acceptor_Settlement_Date = sLine.Substring(77, 6).Trim();
                            Card_Acceptor_ID = sLine.Substring(83, 15).Trim();
                            Card_Acceptor_Terminal_ID = sLine.Substring(98, 8).Trim();
                            Card_Acceptor_Terminal_Location = sLine.Substring(106, 40).Trim();
                            Acquirer_ID = sLine.Substring(146, 11).Trim();
                            Acquirer_Settlement_Date = sLine.Substring(157, 6).Trim();
                            Transaction_Currency_code = sLine.Substring(163, 3).Trim();
                            Transaction_Amount = sLine.Substring(171, 10).Trim();
                            Actual_Transaction_Amount = sLine.Substring(171, 8).Trim();
                            Transaction_Acitivity_fee = sLine.Substring(196, 15).Trim();
                            Acquirer_settlement_Currency_Code = sLine.Substring(211, 3).Trim();
                            Acquirer_settlement_Amount = sLine.Substring(214, 13).Trim();
                            Acquirer_Settlement_Fee = sLine.Substring(229, 15).Trim();
                            Acquirer_settlement_processing_fee = sLine.Substring(244, 15).Trim();
                            Transaction_Acquirer_Conversion_Rate = sLine.Substring(259, 15).Trim();

                            //FORCEMATCH = FileName;
                            // cycle = FileName.Substring(23, 2).Trim();
                        }


                        _DataTable.Rows.Add(ClientID, Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code, PAN_Number, Member_Number,
                                            Approval_Number, System_Trace_Audit_Number, _datetime, Transaction_Time, Merchant_Category_Code, Card_Acceptor_Settlement_Date, Card_Acceptor_ID,
                                            Card_Acceptor_Terminal_ID, Card_Acceptor_Terminal_Location, Acquirer_ID, Acquirer_Settlement_Date, Transaction_Currency_code, Transaction_Amount,
                                            Actual_Transaction_Amount, Transaction_Acitivity_fee, Acquirer_settlement_Currency_Code, Acquirer_settlement_Amount, Acquirer_Settlement_Fee, Acquirer_settlement_processing_fee,
                                            Transaction_Acquirer_Conversion_Rate, 0,
                                            System.DateTime.Now, System.DateTime.Now, UserName, UserName, Cycle, FileName, FileDate, path, UMN.Trim(), Initiation_Mode.Trim(), Purpose_Code.Trim(), Payer_Code.Trim(), Payer_VPA.Trim(), Payee_Code.Trim(), Payee_MCC.Trim(), Rem_Code.Trim(), REM_IFSC_CODE.Trim(), Remitter_Account_Type.Trim(),
                                            Bene_Code.Trim(), BENI_IFSC_CODE.Trim(), Bene_Account_Type.Trim(), BENE_ACCOUNT_NUMBER.Trim(), CardScheme, IssuingNetwork);
                        InsertCount++;

                        LineNo++;
                    }
                    catch (Exception ex)
                    {
                        InsertCount--;
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                }


                if (_DataTable.Rows.Count == 0)
                {

                }


            }
            catch (Exception ex)
            {
                InsertCount--;
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

            }

            return _DataTable;

        }

        public DataTable SplitterUPIAcquirerCSV(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNO", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("UMN", typeof(string));//new column
            _DataTable.Columns.Add("InitiationMode", typeof(string));
            _DataTable.Columns.Add("PurposeCode", typeof(string));
            _DataTable.Columns.Add("PayerCode", typeof(string));
            _DataTable.Columns.Add("PayerVPA", typeof(string));
            _DataTable.Columns.Add("PayeeCode", typeof(string));
            _DataTable.Columns.Add("PayeeMCC", typeof(string));
            _DataTable.Columns.Add("RemCode", typeof(string));
            _DataTable.Columns.Add("REMIFSCCODE", typeof(string));
            _DataTable.Columns.Add("RemitterAccountType", typeof(string));
            _DataTable.Columns.Add("BeneCode", typeof(string));
            _DataTable.Columns.Add("BENIIFSCCODE", typeof(string));
            _DataTable.Columns.Add("BeneAccountType", typeof(string));
            _DataTable.Columns.Add("BENEACCOUNTNUMBER", typeof(string));

            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;

            //
            //

            //
            //
            //
            //

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            // bool TxnAmountIsDecimal = Convert.ToBoolean(dt.Rows[0]["TxnAmountIsDecimal"]);
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            DateTime? Transaction_Date = null;

            string strFileName = Path.GetFileNameWithoutExtension(path);
            string FD = strFileName.Substring(strFileName.Length - 9);
            string[] FDA = FD.Split('_');
            DateTime FileDate = DateTime.ParseExact(FDA[0], "ddMMyy", System.Globalization.CultureInfo.InvariantCulture);
            string Cycle = FDA[1].ToString();


            int Incr = 1;
            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string MEMNUMBER = string.Empty;
            string Approval_Number = string.Empty;
            string SYSTRACAUDITNO = "0";
            string Transaction_Time = string.Empty;
            string Merchant_Category_Code = string.Empty;
            string CARDACCEPTSETDATE = "0";
            string CARDACCID = string.Empty;
            string Card_Acceptor_ID = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string Acquirer_ID = string.Empty;
            string ACCSETDATE = "0";
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = string.Empty;
            string ACCTUALTRANSAMOUNT = string.Empty;
            string TRANSACTIVITYFEE = "0";
            string ACCURSETCURCODE = string.Empty;
            string ACQUIERSETAMOUNT = "0";
            string ACQUIERSETFEE = "0";
            string ACQUIERSETPROFEEE = "0";
            string TRANSACQUIERCONVERRATE = "0";
            int FORCEMATCH = 0;
            string UMN = string.Empty;
            string Initiation_Mode = string.Empty;
            string Purpose_Code = string.Empty;
            string Payer_Code = string.Empty;
            string Payer_VPA = string.Empty;
            string Payee_Code = string.Empty;
            string Payee_MCC = string.Empty;
            string Rem_Code = string.Empty;
            string REM_IFSC_CODE = string.Empty;
            string Remitter_Account_Type = string.Empty;
            string Bene_Code = string.Empty;
            string BENI_IFSC_CODE = string.Empty;
            string Bene_Account_Type = string.Empty;
            string BENE_ACCOUNT_NUMBER = string.Empty;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;
                try
                {

                    string line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                    // string FD = FileName.Substring(16, 2).ToString() + "-" + FileName.Substring(18, 2).ToString() + "-" + FileName.Substring(20, 2).ToString();


                    string[] SplitArr = line1.Split(',');
                    Incr = 1;
                    Participant_ID = SplitArr[12];
                    Transaction_Type = SplitArr[1];
                    From_Account_Type = SplitArr[20];
                    To_Account_Type = SplitArr[24];
                    Transaction_Serial_Number = SplitArr[3];
                    Response_Code = SplitArr[4];
                    PAN_Number = SplitArr[21];
                    MEMNUMBER = SplitArr[9];
                    Approval_Number = SplitArr[2];
                    SYSTRACAUDITNO = "0";
                    Transaction_Date = DateTime.ParseExact(SplitArr[5], "MMddyy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                    Transaction_Time = SplitArr[6];
                    Merchant_Category_Code = SplitArr[16];
                    if (Merchant_Category_Code.Trim() == "")
                    {
                        Merchant_Category_Code = "0";
                    }
                    CARDACCEPTSETDATE = "0";
                    CARDACCID = string.Empty;
                    Card_Acceptor_ID = string.Empty;
                    CARDACCEPTERTERLOC = SplitArr[17];
                    Acquirer_ID = string.Empty;
                    ACCSETDATE = "0";
                    Transaction_Currency_Code = string.Empty;
                    Transaction_Amount = SplitArr[7];
                    ACCTUALTRANSAMOUNT = SplitArr[7];
                    TRANSACTIVITYFEE = "0";
                    ACCURSETCURCODE = string.Empty;
                    ACQUIERSETAMOUNT = "0";
                    ACQUIERSETFEE = "0";
                    ACQUIERSETPROFEEE = "0";
                    TRANSACQUIERCONVERRATE = "0";
                    FORCEMATCH = 0;
                    UMN = SplitArr[8];
                    Initiation_Mode = SplitArr[10];
                    Purpose_Code = SplitArr[11];
                    Payer_Code = SplitArr[12];
                    Payer_VPA = SplitArr[14];
                    Payee_Code = SplitArr[15];
                    Payee_MCC = SplitArr[16];
                    Rem_Code = SplitArr[18];
                    REM_IFSC_CODE = SplitArr[19];
                    Remitter_Account_Type = SplitArr[20];
                    Bene_Code = SplitArr[22];
                    BENI_IFSC_CODE = SplitArr[23];
                    Bene_Account_Type = SplitArr[24];
                    BENE_ACCOUNT_NUMBER = SplitArr[25];

                    _DataTable.Rows.Add(ClientID, Participant_ID.Trim(), Transaction_Type.Trim(), From_Account_Type.Trim(), To_Account_Type.Trim(), Transaction_Serial_Number.Trim(), Response_Code.Trim(), PAN_Number.Trim(), MEMNUMBER.Trim(),
                     Approval_Number.Trim(), SYSTRACAUDITNO.Trim(), Transaction_Date, Transaction_Time, Merchant_Category_Code.Trim(), CARDACCEPTSETDATE.Trim(), CARDACCID.Trim(), Card_Acceptor_ID.Trim(), CARDACCEPTERTERLOC.Trim(),
                     Acquirer_ID.Trim(), ACCSETDATE.Trim(), Transaction_Currency_Code.Trim(), Transaction_Amount.Trim(), ACCTUALTRANSAMOUNT.Trim(), TRANSACTIVITYFEE.Trim(), ACCURSETCURCODE.Trim(), ACQUIERSETAMOUNT.Trim(), ACQUIERSETFEE.Trim(),
                     ACQUIERSETPROFEEE.Trim(), TRANSACQUIERCONVERRATE.Trim(), FORCEMATCH, System.DateTime.Now, System.DateTime.Now, UserName.Trim(), UserName.Trim(), Cycle.Trim(), FileName.Trim(), FileDate, path.Trim(), UMN.Trim(), Initiation_Mode.Trim(), Purpose_Code.Trim(), Payer_Code.Trim(), Payer_VPA.Trim(), Payee_Code.Trim(), Payee_MCC.Trim(), Rem_Code.Trim(), REM_IFSC_CODE.Trim(), Remitter_Account_Type.Trim(),
                     Bene_Code.Trim(), BENI_IFSC_CODE.Trim(), Bene_Account_Type.Trim(), BENE_ACCOUNT_NUMBER.Trim(), CardScheme, IssuingNetwork);

                    LineNo++;

                }
                catch (Exception ex)
                {
                    InsertCount--;
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }

            }

            return _DataTable;

        }

        public DataTable SplitterUPIIssuer(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifyBy", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));


            _DataTable.Columns.Add("UMN", typeof(string));//new column
            _DataTable.Columns.Add("InitiationMode", typeof(string));
            _DataTable.Columns.Add("PurposeCode", typeof(string));
            _DataTable.Columns.Add("PayerVPA", typeof(string));
            _DataTable.Columns.Add("PayeeCode", typeof(string));
            _DataTable.Columns.Add("PayeeMCC", typeof(string));
            _DataTable.Columns.Add("RemCode", typeof(string));
            _DataTable.Columns.Add("REMIFSCCODE", typeof(string));
            _DataTable.Columns.Add("REMACCOUNTNUMBER", typeof(string));
            _DataTable.Columns.Add("BeneCode", typeof(string));
            _DataTable.Columns.Add("BENIIFSCCODE", typeof(string));
            _DataTable.Columns.Add("BENEACCOUNTNUMBER", typeof(string));

            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataSet DT = new DataSet();
            string[] arrLines;
            string m_RecordData = string.Empty;

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            try
            {
                string sLine = string.Empty;
                string Cycle = string.Empty;
                string FD = string.Empty;

                arrLines = File.ReadAllLines(path, Encoding.Default);
                int totalrecords = arrLines.Length;
                if (FileName.Contains("MERCHANT"))
                {
                    Cycle = FileName.Substring(31, 1).ToString();
                    FD = FileName.Substring(24, 2).ToString() + "-" + FileName.Substring(26, 2).ToString() + "-" + FileName.Substring(28, 2).ToString();
                }
                else
                {
                    Cycle = FileName.Substring(23, 1).ToString();
                    FD = FileName.Substring(16, 2).ToString() + "-" + FileName.Substring(18, 2).ToString() + "-" + FileName.Substring(20, 2).ToString();
                }

                //string Cycle = FileName.Substring(23, 1).ToString();
                //string FD = FileName.Substring(16, 2).ToString() + "-" + FileName.Substring(18, 2).ToString() + "-" + FileName.Substring(20, 2).ToString();
                DateTime FileDate = DateTime.ParseExact(FD, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture);

                string Account_1_Number = "";
                string Participant_ID = string.Empty;
                string Transaction_Type = string.Empty;
                string From_Account_Type = string.Empty; ;
                string To_Account_Type = string.Empty;
                string Transaction_Serial_Number = string.Empty;
                string Response_Code = string.Empty;
                string PAN_Number = string.Empty;
                string Member_Number = string.Empty;
                string Approval_Number = string.Empty;
                string System_Trace_Audit_Number = string.Empty;
                string Transaction_Date = string.Empty;
                //DateTime  Transaction_Date ;//= string.Empty;
                string Transaction_Time = string.Empty;
                string Merchant_Category_Code_ = string.Empty;
                string Card_Acceptor_Settlement_Date = string.Empty;
                string Card_Acceptor_ID = string.Empty;
                string Card_Acceptor_Terminal_ID = string.Empty;
                string Card_Acceptor_Terminal_Location = string.Empty;
                string Acquirer_ID = string.Empty;
                string Network_ID = string.Empty;
                string Account_1_Branch_ID = string.Empty;
                string Account_2_Number = string.Empty;
                string Account_2_Branch_ID = string.Empty;
                string Transaction_Currency_Code = string.Empty;
                string Transaction_Amount = string.Empty;
                string Actual_Transaction_Amount = string.Empty;
                string Transaction_Activity_Fee = string.Empty;
                string Issuer_Settlement_Currency_Code = string.Empty;
                string Issuer_Settlement_Amount = string.Empty;
                string Issuer_Settlement_Fee = string.Empty;
                string Issuer_Settlement_Processing_Fee = string.Empty;
                string Cardholder_Billing_Currency_Code = string.Empty;
                string Cardholder_Billing_Amount = string.Empty;
                string Cardholder_Billing_Activity_Fee = string.Empty;
                string Cardholder_Billing_Processing_Fee = string.Empty;
                string Cardholder_Billing_Service_Fee = string.Empty;
                string Transaction_Issuer_Conversion_Rate = string.Empty;
                string Transaction_Cardholder_Conversion_Rate = string.Empty;


                string UMN = string.Empty;//new column
                string Initiation_Mode = string.Empty;
                string Purpose_Code = string.Empty;
                string Payer_VPA = string.Empty;
                string Payee_Code = string.Empty;
                string Payee_MCC = string.Empty;
                string Rem_Code = string.Empty;
                string REM_IFSC_CODE = string.Empty;
                string REM_ACCOUNT_NUMBER = string.Empty;
                string Bene_Code = string.Empty;
                string BENI_IFSC_CODE = string.Empty;
                string BENE_ACCOUNT_NUMBER = string.Empty;

                string CardScheme = string.Empty;
                string IssuingNetwork = "NPCI";

                DateTime _datetime;

                for (int i = 0; i < totalrecords; i++)
                {
                    try
                    {
                        Account_1_Number = "";
                        m_RecordData = arrLines[i];
                        LineNo++;
                        //TotalCount++;

                        Participant_ID = string.Empty;
                        Transaction_Type = string.Empty;
                        From_Account_Type = string.Empty; ;
                        To_Account_Type = string.Empty;
                        Transaction_Serial_Number = string.Empty;
                        Response_Code = string.Empty;
                        PAN_Number = string.Empty;
                        Member_Number = string.Empty;
                        Approval_Number = string.Empty;
                        System_Trace_Audit_Number = string.Empty;
                        Transaction_Date = string.Empty;
                        //DateTime  Transaction_Date ;//= string.Empty;
                        Transaction_Time = string.Empty;
                        Merchant_Category_Code_ = string.Empty;
                        Card_Acceptor_Settlement_Date = string.Empty;
                        Card_Acceptor_ID = string.Empty;
                        Card_Acceptor_Terminal_ID = string.Empty;
                        Card_Acceptor_Terminal_Location = string.Empty;
                        Acquirer_ID = string.Empty;
                        Network_ID = string.Empty;
                        Account_1_Branch_ID = string.Empty;
                        Account_2_Number = string.Empty;
                        Account_2_Branch_ID = string.Empty;
                        Transaction_Currency_Code = string.Empty;
                        Transaction_Amount = string.Empty;
                        Actual_Transaction_Amount = string.Empty;
                        Transaction_Activity_Fee = string.Empty;
                        Issuer_Settlement_Currency_Code = string.Empty;
                        Issuer_Settlement_Amount = string.Empty;
                        Issuer_Settlement_Fee = string.Empty;
                        Issuer_Settlement_Processing_Fee = string.Empty;
                        Cardholder_Billing_Currency_Code = string.Empty;
                        Cardholder_Billing_Amount = string.Empty;
                        Cardholder_Billing_Activity_Fee = string.Empty;
                        Cardholder_Billing_Processing_Fee = string.Empty;
                        Cardholder_Billing_Service_Fee = string.Empty;
                        Transaction_Issuer_Conversion_Rate = string.Empty;
                        Transaction_Cardholder_Conversion_Rate = string.Empty;


                        UMN = string.Empty;//new column
                        Initiation_Mode = string.Empty;
                        Purpose_Code = string.Empty;
                        Payer_VPA = string.Empty;
                        Payee_Code = string.Empty;
                        Payee_MCC = string.Empty;
                        Rem_Code = string.Empty;
                        REM_IFSC_CODE = string.Empty;
                        REM_ACCOUNT_NUMBER = string.Empty;
                        Bene_Code = string.Empty;
                        BENI_IFSC_CODE = string.Empty;
                        BENE_ACCOUNT_NUMBER = string.Empty;

                        if (FileName.Contains("MERCHANT"))
                        {
                            Participant_ID = m_RecordData.Substring(0, 3).Trim();
                            Transaction_Type = m_RecordData.Substring(3, 2).Trim();
                            From_Account_Type = m_RecordData.Substring(5, 2).Trim();
                            To_Account_Type = m_RecordData.Substring(7, 2).Trim();
                            Transaction_Serial_Number = m_RecordData.Substring(9, 12).Trim();
                            Response_Code = m_RecordData.Substring(21, 2).Trim();
                            PAN_Number = m_RecordData.Substring(23, 19).Trim();
                            Member_Number = m_RecordData.Substring(42, 1).Trim();
                            Approval_Number = m_RecordData.Substring(43, 6).Trim();
                            System_Trace_Audit_Number = m_RecordData.Substring(49, 12).Trim();
                            Transaction_Date = m_RecordData.Substring(80, 6).Trim();
                            Transaction_Time = m_RecordData.Substring(86, 6).Trim();
                            FD = Transaction_Date.Substring(4, 2).ToString() + "-" + Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                            //string timestamp = Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + "-" + Transaction_Date.Substring(4, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                            _datetime = DateTime.ParseExact(FD, "yy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                            Merchant_Category_Code_ = m_RecordData.Substring(92, 4).Trim();
                            Card_Acceptor_Settlement_Date = m_RecordData.Substring(96, 6).Trim();
                            Card_Acceptor_ID = m_RecordData.Substring(102, 15).Trim();
                            Card_Acceptor_Terminal_ID = m_RecordData.Substring(117, 8).Trim();
                            Card_Acceptor_Terminal_Location = m_RecordData.Substring(125, 40).Trim();
                            Acquirer_ID = m_RecordData.Substring(165, 11).Trim();
                            Network_ID = m_RecordData.Substring(176, 3).Trim();
                            Account_1_Number = m_RecordData.Substring(738, 19).Trim();
                            Account_1_Branch_ID = m_RecordData.Substring(179, 10).Trim();
                            Account_2_Number = m_RecordData.Substring(189, 19).Trim();
                            Account_2_Branch_ID = m_RecordData.Substring(208, 10).Trim();

                            Transaction_Currency_Code = m_RecordData.Substring(218, 3).Trim();
                            //Eliminated Last two digit
                            Transaction_Amount = m_RecordData.Substring(221, 15).Trim();
                            Actual_Transaction_Amount = m_RecordData.Substring(236, 15).Trim();
                            //***********//
                            Transaction_Activity_Fee = m_RecordData.Substring(251, 15).Trim();
                            Issuer_Settlement_Currency_Code = m_RecordData.Substring(266, 3).Trim();
                            Issuer_Settlement_Amount = m_RecordData.Substring(269, 3).Trim();

                            Issuer_Settlement_Fee = m_RecordData.Substring(284, 15).Trim();
                            Issuer_Settlement_Processing_Fee = m_RecordData.Substring(299, 15).Trim();
                            Cardholder_Billing_Currency_Code = m_RecordData.Substring(314, 3).Trim();
                            Cardholder_Billing_Amount = m_RecordData.Substring(317, 15).Trim();
                            Cardholder_Billing_Activity_Fee = m_RecordData.Substring(332, 15).Trim();
                            Cardholder_Billing_Processing_Fee = m_RecordData.Substring(347, 15).Trim();
                            Cardholder_Billing_Service_Fee = m_RecordData.Substring(362, 15).Trim();
                            Transaction_Issuer_Conversion_Rate = m_RecordData.Substring(377, 15).Trim();
                            Transaction_Cardholder_Conversion_Rate = m_RecordData.Substring(392, 15).Trim();
                            Cycle = FileName.Substring(31, 2).Trim();

                            FD = FileName.Substring(24, 2).ToString() + "-" + FileName.Substring(26, 2).ToString() + "-" + FileName.Substring(28, 2).ToString();
                            _datetime = DateTime.ParseExact(FD, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);

                        }
                        else
                        {
                            Participant_ID = m_RecordData.Substring(0, 2).Trim();
                            Transaction_Type = m_RecordData.Substring(3, 2).Trim();
                            From_Account_Type = m_RecordData.Substring(5, 2).Trim();
                            To_Account_Type = m_RecordData.Substring(7, 2).Trim();
                            Transaction_Serial_Number = m_RecordData.Substring(9, 12).Trim();
                            Response_Code = m_RecordData.Substring(21, 2).Trim();
                            PAN_Number = m_RecordData.Substring(23, 19).Trim();
                            Member_Number = m_RecordData.Substring(42, 1).Trim();
                            Approval_Number = m_RecordData.Substring(43, 6).Trim();
                            System_Trace_Audit_Number = m_RecordData.Substring(49, 12).Trim();
                            Transaction_Date = m_RecordData.Substring(61, 6).Trim();
                            Transaction_Time = m_RecordData.Substring(67, 6).Trim();

                            FD = Transaction_Date.Substring(4, 2).ToString() + "-" + Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                            _datetime = DateTime.ParseExact(FD, "yy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);

                            Merchant_Category_Code_ = m_RecordData.Substring(73, 4).Trim();
                            Card_Acceptor_Settlement_Date = m_RecordData.Substring(77, 6).Trim();
                            Card_Acceptor_ID = m_RecordData.Substring(1316, 36).Trim();
                            Card_Acceptor_Terminal_ID = m_RecordData.Substring(98, 8).Trim();
                            Card_Acceptor_Terminal_Location = m_RecordData.Substring(106, 40).Trim();
                            Acquirer_ID = m_RecordData.Substring(146, 11).Trim();
                            Network_ID = m_RecordData.Substring(157, 3).Trim();
                            Account_1_Number = m_RecordData.Substring(160, 19).Trim();
                            Account_1_Branch_ID = m_RecordData.Substring(179, 10).Trim();
                            Account_2_Number = m_RecordData.Substring(189, 19).Trim();
                            Account_2_Branch_ID = m_RecordData.Substring(208, 10).Trim();
                            Transaction_Currency_Code = m_RecordData.Substring(218, 3).Trim();
                            //Eliminated Last two digit
                            Transaction_Amount = m_RecordData.Substring(221, 15).Trim();
                            Actual_Transaction_Amount = m_RecordData.Substring(236, 13).Trim();
                            //***********//
                            Transaction_Activity_Fee = m_RecordData.Substring(251, 15).Trim();
                            Issuer_Settlement_Currency_Code = m_RecordData.Substring(266, 3).Trim();
                            Issuer_Settlement_Amount = m_RecordData.Substring(269, 13).Trim();
                            Issuer_Settlement_Fee = m_RecordData.Substring(284, 15).Trim();
                            Issuer_Settlement_Processing_Fee = m_RecordData.Substring(299, 15).Trim();
                            Cardholder_Billing_Currency_Code = m_RecordData.Substring(314, 3).Trim();
                            Cardholder_Billing_Amount = m_RecordData.Substring(317, 15).Trim();
                            Cardholder_Billing_Activity_Fee = m_RecordData.Substring(332, 15).Trim();
                            Cardholder_Billing_Processing_Fee = m_RecordData.Substring(347, 15).Trim();
                            Cardholder_Billing_Service_Fee = m_RecordData.Substring(362, 15).Trim();
                            Transaction_Issuer_Conversion_Rate = m_RecordData.Substring(377, 15).Trim();
                            Transaction_Cardholder_Conversion_Rate = m_RecordData.Substring(392, 15).Trim();

                        }
                        _DataTable.Rows.Add(ClientID, Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code,
                                        PAN_Number, Member_Number, Approval_Number, System_Trace_Audit_Number, _datetime, Transaction_Time, Merchant_Category_Code_,
                                        Card_Acceptor_Settlement_Date, Card_Acceptor_ID, Card_Acceptor_Terminal_ID, Card_Acceptor_Terminal_Location, Acquirer_ID, Network_ID,
                                        Account_1_Number, Account_1_Branch_ID, Account_2_Number, Account_2_Branch_ID, Transaction_Currency_Code, Transaction_Amount,
                                        Actual_Transaction_Amount, Transaction_Activity_Fee, Issuer_Settlement_Currency_Code, Issuer_Settlement_Amount, Issuer_Settlement_Fee,
                                        Issuer_Settlement_Processing_Fee, Cardholder_Billing_Currency_Code, Cardholder_Billing_Amount, Cardholder_Billing_Activity_Fee,
                                        Cardholder_Billing_Processing_Fee, Cardholder_Billing_Service_Fee, Transaction_Issuer_Conversion_Rate, Transaction_Cardholder_Conversion_Rate, 0,
                                        System.DateTime.Now, System.DateTime.Now, UserName, UserName, Cycle, FileName, FileDate, path, UMN.Trim(), Initiation_Mode.Trim(), Purpose_Code.Trim(), Payer_VPA.Trim(), Payee_Code.Trim(),
                                       Payee_MCC.Trim(), Rem_Code.Trim(), REM_IFSC_CODE.Trim(), REM_ACCOUNT_NUMBER.Trim(), Bene_Code.Trim(), BENI_IFSC_CODE.Trim(), BENE_ACCOUNT_NUMBER.Trim(), CardScheme, IssuingNetwork);

                        LineNo++;
                    }
                    catch (Exception ex)
                    {
                        InsertCount--;
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

                    }

                }


                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;

                }


            }
            catch (Exception ex)
            {
                InsertCount--;
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            return _DataTable;

        }

        public DataTable SplitterUPIIssuerCSV(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifyBy", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("UMN", typeof(string));//new column
            _DataTable.Columns.Add("InitiationMode", typeof(string));
            _DataTable.Columns.Add("PurposeCode", typeof(string));
            _DataTable.Columns.Add("PayerVPA", typeof(string));
            _DataTable.Columns.Add("PayeeCode", typeof(string));
            _DataTable.Columns.Add("PayeeMCC", typeof(string));
            _DataTable.Columns.Add("RemCode", typeof(string));
            _DataTable.Columns.Add("REMIFSCCODE", typeof(string));
            _DataTable.Columns.Add("REMACCOUNTNUMBER", typeof(string));
            _DataTable.Columns.Add("BeneCode", typeof(string));
            _DataTable.Columns.Add("BENIIFSCCODE", typeof(string));
            _DataTable.Columns.Add("BENEACCOUNTNUMBER", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            //string EMekKey1 = ConfigurationSettings.AppSettings["MekKey1"].ToString();
            //string EMekKey2 = ConfigurationSettings.AppSettings["MekKey2"].ToString();
            //string StrCon = DAL.Comman.ConnectionString(); //ConfigurationSettings.AppSettings["con"].ToString();
            //ConfigurationDAL objConfigurationDAL = new ConfigurationDAL();
            //DataSet dsDEK = objConfigurationDAL.GetEncryptedDEK();
            //DataSet dsCardNetwork = objConfigurationDAL.GetCardNetwork();

            //AesEncryption.ClearMEK = AesEncryption.DecryptEncryptedMEK(EMekKey1);
            //AesEncryption.ClearMEK2 = AesEncryption.DecryptEncryptedMEK(EMekKey2);
            //string DEK = AesEncryption.DecryptEncryptedDEK(dsDEK.Tables[0].Rows[0]["TMK_LMK"].ToString(), AesEncryption.ClearMEK2);
            //

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            // bool TxnAmountIsDecimal = Convert.ToBoolean(dt.Rows[0]["TxnAmountIsDecimal"]);
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            //DateTime? Transaction_Date = null;

            string strFileName = Path.GetFileNameWithoutExtension(path);
            string FD = strFileName.Substring(strFileName.Length - 9);
            string[] FDA = FD.Split('_', '.');
            DateTime FileDate = DateTime.ParseExact(FDA[0], "ddMMyy", CultureInfo.InvariantCulture);
            string Cycle = FDA[1].ToString();
            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                    string[] SplitArr = line1.Split(',');
                    int Incr = 1;
                    string Participant_ID = SplitArr[12];
                    string Transaction_Type = SplitArr[1];
                    string From_Account_Type = SplitArr[20];
                    string To_Account_Type = SplitArr[24];
                    string Transaction_Serial_Number = SplitArr[3];
                    string Response_Code = SplitArr[4];
                    string PAN_Number = SplitArr[21];
                    string MEMNUMBER = SplitArr[9];
                    string Approval_Number = SplitArr[2];
                    string STAUDITNO = "0";
                    //Transaction_Date = DateTime.ParseExact(SplitArr[5], "MMddyy", CultureInfo.InvariantCulture, DateTimeStyles.None);
                    //string Transaction_Time = SplitArr[6];
                    string Transaction_Date = SplitArr[5];
                    string Transaction_Time = SplitArr[6];
                    string timestamp = Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + "-" + Transaction_Date.Substring(4, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                    DateTime Transaction_Date1 = DateTime.ParseExact(timestamp, "MM-dd-yy HH:mm:ss", CultureInfo.InvariantCulture);

                    string Merchant_Category_Code = SplitArr[16];
                    if (Merchant_Category_Code.Trim() == "")
                    {
                        Merchant_Category_Code = "0";
                    }
                    string CARDACCEPTSETDATE = "0";
                    string Card_Acceptor_ID = string.Empty;
                    string CARDACCEPTTERMINALID = string.Empty;
                    string CARDACCEPTERTERLOCATION = SplitArr[17];
                    string Acquirer_ID = SplitArr[15];
                    string NETWORKID = string.Empty;
                    string ACCOUNTNO1 = SplitArr[25];
                    string ACCOUNTBRANCHID = string.Empty;
                    string ACCOUNTNO2 = SplitArr[21];
                    string ACCOUNT2BRANCHID = string.Empty;
                    string Transaction_Currency_Code = string.Empty;
                    string Transaction_Amount = SplitArr[7];
                    string ACCTUALTRANAMOUNT = SplitArr[7];
                    string TRANSACCVITYFEE = "0";
                    string ISSUERSETCURRENCYCODE = string.Empty;
                    string ISSURESETAMOUNT = "0";
                    string ISSUERSETFEE = "0";
                    string ISSURESETPROCFEE = "0";
                    string CARDHOLDERBILLCURNCCODE = string.Empty;
                    string CARDHOLDERBILLAMOUNT = "0";
                    string CARDHOLDERBILACTFEE = "0";
                    string CARDHOLDERBILPROFEE = "0";
                    string CARDHOLDERBILSRVICEFEE = "0";
                    string TRAN_ISSUERCONVERSRATE = "0";
                    string TRANS_CARDHOLDERCONVERRATE = "0";
                    int FORCEMATCH = 0;
                    string UMN = SplitArr[8];//new column
                    string Initiation_Mode = SplitArr[10];
                    string Purpose_Code = SplitArr[11];
                    string Payer_VPA = SplitArr[14];
                    string Payee_Code = SplitArr[15];
                    string Payee_MCC = SplitArr[16];
                    string Rem_Code = SplitArr[18];
                    string REM_IFSC_CODE = SplitArr[19];
                    string REM_ACCOUNT_NUMBER = SplitArr[21];
                    string Bene_Code = SplitArr[22];
                    string BENI_IFSC_CODE = SplitArr[23];
                    string BENE_ACCOUNT_NUMBER = SplitArr[25];

                    _DataTable.Rows.Add(ClientID, Participant_ID.Trim(), Transaction_Type.Trim(), From_Account_Type.Trim(), To_Account_Type.Trim(), Transaction_Serial_Number.Trim(), Response_Code.Trim(), PAN_Number.Trim(), MEMNUMBER.Trim(),
                                       Approval_Number.Trim(), STAUDITNO.Trim(), Transaction_Date1, Transaction_Time.Trim(), Merchant_Category_Code.Trim(), CARDACCEPTSETDATE.Trim(), Card_Acceptor_ID.Trim(), CARDACCEPTTERMINALID.Trim(), CARDACCEPTERTERLOCATION.Trim(),
                                       Acquirer_ID, NETWORKID, ACCOUNTNO1, ACCOUNTBRANCHID, ACCOUNTNO2, ACCOUNT2BRANCHID, Transaction_Currency_Code, Transaction_Amount, ACCTUALTRANAMOUNT,
                                       TRANSACCVITYFEE.Trim(), ISSUERSETCURRENCYCODE.Trim(), ISSURESETAMOUNT.Trim(), ISSUERSETFEE.Trim(), ISSURESETPROCFEE.Trim(), CARDHOLDERBILLCURNCCODE.Trim(), CARDHOLDERBILLAMOUNT.Trim(), CARDHOLDERBILACTFEE.Trim(), CARDHOLDERBILPROFEE.Trim(),
                                       CARDHOLDERBILSRVICEFEE.Trim(), TRAN_ISSUERCONVERSRATE.Trim(), TRANS_CARDHOLDERCONVERRATE.Trim(), FORCEMATCH, System.DateTime.Now, System.DateTime.Now, UserName, UserName, Cycle, FileName, FileDate, path, UMN.Trim(), Initiation_Mode.Trim(), Purpose_Code.Trim(), Payer_VPA.Trim(), Payee_Code.Trim(),
                                       Payee_MCC.Trim(), Rem_Code.Trim(), REM_IFSC_CODE.Trim(), REM_ACCOUNT_NUMBER.Trim(), Bene_Code.Trim(), BENI_IFSC_CODE.Trim(), BENE_ACCOUNT_NUMBER.Trim(), CardScheme, IssuingNetwork);

                    //LineNo++;

                }
                catch (Exception ex)
                {
                    InsertCount--;
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }


            }

            return _DataTable;

        }

        public DataTable SplitterSettlementUPI(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("NoTxns", typeof(int));
            _DataTable.Columns.Add("Debit", typeof(string));
            _DataTable.Columns.Add("Credit", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));
            _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            //int StartIndex = 0;
            //int EndIndex = 0;
            //string EMekKey1 = ConfigurationSettings.AppSettings["MekKey1"].ToString();
            //string EMekKey2 = ConfigurationSettings.AppSettings["MekKey2"].ToString();
            //string StrCon = ConfigurationSettings.AppSettings["con"].ToString(); //DAL.Comman.ConnectionString(); 
            //ConfigurationDAL objConfigurationDAL = new ConfigurationDAL();
            //DataSet dsDEK = objConfigurationDAL.GetEncryptedDEK();
            //DataSet dsCardNetwork = objConfigurationDAL.GetCardNetwork();
            //AesEncryption.ClearMEK = AesEncryption.DecryptEncryptedMEK(EMekKey1);
            //AesEncryption.ClearMEK2 = AesEncryption.DecryptEncryptedMEK(EMekKey2);
            //string DEK = AesEncryption.DecryptEncryptedDEK(dsDEK.Tables[0].Rows[0]["TMK_LMK"].ToString(), AesEncryption.ClearMEK2);
            //

            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            InsertCount = 0;
            TotalCount = 0;

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;
            DataTable dtexcelsheetname = null;
            try
            {
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                OleDbConnection objConn = new OleDbConnection(connString);
                string extension = Path.GetExtension(path);

                switch (extension.ToLower())
                {

                    case ".xls": //Excel 97-03
                                 // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                    case ".xlsx": //Excel 07 or higher
                                  //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;

                }

                try
                {
                    objConn = new OleDbConnection(connString);



                    if (objConn.State == ConnectionState.Open)
                    {
                        objConn.Close();
                    }

                    objConn.Open();

                }
                catch
                {
                    switch (extension.ToLower())
                    {

                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }

                    try
                    {
                        objConn = new OleDbConnection(connString);
                        if (objConn.State == ConnectionState.Open)
                        {
                            objConn.Close();
                        }

                        objConn.Open();
                    }
                    catch
                    {
                        switch (extension.ToLower())
                        {
                            case ".xls": //Excel 97-03
                                         // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                                connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                break;
                            case ".xlsx": //Excel 07 or higher
                                          //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                break;
                        }
                        try
                        {
                            objConn = new OleDbConnection(connString);
                            if (objConn.State == ConnectionState.Open)
                            {
                                objConn.Close();
                            }
                            objConn.Open();
                        }
                        catch
                        {
                            switch (extension.ToLower())
                            {
                                case ".xls": //Excel 97-03 xls
                                    connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                                    break;
                                case ".xlsx": //Excel 07 or higher xlsx
                                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                                    break;
                            }

                            try
                            {
                                objConn = new OleDbConnection(connString);
                                if (objConn.State == ConnectionState.Open)
                                {
                                    objConn.Close();
                                }
                                objConn.Open();
                            }
                            catch
                            {
                                switch (extension.ToLower())
                                {

                                    case ".xls": //Excel 97-03
                                                 // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";



                                        break;
                                    case ".xlsx": //Excel 07 or higher
                                                  //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                        break;
                                }
                                objConn = new OleDbConnection(connString);
                                objConn.Open();
                            }

                        }
                    }

                }


                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                int j = 0;
                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    excelSheets[j] = row["TABLE_NAME"].ToString();
                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                    //string sht = dr[2].ToString().Replace("'", "");

                    OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataTable dtSheet = new DataTable();
                    da.Fill(dtSheet);
                    objConn.Close();

                    if (dtSheet.Rows.Count > 1)
                    {
                        DateTime? Date;
                        Date = null;
                        string[] Filesplit = FileName.Split('_');
                        string[] Cycle = Filesplit[2].Split('.');
                        string DateArray = FileName.Substring(11, 2).ToString() + "-" + FileName.Substring(13, 2).ToString() + "-" + FileName.Substring(15, 2).ToString();
                        Date = DateTime.ParseExact(DateArray.ToString(), "dd-MM-yy", null);
                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            int Incr = 1;
                            string Description = string.Empty;
                            int NoTxns = 0;
                            decimal Debit = 0;
                            decimal Credit = 0;
                            string Remarks = string.Empty;


                            try
                            {

                                if (ds.Tables[0].Rows[0]["Description"].ToString() != "0")
                                {
                                    Description = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Description"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["NoTxns"].ToString() != "0")
                                {
                                    NoTxns = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["NoTxns"].ToString()) - Incr].ToString() != "" ? Convert.ToInt32(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["NoTxns"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Debit"].ToString() != "0")
                                {
                                    Debit = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Debit"].ToString()) - Incr].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Debit"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Credit"].ToString() != "0")
                                {
                                    Credit = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Credit"].ToString()) - Incr].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Credit"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Remarks"].ToString() != "")
                                {
                                    Remarks = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Remarks"].ToString()) - Incr].ToString();
                                }

                                //Description = dtSheet.Rows[k][0].ToString();
                                //NoTxns = dtSheet.Rows[k][1].ToString() != "" ? Convert.ToInt32(dtSheet.Rows[k][1].ToString()) : 0;
                                //Debit = dtSheet.Rows[k][2].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][2].ToString()) : 0;
                                //Credit = dtSheet.Rows[k][3].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][3].ToString()) : 0;

                            }
                            catch (Exception ex)
                            {
                                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            }
                            LineNo++;
                            if (Description != "" && (Debit > 0 || Credit > 0))
                                _DataTable.Rows.Add(Date, Cycle[0].ToString().Trim(), Description, NoTxns, Debit, Credit, Remarks, ClientID, FileName, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);
                            InsertCount++;
                            j++;
                        }
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;

        }

        public DataTable SplitDataUPIDebitReversal(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("TXN_UID", typeof(string));
            _DataTable.Columns.Add("TXN_Type", typeof(string));
            _DataTable.Columns.Add("TxnDateTime", typeof(DateTime));
            _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("RRN_No", typeof(string));
            _DataTable.Columns.Add("STAN_Number", typeof(string));
            _DataTable.Columns.Add("Remitter", typeof(string));
            _DataTable.Columns.Add("Beneficiary", typeof(string));
            _DataTable.Columns.Add("Beneficiary_Number", typeof(string));
            _DataTable.Columns.Add("Remitter_Number", typeof(string));
            _DataTable.Columns.Add("Amount", typeof(string));
            _DataTable.Columns.Add("UTXN_ID", typeof(string));
            _DataTable.Columns.Add("PayerPSP", typeof(string));
            _DataTable.Columns.Add("PayeePSP", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;

            //
            //

            //
            //
            //
            //

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            // bool TxnAmountIsDecimal = Convert.ToBoolean(dt.Rows[0]["TxnAmountIsDecimal"]);
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            DateTime? TxnDateTime = null;
            DateTime? SettlementDate = null;

            string strFileName = Path.GetFileNameWithoutExtension(path);
            string FD = strFileName.Substring(strFileName.Length - 10);


            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    string line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                    string[] SplitArr = line1.Split(',');
                    int Incr = 1;
                    string TXN_UID = SplitArr[0];
                    string TXN_Type = SplitArr[1];
                    string d1 = SplitArr[2].ToString();
                    string d2 = SplitArr[3].ToString();
                    string date1 = d1 + " " + d2;
                    try
                    {
                        TxnDateTime = DateTime.ParseExact(date1.ToString(), new[] { "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy H:mm:ss" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                    }
                    catch
                    {
                        try
                        {
                            TxnDateTime = DateTime.ParseExact(date1.ToString(), new[] { "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy H:mm:ss" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                        }
                        catch
                        {
                            TxnDateTime = null;
                        }
                    }
                    SettlementDate = DateTime.ParseExact(SplitArr[4].ToString(), new string[] { "ddMMYYYY", "dd/MM/yyyy" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                    string ResponseCode = SplitArr[5];
                    ResponseCode = ResponseCode.Replace("'", "");
                    string RRN_No = SplitArr[6];
                    RRN_No = RRN_No.Replace("'", "");
                    string STAN_Number = SplitArr[7];
                    STAN_Number = STAN_Number.Replace("'", "");
                    string Remitter = SplitArr[8];
                    string Beneficiary = SplitArr[9];
                    string Beneficiary_Number = SplitArr[10];
                    Beneficiary_Number = Beneficiary_Number.Replace("'", "");
                    string Remitter_Number = SplitArr[11];
                    Remitter_Number = Remitter_Number.Replace("'", "");
                    string Amount = SplitArr[12];
                    string UTXN_ID = SplitArr[13];
                    string PayerPSP = SplitArr[14];
                    string PayeePSP = SplitArr[15];

                    _DataTable.Rows.Add(ClientID, TXN_UID, TXN_Type, TxnDateTime, SettlementDate, ResponseCode, RRN_No, STAN_Number, Remitter, Beneficiary, Beneficiary_Number,
                        Remitter_Number, Amount, UTXN_ID, PayerPSP, PayeePSP, FileName, UserName, System.DateTime.Now, UserName, System.DateTime.Now
                    );

                    LineNo++;

                }
                catch (Exception ex)
                {
                    InsertCount--;
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }

            }

            return _DataTable;

        }

        public DataTable SplitterAdjustmentUPI(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("TxnUID", typeof(string));
            _DataTable.Columns.Add("UID", typeof(string));
            _DataTable.Columns.Add("AdjDate", typeof(DateTime));
            _DataTable.Columns.Add("AdjType", typeof(string));
            _DataTable.Columns.Add("Remitter", typeof(string));
            _DataTable.Columns.Add("Beneficiery", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("TxnDateTime", typeof(DateTime));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TerminalID", typeof(string));
            _DataTable.Columns.Add("Ben_Mobile_No", typeof(string));
            _DataTable.Columns.Add("Rem_Mobile_No", typeof(string));
            _DataTable.Columns.Add("ChargebackDate", typeof(DateTime));
            _DataTable.Columns.Add("Chbref", typeof(string));
            _DataTable.Columns.Add("TxnAmount", typeof(string));
            _DataTable.Columns.Add("AdjAmount", typeof(string));
            _DataTable.Columns.Add("Rem_Fee", typeof(string));
            _DataTable.Columns.Add("Ben_Fee", typeof(string));
            _DataTable.Columns.Add("BenFeeSW", typeof(string));
            _DataTable.Columns.Add("AdjFee", typeof(string));
            _DataTable.Columns.Add("NPCIFee", typeof(string));
            _DataTable.Columns.Add("Remfeetax", typeof(string));
            _DataTable.Columns.Add("Benfeetax", typeof(string));
            _DataTable.Columns.Add("Npcitax", typeof(string));
            _DataTable.Columns.Add("AdjRef", typeof(string));
            _DataTable.Columns.Add("BankAdjRef", typeof(string));
            _DataTable.Columns.Add("AdjProof", typeof(string));
            _DataTable.Columns.Add("Compensation_amount", typeof(string));
            _DataTable.Columns.Add("Adj_Raise_Time", typeof(string));
            _DataTable.Columns.Add("No_of_Days_for_Penalty", typeof(string));
            _DataTable.Columns.Add("SHDT73", typeof(string));
            _DataTable.Columns.Add("SHDT74", typeof(string));
            _DataTable.Columns.Add("SHDT75", typeof(string));
            _DataTable.Columns.Add("SHDT76", typeof(string));
            _DataTable.Columns.Add("SHDT77", typeof(string));
            _DataTable.Columns.Add("Transaction_Type", typeof(string));
            _DataTable.Columns.Add("Transaction_Indicator", typeof(string));
            _DataTable.Columns.Add("Beneficiary_Account_number", typeof(string));
            _DataTable.Columns.Add("Remitter_Account_number", typeof(string));
            _DataTable.Columns.Add("Aadhar_Number", typeof(string));
            _DataTable.Columns.Add("Mobile_Number", typeof(string));
            _DataTable.Columns.Add("Payer_PSP", typeof(string));
            _DataTable.Columns.Add("Payee_PSP", typeof(string));
            _DataTable.Columns.Add("UPI_Transaction_ID", typeof(string));
            _DataTable.Columns.Add("Virtual_Address", typeof(string));
            _DataTable.Columns.Add("Dispute_Flag", typeof(string));
            _DataTable.Columns.Add("Reason_Code", typeof(string));
            _DataTable.Columns.Add("MCC", typeof(string));
            _DataTable.Columns.Add("Originating_Channel", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;


            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            // bool TxnAmountIsDecimal = Convert.ToBoolean(dt.Rows[0]["TxnAmountIsDecimal"]);
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            DateTime? TxnDateTime = null;
            DateTime? ChargebackDate = null;
            DateTime? AdjDate = null;

            string strFileName = Path.GetFileNameWithoutExtension(path);
            string FD = strFileName.Substring(strFileName.Length - 9);

            string line1 = string.Empty;

            string Txnuid = string.Empty;
            string Uid = string.Empty;
            string AdjType = string.Empty;
            string AcquirerBank = string.Empty;
            string IssuerBank = string.Empty;
            string ResponseCode = string.Empty;
            string d1 = string.Empty;
            string d2 = string.Empty;
            string date1 = string.Empty;
            string ReferenceNumber = string.Empty;
            string benmobno = string.Empty;
            string remmobno = string.Empty;
            string TerminalID = string.Empty;

            string chbref = string.Empty;
            string TxnAmount = string.Empty;
            string AdjAmount = string.Empty;
            string RemFee = string.Empty;
            string BenFee = string.Empty;
            string BenFeeSW = string.Empty;
            string AdjFee = string.Empty;
            string NPCIFee = string.Empty;
            string Remfeetax = string.Empty;
            string Benfeetax = string.Empty;
            string Npcitax = string.Empty;
            string AdjRef = string.Empty;
            string BankAdjRef = string.Empty;
            string AdjProof = string.Empty;
            string Compensation_amount = string.Empty;
            string AdjRaisetime = string.Empty;
            string NoofDaysforPenalty = string.Empty;
            string SHDT73 = string.Empty;
            string SHDT74 = string.Empty;
            string SHDT75 = string.Empty;
            string SHDT76 = string.Empty;
            string SHDT77 = string.Empty;
            string Transaction_Type = string.Empty;
            string Transaction_Indicator = string.Empty;
            string Beneficiary_Account_number = string.Empty;
            string Remitter_Account_number = string.Empty;
            string Aadhar_Number = string.Empty;
            string Mobile_Number = string.Empty;
            string Payer_PSP = string.Empty;
            string Payee_PSP = string.Empty;
            string UPI_Transaction_ID = string.Empty;
            string Virtual_Address = string.Empty;
            string Dispute_Flag = string.Empty;
            string Reason_Code = string.Empty;
            string MCC = string.Empty;
            string Originating_Channel = string.Empty;

            string[] SplitArr;

            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;

                line1 = string.Empty;

                Txnuid = string.Empty;
                Uid = string.Empty;
                AdjType = string.Empty;
                AcquirerBank = string.Empty;
                IssuerBank = string.Empty;
                ResponseCode = string.Empty;
                d1 = string.Empty;
                d2 = string.Empty;
                date1 = string.Empty;
                ReferenceNumber = string.Empty;
                benmobno = string.Empty;
                remmobno = string.Empty;
                TerminalID = string.Empty;

                chbref = string.Empty;
                TxnAmount = string.Empty;
                AdjAmount = string.Empty;
                RemFee = string.Empty;
                BenFee = string.Empty;
                BenFeeSW = string.Empty;
                AdjFee = string.Empty;
                NPCIFee = string.Empty;
                Remfeetax = string.Empty;
                Benfeetax = string.Empty;
                Npcitax = string.Empty;
                AdjRef = string.Empty;
                BankAdjRef = string.Empty;
                AdjProof = string.Empty;
                Compensation_amount = string.Empty;
                AdjRaisetime = string.Empty;
                NoofDaysforPenalty = string.Empty;
                SHDT73 = string.Empty;
                SHDT74 = string.Empty;
                SHDT75 = string.Empty;
                SHDT76 = string.Empty;
                SHDT77 = string.Empty;
                Transaction_Type = string.Empty;
                Transaction_Indicator = string.Empty;
                Beneficiary_Account_number = string.Empty;
                Remitter_Account_number = string.Empty;
                Aadhar_Number = string.Empty;
                Mobile_Number = string.Empty;
                Payer_PSP = string.Empty;
                Payee_PSP = string.Empty;
                UPI_Transaction_ID = string.Empty;
                Virtual_Address = string.Empty;
                Dispute_Flag = string.Empty;
                Reason_Code = string.Empty;
                MCC = string.Empty;
                Originating_Channel = string.Empty;

                try
                {
                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                    SplitArr = line1.Split(',');

                    Txnuid = SplitArr[0];
                    Uid = SplitArr[1];
                    AdjType = SplitArr[3];
                    AcquirerBank = SplitArr[4];
                    IssuerBank = SplitArr[5];
                    ResponseCode = SplitArr[6];
                    d1 = SplitArr[7];
                    d2 = SplitArr[8];

                    date1 = d1 + " " + d2;

                    try
                    {
                        TxnDateTime = DateTime.ParseExact(date1.ToString(), new[] { "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy H:mm:ss" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                    }
                    catch (Exception)
                    {
                        try
                        {
                            TxnDateTime = DateTime.ParseExact(date1.ToString(), new[] { "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy H:mm:ss" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                        }
                        catch (Exception e)
                        {
                            TxnDateTime = null;
                        }
                    }

                    try
                    {
                        AdjDate = DateTime.ParseExact(SplitArr[2].ToString(), new string[] { "ddMMYYYY", "dd-MM-yyyy" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                    }
                    catch (Exception)
                    {
                        try
                        {
                            AdjDate = DateTime.ParseExact(date1.ToString(), new[] { "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy H:mm:ss" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                        }
                        catch (Exception e)
                        {
                            AdjDate = null;
                        }
                    }

                    ReferenceNumber = SplitArr[9].Replace("'", "");
                    TerminalID = SplitArr[10];
                    benmobno = SplitArr[11].Replace("'", "");
                    remmobno = SplitArr[12].Replace("'", "");

                    if (SplitArr[13].Contains("-"))
                    {
                        ChargebackDate = null;
                    }
                    else
                    {
                        try
                        {
                            // ChargebackDate = SplitArr[13].ToString().Contains('-') == true ? (DateTime.ParseExact(SplitArr[13].ToString(), "dd-MM-yyyy", null)) : ChargebackDate;
                            ChargebackDate = DateTime.ParseExact(SplitArr[13].ToString(), new string[] { "ddMMYYYY", "dd-MM-yyyy" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                        }
                        catch (Exception)
                        {
                            ChargebackDate = null;
                        }
                    }

                    chbref = SplitArr[14];
                    TxnAmount = SplitArr[15].Replace("'", "");
                    AdjAmount = SplitArr[16];
                    RemFee = SplitArr[17];
                    BenFee = SplitArr[18];
                    BenFeeSW = SplitArr[19];
                    AdjFee = SplitArr[20];
                    NPCIFee = SplitArr[21];
                    Remfeetax = SplitArr[22];
                    Benfeetax = SplitArr[23];
                    Npcitax = SplitArr[24];
                    AdjRef = SplitArr[25];
                    BankAdjRef = SplitArr[26];
                    AdjProof = SplitArr[27];
                    Compensation_amount = SplitArr[28];
                    AdjRaisetime = SplitArr[29];
                    NoofDaysforPenalty = SplitArr[30];
                    SHDT73 = SplitArr[31];
                    SHDT74 = SplitArr[32];
                    SHDT75 = SplitArr[33];
                    SHDT76 = SplitArr[34];
                    SHDT77 = SplitArr[35];
                    Transaction_Type = SplitArr[36];
                    Transaction_Indicator = SplitArr[37];
                    Beneficiary_Account_number = SplitArr[38];
                    Remitter_Account_number = SplitArr[39];
                    Aadhar_Number = SplitArr[40];
                    Mobile_Number = SplitArr[41].Replace("'", "");
                    Payer_PSP = SplitArr[42];
                    Payee_PSP = SplitArr[43].Replace("'", "");
                    UPI_Transaction_ID = SplitArr[44];
                    Virtual_Address = SplitArr[45];
                    Dispute_Flag = SplitArr[46];
                    Reason_Code = SplitArr[47];
                    MCC = SplitArr[48];
                    Originating_Channel = SplitArr[49];

                    if (TxnDateTime != null)
                    {
                        _DataTable.Rows.Add(ClientID, Txnuid, Uid, AdjDate, AdjType, AcquirerBank, IssuerBank, ResponseCode, TxnDateTime, ReferenceNumber, TerminalID, benmobno, remmobno, ChargebackDate, chbref, TxnAmount,
                        AdjAmount, RemFee, BenFee, BenFeeSW, AdjFee, NPCIFee, Remfeetax, Benfeetax, Npcitax, AdjRef, BankAdjRef, AdjProof, Compensation_amount, AdjRaisetime, NoofDaysforPenalty, SHDT73, SHDT74, SHDT75, SHDT76, SHDT77, Transaction_Type,
                        Transaction_Indicator, Beneficiary_Account_number, Remitter_Account_number, Aadhar_Number, Mobile_Number, Payer_PSP, Payee_PSP, UPI_Transaction_ID, Virtual_Address, Dispute_Flag, Reason_Code, MCC,
                        Originating_Channel, UserName, System.DateTime.Now, UserName, System.DateTime.Now
                        );
                    }

                    LineNo++;

                }
                catch (Exception ex)
                {
                    InsertCount--;
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }


            }

            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;

        }


        public DataTable SplitterIMPSAcquirer(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNO", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));

            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataSet DT = new DataSet();
            string[] arrLines;
            string m_RecordData = string.Empty;

            //string EMekKey1 = ConfigurationSettings.AppSettings["MekKey1"].ToString();
            //string EMekKey2 = ConfigurationSettings.AppSettings["MekKey2"].ToString();
            //string StrCon = DAL.Comman.ConnectionString();//ConfigurationSettings.AppSettings["con"].ToString();
            //ConfigurationDAL objConfigurationDAL = new ConfigurationDAL();
            //DataSet dsDEK = objConfigurationDAL.GetEncryptedDEK();
            //DataSet dsCardNetwork = objConfigurationDAL.GetCardNetwork();

            //AesEncryption.ClearMEK = AesEncryption.DecryptEncryptedMEK(EMekKey1);
            //AesEncryption.ClearMEK2 = AesEncryption.DecryptEncryptedMEK(EMekKey2);
            //string DEK = AesEncryption.DecryptEncryptedDEK(dsDEK.Tables[0].Rows[0]["TMK_LMK"].ToString(), AesEncryption.ClearMEK2);
            //

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            try
            {
                string sLine = string.Empty;
                arrLines = File.ReadAllLines(path, Encoding.Default);
                int totalrecords = arrLines.Length;
                string Cycle = FileName.Substring(15, 1).ToString();
                string FD = FileName.Substring(8, 2).ToString() + "-" + FileName.Substring(10, 2).ToString() + "-" + FileName.Substring(12, 2).ToString();
                DateTime FileDate = DateTime.ParseExact(FD, "dd-MM-yy", CultureInfo.InvariantCulture);

                string Participant_ID = string.Empty;
                string Transaction_Type = string.Empty;
                string From_Account_Type = string.Empty; ;
                string To_Account_Type = string.Empty;
                string Transaction_Serial_Number = string.Empty;
                string Response_Code = string.Empty;
                string PAN_Number = string.Empty;
                string Member_Number = string.Empty;
                string Approval_Number = string.Empty;
                string System_Trace_Audit_Number = string.Empty;
                string Transaction_Date = string.Empty;
                //DateTime  Transaction_Date ;//= string.Empty;
                string Transaction_Time = string.Empty;
                string Merchant_Category_Code = string.Empty;
                string Card_Acceptor_Settlement_Date = string.Empty;
                string Card_Acceptor_ID = string.Empty;
                string Card_Acceptor_Terminal_ID = string.Empty;
                string Card_Acceptor_Terminal_Location = string.Empty;
                string Acquirer_ID = string.Empty;
                string Acquirer_Settlement_Date = string.Empty;
                string Transaction_Currency_code = string.Empty;
                string Transaction_Amount = string.Empty;
                string Actual_Transaction_Amount = string.Empty;
                string Transaction_Acitivity_fee = string.Empty;
                string Acquirer_settlement_Currency_Code = string.Empty;
                string Acquirer_settlement_Amount = string.Empty;
                string Acquirer_Settlement_Fee = string.Empty;
                string Acquirer_settlement_processing_fee = string.Empty;
                string Transaction_Acquirer_Conversion_Rate = string.Empty;

                string timestamp = string.Empty;
                DateTime _datetime = new DateTime();

                string CardScheme = string.Empty;
                string IssuingNetwork = "NPCI";

                for (int i = 0; i < totalrecords; i++)
                {
                    try
                    {
                        //LineNo++;
                        //TotalCount++;
                        Participant_ID = string.Empty;
                        Transaction_Type = string.Empty;
                        From_Account_Type = string.Empty; ;
                        To_Account_Type = string.Empty;
                        Transaction_Serial_Number = string.Empty;
                        Response_Code = string.Empty;
                        PAN_Number = string.Empty;
                        Member_Number = string.Empty;
                        Approval_Number = string.Empty;
                        System_Trace_Audit_Number = string.Empty;
                        Transaction_Date = string.Empty;

                        Transaction_Time = string.Empty;
                        Merchant_Category_Code = string.Empty;
                        Card_Acceptor_Settlement_Date = string.Empty;
                        Card_Acceptor_ID = string.Empty;
                        Card_Acceptor_Terminal_ID = string.Empty;
                        Card_Acceptor_Terminal_Location = string.Empty;
                        Acquirer_ID = string.Empty;
                        Acquirer_Settlement_Date = string.Empty;
                        Transaction_Currency_code = string.Empty;
                        Transaction_Amount = string.Empty;
                        Actual_Transaction_Amount = string.Empty;
                        Transaction_Acitivity_fee = string.Empty;
                        Acquirer_settlement_Currency_Code = string.Empty;
                        Acquirer_settlement_Amount = string.Empty;
                        Acquirer_Settlement_Fee = string.Empty;
                        Acquirer_settlement_processing_fee = string.Empty;
                        Transaction_Acquirer_Conversion_Rate = string.Empty;

                        sLine = arrLines[i];
                        //string[] m_RecordData = csvReader.ReadFields();
                        Participant_ID = sLine.Substring(0, 3).Trim();
                        Transaction_Type = sLine.Substring(3, 2).Trim();
                        From_Account_Type = sLine.Substring(5, 2).Trim();
                        To_Account_Type = sLine.Substring(7, 2).Trim();
                        Transaction_Serial_Number = sLine.Substring(9, 12).Trim();
                        Response_Code = sLine.Substring(21, 2).Trim();
                        PAN_Number = sLine.Substring(23, 19).Trim();
                        Member_Number = sLine.Substring(42, 1).Trim();
                        Approval_Number = sLine.Substring(43, 6).Trim();
                        System_Trace_Audit_Number = sLine.Substring(49, 12).Trim();
                        Transaction_Date = sLine.Substring(61, 6).Trim();
                        Transaction_Time = sLine.Substring(67, 6).Trim();

                        timestamp = Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + "-" + Transaction_Date.Substring(4, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                        _datetime = DateTime.ParseExact(timestamp, "yy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

                        Merchant_Category_Code = sLine.Substring(73, 4).Trim();

                        Card_Acceptor_Settlement_Date = sLine.Substring(77, 6).Trim();
                        Card_Acceptor_ID = sLine.Substring(83, 15).Trim();
                        Card_Acceptor_Terminal_ID = sLine.Substring(98, 8).Trim();
                        Card_Acceptor_Terminal_Location = sLine.Substring(106, 40).Trim();
                        Acquirer_ID = sLine.Substring(146, 11).Trim();
                        Acquirer_Settlement_Date = sLine.Substring(157, 6).Trim();
                        Transaction_Currency_code = sLine.Substring(163, 3).Trim();
                        Transaction_Amount = sLine.Substring(171, 8).Trim() + '.' + sLine.Substring(179, 2).Trim();
                        Actual_Transaction_Amount = sLine.Substring(171, 8).Trim() + '.' + sLine.Substring(179, 2).Trim();
                        Transaction_Acitivity_fee = sLine.Substring(196, 15).Trim();
                        Acquirer_settlement_Currency_Code = sLine.Substring(211, 3).Trim();
                        Acquirer_settlement_Amount = sLine.Substring(214, 13).Trim();
                        Acquirer_Settlement_Fee = sLine.Substring(229, 15).Trim();
                        Acquirer_settlement_processing_fee = sLine.Substring(244, 15).Trim();
                        Transaction_Acquirer_Conversion_Rate = sLine.Substring(259, 15).Trim();


                        _DataTable.Rows.Add(ClientID, Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code, PAN_Number, Member_Number,
                                            Approval_Number, System_Trace_Audit_Number, _datetime, Transaction_Time, Merchant_Category_Code, Card_Acceptor_Settlement_Date, Card_Acceptor_ID,
                                            Card_Acceptor_Terminal_ID, Card_Acceptor_Terminal_Location, Acquirer_ID, Acquirer_Settlement_Date, Transaction_Currency_code,
                                            Transaction_Amount, Transaction_Acitivity_fee, Transaction_Acitivity_fee, Acquirer_settlement_Currency_Code, Acquirer_settlement_Amount, Acquirer_Settlement_Fee, Acquirer_settlement_processing_fee,
                                            Transaction_Acquirer_Conversion_Rate, 0,
                                            System.DateTime.Now, System.DateTime.Now, UserName, UserName, Cycle, FileName, FileDate, path, CardScheme, IssuingNetwork);
                        //InsertCount++;

                        //LineNo++;
                    }
                    catch (Exception ex)
                    {
                        InsertCount--;
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                }


                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;

                }


            }
            catch (Exception ex)
            {
                InsertCount--;
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            return _DataTable;

        }

        public DataTable SplitterIMPSAcquirerCSV(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNO", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));

            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            //string EMekKey1 = ConfigurationSettings.AppSettings["MekKey1"].ToString();
            //string EMekKey2 = ConfigurationSettings.AppSettings["MekKey2"].ToString();
            //string StrCon = DAL.Comman.ConnectionString(); //ConfigurationSettings.AppSettings["con"].ToString();
            //ConfigurationDAL objConfigurationDAL = new ConfigurationDAL();
            //DataSet dsDEK = objConfigurationDAL.GetEncryptedDEK();
            //DataSet dsCardNetwork = objConfigurationDAL.GetCardNetwork();

            //AesEncryption.ClearMEK = AesEncryption.DecryptEncryptedMEK(EMekKey1);
            //AesEncryption.ClearMEK2 = AesEncryption.DecryptEncryptedMEK(EMekKey2);
            //string DEK = AesEncryption.DecryptEncryptedDEK(dsDEK.Tables[0].Rows[0]["TMK_LMK"].ToString(), AesEncryption.ClearMEK2);
            //

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            // bool TxnAmountIsDecimal = Convert.ToBoolean(dt.Rows[0]["TxnAmountIsDecimal"]);
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            DateTime? Transaction_Date = null;
            string strFileName = Path.GetFileNameWithoutExtension(path);
            string FD = strFileName.Substring(strFileName.Length - 9);
            string[] FDA = FD.Split('_', '.');
            DateTime FileDate = DateTime.ParseExact(FDA[0], "ddMMyy", CultureInfo.InvariantCulture);
            string Cycle = FDA[1].ToString();


            string line1 = string.Empty;

            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string MEMNUMBER = string.Empty;
            string Approval_Number = string.Empty;
            string SYSTRACAUDITNO = "0";

            string Transaction_Time = string.Empty;
            string Merchant_Category_Code = string.Empty;

            string CARDACCEPTSETDATE = string.Empty;


            string CARDACCID = string.Empty;//REM_IFSC_CODE
            string Card_Acceptor_ID = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string Acquirer_ID = string.Empty;
            string ACCSETDATE = "0";
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = string.Empty;
            string ACCTUALTRANSAMOUNT = string.Empty;
            string TRANSACTIVITYFEE = string.Empty;//Ben_Account_Number


            string ACCURSETCURCODE = string.Empty;//Bene_IFSC_CODE
            string ACQUIERSETAMOUNT = "0";
            string ACQUIERSETFEE = "0";
            string ACQUIERSETPROFEE = string.Empty;//REM_ACCOUNT_NUMBER


            string TRANSACQUIERCONVERRATE = "0";
            bool FORCEMATCH = false;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            foreach (string line in File.ReadAllLines(path))
            {
                // LineNo++;
                try
                {

                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);
                    //string Cycle = FileName.Substring(15, 1).ToString();
                    //string FD = FileName.Substring(8, 2).ToString() + "-" + FileName.Substring(10, 2).ToString() + "-" + FileName.Substring(12, 2).ToString();
                    //DateTime FileDate = DateTime.ParseExact(FD, "MM-dd-yy", CultureInfo.InvariantCulture);
                    string[] SplitArr = line1.Split(',');


                    Participant_ID = SplitArr[0];
                    Transaction_Type = SplitArr[1];
                    From_Account_Type = SplitArr[2];
                    To_Account_Type = SplitArr[3];
                    Transaction_Serial_Number = SplitArr[4];
                    Response_Code = SplitArr[5];
                    PAN_Number = SplitArr[6];
                    MEMNUMBER = string.Empty;
                    Approval_Number = SplitArr[7];
                    SYSTRACAUDITNO = "0";
                    Transaction_Date = DateTime.ParseExact(SplitArr[8], "yyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None);
                    Transaction_Time = SplitArr[9];
                    Merchant_Category_Code = SplitArr[10];
                    if (Merchant_Category_Code.Trim() == "")
                    {
                        Merchant_Category_Code = "0";
                    }
                    CARDACCEPTSETDATE = SplitArr[13];

                    if (CARDACCEPTSETDATE.Trim() == "")
                    {
                        CARDACCEPTSETDATE = "0";
                    }
                    CARDACCID = SplitArr[19];//REM_IFSC_CODE
                    Card_Acceptor_ID = SplitArr[11];
                    CARDACCEPTERTERLOC = string.Empty;
                    Acquirer_ID = SplitArr[12];
                    ACCSETDATE = "0";
                    Transaction_Currency_Code = SplitArr[14];
                    Transaction_Amount = SplitArr[15];
                    ACCTUALTRANSAMOUNT = SplitArr[15];
                    TRANSACTIVITYFEE = SplitArr[18];//Ben_Account_Number

                    if (TRANSACTIVITYFEE.Trim() == "")
                    {
                        TRANSACTIVITYFEE = "0";
                    }
                    else
                    {
                        try
                        {
                            TRANSACTIVITYFEE = Convert.ToDecimal(TRANSACTIVITYFEE).ToString();
                        }
                        catch
                        {
                            TRANSACTIVITYFEE = "0";
                        }
                    }

                    ACCURSETCURCODE = SplitArr[17];//Bene_IFSC_CODE
                    ACQUIERSETAMOUNT = "0";
                    ACQUIERSETFEE = "0";
                    ACQUIERSETPROFEE = SplitArr[20];//REM_ACCOUNT_NUMBER
                    if (ACQUIERSETPROFEE.Trim() == "")
                    {
                        ACQUIERSETPROFEE = "0";
                    }

                    TRANSACQUIERCONVERRATE = "0";
                    FORCEMATCH = false;



                    _DataTable.Rows.Add(ClientID, Participant_ID.Trim(), Transaction_Type.Trim(), From_Account_Type.Trim(), To_Account_Type.Trim(), Transaction_Serial_Number.Trim(), Response_Code.Trim(), PAN_Number.Trim(), MEMNUMBER.Trim(),
                                            Approval_Number.Trim(), SYSTRACAUDITNO.Trim(), Transaction_Date, Transaction_Time.Trim(), Merchant_Category_Code.Trim(), CARDACCEPTSETDATE.Trim(), CARDACCID.Trim(), Card_Acceptor_ID.Trim(), CARDACCEPTERTERLOC.Trim(),
                                               Acquirer_ID, ACCSETDATE, Transaction_Currency_Code, Transaction_Amount, ACCTUALTRANSAMOUNT, TRANSACTIVITYFEE, ACCURSETCURCODE, ACQUIERSETAMOUNT, ACQUIERSETFEE, ACQUIERSETPROFEE, TRANSACQUIERCONVERRATE,
                                               FORCEMATCH, System.DateTime.Now, System.DateTime.Now, UserName.Trim(), UserName.Trim(), Cycle.Trim(), FileName.Trim(), FileDate, path.Trim(), CardScheme, IssuingNetwork);

                    // LineNo++;

                }
                catch (Exception ex)
                {
                    InsertCount--;
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }

            }

            return _DataTable;

        }

        public DataTable SplitterIMPSIssuer(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifyBy", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));

            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataSet DT = new DataSet();
            string[] arrLines;
            string m_RecordData = string.Empty;
            decimal AMT;
            //string EMekKey1 = ConfigurationSettings.AppSettings["MekKey1"].ToString();
            //string EMekKey2 = ConfigurationSettings.AppSettings["MekKey2"].ToString();
            //string StrCon = DAL.Comman.ConnectionString(); //ConfigurationSettings.AppSettings["con"].ToString();
            //ConfigurationDAL objConfigurationDAL = new ConfigurationDAL();
            //DataSet dsDEK = objConfigurationDAL.GetEncryptedDEK();
            //DataSet dsCardNetwork = objConfigurationDAL.GetCardNetwork();

            //AesEncryption.ClearMEK = AesEncryption.DecryptEncryptedMEK(EMekKey1);
            //AesEncryption.ClearMEK2 = AesEncryption.DecryptEncryptedMEK(EMekKey2);
            //string DEK = AesEncryption.DecryptEncryptedDEK(dsDEK.Tables[0].Rows[0]["TMK_LMK"].ToString(), AesEncryption.ClearMEK2);
            //

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            try
            {

                arrLines = File.ReadAllLines(path, Encoding.Default);

                int totalrecords = arrLines.Length;
                string Cycle = FileName.Substring(15, 1).ToString();
                string FD = FileName.Substring(8, 2).ToString() + "-" + FileName.Substring(10, 2).ToString() + "-" + FileName.Substring(12, 2).ToString();
                DateTime FileDate = DateTime.ParseExact(FD, "dd-MM-yy", CultureInfo.InvariantCulture);

                string Participant_ID = string.Empty;
                string Transaction_Type = string.Empty;
                string From_Account_Type = string.Empty;
                string To_Account_Type = string.Empty;
                string Transaction_Serial_Number = string.Empty;
                string Response_Code = string.Empty;
                string PAN_Number = string.Empty;
                string Member_Number = string.Empty;
                string Approval_Number = string.Empty;
                string System_Trace_Audit_Number = string.Empty;
                int auditno = 0;
                string Transaction_Date = string.Empty;
                string Transaction_Time = string.Empty;

                string timestamp = string.Empty;
                string Merchant_Category_Code_ = string.Empty;
                string Card_Acceptor_Settlement_Date = string.Empty;

                string Card_Acceptor_ID = string.Empty;
                string Card_Acceptor_Terminal_ID = string.Empty;
                string Card_Acceptor_Terminal_Location = string.Empty;
                string Acquirer_ID = string.Empty;
                string Network_ID = string.Empty;
                string Account_1_Number = string.Empty;
                string Account_1_Branch_ID = string.Empty;
                string Account_2_Number = string.Empty;
                string Account_2_Branch_ID = string.Empty;
                string Transaction_Currency_Code = string.Empty;
                //Eliminated Last two digit

                string Transaction_Amount = string.Empty;
                string Actual_Transaction_Amount = string.Empty;
                string Transaction_Activity_Fee = string.Empty;
                string Issuer_Settlement_Currency_Code = string.Empty;
                string Issuer_Settlement_Amount = string.Empty;
                string Issuer_Settlement_Fee = string.Empty;
                string Issuer_Settlement_Processing_Fee = string.Empty;
                string Cardholder_Billing_Currency_Code = string.Empty;
                string Cardholder_Billing_Amount = string.Empty;
                string Cardholder_Billing_Activity_Fee = string.Empty;
                string Cardholder_Billing_Processing_Fee = string.Empty;
                string Cardholder_Billing_Service_Fee = string.Empty;
                string Transaction_Issuer_Conversion_Rate = string.Empty;
                string Transaction_Cardholder_Conversion_Rate = string.Empty;

                string CardScheme = string.Empty;
                string IssuingNetwork = "NPCI";

                for (int i = 0; i < totalrecords; i++)
                {
                    try
                    {
                        m_RecordData = arrLines[i];

                        Participant_ID = m_RecordData.Substring(0, 2).Trim();
                        Transaction_Type = m_RecordData.Substring(3, 2).Trim();
                        From_Account_Type = m_RecordData.Substring(5, 2).Trim();
                        To_Account_Type = m_RecordData.Substring(7, 2).Trim();
                        Transaction_Serial_Number = m_RecordData.Substring(9, 12).Trim();
                        Response_Code = m_RecordData.Substring(21, 2).Trim();
                        PAN_Number = m_RecordData.Substring(23, 19).Trim();
                        Member_Number = m_RecordData.Substring(42, 1).Trim();
                        Approval_Number = m_RecordData.Substring(43, 6).Trim();
                        System_Trace_Audit_Number = m_RecordData.Substring(49, 12).Trim();
                        auditno = 0;
                        if (!int.TryParse(System_Trace_Audit_Number, out auditno))
                        {
                            System_Trace_Audit_Number = "0";
                        }

                        Transaction_Date = m_RecordData.Substring(61, 6).Trim();
                        Transaction_Time = m_RecordData.Substring(67, 6).Trim();

                        timestamp = Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + "-" + Transaction_Date.Substring(4, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                        DateTime _datetime = DateTime.ParseExact(timestamp, "yy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);

                        Merchant_Category_Code_ = m_RecordData.Substring(73, 4).Trim();
                        if (Merchant_Category_Code_.Trim() == "")
                        {
                            Merchant_Category_Code_ = "0";
                        }
                        Card_Acceptor_Settlement_Date = m_RecordData.Substring(77, 6).Trim();
                        if (Card_Acceptor_Settlement_Date.Trim() == "")
                        {
                            Card_Acceptor_Settlement_Date = "0";
                        }
                        Card_Acceptor_ID = m_RecordData.Substring(83, 15).Trim();
                        Card_Acceptor_Terminal_ID = m_RecordData.Substring(98, 8).Trim();
                        Card_Acceptor_Terminal_Location = m_RecordData.Substring(106, 40).Trim();
                        Acquirer_ID = m_RecordData.Substring(146, 11).Trim();
                        Network_ID = m_RecordData.Substring(157, 3).Trim();
                        Account_1_Number = m_RecordData.Substring(160, 19).Trim();
                        Account_1_Branch_ID = m_RecordData.Substring(179, 10).Trim();
                        Account_2_Number = m_RecordData.Substring(189, 19).Trim();
                        Account_2_Branch_ID = m_RecordData.Substring(208, 10).Trim();
                        Transaction_Currency_Code = m_RecordData.Substring(218, 3).Trim();
                        //Eliminated Last two digit

                        Transaction_Amount = m_RecordData.Substring(221, 15).Trim();
                        if (Transaction_Amount.Trim() == "")
                        {
                            Transaction_Amount = "0";
                        }
                        //try
                        //{
                        //    if ((ClientID == 12 && ModeID == 4) || (ClientID == 37 && ModeID == 4))
                        //    {
                        //        AMT = decimal.Parse(Transaction_Amount);
                        //        decimal AMT1 = (AMT / 100);
                        //        Transaction_Amount = Convert.ToString(AMT1);
                        //    }
                        //    else
                        //    {
                        //        Transaction_Amount = m_RecordData.Substring(221, 15).Trim();
                        //    }
                        //}
                        //catch (Exception)
                        //{


                        //}


                        Actual_Transaction_Amount = m_RecordData.Substring(236, 13).Trim();
                        if (Actual_Transaction_Amount.Trim() == "")
                        {
                            Actual_Transaction_Amount = "0";
                        }
                        //***********//
                        Transaction_Activity_Fee = m_RecordData.Substring(251, 15).Trim();
                        if (Transaction_Activity_Fee.Trim() == "")
                        {
                            Transaction_Activity_Fee = "0";
                        }

                        Issuer_Settlement_Currency_Code = m_RecordData.Substring(266, 3).Trim();
                        Issuer_Settlement_Amount = m_RecordData.Substring(269, 13).Trim();
                        if (Issuer_Settlement_Amount.Trim() == "")
                        {
                            Issuer_Settlement_Amount = "0";
                        }

                        Issuer_Settlement_Fee = m_RecordData.Substring(284, 15).Trim();
                        if (Issuer_Settlement_Fee.Trim() == "")
                        {
                            Issuer_Settlement_Fee = "0";
                        }

                        Issuer_Settlement_Processing_Fee = m_RecordData.Substring(299, 15).Trim();
                        if (Issuer_Settlement_Processing_Fee.Trim() == "")
                        {
                            Issuer_Settlement_Processing_Fee = "0";
                        }

                        Cardholder_Billing_Currency_Code = m_RecordData.Substring(314, 3).Trim();
                        Cardholder_Billing_Amount = m_RecordData.Substring(317, 15).Trim();
                        if (Cardholder_Billing_Amount.Trim() == "")
                        {
                            Cardholder_Billing_Amount = "0";
                        }

                        Cardholder_Billing_Activity_Fee = m_RecordData.Substring(332, 15).Trim();
                        if (Cardholder_Billing_Activity_Fee.Trim() == "")
                        {
                            Cardholder_Billing_Activity_Fee = "0";
                        }

                        Cardholder_Billing_Processing_Fee = m_RecordData.Substring(347, 15).Trim();
                        if (Cardholder_Billing_Processing_Fee.Trim() == "")
                        {
                            Cardholder_Billing_Processing_Fee = "0";
                        }

                        Cardholder_Billing_Service_Fee = m_RecordData.Substring(362, 15).Trim();
                        if (Cardholder_Billing_Service_Fee.Trim() == "")
                        {
                            Cardholder_Billing_Service_Fee = "0";
                        }

                        Transaction_Issuer_Conversion_Rate = m_RecordData.Substring(377, 15).Trim();
                        if (Transaction_Issuer_Conversion_Rate.Trim() == "")
                        {
                            Transaction_Issuer_Conversion_Rate = "0";
                        }

                        Transaction_Cardholder_Conversion_Rate = m_RecordData.Substring(392, 15).Trim();
                        if (Transaction_Cardholder_Conversion_Rate.Trim() == "")
                        {
                            Transaction_Cardholder_Conversion_Rate = "0";
                        }

                        _DataTable.Rows.Add(ClientID, Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code,
                                        PAN_Number, Member_Number, Approval_Number, System_Trace_Audit_Number, _datetime, Transaction_Time, Merchant_Category_Code_,
                                        Card_Acceptor_Settlement_Date, Card_Acceptor_ID, Card_Acceptor_Terminal_ID, Card_Acceptor_Terminal_Location, Acquirer_ID, Network_ID,
                                        Account_1_Number, Account_1_Branch_ID, Account_2_Number, Account_2_Branch_ID, Transaction_Currency_Code, Transaction_Amount,
                                        Actual_Transaction_Amount, Transaction_Activity_Fee, Issuer_Settlement_Currency_Code, Issuer_Settlement_Amount, Issuer_Settlement_Fee,
                                        Issuer_Settlement_Processing_Fee, Cardholder_Billing_Currency_Code, Cardholder_Billing_Amount, Cardholder_Billing_Activity_Fee,
                                        Cardholder_Billing_Processing_Fee, Cardholder_Billing_Service_Fee, Transaction_Issuer_Conversion_Rate, Transaction_Cardholder_Conversion_Rate,
                                        System.DateTime.Now, System.DateTime.Now, UserName, UserName, Cycle, FileName, FileDate, path, CardScheme, IssuingNetwork);

                        LineNo++;
                    }
                    catch (Exception ex)
                    {
                        InsertCount--;
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                }


                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;

                }


            }
            catch (Exception ex)
            {
                InsertCount--;
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            return _DataTable;

        }

        public DataTable SplitterIMPSIssuerCSV(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifyBy", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));


            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            //string EMekKey1 = ConfigurationSettings.AppSettings["MekKey1"].ToString();
            //string EMekKey2 = ConfigurationSettings.AppSettings["MekKey2"].ToString();
            //string StrCon = DAL.Comman.ConnectionString(); //ConfigurationSettings.AppSettings["con"].ToString();
            //ConfigurationDAL objConfigurationDAL = new ConfigurationDAL();
            //DataSet dsDEK = objConfigurationDAL.GetEncryptedDEK();
            //DataSet dsCardNetwork = objConfigurationDAL.GetCardNetwork();

            //AesEncryption.ClearMEK = AesEncryption.DecryptEncryptedMEK(EMekKey1);
            //AesEncryption.ClearMEK2 = AesEncryption.DecryptEncryptedMEK(EMekKey2);
            //string DEK = AesEncryption.DecryptEncryptedDEK(dsDEK.Tables[0].Rows[0]["TMK_LMK"].ToString(), AesEncryption.ClearMEK2);
            //

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            // bool TxnAmountIsDecimal = Convert.ToBoolean(dt.Rows[0]["TxnAmountIsDecimal"]);
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            DateTime? Transaction_Date = null;

            string strFileName = Path.GetFileNameWithoutExtension(path);
            string FD = strFileName.Substring(strFileName.Length - 9);
            string[] FDA = FD.Split('_', '.');
            DateTime FileDate = DateTime.ParseExact(FDA[0], "ddMMyy", CultureInfo.InvariantCulture);
            string Cycle = FDA[1].ToString();

            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string MEMNUMBER = string.Empty;
            string Approval_Number = string.Empty;
            string STAUDITNO = "0";
            string TransDate = string.Empty;
            string Transaction_Time = string.Empty;
            string Merchant_Category_Code = string.Empty;
            string CARDACCEPTSETDATE = string.Empty;
            string Card_Acceptor_ID = string.Empty;
            string CARDACCEPTTERMINALID = string.Empty;
            string CARDACCEPTERTERLOCATION = string.Empty;
            string Acquirer_ID = string.Empty;
            string NETWORKID = string.Empty;
            string Ben_Account_Number = string.Empty;
            string Bene_IFSC_CODE = string.Empty;
            string REM_ACCOUNT_NUMBER = string.Empty;
            string REM_IFSC_CODE = string.Empty;
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = "0";
            string ACCTUALTRANAMOUNT = "0";
            string TRANSACCVITYFEE = "0";
            string ISSUERSETCURRENCYCODE = string.Empty;
            string ISSURESETAMOUNT = "0";
            string ISSUERSETFEE = "0";
            string ISSURESETPROCFEE = "0";
            string CARDHOLDERBILLCURNCCODE = string.Empty;
            string CARDHOLDERBILLAMOUNT = "0";
            string CARDHOLDERBILACTFEE = "0";
            string CARDHOLDERBILPROFEE = "0";
            string CARDHOLDERBILSRVICEFEE = "0";
            string TRAN_ISSUERCONVERSRATE = "0";
            string TRANS_CARDHOLDERCONVERRATE = "0";

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            int Incr = 1;

            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    string line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);
                    //string Cycle = FileName.Substring(15, 1).ToString();
                    //string FD = FileName.Substring(8, 2).ToString() + "-" + FileName.Substring(10, 2).ToString() + "-" + FileName.Substring(12, 2).ToString();
                    //DateTime FileDate = DateTime.ParseExact(FD, "MM-dd-yy", CultureInfo.InvariantCulture);
                    string[] SplitArr = line1.Split(',');
                    if (SplitArr[0].Contains("Participant_ID"))
                        continue;

                    if (ds.Tables[0].Rows[0]["PARICIPATEID"].ToString() != "0")
                    {
                        Participant_ID = SplitArr[int.Parse(ds.Tables[0].Rows[0]["PARICIPATEID"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TRANSACTIONTYPE"].ToString() != "0")
                    {
                        Transaction_Type = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TRANSACTIONTYPE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["FROMACCOUNTTYPE"].ToString() != "0")
                    {
                        From_Account_Type = SplitArr[int.Parse(ds.Tables[0].Rows[0]["FROMACCOUNTTYPE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TOACCOUNTTYPE"].ToString() != "0")
                    {
                        To_Account_Type = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TOACCOUNTTYPE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TRANSSERIALNO"].ToString() != "0")
                    {
                        Transaction_Serial_Number = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TRANSSERIALNO"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["RESPONSECODE"].ToString() != "0")
                    {
                        Response_Code = SplitArr[int.Parse(ds.Tables[0].Rows[0]["RESPONSECODE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["PANNUMBER"].ToString() != "0")
                    {
                        PAN_Number = SplitArr[int.Parse(ds.Tables[0].Rows[0]["PANNUMBER"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["MEMNUMBER"].ToString() != "0")
                    {
                        MEMNUMBER = SplitArr[int.Parse(ds.Tables[0].Rows[0]["MEMNUMBER"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["APPROVNO"].ToString() != "0")
                    {
                        Approval_Number = SplitArr[int.Parse(ds.Tables[0].Rows[0]["APPROVNO"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["STAUDITNO"].ToString() != "0")
                    {
                        STAUDITNO = SplitArr[int.Parse(ds.Tables[0].Rows[0]["STAUDITNO"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TRANSACTIONDATE"].ToString() != "0")
                    {
                        TransDate = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TRANSACTIONDATE"].ToString()) - Incr].ToString().Trim();

                        Transaction_Date = DateTime.ParseExact(TransDate, "yyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None);
                    }
                    if (ds.Tables[0].Rows[0]["TRANSACTIONTIME"].ToString() != "0")
                    {
                        Transaction_Time = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TRANSACTIONTIME"].ToString()) - Incr].ToString().Trim();

                        Transaction_Date = DateTime.ParseExact(TransDate + " " + Transaction_Time, "yyMMdd HHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None);
                    }
                    if (ds.Tables[0].Rows[0]["MERCHENTCATCODE"].ToString() != "0")
                    {
                        Merchant_Category_Code = SplitArr[int.Parse(ds.Tables[0].Rows[0]["MERCHENTCATCODE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["CARDACCEPTSETDATE"].ToString() != "0")
                    {
                        CARDACCEPTSETDATE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["CARDACCEPTSETDATE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["CARDACCEPTORID"].ToString() != "0")
                    {
                        Card_Acceptor_ID = SplitArr[int.Parse(ds.Tables[0].Rows[0]["CARDACCEPTORID"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["CARDACCEPTTERMINALID"].ToString() != "0")
                    {
                        CARDACCEPTTERMINALID = SplitArr[int.Parse(ds.Tables[0].Rows[0]["CARDACCEPTTERMINALID"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["CARDACCEPTERTERLOCATION"].ToString() != "0")
                    {
                        CARDACCEPTERTERLOCATION = SplitArr[int.Parse(ds.Tables[0].Rows[0]["CARDACCEPTERTERLOCATION"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["ACQUIRERID"].ToString() != "0")
                    {
                        Acquirer_ID = SplitArr[int.Parse(ds.Tables[0].Rows[0]["ACQUIRERID"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["NETWORKID"].ToString() != "0")
                    {
                        NETWORKID = SplitArr[int.Parse(ds.Tables[0].Rows[0]["NETWORKID"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["ACCOUNTNO1"].ToString() != "0")
                    {
                        Ben_Account_Number = SplitArr[int.Parse(ds.Tables[0].Rows[0]["ACCOUNTNO1"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["ACCOUNTBRANCHID"].ToString() != "0")
                    {
                        Bene_IFSC_CODE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["ACCOUNTBRANCHID"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["ACCOUNTNO2"].ToString() != "0")
                    {
                        REM_ACCOUNT_NUMBER = SplitArr[int.Parse(ds.Tables[0].Rows[0]["ACCOUNTNO2"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["ACCOUNT2BRANCHID"].ToString() != "0")
                    {
                        REM_IFSC_CODE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["ACCOUNT2BRANCHID"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TRANSCURRENCYCODE"].ToString() != "0")
                    {
                        Transaction_Currency_Code = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TRANSCURRENCYCODE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TRANSAMOUNT"].ToString() != "0")
                    {
                        Transaction_Amount = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TRANSAMOUNT"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["ACCTUALTRANAMOUNT"].ToString() != "0")
                    {
                        ACCTUALTRANAMOUNT = SplitArr[int.Parse(ds.Tables[0].Rows[0]["ACCTUALTRANAMOUNT"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TRANSACCVITYFEE"].ToString() != "0")
                    {
                        TRANSACCVITYFEE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TRANSACCVITYFEE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["ISSUERSETCURRENCYCODE"].ToString() != "0")
                    {
                        ISSUERSETCURRENCYCODE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["ISSUERSETCURRENCYCODE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["ISSURESETAMOUNT"].ToString() != "0")
                    {
                        ISSURESETAMOUNT = SplitArr[int.Parse(ds.Tables[0].Rows[0]["ISSURESETAMOUNT"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["ISSUERSETFEE"].ToString() != "0")
                    {
                        ISSUERSETFEE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["ISSUERSETFEE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["ISSURESETPROCFEE"].ToString() != "0")
                    {
                        ISSURESETPROCFEE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["ISSURESETPROCFEE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["CARDHOLDERBILLCURNCCODE"].ToString() != "0")
                    {
                        CARDHOLDERBILLCURNCCODE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["CARDHOLDERBILLCURNCCODE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["CARDHOLDERBILLAMOUNT"].ToString() != "0")
                    {
                        CARDHOLDERBILLAMOUNT = SplitArr[int.Parse(ds.Tables[0].Rows[0]["CARDHOLDERBILLAMOUNT"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["CARDHOLDERBILACTFEE"].ToString() != "0")
                    {
                        CARDHOLDERBILACTFEE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["CARDHOLDERBILACTFEE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["CARDHOLDERBILPROFEE"].ToString() != "0")
                    {
                        CARDHOLDERBILPROFEE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["CARDHOLDERBILPROFEE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["CARDHOLDERBILSRVICEFEE"].ToString() != "0")
                    {
                        CARDHOLDERBILSRVICEFEE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["CARDHOLDERBILSRVICEFEE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TRAN_ISSUERCONVERSRATE"].ToString() != "0")
                    {
                        TRAN_ISSUERCONVERSRATE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TRAN_ISSUERCONVERSRATE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TRANS_CARDHOLDERCONVERRATE"].ToString() != "0")
                    {
                        TRANS_CARDHOLDERCONVERRATE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TRANS_CARDHOLDERCONVERRATE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TRAN_ISSUERCONVERSRATE"].ToString() != "0")
                    {
                        TRAN_ISSUERCONVERSRATE = SplitArr[int.Parse(ds.Tables[0].Rows[0]["TRAN_ISSUERCONVERSRATE"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["CardScheme"].ToString() != "0")
                    {
                        CardScheme = SplitArr[int.Parse(ds.Tables[0].Rows[0]["CardScheme"].ToString()) - Incr].ToString().Trim();
                    }


                    _DataTable.Rows.Add(ClientID, Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code, PAN_Number, MEMNUMBER,
                                       Approval_Number, STAUDITNO, Transaction_Date, Transaction_Time, Merchant_Category_Code, CARDACCEPTSETDATE, Card_Acceptor_ID, CARDACCEPTTERMINALID, CARDACCEPTERTERLOCATION,
                                       Acquirer_ID, NETWORKID, Ben_Account_Number, Bene_IFSC_CODE, REM_ACCOUNT_NUMBER, REM_IFSC_CODE, Transaction_Currency_Code, Transaction_Amount, ACCTUALTRANAMOUNT,
                                       TRANSACCVITYFEE, ISSUERSETCURRENCYCODE, ISSURESETAMOUNT, ISSUERSETFEE, ISSURESETPROCFEE, CARDHOLDERBILLCURNCCODE, CARDHOLDERBILLAMOUNT, CARDHOLDERBILACTFEE, CARDHOLDERBILPROFEE,
                                       CARDHOLDERBILSRVICEFEE, TRAN_ISSUERCONVERSRATE, TRANS_CARDHOLDERCONVERRATE,
                                        System.DateTime.Now, System.DateTime.Now, UserName, UserName, Cycle, FileName, FileDate, path, CardScheme, IssuingNetwork);

                    LineNo++;
                    InsertCount++;

                }
                catch (Exception ex)
                {
                    InsertCount--;
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

                }


            }

            return _DataTable;

        }

        public DataTable SplitterIMPSAdjustment(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("TxnUID", typeof(string));
            //_DataTable.Columns.Add("TxnType", typeof(string));
            _DataTable.Columns.Add("UID", typeof(string));
            _DataTable.Columns.Add("AdjDate", typeof(DateTime));
            _DataTable.Columns.Add("AdjType", typeof(string));
            _DataTable.Columns.Add("Remitter", typeof(string));
            _DataTable.Columns.Add("Beneficiery", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("TxnDateTime", typeof(DateTime));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TerminalID", typeof(string));
            _DataTable.Columns.Add("Ben_Mobile_No", typeof(string));
            _DataTable.Columns.Add("Rem_Mobile_No", typeof(string));
            _DataTable.Columns.Add("ChargebackDate", typeof(DateTime));
            _DataTable.Columns.Add("Chbref", typeof(string));
            _DataTable.Columns.Add("TxnAmount", typeof(decimal));
            _DataTable.Columns.Add("AdjAmount", typeof(decimal));
            _DataTable.Columns.Add("Rem_Fee", typeof(decimal));
            _DataTable.Columns.Add("Ben_Fee", typeof(decimal));
            _DataTable.Columns.Add("BenFeeSW", typeof(decimal));
            _DataTable.Columns.Add("AdjFee", typeof(decimal));
            _DataTable.Columns.Add("NPCIFee", typeof(decimal));
            _DataTable.Columns.Add("RemFeeGST", typeof(decimal));
            _DataTable.Columns.Add("BenFeeGST", typeof(decimal));
            _DataTable.Columns.Add("NPCIGST", typeof(decimal));
            _DataTable.Columns.Add("AdjRef", typeof(string));
            _DataTable.Columns.Add("BankAdjRef", typeof(string));
            _DataTable.Columns.Add("AdjProof", typeof(string));
            _DataTable.Columns.Add("Cust_Comp", typeof(string));
            _DataTable.Columns.Add("Adj_Raise_Time", typeof(string));
            _DataTable.Columns.Add("SHDT72", typeof(string));
            _DataTable.Columns.Add("SHDT73", typeof(string));
            _DataTable.Columns.Add("SHDT74", typeof(string));
            //_DataTable.Columns.Add("ADJSettlementdate", typeof(DateTime));
            _DataTable.Columns.Add("SHDT75", typeof(string));
            _DataTable.Columns.Add("SHDT76", typeof(string));
            //_DataTable.Columns.Add("TATExpDate", typeof(DateTime));
            _DataTable.Columns.Add("SHDT77", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            try
            {
                string Txnuid = string.Empty;
                string Uid = string.Empty;
                //string TxnType = string.Empty;
                DateTime AdjDate;
                string AdjType = string.Empty;
                string AcquirerBank = string.Empty;
                string IssuerBank = string.Empty;
                string ResponseCode = string.Empty;
                DateTime TxnDateTime;
                string ReferenceNumber = string.Empty;
                string TerminalID = string.Empty;
                string benmobno = string.Empty;
                string remmobno = string.Empty;
                DateTime? ChargebackDate = null;
                string chbref = string.Empty;
                decimal TxnAmount = 0;
                decimal AdjAmount = 0;
                decimal RemFee = 0;
                decimal BenFee = 0;
                decimal BenFeeSW = 0;
                decimal AdjFee = 0;
                decimal NPCIFee = 0;
                decimal RemFeegst = 0;
                decimal BenFeegst = 0;
                decimal NPCIgst = 0;
                string AdjRef = string.Empty;
                string BankAdjRef = string.Empty;
                string AdjProof = string.Empty;
                string CustComp = string.Empty;
                string AdjRaisetime = string.Empty;
                string SHDT72 = string.Empty;
                string SHDT73 = string.Empty;
                string SHDT74 = string.Empty;
                //DateTime? ADJSettlementdate = null;
                string SHDT75 = string.Empty;
                string SHDT76 = string.Empty;
                //DateTime? TatExpDate = null;
                string SHDT77 = string.Empty;
                string AcqCC = string.Empty;
                string PEMode = string.Empty;
                string ServiceCode = string.Empty;
                string CarddataInputCap = string.Empty;
                string MCCCode = string.Empty;
                string CreatedBy = string.Empty;
                DateTime CreatedOn;
                string DtTime = string.Empty;
                string Dt = string.Empty;
                string DtAdj = string.Empty;
                string DtSettle = string.Empty;
                string ModifiedBy = string.Empty;
                string d1 = string.Empty;
                string d2 = string.Empty;
                string date1 = string.Empty;
                DateTime ModifiedOn;
                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
                string[] TotalCountArray = File.ReadAllLines(path);
                TotalCount = TotalCountArray.Length;

                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;";
                string extension = Path.GetExtension(path);
                //switch (extension.ToLower())
                //{
                //    case ".xls": //Excel 97-03
                //        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";";
                //        break;
                //    case ".xlsx": //Excel 07 or higher
                //        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                //        break;
                //}

                switch (extension.ToLower())
                {

                    case ".xls": //Excel 97-03
                                 // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                                  //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;

                }

                try
                {
                    objConn = new OleDbConnection(connString);

                    if (objConn.State == ConnectionState.Open)
                    {
                        objConn.Close();
                    }



                    objConn.Open();

                }
                catch
                {
                    switch (extension.ToLower())
                    {

                        //case ".xls": //Excel 97-03
                        // // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        // connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        // //connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        // break;
                        //case ".xlsx": //Excel 07 or higher
                        // //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        // //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        // break;

                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }

                    try
                    {
                        objConn = new OleDbConnection(connString);
                        if (objConn.State == ConnectionState.Open)
                        {
                            objConn.Close();
                        }

                        objConn.Open();
                    }
                    catch
                    {
                        switch (extension.ToLower())
                        {
                            case ".xls": //Excel 97-03
                                         // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                                break;
                            case ".xlsx": //Excel 07 or higher
                                          //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                break;

                        }
                        try
                        {
                            objConn = new OleDbConnection(connString);
                            if (objConn.State == ConnectionState.Open)
                            {
                                objConn.Close();
                            }
                            objConn.Open();
                        }
                        catch
                        {
                            switch (extension.ToLower())
                            {
                                case ".xls": //Excel 97-03 xls
                                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                                    break;
                                case ".xlsx": //Excel 07 or higher xlsx
                                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                                    break;
                            }

                            try
                            {
                                objConn = new OleDbConnection(connString);
                                if (objConn.State == ConnectionState.Open)
                                {
                                    objConn.Close();
                                }
                                objConn.Open();
                            }
                            catch
                            {
                                switch (extension.ToLower())
                                {

                                    case ".xls": //Excel 97-03
                                                 // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";



                                        break;
                                    case ".xlsx": //Excel 07 or higher
                                                  //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                        break;
                                }
                                objConn = new OleDbConnection(connString);
                                if (objConn.State == ConnectionState.Open)
                                {
                                    objConn.Close();
                                }
                                //objConn.Open();
                            }



                        }
                    }

                }
                objConn = new OleDbConnection(connString);
                objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null); 
                
                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(dtexcelsheetname.Rows[0]["TABLE_NAME"]).Replace("'", "") + "]";
                //string sht = dr[2].ToString().Replace("'", "");

                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dtfillsheet1 = new DataTable();
                da.Fill(dtfillsheet1);


                objConn.Close();

                TotalCount = dtfillsheet1.Rows.Count;
                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {
                    try
                    {
                        Txnuid = dtfillsheet1.Rows[i][0].ToString().Trim();
                        Txnuid = Txnuid.Replace("=", "");
                        Txnuid = Txnuid.Replace("\"", "");


                        //Txnuid = txnid.Replace("'", "");
                        //TxnType = dtfillsheet1.Rows[i][1].ToString();
                        Uid = dtfillsheet1.Rows[i][1].ToString();
                        Uid = Uid.Replace("=", "");
                        Uid = Uid.Replace("\"", "");
                        //Uid = uid.Replace("'", "");
                        string adjdate = dtfillsheet1.Rows[i][2].ToString();
                        AdjDate = DateTime.ParseExact(adjdate.ToString(), "dd-MM-yyyy", null);
                        AdjType = dtfillsheet1.Rows[i][3].ToString();
                        AcquirerBank = dtfillsheet1.Rows[i][4].ToString();
                        IssuerBank = dtfillsheet1.Rows[i][5].ToString();
                        string Resp = dtfillsheet1.Rows[i][6].ToString();
                        ResponseCode = Resp.Replace("=", "");
                        ResponseCode = ResponseCode.Replace("\"", "");
                        d1 = dtfillsheet1.Rows[i][7].ToString();
                        d2 = dtfillsheet1.Rows[i][8].ToString();
                        date1 = d1 + " " + d2;
                        TxnDateTime = DateTime.ParseExact(date1.ToString(), "dd-MM-yyyy HH:mm:ss", null);
                        string Refno = dtfillsheet1.Rows[i][9].ToString();
                        ReferenceNumber = Refno.Replace("'", "");
                        TerminalID = dtfillsheet1.Rows[i][10].ToString();
                        string benmobno1 = dtfillsheet1.Rows[i][11].ToString();
                        benmobno = benmobno1.Replace("'", "");
                        string remmobno1 = dtfillsheet1.Rows[i][12].ToString();
                        remmobno = remmobno1.Replace("'", "");
                        string ChargebackDate1 = dtfillsheet1.Rows[i][13].ToString();
                        if (ChargebackDate1.Contains("-"))
                        {
                            ChargebackDate = null;
                        }
                        else
                        {
                            ChargebackDate = dtfillsheet1.Rows[i][13].ToString().Contains('-') == true ? (DateTime.ParseExact(dtfillsheet1.Rows[i][13].ToString(), "dd-MM-yyyy", null)) : ChargebackDate;
                        }

                        chbref = dtfillsheet1.Rows[i][14].ToString();
                        //ChargebackRemarks = chbref.Replace("'", "");
                        TxnAmount = Convert.ToDecimal(dtfillsheet1.Rows[i][15].ToString());
                        AdjAmount = Convert.ToDecimal(dtfillsheet1.Rows[i][16].ToString());
                        RemFee = Convert.ToDecimal(dtfillsheet1.Rows[i][17].ToString());
                        BenFee = Convert.ToDecimal(dtfillsheet1.Rows[i][18].ToString());
                        BenFeeSW = Convert.ToDecimal(dtfillsheet1.Rows[i][19].ToString());
                        AdjFee = Convert.ToDecimal(dtfillsheet1.Rows[i][20].ToString());
                        NPCIFee = Convert.ToDecimal(dtfillsheet1.Rows[i][21].ToString());
                        RemFeegst = Convert.ToDecimal(dtfillsheet1.Rows[i][22].ToString());
                        BenFeegst = Convert.ToDecimal(dtfillsheet1.Rows[i][23].ToString());
                        NPCIgst = Convert.ToDecimal(dtfillsheet1.Rows[i][24].ToString());
                        AdjRef = dtfillsheet1.Rows[i][25].ToString();
                        BankAdjRef = dtfillsheet1.Rows[i][26].ToString();
                        AdjProof = dtfillsheet1.Rows[i][27].ToString();
                        CustComp = dtfillsheet1.Rows[i][28].ToString();
                        AdjRaisetime = dtfillsheet1.Rows[i][29].ToString();
                        SHDT72 = dtfillsheet1.Rows[i][30].ToString();
                        //TermLoc = ATMLoc.Replace("'", "");
                        SHDT73 = dtfillsheet1.Rows[i][31].ToString();
                        SHDT74 = dtfillsheet1.Rows[i][32].ToString();
                        //ADJSettlementdate = dtfillsheet1.Rows[i][32].ToString().Contains('-') == true ? (DateTime.ParseExact(dtfillsheet1.Rows[i][32].ToString(), "dd-MM-yyyy", null)) : ADJSettlementdate;
                        SHDT75 = dtfillsheet1.Rows[i][33].ToString();
                        SHDT76 = dtfillsheet1.Rows[i][34].ToString();
                        SHDT77 = dtfillsheet1.Rows[i][35].ToString();
                        //TatExpDate = dtfillsheet1.Rows[i][36].ToString().Contains('-') == true ? (DateTime.ParseExact(dtfillsheet1.Rows[i][36].ToString(), "dd-MM-yyyy", null)) : TatExpDate;




                        _DataTable.Rows.Add(ClientID, Txnuid, Uid, AdjDate, AdjType, AcquirerBank, IssuerBank, ResponseCode, TxnDateTime, ReferenceNumber, TerminalID,
                                benmobno, remmobno, ChargebackDate, chbref, TxnAmount, AdjAmount, RemFee, BenFee, BenFeeSW, AdjFee, NPCIFee, RemFeegst, BenFeegst,
                                NPCIgst, AdjRef, BankAdjRef, AdjProof, CustComp, AdjRaisetime, SHDT72, SHDT73, SHDT74, SHDT75, SHDT76,
                                SHDT77, UserName, System.DateTime.Now, UserName, System.DateTime.Now);
                        InsertCount++;


                    }
                    catch (Exception EX)
                    {
                        //_DataTable.Rows.Clear();
                        DBLog.InsertLogs(EX.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        // variable();
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                    //_log.FunErrorLog("Transaction not found", BankCode, "ProcessGLLogSpliter", "ProcessLogSpliterBOB", LineNo, FileName, UserName, 'E');
                    // variable();
                }
            }
            catch (Exception EX)
            {
                //_DataTable.Rows.Clear();
                DBLog.InsertLogs(EX.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                //  variable();
            }
            return _DataTable;
        }

        public DataTable SplitterSettlementIMPS(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("NoTxns", typeof(int));
            _DataTable.Columns.Add("Debit", typeof(string));
            _DataTable.Columns.Add("‎Credit", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));
            _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            //string EMekKey1 = ConfigurationSettings.AppSettings["MekKey1"].ToString();
            //string EMekKey2 = ConfigurationSettings.AppSettings["MekKey2"].ToString();
            //string StrCon = DAL.Comman.ConnectionString(); //ConfigurationSettings.AppSettings["con"].ToString();
            //ConfigurationDAL objConfigurationDAL = new ConfigurationDAL();
            //DataSet dsDEK = objConfigurationDAL.GetEncryptedDEK();
            //DataSet dsCardNetwork = objConfigurationDAL.GetCardNetwork();
            //AesEncryption.ClearMEK = AesEncryption.DecryptEncryptedMEK(EMekKey1);
            //AesEncryption.ClearMEK2 = AesEncryption.DecryptEncryptedMEK(EMekKey2);
            //string DEK = AesEncryption.DecryptEncryptedDEK(dsDEK.Tables[0].Rows[0]["TMK_LMK"].ToString(), AesEncryption.ClearMEK2);
            //

            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            InsertCount = 0;
            TotalCount = 0;

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            DataTable dtexcelsheetname = null;
            try
            {
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                OleDbConnection objConn = new OleDbConnection(connString);
                string extension = Path.GetExtension(path);
                //switch (extension.ToLower())
                //{

                //    case ".xls": //Excel 97-03
                //        // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                //        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                //        break;
                //    case ".xlsx": //Excel 07 or higher
                //        //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                //        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                //        break;

                //}

                //try
                //{
                //    objConn = new OleDbConnection(connString);
                //    objConn.Open();
                //}
                //catch
                //{
                //    switch (extension.ToLower())
                //    {


                //        case ".xls": //Excel 97-03
                //            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                //            break;
                //        case ".xlsx": //Excel 07 or higher
                //            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                //            break;
                //    }
                //    objConn = new OleDbConnection(connString);
                //    objConn.Open();
                //}

                switch (extension.ToLower())
                {

                    case ".xls": //Excel 97-03
                                 // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                    case ".xlsx": //Excel 07 or higher
                                  //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;

                }

                try
                {
                    objConn = new OleDbConnection(connString);



                    if (objConn.State == ConnectionState.Open)
                    {
                        objConn.Close();
                    }

                    objConn.Open();

                }
                catch
                {
                    switch (extension.ToLower())
                    {

                        //case ".xls": //Excel 97-03
                        // // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        // connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        // //connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        // break;
                        //case ".xlsx": //Excel 07 or higher
                        // //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        // //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        // break;



                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }

                    try
                    {
                        objConn = new OleDbConnection(connString);
                        if (objConn.State == ConnectionState.Open)
                        {
                            objConn.Close();
                        }

                        objConn.Open();
                    }
                    catch
                    {
                        switch (extension.ToLower())
                        {
                            case ".xls": //Excel 97-03
                                         // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                                connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                break;
                            case ".xlsx": //Excel 07 or higher
                                          //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                break;
                        }
                        try
                        {
                            objConn = new OleDbConnection(connString);
                            if (objConn.State == ConnectionState.Open)
                            {
                                objConn.Close();
                            }
                            objConn.Open();
                        }
                        catch
                        {
                            switch (extension.ToLower())
                            {
                                case ".xls": //Excel 97-03 xls
                                    connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                                    break;
                                case ".xlsx": //Excel 07 or higher xlsx
                                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                                    break;
                            }

                            try
                            {
                                objConn = new OleDbConnection(connString);
                                if (objConn.State == ConnectionState.Open)
                                {
                                    objConn.Close();
                                }
                                objConn.Open();
                            }
                            catch
                            {
                                switch (extension.ToLower())
                                {

                                    case ".xls": //Excel 97-03
                                                 // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";



                                        break;
                                    case ".xlsx": //Excel 07 or higher
                                                  //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                                        break;
                                }
                                objConn = new OleDbConnection(connString);
                                objConn.Open();
                            }

                        }
                    }

                }

                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                int j = 0;
                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    excelSheets[j] = row["TABLE_NAME"].ToString();
                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                    //string sht = dr[2].ToString().Replace("'", "");

                    OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataTable dtSheet = new DataTable();
                    da.Fill(dtSheet);
                    objConn.Close();

                    if (dtSheet.Rows.Count > 1)
                    {
                        DateTime? Date;
                        Date = null;
                        string[] Filesplit = FileName.Split('_');
                        string[] Cycle = Filesplit[1].Split('.');
                        string DateArray = FileName.Substring(11, 2).ToString() + "-" + FileName.Substring(13, 2).ToString() + "-" + FileName.Substring(15, 2).ToString();
                        Date = DateTime.ParseExact(DateArray.ToString(), "dd-MM-yy", null);

                        int Incr = 1;
                        string Description = string.Empty;
                        int NoTxns = 0;
                        decimal Debit = 0;
                        decimal Credit = 0;
                        string Remarks = string.Empty;

                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            Incr = 1;
                            Description = string.Empty;
                            NoTxns = 0;
                            Debit = 0;
                            Credit = 0;
                            Remarks = string.Empty;

                            try
                            {

                                if (ds.Tables[0].Rows[0]["Description"].ToString() != "0")
                                {
                                    Description = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Description"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["NoTxns"].ToString() != "0")
                                {
                                    NoTxns = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["NoTxns"].ToString()) - Incr].ToString() != "" ? Convert.ToInt32(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["NoTxns"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Debit"].ToString() != "0")
                                {
                                    Debit = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Debit"].ToString()) - Incr].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Debit"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Credit"].ToString() != "0")
                                {
                                    Credit = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Credit"].ToString()) - Incr].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Credit"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Remarks"].ToString() != "")
                                {
                                    Remarks = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Remarks"].ToString()) - Incr].ToString();
                                }

                                //Description = dtSheet.Rows[k][0].ToString();
                                //NoTxns = dtSheet.Rows[k][1].ToString() != "" ? Convert.ToInt32(dtSheet.Rows[k][1].ToString()) : 0;
                                //Debit = dtSheet.Rows[k][2].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][2].ToString()) : 0;
                                //Credit = dtSheet.Rows[k][3].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][3].ToString()) : 0;

                            }
                            catch (Exception ex)
                            {
                                ErrorCount++;
                            }
                            LineNo++;
                            if (Description != "" && (Debit > 0 || Credit > 0))
                                _DataTable.Rows.Add(Date, Cycle[0].ToString().Trim(), Description, NoTxns, Debit, Credit, Remarks, ClientID, FileName, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);
                            InsertCount++;
                            j++;
                        }
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "NPCIIMPS.cs", "SplitData", LineNo, FileName, UserName, 'E');
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;

        }


        public DataTable SplitterNPCIAcquirerATM(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            DateTime? Filedate;
            Filedate = null;









            DataSet ds = new DataSet();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(DateTime));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(decimal));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(decimal));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(decimal));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(decimal));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("NoOfDuplicate", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = "1";
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            string file = System.IO.Path.GetFileNameWithoutExtension(FileName);
            string[] FileFormat = file.Substring(file.Length - 9, 9).Split('_');
            Filedate = DateTime.ParseExact(FileFormat[0].ToString(), "ddMMyy", CultureInfo.InvariantCulture);

            int Incr = 1;
            string PARTICIPENTID = string.Empty;
            string TRANSTYPE = string.Empty;
            string FROMACCTYPE = string.Empty;
            string TOACCTYPE = string.Empty;
            string ReferenceNumber = string.Empty;
            string RESPONSECODE = string.Empty;
            string CardNumber = string.Empty;
            string MEMNUMBER = string.Empty;
            string APPROVALNO = string.Empty;
            string SYSTRACAUDITNO = string.Empty;
            string TxnsDateTime = string.Empty;
            string TRANSTIME = string.Empty;
            string MERCHANTCATCODE = string.Empty;
            string CARDACCEPTERSETDATE = string.Empty;
            string CARDACCID = string.Empty;
            string TerminalId = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string ACCIQUIERID = string.Empty;
            string ACCSETDATE = string.Empty;
            string TRANSCURCODE = string.Empty;
            string TxnsAmount = "0";
            string ACCTUALTRANSAMOUNT = "0";
            string TRANSACTIVITYFEE = "0";
            string ACCURSETCURCODE = "0";
            string ACQUIERSETAMOUNT = "0";
            string ACQUIERSETFEE = "0";
            string ACQUIERSETPROFEE = "0";
            string TRANSACQUIERCONVERRATE = "0";
            string ECardNumber = string.Empty;
            string line1 = string.Empty;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            #region StanderedField
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain;
            TxnsDateTimeMain = null;

            DateTime? ACCSETDATEMain;
            ACCSETDATEMain = null;

            DateTime? CARDACCEPTERSETDATEMain;
            CARDACCEPTERSETDATEMain = null;

            #endregion StanderedField 

            int Start; int End;

            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;

                try
                {
                    line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                    //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                    Incr = 1;
                    PARTICIPENTID = string.Empty;
                    TRANSTYPE = string.Empty;
                    FROMACCTYPE = string.Empty;
                    TOACCTYPE = string.Empty;
                    ReferenceNumber = string.Empty;
                    RESPONSECODE = string.Empty;
                    CardNumber = string.Empty;
                    MEMNUMBER = string.Empty;
                    APPROVALNO = string.Empty;
                    SYSTRACAUDITNO = string.Empty;
                    TxnsDateTime = string.Empty;
                    TRANSTIME = string.Empty;
                    MERCHANTCATCODE = string.Empty;
                    CARDACCEPTERSETDATE = string.Empty;
                    CARDACCID = string.Empty;
                    TerminalId = string.Empty;
                    CARDACCEPTERTERLOC = string.Empty;
                    ACCIQUIERID = string.Empty;
                    ACCSETDATE = string.Empty;
                    TRANSCURCODE = string.Empty;
                    TxnsAmount = "0";
                    ACCTUALTRANSAMOUNT = "0";
                    TRANSACTIVITYFEE = "0";
                    ACCURSETCURCODE = "0";
                    ACQUIERSETAMOUNT = "0";
                    ACQUIERSETFEE = "0";
                    ACQUIERSETPROFEE = "0";
                    TRANSACQUIERCONVERRATE = "0";
                    ECardNumber = string.Empty;
                    CardScheme = string.Empty;

                    if (ds.Tables["PARTICIPENTID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PARTICIPENTID"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["PARTICIPENTID"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["PARTICIPENTID"].Rows[0]["Length"].ToString());
                        PARTICIPENTID = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TRANSTYPE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRANSTYPE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TRANSTYPE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRANSTYPE"].Rows[0]["Length"].ToString());
                        TRANSTYPE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["FROMACCTYPE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FROMACCTYPE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["FROMACCTYPE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["FROMACCTYPE"].Rows[0]["Length"].ToString());
                        FROMACCTYPE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TOACCTYPE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TOACCTYPE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TOACCTYPE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TOACCTYPE"].Rows[0]["Length"].ToString());
                        TOACCTYPE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReferenceNumber"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ReferenceNumber"].Rows[0]["Length"].ToString());
                        ReferenceNumber = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["RESPONSECODE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["RESPONSECODE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["RESPONSECODE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["RESPONSECODE"].Rows[0]["Length"].ToString());
                        RESPONSECODE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["CardNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardNumber"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CardNumber"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CardNumber"].Rows[0]["Length"].ToString());
                        CardNumber = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["MEMNUMBER"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MEMNUMBER"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["MEMNUMBER"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["MEMNUMBER"].Rows[0]["Length"].ToString());
                        MEMNUMBER = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["APPROVALNO"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["APPROVALNO"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["APPROVALNO"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["APPROVALNO"].Rows[0]["Length"].ToString());
                        APPROVALNO = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["SYSTRACAUDITNO"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SYSTRACAUDITNO"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["SYSTRACAUDITNO"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["SYSTRACAUDITNO"].Rows[0]["Length"].ToString());
                        SYSTRACAUDITNO = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsDateTime"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TxnsDateTime"].Rows[0]["Length"].ToString());
                        TxnsDateTime = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TRANSTIME"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRANSTIME"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TRANSTIME"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRANSTIME"].Rows[0]["Length"].ToString());
                        TRANSTIME = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["MERCHANTCATCODE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MERCHANTCATCODE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["MERCHANTCATCODE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["MERCHANTCATCODE"].Rows[0]["Length"].ToString());
                        MERCHANTCATCODE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["CARDACCEPTERSETDATE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDACCEPTERSETDATE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDACCEPTERSETDATE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDACCEPTERSETDATE"].Rows[0]["Length"].ToString());
                        CARDACCEPTERSETDATE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["CARDACCID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDACCID"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDACCID"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDACCID"].Rows[0]["Length"].ToString());
                        CARDACCID = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TerminalId"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalId"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TerminalId"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TerminalId"].Rows[0]["Length"].ToString());
                        TerminalId = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["CARDACCEPTERTERLOC"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDACCEPTERTERLOC"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDACCEPTERTERLOC"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDACCEPTERTERLOC"].Rows[0]["Length"].ToString());
                        CARDACCEPTERTERLOC = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["ACCIQUIERID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACCIQUIERID"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACCIQUIERID"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACCIQUIERID"].Rows[0]["Length"].ToString());
                        ACCIQUIERID = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["ACCSETDATE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACCSETDATE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACCSETDATE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACCSETDATE"].Rows[0]["Length"].ToString());
                        ACCSETDATE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TRANSCURCODE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRANSCURCODE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TRANSCURCODE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRANSCURCODE"].Rows[0]["Length"].ToString());
                        TRANSCURCODE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TxnsAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsAmount"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TxnsAmount"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TxnsAmount"].Rows[0]["Length"].ToString());
                        TxnsAmount = line1.Substring(Start - Incr, End);
                        TxnsAmount = TxnsAmount.Substring(0, 13) + '.' + TxnsAmount.Substring(13, 2);
                    }
                    if (ds.Tables["ACCTUALTRANSAMOUNT"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACCTUALTRANSAMOUNT"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACCTUALTRANSAMOUNT"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACCTUALTRANSAMOUNT"].Rows[0]["Length"].ToString());
                        ACCTUALTRANSAMOUNT = line1.Substring(Start - Incr, End);
                        ACCTUALTRANSAMOUNT = ACCTUALTRANSAMOUNT.Substring(0, 13) + '.' + ACCTUALTRANSAMOUNT.Substring(13, 2);
                    }
                    if (ds.Tables["TRANSACTIVITYFEE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRANSACTIVITYFEE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TRANSACTIVITYFEE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRANSACTIVITYFEE"].Rows[0]["Length"].ToString());
                        TRANSACTIVITYFEE = line1.Substring(Start - Incr, End);
                        TRANSACTIVITYFEE = TRANSACTIVITYFEE.Substring(0, 13) + '.' + TRANSACTIVITYFEE.Substring(13, 2);
                    }
                    if (ds.Tables["ACCURSETCURCODE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACCURSETCURCODE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACCURSETCURCODE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACCURSETCURCODE"].Rows[0]["Length"].ToString());
                        ACCURSETCURCODE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["ACQUIERSETAMOUNT"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACQUIERSETAMOUNT"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACQUIERSETAMOUNT"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACQUIERSETAMOUNT"].Rows[0]["Length"].ToString());
                        ACQUIERSETAMOUNT = line1.Substring(Start - Incr, End);
                        ACQUIERSETAMOUNT = ACQUIERSETAMOUNT.Substring(0, 13) + '.' + ACQUIERSETAMOUNT.Substring(13, 2);
                    }
                    if (ds.Tables["ACQUIERSETFEE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACQUIERSETFEE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACQUIERSETFEE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACQUIERSETFEE"].Rows[0]["Length"].ToString());
                        ACQUIERSETFEE = line1.Substring(Start - Incr, End);
                        ACQUIERSETFEE = ACQUIERSETFEE.Substring(0, 13) + '.' + ACQUIERSETFEE.Substring(13, 2);
                    }
                    if (ds.Tables["ACQUIERSETPROFEE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACQUIERSETPROFEE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACQUIERSETPROFEE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACQUIERSETPROFEE"].Rows[0]["Length"].ToString());
                        ACQUIERSETPROFEE = line1.Substring(Start - Incr, End);
                        ACQUIERSETPROFEE = ACQUIERSETPROFEE.Substring(0, 13) + '.' + ACQUIERSETPROFEE.Substring(13, 2);
                    }
                    if (ds.Tables["TRANSACQUIERCONVERRATE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRANSACQUIERCONVERRATE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TRANSACQUIERCONVERRATE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRANSACQUIERCONVERRATE"].Rows[0]["Length"].ToString());
                        TRANSACQUIERCONVERRATE = line1.Substring(Start - Incr, End);
                        TRANSACQUIERCONVERRATE = TRANSACQUIERCONVERRATE.Substring(0, 13) + '.' + TRANSACQUIERCONVERRATE.Substring(13, 2);
                    }

                    #region StanderedFields
                    CardType = string.Empty;
                    TxnsDateTimeMain = null;
                    ACCSETDATEMain = null;
                    CARDACCEPTERSETDATEMain = null;

                    #region ValidateField

                    if (TxnsDateTime != "" && TRANSTIME != "")
                    {
                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime + TRANSTIME, "yyMMddHHmmss", CultureInfo.InvariantCulture);
                    }

                    if (ACCSETDATE != "")
                    {
                        ACCSETDATEMain = DateTime.ParseExact(ACCSETDATE, "yyMMdd", CultureInfo.InvariantCulture);
                    }

                    if (CARDACCEPTERSETDATE != "")
                    {
                        CARDACCEPTERSETDATEMain = DateTime.ParseExact(CARDACCEPTERSETDATE, "yyMMdd", CultureInfo.InvariantCulture);
                    }

                    if (CardNumber != "")
                    {
                        if (CardNumber.Substring(0, 1) == "4")
                        {
                            CardScheme = "VISA";
                        }
                        else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                        {
                            CardScheme = "MASTER";
                        }
                        else if (CardNumber.Substring(0, 2) == "62")
                        {
                            CardScheme = "CUP";
                        }
                        else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                        {
                            CardScheme = "RuPay";
                        }
                        else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                        {
                            CardScheme = "Maestro";
                        }
                    }

                    #endregion ValidateField

                    #region InitilizedField

                    #endregion InitilizedField


                    #endregion StanderedFields

                    if (CardNumber != "")
                    {

                        ECardNumber = AesEncryption.EncryptString(CardNumber);

                    }

                    if (CardNumber != "")
                    {
                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                    }

                    _DataTable.Rows.Add(ClientID
                                    , PARTICIPENTID
                                    , TRANSTYPE
                                    , FROMACCTYPE
                                    , TOACCTYPE
                                    , ReferenceNumber
                                    , RESPONSECODE
                                    , CardNumber.Trim()
                                    , CardType
                                    , MEMNUMBER
                                    , APPROVALNO
                                    , SYSTRACAUDITNO
                                    , TxnsDateTimeMain
                                    , TRANSTIME
                                    , MERCHANTCATCODE
                                    , CARDACCEPTERSETDATEMain
                                    , CARDACCID
                                    , TerminalId
                                    , CARDACCEPTERTERLOC
                                    , ACCIQUIERID
                                    , ACCSETDATEMain
                                    , TRANSCURCODE
                                    , Convert.ToDecimal(TxnsAmount)
                                    , Convert.ToDecimal(ACCTUALTRANSAMOUNT)
                                    , Convert.ToDecimal(TRANSACTIVITYFEE)
                                    , ACCURSETCURCODE
                                    , Convert.ToDecimal(ACQUIERSETAMOUNT)
                                    , Convert.ToDecimal(ACQUIERSETFEE)
                                    , Convert.ToDecimal(ACQUIERSETPROFEE)
                                    , Convert.ToDecimal(TRANSACQUIERCONVERRATE)
                                    , RevEntryLeg
                                    , 0
                                    , FileFormat[1].ToString().Trim()
                                    , Filedate
                                    , FileName
                                    , path
                                    , DateTime.Now
                                    , DateTime.Now
                                    , UserName
                                    , UserName
                                    , ECardNumber.Trim()
                                    , CardScheme
                                    , IssuingNetwork
                                    );

                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "NPCIATM.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }

            }
            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;

        }

        public DataTable SplitterNPCIIssuerATM(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;









            DataSet ds = new DataSet();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(DateTime));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(decimal));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(decimal));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(decimal));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(decimal));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(decimal));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(decimal));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(decimal));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(decimal));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("NoOfDuplicate", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(string));
            _DataTable.Columns.Add("MODIFIEDDON", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = "1";
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());


            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            int Incr = 1;
            string PARICIPATEID = string.Empty;
            string TRANSACTIONTYPE = string.Empty;
            string FROMACCOUNTTYPE = string.Empty;
            string TOACCOUNTTYPE = string.Empty;
            string ReferenceNumber = string.Empty;
            string RESPONSECODE = string.Empty;
            string CardNumber = string.Empty;
            string MEMNUMBER = string.Empty;
            string APPROVNO = string.Empty;
            string STAUDITNO = string.Empty;
            string TxnsDateTime = string.Empty;
            string TRANSACTIONTIME = string.Empty;
            string MERCHENTCATCODE = string.Empty;
            string CARDACCEPTSETDATE = string.Empty;
            string CARDACCID = string.Empty;
            string TerminalId = string.Empty;
            string CARDACCEPTERTERLOCATION = string.Empty;
            string ACQUIRERID = string.Empty;
            string NETWORKID = string.Empty;
            string ACCOUNTNO1 = string.Empty;
            string ACCOUNTBRANCHID = string.Empty;
            string ACCOUNTNO2 = string.Empty;
            string ACCOUNT2BRANCHID = string.Empty;
            string TRANSCURRENCYCODE = string.Empty;
            string TxnsAmount = "0";
            string ACCTUALTRANAMOUNT = "0";
            string TRANSACCVITYFEE = "0";
            string ISSUERSETCURRENCYCODE = string.Empty;
            string ISSURESETAMOUNT = "0";
            string ISSUERSETFEE = "0";
            string ISSURESETPROCFEE = "0";
            string CARDHOLDERBILLCURNCCODE = string.Empty;
            string CARDHOLDERBILLAMOUNT = "0";
            string CARDHOLDERBILACTFEE = "0";
            string CARDHOLDERBILPROFEE = "0";
            string CARDHOLDERBILSRVICEFEE = "0";
            string TRAN_ISSUERCONVERSRATE = "0";
            string TRANS_CARDHOLDERCONVERRATE = "0";
            string CREATEDON = string.Empty;
            string MODIFIEDDON = string.Empty;
            string ModifiedBy = string.Empty;
            string CreatedBy = string.Empty;
            string ECardNumber = string.Empty;
            string line1 = string.Empty;
            DateTime? Filedate;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            DateTime? CARDACCEPTERSETDATEMain = null;


            int Start = 0;
            int End = 0;

            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                    //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                    Incr = 1;
                    PARICIPATEID = string.Empty;
                    TRANSACTIONTYPE = string.Empty;
                    FROMACCOUNTTYPE = string.Empty;
                    TOACCOUNTTYPE = string.Empty;
                    ReferenceNumber = string.Empty;
                    RESPONSECODE = string.Empty;
                    CardNumber = string.Empty;
                    MEMNUMBER = string.Empty;
                    APPROVNO = string.Empty;
                    STAUDITNO = string.Empty;
                    TxnsDateTime = string.Empty;
                    TRANSACTIONTIME = string.Empty;
                    MERCHENTCATCODE = string.Empty;
                    CARDACCEPTSETDATE = string.Empty;
                    CARDACCID = string.Empty;
                    TerminalId = string.Empty;
                    CARDACCEPTERTERLOCATION = string.Empty;
                    ACQUIRERID = string.Empty;
                    NETWORKID = string.Empty;
                    ACCOUNTNO1 = string.Empty;
                    ACCOUNTBRANCHID = string.Empty;
                    ACCOUNTNO2 = string.Empty;
                    ACCOUNT2BRANCHID = string.Empty;
                    TRANSCURRENCYCODE = string.Empty;
                    TxnsAmount = "0";
                    ACCTUALTRANAMOUNT = "0";
                    TRANSACCVITYFEE = "0";
                    ISSUERSETCURRENCYCODE = string.Empty;
                    ISSURESETAMOUNT = "0";
                    ISSUERSETFEE = "0";
                    ISSURESETPROCFEE = "0";
                    CARDHOLDERBILLCURNCCODE = string.Empty;
                    CARDHOLDERBILLAMOUNT = "0";
                    CARDHOLDERBILACTFEE = "0";
                    CARDHOLDERBILPROFEE = "0";
                    CARDHOLDERBILSRVICEFEE = "0";
                    TRAN_ISSUERCONVERSRATE = "0";
                    TRANS_CARDHOLDERCONVERRATE = "0";
                    CREATEDON = string.Empty;
                    MODIFIEDDON = string.Empty;
                    ModifiedBy = string.Empty;
                    CreatedBy = string.Empty;
                    ECardNumber = string.Empty;
                    CardScheme = string.Empty;
                    Filedate = null;

                    string file = System.IO.Path.GetFileNameWithoutExtension(FileName);
                    string[] FileFormat = file.Substring(file.Length - 9, 9).Split('_');
                    Filedate = DateTime.ParseExact(FileFormat[0].ToString(), "ddMMyy", CultureInfo.InvariantCulture);
                    if (ds.Tables["PARICIPATEID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PARICIPATEID"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["PARICIPATEID"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["PARICIPATEID"].Rows[0]["Length"].ToString());
                        PARICIPATEID = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TRANSACTIONTYPE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRANSACTIONTYPE"].Rows[0]["Length"].ToString() != "0")
                    {

                        Start = int.Parse(ds.Tables["TRANSACTIONTYPE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRANSACTIONTYPE"].Rows[0]["Length"].ToString());
                        TRANSACTIONTYPE = line1.Substring(Start - Incr, End);

                    }
                    if (ds.Tables["FROMACCOUNTTYPE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FROMACCOUNTTYPE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["FROMACCOUNTTYPE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["FROMACCOUNTTYPE"].Rows[0]["Length"].ToString());
                        FROMACCOUNTTYPE = line1.Substring(Start - Incr, End);

                    }
                    if (ds.Tables["TOACCOUNTTYPE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TOACCOUNTTYPE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TOACCOUNTTYPE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TOACCOUNTTYPE"].Rows[0]["Length"].ToString());
                        TOACCOUNTTYPE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReferenceNumber"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ReferenceNumber"].Rows[0]["Length"].ToString());
                        ReferenceNumber = line1.Substring(Start - Incr, End);
                        //ReferenceNumber = ReferenceNumber.TrimStart('0');
                    }
                    if (ds.Tables["RESPONSECODE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["RESPONSECODE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["RESPONSECODE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["RESPONSECODE"].Rows[0]["Length"].ToString());
                        RESPONSECODE = line1.Substring(Start - Incr, End);

                    }
                    if (ds.Tables["CardNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardNumber"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CardNumber"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CardNumber"].Rows[0]["Length"].ToString());
                        CardNumber = line1.Substring(Start - Incr, End).Trim();
                        //CardNumber = CardNumber.TrimStart('0');
                    }
                    if (ds.Tables["MEMNUMBER"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MEMNUMBER"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["MEMNUMBER"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["MEMNUMBER"].Rows[0]["Length"].ToString());
                        MEMNUMBER = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["APPROVNO"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["APPROVNO"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["APPROVNO"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["APPROVNO"].Rows[0]["Length"].ToString());
                        APPROVNO = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["STAUDITNO"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["STAUDITNO"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["STAUDITNO"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["STAUDITNO"].Rows[0]["Length"].ToString());
                        STAUDITNO = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsDateTime"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TxnsDateTime"].Rows[0]["Length"].ToString());
                        TxnsDateTime = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TRANSACTIONTIME"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRANSACTIONTIME"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TRANSACTIONTIME"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRANSACTIONTIME"].Rows[0]["Length"].ToString());
                        TRANSACTIONTIME = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["MERCHENTCATCODE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MERCHENTCATCODE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["MERCHENTCATCODE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["MERCHENTCATCODE"].Rows[0]["Length"].ToString());
                        MERCHENTCATCODE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["CARDACCEPTSETDATE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDACCEPTSETDATE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDACCEPTSETDATE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDACCEPTSETDATE"].Rows[0]["Length"].ToString());
                        CARDACCEPTSETDATE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["CARDACCID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDACCID"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDACCID"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDACCID"].Rows[0]["Length"].ToString());
                        CARDACCID = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["TerminalId"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalId"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TerminalId"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TerminalId"].Rows[0]["Length"].ToString());
                        TerminalId = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["CARDACCEPTERTERLOCATION"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDACCEPTERTERLOCATION"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDACCEPTERTERLOCATION"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDACCEPTERTERLOCATION"].Rows[0]["Length"].ToString());
                        CARDACCEPTERTERLOCATION = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["ACQUIRERID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACQUIRERID"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACQUIRERID"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACQUIRERID"].Rows[0]["Length"].ToString());
                        ACQUIRERID = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["NETWORKID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NETWORKID"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["NETWORKID"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["NETWORKID"].Rows[0]["Length"].ToString());
                        NETWORKID = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["ACCOUNTNO1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACCOUNTNO1"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACCOUNTNO1"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACCOUNTNO1"].Rows[0]["Length"].ToString());
                        ACCOUNTNO1 = line1.Substring(Start - Incr, End);
                    }

                    if (ds.Tables["ACCOUNTBRANCHID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACCOUNTBRANCHID"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACCOUNTBRANCHID"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACCOUNTBRANCHID"].Rows[0]["Length"].ToString());
                        ACCOUNTBRANCHID = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["ACCOUNTNO2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACCOUNTNO2"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACCOUNTNO2"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACCOUNTNO2"].Rows[0]["Length"].ToString());
                        ACCOUNTNO2 = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["ACCOUNT2BRANCHID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACCOUNT2BRANCHID"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACCOUNT2BRANCHID"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACCOUNT2BRANCHID"].Rows[0]["Length"].ToString());
                        ACCOUNT2BRANCHID = line1.Substring(Start - Incr, End);
                    }

                    if (ds.Tables["TRANSCURRENCYCODE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRANSCURRENCYCODE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TRANSCURRENCYCODE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRANSCURRENCYCODE"].Rows[0]["Length"].ToString());
                        TRANSCURRENCYCODE = line1.Substring(Start - Incr, End);
                    }

                    if (ds.Tables["TxnsAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsAmount"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TxnsAmount"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TxnsAmount"].Rows[0]["Length"].ToString());
                        TxnsAmount = line1.Substring(Start - Incr, End);
                        TxnsAmount = TxnsAmount.Substring(0, 13) + '.' + TxnsAmount.Substring(13, 2);
                    }
                    if (ds.Tables["ACCTUALTRANAMOUNT"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ACCTUALTRANAMOUNT"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ACCTUALTRANAMOUNT"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ACCTUALTRANAMOUNT"].Rows[0]["Length"].ToString());
                        ACCTUALTRANAMOUNT = line1.Substring(Start - Incr, End);
                        ACCTUALTRANAMOUNT = ACCTUALTRANAMOUNT.Substring(0, 13) + '.' + ACCTUALTRANAMOUNT.Substring(13, 2);
                    }
                    if (ds.Tables["TRANSACCVITYFEE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRANSACCVITYFEE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TRANSACCVITYFEE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRANSACCVITYFEE"].Rows[0]["Length"].ToString());
                        TRANSACCVITYFEE = line1.Substring(Start - Incr, End);
                        TRANSACCVITYFEE = TRANSACCVITYFEE.Substring(0, 13) + '.' + TRANSACCVITYFEE.Substring(13, 2);
                    }
                    if (ds.Tables["ISSUERSETCURRENCYCODE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ISSUERSETCURRENCYCODE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ISSUERSETCURRENCYCODE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ISSUERSETCURRENCYCODE"].Rows[0]["Length"].ToString());
                        ISSUERSETCURRENCYCODE = line1.Substring(Start - Incr, End);
                    }
                    if (ds.Tables["ISSURESETAMOUNT"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ISSURESETAMOUNT"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ISSURESETAMOUNT"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ISSURESETAMOUNT"].Rows[0]["Length"].ToString());
                        ISSURESETAMOUNT = line1.Substring(Start - Incr, End);
                        ISSURESETAMOUNT = ISSURESETAMOUNT.Substring(0, 13) + '.' + ISSURESETAMOUNT.Substring(13, 2);
                    }
                    if (ds.Tables["ISSUERSETFEE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ISSUERSETFEE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ISSUERSETFEE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ISSUERSETFEE"].Rows[0]["Length"].ToString());
                        ISSUERSETFEE = line1.Substring(Start - Incr, End);
                        ISSUERSETFEE = ISSUERSETFEE.Substring(0, 13) + '.' + ISSUERSETFEE.Substring(13, 2);
                    }
                    if (ds.Tables["ISSURESETPROCFEE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ISSURESETPROCFEE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["ISSURESETPROCFEE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["ISSURESETPROCFEE"].Rows[0]["Length"].ToString());
                        ISSURESETPROCFEE = line1.Substring(Start - Incr, End);
                        ISSURESETPROCFEE = ISSURESETPROCFEE.Substring(0, 13) + '.' + ISSURESETPROCFEE.Substring(13, 2);
                    }
                    if (ds.Tables["CARDHOLDERBILLCURNCCODE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDHOLDERBILLCURNCCODE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDHOLDERBILLCURNCCODE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDHOLDERBILLCURNCCODE"].Rows[0]["Length"].ToString());
                        CARDHOLDERBILLCURNCCODE = line1.Substring(Start - Incr, End);
                    }

                    if (ds.Tables["CARDHOLDERBILLAMOUNT"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDHOLDERBILLAMOUNT"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDHOLDERBILLAMOUNT"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDHOLDERBILLAMOUNT"].Rows[0]["Length"].ToString());
                        CARDHOLDERBILLAMOUNT = line1.Substring(Start - Incr, End);
                        CARDHOLDERBILLAMOUNT = CARDHOLDERBILLAMOUNT.Substring(0, 13) + '.' + CARDHOLDERBILLAMOUNT.Substring(13, 2);
                    }

                    if (ds.Tables["CARDHOLDERBILACTFEE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDHOLDERBILACTFEE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDHOLDERBILACTFEE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDHOLDERBILACTFEE"].Rows[0]["Length"].ToString());
                        CARDHOLDERBILACTFEE = line1.Substring(Start - Incr, End);
                        CARDHOLDERBILACTFEE = CARDHOLDERBILACTFEE.Substring(0, 13) + '.' + CARDHOLDERBILACTFEE.Substring(13, 2);
                    }

                    if (ds.Tables["CARDHOLDERBILPROFEE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDHOLDERBILPROFEE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDHOLDERBILPROFEE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDHOLDERBILPROFEE"].Rows[0]["Length"].ToString());
                        CARDHOLDERBILPROFEE = line1.Substring(Start - Incr, End);
                        CARDHOLDERBILPROFEE = CARDHOLDERBILPROFEE.Substring(0, 13) + '.' + CARDHOLDERBILPROFEE.Substring(13, 2);
                    }

                    if (ds.Tables["CARDHOLDERBILSRVICEFEE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CARDHOLDERBILSRVICEFEE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["CARDHOLDERBILSRVICEFEE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["CARDHOLDERBILSRVICEFEE"].Rows[0]["Length"].ToString());
                        CARDHOLDERBILSRVICEFEE = line1.Substring(Start - Incr, End);
                        CARDHOLDERBILSRVICEFEE = CARDHOLDERBILSRVICEFEE.Substring(0, 13) + '.' + CARDHOLDERBILSRVICEFEE.Substring(13, 2);
                    }

                    if (ds.Tables["TRAN_ISSUERCONVERSRATE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRAN_ISSUERCONVERSRATE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TRAN_ISSUERCONVERSRATE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRAN_ISSUERCONVERSRATE"].Rows[0]["Length"].ToString());
                        TRAN_ISSUERCONVERSRATE = line1.Substring(Start - Incr, End);
                        TRAN_ISSUERCONVERSRATE = TRAN_ISSUERCONVERSRATE.Substring(0, 13) + '.' + TRAN_ISSUERCONVERSRATE.Substring(13, 2);
                    }

                    if (ds.Tables["TRANS_CARDHOLDERCONVERRATE"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TRANS_CARDHOLDERCONVERRATE"].Rows[0]["Length"].ToString() != "0")
                    {
                        Start = int.Parse(ds.Tables["TRANS_CARDHOLDERCONVERRATE"].Rows[0]["StartPosition"].ToString());
                        End = int.Parse(ds.Tables["TRANS_CARDHOLDERCONVERRATE"].Rows[0]["Length"].ToString());
                        TRANS_CARDHOLDERCONVERRATE = line1.Substring(Start - Incr, End);
                        TRANS_CARDHOLDERCONVERRATE = TRANS_CARDHOLDERCONVERRATE.Substring(0, 13) + '.' + TRANS_CARDHOLDERCONVERRATE.Substring(13, 2);
                    }

                    #region StanderedFields
                    CardType = string.Empty;
                    TxnsDateTimeMain = null;
                    CARDACCEPTERSETDATEMain = null;

                    #region ValidateField

                    if (TxnsDateTime != "" && TRANSACTIONTIME != "")
                    {
                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime + TRANSACTIONTIME, "yyMMddHHmmss", CultureInfo.InvariantCulture);
                    }

                    if (CARDACCEPTSETDATE != "")
                    {
                        CARDACCEPTERSETDATEMain = DateTime.ParseExact(CARDACCEPTSETDATE, "yyMMdd", CultureInfo.InvariantCulture);
                    }

                    if (CardNumber != "")
                    {
                        if (CardNumber.Substring(0, 1) == "4")
                        {
                            CardScheme = "VISA";
                        }
                        else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                        {
                            CardScheme = "MASTER";
                        }
                        else if (CardNumber.Substring(0, 2) == "62")
                        {
                            CardScheme = "CUP";
                        }
                        else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                        {
                            CardScheme = "RuPay";
                        }
                        else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                        {
                            CardScheme = "Maestro";
                        }

                    }

                    #endregion ValidateField

                    #region InitilizedField

                    #endregion InitilizedField


                    #endregion StanderedFields

                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }


                    if (CardNumber != "")
                    {
                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                    }


                    _DataTable.Rows.Add(ClientID
                                        , PARICIPATEID
                                        , TRANSACTIONTYPE
                                        , FROMACCOUNTTYPE
                                        , TOACCOUNTTYPE
                                        , ReferenceNumber
                                        , RESPONSECODE
                                        , CardNumber.Trim()
                                        , CardType
                                        , MEMNUMBER
                                        , APPROVNO
                                        , STAUDITNO
                                        , TxnsDateTimeMain
                                        , TRANSACTIONTIME
                                        , MERCHENTCATCODE
                                        , CARDACCEPTERSETDATEMain
                                        , CARDACCID
                                        , TerminalId
                                        , CARDACCEPTERTERLOCATION
                                        , ACQUIRERID
                                        , NETWORKID
                                        , ACCOUNTNO1
                                        , ACCOUNTBRANCHID
                                        , ACCOUNTNO2
                                        , ACCOUNT2BRANCHID
                                        , TRANSCURRENCYCODE
                                        , Convert.ToDecimal(TxnsAmount)
                                        , Convert.ToDecimal(ACCTUALTRANAMOUNT)
                                        , Convert.ToDecimal(TRANSACCVITYFEE)
                                        , ISSUERSETCURRENCYCODE
                                        , Convert.ToDecimal(ISSURESETAMOUNT)
                                        , Convert.ToDecimal(ISSUERSETFEE)
                                        , Convert.ToDecimal(ISSURESETPROCFEE)
                                        , CARDHOLDERBILLCURNCCODE
                                        , Convert.ToDecimal(CARDHOLDERBILLAMOUNT)
                                        , Convert.ToDecimal(CARDHOLDERBILACTFEE)
                                        , Convert.ToDecimal(CARDHOLDERBILPROFEE)
                                        , Convert.ToDecimal(CARDHOLDERBILSRVICEFEE)
                                        , Convert.ToDecimal(TRAN_ISSUERCONVERSRATE)
                                        , Convert.ToDecimal(TRANS_CARDHOLDERCONVERRATE)
                                        , RevEntryLeg
                                        , 0
                                        , FileFormat[1].ToString().Trim()
                                        , Filedate
                                        , FileName
                                        , path
                                        , DateTime.Now
                                        , DateTime.Now
                                        , UserName
                                        , UserName
                                        , ECardNumber.Trim()
                                        , CardScheme
                                        , IssuingNetwork
                                    );

                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "NPCIATM.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }

            }
            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;

        }

        public DataTable SplitterAdjustment(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("TxnUID", typeof(string));
            _DataTable.Columns.Add("TxnType", typeof(string));
            _DataTable.Columns.Add("UID", typeof(string));
            _DataTable.Columns.Add("AdjDate", typeof(DateTime));
            _DataTable.Columns.Add("AdjType", typeof(string));
            _DataTable.Columns.Add("AcquirerBank", typeof(string));
            _DataTable.Columns.Add("IssuerBank", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("TxnDateTime", typeof(DateTime));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TerminalID", typeof(string));
            _DataTable.Columns.Add("CardNo", typeof(string));
            _DataTable.Columns.Add("ChargebackDate", typeof(DateTime));
            _DataTable.Columns.Add("ChargebackRemarks", typeof(string));
            _DataTable.Columns.Add("TxnAmount", typeof(decimal));
            _DataTable.Columns.Add("AdjAmount", typeof(decimal));
            _DataTable.Columns.Add("ACQFee", typeof(decimal));
            _DataTable.Columns.Add("ISSFee", typeof(decimal));
            _DataTable.Columns.Add("ISSFeeSW", typeof(decimal));
            //_DataTable.Columns.Add("AdjFee", typeof(decimal));
            _DataTable.Columns.Add("NPCIFee", typeof(decimal));
            _DataTable.Columns.Add("AcqFeeTax", typeof(decimal));
            _DataTable.Columns.Add("IssFeetax", typeof(decimal));
            _DataTable.Columns.Add("NPCITax", typeof(decimal));
            _DataTable.Columns.Add("AdjRef", typeof(string));
            _DataTable.Columns.Add("BankAdjRef", typeof(string));
            _DataTable.Columns.Add("AdjProof", typeof(string));
            _DataTable.Columns.Add("reasondesc", typeof(string));
            _DataTable.Columns.Add("PinCode", typeof(string));
            _DataTable.Columns.Add("TerminalLocation", typeof(string));
            _DataTable.Columns.Add("MultiDisputeGroup", typeof(string));
            _DataTable.Columns.Add("FCQM", typeof(string));
            _DataTable.Columns.Add("ADJSettlementdate", typeof(DateTime));
            _DataTable.Columns.Add("CustomerPenalty", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("TATExpDate", typeof(DateTime));
            _DataTable.Columns.Add("ACQSTLAmount", typeof(string));
            _DataTable.Columns.Add("AcqCC", typeof(string));
            _DataTable.Columns.Add("PanEntryMode", typeof(string));
            _DataTable.Columns.Add("ServiceCode", typeof(string));
            _DataTable.Columns.Add("CardDataInputCapability", typeof(string));
            _DataTable.Columns.Add("MCCCode", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));


            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            try
            {
                string Txnuid = string.Empty;
                string Uid = string.Empty;
                string TxnType = string.Empty;
                DateTime AdjDate;
                string AdjType = string.Empty;
                string AcquirerBank = string.Empty;
                string IssuerBank = string.Empty;
                string ResponseCode = string.Empty;
                DateTime TxnDateTime;
                string ReferenceNumber = string.Empty;
                string TerminalID = string.Empty;
                string CardNo = string.Empty;
                DateTime? ChargebackDate = null;
                string ChargebackRemarks = string.Empty;
                decimal TxnAmount = 0;
                decimal AdjAmount = 0;
                decimal ACQFee = 0;
                decimal ISSFee = 0;
                decimal ISSFeeSW = 0;
                //decimal AdjFee = 0;
                decimal NPCIFee = 0;
                decimal AcqFeeTax = 0;
                decimal IssFeetax = 0;
                decimal NPCITax = 0;
                string AdjRef = string.Empty;
                string BankAdjRef = string.Empty;
                string AdjProof = string.Empty;
                string reasondesc = string.Empty;
                string PinCode = string.Empty;
                string TermLoc = string.Empty;
                string MultDisGroup = string.Empty;
                string FCQM = string.Empty;
                DateTime? ADJSettlementdate = null;
                string CustPenalty = string.Empty;
                string Cycle = string.Empty;
                DateTime? TatExpDate = null;
                string ACQSTLAmt = string.Empty;
                string AcqCC = string.Empty;
                string PEMode = string.Empty;
                string ServiceCode = string.Empty;
                string CarddataInputCap = string.Empty;
                string MCCCode = string.Empty;
                string CreatedBy = string.Empty;

                string DtTime = string.Empty;
                string Dt = string.Empty;
                string DtAdj = string.Empty;
                string DtSettle = string.Empty;
                string ModifiedBy = string.Empty;
                string d1 = string.Empty;
                string d2 = string.Empty;
                string date1 = string.Empty;

                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

                string[] TotalCountArray = File.ReadAllLines(path);
                TotalCount = TotalCountArray.Length;


                string ATMLoc = string.Empty;
                string txnid = string.Empty;
                string uid = string.Empty;
                string adjdate = string.Empty;
                string Resp = string.Empty;
                string Refno = string.Empty;
                string CardNum = string.Empty;
                string ChargebackDate1 = string.Empty;
                string chbref = string.Empty;
                //OleDbConnection objConn = null;
                //DataTable dtexcelsheetname = null;
                //String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                //"Data Source=" + path + ";Extended Properties=Excel 8.0;";
                //string extension = Path.GetExtension(path);
                //switch (extension.ToLower())
                //{
                //    case ".xls": //Excel 97-03
                //        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";";
                //        break;
                //    case ".xlsx": //Excel 07 or higher
                //        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                //        break;
                //}
                //objConn = new OleDbConnection(connString);
                //objConn.Open();
                //dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                //String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                //int j = 0;
                //foreach (DataRow row in dtexcelsheetname.Rows)
                //{
                //    excelSheets[j] = row["TABLE_NAME"].ToString();
                //    j++;
                //}

                //string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                ////string sht = dr[2].ToString().Replace("'", "");

                //OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                //OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                //DataTable dtfillsheet1 = new DataTable();
                //da.Fill(dtfillsheet1);


                //objConn.Close();

                string conString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0;IMEX=1;HDR=Yes;' ";


                conString = string.Format(conString, path);

                DataTable dtexcelsheetname = null;
                //int j = 0;
                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }



                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {
                    DataTable dtfillsheet1 = new DataTable();

                    using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                    {
                        using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                        {
                            using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                            {
                                //Read Data from First Sheet.
                                cmdExcelSheet.Connection = connExcelSheet;
                                connExcelSheet.Open();
                                cmdExcelSheet.CommandText = "SELECT * From [" + dtexcelsheetname.Rows[0]["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                odaExcelSheet.SelectCommand = cmdExcelSheet;
                                odaExcelSheet.Fill(dtfillsheet1);
                                connExcelSheet.Close();
                            }
                        }
                    }

                    TotalCount = dtfillsheet1.Rows.Count;
                    for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                    {
                        try
                        {
                            LineNo++;

                            txnid = dtfillsheet1.Rows[i][0].ToString();
                            Txnuid = txnid.Replace("'", "");
                            TxnType = dtfillsheet1.Rows[i][1].ToString();
                            uid = dtfillsheet1.Rows[i][2].ToString();
                            Uid = uid.Replace("'", "");
                            adjdate = dtfillsheet1.Rows[i][3].ToString();
                            AdjDate = DateTime.ParseExact(adjdate.ToString(), "dd-MM-yyyy", null);
                            AdjType = dtfillsheet1.Rows[i][4].ToString();
                            AcquirerBank = dtfillsheet1.Rows[i][5].ToString();
                            IssuerBank = dtfillsheet1.Rows[i][6].ToString();
                            Resp = dtfillsheet1.Rows[i][7].ToString();
                            ResponseCode = Resp.Replace("'", "");
                            d1 = dtfillsheet1.Rows[i][8].ToString();
                            d2 = dtfillsheet1.Rows[i][9].ToString();
                            date1 = d1 + " " + d2;
                            TxnDateTime = DateTime.ParseExact(date1.ToString(), "dd-MM-yyyy HH:mm:ss", null);
                            Refno = dtfillsheet1.Rows[i][10].ToString();
                            ReferenceNumber = Refno.Replace("'", "");
                            TerminalID = dtfillsheet1.Rows[i][11].ToString();
                            CardNum = dtfillsheet1.Rows[i][12].ToString();
                            CardNo = CardNum.Replace("'", "");
                            ChargebackDate1 = dtfillsheet1.Rows[i][13].ToString();
                            if (ChargebackDate1.Contains("--"))
                            {
                                ChargebackDate = null;
                            }
                            else
                            {
                                ChargebackDate = dtfillsheet1.Rows[i][13].ToString().Contains('-') == true ? (DateTime.ParseExact(dtfillsheet1.Rows[i][13].ToString(), "dd-MM-yyyy", null)) : ChargebackDate;
                            }

                            chbref = dtfillsheet1.Rows[i][14].ToString();
                            ChargebackRemarks = chbref.Replace("'", "");
                            TxnAmount = Convert.ToDecimal(dtfillsheet1.Rows[i][15].ToString());
                            AdjAmount = Convert.ToDecimal(dtfillsheet1.Rows[i][16].ToString());
                            ACQFee = Convert.ToDecimal(dtfillsheet1.Rows[i][17].ToString());
                            ISSFee = Convert.ToDecimal(dtfillsheet1.Rows[i][18].ToString());
                            ISSFeeSW = Convert.ToDecimal(dtfillsheet1.Rows[i][19].ToString());
                            NPCIFee = Convert.ToDecimal(dtfillsheet1.Rows[i][20].ToString());
                            AcqFeeTax = Convert.ToDecimal(dtfillsheet1.Rows[i][21].ToString());
                            IssFeetax = Convert.ToDecimal(dtfillsheet1.Rows[i][22].ToString());
                            NPCITax = Convert.ToDecimal(dtfillsheet1.Rows[i][23].ToString());
                            AdjRef = dtfillsheet1.Rows[i][24].ToString();
                            BankAdjRef = dtfillsheet1.Rows[i][25].ToString();
                            AdjProof = dtfillsheet1.Rows[i][26].ToString();
                            reasondesc = dtfillsheet1.Rows[i][27].ToString();
                            PinCode = dtfillsheet1.Rows[i][28].ToString();
                            ATMLoc = dtfillsheet1.Rows[i][29].ToString();
                            TermLoc = ATMLoc.Replace("'", "");
                            MultDisGroup = dtfillsheet1.Rows[i][30].ToString();
                            FCQM = dtfillsheet1.Rows[i][31].ToString();
                            ADJSettlementdate = dtfillsheet1.Rows[i][32].ToString().Contains('-') == true ? (DateTime.ParseExact(dtfillsheet1.Rows[i][32].ToString(), "dd-MM-yyyy", null)) : ADJSettlementdate;
                            CustPenalty = dtfillsheet1.Rows[i][33].ToString();
                            Cycle = dtfillsheet1.Rows[i][35].ToString();
                            TatExpDate = dtfillsheet1.Rows[i][36].ToString().Contains('-') == true ? (DateTime.ParseExact(dtfillsheet1.Rows[i][36].ToString(), "dd-MM-yyyy", null)) : TatExpDate;
                            ACQSTLAmt = dtfillsheet1.Rows[i][37].ToString();
                            AcqCC = dtfillsheet1.Rows[i][38].ToString();
                            PEMode = dtfillsheet1.Rows[i][39].ToString();
                            ServiceCode = dtfillsheet1.Rows[i][40].ToString();
                            CarddataInputCap = dtfillsheet1.Rows[i][41].ToString();
                            MCCCode = dtfillsheet1.Rows[i][42].ToString();



                            _DataTable.Rows.Add(ClientID, Txnuid, TxnType, Uid, AdjDate, AdjType, AcquirerBank, IssuerBank, ResponseCode, TxnDateTime, ReferenceNumber, TerminalID,
                                    CardNo, ChargebackDate, ChargebackRemarks, TxnAmount, AdjAmount, ACQFee, ISSFee, ISSFeeSW, NPCIFee, AcqFeeTax, IssFeetax,
                                    NPCITax, AdjRef, BankAdjRef, AdjProof, reasondesc, PinCode, TermLoc, MultDisGroup, FCQM, ADJSettlementdate, CustPenalty,
                                    Cycle, TatExpDate, ACQSTLAmt, AcqCC, PEMode, ServiceCode, CarddataInputCap, MCCCode, UserName, System.DateTime.Now, UserName, System.DateTime.Now);
                            InsertCount++;


                        }
                        catch (Exception EX)
                        {
                            //_DataTable.Rows.Clear();
                            DBLog.InsertLogs(EX.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            // variable();
                        }
                    }
                    if (_DataTable.Rows.Count > 0)
                    {
                        // InsertCount--;
                        InsertCount = _DataTable.Rows.Count;

                        //_log.FunErrorLog("Transaction not found", BankCode, "ProcessGLLogSpliter", "ProcessLogSpliterBOB", LineNo, FileName, UserName, 'E');
                        // variable();
                    }
                }
            }
            catch (Exception EX)
            {
                //_DataTable.Rows.Clear();
                DBLog.InsertLogs(EX.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                //  variable();
            }
            return _DataTable;
        }
        public DataTable ProcessBFSFileSpliter(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TransType", typeof(string));
            _DataTable.Columns.Add("Resp_Code", typeof(string));
            _DataTable.Columns.Add("CardNo", typeof(string));
            _DataTable.Columns.Add("RRN", typeof(string));
            _DataTable.Columns.Add("StanNo", typeof(string));
            _DataTable.Columns.Add("ACQ", typeof(string));
            _DataTable.Columns.Add("ISS", typeof(string));
            _DataTable.Columns.Add("Trasn_DateTime", typeof(DateTime));
            _DataTable.Columns.Add("TerminalID", typeof(string));
            _DataTable.Columns.Add("SettleDate", typeof(DateTime));
            _DataTable.Columns.Add("Amount", typeof(decimal));
            _DataTable.Columns.Add("ReceivedAmt", typeof(decimal));
            _DataTable.Columns.Add("Status", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));


            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;









            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            int modeId = 0;

            string m_RecordData = string.Empty;
            string FileName1 = System.IO.Path.GetFileNameWithoutExtension(path);
            string FileDate = FileName.Substring(FileName1.Length - 6, 6);
            string MM = FileDate.Substring(2, 2);
            try
            {
                string TransType = string.Empty;
                string Resp_Code = string.Empty;
                string CardNo = string.Empty;
                string ECardNumber = string.Empty;
                string RRN = string.Empty;
                string StanNo = string.Empty;
                string ACQ = string.Empty;
                string ISS = string.Empty;
                DateTime Trasn_DateTime;
                string TerminalID = string.Empty;
                DateTime SettleDate;
                decimal Amount = 0;
                decimal ReceivedAmt = 0;
                string Status = string.Empty;
                string StrTrasn_DateTime = string.Empty;
                string StrSettleDate = string.Empty;

                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                string extension = System.IO.Path.GetExtension(path);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        break;
                }

                objConn = new OleDbConnection(connString);
                objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null); 

                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(dtexcelsheetname.Rows[0]["TABLE_NAME"]).Replace("'", "") + "]";

                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dtfillsheet1 = new DataTable();
                da.Fill(dtfillsheet1);


                objConn.Close();
                for (int i = 2; i < dtfillsheet1.Rows.Count; i++)
                {
                    try
                    {
                        TransType = dtfillsheet1.Rows[i][0].ToString().Replace("'", "");
                        Resp_Code = dtfillsheet1.Rows[i][1].ToString().Replace("'", "");
                        ECardNumber = dtfillsheet1.Rows[i][2].ToString().Replace("'", "");
                        if (ECardNumber != "")
                        {
                            CardNo = AesEncryption.EncryptString(ECardNumber);
                        }
                        RRN = dtfillsheet1.Rows[i][3].ToString().Replace("'", "");
                        StanNo = dtfillsheet1.Rows[i][4].ToString();
                        ACQ = dtfillsheet1.Rows[i][5].ToString();
                        ISS = dtfillsheet1.Rows[i][6].ToString();
                        StrTrasn_DateTime = dtfillsheet1.Rows[i][7].ToString();
                        Trasn_DateTime = DateTime.ParseExact(StrTrasn_DateTime.ToString(), "dd-MM-yyyy", null);
                        //string StrTrasn_DateTime = dtfillsheet1.Rows[i][7].ToString().Replace("-", "/");
                        //string TDay = string.Empty;
                        //string TYear = string.Empty;
                        //string[] StrTrasn_DateTimeA = StrTrasn_DateTime.Split('/');

                        //if (StrTrasn_DateTimeA[0].Length < 2)
                        //{
                        //    StrTrasn_DateTimeA[0] = "0" + StrTrasn_DateTimeA[0].ToString();
                        //}
                        //if (StrTrasn_DateTimeA[1].Length < 2)
                        //{
                        //    StrTrasn_DateTimeA[1] = "0" + StrTrasn_DateTimeA[1].ToString();
                        //}
                        //if (StrTrasn_DateTimeA[2].Length < 2)
                        //{
                        //    StrTrasn_DateTimeA[2] = "0" + StrTrasn_DateTimeA[2].ToString();
                        //}
                        //if (StrTrasn_DateTimeA[0].ToString() != MM && StrTrasn_DateTimeA[0].Length == 2)
                        //{
                        //    TDay = StrTrasn_DateTimeA[0].ToString();
                        //}

                        //if (StrTrasn_DateTimeA[1].ToString() != MM && StrTrasn_DateTimeA[1].Length == 2)
                        //{
                        //    TDay = StrTrasn_DateTimeA[1].ToString();
                        //}

                        //if (StrTrasn_DateTimeA[2].ToString() != MM && StrTrasn_DateTimeA[2].Length == 2)
                        //{
                        //    TDay = StrTrasn_DateTimeA[2].ToString();
                        //}
                        //if (TDay == string.Empty)
                        //{
                        //    TDay = MM;
                        //}

                        //if (StrTrasn_DateTimeA[0].Length > 3)
                        //{
                        //    TYear = StrTrasn_DateTimeA[0].ToString();
                        //}

                        //if (StrTrasn_DateTimeA[2].Length > 3)
                        //{
                        //    TYear = StrTrasn_DateTimeA[2].ToString();
                        //}
                        //StrTrasn_DateTime = MM + "/" + TDay + "/" + TYear;

                        if (ClientID == 56)
                        {
                            if (ACQ == "ESA")
                            {
                                modeId = 3;
                            }
                            else if (ACQ == "ESA")
                            {
                                modeId = 2;
                            }
                        }

                        //Trasn_DateTime = Convert.ToDateTime(StrTrasn_DateTime);
                        TerminalID = dtfillsheet1.Rows[i][9].ToString();
                        StrSettleDate = dtfillsheet1.Rows[i][10].ToString();
                        SettleDate = DateTime.ParseExact(StrSettleDate.ToString(), "dd-MM-yyyy", null);
                        //string StrSettleDate = dtfillsheet1.Rows[i][10].ToString().Replace("-", "/");
                        //string[] StrSettleDateA = StrSettleDate.Split('/');
                        //string SDay = string.Empty;
                        //string SYear = string.Empty;

                        //if (StrSettleDateA[0].Length < 2)
                        //{
                        //    StrSettleDateA[0] = "0" + StrSettleDateA[0].ToString();
                        //}
                        //if (StrSettleDateA[1].Length < 2)
                        //{
                        //    StrSettleDateA[1] = "0" + StrSettleDateA[1].ToString();
                        //}
                        //if (StrSettleDateA[2].Length < 2)
                        //{
                        //    StrSettleDateA[2] = "0" + StrSettleDateA[2].ToString();
                        //}


                        //if (StrSettleDateA[0].ToString() != MM && StrSettleDateA[0].Length == 2)
                        //{
                        //    SDay = StrSettleDateA[0].ToString();
                        //}

                        //if (StrSettleDateA[1].ToString() != MM && StrSettleDateA[1].Length == 2)
                        //{
                        //    SDay = StrSettleDateA[1].ToString();
                        //}

                        //if (StrSettleDateA[2].ToString() != MM && StrSettleDateA[2].Length == 2)
                        //{
                        //    SDay = StrSettleDateA[2].ToString();
                        //}
                        //if (SDay == string.Empty)
                        //{
                        //    SDay = MM;
                        //}

                        //if (StrSettleDateA[0].Length > 3)
                        //{
                        //    SYear = StrSettleDateA[0].ToString();
                        //}

                        //if (StrSettleDateA[2].Length > 3)
                        //{
                        //    SYear = StrSettleDateA[2].ToString();
                        //}

                        //StrSettleDate = MM + "/" + SDay + "/" + SYear;

                        //SettleDate = Convert.ToDateTime(StrSettleDate);
                        Amount = Convert.ToDecimal(dtfillsheet1.Rows[i][11].ToString());
                        ReceivedAmt = Convert.ToDecimal(dtfillsheet1.Rows[i][12].ToString());
                        Status = dtfillsheet1.Rows[i][13].ToString();

                        _DataTable.Rows.Add(ClientID, 1, modeId, TransType, Resp_Code, CardNo, RRN, StanNo, ACQ, ISS, Trasn_DateTime, TerminalID, SettleDate, Amount, ReceivedAmt, Status, FileName, path, UserName);

                        TransType = string.Empty;
                        Resp_Code = string.Empty;
                        CardNo = string.Empty;
                        RRN = string.Empty;
                        StanNo = string.Empty;
                        ACQ = string.Empty;
                        ISS = string.Empty;
                        TerminalID = string.Empty;
                        Amount = 0;
                        ReceivedAmt = 0;
                        Status = string.Empty;

                        InsertCount++;
                        LineNo++;
                    }
                    catch (Exception ex)
                    {
                        InsertCount--;
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                }


                if (_DataTable.Rows.Count == 0 || _DataTable.Rows.Count == 0)
                {

                }


            }
            catch (Exception ex)
            {
                InsertCount--;
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

            }
            TotalCount = InsertCount;

            return _DataTable;
        }
        public DataTable SplitterSettlementIssuer(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("NoTxns", typeof(int));
            _DataTable.Columns.Add("Debit", typeof(string));
            _DataTable.Columns.Add("Credit", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));
            _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            //int StartIndex = 0;
            //int EndIndex = 0;
            //string EMekKey1 = ConfigurationSettings.AppSettings["MekKey1"].ToString();
            //string EMekKey2 = ConfigurationSettings.AppSettings["MekKey2"].ToString();
            //string StrCon = DAL.Comman.ConnectionString(); //ConfigurationSettings.AppSettings["con"].ToString();
            //ConfigurationDAL objConfigurationDAL = new ConfigurationDAL();
            //DataSet dsDEK = objConfigurationDAL.GetEncryptedDEK();
            //DataSet dsCardNetwork = objConfigurationDAL.GetCardNetwork();
            //AesEncryption.ClearMEK = AesEncryption.DecryptEncryptedMEK(EMekKey1);
            //AesEncryption.ClearMEK2 = AesEncryption.DecryptEncryptedMEK(EMekKey2);
            //string DEK = AesEncryption.DecryptEncryptedDEK(dsDEK.Tables[0].Rows[0]["TMK_LMK"].ToString(), AesEncryption.ClearMEK2);
            //

            //string EMekKey1 = this.Configuration.GetValue<string>("AppSettings:MekKey1");  // ConfigurationSettings.AppSettings["MekKey1"].ToString();
            //string EMekKey2 = this.Configuration.GetValue<string>("AppSettings:MekKey2");  //ConfigurationSettings.AppSettings["MekKey2"].ToString();

            //DataTable dsDEK = objCommon.GetEncryptedDEK();
            //DataSet dsCardNetwork = objCommon.GetCardNetwork();

            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            InsertCount = 0;
            TotalCount = 0;

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            DataTable dtexcelsheetname = new DataTable();
            DataTable dtSheet = new DataTable();

            try
            {
                String connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;";

                string extension = System.IO.Path.GetExtension(path);
                switch (extension.ToLower())
                {

                    case ".xls": //Excel 97-03
                                 // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                                  //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;

                }

                try
                {
                    using (OleDbConnection connExcel = new OleDbConnection(connString))
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            connExcel.Open();
                            //Get the name of First Sheet.
                            dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            connExcel.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }

                string[] excelSheets = new string[dtexcelsheetname.Rows.Count];
                int j = 0;
                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    dtSheet = new DataTable();

                    using (OleDbConnection connExcelSheet = new OleDbConnection(connString))
                    {
                        using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                        {
                            using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                            {
                                //Read Data from First Sheet.
                                cmdExcelSheet.Connection = connExcelSheet;
                                connExcelSheet.Open();
                                cmdExcelSheet.CommandText = "SELECT * FROM [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                odaExcelSheet.SelectCommand = cmdExcelSheet;
                                odaExcelSheet.Fill(dtSheet);
                                connExcelSheet.Close();
                            }
                        }
                    }

                    if (dtSheet.Rows.Count > 1)
                    {
                        DateTime? Date;
                        Date = null;
                        string[] Filesplit = FileName.Split('_');
                        string[] Cycle = Filesplit[1].Split('.');
                        string DateArray = FileName.Substring(7, 2).ToString() + "-" + FileName.Substring(9, 2).ToString() + "-" + FileName.Substring(11, 2).ToString();
                        Date = DateTime.ParseExact(DateArray.ToString(), "dd-MM-yy", null);

                        int Incr = 1;
                        string Description = string.Empty;
                        int NoTxns = 0;
                        decimal Debit = 0;
                        decimal Credit = 0;
                        string Remarks = string.Empty;

                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            Incr = 1;
                            Description = string.Empty;
                            NoTxns = 0;
                            Debit = 0;
                            Credit = 0;
                            Remarks = string.Empty;


                            try
                            {

                                if (ds.Tables[0].Rows[0]["Description"].ToString() != "0")
                                {
                                    Description = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Description"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["NoTxns"].ToString() != "0")
                                {
                                    NoTxns = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["NoTxns"].ToString()) - Incr].ToString() != "" ? Convert.ToInt32(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["NoTxns"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Debit"].ToString() != "0")
                                {
                                    Debit = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Debit"].ToString()) - Incr].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Debit"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Credit"].ToString() != "0")
                                {
                                    Credit = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Credit"].ToString()) - Incr].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Credit"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Remarks"].ToString() != "")
                                {
                                    Remarks = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Remarks"].ToString()) - Incr].ToString();
                                }

                                //Description = dtSheet.Rows[k][0].ToString();
                                //NoTxns = dtSheet.Rows[k][1].ToString() != "" ? Convert.ToInt32(dtSheet.Rows[k][1].ToString()) : 0;
                                //Debit = dtSheet.Rows[k][2].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][2].ToString()) : 0;
                                //Credit = dtSheet.Rows[k][3].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][3].ToString()) : 0;

                            }
                            catch (Exception ex)
                            {
                                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "NPCIATM.cs", "SplitData", LineNo, FileName, UserName, 'E');
                                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            }
                            LineNo++;
                            if (Description != "" && (Debit > 0 || Credit > 0))
                                _DataTable.Rows.Add(Date, Cycle[0].ToString().Trim(), Description, NoTxns, Debit, Credit, Remarks, ClientID, FileName, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);
                            InsertCount++;
                            j++;
                        }
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;

        }


        public DataTable SplitterNPCIAEPSACQUIRER(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            InsertCount = 0;
            TotalCount = 0;

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNO", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("URN", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            System.Data.DataSet DT = new System.Data.DataSet();
            string[] arrLines;
            string m_RecordData = string.Empty;



            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();

            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());


            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty; ;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string Member_Number = string.Empty;
            string Approval_Number = string.Empty;
            string System_Trace_Audit_Number = string.Empty;
            string Transaction_Date = string.Empty;
            //DateTime  Transaction_Date ;//= string.Empty;
            string Transaction_Time = string.Empty;
            string Merchant_Category_Code = string.Empty;
            string Card_Acceptor_Settlement_Date = string.Empty;
            string Card_Acceptor_ID = string.Empty;
            string Card_Acceptor_Terminal_ID = string.Empty;
            string Card_Acceptor_Terminal_Location = string.Empty;
            string Acquirer_ID = string.Empty;
            string Acquirer_Settlement_Date = string.Empty;
            string Transaction_Currency_code = string.Empty;
            string Transaction_Amount = string.Empty;
            string Actual_Transaction_Amount = string.Empty;
            string Transaction_Acitivity_fee = string.Empty;
            string Acquirer_settlement_Currency_Code = string.Empty;
            string Acquirer_settlement_Amount = string.Empty;
            string Acquirer_Settlement_Fee = string.Empty;
            string Acquirer_settlement_processing_fee = string.Empty;
            string Transaction_Acquirer_Conversion_Rate = string.Empty;

            string URN = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;


            try
            {
                string sLine = string.Empty;
                arrLines = File.ReadAllLines(path, Encoding.Default);
                int totalrecords = arrLines.Length;
                string Cycle = FileName.Substring(15, 1).ToString();
                string FD = FileName.Substring(8, 2).ToString() + "-" + FileName.Substring(10, 2).ToString() + "-" + FileName.Substring(12, 2).ToString();
                DateTime FileDate = DateTime.ParseExact(FD, "dd-MM-yy", System.Globalization.CultureInfo.InvariantCulture);


                for (int i = 0; i < totalrecords; i++)
                {
                    try
                    {
                        LineNo++;
                        TotalCount++;
                        Participant_ID = string.Empty;
                        Transaction_Type = string.Empty;
                        From_Account_Type = string.Empty; ;
                        To_Account_Type = string.Empty;
                        Transaction_Serial_Number = string.Empty;
                        Response_Code = string.Empty;
                        PAN_Number = string.Empty;
                        Member_Number = string.Empty;
                        Approval_Number = string.Empty;
                        System_Trace_Audit_Number = string.Empty;
                        Transaction_Date = string.Empty;
                        // Transaction_Date ;//= string.Empty;
                        Transaction_Time = string.Empty;
                        Merchant_Category_Code = string.Empty;
                        Card_Acceptor_Settlement_Date = string.Empty;
                        Card_Acceptor_ID = string.Empty;
                        Card_Acceptor_Terminal_ID = string.Empty;
                        Card_Acceptor_Terminal_Location = string.Empty;
                        Acquirer_ID = string.Empty;
                        Acquirer_Settlement_Date = string.Empty;
                        Transaction_Currency_code = string.Empty;
                        Transaction_Amount = string.Empty;
                        Actual_Transaction_Amount = string.Empty;
                        Transaction_Acitivity_fee = string.Empty;
                        Acquirer_settlement_Currency_Code = string.Empty;
                        Acquirer_settlement_Amount = string.Empty;
                        Acquirer_Settlement_Fee = string.Empty;
                        Acquirer_settlement_processing_fee = string.Empty;
                        Transaction_Acquirer_Conversion_Rate = string.Empty;

                        URN = string.Empty;
                        ReserveField1 = string.Empty;
                        ReserveField2 = string.Empty;
                        ReserveField3 = string.Empty;
                        ReserveField4 = string.Empty;
                        ReserveField5 = string.Empty;

                        sLine = arrLines[i];
                        //string[] m_RecordData = csvReader.ReadFields();
                        Participant_ID = sLine.Substring(0, 3).Trim();
                        Transaction_Type = sLine.Substring(3, 2).Trim();
                        From_Account_Type = sLine.Substring(5, 2).Trim();
                        To_Account_Type = sLine.Substring(7, 2).Trim();
                        Transaction_Serial_Number = sLine.Substring(9, 12).Trim();
                        Response_Code = sLine.Substring(21, 2).Trim();
                        PAN_Number = sLine.Substring(23, 19).Trim();
                        Member_Number = sLine.Substring(42, 1).Trim();
                        Approval_Number = sLine.Substring(43, 6).Trim();
                        System_Trace_Audit_Number = sLine.Substring(49, 12).Trim();
                        Transaction_Date = sLine.Substring(61, 6).Trim();
                        Transaction_Time = sLine.Substring(67, 6).Trim();

                        string timestamp = Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + "-" + Transaction_Date.Substring(4, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                        DateTime _datetime = DateTime.ParseExact(timestamp, "yy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);

                        Merchant_Category_Code = sLine.Substring(73, 4).Trim();

                        Card_Acceptor_Settlement_Date = sLine.Substring(77, 6).Trim();
                        Card_Acceptor_ID = sLine.Substring(83, 15).Trim();
                        Card_Acceptor_Terminal_ID = sLine.Substring(98, 8).Trim();
                        Card_Acceptor_Terminal_Location = sLine.Substring(106, 40).Trim();
                        Acquirer_ID = sLine.Substring(146, 11).Trim();
                        Acquirer_Settlement_Date = sLine.Substring(157, 6).Trim();
                        Transaction_Currency_code = sLine.Substring(163, 3).Trim();
                        Transaction_Amount = sLine.Substring(171, 8).Trim() + '.' + sLine.Substring(179, 2).Trim();
                        Actual_Transaction_Amount = sLine.Substring(171, 8).Trim() + '.' + sLine.Substring(179, 2).Trim();
                        Transaction_Acitivity_fee = sLine.Substring(196, 15).Trim();
                        Acquirer_settlement_Currency_Code = sLine.Substring(211, 3).Trim();
                        Acquirer_settlement_Amount = sLine.Substring(214, 13).Trim();
                        Acquirer_Settlement_Fee = sLine.Substring(229, 15).Trim();
                        Acquirer_settlement_processing_fee = sLine.Substring(244, 15).Trim();
                        Transaction_Acquirer_Conversion_Rate = sLine.Substring(259, 15).Trim();

                        URN = sLine.Substring(274, 35).Trim();

                        ReserveField1 = string.Empty;
                        ReserveField2 = string.Empty;
                        ReserveField3 = string.Empty;
                        ReserveField4 = string.Empty;
                        ReserveField5 = string.Empty;


                        _DataTable.Rows.Add(ClientID, Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code, PAN_Number, Member_Number,
                                            Approval_Number, System_Trace_Audit_Number, _datetime, Transaction_Time, Merchant_Category_Code, Card_Acceptor_Settlement_Date, Card_Acceptor_ID,
                                            Card_Acceptor_Terminal_ID, Card_Acceptor_Terminal_Location, Acquirer_ID, Acquirer_Settlement_Date, Transaction_Currency_code,
                                            Transaction_Amount, Transaction_Acitivity_fee, Transaction_Acitivity_fee, Acquirer_settlement_Currency_Code, Acquirer_settlement_Amount, Acquirer_Settlement_Fee, Acquirer_settlement_processing_fee,
                                            Transaction_Acquirer_Conversion_Rate, 0, Cycle, URN, ReserveField1, ReserveField2, ReserveField3, ReserveField4, ReserveField5,
                                            FileName, path, FileDate, System.DateTime.Now, null, null, UserName
                                           );
                        InsertCount++;

                        LineNo++;
                    }
                    catch (Exception ex)
                    {
                        InsertCount--;
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                }


                if (_DataTable.Rows.Count == 0)
                {

                }


            }
            catch (Exception ex)
            {
                InsertCount--;
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

            }

            return _DataTable;

        }


        public DataTable SplitterNPCIAEPSSettlement(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("NoTxns", typeof(int));
            _DataTable.Columns.Add("Debit", typeof(string));
            _DataTable.Columns.Add("Credit", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0, ErrorLine = 0;


            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            InsertCount = 0;
            TotalCount = 0;
            DataTable dtexcelsheetname = null;
            DataTable dtSheet = new DataTable();
            try
            {

                string conString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0;HDR=YES;' ";

                conString = string.Format(conString, path);

                try
                {
                    using (OleDbConnection connExcel = new OleDbConnection(conString))
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            connExcel.Open();
                            //Get the name of First Sheet.
                            dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            connExcel.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }


                string[] excelSheets = new string[dtexcelsheetname.Rows.Count];
                int j = 0;

                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    excelSheets[j] = row["TABLE_NAME"].ToString();
                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                    //string sht = dr[2].ToString().Replace("'", "");

                    using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                    {
                        using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                        {
                            using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                            {
                                //Read Data from First Sheet.
                                cmdExcelSheet.Connection = connExcelSheet;
                                connExcelSheet.Open();
                                cmdExcelSheet.CommandText = Getdatafromsheet1;
                                odaExcelSheet.SelectCommand = cmdExcelSheet;
                                odaExcelSheet.Fill(dtSheet);
                                connExcelSheet.Close();
                            }
                        }
                    }

                    if (dtSheet.Rows.Count > 1)
                    {
                        TotalCount = dtSheet.Rows.Count;
                        DateTime? Date;
                        Date = null;
                        //string[] Filesplit = FileName.Split('_');
                        //string[] Cycle = Filesplit[1].Split('.');

                        string DateArray = FileName.Substring(11, 2).ToString() + "-" + FileName.Substring(13, 2).ToString() + "-" + FileName.Substring(15, 2).ToString();
                        string Cycle = FileName.Substring(18, 2).ToString();
                        Date = DateTime.ParseExact(DateArray.ToString(), "dd-MM-yy", null);
                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            int Incr = 1;
                            string Description = string.Empty;
                            int NoTxns = 0;
                            decimal Debit = 0;
                            decimal Credit = 0;
                            string Remarks = string.Empty;


                            try
                            {

                                if (ds.Tables[0].Rows[0]["Description"].ToString() != "0")
                                {
                                    Description = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Description"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["NoTxns"].ToString() != "0")
                                {
                                    NoTxns = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["NoTxns"].ToString()) - Incr].ToString() != "" ? Convert.ToInt32(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["NoTxns"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Debit"].ToString() != "0")
                                {
                                    Debit = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Debit"].ToString()) - Incr].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Debit"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Credit"].ToString() != "0")
                                {
                                    Credit = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Credit"].ToString()) - Incr].ToString() != "" ? Convert.ToDecimal(dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Credit"].ToString()) - Incr]) : 0;
                                }
                                if (ds.Tables[0].Rows[0]["Remarks"].ToString() != "")
                                {
                                    Remarks = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Remarks"].ToString()) - Incr].ToString();
                                }

                                if (Description != "" && (Debit > 0 || Credit > 0))
                                    _DataTable.Rows.Add(ClientCode, Date, Cycle, Description, NoTxns, Debit, Credit, Remarks, FileName, DateTime.Now.ToString(), UserName, null, null);

                            }
                            catch (Exception ex)
                            {
                                ErrorLine++;
                                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            }
                            LineNo++;
                            j++;
                        }
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                ErrorLine++;
                InsertCount = 0;
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;

        }

        public DataTable SplitterNPCIAEPSAdjustment(string FilePath, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientID)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("ChannelID", typeof(string));
            _DataTable.Columns.Add("Txnuid", typeof(string));
            _DataTable.Columns.Add("TxnType", typeof(string));
            _DataTable.Columns.Add("Uid", typeof(string));
            _DataTable.Columns.Add("Adjdate", typeof(DateTime));
            _DataTable.Columns.Add("Adjtype", typeof(string));
            _DataTable.Columns.Add("ACQ", typeof(string));
            _DataTable.Columns.Add("ISR", typeof(string));
            _DataTable.Columns.Add("Response", typeof(string));
            _DataTable.Columns.Add("Txndate", typeof(DateTime));
            _DataTable.Columns.Add("RRN", typeof(string));
            _DataTable.Columns.Add("ATMID", typeof(string));
            _DataTable.Columns.Add("CardNo", typeof(string));
            _DataTable.Columns.Add("ChbDate", typeof(string));
            _DataTable.Columns.Add("ChbRef", typeof(string));
            _DataTable.Columns.Add("Txnamount", typeof(double));
            _DataTable.Columns.Add("Adjamount", typeof(double));

            _DataTable.Columns.Add("ACQFee", typeof(double));
            _DataTable.Columns.Add("ISSFee", typeof(double));
            _DataTable.Columns.Add("ACQFeeSW", typeof(double));
            _DataTable.Columns.Add("ISSFeeSW", typeof(double));
            _DataTable.Columns.Add("AdjFee", typeof(double));
            _DataTable.Columns.Add("NpciFee", typeof(double));
            _DataTable.Columns.Add("AcqFeeGST", typeof(double));
            _DataTable.Columns.Add("IssFeeGST", typeof(double));
            _DataTable.Columns.Add("NpciFeeGST", typeof(double));
            _DataTable.Columns.Add("Adjref", typeof(string));
            _DataTable.Columns.Add("Bankadjref", typeof(string));
            _DataTable.Columns.Add("Adjproof", typeof(string));
            _DataTable.Columns.Add("TrnCode", typeof(string));
            _DataTable.Columns.Add("AdjRaisedBy", typeof(string));
            _DataTable.Columns.Add("AdjReceivedBy", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));



            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("CREATEDBY", typeof(string));
            _DataTable.Columns.Add("MODIFIEDBY", typeof(string));

            try
            {
                string Txnuid = string.Empty; string TxnType = string.Empty;
                string Uid = string.Empty;
                string Adjtype = string.Empty;
                string ACQ = string.Empty; string ISR = string.Empty; string Response = string.Empty;
                string RRN = string.Empty; string ATMID = string.Empty; string CardNo = string.Empty; string ChbRef = string.Empty;

                string Adjref = string.Empty;
                string Bankadjref = string.Empty; string DATE = string.Empty; string DATE2 = string.Empty;
                string Adjproof = string.Empty; string TrnCode = string.Empty;

                string Remarks = string.Empty; //string CREATEDON = string.Empty; string MODIFIEDON = string.Empty;
                string AdjRaisedBy = string.Empty; string AdjReceivedBy = string.Empty;

                string FCQM = string.Empty;
                string AdjTime = string.Empty;
                string Cycle = string.Empty; string AcqCC = string.Empty;

                string PanEntryMode = string.Empty; string ServiceCode = string.Empty; string CardDataInputCapability = string.Empty;

                string ChbDate = string.Empty; string TATExpiryDate = string.Empty;
                double Txnamount; double Adjamount; double ACQFee; double ISSFee; double ACQFeeSW; double ISSFeeSW; double AdjFee; double NpciFee;
                double AcqFeeGST; double IssFeeGST; double NpciFeeGST;

                DataTable dtexcelsheetname = new DataTable();
                DataTable dtfillsheet1 = new DataTable();
                //double CustomerPenalty;double AcqSTLAmount;
                string conString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Text;HDR=YES;FMT=Delimited;' ";

                conString = string.Format(conString, FilePath.Replace(FileName, ""));

                string Getdatafromsheet1 = "SELECT * FROM [" + FileName + "]";

                using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                {
                    using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                    {
                        using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                        {
                            //Read Data from First Sheet.
                            cmdExcelSheet.Connection = connExcelSheet;
                            connExcelSheet.Open();
                            cmdExcelSheet.CommandText = Getdatafromsheet1;
                            odaExcelSheet.SelectCommand = cmdExcelSheet;
                            odaExcelSheet.Fill(dtfillsheet1);
                            connExcelSheet.Close();
                        }
                    }
                }

                TotalCount = dtfillsheet1.Rows.Count;
                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {
                    try
                    {
                        Txnuid = string.Empty;
                        Uid = string.Empty;
                        DATE = string.Empty;
                        Adjtype = string.Empty;
                        ACQ = string.Empty;
                        ISR = string.Empty;
                        Response = string.Empty;
                        DATE2 = string.Empty;
                        RRN = string.Empty;
                        ATMID = string.Empty;
                        CardNo = string.Empty;
                        ChbDate = string.Empty;
                        ChbRef = string.Empty;

                        Txnamount = 0;
                        Adjamount = 0;

                        ACQFee = 0;
                        ISSFee = 0;
                        ACQFeeSW = 0;
                        ISSFeeSW = 0;
                        AdjFee = 0;
                        NpciFee = 0;
                        AcqFeeGST = 0;
                        IssFeeGST = 0;
                        NpciFeeGST = 0;

                        Adjref = string.Empty;
                        Bankadjref = string.Empty;
                        Adjproof = string.Empty;

                        TrnCode = string.Empty;
                        AdjRaisedBy = string.Empty;
                        AdjReceivedBy = string.Empty;

                        Txnuid = dtfillsheet1.Rows[i][0].ToString().Replace("'", "");
                        Uid = dtfillsheet1.Rows[i][1].ToString().Replace("'", ""); //TransDescription
                        DATE = dtfillsheet1.Rows[i][2].ToString(); // AdjDate
                        DateTime _datetime;
                        //DateTime _datetime = DateTime.ParseExact(DATE, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        try
                        {

                            _datetime = DateTime.ParseExact(dtfillsheet1.Rows[i][2].ToString().Replace("AM", "").Replace("PM", "").Trim(), new[] {
                                                   "M/d/yyyy HH:mm:ss", "M-dd-yyyy HH:mm:ss", "M/dd/yyyy HH:mm:ss"
                                                   ,"MM/dd/yyyy HH:mm:ss", "MM-dd-yyyy HH:mm:ss", "MM/dd/yyyy HH:mm:ss"
                                                 , "M/d/yyyy HH:mm:ss tt", "M-dd-yyyy HH:mm:ss tt", "M/dd/yyyy HH:mm:ss tt"
                                                 , "MM/dd/yyyy HH:mm:ss tt", "MM-dd-yyyy HH:mm:ss tt", "MM/dd/yyyy HH:mm:ss tt"
                                                 ,"dd/MM/yyyy HH:mm:ss", "dd-MM-yyyy HH:mm:ss", "dd/MM/yyyy HH:mm:ss"
                            ,"dd/MM/yyyy HH:mm:ss tt", "dd-MM-yyyy HH:mm:ss tt", "dd/MM/yyyy HH:mm:ss tt"
                            ,"d/MM/yyyy HH:mm:ss tt", "d-MM-yyyy HH:mm:ss tt", "d/MM/yyyy HH:mm:ss tt"}, null, System.Globalization.DateTimeStyles.None);

                        }
                        catch
                        {
                            _datetime = Convert.ToDateTime(DATE);
                        }
                        ////try
                        ////{
                        ////    _datetime = DateTime.ParseExact(DATE, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        ////}
                        ////catch
                        ////{
                        ////    _datetime = DateTime.ParseExact(DATE, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                        ////}
                        ////// Adjdate = Convert.ToDateTime(dtfillsheet1.Rows[i][2].ToString()); //TYP
                        Adjtype = dtfillsheet1.Rows[i][3].ToString(); //TRANSACTIONTYPE


                        ACQ = dtfillsheet1.Rows[i][4].ToString(); //CDE

                        ISR = dtfillsheet1.Rows[i][5].ToString(); //CARDNUMBER
                        Response = dtfillsheet1.Rows[i][6].ToString().Replace("'", ""); //RVSL_RSN
                        //  DATE2 = dtfillsheet1.Rows[i][7].ToString();
                        DATE2 = dtfillsheet1.Rows[i][7].ToString() + " " + dtfillsheet1.Rows[i][8].ToString(); // TxnDate
                        DateTime _datetime3;
                        //DateTime _datetime2 = DateTime.ParseExact(DATE2, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                        try
                        {
                            //string strTxnsDate = DATE2.Replace("/", "-");
                            ////string txntime = "00:00:00";
                            ////strTxnsDate = strTxnsDate + " " + txntime;
                            ////TxnsDateTime = DateTime.ParseExact(TxnsDate, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                            //_datetime3 = DateTime.ParseExact(strTxnsDate, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);

                            _datetime3 = DateTime.ParseExact(dtfillsheet1.Rows[i][7].ToString().Replace("AM", "").Replace("PM", "").Trim(), new[] {
                                                   "M/d/yyyy HH:mm:ss", "M-dd-yyyy HH:mm:ss", "M/dd/yyyy HH:mm:ss"
                                                   ,"MM/dd/yyyy HH:mm:ss", "MM-dd-yyyy HH:mm:ss", "MM/dd/yyyy HH:mm:ss"
                                                 , "M/d/yyyy HH:mm:ss tt", "M-dd-yyyy HH:mm:ss tt", "M/dd/yyyy HH:mm:ss tt"
                                                 , "MM/dd/yyyy HH:mm:ss tt", "MM-dd-yyyy HH:mm:ss tt", "MM/dd/yyyy HH:mm:ss tt"
                                                 ,"dd/MM/yyyy HH:mm:ss", "dd-MM-yyyy HH:mm:ss", "dd/MM/yyyy HH:mm:ss"
                            ,"dd/MM/yyyy HH:mm:ss tt", "dd-MM-yyyy HH:mm:ss tt", "dd/MM/yyyy HH:mm:ss tt"
                            ,"d/MM/yyyy HH:mm:ss tt", "d-MM-yyyy HH:mm:ss tt", "d/MM/yyyy HH:mm:ss tt"}, null, System.Globalization.DateTimeStyles.None);
                        }
                        catch
                        {
                            _datetime3 = Convert.ToDateTime(DATE2);
                        }
                        //try
                        //{
                        //    _datetime3 = DateTime.ParseExact(DATE2, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                        //}
                        //catch
                        //{
                        //    _datetime3 = DateTime.ParseExact(DATE2, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                        //}



                        //Txndate = Convert.ToDateTime(dtfillsheet1.Rows[i][7].ToString()); //TR_TIMESTAMP
                        RRN = dtfillsheet1.Rows[i][9].ToString().Replace("'", ""); //CurrencyCode
                        //RecInsCode = dtfillsheet1.Rows[i][6].ToString(); --//ReconeId
                        ATMID = dtfillsheet1.Rows[i][10].ToString().Replace("'", ""); //TRANSREFNO
                        CardNo = dtfillsheet1.Rows[i][11].ToString().Replace("'", ""); //TRANSREFNO
                        ChbDate = dtfillsheet1.Rows[i][12].ToString().Replace("'", ""); //TRANSREFNO

                        ChbRef = dtfillsheet1.Rows[i][13].ToString().Replace("'", "");  //ReconId   --//AuthCode

                        Txnamount = Convert.ToDouble(dtfillsheet1.Rows[i][14].ToString().Replace("'", "")); //AMOUNT
                        Adjamount = Convert.ToDouble(dtfillsheet1.Rows[i][15].ToString()); //AMOUNT

                        ACQFee = Convert.ToDouble(dtfillsheet1.Rows[i][16].ToString()); //AMOUNT
                        ISSFee = Convert.ToDouble(dtfillsheet1.Rows[i][17].ToString()); //AMOUNT
                        ACQFeeSW = Convert.ToDouble(dtfillsheet1.Rows[i][18].ToString()); //AMOUNT
                        ISSFeeSW = Convert.ToDouble(dtfillsheet1.Rows[i][19].ToString()); //AMOUNT
                        AdjFee = Convert.ToDouble(dtfillsheet1.Rows[i][20].ToString()); //AMOUNT
                        NpciFee = Convert.ToDouble(dtfillsheet1.Rows[i][21].ToString()); //AMOUNT
                        AcqFeeGST = Convert.ToDouble(dtfillsheet1.Rows[i][22].ToString()); //AMOUNT
                        IssFeeGST = Convert.ToDouble(dtfillsheet1.Rows[i][23].ToString()); //AMOUNT
                        NpciFeeGST = Convert.ToDouble(dtfillsheet1.Rows[i][24].ToString()); //AMOUNT


                        //NpciGST = Convert.ToDouble(dtfillsheet1.Rows[i][24].ToString()); //AMOUNT



                        Adjref = dtfillsheet1.Rows[i][25].ToString(); //CARDISSUER
                        Bankadjref = dtfillsheet1.Rows[i][26].ToString().Replace("'", "").Trim(); //TERMINALID
                        Adjproof = dtfillsheet1.Rows[i][27].ToString(); //TERMINALID

                        TrnCode = dtfillsheet1.Rows[i][28].ToString(); //TERMINALID
                        AdjRaisedBy = dtfillsheet1.Rows[i][29].ToString(); //TERMINALID
                        AdjReceivedBy = dtfillsheet1.Rows[i][30].ToString(); //TERMINALID 


                        _DataTable.Rows.Add(ClientID, "5", Txnuid, TxnType, Uid, _datetime, Adjtype, ACQ, ISR, Response, _datetime3, RRN, ATMID, CardNo.Trim()
, ChbDate, ChbRef, Txnamount, Adjamount, ACQFee, ISSFee, ACQFeeSW, ISSFeeSW, AdjFee, NpciFee,
                         AcqFeeGST, IssFeeGST, NpciFeeGST, Adjref, Bankadjref, Adjproof, TrnCode
                         , AdjRaisedBy, AdjReceivedBy, Remarks
                         , System.DateTime.Now, System.DateTime.Now, UserName, UserName);//, SwitchFilePath);
                        InsertCount++;
                        Uid = string.Empty;

                        Adjtype = string.Empty;
                        ACQ = string.Empty;
                        ISR = string.Empty;
                        Response = string.Empty;
                        RRN = string.Empty;
                        ATMID = string.Empty;
                        CardNo = string.Empty;
                        ChbDate = string.Empty;
                        ChbRef = string.Empty;
                        Adjref = string.Empty;
                        Bankadjref = string.Empty;

                        Adjproof = string.Empty;
                        Remarks = string.Empty;
                        TrnCode = string.Empty;
                        AdjRaisedBy = string.Empty;
                        AdjReceivedBy = string.Empty;

                        // TxnsDateTime.=null;

                    }
                    catch (Exception EX)
                    {
                        InsertCount--;
                        DBLog.InsertLogs(EX.Message.ToString(), ClientID, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }
                }
                if (_DataTable.Rows.Count == 0)
                {
                    InsertCount--;
                }
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientID, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;
        }

        public DataTable SplitterNPCIAEPSISSUER(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));

            string[] arrLines;

            string FORCEMATCH = string.Empty;
            string cycle = string.Empty;
            string timestamp = string.Empty;
            string timestamp1 = string.Empty;

            try
            {
                string LogType = dt.Rows[0]["FileName"].ToString();
                string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
                string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();

                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());


                arrLines = File.ReadAllLines(path, Encoding.Default);
                int totalrecords = arrLines.Length;

                string Participant_ID;
                string Transaction_Type;
                string From_Account_Type;
                string To_Account_Type;
                string Transaction_Serial_Number;
                string Response_Code;
                string PAN_Number;
                string Member_Number;
                string Approval_Number;
                string System_Trace_Audit_Number;
                string Transaction_Date;
                string Transaction_Time;


                string Merchant_Category_Code_;
                string Card_Acceptor_Settlement_Date;
                string Card_Acceptor_ID;
                string Card_Acceptor_Terminal_ID;
                string Card_Acceptor_Terminal_Location;
                string Acquirer_ID;
                string Network_ID;
                string Account_1_Number;
                string Account_1_Branch_ID;
                string Account_2_Number;
                string Account_2_Branch_ID;
                string Transaction_Currency_Code;
                //Eliminated Last two digit

                string Transaction_Amount;
                string Actual_Transaction_Amount;
                //***********//
                string Transaction_Activity_Fee;
                string Issuer_Settlement_Currency_Code;
                string Issuer_Settlement_Amount;
                string Issuer_Settlement_Fee;
                string Issuer_Settlement_Processing_Fee;
                string Cardholder_Billing_Currency_Code;
                string Cardholder_Billing_Amount;
                string Cardholder_Billing_Activity_Fee;
                string Cardholder_Billing_Processing_Fee;
                string Cardholder_Billing_Service_Fee;
                string Transaction_Issuer_Conversion_Rate;
                string Transaction_Cardholder_Conversion_Rate;
                DateTime? _datetime = null;
                DateTime? _datetime1 = null;

                foreach (string m_RecordData in File.ReadAllLines(path))
                {
                    try
                    {
                        LineNo++;
                        Participant_ID = m_RecordData.Substring(0, 2).Trim();
                        Transaction_Type = m_RecordData.Substring(3, 2).Trim();
                        From_Account_Type = m_RecordData.Substring(5, 2).Trim();
                        To_Account_Type = m_RecordData.Substring(7, 2).Trim();
                        Transaction_Serial_Number = m_RecordData.Substring(9, 12).Trim();
                        Response_Code = m_RecordData.Substring(21, 2).Trim();
                        PAN_Number = m_RecordData.Substring(23, 19).Trim();
                        Member_Number = m_RecordData.Substring(42, 1).Trim();
                        Approval_Number = m_RecordData.Substring(43, 6).Trim();
                        System_Trace_Audit_Number = m_RecordData.Substring(49, 12).Trim();
                        Transaction_Date = m_RecordData.Substring(61, 6).Trim();
                        Transaction_Time = m_RecordData.Substring(67, 6).Trim();


                        Merchant_Category_Code_ = m_RecordData.Substring(73, 4).Trim();
                        Card_Acceptor_Settlement_Date = m_RecordData.Substring(77, 6).Trim();
                        Card_Acceptor_ID = m_RecordData.Substring(83, 15).Trim();
                        Card_Acceptor_Terminal_ID = m_RecordData.Substring(98, 8).Trim();
                        Card_Acceptor_Terminal_Location = m_RecordData.Substring(106, 40).Trim();
                        Acquirer_ID = m_RecordData.Substring(146, 11).Trim();
                        Network_ID = m_RecordData.Substring(157, 3).Trim();
                        Account_1_Number = m_RecordData.Substring(160, 19).Trim();
                        Account_1_Branch_ID = m_RecordData.Substring(179, 10).Trim();
                        Account_2_Number = m_RecordData.Substring(189, 19).Trim();
                        Account_2_Branch_ID = m_RecordData.Substring(208, 10).Trim();
                        Transaction_Currency_Code = m_RecordData.Substring(218, 3).Trim();

                        Transaction_Amount = m_RecordData.Substring(221, 15).Trim();
                        Actual_Transaction_Amount = m_RecordData.Substring(236, 13).Trim();

                        Transaction_Activity_Fee = m_RecordData.Substring(251, 15).Trim();
                        Issuer_Settlement_Currency_Code = m_RecordData.Substring(266, 3).Trim();
                        Issuer_Settlement_Amount = m_RecordData.Substring(269, 13).Trim();
                        Issuer_Settlement_Fee = m_RecordData.Substring(284, 15).Trim();
                        Issuer_Settlement_Processing_Fee = m_RecordData.Substring(299, 15).Trim();
                        Cardholder_Billing_Currency_Code = m_RecordData.Substring(314, 3).Trim();
                        Cardholder_Billing_Amount = m_RecordData.Substring(317, 15).Trim();
                        Cardholder_Billing_Activity_Fee = m_RecordData.Substring(332, 15).Trim();
                        Cardholder_Billing_Processing_Fee = m_RecordData.Substring(347, 15).Trim();
                        Cardholder_Billing_Service_Fee = m_RecordData.Substring(362, 15).Trim();
                        Transaction_Issuer_Conversion_Rate = m_RecordData.Substring(377, 15).Trim();
                        Transaction_Cardholder_Conversion_Rate = m_RecordData.Substring(392, 15).Trim();

                        _datetime = null;
                        _datetime1 = null;

                        cycle = FileName.Substring(15, 2).Trim();

                        timestamp = Transaction_Date.Substring(0, 2).ToString() + "-" + Transaction_Date.Substring(2, 2).ToString() + "-" + Transaction_Date.Substring(4, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();
                        _datetime = DateTime.ParseExact(timestamp, "yy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);



                        timestamp1 = FileName.Substring(12, 2).ToString() + "-" + FileName.Substring(10, 2).ToString() + "-" + FileName.Substring(8, 2).ToString();
                        _datetime1 = DateTime.ParseExact(timestamp1, "yy-MM-dd", CultureInfo.InvariantCulture);

                        _DataTable.Rows.Add(ClientID, Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code,
                                        PAN_Number, Member_Number, Approval_Number, System_Trace_Audit_Number, _datetime, Transaction_Time, Merchant_Category_Code_,
                                        Card_Acceptor_Settlement_Date, Card_Acceptor_ID, Card_Acceptor_Terminal_ID, Card_Acceptor_Terminal_Location, Acquirer_ID, Network_ID,
                                        Account_1_Number, Account_1_Branch_ID, Account_2_Number, Account_2_Branch_ID, Transaction_Currency_Code, Transaction_Amount,
                                        Actual_Transaction_Amount, Transaction_Activity_Fee, Issuer_Settlement_Currency_Code, Issuer_Settlement_Amount, Issuer_Settlement_Fee,
                                        Issuer_Settlement_Processing_Fee, Cardholder_Billing_Currency_Code, Cardholder_Billing_Amount, Cardholder_Billing_Activity_Fee,
                                        Cardholder_Billing_Processing_Fee, Cardholder_Billing_Service_Fee, Transaction_Issuer_Conversion_Rate, Transaction_Cardholder_Conversion_Rate,
                                        cycle, FileName, path, _datetime1, UserName, System.DateTime.Now, null, null);


                        InsertCount++;
                        TotalCount++;
                    }
                    catch (Exception ex)
                    {
                        InsertCount--;
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                }

            }
            catch (Exception ex)
            {
                InsertCount--;
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

            }

            return _DataTable;
        }

    }
}
