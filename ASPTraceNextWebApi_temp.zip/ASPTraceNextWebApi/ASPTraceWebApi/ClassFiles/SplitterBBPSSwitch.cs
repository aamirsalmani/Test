﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ASPTraceWebApi
{
    public class SplitterBBPSSwitch : SwitchBBPSFileSplitter
    {
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;

        public SplitterBBPSSwitch(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }
        public DataTable SplitData(string FilePath, string FileName, string UserName, string BankCode, out int InsertCount, out int TotalCount)
        {
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;

            DataTable _DataTable = new DataTable();
            try
            {
                _DataTable.Columns.Add("ClientID", typeof(string));
                _DataTable.Columns.Add("ChannelID", typeof(string));
                _DataTable.Columns.Add("ModeID", typeof(string));
                _DataTable.Columns.Add("TransID", typeof(string));
                _DataTable.Columns.Add("CCTransID", typeof(string));
                _DataTable.Columns.Add("PartnerReferenceNumber", typeof(string));
                _DataTable.Columns.Add("TerminalID", typeof(string));
                _DataTable.Columns.Add("BankName", typeof(string));
                _DataTable.Columns.Add("FranchiseID", typeof(string));
                _DataTable.Columns.Add("FranchiseName", typeof(string));
                _DataTable.Columns.Add("BCAgentId", typeof(string));
                _DataTable.Columns.Add("AgentName", typeof(string));
                _DataTable.Columns.Add("BillNumber", typeof(string));
                _DataTable.Columns.Add("BillCat", typeof(string));
                _DataTable.Columns.Add("BillerName", typeof(string));
                _DataTable.Columns.Add("TransDate", typeof(DateTime));
                _DataTable.Columns.Add("TransAmount", typeof(decimal));
                _DataTable.Columns.Add("TransType", typeof(string));
                _DataTable.Columns.Add("CCF", typeof(decimal));
                _DataTable.Columns.Add("BaseAmount", typeof(decimal));
                _DataTable.Columns.Add("GST", typeof(decimal));
                _DataTable.Columns.Add("GrossAmount", typeof(decimal));
                _DataTable.Columns.Add("TransStatus", typeof(string));
                _DataTable.Columns.Add("ConsumerNo", typeof(string));
                _DataTable.Columns.Add("DateSortID", typeof(string));
                _DataTable.Columns.Add("CreatedOn", typeof(string));
                _DataTable.Columns.Add("Createdby", typeof(string));
                _DataTable.Columns.Add("ModifiedyOn", typeof(string));
                _DataTable.Columns.Add("Modifiedyby", typeof(string));
                _DataTable.Columns.Add("FileName", typeof(string));
                _DataTable.Columns.Add("FilePath", typeof(string));
                _DataTable.Columns.Add("BillerID", typeof(string));
                _DataTable.Columns.Add("BillerCoverage", typeof(string));
                _DataTable.Columns.Add("BillType", typeof(string));
                _DataTable.Columns.Add("CCFGST", typeof(decimal));
                _DataTable.Columns.Add("CCAResponseCode", typeof(string));
                _DataTable.Columns.Add("NPCIResponseCode", typeof(string));
                _DataTable.Columns.Add("ChannelPartnerRefNo", typeof(string));
                _DataTable.Columns.Add("DeviceType", typeof(string));
                _DataTable.Columns.Add("State", typeof(string));
                _DataTable.Columns.Add("City", typeof(string));
                _DataTable.Columns.Add("Area", typeof(string));
                _DataTable.Columns.Add("Pincode", typeof(string));

                _DataTable = SWFile_BBPS_Process(FilePath, _DataTable, UserName, BankCode, FileName, out InsertCount, out TotalCount);

                foreach (DataRow row in _DataTable.Rows)
                {

                    row["ChannelID"] = (int)TxnsChannelID.BBPS;
                    row["ModeID"] = (int)TxnsMode.ACQUIRER;

                }
            }
            catch (Exception EX)
            {
                
                objCommon.InsertLogs(EX.Message.ToString(), BankCode, "SplitterBBPSSwitch.cs", "SplitData", LineNo, FileName, UserName, 'E');

            }
            return _DataTable;
        }
    }
}
