﻿
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using TextFieldParserCore;
using Utility;

namespace ASPTraceWebApi
{
    public class SplitterBFSCommon
    {
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public SplitterBFSCommon(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        DateTimeConverter objDateTimeConverter = new DateTimeConverter();
        System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");
        public DataSet SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            
            string relativePath = _configuration["AppSettings:MekKey2Path"];

            
            

            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            


            DataSet ds = new DataSet();
            DataSet DSCommon = new DataSet();
            DataTable dtAcquirer = new DataTable();
            DataTable dtIssuer = new DataTable();
            dtAcquirer.Columns.Add("ClientID", typeof(int));
            dtAcquirer.Columns.Add("AcquirerBank", typeof(string));
            dtAcquirer.Columns.Add("TxnsDateTime", typeof(string));
            dtAcquirer.Columns.Add("CardNumber", typeof(string));
            dtAcquirer.Columns.Add("TxnsTYPE", typeof(string));
            dtAcquirer.Columns.Add("AcqReferenceNumber", typeof(string));
            dtAcquirer.Columns.Add("ReferenceNumber", typeof(string));
            dtAcquirer.Columns.Add("TerminalId", typeof(string));
            dtAcquirer.Columns.Add("StanNumber", typeof(string));
            dtAcquirer.Columns.Add("TxnsAmount", typeof(decimal));
            dtAcquirer.Columns.Add("TxnsCurrency", typeof(string));
            dtAcquirer.Columns.Add("TxnsStatus", typeof(string));
            dtAcquirer.Columns.Add("FeeAmount", typeof(decimal));
            dtAcquirer.Columns.Add("FeeStatus", typeof(string));
            dtAcquirer.Columns.Add("Remarks", typeof(string));
            dtAcquirer.Columns.Add("ReserveField1", typeof(string));
            dtAcquirer.Columns.Add("ReserveField2", typeof(string));
            dtAcquirer.Columns.Add("ReserveField3", typeof(string));
            dtAcquirer.Columns.Add("ReserveField4", typeof(string));
            dtAcquirer.Columns.Add("ReserveField5", typeof(string));
            dtAcquirer.Columns.Add("RevEntryLeg", typeof(int));
            dtAcquirer.Columns.Add("NoOfDuplicate", typeof(int));
            dtAcquirer.Columns.Add("FileName", typeof(string));
            dtAcquirer.Columns.Add("FilePath", typeof(string));
            dtAcquirer.Columns.Add("FileDate", typeof(DateTime));
            dtAcquirer.Columns.Add("CreatedOn", typeof(DateTime));
            dtAcquirer.Columns.Add("ModifiedOn", typeof(DateTime));
            dtAcquirer.Columns.Add("CreatedBy", typeof(string));
            dtAcquirer.Columns.Add("ModifiedBy", typeof(string));

            dtIssuer.Columns.Add("ClientID", typeof(int));
            dtIssuer.Columns.Add("AcquirerBank", typeof(string));
            dtIssuer.Columns.Add("TxnsDateTime", typeof(string));
            dtIssuer.Columns.Add("CardNumber", typeof(string));
            dtIssuer.Columns.Add("TxnsTYPE", typeof(string));
            dtIssuer.Columns.Add("AcqReferenceNumber", typeof(string));
            dtIssuer.Columns.Add("ReferenceNumber", typeof(string));
            dtIssuer.Columns.Add("TerminalId", typeof(string));
            dtIssuer.Columns.Add("StanNumber", typeof(string));
            dtIssuer.Columns.Add("TxnsAmount", typeof(decimal));
            dtIssuer.Columns.Add("TxnsCurrency", typeof(string));
            dtIssuer.Columns.Add("TxnsStatus", typeof(string));
            dtIssuer.Columns.Add("FeeAmount", typeof(decimal));
            dtIssuer.Columns.Add("FeeStatus", typeof(string));
            dtIssuer.Columns.Add("Remarks", typeof(string));
            dtIssuer.Columns.Add("ReserveField1", typeof(string));
            dtIssuer.Columns.Add("ReserveField2", typeof(string));
            dtIssuer.Columns.Add("ReserveField3", typeof(string));
            dtIssuer.Columns.Add("ReserveField4", typeof(string));
            dtIssuer.Columns.Add("ReserveField5", typeof(string));
            dtIssuer.Columns.Add("RevEntryLeg", typeof(int));
            dtIssuer.Columns.Add("NoOfDuplicate", typeof(int));
            dtIssuer.Columns.Add("FileName", typeof(string));
            dtIssuer.Columns.Add("FilePath", typeof(string));
            dtIssuer.Columns.Add("FileDate", typeof(DateTime));
            dtIssuer.Columns.Add("CreatedOn", typeof(DateTime));
            dtIssuer.Columns.Add("ModifiedOn", typeof(DateTime));
            dtIssuer.Columns.Add("CreatedBy", typeof(string));
            dtIssuer.Columns.Add("ModifiedBy", typeof(string));

            string BankName = string.Empty;
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string ClientName = dt.Rows[0]["ClientName"].ToString();
            string RevEntryLeg = "1";
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;
            using (TextFieldParser csvReader = new TextFieldParser(path))
            {
                csvReader.SetDelimiters(new string[] { "," });
                csvReader.HasFieldsEnclosedInQuotes = true;

                while (!csvReader.EndOfData)
                {
                    LineNo++;
                    try
                    {
                        string[] colFields = csvReader.ReadFields();
                        //string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                        //line1 = line1.Replace(",\"", ",").Replace("\",", ",");

                        /*
                        if (line1.Contains('"'))
                        {
                            string b = line1.Substring(line1.IndexOf('"'), line1.LastIndexOf('"') + 1 - line1.IndexOf('"'));
                            string c = b.Replace("\"", "").Replace(",", "");
                            line1 = line1.Replace(b, c);
                        }*/
                        //string[] colFields = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                        int Incr = 1;

                        //string ClientID = string.Empty;                    
                        DateTime? TxnsMainDateTime;
                        TxnsMainDateTime = null;
                        string AcquirerBank = string.Empty;
                        string TxnsDateTime = string.Empty;
                        string CardNumber = string.Empty;
                        string TxnsTYPE = string.Empty;
                        string AcqReferenceNumber = string.Empty;
                        string ReferenceNumber = string.Empty;
                        string TerminalId = string.Empty;
                        string StanNumber = string.Empty;
                        string TxnsAmount = "0";
                        string TxnsCurrency = string.Empty;
                        string TxnsStatus = string.Empty;
                        string FeeAmount = "0";
                        string FeeStatus = string.Empty;
                        string Remarks = string.Empty;
                        string ECardNumber = string.Empty;

                        if (FileName.Contains("Acquirer Successful Transaction Detail Report") || FileName.Contains("Issuer Successful Transaction Detail Report"))
                        {

                            if (ds.Tables[0].Rows[0]["TxnsDateTime"].ToString() != "0")
                            {
                                TxnsDateTime = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsDateTime"].ToString())].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["CardNumber"].ToString() != "0")
                            {
                                CardNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["CardNumber"].ToString())].ToString();

                                if (CardNumber != "")
                                {
                                    ECardNumber = AesEncryption.EncryptString(CardNumber);;
                                }
                            }
                            if (ds.Tables[0].Rows[0]["TxnsTYPE"].ToString() != "0")
                            {
                                TxnsTYPE = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsTYPE"].ToString())].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["AcqReferenceNumber"].ToString() != "0")
                            {
                                AcqReferenceNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["AcqReferenceNumber"].ToString())].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["ReferenceNumber"].ToString() != "0")
                            {
                                ReferenceNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["ReferenceNumber"].ToString())].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["TerminalId"].ToString() != "0")
                            {
                                TerminalId = colFields[int.Parse(ds.Tables[0].Rows[0]["TerminalId"].ToString())].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["StanNumber"].ToString() != "0")
                            {
                                StanNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["StanNumber"].ToString())].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["TxnsAmount"].ToString() != "0")
                            {
                                TxnsAmount = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString())].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["TxnsCurrency"].ToString() != "0")
                            {
                                TxnsCurrency = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsCurrency"].ToString())].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["TxnsStatus"].ToString() != "0")
                            {
                                TxnsStatus = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsStatus"].ToString())].ToString();
                            }
                            if (ds.Tables[0].Rows[0]["Remarks"].ToString() != "0")
                            {
                                Remarks = colFields[int.Parse(ds.Tables[0].Rows[0]["Remarks"].ToString())].ToString();
                            }
                            long n;
                            if (long.TryParse(ReferenceNumber, out n))
                            {
                                if (FileName.Contains("Acquirer Successful Transaction Detail Report"))
                                {
                                    dtAcquirer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), ECardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, "", "", "", "", "", RevEntryLeg, 0, FileName, path, DateTime.Now, DateTime.Now, DateTime.Now, UserName, UserName);
                                }
                                else if (FileName.Contains("Issuer Successful Transaction Detail Report"))
                                {
                                    dtIssuer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), ECardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, "", "", "", "", "", RevEntryLeg, 0, FileName, path, DateTime.Now, DateTime.Now, DateTime.Now, UserName, UserName);
                                }
                            }
                        }
                        else if (FileName.Contains("Pending Transaction Detail Report"))
                        {
                            if (colFields.Contains("Acquirer Bank"))
                            {
                                BankName = colFields[5].ToString();
                            }
                            TxnsDateTime = colFields[3].ToString();
                            CardNumber = colFields[5].ToString();
                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);;
                            }
                            TxnsTYPE = colFields[6].ToString();
                            AcqReferenceNumber = colFields[7].ToString();
                            ReferenceNumber = colFields[9].ToString();
                            TerminalId = colFields[10].ToString();
                            StanNumber = colFields[11].ToString();
                            TxnsCurrency = colFields[12].ToString();
                            TxnsAmount = colFields[13].Replace(@",", "").ToString().Trim();
                            TxnsStatus = colFields[14].ToString();
                            Remarks = colFields[15].ToString();
                            long n;
                            if (long.TryParse(ReferenceNumber, out n))
                            {
                                if (ClientName == BankName)
                                {
                                    dtAcquirer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), ECardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, "", "", "", "", "", RevEntryLeg, 0, FileName, path, DateTime.Now, DateTime.Now, DateTime.Now, UserName, UserName);
                                }
                                else
                                {
                                    dtIssuer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), ECardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, "", "", "", "", "", RevEntryLeg, 0, FileName, path, DateTime.Now, DateTime.Now, DateTime.Now, UserName, UserName);
                                }
                            }

                        }
                        else if (FileName.Contains("Success Interchange Fee Detail Report"))
                        {
                            if (colFields.Contains("Acquirer Bank"))
                            {
                                BankName = colFields[5].ToString();
                            }
                            //colFields = colFields.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                            TxnsDateTime = colFields[3].ToString();
                            CardNumber = colFields[5].ToString();
                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);;
                            }
                            TxnsTYPE = colFields[6].ToString();
                            AcqReferenceNumber = colFields[7].ToString();
                            ReferenceNumber = colFields[9].ToString();
                            TerminalId = colFields[10].ToString();
                            StanNumber = colFields[11].ToString();
                            TxnsCurrency = colFields[12].ToString();
                            TxnsAmount = colFields[13].Replace(@",", "").ToString().Trim();
                            FeeAmount = colFields[14].Replace(@",", "").ToString().Trim();
                            FeeStatus = colFields[16].ToString();
                            Remarks = colFields[18].ToString();
                            long n;
                            if (long.TryParse(ReferenceNumber, out n))
                            {
                                if (ClientName == BankName)
                                {
                                    dtAcquirer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), ECardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, "", "", "", "", "", RevEntryLeg, 0, FileName, path, DateTime.Now, DateTime.Now, DateTime.Now, UserName, UserName);
                                }
                                else
                                {
                                    dtIssuer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), ECardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, "", "", "", "", "", RevEntryLeg, 0, FileName, path, DateTime.Now, DateTime.Now, DateTime.Now, UserName, UserName);
                                }
                            }

                        }
                        else if (FileName.Contains("Success Reversal Transaction Details Report"))
                        {
                            if (colFields.Contains("Acquirer Bank"))
                            {
                                BankName = colFields[5].ToString();
                            }
                            TxnsDateTime = colFields[4].ToString();
                            CardNumber = colFields[6].ToString();
                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);;
                            }
                            TxnsTYPE = colFields[7].ToString();
                            AcqReferenceNumber = colFields[9].ToString();
                            ReferenceNumber = colFields[10].ToString();
                            TerminalId = colFields[11].ToString();
                            StanNumber = colFields[12].ToString();
                            TxnsCurrency = colFields[15].ToString();
                            TxnsAmount = colFields[13].ToString();
                            TxnsStatus = colFields[14].ToString();
                            long n;
                            if (long.TryParse(ReferenceNumber, out n))
                            {
                                if (ClientName == BankName)
                                {
                                    dtAcquirer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), ECardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, "", "", "", "", "", RevEntryLeg, 0, FileName, path, DateTime.Now, DateTime.Now, DateTime.Now, UserName, UserName);
                                }
                                else
                                {
                                    dtIssuer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), ECardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, "", "", "", "", "", RevEntryLeg, 0, FileName, path, DateTime.Now, DateTime.Now, DateTime.Now, UserName, UserName);
                                }
                            }
                        }
                        else if (FileName.Contains("UnSuccess Reversal Transaction Details Report"))
                        {
                            if (colFields.Contains("Acquirer Bank"))
                            {
                                BankName = colFields[5].ToString();
                            }
                            TxnsDateTime = colFields[5].ToString();
                            CardNumber = colFields[7].ToString();
                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);;
                            }
                            TxnsTYPE = colFields[8].ToString();
                            AcqReferenceNumber = colFields[10].ToString();
                            ReferenceNumber = colFields[11].ToString();
                            TerminalId = colFields[12].ToString();
                            StanNumber = colFields[13].ToString();
                            TxnsCurrency = colFields[16].ToString();
                            TxnsAmount = colFields[14].ToString();
                            TxnsStatus = colFields[19].ToString();
                            long n;
                            if (long.TryParse(ReferenceNumber, out n))
                            {
                                if (ClientName == BankName)
                                {
                                    dtAcquirer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), ECardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, "", "", "", "", "", RevEntryLeg, 0, FileName, path, DateTime.Now, DateTime.Now, DateTime.Now, UserName, UserName);
                                }
                                else
                                {
                                    dtIssuer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), ECardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, "", "", "", "", "", RevEntryLeg, 0, FileName, path, DateTime.Now, DateTime.Now, DateTime.Now, UserName, UserName);
                                }
                            }

                        }


                    }

                    //}
                    catch (Exception ex)
                    {

                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterBFSCommon.cs", "SplitData", LineNo, FileName, UserName, 'E');
                        objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterBFSCommon.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    }
                }

            }
            if (dtAcquirer.Rows.Count > 0)
            {
                InsertCount = dtAcquirer.Rows.Count;
            }
            if (dtIssuer.Rows.Count > 0)
            {
                InsertCount = dtIssuer.Rows.Count;
            }

            DSCommon.Tables.Add(dtAcquirer);
            DSCommon.Tables.Add(dtIssuer);
            return DSCommon;

        }

        public DataTable SwitchFileSMobiware_TLFSpliter(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataSet DT = new DataSet();
            string[] arrLines;
            string[] split;
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());
            int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());


            if (ModeID == 15)
            {
                ModeID = 2;
            }
            else
            {

            }

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(Int32));
            _DataTable.Columns.Add("ChannelId", typeof(Int32));
            _DataTable.Columns.Add("ModeId", typeof(Int32));
            _DataTable.Columns.Add("MessageType", typeof(string));
            _DataTable.Columns.Add("orgId", typeof(string));
            _DataTable.Columns.Add("RefId", typeof(string));
            _DataTable.Columns.Add("MessageId", typeof(string));
            _DataTable.Columns.Add("TxnRefId", typeof(string));
            _DataTable.Columns.Add("ClientRequestId", typeof(string));
            _DataTable.Columns.Add("CustMobileNo", typeof(string));
            _DataTable.Columns.Add("CustomerInfo", typeof(string));
            _DataTable.Columns.Add("AgentId", typeof(string));
            _DataTable.Columns.Add("AgentChannel", typeof(string));
            _DataTable.Columns.Add("AgentInfo", typeof(string));
            _DataTable.Columns.Add("PartnerId", typeof(string));
            _DataTable.Columns.Add("PartnerName", typeof(string));
            _DataTable.Columns.Add("BillerId", typeof(string));
            _DataTable.Columns.Add("BillerName", typeof(string));
            _DataTable.Columns.Add("BillerCategory", typeof(string));
            _DataTable.Columns.Add("BillInfo", typeof(string));
            _DataTable.Columns.Add("ApprovelRefNo", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("ResponseReason", typeof(string));
            _DataTable.Columns.Add("BillerResponseInfo", typeof(string));
            _DataTable.Columns.Add("AdditionalInfo", typeof(string));
            _DataTable.Columns.Add("PaymentMode", typeof(string));
            _DataTable.Columns.Add("QuickPay", typeof(string));
            _DataTable.Columns.Add("SplitPay", typeof(string));
            _DataTable.Columns.Add("Amount", typeof(decimal));
            _DataTable.Columns.Add("Currency", typeof(string));
            _DataTable.Columns.Add("CustConvFee", typeof(decimal));
            _DataTable.Columns.Add("PaymentChannel", typeof(string));
            _DataTable.Columns.Add("PaymentInfo", typeof(string));
            _DataTable.Columns.Add("TransactionType", typeof(string));
            _DataTable.Columns.Add("TxnDateTime", typeof(DateTime));
            _DataTable.Columns.Add("PayBy", typeof(string));
            _DataTable.Columns.Add("ComplianceReason", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));

            string sLine = string.Empty;
            string sLine1 = string.Empty;
            string sLine2 = string.Empty;
            string FORCEMATCH = string.Empty;
            string cycle = string.Empty;
            try
            {
                arrLines = File.ReadAllLines(path, Encoding.Default);
                int totalrecords = arrLines.Length;
                for (int i = 0; i < totalrecords; i++)
                {
                    try
                    {
                        sLine = arrLines[i];
                        TotalCount = File.ReadAllLines(path).Length - 1;
                        sLine2 = Regex.Replace(sLine, @"(\{""[^}]*?\})|(\[{[^]]*?}\])", m => m.Value.Replace(",", ""));
                        sLine2 = sLine2.Replace("},{", "}{");

                        split = sLine2.Replace("\"", "").Split(',');

                        string orgId = string.Empty;
                        string RefId = string.Empty;
                        string MessageId = string.Empty;
                        string TxnRefId = string.Empty;
                        string MessageType = string.Empty;
                        string ClientRequestId = string.Empty;
                        string CustMobileNo = string.Empty;
                        string CustomerInfo = string.Empty;
                        string AgentId = string.Empty;
                        string AgentChannel = string.Empty;
                        string AgentInfo1 = string.Empty;
                        string AgentInfo2 = string.Empty;
                        string AgentInfo = string.Empty;
                        string PartnerId = string.Empty;
                        string PartnerName = string.Empty;
                        string BillerId = string.Empty;
                        string BillerName = string.Empty;
                        string BillerCategory = string.Empty;
                        string BillInfo = string.Empty;
                        string ApprovelRefNo = string.Empty;
                        string ResponseCode = string.Empty;
                        string ResponseReason = string.Empty;
                        string BillerResponseInfo = string.Empty;
                        string AdditionalInfo = string.Empty;
                        string PaymentMode = string.Empty;
                        string QuickPay = string.Empty;
                        string SplitPay = string.Empty;
                        decimal Amount = 0;
                        string Currency = string.Empty;
                        decimal CustConvFee = 0;
                        string PaymentChannel = string.Empty;
                        string PaymentInfo = string.Empty;
                        string TransactionType = string.Empty;
                        DateTime? TxnDateTime = null;
                        string PayBy = string.Empty;
                        string ComplianceReason = string.Empty;


                        MessageType = split[0].Trim();
                        orgId = split[1].Trim();
                        RefId = split[2].Trim();
                        MessageId = split[3].Trim();
                        TxnRefId = split[4].Trim();
                        ClientRequestId = split[5].Trim();
                        CustMobileNo = split[6].Trim();
                        CustomerInfo = split[7].Trim().Replace("}{", "},{").Replace("value:", ",value:").Trim();
                        AgentId = split[8].Trim();
                        AgentChannel = split[9].Trim();
                        //AgentInfo1 = split[10].Replace("|", "\"\",\"\"").Replace("}{", "},{").Trim();
                        //AgentInfo2 = split[11].Replace("|", "\"\",\"\"").Replace("}{", "},{").Trim();
                        // AgentInfo = AgentInfo1 + ',' + AgentInfo2;
                        AgentInfo = split[10].Trim().Replace("}{", "},{").Replace("value:", ",value:").Trim();
                        PartnerId = split[11].Trim();
                        PartnerName = split[12].Trim();
                        BillerId = split[13].Trim();
                        BillerName = split[14].Trim();
                        BillerCategory = split[15].Trim();
                        BillInfo = split[16].Trim().Replace("}{", "},{").Replace("value:", ",value:").Trim();
                        ApprovelRefNo = split[17].Trim();
                        ResponseCode = split[18].Trim();
                        ResponseReason = split[19].Trim();
                        BillerResponseInfo = split[20].Trim().Replace("}{", "},{").Replace("value:", ",value:").Trim();
                        AdditionalInfo = split[21].Trim();
                        PaymentMode = split[22].Trim();
                        QuickPay = split[23].Trim();
                        SplitPay = split[24].Trim();
                        Amount = Convert.ToDecimal(split[25].Trim());
                        Currency = split[26].Trim();
                        CustConvFee = Convert.ToDecimal(split[27].Trim());
                        PaymentChannel = split[28].Trim();
                        PaymentInfo = split[29].Trim().Replace("}{", "},{").Replace("value:", ",value:").Trim();
                        TransactionType = split[30].Trim();
                        TxnDateTime = DateTime.ParseExact(split[31].Trim(), new[] { "yy-MM-dd HH:mm:ss", "dd/MM/yyyy", "yyyy-MM-dd HH:mm:ss" }, null, System.Globalization.DateTimeStyles.None);
                        PayBy = split[32].Trim();
                        ComplianceReason = split[33].Trim();




                        _DataTable.Rows.Add(
                            ClientID, ChannelID, ModeID,
                                            MessageType,
                                            orgId,
                                            RefId,
                                            MessageId,
                                            TxnRefId,
                                            ClientRequestId,
                                            CustMobileNo,
                                            CustomerInfo,
                                            AgentId,
                                            AgentChannel,
                                            AgentInfo,
                                            PartnerId,
                                            PartnerName,
                                            BillerId,
                                            BillerName,
                                            BillerCategory,
                                            BillInfo,
                                            ApprovelRefNo,
                                            ResponseCode,
                                            ResponseReason,
                                            BillerResponseInfo,
                                            AdditionalInfo,
                                            PaymentMode,
                                            QuickPay,
                                            SplitPay,
                                            Amount,
                                            Currency,
                                            CustConvFee,
                                            PaymentChannel,
                                            PaymentInfo,
                                            TransactionType,
                                            TxnDateTime,
                                            PayBy,
                                            ComplianceReason,
                                            System.DateTime.Now,
                                            UserName,
                                            null,
                                            "",
                                            FileName,
                                            path
                                          );

                        LineNo++;
                        InsertCount++;
                        TotalCount++;
                    }
                    catch (Exception ex)
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterBFSCommon.cs", "SwitchFileSMobiware_TLFSpliter", LineNo, FileName, UserName, 'E');

            }

            return _DataTable;
        }

    }
}
