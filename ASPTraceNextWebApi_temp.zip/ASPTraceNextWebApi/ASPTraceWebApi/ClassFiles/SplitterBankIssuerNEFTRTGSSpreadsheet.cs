﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;
using Utility;
using System.Data.OleDb;

namespace ASPTraceWebApi
{
    public class SplitterBankIssuerNEFTRTGSSpreadsheet
    {
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;

        public SplitterBankIssuerNEFTRTGSSpreadsheet(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        public string GetUniqueID()
        {
            Random rnd = new Random();
            int value = rnd.Next(1000, 9999);
            string UniqueID = DateTime.Now.ToString("ddMMyyyyHHmmssfff") + value.ToString();
            return UniqueID;

        }

        public DataTable SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TranRefNum", typeof(string));
            _DataTable.Columns.Add("UTRNo", typeof(string));
            _DataTable.Columns.Add("AMOUNT", typeof(double));
            _DataTable.Columns.Add("Tr_timestamp", typeof(DateTime));
            _DataTable.Columns.Add("SenderIFSC", typeof(string));
            _DataTable.Columns.Add("SenderAccount", typeof(string));
            _DataTable.Columns.Add("SenderCustName", typeof(string));
            _DataTable.Columns.Add("BenefIFSC", typeof(string));
            _DataTable.Columns.Add("BenefAccount", typeof(string));
            _DataTable.Columns.Add("BenefCustName", typeof(string));
            _DataTable.Columns.Add("SenderRecInfo", typeof(string));
            _DataTable.Columns.Add("Status", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("AcknFLg", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;

            
            string relativePath = _configuration["AppSettings:MekKey2Path"];

            
            

            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());
            int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());
            InsertCount = 0;
            TotalCount = 0;
            DataTable dtexcelsheetname = null;

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;
            try
            {
                foreach (string line in File.ReadAllLines(path))
                {
                    LineNo++;
                    try
                    {

                        string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                        string[] colFields = line1.Split('!');

                        string SEQNO = string.Empty;
                        string TranRefNum = string.Empty;
                        string UTRNo = string.Empty;
                        string AMOUNT = "0";
                        string Txndate = string.Empty;
                        string Tr_timestamp = string.Empty;
                        string SenderIFSC = string.Empty;
                        string SenderAccount = string.Empty;
                        string SenderCustName = string.Empty;
                        string BenefIFSC = string.Empty;
                        string BenefAccount = string.Empty;
                        string BenefCustName = string.Empty;
                        string SenderRecInfo = string.Empty;
                        string Status = string.Empty;
                        string BATCHID = string.Empty;
                        string AcknFLg = string.Empty;
                        string DRCR = string.Empty;

                        if (FileName.Contains("INWARD"))
                        {

                            BATCHID = colFields[1].ToString().Trim();
                            string[] TerminalSplit = BATCHID.Split('-');

                            TranRefNum = TerminalSplit[4].ToString().Trim();
                            UTRNo = "";
                            AMOUNT = colFields[4].ToString();

                            Txndate = (colFields[0].ToString().Trim());
                            string timestamp = Txndate.Substring(0, 2).ToString() + "-" + Txndate.Substring(3, 2).ToString() + "-" + Txndate.Substring(6, 4).ToString() + " " + Txndate.Substring(11, 2).ToString() + ":" + Txndate.Substring(14, 2).ToString() + ":" + Txndate.Substring(17, 2).ToString();
                            Tr_timestamp = DateTime.ParseExact(timestamp, "dd-MM-yyyy HH:mm:ss", null).ToString("yyyy-MM-dd HH:mm:ss");
                            SenderIFSC = TerminalSplit[1].ToString().Trim();
                            SenderAccount = (colFields[2].ToString().Trim());
                            SenderCustName = TerminalSplit[3].ToString().Trim();
                            BenefIFSC = "";
                            BenefAccount = "";
                            BenefCustName = TerminalSplit[2].ToString().Trim();
                            SenderRecInfo = (colFields[2].ToString().Trim());
                            FileName = path;
                            Status = TerminalSplit[0].ToString().Trim();


                            SEQNO = (colFields[3].ToString().Trim());
                            if (SEQNO == "C")
                            {
                                AcknFLg = "INWARD";
                            }
                            else
                            {
                                AcknFLg = "OUTWARD";

                            }
                            LineNo++;
                            _DataTable.Rows.Add(ClientID, ChannelID, ModeID, TranRefNum, UTRNo, Convert.ToDouble(AMOUNT).ToString(), Tr_timestamp, SenderIFSC, SenderAccount, SenderCustName, BenefIFSC, BenefAccount, BenefCustName, SenderRecInfo, Status, FileName, AcknFLg, DateTime.Now.ToString(), path, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);
                            InsertCount++;
                        }
                        else
                        {
                            BATCHID = colFields[1].ToString().Trim();
                            string[] TerminalSplit = BATCHID.Split('-');

                            TranRefNum = TerminalSplit[2].ToString().Trim();
                            UTRNo = "";
                            AMOUNT = colFields[4].ToString();

                            Txndate = (colFields[0].ToString().Trim());
                            string timestamp = Txndate.Substring(0, 2).ToString() + "-" + Txndate.Substring(3, 2).ToString() + "-" + Txndate.Substring(6, 4).ToString() + " " + Txndate.Substring(11, 2).ToString() + ":" + Txndate.Substring(14, 2).ToString() + ":" + Txndate.Substring(17, 2).ToString();
                            Tr_timestamp = DateTime.ParseExact(timestamp, "dd-MM-yyyy HH:mm:ss", null).ToString("yyyy-MM-dd HH:mm:ss");
                            SenderIFSC = TerminalSplit[1].ToString().Trim();
                            SenderAccount = (colFields[2].ToString().Trim());
                            SenderCustName = TerminalSplit[3].ToString().Trim();
                            BenefIFSC = "";
                            BenefAccount = "";
                            BenefCustName = TerminalSplit[2].ToString().Trim();
                            SenderRecInfo = (colFields[2].ToString().Trim());
                            FileName = path;
                            Status = TerminalSplit[0].ToString().Trim();


                            SEQNO = (colFields[3].ToString().Trim());
                            if (SEQNO == "C")
                            {
                                AcknFLg = "INWARD";
                            }
                            else
                            {
                                AcknFLg = "OUTWARD";

                            }

                            LineNo++;
                            _DataTable.Rows.Add(ClientID, ChannelID, ModeID, TranRefNum, UTRNo, Convert.ToDouble(AMOUNT).ToString(), Tr_timestamp, SenderIFSC, SenderAccount, SenderCustName, BenefIFSC, BenefAccount, BenefCustName, SenderRecInfo, Status, FileName, AcknFLg, DateTime.Now.ToString(), path, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);
                            InsertCount++;


                        }




                    }
                    catch (Exception ex)
                    {
                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                        objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    }
                }
            }
            catch (Exception ex)
            {
                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
            }



            return _DataTable;

        }

        public DataTable GLAgentLedgerFiles(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;


            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());

            int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());

            if (ModeID == 0)
            {
                ModeID = 2;
            }
            else
            {

            }

            DataSet ds = new DataSet();
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(Int32));
            _DataTable.Columns.Add("ChannelID", typeof(Int32));
            _DataTable.Columns.Add("ModeID", typeof(Int32));
            _DataTable.Columns.Add("Channel", typeof(string));
            _DataTable.Columns.Add("AgentID", typeof(string));
            _DataTable.Columns.Add("AgentName", typeof(string));
            _DataTable.Columns.Add("TxnType", typeof(string));
            _DataTable.Columns.Add("RRN", typeof(string));
            _DataTable.Columns.Add("SourceTxnID", typeof(string));
            _DataTable.Columns.Add("MasterRefNo", typeof(string));
            _DataTable.Columns.Add("PartnerReferenceNumber", typeof(string));
            _DataTable.Columns.Add("ChannelPartnerRefNo", typeof(string));
            _DataTable.Columns.Add("UTR", typeof(string));
            _DataTable.Columns.Add("TxnDate", typeof(DateTime));
            _DataTable.Columns.Add("TxnTime", typeof(string));
            _DataTable.Columns.Add("TxnDateTime", typeof(string));
            _DataTable.Columns.Add("SettledDate", typeof(DateTime));
            _DataTable.Columns.Add("SettledTime", typeof(string));
            _DataTable.Columns.Add("RequestDate", typeof(DateTime));
            _DataTable.Columns.Add("RequestTime", typeof(string));
            _DataTable.Columns.Add("Status", typeof(string));
            _DataTable.Columns.Add("TxnFlag", typeof(string));
            _DataTable.Columns.Add("OpeningBalance", typeof(decimal));
            _DataTable.Columns.Add("TxnAmount", typeof(decimal));
            _DataTable.Columns.Add("ServiceChargesCCF", typeof(decimal));
            _DataTable.Columns.Add("BaseAmount", typeof(decimal));
            _DataTable.Columns.Add("GST", typeof(decimal));
            _DataTable.Columns.Add("GrosAmount", typeof(decimal));
            _DataTable.Columns.Add("ClosingBalance", typeof(decimal));
            _DataTable.Columns.Add("Narration", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("FranchiseID", typeof(string));
            _DataTable.Columns.Add("FranchiseName", typeof(string));
            _DataTable.Columns.Add("TermID", typeof(string));
            _DataTable.Columns.Add("BankName", typeof(string));
            _DataTable.Columns.Add("NPCIReferenceNumber", typeof(string));
            _DataTable.Columns.Add("ApproverRemarks", typeof(string));
            _DataTable.Columns.Add("BCAccountNumber", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifyOn", typeof(string));
            _DataTable.Columns.Add("ModifyBy", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));


            try
            {
                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = "Provider = Microsoft.ACE.OLEDB.12.0;" +
                   "Data Source = " + path + "; Extended Properties=Excel 8.0;";
                string extension = Path.GetExtension(path);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03                     
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + " ; Extended Properties =\"Excel 8.0;HDR=Yes;IMEX=1\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = " + path + "; Extended Properties =\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        break;
                }

                try
                {
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }
                catch
                {
                    switch (extension.ToLower())
                    {
                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                int j = 0;

                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    excelSheets[j] = row["TABLE_NAME"].ToString();
                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                    OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataTable dtSheet = new DataTable();
                    da.Fill(dtSheet);
                    objConn.Close();
                    TotalCount = dtSheet.Rows.Count;
                    if (dtSheet.Rows.Count > 1)
                    {
                        for (int k = 1; k < dtSheet.Rows.Count; k++)
                        {

                            string Channel = string.Empty;
                            string AgentID = string.Empty;
                            string AgentName = string.Empty;
                            string TxnType = string.Empty;
                            string RRN = string.Empty;
                            string SourceTxnID = string.Empty;
                            string MasterRefNo = string.Empty;
                            string PartnerReferenceNumber = string.Empty;
                            string ChannelPartnerRefNo = string.Empty;
                            string UTR = string.Empty;
                            DateTime? TxnDate = null;
                            string TxnTime = string.Empty;
                            DateTime? TxnDateTime = null;
                            DateTime? SettledDate = null;
                            string SettledTime = string.Empty;
                            DateTime? RequestDate = null;
                            string RequestTime = string.Empty;
                            string Status = string.Empty;
                            string TxnFlag = string.Empty;
                            decimal? OpeningBalance = 0;
                            decimal? TxnAmount = 0;
                            decimal? ServiceChargesCCF = 0;
                            decimal? BaseAmount = 0;
                            decimal? GST = 0;
                            decimal? GrosAmount = 0;
                            decimal? ClosingBalance = 0;
                            string Narration = string.Empty;
                            string Remarks = string.Empty;
                            string TerminalId = string.Empty;
                            string FranchiseID = string.Empty;
                            string FranchiseName = string.Empty;
                            string TermID = string.Empty;
                            string BankName = string.Empty;
                            string NPCIReferenceNumber = string.Empty;
                            string ApproverRemarks = string.Empty;
                            string BCAccountNumber = string.Empty;
                            string CreatedBy = string.Empty;
                            string ModifyBy = string.Empty;
                            string FilePath = string.Empty;

                            try
                            {

                                if (dtSheet.Rows[k][1].ToString().Contains("DMT"))
                                {
                                    Channel = "IMPS";
                                }
                                else
                                {
                                    Channel = string.IsNullOrEmpty(dtSheet.Rows[k][1].ToString()) || Convert.ToString(dtSheet.Rows[k][1]).Equals("NULL") ? null : dtSheet.Rows[k][1].ToString();
                                }

                                AgentID = string.IsNullOrEmpty(dtSheet.Rows[k][2].ToString()) || Convert.ToString(dtSheet.Rows[k][2]).Equals("NULL") ? null : dtSheet.Rows[k][2].ToString();
                                AgentName = string.IsNullOrEmpty(dtSheet.Rows[k][3].ToString()) || Convert.ToString(dtSheet.Rows[k][3]).Equals("NULL") ? null : dtSheet.Rows[k][3].ToString();
                                TxnType = string.IsNullOrEmpty(dtSheet.Rows[k][4].ToString()) || Convert.ToString(dtSheet.Rows[k][4]).Equals("NULL") ? null : dtSheet.Rows[k][4].ToString();
                                RRN = string.IsNullOrEmpty(dtSheet.Rows[k][5].ToString()) || Convert.ToString(dtSheet.Rows[k][5]).Equals("NULL") ? null : dtSheet.Rows[k][5].ToString();
                                SourceTxnID = string.IsNullOrEmpty(dtSheet.Rows[k][6].ToString()) || Convert.ToString(dtSheet.Rows[k][6]).Equals("NULL") ? null : dtSheet.Rows[k][6].ToString();
                                MasterRefNo = string.IsNullOrEmpty(dtSheet.Rows[k][7].ToString()) || Convert.ToString(dtSheet.Rows[k][7]).Equals("NULL") ? null : dtSheet.Rows[k][7].ToString();
                                PartnerReferenceNumber = string.IsNullOrEmpty(dtSheet.Rows[k][8].ToString()) || Convert.ToString(dtSheet.Rows[k][8]).Equals("NULL") ? null : dtSheet.Rows[k][8].ToString();
                                ChannelPartnerRefNo = string.IsNullOrEmpty(dtSheet.Rows[k][9].ToString()) || Convert.ToString(dtSheet.Rows[k][9]).Equals("NULL") ? null : dtSheet.Rows[k][9].ToString();
                                UTR = string.IsNullOrEmpty(dtSheet.Rows[k][10].ToString()) || Convert.ToString(dtSheet.Rows[k][10]).Equals("NULL") ? null : dtSheet.Rows[k][10].ToString();

                                TxnDate = DateTime.ParseExact(dtSheet.Rows[k][11].ToString().Trim(), new[] { "dd/MM/yyyy", "dd-MM-yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);

                                objCommon.InsertLogs("TxnDate conversion" + TxnDate, ClientCode, "SplitterBankIssuerNEFTRTGSSpreadsheet.cs", "GLAgentLedgerFiles", LineNo, FileName, UserName, 'E');
                                TxnTime = string.IsNullOrEmpty(dtSheet.Rows[k][12].ToString()) || Convert.ToString(dtSheet.Rows[k][12]).Equals("NULL") ? null : dtSheet.Rows[k][12].ToString();

                                objCommon.InsertLogs("TxnDate conversion" + TxnDate, ClientCode, "SplitterBankIssuerNEFTRTGSSpreadsheet.cs", "GLAgentLedgerFiles", LineNo, FileName, UserName, 'E');
                                string Date = dtSheet.Rows[k][11].ToString().Trim();

                                objCommon.InsertLogs("Date " + Date, ClientCode, "SplitterBankIssuerNEFTRTGSSpreadsheet.cs", "GLAgentLedgerFiles", LineNo, FileName, UserName, 'E');
                                string TxnDatetimes = Date + " " + TxnTime;



                                TxnDateTime = DateTime.ParseExact(TxnDatetimes.ToString(), new[] { "MM-dd-yyyy HH:mm:ss", "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy h:mm:ss", "MM-dd-yyyy H:mm:ss", "MM/dd/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);

                                objCommon.InsertLogs("TxnDateTime conversion" + TxnDateTime, ClientCode, "SplitterBankIssuerNEFTRTGSSpreadsheet.cs", "GLAgentLedgerFiles", LineNo, FileName, UserName, 'E');
                                if (dtSheet.Rows[k][13].ToString().Replace("'", "").Trim() != "")
                                {
                                    SettledDate = DateTime.ParseExact(dtSheet.Rows[k][13].ToString(), new[] { "dd-MM-yyyy", "dd/MM/yyyy", "dd/MM/yyyy hh:mm:ss tt", "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);

                                    objCommon.InsertLogs("SettledDate conversion" + SettledDate, ClientCode, "SplitterBankIssuerNEFTRTGSSpreadsheet.cs", "GLAgentLedgerFiles", LineNo, FileName, UserName, 'E');

                                }
                                else
                                {
                                    SettledDate = null;

                                    objCommon.InsertLogs("SettledDate" + SettledDate, ClientCode, "SplitterBankIssuerNEFTRTGSSpreadsheet.cs", "GLAgentLedgerFiles", LineNo, FileName, UserName, 'E');
                                }
                                SettledTime = string.IsNullOrEmpty(dtSheet.Rows[k][14].ToString()) || Convert.ToString(dtSheet.Rows[k][14]).Equals("NULL") ? null : dtSheet.Rows[k][14].ToString();

                                if (dtSheet.Rows[k][15].ToString().Replace("NULL", "").Trim() != "")
                                {
                                    RequestDate = DateTime.ParseExact(dtSheet.Rows[k][15].ToString(), new[] { "MM/dd/yyyy hh:mm:ss tt", "MM-dd-yyyy hh:mm:ss tt", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt", "dd/MM/yyyy hh:mm:ss", "dd-MM-yyyy HHmmss", "dd-MM-yyyy HHmm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);

                                    objCommon.InsertLogs("RequestDate Conversion" + RequestDate, ClientCode, "SplitterBankIssuerNEFTRTGSSpreadsheet.cs", "GLAgentLedgerFiles", LineNo, FileName, UserName, 'E');
                                }
                                else
                                {
                                    RequestDate = null;

                                    objCommon.InsertLogs("RequestDate" + RequestDate, ClientCode, "SplitterBankIssuerNEFTRTGSSpreadsheet.cs", "GLAgentLedgerFiles", LineNo, FileName, UserName, 'E');
                                }

                                RequestTime = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][16])) || Convert.ToString(dtSheet.Rows[k][16]).Equals("NULL") ? null : Convert.ToString(dtSheet.Rows[k][16].ToString());


                                objCommon.InsertLogs("RequestDate" + RequestDate, ClientCode, "SplitterBankIssuerNEFTRTGSSpreadsheet.cs", "GLAgentLedgerFiles", LineNo, FileName, UserName, 'E');


                                Status = dtSheet.Rows[k][17].ToString().Trim();
                                TxnFlag = dtSheet.Rows[k][18].ToString().Trim();
                                OpeningBalance = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][19])) || Convert.ToString(dtSheet.Rows[k][19]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][19]));
                                TxnAmount = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][20])) || Convert.ToString(dtSheet.Rows[k][20]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][20]));
                                ServiceChargesCCF = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][21])) || Convert.ToString(dtSheet.Rows[k][21]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][21]));
                                BaseAmount = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][22])) || Convert.ToString(dtSheet.Rows[k][22]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][22]));
                                GST = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][23])) || Convert.ToString(dtSheet.Rows[k][23]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][23]));
                                GrosAmount = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][24])) || Convert.ToString(dtSheet.Rows[k][24]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][24]));
                                ClosingBalance = string.IsNullOrEmpty(Convert.ToString(dtSheet.Rows[k][25])) || Convert.ToString(dtSheet.Rows[k][25]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(dtSheet.Rows[k][25]));
                                Narration = dtSheet.Rows[k][26].ToString().Trim();
                                Remarks = dtSheet.Rows[k][27].ToString().Trim();
                                TerminalId = dtSheet.Rows[k][28].ToString().Trim();
                                FranchiseID = dtSheet.Rows[k][29].ToString().Trim();
                                FranchiseName = dtSheet.Rows[k][30].ToString().Trim();
                                TermID = dtSheet.Rows[k][31].ToString().Trim();
                                BankName = dtSheet.Rows[k][32].ToString().Trim();
                                NPCIReferenceNumber = dtSheet.Rows[k][33].ToString().Trim();
                                ApproverRemarks = dtSheet.Rows[k][34].ToString().Trim();
                                BCAccountNumber = dtSheet.Rows[k][35].ToString().Trim();
                                RequestTime = dtSheet.Rows[k][36].ToString().Trim();

                                if (Channel == "Wallet-Wallet")
                                {
                                    ChannelID = 7;

                                }
                                else if (Channel == "MATM")
                                {
                                    ChannelID = 5;

                                }
                                else if (Channel == "IMPS")
                                {
                                    ChannelID = 4;


                                }
                                else if (Channel == "AEPS")
                                {
                                    ChannelID = 12;

                                }
                                else if (Channel == "BBPS")
                                {
                                    ChannelID = 13;

                                }
                                else if (Channel == "Wallet-Account")
                                {
                                    ChannelID = 9;

                                }
                                else if (Channel == "REFIL")
                                {
                                    ChannelID = 6;
                                }
                            }

                            catch (Exception ex)
                            {

                            }
                            LineNo++;

                            _DataTable.Rows.Add(
                                                   ClientID,
                                                   ChannelID,
                                                   ModeID,
                                                   Channel,
                                                   AgentID,
                                                   AgentName,
                                                   TxnType,
                                                   RRN,
                                                   SourceTxnID,
                                                   MasterRefNo,
                                                   PartnerReferenceNumber,
                                                   ChannelPartnerRefNo,
                                                   UTR,
                                                   TxnDate,
                                                   TxnTime,
                                                   TxnDateTime,
                                                   SettledDate,
                                                   SettledTime,
                                                   RequestDate,
                                                   RequestTime,
                                                   Status,
                                                   TxnFlag,
                                                   OpeningBalance,
                                                   TxnAmount,
                                                   ServiceChargesCCF,
                                                   BaseAmount,
                                                   GST,
                                                   GrosAmount,
                                                   ClosingBalance,
                                                   Narration,
                                                   Remarks,
                                                   TerminalId,
                                                   FranchiseID,
                                                   FranchiseName,
                                                   TermID,
                                                   BankName,
                                                   NPCIReferenceNumber,
                                                   ApproverRemarks,
                                                   BCAccountNumber,
                                                   System.DateTime.Now,
                                                   UserName,
                                                   null,
                                                   "",
                                                   FileName,
                                                   path
                                               );

                            InsertCount++;

                        }
                    }
                    j++;
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterBankIssuerNEFTRTGSSpreadsheet.cs", "GLAgentLedgerFiles", LineNo, FileName, UserName, 'E');

            }
            return _DataTable;
        }
    }
}
