﻿ 
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using Utility;

namespace ASPTraceWebApi
{
    public class SplitterNEFTRTGSwithseparaterINWARD
    {
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;

        public SplitterNEFTRTGSwithseparaterINWARD(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        public string GetUniqueID()
        {
            Random rnd = new Random();
            int value = rnd.Next(1000, 9999);
            string UniqueID = DateTime.Now.ToString("ddMMyyyyHHmmssfff") + value.ToString();
            return UniqueID;

        }

        public DataTable SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TranRefNum", typeof(string));
            _DataTable.Columns.Add("UTRNo", typeof(string));
            _DataTable.Columns.Add("BANKCODE", typeof(string));
            _DataTable.Columns.Add("AMOUNT", typeof(double));
            _DataTable.Columns.Add("Tr_timestamp", typeof(DateTime));
            _DataTable.Columns.Add("SenderIFSC", typeof(string));
            _DataTable.Columns.Add("SenderAccount", typeof(string));
            _DataTable.Columns.Add("SenderCustName", typeof(string));
            _DataTable.Columns.Add("BenefIFSC", typeof(string));
            _DataTable.Columns.Add("BenefAccount", typeof(string));
            _DataTable.Columns.Add("BenefCustName", typeof(string));
            _DataTable.Columns.Add("SenderRecInfo", typeof(string));
            _DataTable.Columns.Add("Status", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("AcknFLg", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;
            
            string relativePath = _configuration["AppSettings:MekKey2Path"];

            
            

            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());
            int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());
            InsertCount = 0;
            TotalCount = 0;
            DataTable dtexcelsheetname = null;
            string Status = string.Empty;
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;
            try
            {
                foreach (string line in File.ReadAllLines(path))
                {
                    LineNo++;
                    try
                    {

                        string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                        string[] colFields = line1.Split('|');



                        string SEQNO = string.Empty;
                        string TranRefNum = string.Empty;
                        string UTRNo = string.Empty;
                        string AMOUNT = "0";
                        string Txndate = string.Empty;
                        string Tr_timestamp = string.Empty;
                        string SenderIFSC = string.Empty;
                        string SenderAccount = string.Empty;
                        string SenderCustName = string.Empty;
                        string BenefIFSC = string.Empty;
                        string BenefAccount = string.Empty;
                        string BenefCustName = string.Empty;
                        string SenderRecInfo = string.Empty;

                        string BATCHID = string.Empty;
                        string AcknFLg = string.Empty;
                        string DRCR = string.Empty;
                        string Bankcode = string.Empty;



                        //if (FileName.Contains("INWARD"))
                        //{

                        if (colFields[0].Contains("NEFT"))
                        {
                            Status = "NEFT";
                        }
                        else if (colFields[0].Contains("RTGS"))
                        {
                            Status = "RTGS";
                        }

                        BATCHID = colFields[1].ToString().Trim();
                        string[] TerminalSplit = BATCHID.Split('-');

                        TranRefNum = colFields[7].ToString().Trim();
                        UTRNo = "";
                        Bankcode = "";
                        AMOUNT = colFields[5].Trim().ToString();

                        Txndate = (colFields[1].ToString().Trim());
                        //string timestamp = Txndate.Substring(0, 2).ToString() + "-" + Txndate.Substring(3, 2).ToString() + "-" + Txndate.Substring(6, 4).ToString() + " " + Txndate.Substring(11, 2).ToString() + ":" + Txndate.Substring(14, 2).ToString() + ":" + Txndate.Substring(17, 2).ToString();
                        Tr_timestamp = DateTime.ParseExact(Txndate, "dd-MM-yyyy", null).ToString("yyyy-MM-dd");
                        SenderIFSC = colFields[4].ToString().Trim();
                        SenderAccount = colFields[3].ToString().Trim();
                        SenderCustName = "";
                        BenefIFSC = "";
                        BenefAccount = colFields[2].ToString().Trim();
                        BenefCustName = "";
                        SenderRecInfo = "";
                        FileName = path;



                        SEQNO = (colFields[6].ToString().Trim());
                        if (SEQNO == "C")
                        {
                            AcknFLg = "INWARD";
                        }
                        else
                        {
                            AcknFLg = "OUTWARD";

                        }

                        LineNo++;
                        _DataTable.Rows.Add(ClientID, ChannelID, ModeID, TranRefNum, UTRNo, Bankcode, Convert.ToDouble(AMOUNT).ToString(), Tr_timestamp, SenderIFSC, SenderAccount, SenderCustName, BenefIFSC, BenefAccount, BenefCustName, SenderRecInfo, Status, FileName, AcknFLg, DateTime.Now.ToString(), path, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);
                        InsertCount++;


                        //BATCHID = colFields[1].ToString().Trim();
                        //string[] TerminalSplit = BATCHID.Split('|');

                        //TranRefNum = TerminalSplit[4].ToString().Trim();
                        //UTRNo = "";
                        //AMOUNT = colFields[4].ToString();                            

                        //Txndate = (colFields[0].ToString().Trim());                          
                        //string timestamp = Txndate.Substring(0, 2).ToString() + "-" + Txndate.Substring(3, 2).ToString() + "-" + Txndate.Substring(6, 4).ToString() + " " + Txndate.Substring(11, 2).ToString() + ":" + Txndate.Substring(14, 2).ToString() + ":" + Txndate.Substring(17, 2).ToString();
                        //Tr_timestamp = DateTime.ParseExact(timestamp, "dd-MM-yyyy HH:mm:ss", null).ToString("yyyy-MM-dd HH:mm:ss");
                        //SenderIFSC = TerminalSplit[1].ToString().Trim();
                        //SenderAccount = (colFields[2].ToString().Trim());
                        //SenderCustName = TerminalSplit[3].ToString().Trim();
                        //BenefIFSC = "";
                        //BenefAccount = "";
                        //BenefCustName = TerminalSplit[2].ToString().Trim();
                        //SenderRecInfo = (colFields[2].ToString().Trim());
                        //FileName = path;
                        //Status = TerminalSplit[0].ToString().Trim();                   


                        //SEQNO = (colFields[3].ToString().Trim());
                        //if (SEQNO == "C")
                        //{
                        //    AcknFLg = "INWARD";
                        //}
                        //else
                        //{
                        //    AcknFLg = "OUTWARD";

                        //}
                        //LineNo++;
                        //_DataTable.Rows.Add(ClientID, ChannelID, ModeID, TranRefNum, UTRNo, Convert.ToDouble(AMOUNT).ToString(), Tr_timestamp, SenderIFSC, SenderAccount, SenderCustName, BenefIFSC, BenefAccount, BenefCustName, SenderRecInfo, Status, FileName, AcknFLg, DateTime.Now.ToString(), path, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);
                        //InsertCount++;
                        //  }
                        //else
                        //{


                        //BATCHID = colFields[1].ToString().Trim();
                        //string[] TerminalSplit = BATCHID.Split('-');

                        //TranRefNum = colFields[7].ToString().Trim();
                        //UTRNo = "";
                        //AMOUNT = colFields[5].Trim().ToString();

                        //Txndate = (colFields[1].ToString().Trim());
                        ////string timestamp = Txndate.Substring(0, 2).ToString() + "-" + Txndate.Substring(3, 2).ToString() + "-" + Txndate.Substring(6, 4).ToString() + " " + Txndate.Substring(11, 2).ToString() + ":" + Txndate.Substring(14, 2).ToString() + ":" + Txndate.Substring(17, 2).ToString();
                        //Tr_timestamp = DateTime.ParseExact(Txndate, "dd-MM-yyyy HH:mm:ss", null).ToString("yyyy-MM-dd HH:mm:ss");
                        //SenderIFSC = colFields[4].ToString().Trim();
                        //SenderAccount = colFields[3].ToString().Trim();
                        //SenderCustName = "";
                        //BenefIFSC = "";
                        //BenefAccount = colFields[2].ToString().Trim();
                        //BenefCustName = "";
                        //SenderRecInfo = "";
                        //FileName = path;
                        //Status = TerminalSplit[0].ToString().Trim();


                        //SEQNO = (colFields[3].ToString().Trim());
                        //if (SEQNO == "C")
                        //{
                        //    AcknFLg = "INWARD";
                        //}
                        //else
                        //{
                        //    AcknFLg = "OUTWARD";

                        //}

                        //LineNo++;
                        //_DataTable.Rows.Add(ClientID, ChannelID, ModeID, TranRefNum, UTRNo, Convert.ToDouble(AMOUNT).ToString(), Tr_timestamp, SenderIFSC, SenderAccount, SenderCustName, BenefIFSC, BenefAccount, BenefCustName, SenderRecInfo, Status, FileName, AcknFLg, DateTime.Now.ToString(), path, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);
                        //InsertCount++;


                        // }




                    }
                    catch (Exception ex)
                    {
                       // objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                        objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    }
                }
            }
            catch (Exception ex)
            {
                // objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
            }



            return _DataTable;

        }
    }
}
