﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using Utility;

namespace ASPTraceWebApi
{
    public class SplitterVISAIssuer
    {
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public SplitterVISAIssuer(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        public string GetUniqueID()
        {
            Random rnd = new Random();
            int value = rnd.Next(1000, 9999);
            string UniqueID = DateTime.Now.ToString("ddMMyyyyHHmmssfff") + value.ToString();
            return UniqueID;

        }

        public DataSet SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {

            DataSet _DataSet = new DataSet();
            int month = 0;
            int fyear = 0;
            string FileNameSplit = string.Empty;
            string FileDateString = string.Empty;
            int FDate = 0;
            int Fday = 0;
            int FFyear = 0;
            var FileDate = new DateTime();

            if (FileName.Substring(0, 3) == "CTF")
            {

                FileNameSplit = FileName.Substring(8, 5);
                FDate = Convert.ToInt32(FileNameSplit);
                Fday = FDate % 1000;
                if (Fday == 366)
                {
                    Fday = Fday - 1;
                }
                FFyear = int.Parse("20" + FileNameSplit.Substring(0, 2));
                var Fdate = new DateTime(FFyear, 1, 1);
                FileDate = Fdate.AddDays(Fday - 1);
                FileDateString = FileDate.ToString();
                month = FileDate.Month;//month = int.Parse(FileDateString.Substring(5, 2));
                fyear = FFyear;

            }
            else
            {

                if (FileName.Length > 14)
                {
                    InsertCount = 0;
                    TotalCount = 0;
                    return _DataSet;
                }

                month = int.Parse(FileName.Substring(3, 2));
                fyear = int.Parse(FileName.Substring(6, 4));


                string FileName1 = FileName.Substring(0, 2) + "/" + FileName.Substring(3, 2) + "/" + FileName.Substring(6, 4) + " 00:00:00";
                FileDate = DateTime.ParseExact(FileName1, "dd/MM/yyyy HH:mm:ss", null);

            }

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            
            string relativePath = _configuration["AppSettings:MekKey2Path"];

            
            

            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            DataSet ds = new DataSet();

            DataTable _DataTable0 = new DataTable();
            _DataTable0.Columns.Add("UniqueID", typeof(string));
            _DataTable0.Columns.Add("TxnsCode", typeof(string));
            _DataTable0.Columns.Add("TxnsCodeQ", typeof(string));
            _DataTable0.Columns.Add("TxnsCSN", typeof(string));
            _DataTable0.Columns.Add("AccountNumber", typeof(string));
            _DataTable0.Columns.Add("AccountNumberExt", typeof(string));
            _DataTable0.Columns.Add("FloorLimit", typeof(string));
            _DataTable0.Columns.Add("ExceptionFile", typeof(string));
            _DataTable0.Columns.Add("PCAS", typeof(string));
            _DataTable0.Columns.Add("AcqReferenceNumber", typeof(string));
            _DataTable0.Columns.Add("AcqBusinessID", typeof(string));
            _DataTable0.Columns.Add("PurchaseDate", typeof(DateTime));
            _DataTable0.Columns.Add("DestAmount", typeof(decimal));
            _DataTable0.Columns.Add("DestCCY", typeof(string));
            _DataTable0.Columns.Add("SrcAmount", typeof(decimal));
            _DataTable0.Columns.Add("SrcCCY", typeof(string));
            _DataTable0.Columns.Add("MarchantName", typeof(string));
            _DataTable0.Columns.Add("MarchantCity", typeof(string));
            _DataTable0.Columns.Add("MarchantCountryCode", typeof(string));
            _DataTable0.Columns.Add("MarchantCateCode", typeof(string));
            _DataTable0.Columns.Add("MarchantZIPCode", typeof(string));
            _DataTable0.Columns.Add("MarchantSPCode", typeof(string));
            _DataTable0.Columns.Add("ReqPaymentService", typeof(string));
            _DataTable0.Columns.Add("NoOfPaymentForm", typeof(string));
            _DataTable0.Columns.Add("UsageCode", typeof(string));
            _DataTable0.Columns.Add("ReasonCode", typeof(string));
            _DataTable0.Columns.Add("SettlementFlag", typeof(string));
            _DataTable0.Columns.Add("AuthCharIndicator", typeof(string));
            _DataTable0.Columns.Add("AuthCode", typeof(string));
            _DataTable0.Columns.Add("POSTerminalCapability", typeof(string));
            _DataTable0.Columns.Add("Reserved1", typeof(string));
            _DataTable0.Columns.Add("CardHolderID", typeof(string));
            _DataTable0.Columns.Add("CollectionOnlyFlag", typeof(string));
            _DataTable0.Columns.Add("POSEntryMode", typeof(string));
            _DataTable0.Columns.Add("CentralProcessDate", typeof(DateTime));
            _DataTable0.Columns.Add("ReimbursementAttribute", typeof(string));
            _DataTable0.Columns.Add("ReserveField1", typeof(string));
            _DataTable0.Columns.Add("ReserveField2", typeof(string));
            _DataTable0.Columns.Add("ReserveField3", typeof(string));
            _DataTable0.Columns.Add("ReserveField4", typeof(string));
            _DataTable0.Columns.Add("ReserveField5", typeof(string));
            _DataTable0.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable0.Columns.Add("NoOfDuplicate", typeof(string));
            _DataTable0.Columns.Add("FileName", typeof(string));
            _DataTable0.Columns.Add("FilePath", typeof(string));
            _DataTable0.Columns.Add("FileDate", typeof(DateTime));
            _DataTable0.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable0.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable0.Columns.Add("CreatedBy", typeof(string));
            _DataTable0.Columns.Add("ModifiedBy", typeof(string));

            DataTable _DataTable1 = new DataTable();
            _DataTable1.Columns.Add("UniqueID", typeof(string));
            _DataTable1.Columns.Add("BusinessFC", typeof(string));
            _DataTable1.Columns.Add("TokanAssuranceLevel", typeof(string));
            _DataTable1.Columns.Add("Reserved2", typeof(string));
            _DataTable1.Columns.Add("ChargebackRefNo", typeof(string));
            _DataTable1.Columns.Add("DocIndicator", typeof(string));
            _DataTable1.Columns.Add("MemMsgText", typeof(string));
            _DataTable1.Columns.Add("SpecialCondition", typeof(string));
            _DataTable1.Columns.Add("FeeProgram", typeof(string));
            _DataTable1.Columns.Add("IssuerCharge", typeof(string));
            _DataTable1.Columns.Add("Reserved3", typeof(string));
            _DataTable1.Columns.Add("CardAcceptorID", typeof(string));
            _DataTable1.Columns.Add("TerminalID", typeof(string));
            _DataTable1.Columns.Add("NationalRBFee", typeof(string));
            _DataTable1.Columns.Add("MPECIndicator", typeof(string));
            _DataTable1.Columns.Add("SpecialChargeback", typeof(string));
            _DataTable1.Columns.Add("IntTraceNumber", typeof(string));
            _DataTable1.Columns.Add("AcceptTerminal", typeof(string));
            _DataTable1.Columns.Add("PrepaidCard", typeof(string));
            _DataTable1.Columns.Add("ServiceDevlopmentField", typeof(string));
            _DataTable1.Columns.Add("AVSResponseCode", typeof(string));
            _DataTable1.Columns.Add("AuthSourceCode", typeof(string));
            _DataTable1.Columns.Add("PurchaseIdenFormat", typeof(string));
            _DataTable1.Columns.Add("AccountSelection", typeof(string));
            _DataTable1.Columns.Add("InstallmentPayCount", typeof(string));
            _DataTable1.Columns.Add("PurchaseIdentifier", typeof(string));
            _DataTable1.Columns.Add("CashBack", typeof(string));
            _DataTable1.Columns.Add("ChipConCode", typeof(string));
            _DataTable1.Columns.Add("POSEnviroment", typeof(string));
            _DataTable1.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable1.Columns.Add("NoOfDuplicate", typeof(string));

            DataTable _DataTable3 = new DataTable();
            _DataTable3.Columns.Add("UniqueID", typeof(string));
            _DataTable3.Columns.Add("Reserved5", typeof(string));
            _DataTable3.Columns.Add("BusinessFCLG", typeof(string));
            _DataTable3.Columns.Add("Reserved6", typeof(string));
            _DataTable3.Columns.Add("LodgingNo", typeof(string));
            _DataTable3.Columns.Add("LodExtraCharge", typeof(string));
            _DataTable3.Columns.Add("Reserved7", typeof(string));
            _DataTable3.Columns.Add("LodgingDate", typeof(string));
            _DataTable3.Columns.Add("DailyRoomRate", typeof(string));
            _DataTable3.Columns.Add("TotalTax", typeof(string));
            _DataTable3.Columns.Add("PrepaidExpns", typeof(string));
            _DataTable3.Columns.Add("FoodCharges", typeof(string));
            _DataTable3.Columns.Add("FolioCashAdv", typeof(string));
            _DataTable3.Columns.Add("RoomNight", typeof(string));
            _DataTable3.Columns.Add("TotalRoomTax", typeof(string));
            _DataTable3.Columns.Add("Reserved8", typeof(string));
            _DataTable3.Columns.Add("Reserved9", typeof(string));
            _DataTable3.Columns.Add("FastFundsIn", typeof(string));
            _DataTable3.Columns.Add("BusinessFCCR", typeof(string));
            _DataTable3.Columns.Add("BusinessAppID", typeof(string));
            _DataTable3.Columns.Add("SourceOfFunds", typeof(string));
            _DataTable3.Columns.Add("PaymentRevRC", typeof(string));
            _DataTable3.Columns.Add("SenderRefNo", typeof(string));
            _DataTable3.Columns.Add("SenderAcNo", typeof(string));
            _DataTable3.Columns.Add("SenderName", typeof(string));
            _DataTable3.Columns.Add("SenderAdd", typeof(string));
            _DataTable3.Columns.Add("SenderCity", typeof(string));
            _DataTable3.Columns.Add("SenderState", typeof(string));
            _DataTable3.Columns.Add("SenderCountry", typeof(string));
            _DataTable3.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable3.Columns.Add("NoOfDuplicate", typeof(string));


            DataTable _DataTable4 = new DataTable();
            _DataTable4.Columns.Add("UniqueID", typeof(string));
            _DataTable4.Columns.Add("AUniqueID", typeof(string));
            _DataTable4.Columns.Add("Reserved10", typeof(string));
            _DataTable4.Columns.Add("BusinessFC4", typeof(string));
            _DataTable4.Columns.Add("NetIdCode", typeof(string));
            _DataTable4.Columns.Add("ConforInfo", typeof(string));
            _DataTable4.Columns.Add("AdjProceIn", typeof(string));
            _DataTable4.Columns.Add("MsgReasonCode", typeof(string));
            _DataTable4.Columns.Add("SurchargeAmnt", typeof(string));
            _DataTable4.Columns.Add("SurCrDr", typeof(string));
            _DataTable4.Columns.Add("VisaIUO", typeof(string));
            _DataTable4.Columns.Add("Reserved11", typeof(string));
            _DataTable4.Columns.Add("SurAmntBillCCY", typeof(string));
            _DataTable4.Columns.Add("MoneyTrfExchFee", typeof(string));
            _DataTable4.Columns.Add("Reserved12", typeof(string));
            _DataTable4.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable4.Columns.Add("NoOfDuplicate", typeof(string));



            DataTable _DataTable5 = new DataTable();
            _DataTable5.Columns.Add("UniqueID", typeof(string));
            _DataTable5.Columns.Add("TxnsIdentifier", typeof(string));
            _DataTable5.Columns.Add("AuthAmount", typeof(decimal));
            _DataTable5.Columns.Add("AuthCCY", typeof(string));
            _DataTable5.Columns.Add("AuthResponseCode", typeof(string));
            _DataTable5.Columns.Add("ValidationCode", typeof(string));
            _DataTable5.Columns.Add("ExcludedTxnsIdenReason", typeof(string));
            _DataTable5.Columns.Add("CRSProcessCode", typeof(string));
            _DataTable5.Columns.Add("ChargeRight", typeof(string));
            _DataTable5.Columns.Add("MultiClearingSN", typeof(string));
            _DataTable5.Columns.Add("MultiClearingSC", typeof(string));
            _DataTable5.Columns.Add("MarketSADI", typeof(string));
            _DataTable5.Columns.Add("TotalAuthAmount", typeof(decimal));
            _DataTable5.Columns.Add("InformationIndicator", typeof(string));
            _DataTable5.Columns.Add("MarchantTelephoneNumber", typeof(string));
            _DataTable5.Columns.Add("AdditionalData", typeof(string));
            _DataTable5.Columns.Add("MerchantVolume", typeof(string));
            _DataTable5.Columns.Add("ElectronicsCGI", typeof(string));
            _DataTable5.Columns.Add("MerchantVerValue", typeof(string));
            _DataTable5.Columns.Add("InterchangeFeeAmount", typeof(decimal));
            _DataTable5.Columns.Add("InterchangeFeeSign", typeof(string));
            _DataTable5.Columns.Add("SCBCCYExchangeRate", typeof(decimal));
            _DataTable5.Columns.Add("BCDCCYExhangeRate", typeof(decimal));
            _DataTable5.Columns.Add("ISAAmount", typeof(decimal));
            _DataTable5.Columns.Add("ProductID", typeof(string));
            _DataTable5.Columns.Add("ProgramID", typeof(string));
            _DataTable5.Columns.Add("DCCIndicator", typeof(string));
            _DataTable5.Columns.Add("AccountTypeIdentification", typeof(string));
            _DataTable5.Columns.Add("SpendQIndicator", typeof(string));
            _DataTable5.Columns.Add("PanToken", typeof(string));
            _DataTable5.Columns.Add("Reserved4", typeof(string));
            _DataTable5.Columns.Add("CVV2ResultCode", typeof(string));
            _DataTable5.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable5.Columns.Add("NoOfDuplicate", typeof(string));


            DataTable _DataTable6 = new DataTable();
            _DataTable6.Columns.Add("UniqueID", typeof(string));
            _DataTable6.Columns.Add("LocalTax", typeof(string));
            _DataTable6.Columns.Add("LocalTaxIn", typeof(string));
            _DataTable6.Columns.Add("NtlTax", typeof(string));
            _DataTable6.Columns.Add("NtlTaxIn", typeof(string));
            _DataTable6.Columns.Add("BusinessRefNo", typeof(string));
            _DataTable6.Columns.Add("CustVATRegNo", typeof(string));
            _DataTable6.Columns.Add("Reserved13", typeof(string));
            _DataTable6.Columns.Add("SummaryCommCode", typeof(string));
            _DataTable6.Columns.Add("OtherTax", typeof(string));
            _DataTable6.Columns.Add("MsgID", typeof(string));
            _DataTable6.Columns.Add("TimeOfPurchase", typeof(string));
            _DataTable6.Columns.Add("CustCode", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode1", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode2", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode3", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode4", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode5", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode6", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode7", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode8", typeof(string));
            _DataTable6.Columns.Add("MerPostCode", typeof(string));
            _DataTable6.Columns.Add("Reserved14", typeof(string));
            _DataTable6.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable6.Columns.Add("NoOfDuplicate", typeof(string));

            DataTable _DataTable7 = new DataTable();
            _DataTable7.Columns.Add("UniqueID", typeof(string));
            _DataTable7.Columns.Add("TxnsType", typeof(string));
            _DataTable7.Columns.Add("CardSeqNo", typeof(string));
            _DataTable7.Columns.Add("TerminalTxnsDate", typeof(string));
            _DataTable7.Columns.Add("TerminalCapProfile", typeof(string));
            _DataTable7.Columns.Add("TerminalCountryCode", typeof(string));
            _DataTable7.Columns.Add("TerminalSerialNo", typeof(string));
            _DataTable7.Columns.Add("UnpredictableNo", typeof(string));
            _DataTable7.Columns.Add("AppTxnsCounter", typeof(string));
            _DataTable7.Columns.Add("AppIntProfile", typeof(string));
            _DataTable7.Columns.Add("Cryptogram", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData2", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData3", typeof(string));
            _DataTable7.Columns.Add("TerminalVerResult", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData47", typeof(string));
            _DataTable7.Columns.Add("CryptogramAmount", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData8", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData916", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData1", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData17", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData1832", typeof(string));
            _DataTable7.Columns.Add("FormFactInd", typeof(string));
            _DataTable7.Columns.Add("IssuerScriptResults", typeof(string));
            _DataTable7.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable7.Columns.Add("NoOfDuplicate", typeof(string));

            #region _DataTable1020
            DataTable _DataTable1020 = new DataTable();
            _DataTable1020.Columns.Add("Transaction_Code", typeof(string));
            _DataTable1020.Columns.Add("Transaction_Code_Qualifier", typeof(string));
            _DataTable1020.Columns.Add("Transaction_Component_Sequence_Number", typeof(string));
            _DataTable1020.Columns.Add("Destination_BIN", typeof(string));
            _DataTable1020.Columns.Add("Source_BIN", typeof(string));
            _DataTable1020.Columns.Add("Reason_Code", typeof(string));
            _DataTable1020.Columns.Add("Country_Code", typeof(string));
            _DataTable1020.Columns.Add("Event_Date", typeof(DateTime));
            _DataTable1020.Columns.Add("Account_Number", typeof(string));
            _DataTable1020.Columns.Add("Account_Number_Extension", typeof(string));
            _DataTable1020.Columns.Add("Destination_Amount", typeof(decimal));
            _DataTable1020.Columns.Add("Destination_Currency_Code", typeof(string));
            _DataTable1020.Columns.Add("Source_Amount", typeof(decimal));
            _DataTable1020.Columns.Add("Source_Currency_Code", typeof(string));
            _DataTable1020.Columns.Add("Message_Text", typeof(string));
            _DataTable1020.Columns.Add("Settlement_Flag", typeof(string));
            _DataTable1020.Columns.Add("Transaction_Identifier", typeof(string));
            _DataTable1020.Columns.Add("Reserved", typeof(string));
            _DataTable1020.Columns.Add("Central_Processing_Date", typeof(string));
            _DataTable1020.Columns.Add("Reimbursement_Attribute", typeof(string));
            _DataTable1020.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable1020.Columns.Add("CreatedBy", typeof(string));
            _DataTable1020.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable1020.Columns.Add("ModifiedBy", typeof(string));
            _DataTable1020.Columns.Add("VisaFileDate", typeof(DateTime));
            #endregion _DataTable1020


            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = "1";
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());


            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;


            for (int line = 0; line < TotalCount; line++)
            {
                string line1 = Regex.Replace(TotalCountArray[line].ToString(), "[^ -~]+", string.Empty);


                #region 10_20FeeCollectionData
                if (line1.Substring(0, 4).Contains("2000") || line1.Substring(0, 4).Contains("1000"))
                {

                    string year = string.Empty;
                    string Transaction_Code = string.Empty;
                    string Transaction_Code_Qualifier = string.Empty;
                    string Transaction_Component_Sequence_Number = string.Empty;
                    string Destination_BIN = string.Empty;
                    string Source_BIN = string.Empty;
                    string Reason_Code = string.Empty;
                    string Country_Code = string.Empty;
                    string Event_Date = string.Empty;
                    string Account_Number = string.Empty;
                    string Account_Number_Extension = string.Empty;
                    decimal Destination_Amount = 0;
                    string Destination_Currency_Code = string.Empty;
                    decimal Source_Amount = 0;
                    string Source_Currency_Code = string.Empty;
                    string Message_Text = string.Empty;
                    string Settlement_Flag = string.Empty;
                    string Transaction_Identifier = string.Empty;
                    string Reserved = string.Empty;
                    string Central_Processing_Date = string.Empty;
                    string Reimbursement_Attribute = string.Empty;

                    string year1 = line1.Substring(33, 1).ToString();
                    Transaction_Code = line1.Substring(0, 2);
                    Transaction_Code_Qualifier = line1.Substring(2, 1);
                    Transaction_Component_Sequence_Number = line1.Substring(3, 1);
                    Destination_BIN = line1.Substring(4, 6);
                    Source_BIN = line1.Substring(10, 6);
                    Reason_Code = line1.Substring(16, 4);
                    Country_Code = line1.Substring(20, 3);
                    Event_Date = line1.Substring(23, 4);
                    if (Convert.ToInt32(Event_Date.Substring(0, 2)) > month)
                    {
                        year1 = (fyear - 1).ToString();
                    }
                    else
                    {
                        year1 = fyear.ToString();//DateTime.Now.Year.ToString();
                    }
                    Event_Date = Event_Date.Substring(2, 2) + "/" + Event_Date.Substring(0, 2) + "/" + year1 + " 00:00:00";
                    DateTime tempDate = DateTime.ParseExact(Event_Date, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                    Account_Number = line1.Substring(27, 16);
                    Account_Number_Extension = line1.Substring(43, 3);
                    Destination_Amount = Convert.ToDecimal(line1.Substring(46, 10) + "." + line1.Substring(56, 02));
                    Destination_Currency_Code = line1.Substring(58, 3);
                    Source_Amount = Convert.ToDecimal(line1.Substring(61, 10) + "." + line1.Substring(71, 02));
                    Source_Currency_Code = line1.Substring(73, 3);
                    Message_Text = line1.Substring(76, 70);
                    Settlement_Flag = line1.Substring(146, 1);
                    Transaction_Identifier = line1.Substring(147, 15);
                    Reserved = line1.Substring(162, 1);
                    Central_Processing_Date = line1.Substring(163, 4);
                    if (Convert.ToInt32(Central_Processing_Date.Substring(0, 2)) > month)
                    {
                        year = (fyear - 1).ToString();
                    }
                    else
                    {
                        year = fyear.ToString();//DateTime.Now.Year.ToString();
                    }
                    Central_Processing_Date = Central_Processing_Date.Substring(2, 2) + "/" + Central_Processing_Date.Substring(0, 2) + "/" + year + " 00:00:00";
                    DateTime CPDate = DateTime.ParseExact(Event_Date, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                    Reimbursement_Attribute = line1.Substring(167, 1);


                    _DataTable1020.Rows.Add(Transaction_Code.Trim(), Transaction_Code_Qualifier, Transaction_Component_Sequence_Number.Trim(),
                    Destination_BIN.Trim(), Source_BIN, Reason_Code, Country_Code, tempDate, Account_Number.Trim(), Account_Number_Extension,
                    Destination_Amount, Destination_Currency_Code, Source_Amount, Source_Currency_Code, Message_Text, Settlement_Flag,
                    Transaction_Identifier.Trim(), Reserved, CPDate, Reimbursement_Attribute, System.DateTime.Now, UserName, System.DateTime.Now, UserName, FileDate);

                }
                #endregion 10_20FeeCollectionData




                if (line1.StartsWith("0500") || line1.StartsWith("0600") || line1.StartsWith("0700") || line1.StartsWith("2500") || line1.StartsWith("2600") || line1.StartsWith("2700")
                     || line1.StartsWith("1500") || line1.StartsWith("1600") || line1.StartsWith("1700") || line1.StartsWith("3500") || line1.StartsWith("3600") || line1.StartsWith("3700"))
                {
                    LineNo++;
                    try
                    {
                        string UniqueID = GetUniqueID();
                        //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                        int Incr = 1;
                        string TxnsCode = string.Empty;
                        string TxnsCodeQ = string.Empty;
                        string TxnsCSN = string.Empty;
                        string AccountNumber = string.Empty;
                        string AccountNumberExt = string.Empty;
                        string FloorLimit = string.Empty;
                        string ExceptionFile = string.Empty;
                        string PCAS = string.Empty;
                        string AcqReferenceNumber = string.Empty;
                        string AcqBusinessID = string.Empty;
                        string PurchaseDate = string.Empty;
                        string DestAmount = string.Empty;
                        string DestCCY = string.Empty;
                        string SrcAmount = string.Empty;
                        string SrcCCY = string.Empty;
                        string MarchantName = string.Empty;
                        string MarchantCity = string.Empty;
                        string MarchantCountryCode = string.Empty;
                        string MarchantCateCode = string.Empty;
                        string MarchantZIPCode = string.Empty;
                        string MarchantSPCode = string.Empty;
                        string ReqPaymentService = string.Empty;
                        string NoOfPaymentForm = string.Empty;
                        string UsageCode = string.Empty;
                        string ReasonCode = string.Empty;
                        string SettlementFlag = string.Empty;
                        string AuthCharIndicator = string.Empty;
                        string AuthCode = string.Empty;
                        string POSTerminalCapability = string.Empty;
                        string Reserved1 = string.Empty;
                        string CardHolderID = string.Empty;
                        string CollectionOnlyFlag = string.Empty;
                        string POSEntryMode = string.Empty;
                        string CentralProcessDate = string.Empty;
                        string ReimbursementAttribute = string.Empty;
                        string BusinessFC = string.Empty;
                        string TokanAssuranceLevel = string.Empty;
                        string Reserved2 = string.Empty;
                        string ChargebackRefNo = string.Empty;
                        string DocIndicator = string.Empty;
                        string MemMsgText = string.Empty;
                        string SpecialCondition = string.Empty;
                        string FeeProgram = string.Empty;
                        string IssuerCharge = string.Empty;
                        string Reserved3 = string.Empty;
                        string CardAcceptorID = string.Empty;
                        string TerminalID = string.Empty;
                        string NationalRBFee = string.Empty;
                        string MPECIndicator = string.Empty;
                        string SpecialChargeback = string.Empty;
                        string IntTraceNumber = string.Empty;
                        string AcceptTerminal = string.Empty;
                        string PrepaidCard = string.Empty;
                        string ServiceDevlopmentField = string.Empty;
                        string AVSResponseCode = string.Empty;
                        string AuthSourceCode = string.Empty;
                        string PurchaseIdenFormat = string.Empty;
                        string AccountSelection = string.Empty;
                        string InstallmentPayCount = string.Empty;
                        string PurchaseIdentifier = string.Empty;
                        string CashBack = string.Empty;
                        string ChipConCode = string.Empty;
                        string POSEnviroment = string.Empty;
                        string TxnsIdentifier = string.Empty;
                        string AuthAmount = string.Empty;
                        string AuthCCY = string.Empty;
                        string AuthResponseCode = string.Empty;
                        string ValidationCode = string.Empty;
                        string ExcludedTxnsIdenReason = string.Empty;
                        string CRSProcessCode = string.Empty;
                        string ChargeRight = string.Empty;
                        string MultiClearingSN = string.Empty;
                        string MultiClearingSC = string.Empty;
                        string MarketSADI = string.Empty;
                        string TotalAuthAmount = string.Empty;
                        string InformationIndicator = string.Empty;
                        string MarchantTelephoneNumber = string.Empty;
                        string AdditionalData = string.Empty;
                        string MerchantVolume = string.Empty;
                        string ElectronicsCGI = string.Empty;
                        string MerchantVerValue = string.Empty;
                        string InterchangeFeeAmount = string.Empty;
                        string InterchangeFeeSign = string.Empty;
                        string SCBCCYExchangeRate = string.Empty;
                        string BCDCCYExhangeRate = string.Empty;
                        string ISAAmount = string.Empty;
                        string ProductID = string.Empty;
                        string ProgramID = string.Empty;
                        string DCCIndicator = string.Empty;
                        string AccountTypeIdentification = string.Empty;
                        string SpendQIndicator = string.Empty;
                        string PanToken = string.Empty;
                        string Reserved4 = string.Empty;
                        string CVV2ResultCode = string.Empty;
                        string ReserveField1 = string.Empty;
                        string ReserveField2 = string.Empty;
                        string ReserveField3 = string.Empty;
                        string ReserveField4 = string.Empty;
                        string ReserveField5 = string.Empty;
                        string Reserved5 = string.Empty;
                        string BusinessFCLG = string.Empty;
                        string Reserved6 = string.Empty;
                        string LodgingNo = string.Empty;
                        string LodExtraCharge = string.Empty;
                        string Reserved7 = string.Empty;
                        string LodgingDate = string.Empty;
                        string DailyRoomRate = string.Empty;
                        string TotalTax = string.Empty;
                        string PrepaidExpns = string.Empty;
                        string FoodCharges = string.Empty;
                        string FolioCashAdv = string.Empty;
                        string RoomNight = string.Empty;
                        string TotalRoomTax = string.Empty;
                        string Reserved8 = string.Empty;
                        string Reserved9 = string.Empty;
                        string FastFundsIn = string.Empty;
                        string BusinessFCCR = string.Empty;
                        string BusinessAppID = string.Empty;
                        string SourceOfFunds = string.Empty;
                        string PaymentRevRC = string.Empty;
                        string SenderRefNo = string.Empty;
                        string SenderAcNo = string.Empty;
                        string SenderName = string.Empty;
                        string SenderAdd = string.Empty;
                        string SenderCity = string.Empty;
                        string SenderState = string.Empty;
                        string SenderCountry = string.Empty;
                        string AUniqueID = string.Empty;
                        string Reserved10 = string.Empty;
                        string BusinessFC4 = string.Empty;
                        string NetIdCode = string.Empty;
                        string ConforInfo = string.Empty;
                        string AdjProceIn = string.Empty;
                        string MsgReasonCode = string.Empty;
                        string SurchargeAmnt = string.Empty;
                        string SurCrDr = string.Empty;
                        string VisaIUO = string.Empty;
                        string Reserved11 = string.Empty;
                        string SurAmntBillCCY = string.Empty;
                        string MoneyTrfExchFee = string.Empty;
                        string Reserved12 = string.Empty;
                        string LocalTax = string.Empty;
                        string LocalTaxIn = string.Empty;
                        string NtlTax = string.Empty;
                        string NtlTaxIn = string.Empty;
                        string BusinessRefNo = string.Empty;
                        string CustVATRegNo = string.Empty;
                        string Reserved13 = string.Empty;
                        string SummaryCommCode = string.Empty;
                        string OtherTax = string.Empty;
                        string MsgID = string.Empty;
                        string TimeOfPurchase = string.Empty;
                        string CustCode = string.Empty;
                        string NonFuelProdCode1 = string.Empty;
                        string NonFuelProdCode2 = string.Empty;
                        string NonFuelProdCode3 = string.Empty;
                        string NonFuelProdCode4 = string.Empty;
                        string NonFuelProdCode5 = string.Empty;
                        string NonFuelProdCode6 = string.Empty;
                        string NonFuelProdCode7 = string.Empty;
                        string NonFuelProdCode8 = string.Empty;
                        string MerPostCode = string.Empty;
                        string Reserved14 = string.Empty;
                        string TxnsType = string.Empty;
                        string CardSeqNo = string.Empty;
                        string TerminalTxnsDate = string.Empty;
                        string TerminalCapProfile = string.Empty;
                        string TerminalCountryCode = string.Empty;
                        string TerminalSerialNo = string.Empty;
                        string UnpredictableNo = string.Empty;
                        string AppTxnsCounter = string.Empty;
                        string AppIntProfile = string.Empty;
                        string Cryptogram = string.Empty;
                        string IssuerAppData2 = string.Empty;
                        string IssuerAppData3 = string.Empty;
                        string TerminalVerResult = string.Empty;
                        string IssuerAppData47 = string.Empty;
                        string CryptogramAmount = string.Empty;
                        string IssuerAppData8 = string.Empty;
                        string IssuerAppData916 = string.Empty;
                        string IssuerAppData1 = string.Empty;
                        string IssuerAppData17 = string.Empty;
                        string IssuerAppData1832 = string.Empty;
                        string FormFactInd = string.Empty;
                        string IssuerScriptResults = string.Empty;


                        string TCR = string.Empty;
                        bool TxnsNo = false;

                        for (int i = 0; i < 7; i++)
                        {
                            line1 = Regex.Replace(TotalCountArray[line + i].ToString(), "[^ -~]+", string.Empty);

                            if (ds.Tables["TxnsCSN"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsCSN"].Rows[0]["Length"].ToString() != "0")
                            {
                                int Start = int.Parse(ds.Tables["TxnsCSN"].Rows[0]["StartPosition"].ToString());
                                int End = int.Parse(ds.Tables["TxnsCSN"].Rows[0]["Length"].ToString());
                                TCR = line1.Substring(Start - Incr, End);
                            }

                            if (TxnsNo && TCR == "0")
                            {
                                break;
                            }

                            #region TCR0
                            if (TCR == "0")
                            {
                                TxnsNo = true;
                                if (ds.Tables["TxnsCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TxnsCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TxnsCode"].Rows[0]["Length"].ToString());
                                    TxnsCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["TxnsCodeQ"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsCodeQ"].Rows[0]["Length"].ToString() != "0")
                                {

                                    int Start = int.Parse(ds.Tables["TxnsCodeQ"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TxnsCodeQ"].Rows[0]["Length"].ToString());
                                    TxnsCodeQ = line1.Substring(Start - Incr, End);

                                }
                                if (ds.Tables["TxnsCSN"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsCSN"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TxnsCSN"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TxnsCSN"].Rows[0]["Length"].ToString());
                                    TxnsCSN = line1.Substring(Start - Incr, End);

                                }
                                if (ds.Tables["AccountNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AccountNumber"].Rows[0]["Length"].ToString() != "0")
                                {

                                    int Start = int.Parse(ds.Tables["AccountNumber"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AccountNumber"].Rows[0]["Length"].ToString());
                                    AccountNumber = line1.Substring(Start - Incr, End);


                                }
                                if (ds.Tables["AccountNumberExt"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AccountNumberExt"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AccountNumberExt"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AccountNumberExt"].Rows[0]["Length"].ToString());
                                    AccountNumberExt = line1.Substring(Start - Incr, End);

                                }
                                if (ds.Tables["FloorLimit"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FloorLimit"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["FloorLimit"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["FloorLimit"].Rows[0]["Length"].ToString());
                                    FloorLimit = line1.Substring(Start - Incr, End);

                                }
                                if (ds.Tables["ExceptionFile"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ExceptionFile"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ExceptionFile"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ExceptionFile"].Rows[0]["Length"].ToString());
                                    ExceptionFile = line1.Substring(Start - Incr, End);

                                }
                                if (ds.Tables["PCAS"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PCAS"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["PCAS"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["PCAS"].Rows[0]["Length"].ToString());
                                    PCAS = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AcqReferenceNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AcqReferenceNumber"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AcqReferenceNumber"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AcqReferenceNumber"].Rows[0]["Length"].ToString());
                                    AcqReferenceNumber = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AcqBusinessID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AcqBusinessID"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AcqBusinessID"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AcqBusinessID"].Rows[0]["Length"].ToString());
                                    AcqBusinessID = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["PurchaseDate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PurchaseDate"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["PurchaseDate"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["PurchaseDate"].Rows[0]["Length"].ToString());
                                    PurchaseDate = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["DestAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DestAmount"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["DestAmount"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["DestAmount"].Rows[0]["Length"].ToString());
                                    DestAmount = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["DestCCY"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DestCCY"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["DestCCY"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["DestCCY"].Rows[0]["Length"].ToString());
                                    DestCCY = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SrcAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SrcAmount"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SrcAmount"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SrcAmount"].Rows[0]["Length"].ToString());
                                    SrcAmount = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SrcCCY"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SrcCCY"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SrcCCY"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SrcCCY"].Rows[0]["Length"].ToString());
                                    SrcCCY = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MarchantName"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantName"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MarchantName"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MarchantName"].Rows[0]["Length"].ToString());
                                    MarchantName = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MarchantCity"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantCity"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MarchantCity"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MarchantCity"].Rows[0]["Length"].ToString());
                                    MarchantCity = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MarchantCountryCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantCountryCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MarchantCountryCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MarchantCountryCode"].Rows[0]["Length"].ToString());
                                    MarchantCountryCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MarchantCateCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantCateCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MarchantCateCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MarchantCateCode"].Rows[0]["Length"].ToString());
                                    MarchantCateCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MarchantZIPCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantZIPCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MarchantZIPCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MarchantZIPCode"].Rows[0]["Length"].ToString());
                                    MarchantZIPCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MarchantSPCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantSPCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MarchantSPCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MarchantSPCode"].Rows[0]["Length"].ToString());
                                    MarchantSPCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ReqPaymentService"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReqPaymentService"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ReqPaymentService"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ReqPaymentService"].Rows[0]["Length"].ToString());
                                    ReqPaymentService = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NoOfPaymentForm"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NoOfPaymentForm"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NoOfPaymentForm"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NoOfPaymentForm"].Rows[0]["Length"].ToString());
                                    NoOfPaymentForm = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["UsageCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["UsageCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["UsageCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["UsageCode"].Rows[0]["Length"].ToString());
                                    UsageCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ReasonCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReasonCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ReasonCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ReasonCode"].Rows[0]["Length"].ToString());
                                    ReasonCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SettlementFlag"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SettlementFlag"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SettlementFlag"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SettlementFlag"].Rows[0]["Length"].ToString());
                                    SettlementFlag = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AuthCharIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthCharIndicator"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AuthCharIndicator"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AuthCharIndicator"].Rows[0]["Length"].ToString());
                                    AuthCharIndicator = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AuthCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AuthCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AuthCode"].Rows[0]["Length"].ToString());
                                    AuthCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["POSTerminalCapability"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["POSTerminalCapability"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["POSTerminalCapability"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["POSTerminalCapability"].Rows[0]["Length"].ToString());
                                    POSTerminalCapability = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["Reserved1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved1"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["Reserved1"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["Reserved1"].Rows[0]["Length"].ToString());
                                    Reserved1 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CardHolderID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardHolderID"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CardHolderID"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CardHolderID"].Rows[0]["Length"].ToString());
                                    CardHolderID = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CollectionOnlyFlag"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CollectionOnlyFlag"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CollectionOnlyFlag"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CollectionOnlyFlag"].Rows[0]["Length"].ToString());
                                    CollectionOnlyFlag = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["POSEntryMode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["POSEntryMode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["POSEntryMode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["POSEntryMode"].Rows[0]["Length"].ToString());
                                    POSEntryMode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CentralProcessDate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CentralProcessDate"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CentralProcessDate"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CentralProcessDate"].Rows[0]["Length"].ToString());
                                    CentralProcessDate = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ReimbursementAttribute"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReimbursementAttribute"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ReimbursementAttribute"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ReimbursementAttribute"].Rows[0]["Length"].ToString());
                                    ReimbursementAttribute = line1.Substring(Start - Incr, End);
                                }

                            }
                            #endregion TCR0

                            #region TCR1
                            if (TCR == "1")
                            {
                                if (ds.Tables["BusinessFC"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessFC"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["BusinessFC"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["BusinessFC"].Rows[0]["Length"].ToString());
                                    BusinessFC = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["TokanAssuranceLevel"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TokanAssuranceLevel"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TokanAssuranceLevel"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TokanAssuranceLevel"].Rows[0]["Length"].ToString());
                                    TokanAssuranceLevel = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["Reserved2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved2"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["Reserved2"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["Reserved2"].Rows[0]["Length"].ToString());
                                    Reserved2 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ChargebackRefNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ChargebackRefNo"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ChargebackRefNo"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ChargebackRefNo"].Rows[0]["Length"].ToString());
                                    ChargebackRefNo = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["DocIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DocIndicator"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["DocIndicator"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["DocIndicator"].Rows[0]["Length"].ToString());
                                    DocIndicator = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MemMsgText"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MemMsgText"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MemMsgText"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MemMsgText"].Rows[0]["Length"].ToString());
                                    MemMsgText = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SpecialCondition"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SpecialCondition"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SpecialCondition"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SpecialCondition"].Rows[0]["Length"].ToString());
                                    SpecialCondition = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["FeeProgram"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FeeProgram"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["FeeProgram"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["FeeProgram"].Rows[0]["Length"].ToString());
                                    FeeProgram = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IssuerCharge"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerCharge"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IssuerCharge"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IssuerCharge"].Rows[0]["Length"].ToString());
                                    IssuerCharge = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["Reserved3"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved3"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["Reserved3"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["Reserved3"].Rows[0]["Length"].ToString());
                                    Reserved3 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CardAcceptorID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardAcceptorID"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CardAcceptorID"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CardAcceptorID"].Rows[0]["Length"].ToString());
                                    CardAcceptorID = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["TerminalID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalID"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TerminalID"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TerminalID"].Rows[0]["Length"].ToString());
                                    TerminalID = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NationalRBFee"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NationalRBFee"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NationalRBFee"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NationalRBFee"].Rows[0]["Length"].ToString());
                                    NationalRBFee = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MPECIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MPECIndicator"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MPECIndicator"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MPECIndicator"].Rows[0]["Length"].ToString());
                                    MPECIndicator = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SpecialChargeback"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SpecialChargeback"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SpecialChargeback"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SpecialChargeback"].Rows[0]["Length"].ToString());
                                    SpecialChargeback = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IntTraceNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IntTraceNumber"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IntTraceNumber"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IntTraceNumber"].Rows[0]["Length"].ToString());
                                    IntTraceNumber = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AcceptTerminal"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AcceptTerminal"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AcceptTerminal"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AcceptTerminal"].Rows[0]["Length"].ToString());
                                    AcceptTerminal = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["PrepaidCard"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PrepaidCard"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["PrepaidCard"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["PrepaidCard"].Rows[0]["Length"].ToString());
                                    PrepaidCard = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ServiceDevlopmentField"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ServiceDevlopmentField"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ServiceDevlopmentField"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ServiceDevlopmentField"].Rows[0]["Length"].ToString());
                                    ServiceDevlopmentField = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AVSResponseCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AVSResponseCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AVSResponseCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AVSResponseCode"].Rows[0]["Length"].ToString());
                                    AVSResponseCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AuthSourceCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthSourceCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AuthSourceCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AuthSourceCode"].Rows[0]["Length"].ToString());
                                    AuthSourceCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["PurchaseIdenFormat"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PurchaseIdenFormat"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["PurchaseIdenFormat"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["PurchaseIdenFormat"].Rows[0]["Length"].ToString());
                                    PurchaseIdenFormat = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AccountSelection"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AccountSelection"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AccountSelection"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AccountSelection"].Rows[0]["Length"].ToString());
                                    AccountSelection = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["InstallmentPayCount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["InstallmentPayCount"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["InstallmentPayCount"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["InstallmentPayCount"].Rows[0]["Length"].ToString());
                                    InstallmentPayCount = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["PurchaseIdentifier"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PurchaseIdentifier"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["PurchaseIdentifier"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["PurchaseIdentifier"].Rows[0]["Length"].ToString());
                                    PurchaseIdentifier = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CashBack"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CashBack"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CashBack"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CashBack"].Rows[0]["Length"].ToString());
                                    CashBack = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ChipConCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ChipConCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ChipConCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ChipConCode"].Rows[0]["Length"].ToString());
                                    ChipConCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["POSEnviroment"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["POSEnviroment"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["POSEnviroment"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["POSEnviroment"].Rows[0]["Length"].ToString());
                                    POSEnviroment = line1.Substring(Start - Incr, End);
                                }
                            }
                            #endregion TCR1

                            #region TCR3
                            if (TCR == "3")
                            {
                                if (ds.Tables["BusinessFCLG"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessFCLG"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["BusinessFCLG"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["BusinessFCLG"].Rows[0]["Length"].ToString());
                                    BusinessFCLG = line1.Substring(Start - Incr, End);
                                }

                                if (BusinessFCLG == "LG")
                                {

                                    if (ds.Tables["Reserved5"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved5"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["Reserved5"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["Reserved5"].Rows[0]["Length"].ToString());
                                        Reserved5 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["BusinessFCLG"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessFCLG"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["BusinessFCLG"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["BusinessFCLG"].Rows[0]["Length"].ToString());
                                        BusinessFCLG = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved6"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved6"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["Reserved6"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["Reserved6"].Rows[0]["Length"].ToString());
                                        Reserved6 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["LodgingNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LodgingNo"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["LodgingNo"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["LodgingNo"].Rows[0]["Length"].ToString());
                                        LodgingNo = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["LodExtraCharge"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LodExtraCharge"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["LodExtraCharge"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["LodExtraCharge"].Rows[0]["Length"].ToString());
                                        LodExtraCharge = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved7"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved7"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["Reserved7"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["Reserved7"].Rows[0]["Length"].ToString());
                                        Reserved7 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["LodgingDate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LodgingDate"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["LodgingDate"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["LodgingDate"].Rows[0]["Length"].ToString());
                                        LodgingDate = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["DailyRoomRate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DailyRoomRate"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["DailyRoomRate"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["DailyRoomRate"].Rows[0]["Length"].ToString());
                                        DailyRoomRate = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TotalTax"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TotalTax"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["TotalTax"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["TotalTax"].Rows[0]["Length"].ToString());
                                        TotalTax = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["PrepaidExpns"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PrepaidExpns"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["PrepaidExpns"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["PrepaidExpns"].Rows[0]["Length"].ToString());
                                        PrepaidExpns = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["FoodCharges"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FoodCharges"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["FoodCharges"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["FoodCharges"].Rows[0]["Length"].ToString());
                                        FoodCharges = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["FolioCashAdv"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FolioCashAdv"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["FolioCashAdv"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["FolioCashAdv"].Rows[0]["Length"].ToString());
                                        FolioCashAdv = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["RoomNight"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["RoomNight"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["RoomNight"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["RoomNight"].Rows[0]["Length"].ToString());
                                        RoomNight = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TotalRoomTax"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TotalRoomTax"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["TotalRoomTax"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["TotalRoomTax"].Rows[0]["Length"].ToString());
                                        TotalRoomTax = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved8"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved8"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["Reserved8"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["Reserved8"].Rows[0]["Length"].ToString());
                                        Reserved8 = line1.Substring(Start - Incr, End);
                                    }
                                }
                                if (BusinessFCLG == "CR")
                                {
                                    if (ds.Tables["Reserved9"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved9"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["Reserved9"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["Reserved9"].Rows[0]["Length"].ToString());
                                        Reserved9 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["FastFundsIn"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FastFundsIn"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["FastFundsIn"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["FastFundsIn"].Rows[0]["Length"].ToString());
                                        FastFundsIn = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["BusinessFCCR"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessFCCR"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["BusinessFCCR"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["BusinessFCCR"].Rows[0]["Length"].ToString());
                                        BusinessFCCR = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["BusinessAppID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessAppID"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["BusinessAppID"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["BusinessAppID"].Rows[0]["Length"].ToString());
                                        BusinessAppID = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SourceOfFunds"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SourceOfFunds"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["SourceOfFunds"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["SourceOfFunds"].Rows[0]["Length"].ToString());
                                        SourceOfFunds = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["PaymentRevRC"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PaymentRevRC"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["PaymentRevRC"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["PaymentRevRC"].Rows[0]["Length"].ToString());
                                        PaymentRevRC = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SenderRefNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderRefNo"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["SenderRefNo"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["SenderRefNo"].Rows[0]["Length"].ToString());
                                        SenderRefNo = line1.Substring(Start - Incr, End);
                                    }


                                    if (ds.Tables["SenderAcNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderAcNo"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["SenderAcNo"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["SenderAcNo"].Rows[0]["Length"].ToString());
                                        SenderAcNo = line1.Substring(Start - Incr, End);
                                    }

                                    if (ds.Tables["SenderName"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderName"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["SenderName"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["SenderName"].Rows[0]["Length"].ToString());
                                        SenderName = line1.Substring(Start - Incr, End);
                                    }

                                    if (ds.Tables["SenderAdd"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderAdd"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["SenderAdd"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["SenderAdd"].Rows[0]["Length"].ToString());
                                        SenderAdd = line1.Substring(Start - Incr, End);
                                    }

                                    if (ds.Tables["SenderCity"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderCity"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["SenderCity"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["SenderCity"].Rows[0]["Length"].ToString());
                                        SenderCity = line1.Substring(Start - Incr, End);
                                    }

                                    if (ds.Tables["SenderState"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderState"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["SenderState"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["SenderState"].Rows[0]["Length"].ToString());
                                        SenderState = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SenderCountry"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderCountry"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        int Start = int.Parse(ds.Tables["SenderCountry"].Rows[0]["StartPosition"].ToString());
                                        int End = int.Parse(ds.Tables["SenderCountry"].Rows[0]["Length"].ToString());
                                        SenderCountry = line1.Substring(Start - Incr, End);
                                    }

                                }



                            }
                            #endregion TCR3

                            #region TCR4
                            if (TCR == "4")
                            {
                                if (ds.Tables["AUniqueID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AUniqueID"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AUniqueID"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AUniqueID"].Rows[0]["Length"].ToString());
                                    AUniqueID = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["Reserved10"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved10"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["Reserved10"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["Reserved10"].Rows[0]["Length"].ToString());
                                    Reserved10 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["BusinessFC4"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessFC4"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["BusinessFC4"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["BusinessFC4"].Rows[0]["Length"].ToString());
                                    BusinessFC4 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NetIdCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NetIdCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NetIdCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NetIdCode"].Rows[0]["Length"].ToString());
                                    NetIdCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ConforInfo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ConforInfo"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ConforInfo"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ConforInfo"].Rows[0]["Length"].ToString());
                                    ConforInfo = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AdjProceIn"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AdjProceIn"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AdjProceIn"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AdjProceIn"].Rows[0]["Length"].ToString());
                                    AdjProceIn = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MsgReasonCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MsgReasonCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MsgReasonCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MsgReasonCode"].Rows[0]["Length"].ToString());
                                    MsgReasonCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SurchargeAmnt"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SurchargeAmnt"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SurchargeAmnt"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SurchargeAmnt"].Rows[0]["Length"].ToString());
                                    SurchargeAmnt = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SurCrDr"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SurCrDr"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SurCrDr"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SurCrDr"].Rows[0]["Length"].ToString());
                                    SurCrDr = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["VisaIUO"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["VisaIUO"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["VisaIUO"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["VisaIUO"].Rows[0]["Length"].ToString());
                                    VisaIUO = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["Reserved11"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved11"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["Reserved11"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["Reserved11"].Rows[0]["Length"].ToString());
                                    Reserved11 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SurAmntBillCCY"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SurAmntBillCCY"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SurAmntBillCCY"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SurAmntBillCCY"].Rows[0]["Length"].ToString());
                                    SurAmntBillCCY = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MoneyTrfExchFee"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MoneyTrfExchFee"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MoneyTrfExchFee"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MoneyTrfExchFee"].Rows[0]["Length"].ToString());
                                    MoneyTrfExchFee = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["Reserved12"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved12"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["Reserved12"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["Reserved12"].Rows[0]["Length"].ToString());
                                    Reserved12 = line1.Substring(Start - Incr, End);
                                }

                            }
                            #endregion TCR4

                            #region TCR5
                            if (TCR == "5")
                            {
                                if (ds.Tables["TxnsIdentifier"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsIdentifier"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TxnsIdentifier"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TxnsIdentifier"].Rows[0]["Length"].ToString());
                                    TxnsIdentifier = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AuthAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthAmount"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AuthAmount"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AuthAmount"].Rows[0]["Length"].ToString());
                                    AuthAmount = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AuthCCY"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthCCY"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AuthCCY"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AuthCCY"].Rows[0]["Length"].ToString());
                                    AuthCCY = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AuthResponseCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthResponseCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AuthResponseCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AuthResponseCode"].Rows[0]["Length"].ToString());
                                    AuthResponseCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ValidationCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ValidationCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ValidationCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ValidationCode"].Rows[0]["Length"].ToString());
                                    ValidationCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ExcludedTxnsIdenReason"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ExcludedTxnsIdenReason"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ExcludedTxnsIdenReason"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ExcludedTxnsIdenReason"].Rows[0]["Length"].ToString());
                                    ExcludedTxnsIdenReason = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CRSProcessCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CRSProcessCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CRSProcessCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CRSProcessCode"].Rows[0]["Length"].ToString());
                                    CRSProcessCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ChargeRight"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ChargeRight"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ChargeRight"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ChargeRight"].Rows[0]["Length"].ToString());
                                    ChargeRight = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MultiClearingSN"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MultiClearingSN"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MultiClearingSN"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MultiClearingSN"].Rows[0]["Length"].ToString());
                                    MultiClearingSN = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MultiClearingSC"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MultiClearingSC"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MultiClearingSC"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MultiClearingSC"].Rows[0]["Length"].ToString());
                                    MultiClearingSC = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MarketSADI"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarketSADI"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MarketSADI"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MarketSADI"].Rows[0]["Length"].ToString());
                                    MarketSADI = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["TotalAuthAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TotalAuthAmount"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TotalAuthAmount"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TotalAuthAmount"].Rows[0]["Length"].ToString());
                                    TotalAuthAmount = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["InformationIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["InformationIndicator"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["InformationIndicator"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["InformationIndicator"].Rows[0]["Length"].ToString());
                                    InformationIndicator = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MarchantTelephoneNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantTelephoneNumber"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MarchantTelephoneNumber"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MarchantTelephoneNumber"].Rows[0]["Length"].ToString());
                                    MarchantTelephoneNumber = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AdditionalData"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AdditionalData"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AdditionalData"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AdditionalData"].Rows[0]["Length"].ToString());
                                    AdditionalData = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MerchantVolume"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MerchantVolume"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MerchantVolume"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MerchantVolume"].Rows[0]["Length"].ToString());
                                    MerchantVolume = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ElectronicsCGI"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ElectronicsCGI"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ElectronicsCGI"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ElectronicsCGI"].Rows[0]["Length"].ToString());
                                    ElectronicsCGI = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MerchantVerValue"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MerchantVerValue"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MerchantVerValue"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MerchantVerValue"].Rows[0]["Length"].ToString());
                                    MerchantVerValue = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["InterchangeFeeAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["InterchangeFeeAmount"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["InterchangeFeeAmount"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["InterchangeFeeAmount"].Rows[0]["Length"].ToString());
                                    InterchangeFeeAmount = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["InterchangeFeeSign"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["InterchangeFeeSign"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["InterchangeFeeSign"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["InterchangeFeeSign"].Rows[0]["Length"].ToString());
                                    InterchangeFeeSign = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SCBCCYExchangeRate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SCBCCYExchangeRate"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SCBCCYExchangeRate"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SCBCCYExchangeRate"].Rows[0]["Length"].ToString());
                                    SCBCCYExchangeRate = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["BCDCCYExhangeRate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BCDCCYExhangeRate"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["BCDCCYExhangeRate"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["BCDCCYExhangeRate"].Rows[0]["Length"].ToString());
                                    BCDCCYExhangeRate = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ISAAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ISAAmount"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ISAAmount"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ISAAmount"].Rows[0]["Length"].ToString());
                                    ISAAmount = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ProductID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ProductID"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ProductID"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ProductID"].Rows[0]["Length"].ToString());
                                    ProductID = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["ProgramID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ProgramID"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["ProgramID"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["ProgramID"].Rows[0]["Length"].ToString());
                                    ProgramID = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["DCCIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DCCIndicator"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["DCCIndicator"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["DCCIndicator"].Rows[0]["Length"].ToString());
                                    DCCIndicator = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AccountTypeIdentification"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AccountTypeIdentification"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AccountTypeIdentification"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AccountTypeIdentification"].Rows[0]["Length"].ToString());
                                    AccountTypeIdentification = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SpendQIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SpendQIndicator"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SpendQIndicator"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SpendQIndicator"].Rows[0]["Length"].ToString());
                                    SpendQIndicator = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["PanToken"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PanToken"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["PanToken"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["PanToken"].Rows[0]["Length"].ToString());
                                    PanToken = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CVV2ResultCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CVV2ResultCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CVV2ResultCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CVV2ResultCode"].Rows[0]["Length"].ToString());
                                    CVV2ResultCode = line1.Substring(Start - Incr, End);
                                }
                            }
                            #endregion TCR5

                            #region TCR6
                            if (TCR == "6")
                            {
                                if (ds.Tables["LocalTax"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LocalTax"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["LocalTax"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["LocalTax"].Rows[0]["Length"].ToString());
                                    LocalTax = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["LocalTaxIn"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LocalTaxIn"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["LocalTaxIn"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["LocalTaxIn"].Rows[0]["Length"].ToString());
                                    LocalTaxIn = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NtlTax"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NtlTax"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NtlTax"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NtlTax"].Rows[0]["Length"].ToString());
                                    NtlTax = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NtlTaxIn"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NtlTaxIn"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NtlTaxIn"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NtlTaxIn"].Rows[0]["Length"].ToString());
                                    NtlTaxIn = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["BusinessRefNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessRefNo"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["BusinessRefNo"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["BusinessRefNo"].Rows[0]["Length"].ToString());
                                    BusinessRefNo = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CustVATRegNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CustVATRegNo"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CustVATRegNo"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CustVATRegNo"].Rows[0]["Length"].ToString());
                                    CustVATRegNo = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["Reserved13"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved13"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["Reserved13"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["Reserved13"].Rows[0]["Length"].ToString());
                                    Reserved13 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["SummaryCommCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SummaryCommCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["SummaryCommCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["SummaryCommCode"].Rows[0]["Length"].ToString());
                                    SummaryCommCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["OtherTax"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["OtherTax"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["OtherTax"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["OtherTax"].Rows[0]["Length"].ToString());
                                    OtherTax = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MsgID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MsgID"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MsgID"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MsgID"].Rows[0]["Length"].ToString());
                                    MsgID = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["TimeOfPurchase"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TimeOfPurchase"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TimeOfPurchase"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TimeOfPurchase"].Rows[0]["Length"].ToString());
                                    TimeOfPurchase = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CustCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CustCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CustCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CustCode"].Rows[0]["Length"].ToString());
                                    CustCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NonFuelProdCode1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode1"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NonFuelProdCode1"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NonFuelProdCode1"].Rows[0]["Length"].ToString());
                                    NonFuelProdCode1 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NonFuelProdCode2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode2"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NonFuelProdCode2"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NonFuelProdCode2"].Rows[0]["Length"].ToString());
                                    NonFuelProdCode2 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NonFuelProdCode3"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode3"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NonFuelProdCode3"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NonFuelProdCode3"].Rows[0]["Length"].ToString());
                                    NonFuelProdCode3 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NonFuelProdCode4"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode4"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NonFuelProdCode4"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NonFuelProdCode4"].Rows[0]["Length"].ToString());
                                    NonFuelProdCode4 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NonFuelProdCode5"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode5"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NonFuelProdCode5"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NonFuelProdCode5"].Rows[0]["Length"].ToString());
                                    NonFuelProdCode5 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NonFuelProdCode6"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode6"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NonFuelProdCode6"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NonFuelProdCode6"].Rows[0]["Length"].ToString());
                                    NonFuelProdCode6 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NonFuelProdCode7"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode7"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NonFuelProdCode7"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NonFuelProdCode7"].Rows[0]["Length"].ToString());
                                    NonFuelProdCode7 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["NonFuelProdCode8"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode8"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["NonFuelProdCode8"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["NonFuelProdCode8"].Rows[0]["Length"].ToString());
                                    NonFuelProdCode8 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["MerPostCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MerPostCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["MerPostCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["MerPostCode"].Rows[0]["Length"].ToString());
                                    MerPostCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["Reserved14"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved14"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["Reserved14"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["Reserved14"].Rows[0]["Length"].ToString());
                                    Reserved14 = line1.Substring(Start - Incr, End);
                                }

                            }
                            #endregion TCR6

                            #region TCR7
                            if (TCR == "7")
                            {
                                if (ds.Tables["TxnsType"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsType"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TxnsType"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TxnsType"].Rows[0]["Length"].ToString());
                                    TxnsType = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CardSeqNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardSeqNo"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CardSeqNo"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CardSeqNo"].Rows[0]["Length"].ToString());
                                    CardSeqNo = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["TerminalTxnsDate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalTxnsDate"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TerminalTxnsDate"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TerminalTxnsDate"].Rows[0]["Length"].ToString());
                                    TerminalTxnsDate = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["TerminalCapProfile"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalCapProfile"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TerminalCapProfile"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TerminalCapProfile"].Rows[0]["Length"].ToString());
                                    TerminalCapProfile = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["TerminalCountryCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalCountryCode"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TerminalCountryCode"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TerminalCountryCode"].Rows[0]["Length"].ToString());
                                    TerminalCountryCode = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["TerminalSerialNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalSerialNo"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TerminalSerialNo"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TerminalSerialNo"].Rows[0]["Length"].ToString());
                                    TerminalSerialNo = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["UnpredictableNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["UnpredictableNo"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["UnpredictableNo"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["UnpredictableNo"].Rows[0]["Length"].ToString());
                                    UnpredictableNo = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AppTxnsCounter"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AppTxnsCounter"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AppTxnsCounter"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AppTxnsCounter"].Rows[0]["Length"].ToString());
                                    AppTxnsCounter = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["AppIntProfile"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AppIntProfile"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["AppIntProfile"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["AppIntProfile"].Rows[0]["Length"].ToString());
                                    AppIntProfile = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["Cryptogram"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Cryptogram"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["Cryptogram"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["Cryptogram"].Rows[0]["Length"].ToString());
                                    Cryptogram = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IssuerAppData2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData2"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IssuerAppData2"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IssuerAppData2"].Rows[0]["Length"].ToString());
                                    IssuerAppData2 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IssuerAppData3"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData3"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IssuerAppData3"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IssuerAppData3"].Rows[0]["Length"].ToString());
                                    IssuerAppData3 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["TerminalVerResult"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalVerResult"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["TerminalVerResult"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["TerminalVerResult"].Rows[0]["Length"].ToString());
                                    TerminalVerResult = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IssuerAppData47"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData47"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IssuerAppData47"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IssuerAppData47"].Rows[0]["Length"].ToString());
                                    IssuerAppData47 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["CryptogramAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CryptogramAmount"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["CryptogramAmount"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["CryptogramAmount"].Rows[0]["Length"].ToString());
                                    CryptogramAmount = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IssuerAppData8"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData8"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IssuerAppData8"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IssuerAppData8"].Rows[0]["Length"].ToString());
                                    IssuerAppData8 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IssuerAppData916"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData916"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IssuerAppData916"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IssuerAppData916"].Rows[0]["Length"].ToString());
                                    IssuerAppData916 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IssuerAppData1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData1"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IssuerAppData1"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IssuerAppData1"].Rows[0]["Length"].ToString());
                                    IssuerAppData1 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IssuerAppData17"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData17"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IssuerAppData17"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IssuerAppData17"].Rows[0]["Length"].ToString());
                                    IssuerAppData17 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IssuerAppData1832"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData1832"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IssuerAppData1832"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IssuerAppData1832"].Rows[0]["Length"].ToString());
                                    IssuerAppData1832 = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["FormFactInd"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FormFactInd"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["FormFactInd"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["FormFactInd"].Rows[0]["Length"].ToString());
                                    FormFactInd = line1.Substring(Start - Incr, End);
                                }
                                if (ds.Tables["IssuerScriptResults"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerScriptResults"].Rows[0]["Length"].ToString() != "0")
                                {
                                    int Start = int.Parse(ds.Tables["IssuerScriptResults"].Rows[0]["StartPosition"].ToString());
                                    int End = int.Parse(ds.Tables["IssuerScriptResults"].Rows[0]["Length"].ToString());
                                    IssuerScriptResults = line1.Substring(Start - Incr, End);
                                }

                            }
                            #endregion TCR7

                        }



                        DateTime? LodgingDateTime;
                        LodgingDateTime = null;
                        if (LodgingDate != "" && LodgingDate != "000000")
                        {
                            LodgingDateTime = DateTime.ParseExact(LodgingDate, "yyMMdd", CultureInfo.InvariantCulture);
                        }


                        DateTime? TerminalTxnsDateTime;
                        TerminalTxnsDateTime = null;
                        if (TerminalTxnsDate != "")
                        {
                            TerminalTxnsDateTime = DateTime.ParseExact(TerminalTxnsDate, "yyMMdd", CultureInfo.InvariantCulture);
                        }


                        string SettlementDate = AcqReferenceNumber.Substring(7, 5);

                        string year = string.Empty;

                        int SDate = Convert.ToInt32(SettlementDate);
                        int SDay = SDate % 1000;
                        if (SDay == 366)
                        {
                            SDay = SDay - 1;
                        }
                        int Syear = fyear;
                        var SDateTime = new DateTime(Syear, 1, 1);
                        var SettlementDateTime = SDateTime.AddDays(SDay - 1);


                        if (Convert.ToInt32(PurchaseDate.Substring(0, 2)) > month)
                        {
                            year = (fyear - 1).ToString();
                        }
                        else
                        {
                            year = fyear.ToString();//DateTime.Now.Year.ToString();
                        }
                        PurchaseDate = PurchaseDate.Substring(2, 2) + "/" + PurchaseDate.Substring(0, 2) + "/" + year + " 00:00:00";
                        // CultureInfo culture = new CultureInfo("en-US");
                        DateTime TransactionDateTime = DateTime.ParseExact(PurchaseDate, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);

                        int CDate = Convert.ToInt32(CentralProcessDate);
                        int CDay = CDate % 1000;
                        if (CDay == 366)
                        {
                            CDay = CDay - 1;
                        }
                        int Cyear = fyear;
                        var CDateTime = new DateTime(Cyear, 1, 1);
                        var Central_Processing_DateTime = CDateTime.AddDays(CDay - 1);

                        string CardNumber = AccountNumber;
                        string CardType = string.Empty;
                    
                        #region InitilizedField

                        #endregion InitilizedField

                        string ECardNumber = string.Empty;
                        if (CardNumber != "")
                        {
                            ECardNumber = AesEncryption.EncryptString(CardNumber);;
                        }

                        _DataTable0.Rows.Add(UniqueID
                          , TxnsCode
                          , TxnsCodeQ
                          , TxnsCSN
                          , ECardNumber
                          , AccountNumberExt
                          , FloorLimit
                          , ExceptionFile
                          , PCAS
                          , AcqReferenceNumber
                          , AcqBusinessID
                          , TransactionDateTime
                          , Convert.ToDecimal(DestAmount)
                          , DestCCY
                          , Convert.ToDecimal(SrcAmount)
                          , SrcCCY
                          , MarchantName
                          , MarchantCity
                          , MarchantCountryCode
                          , MarchantCateCode
                          , MarchantZIPCode
                          , MarchantSPCode
                          , ReqPaymentService
                          , NoOfPaymentForm
                          , UsageCode
                          , ReasonCode
                          , SettlementFlag
                          , AuthCharIndicator
                          , AuthCode
                          , POSTerminalCapability
                          , Reserved1
                          , CardHolderID
                          , CollectionOnlyFlag
                          , POSEntryMode
                          , Central_Processing_DateTime
                          , ReimbursementAttribute
                          , ReserveField1
                          , ReserveField2
                          , ReserveField3
                          , ReserveField4
                          , ReserveField5
                          , RevEntryLeg
                          , 0
                          , FileName
                          , path
                          , FileDate
                          , DateTime.Now
                          , DateTime.Now
                          , UserName
                          , UserName
                          );



                        _DataTable1.Rows.Add(UniqueID
                                      , BusinessFC
                                      , TokanAssuranceLevel
                                      , Reserved2
                                      , ChargebackRefNo
                                      , DocIndicator
                                      , MemMsgText
                                      , SpecialCondition
                                      , FeeProgram
                                      , IssuerCharge
                                      , Reserved3
                                      , CardAcceptorID
                                      , TerminalID
                                      , NationalRBFee
                                      , MPECIndicator
                                      , SpecialChargeback
                                      , IntTraceNumber
                                      , AcceptTerminal
                                      , PrepaidCard
                                      , ServiceDevlopmentField
                                      , AVSResponseCode
                                      , AuthSourceCode
                                      , PurchaseIdenFormat
                                      , AccountSelection
                                      , InstallmentPayCount
                                      , PurchaseIdentifier
                                      , CashBack
                                      , ChipConCode
                                      , POSEnviroment
                                      , RevEntryLeg
                                      , 0
                                      );

                        if (BusinessFCLG != "")
                        {
                            _DataTable3.Rows.Add(UniqueID
                                                 , Reserved5
                                                 , BusinessFCLG
                                                 , Reserved6
                                                 , LodgingNo
                                                 , LodExtraCharge
                                                 , Reserved7
                                                 , LodgingDateTime
                                                 , DailyRoomRate
                                                 , TotalTax
                                                 , PrepaidExpns
                                                 , FoodCharges
                                                 , FolioCashAdv
                                                 , RoomNight
                                                 , TotalRoomTax
                                                 , Reserved8
                                                 , Reserved9
                                                 , FastFundsIn
                                                  , BusinessFCCR
                                                  , BusinessAppID
                                                  , SourceOfFunds
                                                  , PaymentRevRC
                                                  , SenderRefNo
                                                  , SenderAcNo
                                                  , SenderName
                                                  , SenderAdd
                                                  , SenderCity
                                                  , SenderState
                                                  , SenderCountry
                                                 , RevEntryLeg
                                                 , 0
                                                 );
                        }


                        if (AUniqueID != "")
                        {
                            _DataTable4.Rows.Add(UniqueID
                                                  , AUniqueID
                                                  , Reserved10
                                                  , BusinessFC4
                                                  , NetIdCode
                                                  , ConforInfo
                                                  , AdjProceIn
                                                  , MsgReasonCode
                                                  , SurchargeAmnt
                                                  , SurCrDr
                                                  , VisaIUO
                                                  , Reserved11
                                                  , SurAmntBillCCY
                                                  , MoneyTrfExchFee
                                                  , Reserved12
                                                 , RevEntryLeg
                                                 , 0
                                                 );
                        }




                        _DataTable5.Rows.Add(UniqueID
                                , TxnsIdentifier
                                , Convert.ToDecimal(AuthAmount)
                                , AuthCCY
                                , AuthResponseCode
                                , ValidationCode
                                , ExcludedTxnsIdenReason
                                , CRSProcessCode
                                , ChargeRight
                                , MultiClearingSN
                                , MultiClearingSC
                                , MarketSADI
                                , Convert.ToDecimal(TotalAuthAmount)
                                , InformationIndicator
                                , MarchantTelephoneNumber
                                , AdditionalData
                                , MerchantVolume
                                , ElectronicsCGI
                                , MerchantVerValue
                                , Convert.ToDecimal(InterchangeFeeAmount)
                                , InterchangeFeeSign
                                , Convert.ToDecimal(SCBCCYExchangeRate)
                                , Convert.ToDecimal(BCDCCYExhangeRate)
                                , Convert.ToDecimal(ISAAmount)
                                , ProductID
                                , ProgramID
                                , DCCIndicator
                                , AccountTypeIdentification
                                , SpendQIndicator
                                , PanToken
                                , Reserved4
                                , CVV2ResultCode
                                , RevEntryLeg
                                , 0
                                );

                        if (BusinessRefNo != "")
                        {
                            _DataTable6.Rows.Add(UniqueID
                                                 , LocalTax
                                                 , LocalTaxIn
                                                 , NtlTax
                                                 , NtlTaxIn
                                                 , BusinessRefNo
                                                 , CustVATRegNo
                                                 , Reserved13
                                                 , SummaryCommCode
                                                 , OtherTax
                                                 , MsgID
                                                 , TimeOfPurchase
                                                 , CustCode
                                                 , NonFuelProdCode1
                                                 , NonFuelProdCode2
                                                 , NonFuelProdCode3
                                                 , NonFuelProdCode4
                                                 , NonFuelProdCode5
                                                 , NonFuelProdCode6
                                                 , NonFuelProdCode7
                                                 , NonFuelProdCode8
                                                 , MerPostCode
                                                 , Reserved14
                                                 , RevEntryLeg
                                                 , 0
                                                 );


                        }


                        if (CardSeqNo != "")
                        {
                            _DataTable7.Rows.Add(UniqueID
                                                  , TxnsType
                                                  , CardSeqNo
                                                  , TerminalTxnsDate
                                                  , TerminalCapProfile
                                                  , TerminalCountryCode
                                                  , TerminalSerialNo
                                                  , UnpredictableNo
                                                  , AppTxnsCounter
                                                  , AppIntProfile
                                                  , Cryptogram
                                                  , IssuerAppData2
                                                  , IssuerAppData3
                                                  , TerminalVerResult
                                                  , IssuerAppData47
                                                  , CryptogramAmount
                                                  , IssuerAppData8
                                                  , IssuerAppData916
                                                  , IssuerAppData1
                                                  , IssuerAppData17
                                                  , IssuerAppData1832
                                                  , FormFactInd
                                                  , IssuerScriptResults
                                                  , RevEntryLeg
                                                  , 0
                                                  );

                        }


                    }
                    catch (Exception ex)
                    {
                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "VISA.cs", "SplitData", LineNo, FileName + line1, UserName, 'E');
                        objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterVISAIssuer.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    }

                }

            }

            int i0 = _DataTable0.Rows.Count;
            int i1 = _DataTable1.Rows.Count;
            int i3 = _DataTable3.Rows.Count;
            int i4 = _DataTable4.Rows.Count;
            int i5 = _DataTable5.Rows.Count;
            int i6 = _DataTable6.Rows.Count;
            int i7 = _DataTable7.Rows.Count;
            int i8 = _DataTable1020.Rows.Count;

            if (_DataTable0.Rows.Count > 0)
            {
                InsertCount = i0 + i1 + i3 + i4 + i5 + i6 + i7 + i8;
                _DataSet.Tables.Add(_DataTable0);
                _DataSet.Tables.Add(_DataTable1);
                _DataSet.Tables.Add(_DataTable3);
                _DataSet.Tables.Add(_DataTable4);
                _DataSet.Tables.Add(_DataTable5);
                _DataSet.Tables.Add(_DataTable6);
                _DataSet.Tables.Add(_DataTable7);
                _DataSet.Tables.Add(_DataTable1020);
            }
            //if (_DataTable1.Rows.Count > 0)
            //    {           
            //    _DataSet.Tables.Add(_DataTable1);
            //    }
            //if (_DataTable3.Rows.Count > 0)
            //    {
            //    _DataSet.Tables.Add(_DataTable3);
            //    }
            //if (_DataTable4.Rows.Count > 0)
            //    {
            //    _DataSet.Tables.Add(_DataTable4);
            //    }
            //if (_DataTable5.Rows.Count > 0)
            //    {
            //    _DataSet.Tables.Add(_DataTable5);
            //    }
            //if (_DataTable6.Rows.Count > 0)
            //    {
            //    _DataSet.Tables.Add(_DataTable6);
            //    }
            //if (_DataTable7.Rows.Count > 0)
            //    {
            //    _DataSet.Tables.Add(_DataTable7);
            //    }


            return _DataSet;

        }
    }
}
