﻿
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using Utility;

namespace ASPTraceWebApi
{
    public class SplitterWithSeparator
    {

        
        DateTimeConverter objDateTimeConverter = new DateTimeConverter();
        System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public SplitterWithSeparator(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        public DataTable SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode, DataTable _DataTable)
        {
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0; 

            string relativePath = _configuration["AppSettings:MekKey2Path"];   
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim(); 

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            bool TxnAmountIsDecimal = Convert.ToBoolean(dt.Rows[0]["TxnAmountIsDecimal"]);
            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                    string[] colFields = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                    int Incr = 1;
                    string TerminalID = string.Empty;
                    string AcquirerID = string.Empty;
                    string ReferenceNumber = string.Empty;
                    string CardNumber = string.Empty;
                    string CustAccountNo = string.Empty;
                    string InterchangeAccountNo = string.Empty;
                    string ATMAccountNo = string.Empty;
                    string TxnsDateTime = string.Empty;
                    string TxnsDate = string.Empty;
                    string TxnsTime = string.Empty;
                    string TxnsAmount = "0";
                    string Amount1 = "0";
                    string Amount2 = "0";
                    string Amount3 = "0";
                    string ChannelType = string.Empty;
                    string TxnsSubType = string.Empty;
                    string TxnsNumber = string.Empty;
                    string TxnsPerticulars = string.Empty;
                    string DrCrType = string.Empty;
                    string ResponseCode1 = string.Empty;
                    string ResponseCode2 = string.Empty;
                    string ReversalCode1 = string.Empty;
                    string ReversalCode2 = string.Empty;
                    string TxnsPostDateTime = string.Empty;
                    string TxnsValueDateTime = string.Empty;
                    string AuthCode = string.Empty;
                    string ProcessingCode = string.Empty;
                    string FeeAmount = "0";
                    string CurrencyCode = string.Empty;
                    string CustBalance = "0";
                    string InterchangeBalance = "0";
                    string ATMBalance = "0";
                    string BranchCode = string.Empty;
                    string ReserveField1 = string.Empty;
                    string ReserveField2 = string.Empty;
                    string ReserveField3 = string.Empty;
                    string ReserveField4 = string.Empty;
                    string ReserveField5 = string.Empty;
                    string NoOfDuplicate = string.Empty;
                    decimal AMT;
                    //if(dt.Rows[0][3])

                    if (ds.Tables[0].Rows[0]["TerminalID"].ToString() != "0")
                    {
                        TerminalID = colFields[int.Parse(ds.Tables[0].Rows[0]["TerminalID"].ToString()) - Incr].ToString().Trim();
                    }
                    if (ds.Tables[0].Rows[0]["AcquirerID"].ToString() != "0")
                    {
                        AcquirerID = colFields[int.Parse(ds.Tables[0].Rows[0]["AcquirerID"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ReferenceNumber"].ToString() != "0")
                    {
                        ReferenceNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["ReferenceNumber"].ToString()) - Incr].ToString();
                        if (ReferenceNumber == "302418011245")
                        {

                        }
                        //ReferenceNumber = ReferenceNumber.TrimStart('0');
                    }
                    if (ds.Tables[0].Rows[0]["CardNumber"].ToString() != "0")
                    {
                        CardNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["CardNumber"].ToString()) - Incr].ToString();
                        CardNumber = CardNumber.TrimStart('0');
                    }
                    if (ds.Tables[0].Rows[0]["CustAccountNo"].ToString() != "0")
                    {
                        CustAccountNo = colFields[int.Parse(ds.Tables[0].Rows[0]["CustAccountNo"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["InterchangeAccountNo"].ToString() != "0")
                    {
                        InterchangeAccountNo = colFields[int.Parse(ds.Tables[0].Rows[0]["InterchangeAccountNo"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ATMAccountNo"].ToString() != "0")
                    {
                        ATMAccountNo = colFields[int.Parse(ds.Tables[0].Rows[0]["ATMAccountNo"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["TxnsDateTime"].ToString() != "0")
                    {
                        TxnsDateTime = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsDateTime"].ToString()) - Incr].ToString();
                        //TxnsDateTime = TxnsDateTime.Replace("AM", "").Replace("PM", "").Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TxnsDate"].ToString() != "0")
                    {
                        TxnsDate = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsDate"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["TxnsTime"].ToString() != "0")
                    {
                        TxnsTime = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsTime"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["TxnsAmount"].ToString() != "0")
                    {
                        //if (dt.Rows[0]["Vendor"].ToString() == "6" || Convert.ToInt32(ClientID) == 39 || Convert.ToInt32(ClientID) == 29)
                        //{
                        //    TxnsAmount = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                        //    if (TxnsAmount.Contains('.'))
                        //    {
                        //        TxnsAmount = TxnsAmount.Replace(".", "");
                        //    }
                        //    else
                        //    {
                        //        TxnsAmount = TxnsAmount + "00";
                        //    }
                        //}
                        //else 



                        if (Convert.ToInt32(ClientID) == 33)
                        {
                            TxnsAmount = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                            TxnsAmount = TxnsAmount.Substring(0, TxnsAmount.IndexOf(".") + 3);
                        }
                        else
                        {
                            TxnsAmount = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                            try
                            {
                                if (TxnAmountIsDecimal == true)
                                {
                                    AMT = decimal.Parse(TxnsAmount);
                                    decimal AMT1 = (AMT / 100);
                                    TxnsAmount = Convert.ToString(AMT1);
                                }
                                else
                                {
                                    TxnsAmount = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                                }
                            }
                            catch (Exception)
                            {

                            }
                            //if (Convert.ToInt32(ClientID) == 36 && TxnsAmount != "0")
                            //{
                            //    if (TxnsAmount.Contains("."))
                            //    {

                            //    }
                            //    else
                            //    {
                            //        TxnsAmount = TxnsAmount + "00";
                            //    }
                            //}
                            //TxnsAmount = TxnsAmount.Replace(".", "");
                        }
                    }
                    if (ds.Tables[0].Rows[0]["Amount1"].ToString() != "0")
                    {
                        Amount1 = colFields[int.Parse(ds.Tables[0].Rows[0]["Amount1"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["Amount2"].ToString() != "0")
                    {
                        Amount2 = colFields[int.Parse(ds.Tables[0].Rows[0]["Amount2"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["Amount3"].ToString() != "0")
                    {
                        Amount3 = colFields[int.Parse(ds.Tables[0].Rows[0]["Amount3"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["TxnsSubType"].ToString() != "0")
                    {
                        TxnsSubType = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsSubType"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ChannelType"].ToString() != "0")
                    {
                        ChannelType = colFields[int.Parse(ds.Tables[0].Rows[0]["ChannelType"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["TxnsNumber"].ToString() != "0")
                    {
                        TxnsNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsNumber"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["TxnsPerticulars"].ToString() != "0")
                    {
                        TxnsPerticulars = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsPerticulars"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["DrCrType"].ToString() != "0")
                    {
                        DrCrType = colFields[int.Parse(ds.Tables[0].Rows[0]["DrCrType"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ResponseCode1"].ToString() != "0")
                    {
                        ResponseCode1 = colFields[int.Parse(ds.Tables[0].Rows[0]["ResponseCode1"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ResponseCode2"].ToString() != "0")
                    {
                        ResponseCode2 = colFields[int.Parse(ds.Tables[0].Rows[0]["ResponseCode2"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ReversalCode1"].ToString() != "0")
                    {
                        ReversalCode1 = colFields[int.Parse(ds.Tables[0].Rows[0]["ReversalCode1"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ReversalCode2"].ToString() != "0")
                    {
                        ReversalCode2 = colFields[int.Parse(ds.Tables[0].Rows[0]["ReversalCode2"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["TxnsPostDateTime"].ToString() != "0")
                    {
                        TxnsPostDateTime = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsPostDateTime"].ToString()) - Incr].ToString();
                        TxnsPostDateTime = TxnsPostDateTime.Replace("AM", "").Replace("PM", "").Trim();
                    }
                    if (ds.Tables[0].Rows[0]["TxnsValueDateTime"].ToString() != "0")
                    {
                        TxnsValueDateTime = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsValueDateTime"].ToString()) - Incr].ToString();
                        TxnsValueDateTime = TxnsValueDateTime.Replace("AM", "").Replace("PM", "").Trim();
                    }
                    if (ds.Tables[0].Rows[0]["AuthCode"].ToString() != "0")
                    {
                        AuthCode = colFields[int.Parse(ds.Tables[0].Rows[0]["AuthCode"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ProcessingCode"].ToString() != "0")
                    {
                        ProcessingCode = colFields[int.Parse(ds.Tables[0].Rows[0]["ProcessingCode"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["FeeAmount"].ToString() != "0")
                    {
                        FeeAmount = colFields[int.Parse(ds.Tables[0].Rows[0]["FeeAmount"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["CurrencyCode"].ToString() != "0")
                    {
                        CurrencyCode = colFields[int.Parse(ds.Tables[0].Rows[0]["CurrencyCode"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["CustBalance"].ToString() != "0")
                    {
                        CustBalance = colFields[int.Parse(ds.Tables[0].Rows[0]["CustBalance"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["InterchangeBalance"].ToString() != "0")
                    {
                        InterchangeBalance = colFields[int.Parse(ds.Tables[0].Rows[0]["InterchangeBalance"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ATMBalance"].ToString() != "0")
                    {
                        ATMBalance = colFields[int.Parse(ds.Tables[0].Rows[0]["ATMBalance"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["BranchCode"].ToString() != "0")
                    {
                        BranchCode = colFields[int.Parse(ds.Tables[0].Rows[0]["BranchCode"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ReserveField1"].ToString() != "0")
                    {
                        ReserveField1 = colFields[int.Parse(ds.Tables[0].Rows[0]["ReserveField1"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ReserveField2"].ToString() != "0")
                    {
                        ReserveField2 = colFields[int.Parse(ds.Tables[0].Rows[0]["ReserveField2"].ToString()) - Incr].ToString();
                        if ((dt.Rows[0]["Vendor"].ToString() == "7") && (dt.Rows[0]["ChannelID"].ToString() == "4" || dt.Rows[0]["ChannelID"].ToString() == "7") && (dt.Rows[0]["ClientID"].ToString() != "36"))
                        {
                            string[] splitdata = ReserveField2.Split('/');
                            TxnsDateTime = splitdata[1].Substring(0, splitdata[1].LastIndexOf(':'));
                            InterchangeAccountNo = splitdata[3].ToString();
                            TxnsNumber = splitdata[4].ToString();
                        }

                        if ((dt.Rows[0]["ClientID"].ToString() == "36") && (dt.Rows[0]["ChannelID"].ToString() == "4" || dt.Rows[0]["ChannelID"].ToString() == "7"))
                        {
                            if (ReserveField2.Contains("Reverse") && ChannelType == "UPI")
                            {
                                ReserveField2 = colFields[int.Parse(ds.Tables[0].Rows[0]["ReserveField2"].ToString()) - Incr].ToString();
                                string[] splitdata = ReserveField2.Split('/');
                                ////TxnsDateTime = splitdata[1].Substring(0, splitdata[1].LastIndexOf(':'));
                                if (TxnsDateTime == "")
                                {
                                    TxnsDateTime = splitdata[1].Substring(0, splitdata[1].LastIndexOf(':'));
                                }
                                else
                                {
                                    TxnsDateTime = TxnsDate.ToString();
                                }
                            }
                            else
                            {
                                string[] splitdata = ReserveField2.Split('/');
                                TxnsDateTime = splitdata[1].Substring(0, splitdata[1].LastIndexOf(':'));
                                InterchangeAccountNo = splitdata[3].ToString();
                                TxnsNumber = splitdata[4].ToString();
                            }
                        }



                    }


                    if (ds.Tables[0].Rows[0]["ReserveField3"].ToString() != "0")
                    {
                        ReserveField3 = colFields[int.Parse(ds.Tables[0].Rows[0]["ReserveField3"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ReserveField4"].ToString() != "0")
                    {
                        ReserveField4 = colFields[int.Parse(ds.Tables[0].Rows[0]["ReserveField4"].ToString()) - Incr].ToString();
                    }
                    if (ds.Tables[0].Rows[0]["ReserveField5"].ToString() != "0")
                    {
                        ReserveField5 = colFields[int.Parse(ds.Tables[0].Rows[0]["ReserveField5"].ToString()) - Incr].ToString();
                    }

                    #region StanderedFields
                    string SplitType = ",";
                    int ModeID = 0;
                    int ChannelID = 0;
                    bool ReversalFlag = false;
                    string ResponseCode = string.Empty;
                    string TxnsStatus = string.Empty;
                    string DebitCreditType = string.Empty;
                    string TxnsType = string.Empty;
                    string TxnsSubTypeMain = string.Empty;
                    string TxnsEntryType = string.Empty;
                    string CardType = string.Empty;
                    DateTime? TxnsDateTimeMain;

                    TxnsDateTimeMain = null;
                    DateTime? TxnsPostDateTimeMain;
                    TxnsPostDateTimeMain = null;

                    string[] TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] AcquirerIDArray = dt.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] ReversalCode1Array = dt.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] ReversalCode2Array = dt.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string ReversalType = dt.Rows[0]["ReversalType"].ToString();
                    string[] ATMType = dt.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] CDMType = dt.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] POSType = dt.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] ECOMType = dt.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] IMPType = dt.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] UPIType = dt.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] MicroATMType = dt.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] MobileRechargeType = dt.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] BalanceEnquiry = dt.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] MiniStatement = dt.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] PinChange = dt.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] ChequeBookReq = dt.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string ResponseType = dt.Rows[0]["ResponseType"].ToString();
                    string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] ResponseCode2Array = dt.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] OfflineCode = dt.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] TxnDateTime = dt.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] TxnPostDateTime = dt.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] DebitCode = dt.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] CreditCode = dt.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);

                    bool card = false;
                    bool Terminal = false;
                    bool Acquirer = false;
                    bool Rev1 = false;
                    bool Rev2 = false;
                    bool ATM = false;
                    bool CDM = false;
                    bool POS = false;
                    bool ECOM = false;
                    bool IMPS = false;
                    bool UPI = false;
                    bool MicroATM = false;
                    bool MobileRecharge = false;
                    bool BAL = false;
                    bool MS = false;
                    bool PC = false;
                    bool CB = false;
                    bool RCA1 = false;
                    bool RCA2 = false;
                    bool MC = false;
                    bool VC = false;
                    bool OC = false;
                    bool D = false;
                    bool C = false;

                    #region ValidateField

                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        if (TxnDateTime[0].ToString() != "")
                        {
                            for (int i = 0; i < TxnDateTime.Length; i++)
                            {
                                string TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;
                                if (TxnsDateTimeDiff.Contains("/") || TxnsDateTimeDiff.Contains(".") || TxnsDateTimeDiff.Contains("-"))
                                {
                                    try
                                    {
                                        if ((TxnsDateTimeDiff != "" && TxnsDateTimeDiff.Contains("PM") || TxnsDateTimeDiff.Contains("pm")))
                                        {
                                            TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTimeAMPM(TxnDateTime[i].ToString(), TxnsDateTimeDiff);
                                        }
                                        else
                                        {
                                            TxnsDateTime = TxnsDateTimeDiff.Replace("AM", "").Replace("PM", "").Trim();
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                        }
                                    }
                                    catch (Exception ex)
                                    {

                                        TxnsDateTimeMain = Convert.ToDateTime(TxnsDateTimeDiff);
                                    }
                                }
                                else
                                {
                                    TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTimeDiff);

                                }
                            }
                        }
                    }

                    if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                    {

                        for (int i = 0; i < TxnDateTime.Length; i++)
                        {
                            if (TxnsDateTime.Contains("/") || TxnsDateTime.Contains(".") || TxnsDateTime.Contains("-") || TxnsDateTime.Contains(""))
                            {
                                try
                                {
                                    if ((TxnsDateTime != "" && TxnsDateTime.Contains("PM") || TxnsDateTime.Contains("pm")))
                                    {
                                        TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTimeAMPM(TxnDateTime[i].ToString(), TxnsDateTime);
                                    }
                                    else
                                    {
                                        TxnsDateTime = TxnsDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    TxnsDateTimeMain = Convert.ToDateTime(TxnsDateTime);
                                }

                            }
                            else
                            {
                                TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTime);

                            }
                        }

                    }

                    if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                    {
                        for (int i = 0; i < TxnPostDateTime.Length; i++)
                        {
                            if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                            {
                                TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), CultureInfo.InvariantCulture);
                            }
                            else
                            {
                                TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                            }
                        }
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (int i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                            }
                        }
                    }

                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (int i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (int i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                            {
                                card = true;
                            }
                        }
                    }

                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (int i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                    }

                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (int i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                        for (int i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                            }
                        }
                    }


                    if (ChannelType != "" && TxnsSubType != "" && ClientID == 74 && LogType == "CBS_ATM_ALL")
                    {
                        if (CDMType[0].ToString() != "")
                        {
                            for (int i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                }
                            }
                        }
                    }

                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (int i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                }
                            }
                        }


                        if (ATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType && TerminalID.Substring(0, 2) != MicroATMType[i].ToString())
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (int i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == TxnsSubType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == TxnsSubType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (int i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == TxnsSubType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (int i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == TxnsSubType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType || TerminalID.Substring(0, 2) == MicroATMType[i].ToString())
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (int i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (int i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType && TerminalID.Substring(0, 2) != MicroATMType[i].ToString())
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (int i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == ChannelType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == ChannelType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (int i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == ChannelType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (int i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == ChannelType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType || TerminalID.Substring(0, 2) == MicroATMType[i].ToString())
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (int i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }

                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (int i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (int i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (int i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (int i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode1 != "")
                    {
                        for (int i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode1 != "" || ResponseCode2 != "")
                    {
                        for (int i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                            }
                        }

                        for (int i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode2)
                            {
                                RCA2 = true;
                            }
                        }
                    }

                    if (ResponseCode1Array[0].ToString() == "")
                    {
                        RCA1 = true;
                    }

                    try
                    {
                        if (reNum.Match(CardNumber.Substring(0, 6)).Success)
                        { 

                        }
                    }
                    catch (Exception)
                    {


                    }

                    if (DebitCode[0].ToString() != "")
                    {
                        for (int i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (int i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                            }
                        }
                    }

                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (int i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (int i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    if (AcquirerID == string.Empty || AcquirerID == "" || AcquirerIDArray[0].ToString() == "")
                    {
                        if (Terminal == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Terminal == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Terminal == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }

                    else
                    {
                        if (Acquirer == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Acquirer == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Acquirer == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }

                    if (ChannelType.ToUpper() == "INWARD" || TxnsSubType.ToUpper() == "INWARD" || (C == true && UPI == true))
                    {
                        ModeID = (int)TxnsMode.INWARD;
                    }
                    if (ChannelType.ToUpper() == "OUTWARD" || TxnsSubType.ToUpper() == "OUTWARD" || (D == true && UPI == true))
                    {
                        ModeID = (int)TxnsMode.OUTWARD;
                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (POS)
                    {
                        ChannelID = (int)TxnsChannelID.POS;
                        TxnsSubTypeMain = "Purchase";
                    }

                    if (ECOM)
                    {
                        ChannelID = (int)TxnsChannelID.E_COMMERCE;
                        //TxnsSubTypeMain = "Transfer";
                        TxnsSubTypeMain = "Purchase";
                    }

                    if (IMPS)
                    {
                        ChannelID = (int)TxnsChannelID.IMPS;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (MicroATM)
                    {
                        ChannelID = (int)TxnsChannelID.MICRO_ATM;
                        TxnsSubTypeMain = "Withdrawal";
                    }

                    if (MobileRecharge)
                    {
                        ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (UPI)
                    {
                        ChannelID = (int)TxnsChannelID.UPI;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (RCA1 == true || RCA1 == true && RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }
                    else
                    {
                        ResponseCode = ResponseCode1;
                        TxnsStatus = "Unsucessfull";
                    }

                    if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }

                    if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }

                    if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }

                    if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }

                    if (BAL || MS || PC || CB)
                    {
                        TxnsType = "Non-Financial";
                    }
                    else
                    {
                        TxnsType = "Financial";
                    }

                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    #endregion InitilizedField

                    #endregion StanderedFields

                    string ECardNumber = string.Empty;
                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);;
                    }

                    if (TxnsDateTimeMain != null)
                    {
                        _DataTable.Rows.Add(ClientID
                                        , ChannelID
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , ECardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , InterchangeAccountNo
                                        , ATMAccountNo
                                        , TxnsDateTimeMain
                                        , Decimal.Parse(TxnsAmount, CultureInfo.CurrentCulture)
                                        //, Convert.ToDecimal(TxnsAmount)
                                        , Convert.ToDecimal(Amount1)
                                        , Convert.ToDecimal(Amount2)
                                        , Convert.ToDecimal(Amount3)
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubTypeMain
                                        , TxnsEntryType
                                        , TxnsNumber
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , ReversalFlag
                                        , TxnsPostDateTimeMain
                                        , TxnsPostDateTimeMain
                                        , AuthCode
                                        , ProcessingCode
                                        , Convert.ToDecimal(FeeAmount)
                                        , CurrencyCode
                                        , Convert.ToDecimal(CustBalance)
                                        , Convert.ToDecimal(InterchangeBalance)
                                        , Convert.ToDecimal(ATMBalance)
                                        , BranchCode
                                        , ReserveField1
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , RevEntryLeg
                                        , 0
                                        , FileName
                                        , path
                                        , null
                                        , DateTime.Now
                                        , DateTime.Now
                                        , UserName
                                        , ""
                                        );
                    }

                }
                catch (Exception ex)
                {

                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                }

            }
            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;

        }
    }
}
