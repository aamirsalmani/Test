﻿ 
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using Utility;
using Excel = Microsoft.Office.Interop.Excel;

namespace ASPTraceWebApi
{
    public class SplitterWithSpreadsheet
    {

        
        DateTimeConverter objDateTimeConverter = new DateTimeConverter();
        System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");

        private readonly IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public SplitterWithSpreadsheet(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }
        
        public DataTable SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode, DataTable _DataTable)
        {
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            bool TxnAmountIsDecimal = Convert.ToBoolean(dt.Rows[0]["TxnAmountIsDecimal"]);
            //string[] TotalCountArray = File.ReadAllLines(path);
            //= TotalCountArray.Length;

            DataTable dtexcelsheetname = null;
            try
            { 
                string relativePath = _configuration["AppSettings:MekKey2Path"];
                AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
                AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim(); 

                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                OleDbConnection objConn;
                string extension = Path.GetExtension(path);
                if (ClientID == 37)
                {
                    path = ConvertNPCIExcel(path, path);
                }
                switch (extension.ToLower())
                {

                    case ".xls": //Excel 97-03
                        //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        // connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1\'";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        if (ClientID == 49)
                        {
                            connString = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = " + path + "; Extended Properties =\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        }
                        else
                        {
                            //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        }
                        break;
                }
                //}
                //else
                //{
                //    switch (extension.ToLower())
                //    {

                //        case ".xls": //Excel 97-03
                //            // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                //            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                //            //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                //            break;
                //        case ".xlsx": //Excel 07 or higher
                //            //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                //            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                //            break;

                //    }
                //}

                try
                {
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }
                catch
                {
                    path = ConvertNPCIExcel(path, path);
                    switch (extension.ToLower())
                    {
                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }

                //OleDbConnection objConn = new OleDbConnection(connString);
                //objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                int j = 0;
                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    DataTable dtSheet = new DataTable();
                    excelSheets[j] = row["TABLE_NAME"].ToString();
                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                    try
                    {
                        OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);

                        da.Fill(dtSheet);

                        objConn.Close();
                    }
                    catch (Exception ex)
                    {
                        objConn.Close();
                    }

                    TotalCount = dtSheet.Rows.Count;

                    if (dtSheet.Rows.Count >= 1)
                    {
                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            LineNo++;
                            try
                            {
                                //string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                                //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                                int Incr = 1;
                                string TerminalID = string.Empty;
                                string AcquirerID = string.Empty;
                                string ReferenceNumber = string.Empty;
                                string CardNumber = string.Empty;
                                string CustAccountNo = string.Empty;
                                string InterchangeAccountNo = string.Empty;
                                string ATMAccountNo = string.Empty;
                                string TxnsDateTime = string.Empty;
                                string TxnsDate = string.Empty;
                                string TxnsTime = string.Empty;
                                string TxnsAmount = "0";
                                string Amount1 = "0";
                                string Amount2 = "0";
                                string Amount3 = "0";
                                string ChannelType = string.Empty;
                                string TxnsSubType = string.Empty;
                                string TxnsNumber = string.Empty;
                                string TxnsPerticulars = string.Empty;
                                string DrCrType = string.Empty;
                                string ResponseCode1 = string.Empty;
                                string ResponseCode2 = string.Empty;
                                string ReversalCode1 = string.Empty;
                                string ReversalCode2 = string.Empty;
                                string TxnsPostDateTime = string.Empty;
                                string TxnsValueDateTime = string.Empty;
                                string AuthCode = string.Empty;
                                string ProcessingCode = string.Empty;
                                string FeeAmount = "0";
                                string CurrencyCode = string.Empty;
                                string CustBalance = "0";
                                string InterchangeBalance = "0";
                                string ATMBalance = "0";
                                string BranchCode = string.Empty;
                                string ReserveField1 = string.Empty;
                                string ReserveField2 = string.Empty;
                                string ReserveField3 = string.Empty;
                                string ReserveField4 = string.Empty;
                                string ReserveField5 = string.Empty;
                                string NoOfDuplicate = string.Empty;
                                string ECardNumber = string.Empty;
                                decimal AMT;

                                if (ds.Tables[0].Rows[0]["TerminalID"].ToString() != "0")
                                {
                                    TerminalID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TerminalID"].ToString()) - Incr].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["AcquirerID"].ToString() != "0")
                                {
                                    AcquirerID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AcquirerID"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReferenceNumber"].ToString() != "0")
                                {
                                    ReferenceNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReferenceNumber"].ToString()) - Incr].ToString();
                                    if (ReferenceNumber == "234210008473")
                                    {

                                    }
                                }
                                if (ds.Tables[0].Rows[0]["CardNumber"].ToString() != "0")
                                {
                                    CardNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CardNumber"].ToString()) - Incr].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["CustAccountNo"].ToString() != "0")
                                {
                                    CustAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CustAccountNo"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["InterchangeAccountNo"].ToString() != "0")
                                {
                                    InterchangeAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["InterchangeAccountNo"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ATMAccountNo"].ToString() != "0")
                                {
                                    ATMAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ATMAccountNo"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsDateTime"].ToString() != "0")
                                {
                                    TxnsDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsDateTime"].ToString()) - Incr].ToString();
                                    TxnsDateTime = TxnsDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsDate"].ToString() != "0")
                                {
                                    TxnsDate = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsDate"].ToString()) - Incr].ToString();
                                    string[] Date = TxnsDate.Split(' ');
                                    TxnsDate = Date[0];
                                }
                                if (ds.Tables[0].Rows[0]["TxnsTime"].ToString() != "0")
                                {
                                    if (ClientID == 40)
                                    {
                                        TxnsTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsTime"].ToString()) - Incr].ToString();
                                        if (TxnsTime.Contains("/") && TxnsTime.Contains(" "))
                                        {
                                            string[] strtime = TxnsTime.Split();
                                            TxnsTime = Convert.ToString(strtime[1] + " " + strtime[2]).Trim();
                                        }
                                    }
                                    else
                                    {
                                        TxnsTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsTime"].ToString()) - Incr].ToString();
                                    }
                                    //TxnsTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsTime"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsAmount"].ToString() != "0")
                                {
                                    TxnsAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();

                                    try
                                    {
                                        if (TxnAmountIsDecimal == true)
                                        {
                                            AMT = decimal.Parse(TxnsAmount);
                                            decimal AMT1 = (AMT / 100);
                                            TxnsAmount = Convert.ToString(AMT1);
                                        }
                                        else
                                        {
                                            TxnsAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                                            TxnsAmount = TxnsAmount.Replace(",", "");
                                        }
                                    }
                                    catch (Exception)
                                    {


                                    }

                                    //if (ClientCode == "028" && TxnsAmount != "")
                                    //{
                                    //    if ((TxnsAmount.Length - TxnsAmount.IndexOf(".") - 1) > 2)
                                    //    {
                                    //        TxnsAmount = TxnsAmount.Substring(0, TxnsAmount.IndexOf(".") + 3);
                                    //    }
                                    //}
                                    //if ((ClientCode == "036" && dt.Rows[0]["Vendor"].ToString() == "16" && TxnsAmount != ""))
                                    //{
                                    //    if (TxnsAmount.Contains("."))
                                    //    {

                                    //    }
                                    //    else
                                    //    {
                                    //        TxnsAmount = TxnsAmount + "00";
                                    //    }
                                    //}
                                    //TxnsAmount = TxnsAmount.Replace(".", "");
                                }
                                if (ds.Tables[0].Rows[0]["Amount1"].ToString() != "0")
                                {
                                    Amount1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Amount1"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Amount2"].ToString() != "0")
                                {
                                    Amount2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Amount2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Amount3"].ToString() != "0")
                                {
                                    Amount3 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Amount3"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsSubType"].ToString() != "0")
                                {
                                    TxnsSubType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsSubType"].ToString()) - Incr].ToString();
                                    if (ClientID == 60)
                                    {
                                        TxnsSubType.Trim();
                                        TxnsSubType = TxnsSubType.Replace(" ", "");
                                    }

                                    if (ClientID == 10068)
                                    {
                                        if (TxnsSubType == "IMPS_INWARD")
                                        {
                                            TxnsSubType = "INWARD";
                                            //ChannelType = "IMPS";
                                        }
                                        else
                                        {
                                            TxnsSubType = "OUTWARD";
                                            //ChannelType = "IMPS";
                                        }
                                    }
                                }

                                if (ds.Tables[0].Rows[0]["ChannelType"].ToString() != "0")
                                {
                                    ChannelType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ChannelType"].ToString()) - Incr].ToString();
                                    if (ClientID == 60)
                                    {
                                        ChannelType.Trim();
                                        ChannelType = ChannelType.Replace(" ", "");
                                    }
                                    if (ClientID == 38 && ChannelType == "UPI")
                                    {
                                        if (TxnsSubType == "CREDIT")
                                        {
                                            TxnsSubType = "INWARD";
                                            //ChannelType = "UPI";
                                        }
                                        else if (TxnsSubType == "DEBIT" || TxnsSubType == "REVERSAL")
                                        {
                                            TxnsSubType = "OUTWARD";
                                            //ChannelType = "UPI";
                                        }
                                        else
                                        {
                                            TxnsSubType = "INTRA";
                                            //ChannelType = "UPI";
                                        }
                                    }
                                }
                                if (ds.Tables[0].Rows[0]["TxnsNumber"].ToString() != "0")
                                {
                                    TxnsNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsNumber"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsPerticulars"].ToString() != "0")
                                {
                                    TxnsPerticulars = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsPerticulars"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["DrCrType"].ToString() != "0")
                                {
                                    DrCrType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["DrCrType"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ResponseCode1"].ToString() != "0")
                                {
                                    ResponseCode1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode1"].ToString()) - Incr].ToString();
                                    if (ClientID == 10068)
                                    {
                                        if (ResponseCode1 == "Success")
                                        {
                                            ResponseCode1 = "00";
                                        }
                                    }
                                }
                                if (ds.Tables[0].Rows[0]["ResponseCode2"].ToString() != "0")
                                {
                                    ResponseCode2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReversalCode1"].ToString() != "0")
                                {
                                    ReversalCode1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReversalCode1"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReversalCode2"].ToString() != "0")
                                {
                                    ReversalCode2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReversalCode2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsPostDateTime"].ToString() != "0")
                                {
                                    TxnsPostDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsPostDateTime"].ToString()) - Incr].ToString();
                                    TxnsPostDateTime = TxnsPostDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsValueDateTime"].ToString() != "0")
                                {
                                    TxnsValueDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsValueDateTime"].ToString()) - Incr].ToString();
                                    TxnsValueDateTime = TxnsValueDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                }
                                if (ds.Tables[0].Rows[0]["AuthCode"].ToString() != "0")
                                {
                                    AuthCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AuthCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ProcessingCode"].ToString() != "0")
                                {
                                    ProcessingCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ProcessingCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["FeeAmount"].ToString() != "0")
                                {
                                    FeeAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["FeeAmount"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["CurrencyCode"].ToString() != "0")
                                {
                                    CurrencyCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CurrencyCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["CustBalance"].ToString() != "0")
                                {
                                    CustBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CustBalance"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["InterchangeBalance"].ToString() != "0")
                                {
                                    InterchangeBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["InterchangeBalance"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ATMBalance"].ToString() != "0")
                                {
                                    ATMBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ATMBalance"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["BranchCode"].ToString() != "0")
                                {
                                    BranchCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["BranchCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField1"].ToString() != "0")
                                {
                                    ReserveField1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField1"].ToString()) - Incr].ToString();

                                }
                                if (ds.Tables[0].Rows[0]["ReserveField2"].ToString() != "0")
                                {
                                    ReserveField2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField3"].ToString() != "0")
                                {
                                    ReserveField3 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField3"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField4"].ToString() != "0")
                                {
                                    ReserveField4 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField4"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField5"].ToString() != "0")
                                {
                                    ReserveField5 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField5"].ToString()) - Incr].ToString();
                                }

                                #region StanderedFields
                                string SplitType = ",";
                                int ModeID = 0;
                                int ChannelID = 0;
                                bool ReversalFlag = false;
                                string ResponseCode = string.Empty;
                                string TxnsStatus = string.Empty;
                                string DebitCreditType = string.Empty;
                                string TxnsType = string.Empty;
                                string TxnsSubTypeMain = string.Empty;
                                string TxnsEntryType = string.Empty;
                                string CardType = string.Empty;
                                DateTime? TxnsDateTimeMain;

                                TxnsDateTimeMain = null;
                                DateTime? TxnsPostDateTimeMain;
                                TxnsPostDateTimeMain = null;

                                string[] TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] AcquirerIDArray = dt.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ReversalCode1Array = dt.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ReversalCode2Array = dt.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string ReversalType = dt.Rows[0]["ReversalType"].ToString();
                                string[] ATMType = dt.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] CDMType = dt.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] POSType = dt.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ECOMType = dt.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] IMPType = dt.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] UPIType = dt.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] MicroATMType = dt.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] MobileRechargeType = dt.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] BalanceEnquiry = dt.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] MiniStatement = dt.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] PinChange = dt.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ChequeBookReq = dt.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string ResponseType = dt.Rows[0]["ResponseType"].ToString();
                                string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ResponseCode2Array = dt.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] OfflineCode = dt.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] TxnDateTime = dt.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] TxnPostDateTime = dt.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] DebitCode = dt.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] CreditCode = dt.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);

                                bool card = false;
                                bool Terminal = false;
                                bool Acquirer = false;
                                bool Rev1 = false;
                                bool Rev2 = false;
                                bool ATM = false;
                                bool CDM = false;
                                bool POS = false;
                                bool ECOM = false;
                                bool IMPS = false;
                                bool UPI = false;
                                bool MicroATM = false;
                                bool MobileRecharge = false;
                                bool BAL = false;
                                bool MS = false;
                                bool PC = false;
                                bool CB = false;
                                bool RCA1 = false;
                                bool RCA2 = false;
                                bool MC = false;
                                bool VC = false;
                                bool OC = false;
                                bool D = false;
                                bool C = false;

                                #region ValidateField
                                if (TxnsDate != "" && TxnsTime != "")
                                {

                                    if (TxnDateTime[0].ToString() != "")
                                    {
                                        for (int i = 0; i < TxnDateTime.Length; i++)
                                        {
                                            string TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;
                                            if (TxnsDateTimeDiff.Contains("/") || TxnsDateTimeDiff.Contains(".") || TxnsDateTimeDiff.Contains("-"))
                                            {
                                                //TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                                TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTimeDiff);
                                            }
                                            else
                                            {
                                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTime[i].ToString(), null);
                                            }

                                        }
                                    }
                                }

                                if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                                {

                                    for (int i = 0; i < TxnDateTime.Length; i++)
                                    {
                                        if (TxnsDateTime.Contains("/") || TxnsDateTime.Contains(".") || TxnsDateTime.Contains("-"))
                                        {
                                            TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTime);
                                        }
                                        else
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[i].ToString(), null);
                                        }
                                    }
                                }

                                if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                                {
                                    for (int i = 0; i < TxnPostDateTime.Length; i++)
                                    {
                                        if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                                        {
                                            TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                                        }
                                        else
                                        {
                                            TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), null);
                                        }
                                    }
                                }

                                if (TerminalCode[0].ToString() != "" && TerminalID != "")
                                {
                                    for (int i = 0; i < TerminalCode.Length; i++)
                                    {
                                        if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                                        {
                                            Terminal = true;
                                        }
                                    }
                                }

                                if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                                {
                                    for (int i = 0; i < AcquirerIDArray.Length; i++)
                                    {
                                        if (AcquirerIDArray[i].ToString() == AcquirerID)
                                        {
                                            Acquirer = true;
                                        }
                                    }
                                }

                                if (BIN_No[0].ToString() != "" && CardNumber != "" && CardNumber != "IMPS")
                                {
                                    for (int i = 0; i < BIN_No.Length; i++)
                                    {
                                        if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                                        {
                                            card = true;
                                        }
                                    }
                                }

                                if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                                {
                                    for (int i = 0; i < ReversalCode1Array.Length; i++)
                                    {
                                        if (ReversalCode1Array[i].ToString() == ReversalCode1)
                                        {
                                            Rev1 = true;
                                        }
                                    }
                                }

                                if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                                {
                                    for (int i = 0; i < ReversalCode1Array.Length; i++)
                                    {
                                        if (ReversalCode1Array[i].ToString() == ReversalCode1)
                                        {
                                            Rev1 = true;
                                        }
                                    }
                                    for (int i = 0; i < ReversalCode2Array.Length; i++)
                                    {
                                        if (ReversalCode2Array[i].ToString() == ReversalCode2)
                                        {
                                            Rev2 = true;
                                        }
                                    }
                                }

                                if (ChannelType == "" && TxnsSubType != "")
                                {

                                    if (CDMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < CDMType.Length; i++)
                                        {
                                            if (CDMType[i].ToString() == TxnsSubType)
                                            {
                                                CDM = true;
                                            }
                                        }
                                    }

                                    if (ATMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < ATMType.Length; i++)
                                        {
                                            if (ATMType[i].ToString() == TxnsSubType && TerminalID.Substring(0, 2) != MicroATMType[i].ToString())
                                            {
                                                ATM = true;
                                            }
                                        }
                                    }

                                    if (POSType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < POSType.Length; i++)
                                        {
                                            if (POSType[i].ToString() == TxnsSubType)
                                            {
                                                POS = true;
                                            }
                                        }
                                    }
                                    if (ECOMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < ECOMType.Length; i++)
                                        {
                                            if (ECOMType[i].ToString() == TxnsSubType)
                                            {
                                                ECOM = true;
                                            }
                                        }
                                    }

                                    if (IMPType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < IMPType.Length; i++)
                                        {
                                            if (IMPType[i].ToString() == TxnsSubType)
                                            {
                                                IMPS = true;
                                            }
                                        }
                                    }

                                    if (UPIType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < UPIType.Length; i++)
                                        {
                                            if (UPIType[i].ToString() == TxnsSubType)
                                            {
                                                UPI = true;
                                            }
                                        }
                                    }

                                    if (MicroATMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < MicroATMType.Length; i++)
                                        {
                                            if (MicroATMType[i].ToString() == TxnsSubType || TerminalID.Substring(0, 2) == MicroATMType[i].ToString())
                                            {
                                                MicroATM = true;
                                            }
                                        }
                                    }

                                    if (MobileRechargeType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < MobileRechargeType.Length; i++)
                                        {
                                            if (MobileRechargeType[i].ToString() == TxnsSubType)
                                            {
                                                MobileRecharge = true;
                                            }
                                        }
                                    }
                                }
                                else
                                {

                                    if (CDMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < CDMType.Length; i++)
                                        {
                                            if (CDMType[i].ToString() == ChannelType || CDMType[i].ToString() == TxnsSubType)
                                            {
                                                CDM = true;
                                            }
                                        }
                                    }

                                    if (ClientID != 38 && ClientID != 49)
                                    {
                                        if (ATMType[0].ToString() != "")
                                        {
                                            for (int i = 0; i < ATMType.Length; i++)
                                            {
                                                if (ATMType[i].ToString() == ChannelType && TerminalID.Substring(0, 2) != MicroATMType[i].ToString())
                                                {
                                                    ATM = true;
                                                }
                                            }
                                        }
                                        //if (ClientID == 60)
                                        //{
                                        //    if (ChannelType == "ATM")
                                        //    {
                                        //        ATM = true;
                                        //    }
                                        //}
                                    }
                                    else
                                    {
                                        if (ATMType[0].ToString() != "")
                                        {
                                            for (int i = 0; i < ATMType.Length; i++)
                                            {
                                                if (ATMType[i].ToString() == ChannelType && TerminalID.Substring(0, 2) != MicroATMType[i].ToString() && TxnsSubType != "POS" && TxnsSubType != "E-COMMERCE" && TxnsSubType != "ECOM")
                                                {
                                                    ATM = true;
                                                }
                                            }
                                            for (int i = 0; i < ATMType.Length; i++)
                                            {
                                                if (ATMType[i].ToString() == ChannelType && TerminalID.Substring(0, 2) != MicroATMType[i].ToString() && TxnsSubType == "POS")
                                                {
                                                    POS = true;
                                                }
                                            }
                                            for (int i = 0; i < ATMType.Length; i++)
                                            {
                                                if (ATMType[i].ToString() == ChannelType && TerminalID.Substring(0, 2) != MicroATMType[i].ToString() && (TxnsSubType == "E-COMMERCE" || TxnsSubType == "ECOM"))
                                                {
                                                    ECOM = true;
                                                }
                                            }
                                        }
                                    }

                                    //if (ClientID == 60)
                                    //{
                                    //    if (ATMType[0].ToString() != "")
                                    //    {
                                    //        for (int i = 0; i < ATMType.Length; i++)
                                    //        {
                                    //            if (ATMType[i].ToString() == ChannelType)
                                    //            {
                                    //                ATM = true;
                                    //            }
                                    //        }
                                    //    }
                                    //}

                                    if (POSType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < POSType.Length; i++)
                                        {
                                            if (POSType[i].ToString() == ChannelType)
                                            {
                                                POS = true;
                                            }
                                        }
                                    }
                                    if (ECOMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < ECOMType.Length; i++)
                                        {
                                            if (ECOMType[i].ToString() == ChannelType)
                                            {
                                                ECOM = true;
                                            }
                                        }
                                    }

                                    if (IMPType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < IMPType.Length; i++)
                                        {
                                            if (IMPType[i].ToString() == ChannelType)
                                            {
                                                IMPS = true;
                                            }
                                        }
                                    }

                                    if (UPIType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < UPIType.Length; i++)
                                        {
                                            if (UPIType[i].ToString() == ChannelType)
                                            {
                                                UPI = true;
                                            }
                                        }
                                    }

                                    if (MicroATMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < MicroATMType.Length; i++)
                                        {
                                            if (MicroATMType[i].ToString() == ChannelType || TerminalID.Substring(0, 2) == MicroATMType[i].ToString())
                                            {
                                                MicroATM = true;
                                            }
                                        }
                                    }

                                    if (MobileRechargeType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < MobileRechargeType.Length; i++)
                                        {
                                            if (MobileRechargeType[i].ToString() == ChannelType)
                                            {
                                                MobileRecharge = true;
                                            }
                                        }
                                    }
                                }

                                if (BalanceEnquiry[0].ToString() != "")
                                {
                                    for (int i = 0; i < BalanceEnquiry.Length; i++)
                                    {
                                        if (BalanceEnquiry[i].ToString() == TxnsSubType)
                                        {
                                            BAL = true;
                                        }
                                    }
                                }

                                if (MiniStatement[0].ToString() != "")
                                {
                                    for (int i = 0; i < MiniStatement.Length; i++)
                                    {
                                        if (MiniStatement[i].ToString() == TxnsSubType)
                                        {
                                            MS = true;
                                        }
                                    }
                                }

                                if (PinChange[0].ToString() != "")
                                {
                                    for (int i = 0; i < PinChange.Length; i++)
                                    {
                                        if (PinChange[i].ToString() == TxnsSubType)
                                        {
                                            PC = true;
                                        }
                                    }
                                }

                                if (ChequeBookReq[0].ToString() != "")
                                {
                                    for (int i = 0; i < ChequeBookReq.Length; i++)
                                    {
                                        if (ChequeBookReq[i].ToString() == TxnsSubType)
                                        {
                                            CB = true;
                                        }
                                    }
                                }

                                if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode1 != "")
                                {
                                    for (int i = 0; i < ResponseCode1Array.Length; i++)
                                    {
                                        if (ResponseCode1Array[i].ToString() == ResponseCode1)
                                        {
                                            RCA1 = true;
                                        }
                                    }
                                }
                                if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode1 != "" || ResponseCode2 != "")
                                {
                                    for (int i = 0; i < ResponseCode1Array.Length; i++)
                                    {
                                        if (ResponseCode1Array[i].ToString() == ResponseCode1)
                                        {
                                            RCA1 = true;
                                        }
                                    }

                                    for (int i = 0; i < ResponseCode2Array.Length; i++)
                                    {
                                        if (ResponseCode2Array[i].ToString() == ResponseCode2)
                                        {
                                            RCA2 = true;
                                        }
                                    }
                                }

                                if (ResponseCode1Array[0].ToString() == "")
                                {
                                    RCA1 = true;
                                }

                                if (CardNumber != "" && CardNumber != "IMPS")
                                {
                                    if (reNum.Match(CardNumber.Substring(0, 6)).Success)
                                    {
                                         
                                    }
                                }
                                if (DebitCode[0].ToString() != "")
                                {
                                    for (int i = 0; i < DebitCode.Length; i++)
                                    {
                                        if (DebitCode[i].ToString() == DrCrType)
                                        {
                                            D = true;
                                        }
                                    }
                                }

                                if (CreditCode[0].ToString() != "")
                                {
                                    for (int i = 0; i < CreditCode.Length; i++)
                                    {
                                        if (CreditCode[i].ToString() == DrCrType)
                                        {
                                            C = true;
                                        }
                                    }
                                }

                                /*
                                if (VISACode[0].ToString() != "" && CardNumber != "")
                                    {
                                    for (int i = 0; i < VISACode.Length; i++)
                                        {
                                        if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                            {
                                            CardType = "VISA";
                                            }
                                        }
                                    }

                                if (MasterCode[0].ToString() != "" && CardNumber != "")
                                    {
                                    for (int i = 0; i < MasterCode.Length; i++)
                                        {
                                        if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                            {
                                            CardType = "MASTER";
                                            }
                                        }
                                    }

                                    */

                                #endregion ValidateField

                                #region InitilizedField

                                if (AcquirerID == string.Empty || AcquirerID == "" || AcquirerIDArray[0].ToString() == "")
                                {
                                    if (Terminal == true && card == true)
                                    {
                                        ModeID = (int)TxnsMode.ONUS;
                                    }
                                    if (Terminal == true && card == false)
                                    {
                                        ModeID = (int)TxnsMode.ACQUIRER;
                                    }
                                    if (Terminal == false && card == true)
                                    {
                                        ModeID = (int)TxnsMode.ISSUER;
                                    }
                                }
                                else
                                {
                                    if (Acquirer == true && card == true)
                                    {
                                        ModeID = (int)TxnsMode.ONUS;
                                    }
                                    if (Acquirer == true && card == false)
                                    {
                                        ModeID = (int)TxnsMode.ACQUIRER;
                                    }
                                    if (Acquirer == false && card == true)
                                    {
                                        ModeID = (int)TxnsMode.ISSUER;
                                    }
                                }
                                if (ClientID == 60 || ClientID == 64)
                                {
                                    if (TxnsSubType.ToUpper() == "ISSUER" || TxnsSubType.ToUpper() == "POS" || TxnsSubType.ToUpper() == "ECOM")
                                    {
                                        ModeID = (int)TxnsMode.ISSUER;
                                    }
                                    if (TxnsSubType.ToUpper() == "ACQUIRER")
                                    {
                                        ModeID = (int)TxnsMode.ACQUIRER;
                                    }
                                    if (TxnsSubType.ToUpper() == "ONUS")
                                    {
                                        ModeID = (int)TxnsMode.ONUS;
                                    }
                                }

                                if (ChannelType.ToUpper() == "INWARD" || TxnsSubType.ToUpper() == "INWARD")
                                {
                                    ModeID = (int)TxnsMode.INWARD;
                                }
                                if (ChannelType.ToUpper() == "OUTWARD" || TxnsSubType.ToUpper() == "OUTWARD")
                                {
                                    ModeID = (int)TxnsMode.OUTWARD;
                                }
                                if (ChannelType.ToUpper() == "INTRA" || TxnsSubType.ToUpper() == "INTRA" || TxnsSubType.ToUpper() == "LISTACCOUNT")
                                {
                                    ModeID = (int)TxnsMode.INTRA;
                                }

                                if (Rev1 == true || Rev1 == true && Rev2 == true)
                                {
                                    ReversalFlag = true;
                                }
                                else
                                {
                                    ReversalFlag = false;
                                }

                                if (ATM)
                                {
                                    TxnsSubTypeMain = "Withdrawal";
                                    ChannelID = (int)TxnsChannelID.ATM;
                                }

                                if (CDM)
                                {
                                    TxnsSubTypeMain = "Deposit";
                                    ChannelID = (int)TxnsChannelID.ATM;
                                }

                                if (POS)
                                {
                                    ChannelID = (int)TxnsChannelID.POS;
                                    TxnsSubTypeMain = "Purchase";
                                }

                                if (ECOM)
                                {
                                    ChannelID = (int)TxnsChannelID.E_COMMERCE;
                                    TxnsSubTypeMain = "Purchase";
                                }

                                if (IMPS)
                                {
                                    ChannelID = (int)TxnsChannelID.IMPS;
                                    TxnsSubTypeMain = "Transfer";
                                }

                                if (MicroATM)
                                {
                                    ChannelID = (int)TxnsChannelID.MICRO_ATM;
                                    TxnsSubTypeMain = "Withdrawal";
                                }

                                if (MobileRecharge)
                                {
                                    ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                                    TxnsSubTypeMain = "Transfer";
                                }

                                if (UPI)
                                {
                                    ChannelID = (int)TxnsChannelID.UPI;
                                    TxnsSubTypeMain = "Transfer";
                                }

                                if (RCA1 == true || RCA1 == true && RCA2 == true)
                                {
                                    ResponseCode = "00";
                                    TxnsStatus = "Sucessfull";
                                }
                                else
                                {
                                    ResponseCode = ResponseCode1;
                                    TxnsStatus = "Unsucessfull";
                                }

                                if (BAL)
                                {
                                    TxnsSubTypeMain = "Balance enquiry";
                                }

                                if (MS)
                                {
                                    TxnsSubTypeMain = "Mini statement";
                                }

                                if (PC)
                                {
                                    TxnsSubTypeMain = "Pin change";
                                }

                                if (CB)
                                {
                                    TxnsSubTypeMain = "Cheque book request";
                                }


                                if (BAL || MS || PC || CB)
                                {
                                    TxnsType = "Non-Financial";
                                }
                                else
                                {
                                    TxnsType = "Financial";
                                }
                                if (OC)
                                {
                                    TxnsEntryType = "Manual";
                                }
                                else
                                {
                                    TxnsEntryType = "Auto";
                                }
                                if (D)
                                {
                                    DebitCreditType = "D";
                                }

                                if (C)
                                {
                                    DebitCreditType = "C";
                                }

                                #endregion InitilizedField

                                #endregion StanderedFields

                                if (CardNumber != "" && CardNumber != "IMPS")
                                {
                                    ECardNumber = AesEncryption.EncryptString(CardNumber);
                                }

                                if (CardNumber != "")
                                {
                                    string dummy = "XXXXXXXXXX";
                                    CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                                }

                                if (TxnsDateTimeMain != null)
                                {
                                    _DataTable.Rows.Add(ClientID
                                                    , ChannelID
                                                    , ModeID
                                                    , TerminalID
                                                    , ReferenceNumber
                                                    , CardNumber.Trim()
                                                    , CardType
                                                    , CustAccountNo
                                                    , InterchangeAccountNo
                                                    , ATMAccountNo
                                                    , TxnsDateTimeMain
                                                    , Convert.ToDecimal(TxnsAmount)
                                                    , Convert.ToDecimal(Amount1)
                                                    , Convert.ToDecimal(Amount2)
                                                    , Convert.ToDecimal(Amount3)
                                                    , TxnsStatus
                                                    , TxnsType
                                                    , TxnsSubTypeMain
                                                    , TxnsEntryType
                                                    , TxnsNumber
                                                    , TxnsPerticulars
                                                    , DebitCreditType
                                                    , ResponseCode
                                                    , ReversalFlag
                                                    , TxnsPostDateTimeMain
                                                    , TxnsPostDateTimeMain
                                                    , AuthCode
                                                    , ProcessingCode
                                                    , Convert.ToDecimal(FeeAmount)
                                                    , CurrencyCode
                                                    , Convert.ToDecimal(CustBalance)
                                                    , Convert.ToDecimal(InterchangeBalance)
                                                    , Convert.ToDecimal(ATMBalance)
                                                    , BranchCode
                                                    , ReserveField1
                                                    , ReserveField2
                                                    , ReserveField3
                                                    , ReserveField4
                                                    , ReserveField5
                                                    , RevEntryLeg
                                                    , 0
                                                    , FileName
                                                    , path
                                                    , null
                                                    , DateTime.Now
                                                    , DateTime.Now
                                                    , UserName
                                                    , ""
                                                    , ECardNumber.Trim()
                                                    );
                                }
                                j++;
                            }
                            catch (Exception ex)
                            {
                                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                            }
                        }
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
            }
            return _DataTable;
        }

        public DataTable SplitData1(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode, DataTable _DataTable)
        {
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;

            try
            {
                 //ConfigurationSettings.AppSettings["EMekKey1"].ToString();
                string relativePath = _configuration["AppSettings:MekKey2Path"];  
                AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
                AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
                
                

                DataSet ds = new DataSet();

                string LogType = dt.Rows[0]["FileName"].ToString();
                string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
                string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

                //string[] TotalCountArray = File.ReadAllLines(path);
                //= TotalCountArray.Length;

                DataTable dtexcelsheetname = new DataTable();
                DataTable dtSheet = new DataTable();
                //Read the connection string for the Excel file.
                string conString = this._configuration.GetConnectionString("ExcelConString");

                conString = string.Format(conString, path);


                try
                {

                    using (OleDbConnection connExcel = new OleDbConnection(conString))
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            connExcel.Open();
                            //Get the name of First Sheet. 
                            dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            connExcel.Close();
                        }
                    }

                    if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                    {
                        string[] excelSheets = new string[dtexcelsheetname.Rows.Count];
                        int j = 0;
                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            excelSheets[j] = row["TABLE_NAME"].ToString();

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = "SELECT * From [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            TotalCount = dtSheet.Rows.Count;

                            if (dtSheet.Rows.Count > 1)
                            {
                                for (int k = 0; k < dtSheet.Rows.Count; k++)
                                {
                                    LineNo++;
                                    try
                                    {
                                        //string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                                        //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                                        int Incr = 1;
                                        string TerminalID = string.Empty;
                                        string AcquirerID = string.Empty;
                                        string ReferenceNumber = string.Empty;
                                        string CardNumber = string.Empty;
                                        string CustAccountNo = string.Empty;
                                        string InterchangeAccountNo = string.Empty;
                                        string ATMAccountNo = string.Empty;
                                        string TxnsDateTime = string.Empty;
                                        string TxnsDate = string.Empty;
                                        string TxnsTime = string.Empty;
                                        string TxnsAmount = "0";
                                        string Amount1 = "0";
                                        string Amount2 = "0";
                                        string Amount3 = "0";
                                        string ChannelType = string.Empty;
                                        string TxnsSubType = string.Empty;
                                        string TxnsNumber = string.Empty;
                                        string TxnsPerticulars = string.Empty;
                                        string DrCrType = string.Empty;
                                        string ResponseCode1 = string.Empty;
                                        string ResponseCode2 = string.Empty;
                                        string ReversalCode1 = string.Empty;
                                        string ReversalCode2 = string.Empty;
                                        string TxnsPostDateTime = string.Empty;
                                        string TxnsValueDateTime = string.Empty;
                                        string AuthCode = string.Empty;
                                        string ProcessingCode = string.Empty;
                                        string FeeAmount = "0";
                                        string CurrencyCode = string.Empty;
                                        string CustBalance = "0";
                                        string InterchangeBalance = "0";
                                        string ATMBalance = "0";
                                        string BranchCode = string.Empty;
                                        string ReserveField1 = string.Empty;
                                        string ReserveField2 = string.Empty;
                                        string ReserveField3 = string.Empty;
                                        string ReserveField4 = string.Empty;
                                        string ReserveField5 = string.Empty;
                                        string NoOfDuplicate = string.Empty;
                                        string ECardNumber = string.Empty;

                                        if (ds.Tables[0].Rows[0]["TerminalID"].ToString() != "0")
                                        {
                                            TerminalID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TerminalID"].ToString()) - Incr].ToString();

                                        }
                                        if (ds.Tables[0].Rows[0]["AcquirerID"].ToString() != "0")
                                        {
                                            AcquirerID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AcquirerID"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ReferenceNumber"].ToString() != "0")
                                        {
                                            ReferenceNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReferenceNumber"].ToString()) - Incr].ToString();
                                            if (ReferenceNumber == "229252664788")
                                            {

                                            }
                                        }
                                        if (ds.Tables[0].Rows[0]["CardNumber"].ToString() != "0")
                                        {
                                            CardNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CardNumber"].ToString()) - Incr].ToString().Trim();
                                        }
                                        if (ds.Tables[0].Rows[0]["CustAccountNo"].ToString() != "0")
                                        {
                                            CustAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CustAccountNo"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["InterchangeAccountNo"].ToString() != "0")
                                        {
                                            InterchangeAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["InterchangeAccountNo"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ATMAccountNo"].ToString() != "0")
                                        {
                                            ATMAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ATMAccountNo"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["TxnsDateTime"].ToString() != "0")
                                        {
                                            TxnsDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsDateTime"].ToString()) - Incr].ToString();

                                            //TxnsDateTime = TxnsDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                        }
                                        if (ds.Tables[0].Rows[0]["TxnsDate"].ToString() != "0")
                                        {
                                            TxnsDate = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsDate"].ToString()) - Incr].ToString();

                                        }
                                        if (ds.Tables[0].Rows[0]["TxnsTime"].ToString() != "0")
                                        {
                                            TxnsTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsTime"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["TxnsAmount"].ToString() != "0")
                                        {
                                            TxnsAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                                            //if(ClientID == 10068)
                                            //{
                                            //    if (TxnsAmount.Length > 2)
                                            //    {
                                            //        TxnsAmount = TxnsAmount.Remove(TxnsAmount.Length-2);
                                            //    }
                                            //    else
                                            //    {
                                            //        TxnsAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                                            //    }


                                            //}
                                            //else 
                                            //{
                                            //    TxnsAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                                            //}
                                        }
                                        if (ds.Tables[0].Rows[0]["Amount1"].ToString() != "0")
                                        {
                                            Amount1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Amount1"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["Amount2"].ToString() != "0")
                                        {
                                            Amount2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Amount2"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["Amount3"].ToString() != "0")
                                        {
                                            Amount3 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Amount3"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["TxnsSubType"].ToString() != "0")
                                        {
                                            TxnsSubType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsSubType"].ToString()) - Incr].ToString();
                                            if (ClientID == 10068)
                                            {
                                                if (TxnsSubType == "ACQ" || TxnsSubType == "ONUS")
                                                {
                                                    String amt = TxnsAmount;
                                                    TxnsAmount = amt;
                                                }
                                                else
                                                {
                                                    decimal AMT = decimal.Parse(TxnsAmount);
                                                    decimal AMT1 = (AMT / 100);
                                                    TxnsAmount = Convert.ToString(AMT1);
                                                }
                                            }
                                        }
                                        if (ds.Tables[0].Rows[0]["ChannelType"].ToString() != "0")
                                        {
                                            ChannelType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ChannelType"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["TxnsNumber"].ToString() != "0")
                                        {
                                            TxnsNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsNumber"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["TxnsPerticulars"].ToString() != "0")
                                        {
                                            TxnsPerticulars = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsPerticulars"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["DrCrType"].ToString() != "0")
                                        {
                                            DrCrType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["DrCrType"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ResponseCode1"].ToString() != "0")
                                        {
                                            ResponseCode1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode1"].ToString()) - Incr].ToString();
                                            if (ClientID == 10068)
                                            {
                                                if (TxnsSubType == "ACQ" && ResponseCode1 == "0 ")
                                                {
                                                    ResponseCode1 = "00";
                                                }
                                                else
                                                {
                                                    ResponseCode1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode1"].ToString()) - Incr].ToString();
                                                }
                                            }
                                        }
                                        if (ds.Tables[0].Rows[0]["ResponseCode2"].ToString() != "0")
                                        {
                                            ResponseCode2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode2"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ReversalCode1"].ToString() != "0")
                                        {
                                            ReversalCode1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReversalCode1"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ReversalCode2"].ToString() != "0")
                                        {
                                            ReversalCode2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReversalCode2"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["TxnsPostDateTime"].ToString() != "0")
                                        {
                                            TxnsPostDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsPostDateTime"].ToString()) - Incr].ToString();
                                            TxnsPostDateTime = TxnsPostDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                        }
                                        if (ds.Tables[0].Rows[0]["TxnsValueDateTime"].ToString() != "0")
                                        {
                                            TxnsValueDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsValueDateTime"].ToString()) - Incr].ToString();
                                            TxnsValueDateTime = TxnsValueDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                        }
                                        if (ds.Tables[0].Rows[0]["AuthCode"].ToString() != "0")
                                        {
                                            AuthCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AuthCode"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ProcessingCode"].ToString() != "0")
                                        {
                                            ProcessingCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ProcessingCode"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["FeeAmount"].ToString() != "0")
                                        {
                                            FeeAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["FeeAmount"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["CurrencyCode"].ToString() != "0")
                                        {
                                            CurrencyCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CurrencyCode"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["CustBalance"].ToString() != "0")
                                        {
                                            CustBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CustBalance"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["InterchangeBalance"].ToString() != "0")
                                        {
                                            InterchangeBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["InterchangeBalance"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ATMBalance"].ToString() != "0")
                                        {
                                            ATMBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ATMBalance"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["BranchCode"].ToString() != "0")
                                        {
                                            BranchCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["BranchCode"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ReserveField1"].ToString() != "0")
                                        {
                                            ReserveField1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField1"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ReserveField2"].ToString() != "0")
                                        {
                                            ReserveField2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField2"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ReserveField3"].ToString() != "0")
                                        {
                                            ReserveField3 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField3"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ReserveField4"].ToString() != "0")
                                        {
                                            ReserveField4 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField4"].ToString()) - Incr].ToString();
                                        }
                                        if (ds.Tables[0].Rows[0]["ReserveField5"].ToString() != "0")
                                        {
                                            ReserveField5 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField5"].ToString()) - Incr].ToString();
                                        }

                                        #region StanderedFields
                                        string SplitType = ",";
                                        int ModeID = 0;
                                        int ChannelID = 0;
                                        bool ReversalFlag = false;
                                        string ResponseCode = string.Empty;
                                        string TxnsStatus = string.Empty;
                                        string DebitCreditType = string.Empty;
                                        string TxnsType = string.Empty;
                                        string TxnsSubTypeMain = string.Empty;
                                        string TxnsEntryType = string.Empty;
                                        string CardType = string.Empty;
                                        DateTime? TxnsDateTimeMain;

                                        TxnsDateTimeMain = null;
                                        DateTime? TxnsPostDateTimeMain;
                                        TxnsPostDateTimeMain = null;

                                        string[] TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] AcquirerIDArray = dt.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] ReversalCode1Array = dt.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] ReversalCode2Array = dt.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string ReversalType = dt.Rows[0]["ReversalType"].ToString();
                                        string[] ATMType = dt.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] CDMType = dt.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] POSType = dt.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] ECOMType = dt.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] IMPType = dt.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] UPIType = dt.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] MicroATMType = dt.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] MobileRechargeType = dt.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] BalanceEnquiry = dt.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] MiniStatement = dt.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] PinChange = dt.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] ChequeBookReq = dt.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string ResponseType = dt.Rows[0]["ResponseType"].ToString();
                                        string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] ResponseCode2Array = dt.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] OfflineCode = dt.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] TxnDateTime = dt.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] TxnPostDateTime = dt.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] DebitCode = dt.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                        string[] CreditCode = dt.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);


                                        bool card = false;
                                        bool Terminal = false;
                                        bool Acquirer = false;
                                        bool Rev1 = false;
                                        bool Rev2 = false;
                                        bool ATM = false;
                                        bool CDM = false;
                                        bool POS = false;
                                        bool ECOM = false;
                                        bool IMPS = false;
                                        bool UPI = false;
                                        bool MicroATM = false;
                                        bool MobileRecharge = false;
                                        bool BAL = false;
                                        bool MS = false;
                                        bool PC = false;
                                        bool CB = false;
                                        bool RCA1 = false;
                                        bool RCA2 = false;
                                        bool MC = false;
                                        bool VC = false;
                                        bool OC = false;
                                        bool D = false;
                                        bool C = false;

                                        #region ValidateField
                                        if (TxnsDate != "" && TxnsTime != "")
                                        {

                                            if (TxnDateTime[0].ToString() != "")
                                            {
                                                for (int i = 0; i < TxnDateTime.Length; i++)
                                                {
                                                    string TxnsDateTimeDiff;
                                                    if (ClientID == 10068)
                                                    {
                                                        TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;
                                                    }
                                                    else
                                                    {
                                                        TxnsDateTimeDiff = TxnsDate + TxnsTime;
                                                    }

                                                    if (TxnsDateTimeDiff.Contains("/") || TxnsDateTimeDiff.Contains(".") || TxnsDateTimeDiff.Contains("-"))
                                                    {
                                                        try
                                                        {
                                                            if (TxnsDateTimeDiff != "" && TxnsDateTimeDiff.Contains("PM") || TxnsDateTimeDiff.Contains("pm"))
                                                            {
                                                                TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTimeAMPM(TxnDateTime[i].ToString(), TxnsDateTimeDiff);
                                                            }
                                                            else
                                                            {
                                                                TxnsDateTime = TxnsDateTimeDiff.Replace("AM", "").Replace("PM", "").Trim();
                                                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                                                if (ClientID == 10068)
                                                                {
                                                                    TxnsDateTime = TxnsDateTimeMain.ToString();
                                                                }

                                                            }
                                                        }
                                                        catch (Exception ex)
                                                        {

                                                            TxnsDateTimeMain = Convert.ToDateTime(TxnsDateTimeDiff);

                                                        }
                                                        //TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTimeDiff);
                                                    }
                                                    else
                                                    {
                                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                                    }
                                                }
                                            }
                                        }

                                        if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                                        {

                                            for (int i = 0; i < TxnDateTime.Length; i++)
                                            {
                                                if (TxnsDateTime.Contains("/") || TxnsDateTime.Contains(".") || TxnsDateTime.Contains("-"))
                                                {
                                                    try
                                                    {

                                                        if (TxnsDateTime != "" && TxnsDateTime.Contains("PM") || TxnsDateTime.Contains("pm"))
                                                        {

                                                            TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTimeAMPM(TxnDateTime[i].ToString(), TxnsDateTime);
                                                        }
                                                        else
                                                        {
                                                            TxnsDateTime = TxnsDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                                            //if(dt.Rows[0]["FileName"].ToString().Contains("UPI"))
                                                            //{
                                                            //    TxnsDateTimeMain = Convert.ToDateTime(TxnsDateTime);                                             
                                                            //}

                                                        }
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        TxnsDateTimeMain = Convert.ToDateTime(TxnsDateTime);

                                                    }
                                                }
                                                else
                                                {
                                                    TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTime);
                                                    if (ClientID == 49)
                                                    {
                                                        TxnsDateTime = TxnsDateTimeMain.ToString();
                                                    }
                                                }
                                                //if (TxnsDateTime.Contains("/") || TxnsDateTime.Contains(".") || TxnsDateTime.Contains("-"))
                                                //{
                                                //    TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTime);
                                                //}
                                                //else
                                                //{
                                                //    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                                //}
                                            }
                                        }


                                        if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                                        {
                                            for (int i = 0; i < TxnPostDateTime.Length; i++)
                                            {
                                                if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                                                {
                                                    TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                                                }
                                                else
                                                {
                                                    TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                                }
                                            }
                                        }

                                        if (TerminalCode[0].ToString() != "" && TerminalID != "")
                                        {
                                            for (int i = 0; i < TerminalCode.Length; i++)
                                            {
                                                if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                                                {
                                                    Terminal = true;
                                                }
                                            }
                                        }

                                        if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                                        {
                                            for (int i = 0; i < AcquirerIDArray.Length; i++)
                                            {
                                                if (AcquirerIDArray[i].ToString() == AcquirerID)
                                                {
                                                    Acquirer = true;
                                                }
                                            }
                                        }

                                        if (BIN_No[0].ToString() != "" && CardNumber != "")
                                        {
                                            for (int i = 0; i < BIN_No.Length; i++)
                                            {
                                                if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                                                {
                                                    card = true;
                                                }
                                            }
                                        }

                                        if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "")//&& ReversalCode1 != ""
                                        {
                                            for (int i = 0; i < ReversalCode1Array.Length; i++)
                                            {
                                                if (ReserveField1.Contains("Reversal") || ReserveField1.Contains("REVERSAL"))
                                                {
                                                    Rev1 = true;
                                                }
                                                if (ClientID == 10068)
                                                {
                                                    if (ReversalCode1Array[0].ToString() == ReversalCode1)
                                                    {
                                                        Rev1 = true;
                                                    }
                                                }
                                            }
                                        }
                                        if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                                        {
                                            for (int i = 0; i < ReversalCode1Array.Length; i++)
                                            {
                                                if (ReversalCode1Array[i].ToString() == ReversalCode1)
                                                {
                                                    Rev1 = true;
                                                }
                                            }
                                            for (int i = 0; i < ReversalCode2Array.Length; i++)
                                            {
                                                if (ReversalCode2Array[i].ToString() == ReversalCode2)
                                                {
                                                    Rev2 = true;
                                                }
                                            }
                                        }

                                        if (ChannelType == "" && TxnsSubType != "")
                                        {

                                            if (CDMType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < CDMType.Length; i++)
                                                {
                                                    if (CDMType[i].ToString() == TxnsSubType)
                                                    {
                                                        CDM = true;
                                                    }
                                                }
                                            }

                                            if (ATMType[0].ToString() != "")
                                            {
                                                if (ClientID == 10068)
                                                {
                                                    if (TxnsSubType == "ACQ" || TxnsSubType == "ISS" || TxnsSubType == "ONUS" || TxnsSubType == "OTHR")
                                                    {
                                                        ATM = true;
                                                    }
                                                }
                                                else
                                                {
                                                    for (int i = 0; i < ATMType.Length; i++)
                                                    {
                                                        if (ATMType[i].ToString() == TxnsSubType && TerminalID.Substring(0, 2) != MicroATMType[i].ToString())
                                                        {
                                                            ATM = true;
                                                        }
                                                    }
                                                }

                                            }

                                            if (POSType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < POSType.Length; i++)
                                                {
                                                    if (POSType[i].ToString() == TxnsSubType)
                                                    {
                                                        POS = true;
                                                    }
                                                }
                                            }
                                            if (ECOMType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < ECOMType.Length; i++)
                                                {
                                                    if (ECOMType[i].ToString() == TxnsSubType)
                                                    {
                                                        ECOM = true;
                                                    }
                                                }
                                            }

                                            if (IMPType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < IMPType.Length; i++)
                                                {
                                                    if (IMPType[i].ToString() == TxnsSubType)
                                                    {
                                                        IMPS = true;
                                                    }
                                                }
                                            }

                                            if (UPIType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < UPIType.Length; i++)
                                                {
                                                    if (UPIType[i].ToString() == TxnsSubType)
                                                    {
                                                        UPI = true;
                                                    }
                                                }
                                            }

                                            if (MicroATMType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < MicroATMType.Length; i++)
                                                {
                                                    if (MicroATMType[i].ToString() == TxnsSubType || TerminalID.Substring(0, 2) == MicroATMType[i].ToString())
                                                    {
                                                        MicroATM = true;
                                                    }
                                                }
                                            }

                                            if (MobileRechargeType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < MobileRechargeType.Length; i++)
                                                {
                                                    if (MobileRechargeType[i].ToString() == TxnsSubType)
                                                    {
                                                        MobileRecharge = true;
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {

                                            if (CDMType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < CDMType.Length; i++)
                                                {
                                                    if (CDMType[i].ToString() == ChannelType)
                                                    {
                                                        CDM = true;
                                                    }
                                                }
                                            }

                                            if (ATMType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < ATMType.Length; i++)
                                                {
                                                    if (ATMType[i].ToString() == ChannelType || ChannelType == "NFS")
                                                    {
                                                        ATM = true;
                                                    }
                                                }
                                            }

                                            if (POSType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < POSType.Length; i++)
                                                {
                                                    if (POSType[i].ToString() == ChannelType)
                                                    {
                                                        POS = true;
                                                    }
                                                }
                                            }
                                            if (ECOMType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < ECOMType.Length; i++)
                                                {
                                                    if (ECOMType[i].ToString() == ChannelType)
                                                    {
                                                        ECOM = true;
                                                    }
                                                }
                                            }

                                            if (IMPType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < IMPType.Length; i++)
                                                {
                                                    if (IMPType[i].ToString() == ChannelType)
                                                    {
                                                        IMPS = true;
                                                    }
                                                }
                                            }

                                            if (UPIType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < UPIType.Length; i++)
                                                {
                                                    if (UPIType[i].ToString() == ChannelType)
                                                    {
                                                        UPI = true;
                                                    }
                                                }
                                            }

                                            if (MicroATMType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < MicroATMType.Length; i++)
                                                {
                                                    if (MicroATMType[i].ToString() == ChannelType || TerminalID.Substring(0, 2) == MicroATMType[i].ToString())
                                                    {
                                                        MicroATM = true;
                                                    }
                                                }
                                            }

                                            if (MobileRechargeType[0].ToString() != "")
                                            {
                                                for (int i = 0; i < MobileRechargeType.Length; i++)
                                                {
                                                    if (MobileRechargeType[i].ToString() == ChannelType)
                                                    {
                                                        MobileRecharge = true;
                                                    }
                                                }
                                            }
                                        }

                                        if (BalanceEnquiry[0].ToString() != "")
                                        {
                                            for (int i = 0; i < BalanceEnquiry.Length; i++)
                                            {
                                                if (BalanceEnquiry[i].ToString() == TxnsSubType)
                                                {
                                                    BAL = true;
                                                }
                                            }
                                        }

                                        if (MiniStatement[0].ToString() != "")
                                        {
                                            for (int i = 0; i < MiniStatement.Length; i++)
                                            {
                                                if (MiniStatement[i].ToString() == TxnsSubType)
                                                {
                                                    MS = true;
                                                }
                                            }
                                        }

                                        if (PinChange[0].ToString() != "")
                                        {
                                            for (int i = 0; i < PinChange.Length; i++)
                                            {
                                                if (PinChange[i].ToString() == TxnsSubType)
                                                {
                                                    PC = true;
                                                }
                                            }
                                        }

                                        if (ChequeBookReq[0].ToString() != "")
                                        {
                                            for (int i = 0; i < ChequeBookReq.Length; i++)
                                            {
                                                if (ChequeBookReq[i].ToString() == TxnsSubType)
                                                {
                                                    CB = true;
                                                }
                                            }
                                        }

                                        if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode1 != "")
                                        {
                                            for (int i = 0; i < ResponseCode1Array.Length; i++)
                                            {
                                                if (ResponseCode1Array[i].ToString() == ResponseCode1)
                                                {
                                                    RCA1 = true;
                                                }
                                            }
                                        }
                                        if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode1 != "" || ResponseCode2 != "")
                                        {
                                            for (int i = 0; i < ResponseCode1Array.Length; i++)
                                            {
                                                if (ResponseCode1Array[i].ToString() == ResponseCode1)
                                                {
                                                    RCA1 = true;
                                                }
                                            }

                                            for (int i = 0; i < ResponseCode2Array.Length; i++)
                                            {
                                                if (ResponseCode2Array[i].ToString() == ResponseCode2)
                                                {
                                                    RCA2 = true;
                                                }
                                            }
                                        }

                                        if (ResponseCode1Array[0].ToString() == "")
                                        {
                                            RCA1 = true;
                                        }
                                        if (CardNumber != "")
                                        {
                                            if (reNum.Match(CardNumber.Substring(0, 6)).Success)
                                            {
                                               
                                            }
                                        }


                                        if (DebitCode[0].ToString() != "")
                                        {
                                            for (int i = 0; i < DebitCode.Length; i++)
                                            {
                                                if (DebitCode[i].ToString() == DrCrType)
                                                {
                                                    D = true;
                                                }
                                            }
                                        }

                                        if (CreditCode[0].ToString() != "")
                                        {
                                            for (int i = 0; i < CreditCode.Length; i++)
                                            {
                                                if (CreditCode[i].ToString() == DrCrType)
                                                {
                                                    C = true;
                                                }
                                            }
                                        }


                                        /*
                                        if (VISACode[0].ToString() != "" && CardNumber != "")
                                            {
                                            for (int i = 0; i < VISACode.Length; i++)
                                                {
                                                if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                                    {
                                                    CardType = "VISA";
                                                    }
                                                }
                                            }

                                        if (MasterCode[0].ToString() != "" && CardNumber != "")
                                            {
                                            for (int i = 0; i < MasterCode.Length; i++)
                                                {
                                                if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                                    {
                                                    CardType = "MASTER";
                                                    }
                                                }
                                            }

                                            */

                                        #endregion ValidateField

                                        #region InitilizedField

                                        if (AcquirerID != "" || AcquirerID == "" || AcquirerIDArray[0].ToString() == "")
                                        {
                                            if (Terminal == true && card == true)
                                            {
                                                ModeID = (int)TxnsMode.ONUS;
                                            }
                                            if (Terminal == true && card == false)
                                            {
                                                ModeID = (int)TxnsMode.ACQUIRER;
                                            }
                                            if (Terminal == false && card == true)
                                            {
                                                ModeID = (int)TxnsMode.ISSUER;
                                            }
                                        }
                                        else
                                        {
                                            if (Acquirer == true && card == true)
                                            {
                                                ModeID = (int)TxnsMode.ONUS;
                                            }
                                            if (Acquirer == true && card == false)
                                            {
                                                ModeID = (int)TxnsMode.ACQUIRER;
                                            }
                                            if (Acquirer == false && card == true)
                                            {
                                                ModeID = (int)TxnsMode.ISSUER;
                                            }
                                        }

                                        if (Rev1 == true || Rev1 == true && Rev2 == true)
                                        {
                                            ReversalFlag = true;
                                        }
                                        else
                                        {
                                            ReversalFlag = false;
                                        }

                                        if (ATM)
                                        {
                                            if (TxnsSubType == "Withdrawal")
                                            {
                                                TxnsSubTypeMain = "Withdrawal";
                                            }
                                            else if (TxnsSubType == "CashDeposit")
                                            {
                                                TxnsSubTypeMain = "Deposit";
                                            }
                                            else if (ClientID == 10068)
                                            {
                                                if (TxnsSubType != "OTHR")
                                                {
                                                    TxnsSubTypeMain = "Withdrawal";
                                                }
                                            }
                                            ChannelID = (int)TxnsChannelID.ATM;
                                        }

                                        if (CDM)
                                        {
                                            TxnsSubTypeMain = "Deposit";
                                            ChannelID = (int)TxnsChannelID.ATM;
                                        }

                                        if (POS)
                                        {
                                            ChannelID = (int)TxnsChannelID.POS;
                                            TxnsSubTypeMain = "Purchase";
                                            //TxnsSubTypeMain = TxnsSubType;
                                        }

                                        if (ECOM)
                                        {
                                            ChannelID = (int)TxnsChannelID.E_COMMERCE;
                                            TxnsSubTypeMain = "Purchase";
                                            //TxnsSubTypeMain = TxnsSubType;
                                        }

                                        if (IMPS)
                                        {
                                            ChannelID = (int)TxnsChannelID.IMPS;
                                            TxnsSubTypeMain = "Transfer";
                                        }

                                        if (MicroATM)
                                        {
                                            ChannelID = (int)TxnsChannelID.MICRO_ATM;
                                            TxnsSubTypeMain = "Withdrawal";
                                        }

                                        if (MobileRecharge)
                                        {
                                            ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                                            TxnsSubTypeMain = "Transfer";
                                        }

                                        if (UPI)
                                        {
                                            ChannelID = (int)TxnsChannelID.UPI;
                                            TxnsSubTypeMain = "Transfer";
                                        }
                                        if (dt.Rows[0]["FileName"].ToString().Contains("UPI"))
                                        {
                                            ChannelID = (int)TxnsChannelID.UPI;
                                            TxnsSubTypeMain = "Transfer";
                                        }

                                        if (RCA1 == true || RCA1 == true && RCA2 == true)
                                        {
                                            ResponseCode = "00";
                                            TxnsStatus = "Sucessfull";
                                        }
                                        else
                                        {
                                            ResponseCode = ResponseCode1;
                                            TxnsStatus = "Unsucessfull";
                                        }

                                        if (BAL)
                                        {
                                            TxnsSubTypeMain = "Balance enquiry";
                                        }

                                        if (MS)
                                        {
                                            TxnsSubTypeMain = "Mini statement";
                                        }

                                        if (PC)
                                        {
                                            TxnsSubTypeMain = "Pin change";
                                        }

                                        if (CB)
                                        {
                                            TxnsSubTypeMain = "Cheque book request";
                                        }


                                        if (BAL || MS || PC || CB)
                                        {
                                            TxnsType = "Non-Financial";
                                        }
                                        else
                                        {
                                            TxnsType = "Financial";
                                        }
                                        if (OC)
                                        {
                                            TxnsEntryType = "Manual";
                                        }
                                        else
                                        {
                                            TxnsEntryType = "Auto";
                                        }
                                        if (D)
                                        {
                                            DebitCreditType = "D";
                                            ModeID = (int)TxnsMode.OUTWARD;
                                        }

                                        if (C)
                                        {
                                            DebitCreditType = "C";
                                            ModeID = (int)TxnsMode.INWARD;
                                        }

                                        #endregion InitilizedField


                                        #endregion StanderedFields


                                        if (CardNumber != "")
                                        {
                                            ECardNumber = AesEncryption.EncryptString(CardNumber);
                                        }

                                        if (CardNumber != "")
                                        {
                                            string dummy = "XXXXXXXXXX";
                                            CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();

                                        }

                                        if (TxnsDateTime != null)
                                        {
                                            _DataTable.Rows.Add(ClientID
                                                            , ChannelID
                                                            , ModeID
                                                            , TerminalID
                                                            , ReferenceNumber
                                                            , CardNumber.Trim()
                                                            , CardType
                                                            , CustAccountNo
                                                            , InterchangeAccountNo
                                                            , ATMAccountNo
                                                            , TxnsDateTime
                                                            , Convert.ToDecimal(TxnsAmount)
                                                            , Convert.ToDecimal(Amount1)
                                                            , Convert.ToDecimal(Amount2)
                                                            , Convert.ToDecimal(Amount3)
                                                            , TxnsStatus
                                                            , TxnsType
                                                            , TxnsSubTypeMain
                                                            , TxnsEntryType
                                                            , TxnsNumber
                                                            , TxnsPerticulars
                                                            , DebitCreditType
                                                            , ResponseCode
                                                            , ReversalFlag
                                                            , TxnsPostDateTimeMain
                                                            , TxnsPostDateTimeMain
                                                            , AuthCode
                                                            , ProcessingCode
                                                            , Convert.ToDecimal(FeeAmount)
                                                            , CurrencyCode
                                                            , Convert.ToDecimal(CustBalance)
                                                            , Convert.ToDecimal(InterchangeBalance)
                                                            , Convert.ToDecimal(ATMBalance)
                                                            , BranchCode
                                                            , ReserveField1
                                                            , ReserveField2
                                                            , ReserveField3
                                                            , ReserveField4
                                                            , ReserveField5
                                                            , RevEntryLeg
                                                            , 0
                                                            , FileName
                                                            , path
                                                            , null
                                                            , DateTime.Now
                                                            , DateTime.Now
                                                            , UserName
                                                            , ""
                                                            , ECardNumber.Trim()
                                                            );
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                                        objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                                    }
                                    j++;
                                }
                            }
                        }
                    }


                }
                catch (Exception ex)
                {
                    // objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                }
            }
            catch (Exception ex)
            {
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
            }

            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;

        }

        public string ConvertNPCIExcel(string OldFilepath, string OldFileName)
        {
            string NewFileName = "";
            try
            {
                //objLogWriter.FunErrorLog(OldFilepath, objLoginEntity._ClientCode, "ImportFile.aspx", "ConvertNPCIExcel", 0, "ImportFile.aspx", objLoginEntity._UserName, 'E');
                NewFileName = OldFilepath.Replace(OldFileName, "");
                string extension = System.IO.Path.GetExtension(OldFileName);
                NewFileName = NewFileName + OldFileName.Replace(extension, "") + "_New" + extension;

                string xmlPathName = OldFilepath;

                //NewFileName = @"D:\Rupali\SVN_Live\Ankita\sachinSir\files\NTSLSMU020919_1C_backup.xls";
                Excel.Application activeExcel = new Excel.Application();
                Excel.Workbook openWorkBook;
                openWorkBook = activeExcel.Workbooks.Open(xmlPathName);
                openWorkBook.SaveAs(NewFileName, Excel.XlFileFormat.xlExcel9795);
                openWorkBook.Close();
                //objLogWriter.FunErrorLog(NewFileName, objLoginEntity._ClientCode, "INewFileName", "ConvertNPCIExcel", 0, "ImportFile.aspx", objLoginEntity._UserName, 'E');
            }
            catch  
            {
                //LogWriter objLogWriter = new LogWriter();
                //  objLogWriter.FunErrorLog(ex.Message.ToString(), objLoginEntity._ClientCode, "ImportFile.aspx", "ConvertNPCIExcel", 0, "ImportFile.aspx", objLoginEntity._UserName, 'E');
                NewFileName = OldFileName;
            }

            return NewFileName;
        }

        protected DataTable ProcessLateReversal(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {

            DataSet ds = new DataSet();
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("TransType", typeof(string));
            _DataTable.Columns.Add("Resp_Code", typeof(string));
            _DataTable.Columns.Add("CardNo", typeof(string));
            _DataTable.Columns.Add("RRN", typeof(string));
            _DataTable.Columns.Add("StanNo", typeof(string));
            _DataTable.Columns.Add("ACQ", typeof(string));
            _DataTable.Columns.Add("ISS", typeof(string));
            _DataTable.Columns.Add("Trasn_DateTime", typeof(DateTime));
            _DataTable.Columns.Add("TerminalID", typeof(string));
            _DataTable.Columns.Add("SettleDate", typeof(DateTime));
            _DataTable.Columns.Add("Amount", typeof(decimal));
            _DataTable.Columns.Add("ReceivedAmt", typeof(decimal));
            _DataTable.Columns.Add("Status", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));

            
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            try
            {
                string TerminalID = string.Empty;
                string ReferenceNumber = string.Empty;
                string CardNumber = string.Empty;
                string AccountNumber = string.Empty;
                DateTime TxnsDateTime;
                DateTime SettleDate;
                //double Amount;
                string TransSource = string.Empty;
                string ResponseCode = string.Empty;
                string TxnsType = string.Empty;
                string TxnsSubType = string.Empty;
                string TransStatus = string.Empty;
                string TxnsAgentTypeone = string.Empty;
                string TxnsAgentTypetwo = string.Empty;
                string ProcessCode = string.Empty;
                string DATETIME = string.Empty;
                string Reversalcode = string.Empty;
                string TransDescription = string.Empty;
                string AuthCode = string.Empty;
                string TransCycle = string.Empty;
                string ToAccountNumber = string.Empty;
                string Hours = string.Empty;
                string Minute = string.Empty;
                string second = string.Empty;
                string StanNo = string.Empty;
                string AcqInsCode = string.Empty;
                string RecInsCode = string.Empty;
                string TerminalLocation = string.Empty;
                string Acq = string.Empty;
                string Iss = string.Empty;

                string TransactionReqDate = string.Empty;
                string TransactionDate = string.Empty;
                string TransactionTime = string.Empty;
                string ReversalFlag = string.Empty;
                string TransactionID = string.Empty;
                string TransactionType = string.Empty;
                string ProcessingCode = string.Empty;
                string TAmount = string.Empty;
                string ActualAmount = string.Empty;
                string Status = string.Empty;


                string LogType = dt.Rows[0]["FileName"].ToString();
                string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
                //string RevEntryLeg = "1";
                ds.ReadXml(new XmlTextReader(new System.IO.StringReader(xmlFile)));
                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                string extension = System.IO.Path.GetExtension(path);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        break;
                }
                objConn = new OleDbConnection(connString);
                objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);                

                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(dtexcelsheetname.Rows[0]["TABLE_NAME"]).Replace("'", "") + "]";
                //string sht = dr[2].ToString().Replace("'", "");

                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dtfillsheet1 = new DataTable();
                da.Fill(dtfillsheet1);

                objConn.Close();

                TotalCount = dtfillsheet1.Rows.Count;
                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {
                    try
                    {
                        TransactionType = dtfillsheet1.Rows[i][0].ToString().Trim();
                        ResponseCode = dtfillsheet1.Rows[i][1].ToString().Trim();
                        CardNumber = dtfillsheet1.Rows[i][2].ToString().Trim();
                        ReferenceNumber = dtfillsheet1.Rows[i][3].ToString().Trim();
                        StanNo = dtfillsheet1.Rows[i][4].ToString().Trim();
                        if (TransactionType.StartsWith("'"))
                        {
                            TransactionType = TransactionType.Remove(0, 1);
                        }
                        else
                        {
                            TransactionType = dtfillsheet1.Rows[i][0].ToString().Trim();
                        }
                        if (ResponseCode.StartsWith("'"))
                        {
                            ResponseCode = dtfillsheet1.Rows[i][1].ToString().Remove(0, 1).Trim();
                        }
                        else
                        {
                            ResponseCode = dtfillsheet1.Rows[i][1].ToString().Trim();
                        }
                        if (CardNumber.StartsWith("'"))
                        {
                            CardNumber = dtfillsheet1.Rows[i][2].ToString().Remove(0, 1).Trim();
                        }
                        else
                        {
                            CardNumber = dtfillsheet1.Rows[i][2].ToString().Trim();
                        }
                        if (ReferenceNumber.StartsWith("'"))
                        {
                            ReferenceNumber = dtfillsheet1.Rows[i][3].ToString().Remove(0, 1).Trim();
                        }
                        else
                        {
                            ReferenceNumber = dtfillsheet1.Rows[i][3].ToString().Trim();
                        }
                        if (StanNo.StartsWith("'"))
                        {
                            StanNo = dtfillsheet1.Rows[i][4].ToString().Remove(0, 1).Trim();
                        }
                        {
                            StanNo = dtfillsheet1.Rows[i][4].ToString().Trim();
                        }
                        Acq = dtfillsheet1.Rows[i][5].ToString().Trim();
                        Iss = dtfillsheet1.Rows[i][6].ToString().Trim();
                        TransactionDate = dtfillsheet1.Rows[i][7].ToString();
                        TransactionTime = dtfillsheet1.Rows[i][8].ToString();
                        if (TransactionDate.Contains("/"))
                        {
                            TransactionDate = TransactionDate.Replace('/', '-');
                        }
                        string TempDate = TransactionDate + " " + TransactionTime;
                        //TxnsDateTime = Convert.ToDateTime(TempDate);
                        TxnsDateTime = DateTime.ParseExact(TempDate, "MM-dd-yyyy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);

                        TerminalID = dtfillsheet1.Rows[i][9].ToString();
                        TransactionReqDate = dtfillsheet1.Rows[i][10].ToString(); //SettleDate
                        if (TransactionReqDate.Contains("/"))
                        {
                            TransactionReqDate = TransactionReqDate.Replace('/', '-');
                        }
                        SettleDate = DateTime.ParseExact(TransactionReqDate, "MM-dd-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        TAmount = dtfillsheet1.Rows[i][11].ToString();
                        ActualAmount = dtfillsheet1.Rows[i][12].ToString();
                        Status = dtfillsheet1.Rows[i][13].ToString().Trim();

                        _DataTable.Rows.Add(ClientID, TransactionType, ResponseCode, CardNumber, ReferenceNumber, StanNo, Acq, Iss, TxnsDateTime,
                            TerminalID, SettleDate, TAmount, ActualAmount, Status, FileName, path, UserName, System.DateTime.Now, UserName, System.DateTime.Now);

                        InsertCount++;
                        TerminalID = string.Empty;
                        ReferenceNumber = string.Empty;
                        CardNumber = string.Empty;
                        AccountNumber = string.Empty;
                        //Amount = 0.0;
                        ResponseCode = string.Empty;
                        TransSource = string.Empty;
                        TxnsType = string.Empty;
                        TransStatus = string.Empty;
                        ProcessCode = string.Empty;
                        TransDescription = string.Empty;
                        AuthCode = string.Empty;
                        TransCycle = string.Empty;
                        ToAccountNumber = string.Empty;

                    }
                    catch (Exception ex)
                    {

                        objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');

                    }
                }
                if (_DataTable.Rows.Count == 0)
                {
                    InsertCount--;
                }
            }
            catch (Exception ex)
            {

                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');

            }
            return _DataTable;
        }

        public DataTable SwitchSplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode, DataTable _DataTable)
        {
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0; 

            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new System.IO.StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            //string[] TotalCountArray = File.ReadAllLines(path);
            //= TotalCountArray.Length;

            DataTable dtexcelsheetname = null;
            try
            {
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                OleDbConnection objConn;
                string extension = System.IO.Path.GetExtension(path);
                switch (extension.ToLower())
                {

                    case ".xls": //Excel 97-03
                        // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                }

                try
                {
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }
                catch
                {
                    switch (extension.ToLower())
                    {


                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }

                //OleDbConnection objConn = new OleDbConnection(connString);
                //objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                int j = 0;
                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    excelSheets[j] = row["TABLE_NAME"].ToString();
                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";

                    OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataTable dtSheet = new DataTable();
                    da.Fill(dtSheet);

                    objConn.Close();

                    TotalCount = dtSheet.Rows.Count;

                    if (dtSheet.Rows.Count > 1)
                    {
                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            LineNo++;
                            try
                            {
                                //string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                                //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                                int Incr = 1;
                                string TerminalID = string.Empty;
                                string AcquirerID = string.Empty;
                                string ReferenceNumber = string.Empty;
                                string CardNumber = string.Empty;
                                string CustAccountNo = string.Empty;
                                string InterchangeAccountNo = string.Empty;
                                string ATMAccountNo = string.Empty;
                                string TxnsDateTime = string.Empty;
                                string TxnsDate = string.Empty;
                                string TxnsTime = string.Empty;
                                string TxnsAmount = "0";
                                string Amount1 = "0";
                                string Amount2 = "0";
                                string Amount3 = "0";
                                string ChannelType = string.Empty;
                                string TxnsSubType = string.Empty;
                                string TxnsNumber = string.Empty;
                                string TxnsPerticulars = string.Empty;
                                string DrCrType = string.Empty;
                                string ResponseCode1 = string.Empty;
                                string ResponseCode2 = string.Empty;
                                string ReversalCode1 = string.Empty;
                                string ReversalCode2 = string.Empty;
                                string TxnsPostDateTime = string.Empty;
                                string TxnsValueDateTime = string.Empty;
                                string AuthCode = string.Empty;
                                string ProcessingCode = string.Empty;
                                string FeeAmount = "0";
                                string CurrencyCode = string.Empty;
                                string CustBalance = "0";
                                string InterchangeBalance = "0";
                                string ATMBalance = "0";
                                string BranchCode = string.Empty;
                                string ReserveField1 = string.Empty;
                                string ReserveField2 = string.Empty;
                                string ReserveField3 = string.Empty;
                                string ReserveField4 = string.Empty;
                                string ReserveField5 = string.Empty;
                                string NoOfDuplicate = string.Empty;

                                if (ds.Tables[0].Rows[0]["TerminalID"].ToString() != "0")
                                {
                                    TerminalID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TerminalID"].ToString()) - Incr].ToString();

                                }
                                if (ds.Tables[0].Rows[0]["AcquirerID"].ToString() != "0")
                                {
                                    AcquirerID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AcquirerID"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReferenceNumber"].ToString() != "0")
                                {
                                    ReferenceNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReferenceNumber"].ToString()) - Incr].ToString();
                                    if (ReferenceNumber == "009815001487")
                                    {

                                    }
                                }
                                if (ds.Tables[0].Rows[0]["CardNumber"].ToString() != "0")
                                {
                                    CardNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CardNumber"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["CustAccountNo"].ToString() != "0")
                                {
                                    CustAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CustAccountNo"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["InterchangeAccountNo"].ToString() != "0")
                                {
                                    InterchangeAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["InterchangeAccountNo"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ATMAccountNo"].ToString() != "0")
                                {
                                    ATMAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ATMAccountNo"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsDateTime"].ToString() != "0")
                                {
                                    TxnsDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsDateTime"].ToString()) - Incr].ToString();

                                    //TxnsDateTime = TxnsDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsDate"].ToString() != "0")
                                {
                                    TxnsDate = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsDate"].ToString()) - Incr].ToString();

                                }
                                if (ds.Tables[0].Rows[0]["TxnsTime"].ToString() != "0")
                                {
                                    TxnsTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsTime"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsAmount"].ToString() != "0")
                                {
                                    TxnsAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                                    //if(ClientID == 10068)
                                    //{
                                    //    if (TxnsAmount.Length > 2)
                                    //    {
                                    //        TxnsAmount = TxnsAmount.Remove(TxnsAmount.Length-2);
                                    //    }
                                    //    else
                                    //    {
                                    //        TxnsAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                                    //    }


                                    //}
                                    //else 
                                    //{
                                    //    TxnsAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                                    //}
                                }
                                if (ds.Tables[0].Rows[0]["Amount1"].ToString() != "0")
                                {
                                    Amount1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Amount1"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Amount2"].ToString() != "0")
                                {
                                    Amount2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Amount2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Amount3"].ToString() != "0")
                                {
                                    Amount3 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Amount3"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsSubType"].ToString() != "0")
                                {
                                    TxnsSubType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsSubType"].ToString()) - Incr].ToString();
                                    if (ClientID != 10068)
                                    {
                                        if (TxnsSubType == "ACQ" || TxnsSubType == "ONUS")
                                        {
                                            String amt = TxnsAmount;
                                            TxnsAmount = amt;
                                        }
                                        else
                                        {
                                            decimal AMT = decimal.Parse(TxnsAmount);
                                            decimal AMT1 = (AMT / 100);
                                            TxnsAmount = Convert.ToString(AMT1);
                                        }
                                    }
                                }
                                if (ds.Tables[0].Rows[0]["ChannelType"].ToString() != "0")
                                {
                                    ChannelType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ChannelType"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsNumber"].ToString() != "0")
                                {
                                    TxnsNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsNumber"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsPerticulars"].ToString() != "0")
                                {
                                    TxnsPerticulars = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsPerticulars"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["DrCrType"].ToString() != "0")
                                {
                                    DrCrType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["DrCrType"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ResponseCode1"].ToString() != "0")
                                {
                                    ResponseCode1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode1"].ToString()) - Incr].ToString();
                                    if (ClientID == 10068)
                                    {
                                        if (TxnsSubType == "ACQ" && ResponseCode1 == "0 ")
                                        {
                                            ResponseCode1 = "00";
                                        }
                                        else
                                        {
                                            ResponseCode1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode1"].ToString()) - Incr].ToString();
                                        }
                                    }
                                }
                                if (ds.Tables[0].Rows[0]["ResponseCode2"].ToString() != "0")
                                {
                                    ResponseCode2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReversalCode1"].ToString() != "0")
                                {
                                    ReversalCode1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReversalCode1"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReversalCode2"].ToString() != "0")
                                {
                                    ReversalCode2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReversalCode2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsPostDateTime"].ToString() != "0")
                                {
                                    TxnsPostDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsPostDateTime"].ToString()) - Incr].ToString();
                                    TxnsPostDateTime = TxnsPostDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsValueDateTime"].ToString() != "0")
                                {
                                    TxnsValueDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsValueDateTime"].ToString()) - Incr].ToString();
                                    TxnsValueDateTime = TxnsValueDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                }
                                if (ds.Tables[0].Rows[0]["AuthCode"].ToString() != "0")
                                {
                                    AuthCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AuthCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ProcessingCode"].ToString() != "0")
                                {
                                    ProcessingCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ProcessingCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["FeeAmount"].ToString() != "0")
                                {
                                    FeeAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["FeeAmount"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["CurrencyCode"].ToString() != "0")
                                {
                                    CurrencyCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CurrencyCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["CustBalance"].ToString() != "0")
                                {
                                    CustBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CustBalance"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["InterchangeBalance"].ToString() != "0")
                                {
                                    InterchangeBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["InterchangeBalance"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ATMBalance"].ToString() != "0")
                                {
                                    ATMBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ATMBalance"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["BranchCode"].ToString() != "0")
                                {
                                    BranchCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["BranchCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField1"].ToString() != "0")
                                {
                                    ReserveField1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField1"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField2"].ToString() != "0")
                                {
                                    ReserveField2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField3"].ToString() != "0")
                                {
                                    ReserveField3 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField3"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField4"].ToString() != "0")
                                {
                                    ReserveField4 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField4"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField5"].ToString() != "0")
                                {
                                    ReserveField5 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField5"].ToString()) - Incr].ToString();
                                }

                                #region StanderedFields
                                string SplitType = ",";
                                int ModeID = 0;
                                int ChannelID = 0;
                                bool ReversalFlag = false;
                                string ResponseCode = string.Empty;
                                string TxnsStatus = string.Empty;
                                string DebitCreditType = string.Empty;
                                string TxnsType = string.Empty;
                                string TxnsSubTypeMain = string.Empty;
                                string TxnsEntryType = string.Empty;
                                string CardType = string.Empty;
                                DateTime? TxnsDateTimeMain;

                                TxnsDateTimeMain = null;
                                DateTime? TxnsPostDateTimeMain;
                                TxnsPostDateTimeMain = null;

                                string[] TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] AcquirerIDArray = dt.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ReversalCode1Array = dt.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ReversalCode2Array = dt.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string ReversalType = dt.Rows[0]["ReversalType"].ToString();
                                string[] ATMType = dt.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] CDMType = dt.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] POSType = dt.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ECOMType = dt.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] IMPType = dt.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] UPIType = dt.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] MicroATMType = dt.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] MobileRechargeType = dt.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] BalanceEnquiry = dt.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] MiniStatement = dt.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] PinChange = dt.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ChequeBookReq = dt.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string ResponseType = dt.Rows[0]["ResponseType"].ToString();
                                string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ResponseCode2Array = dt.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] OfflineCode = dt.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] TxnDateTime = dt.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] TxnPostDateTime = dt.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] DebitCode = dt.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] CreditCode = dt.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);


                                bool card = false;
                                bool Terminal = false;
                                bool Acquirer = false;
                                bool Rev1 = false;
                                bool Rev2 = false;
                                bool ATM = false;
                                bool CDM = false;
                                bool POS = false;
                                bool ECOM = false;
                                bool IMPS = false;
                                bool UPI = false;
                                bool MicroATM = false;
                                bool MobileRecharge = false;
                                bool BAL = false;
                                bool MS = false;
                                bool PC = false;
                                bool CB = false;
                                bool RCA1 = false;
                                bool RCA2 = false;
                                //bool MC = false;
                                //bool VC = false;
                                bool OC = false;
                                bool D = false;
                                bool C = false;

                                #region ValidateField
                                if (TxnsDate != "" && TxnsTime != "")
                                {

                                    if (TxnDateTime[0].ToString() != "")
                                    {
                                        for (int i = 0; i < TxnDateTime.Length; i++)
                                        {
                                            string TxnsDateTimeDiff;
                                            if (ClientID == 10068)
                                            {
                                                TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;
                                            }
                                            else
                                            {
                                                TxnsDateTimeDiff = TxnsDate + TxnsTime;
                                            }

                                            if (TxnsDateTimeDiff.Contains("/") || TxnsDateTimeDiff.Contains(".") || TxnsDateTimeDiff.Contains("-"))
                                            {
                                                try
                                                {
                                                    if (TxnsDateTimeDiff != "" && TxnsDateTimeDiff.Contains("PM") || TxnsDateTimeDiff.Contains("pm"))
                                                    {
                                                        TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTimeAMPM(TxnDateTime[i].ToString(), TxnsDateTimeDiff);
                                                    }
                                                    else
                                                    {
                                                        TxnsDateTime = TxnsDateTimeDiff.Replace("AM", "").Replace("PM", "").Trim();
                                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[i].ToString(), System.Globalization.CultureInfo.InvariantCulture);
                                                        if (ClientID == 10068)
                                                        {
                                                            TxnsDateTime = TxnsDateTimeMain.ToString();
                                                        }

                                                    }
                                                }
                                                catch  
                                                {

                                                    TxnsDateTimeMain = Convert.ToDateTime(TxnsDateTimeDiff);

                                                }
                                                //TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTimeDiff);
                                            }
                                            else
                                            {
                                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTime[i].ToString(), System.Globalization.CultureInfo.InvariantCulture);
                                            }
                                        }
                                    }
                                }

                                if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                                {

                                    for (int i = 0; i < TxnDateTime.Length; i++)
                                    {
                                        if (TxnsDateTime.Contains("/") || TxnsDateTime.Contains(".") || TxnsDateTime.Contains("-"))
                                        {
                                            try
                                            {

                                                if (TxnsDateTime != "" && TxnsDateTime.Contains("PM") || TxnsDateTime.Contains("pm"))
                                                {

                                                    TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTimeAMPM(TxnDateTime[i].ToString(), TxnsDateTime);
                                                }
                                                else
                                                {
                                                    TxnsDateTime = TxnsDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[i].ToString(), System.Globalization.CultureInfo.InvariantCulture);
                                                    //if(dt.Rows[0]["FileName"].ToString().Contains("UPI"))
                                                    //{
                                                    //    TxnsDateTimeMain = Convert.ToDateTime(TxnsDateTime);                                             
                                                    //}

                                                }
                                            }
                                            catch  
                                            {
                                                TxnsDateTimeMain = Convert.ToDateTime(TxnsDateTime);

                                            }
                                        }
                                        else
                                        {
                                            TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTime);
                                            if (ClientID == 49)
                                            {
                                                TxnsDateTime = TxnsDateTimeMain.ToString();
                                            }
                                        }
                                        //if (TxnsDateTime.Contains("/") || TxnsDateTime.Contains(".") || TxnsDateTime.Contains("-"))
                                        //{
                                        //    TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTime);
                                        //}
                                        //else
                                        //{
                                        //    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[i].ToString(),  System.Globalization.CultureInfo.InvariantCulture);
                                        //}
                                    }
                                }


                                if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                                {
                                    for (int i = 0; i < TxnPostDateTime.Length; i++)
                                    {
                                        if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                                        {
                                            TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                                        }
                                        else
                                        {
                                            TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), System.Globalization.CultureInfo.InvariantCulture);
                                        }
                                    }
                                }

                                if (TerminalCode[0].ToString() != "" && TerminalID != "")
                                {
                                    for (int i = 0; i < TerminalCode.Length; i++)
                                    {
                                        if (TerminalID.Contains(TerminalCode[i].ToString()))
                                        {
                                            Terminal = true;
                                        }
                                    }
                                }

                                if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                                {
                                    for (int i = 0; i < AcquirerIDArray.Length; i++)
                                    {
                                        if (AcquirerIDArray[i].ToString() == AcquirerID)
                                        {
                                            Acquirer = true;
                                        }
                                    }
                                }

                                if (BIN_No[0].ToString() != "" && CardNumber != "")
                                {
                                    for (int i = 0; i < BIN_No.Length; i++)
                                    {
                                        if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                                        {
                                            card = true;
                                        }
                                    }
                                }

                                if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "")//&& ReversalCode1 != ""
                                {
                                    for (int i = 0; i < ReversalCode1Array.Length; i++)
                                    {
                                        if (ReserveField1.Contains("Reversal") || ReserveField1.Contains("REVERSAL"))
                                        {
                                            Rev1 = true;
                                        }
                                        if (ClientID == 10068)
                                        {
                                            if (ReversalCode1Array[0].ToString() == ReversalCode1)
                                            {
                                                Rev1 = true;
                                            }
                                        }
                                    }
                                }
                                if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                                {
                                    for (int i = 0; i < ReversalCode1Array.Length; i++)
                                    {
                                        if (ReversalCode1Array[i].ToString() == ReversalCode1)
                                        {
                                            Rev1 = true;
                                        }
                                    }
                                    for (int i = 0; i < ReversalCode2Array.Length; i++)
                                    {
                                        if (ReversalCode2Array[i].ToString() == ReversalCode2)
                                        {
                                            Rev2 = true;
                                        }
                                    }
                                }

                                if (ChannelType == "" && TxnsSubType != "")
                                {

                                    if (CDMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < CDMType.Length; i++)
                                        {
                                            if (CDMType[i].ToString() == TxnsSubType)
                                            {
                                                CDM = true;
                                            }
                                        }
                                    }

                                    if (ATMType[0].ToString() != "")
                                    {
                                        if (ClientID == 10068)
                                        {
                                            if (TxnsSubType == "ACQ" || TxnsSubType == "ISS" || TxnsSubType == "ONUS" || TxnsSubType == "OTHR")
                                            {
                                                ATM = true;
                                            }
                                        }
                                        else
                                        {
                                            for (int i = 0; i < ATMType.Length; i++)
                                            {
                                                if (ATMType[i].ToString() == TxnsSubType && TerminalID.Substring(0, 2) != MicroATMType[i].ToString())
                                                {
                                                    ATM = true;
                                                }
                                            }
                                        }

                                    }

                                    if (POSType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < POSType.Length; i++)
                                        {
                                            if (POSType[i].ToString() == TxnsSubType)
                                            {
                                                POS = true;
                                            }
                                        }
                                    }
                                    if (ECOMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < ECOMType.Length; i++)
                                        {
                                            if (ECOMType[i].ToString() == TxnsSubType)
                                            {
                                                ECOM = true;
                                            }
                                        }
                                    }

                                    if (IMPType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < IMPType.Length; i++)
                                        {
                                            if (IMPType[i].ToString() == TxnsSubType)
                                            {
                                                IMPS = true;
                                            }
                                        }
                                    }

                                    if (UPIType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < UPIType.Length; i++)
                                        {
                                            if (UPIType[i].ToString() == TxnsSubType)
                                            {
                                                UPI = true;
                                            }
                                        }
                                    }

                                    if (MicroATMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < MicroATMType.Length; i++)
                                        {
                                            if (MicroATMType[i].ToString() == TxnsSubType || TerminalID.Substring(0, 2) == MicroATMType[i].ToString())
                                            {
                                                MicroATM = true;
                                            }
                                        }
                                    }

                                    if (MobileRechargeType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < MobileRechargeType.Length; i++)
                                        {
                                            if (MobileRechargeType[i].ToString() == TxnsSubType)
                                            {
                                                MobileRecharge = true;
                                            }
                                        }
                                    }
                                }
                                else
                                {

                                    if (CDMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < CDMType.Length; i++)
                                        {
                                            if (CDMType[i].ToString() == ChannelType)
                                            {
                                                CDM = true;
                                            }
                                        }
                                    }

                                    if (ATMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < ATMType.Length; i++)
                                        {
                                            if (ATMType[i].ToString() == ChannelType || ChannelType == "NFS")
                                            {
                                                ATM = true;
                                            }
                                        }
                                    }

                                    if (POSType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < POSType.Length; i++)
                                        {
                                            if (POSType[i].ToString() == ChannelType)
                                            {
                                                POS = true;
                                            }
                                        }
                                    }
                                    if (ECOMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < ECOMType.Length; i++)
                                        {
                                            if (ECOMType[i].ToString() == ChannelType)
                                            {
                                                ECOM = true;
                                            }
                                        }
                                    }

                                    if (IMPType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < IMPType.Length; i++)
                                        {
                                            if (IMPType[i].ToString() == ChannelType)
                                            {
                                                IMPS = true;
                                            }
                                        }
                                    }

                                    if (UPIType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < UPIType.Length; i++)
                                        {
                                            if (UPIType[i].ToString() == ChannelType)
                                            {
                                                UPI = true;
                                            }
                                        }
                                    }

                                    if (MicroATMType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < MicroATMType.Length; i++)
                                        {
                                            if (MicroATMType[i].ToString() == ChannelType || TerminalID.Substring(0, 2) == MicroATMType[i].ToString())
                                            {
                                                MicroATM = true;
                                            }
                                        }
                                    }

                                    if (MobileRechargeType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < MobileRechargeType.Length; i++)
                                        {
                                            if (MobileRechargeType[i].ToString() == ChannelType)
                                            {
                                                MobileRecharge = true;
                                            }
                                        }
                                    }
                                }

                                if (BalanceEnquiry[0].ToString() != "")
                                {
                                    for (int i = 0; i < BalanceEnquiry.Length; i++)
                                    {
                                        if (BalanceEnquiry[i].ToString() == TxnsSubType)
                                        {
                                            BAL = true;
                                        }
                                    }
                                }

                                if (MiniStatement[0].ToString() != "")
                                {
                                    for (int i = 0; i < MiniStatement.Length; i++)
                                    {
                                        if (MiniStatement[i].ToString() == TxnsSubType)
                                        {
                                            MS = true;
                                        }
                                    }
                                }

                                if (PinChange[0].ToString() != "")
                                {
                                    for (int i = 0; i < PinChange.Length; i++)
                                    {
                                        if (PinChange[i].ToString() == TxnsSubType)
                                        {
                                            PC = true;
                                        }
                                    }
                                }

                                if (ChequeBookReq[0].ToString() != "")
                                {
                                    for (int i = 0; i < ChequeBookReq.Length; i++)
                                    {
                                        if (ChequeBookReq[i].ToString() == TxnsSubType)
                                        {
                                            CB = true;
                                        }
                                    }
                                }

                                if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode1 != "")
                                {
                                    for (int i = 0; i < ResponseCode1Array.Length; i++)
                                    {
                                        if (ResponseCode1Array[i].ToString() == ResponseCode1)
                                        {
                                            RCA1 = true;
                                        }
                                    }
                                }
                                if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode1 != "" || ResponseCode2 != "")
                                {
                                    for (int i = 0; i < ResponseCode1Array.Length; i++)
                                    {
                                        if (ResponseCode1Array[i].ToString() == ResponseCode1)
                                        {
                                            RCA1 = true;
                                        }
                                    }

                                    for (int i = 0; i < ResponseCode2Array.Length; i++)
                                    {
                                        if (ResponseCode2Array[i].ToString() == ResponseCode2)
                                        {
                                            RCA2 = true;
                                        }
                                    }
                                }

                                if (ResponseCode1Array[0].ToString() == "")
                                {
                                    RCA1 = true;
                                }
                                if (CardNumber != "")
                                {
                                    if (reNum.Match(CardNumber.Substring(0, 6)).Success)
                                    {
                                      
                                    }
                                }


                                if (DebitCode[0].ToString() != "")
                                {
                                    for (int i = 0; i < DebitCode.Length; i++)
                                    {
                                        if (DebitCode[i].ToString() == DrCrType)
                                        {
                                            D = true;
                                        }
                                    }
                                }

                                if (CreditCode[0].ToString() != "")
                                {
                                    for (int i = 0; i < CreditCode.Length; i++)
                                    {
                                        if (CreditCode[i].ToString() == DrCrType)
                                        {
                                            C = true;
                                        }
                                    }
                                }


                                /*
                                if (VISACode[0].ToString() != "" && CardNumber != "")
                                    {
                                    for (int i = 0; i < VISACode.Length; i++)
                                        {
                                        if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                            {
                                            CardType = "VISA";
                                            }
                                        }
                                    }

                                if (MasterCode[0].ToString() != "" && CardNumber != "")
                                    {
                                    for (int i = 0; i < MasterCode.Length; i++)
                                        {
                                        if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                            {
                                            CardType = "MASTER";
                                            }
                                        }
                                    }

                                    */

                                #endregion ValidateField

                                #region InitilizedField

                                if (AcquirerID != "" || AcquirerID == "" || AcquirerIDArray[0].ToString() == "")
                                {
                                    if (Terminal == true && card == true)
                                    {
                                        ModeID = (int)TxnsMode.ONUS;
                                    }
                                    if (Terminal == true && card == false)
                                    {
                                        ModeID = (int)TxnsMode.ACQUIRER;
                                    }
                                    if (Terminal == false && card == true)
                                    {
                                        ModeID = (int)TxnsMode.ISSUER;
                                    }
                                }
                                else
                                {
                                    if (Acquirer == true && card == true)
                                    {
                                        ModeID = (int)TxnsMode.ONUS;
                                    }
                                    if (Acquirer == true && card == false)
                                    {
                                        ModeID = (int)TxnsMode.ACQUIRER;
                                    }
                                    if (Acquirer == false && card == true)
                                    {
                                        ModeID = (int)TxnsMode.ISSUER;
                                    }
                                }

                                if (Rev1 == true || Rev1 == true && Rev2 == true)
                                {
                                    ReversalFlag = true;
                                }
                                else
                                {
                                    ReversalFlag = false;
                                }

                                if (ATM)
                                {
                                    if (TxnsSubType == "Withdrawal")
                                    {
                                        TxnsSubTypeMain = "Withdrawal";
                                    }
                                    else if (TxnsSubType == "CashDeposit")
                                    {
                                        TxnsSubTypeMain = "Deposit";
                                    }
                                    else if (ClientID == 10068)
                                    {
                                        if (TxnsSubType != "OTHR")
                                        {
                                            TxnsSubTypeMain = "Withdrawal";
                                        }
                                    }
                                    ChannelID = (int)TxnsChannelID.ATM;
                                }

                                if (CDM)
                                {
                                    TxnsSubTypeMain = "Deposit";
                                    ChannelID = (int)TxnsChannelID.ATM;
                                }

                                if (POS)
                                {
                                    ChannelID = (int)TxnsChannelID.POS;
                                    TxnsSubTypeMain = "Purchase";
                                    //TxnsSubTypeMain = TxnsSubType;
                                }

                                if (ECOM)
                                {
                                    ChannelID = (int)TxnsChannelID.E_COMMERCE;
                                    TxnsSubTypeMain = "Purchase";
                                    //TxnsSubTypeMain = TxnsSubType;
                                }

                                if (IMPS)
                                {
                                    ChannelID = (int)TxnsChannelID.IMPS;
                                    TxnsSubTypeMain = "Transfer";
                                }

                                if (MicroATM)
                                {
                                    ChannelID = (int)TxnsChannelID.MICRO_ATM;
                                    TxnsSubTypeMain = "Withdrawal";
                                }

                                if (MobileRecharge)
                                {
                                    ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                                    TxnsSubTypeMain = "Transfer";
                                }

                                if (UPI)
                                {
                                    ChannelID = (int)TxnsChannelID.UPI;
                                    TxnsSubTypeMain = "Transfer";
                                }
                                if (dt.Rows[0]["FileName"].ToString().Contains("UPI"))
                                {
                                    ChannelID = (int)TxnsChannelID.UPI;
                                    TxnsSubTypeMain = "Transfer";
                                }

                                if (RCA1 == true || RCA1 == true && RCA2 == true)
                                {
                                    ResponseCode = "00";
                                    TxnsStatus = "Sucessfull";
                                }
                                else
                                {
                                    ResponseCode = ResponseCode1;
                                    TxnsStatus = "Unsucessfull";
                                }

                                if (BAL)
                                {
                                    TxnsSubTypeMain = "Balance enquiry";
                                }

                                if (MS)
                                {
                                    TxnsSubTypeMain = "Mini statement";
                                }

                                if (PC)
                                {
                                    TxnsSubTypeMain = "Pin change";
                                }

                                if (CB)
                                {
                                    TxnsSubTypeMain = "Cheque book request";
                                }


                                if (BAL || MS || PC || CB)
                                {
                                    TxnsType = "Non-Financial";
                                }
                                else
                                {
                                    TxnsType = "Financial";
                                }
                                if (OC)
                                {
                                    TxnsEntryType = "Manual";
                                }
                                else
                                {
                                    TxnsEntryType = "Auto";
                                }
                                if (D)
                                {
                                    DebitCreditType = "D";
                                    ModeID = (int)TxnsMode.OUTWARD;
                                }

                                if (C)
                                {
                                    DebitCreditType = "C";
                                    ModeID = (int)TxnsMode.INWARD;
                                }

                                #endregion InitilizedField


                                #endregion StanderedFields


                                string ECardNumber = string.Empty;
                                if (CardNumber != "")
                                {
                                    ECardNumber = AesEncryption.EncryptString(CardNumber);;
                                }

                                if (TxnsDateTime != null)
                                {
                                    _DataTable.Rows.Add(ClientID
                                                    , ChannelID
                                                    , ModeID
                                                    , TerminalID
                                                    , ReferenceNumber
                                                    , ECardNumber.Trim()
                                                    , CardType
                                                    , CustAccountNo
                                                    , InterchangeAccountNo
                                                    , ATMAccountNo
                                                    , TxnsDateTimeMain
                                                    , Convert.ToDecimal(TxnsAmount)
                                                    , Convert.ToDecimal(Amount1)
                                                    , Convert.ToDecimal(Amount2)
                                                    , Convert.ToDecimal(Amount3)
                                                    , TxnsStatus
                                                    , TxnsType
                                                    , TxnsSubTypeMain
                                                    , TxnsEntryType
                                                    , TxnsNumber
                                                    , TxnsPerticulars
                                                    , DebitCreditType
                                                    , ResponseCode
                                                    , ReversalFlag
                                                    , TxnsPostDateTimeMain
                                                    , TxnsPostDateTimeMain
                                                    , AuthCode
                                                    , ProcessingCode
                                                    , Convert.ToDecimal(FeeAmount)
                                                    , CurrencyCode
                                                    , Convert.ToDecimal(CustBalance)
                                                    , Convert.ToDecimal(InterchangeBalance)
                                                    , Convert.ToDecimal(ATMBalance)
                                                    , BranchCode
                                                    , ReserveField1
                                                    , ReserveField2
                                                    , ReserveField3
                                                    , ReserveField4
                                                    , ReserveField5
                                                    , RevEntryLeg
                                                    , 0
                                                    , FileName
                                                    , path
                                                    , null
                                                    , DateTime.Now
                                                    , DateTime.Now
                                                    , UserName
                                                    , ""
                                                    );
                                }

                            }
                            catch (Exception ex)
                            {
                                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                            }
                            j++;
                        }
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
            }
            return _DataTable;

        }
    }

    public enum TxnsMode
    {
        ONUS = 1,
        ACQUIRER = 2,
        ISSUER = 3,
        INWARD = 4,
        OUTWARD = 5,
        INTRA = 14
    }

    public enum TxnsChannelID
    {
        ATM = 1,
        POS = 2,
        E_COMMERCE = 3,
        IMPS = 4,
        MICRO_ATM = 5,
        MOBILE_RECHARGE = 6,
        UPI = 7,
        BBPS=17
    }


}
