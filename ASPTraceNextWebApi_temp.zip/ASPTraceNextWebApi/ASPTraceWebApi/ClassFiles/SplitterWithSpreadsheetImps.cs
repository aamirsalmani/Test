﻿using System; 
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Utility;

namespace ASPTraceWebApi
{
    public class SplitterWithSpreadsheetImps
    {


        
        DateTimeConverter objDateTimeConverter = new DateTimeConverter();

        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public SplitterWithSpreadsheetImps(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        public DataTable SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode, DataTable _DataTable)
        {
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0; 

            string relativePath = _configuration["AppSettings:MekKey2Path"];   
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            //string[] TotalCountArray = File.ReadAllLines(path);
            //= TotalCountArray.Length;

            DataTable dtexcelsheetname = null;
            try
            {
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                OleDbConnection objConn;
                string extension = Path.GetExtension(path);
                switch (extension.ToLower())
                {

                    case ".xls": //Excel 97-03
                        // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                }

                try
                {
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }
                catch
                {
                    switch (extension.ToLower())
                    {


                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }

                //OleDbConnection objConn = new OleDbConnection(connString);
                //objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                int j = 0;
                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    excelSheets[j] = row["TABLE_NAME"].ToString();
                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";

                    OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataTable dtSheet = new DataTable();
                    da.Fill(dtSheet);

                    objConn.Close();

                    TotalCount = dtSheet.Rows.Count;

                    if (dtSheet.Rows.Count > 1)
                    {
                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            LineNo++;
                            try
                            {

                                //string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                                //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                                int Incr = 1;
                                string TerminalID = string.Empty;
                                string AcquirerID = string.Empty;
                                string ReferenceNumber = string.Empty;
                                string CardNumber = string.Empty;
                                string CustAccountNo = string.Empty;
                                string InterchangeAccountNo = string.Empty;
                                string ATMAccountNo = string.Empty;
                                string TxnsDateTime = string.Empty;
                                string TxnsDate = string.Empty;
                                string TxnsTime = string.Empty;
                                string TxnsAmount = "0";
                                string Amount1 = "0";
                                string DestinationAmount = "0";
                                string FeeAmount = "0";
                                string ChannelType = string.Empty;
                                string TxnsSubType = string.Empty;
                                string TxnsNumber = string.Empty;
                                string TxnsPerticulars = string.Empty;
                                string DrCrType = string.Empty;
                                string ResponseCode1 = string.Empty;
                                string ResponseCode2 = string.Empty;
                                string ReversalCode1 = string.Empty;
                                string ReversalCode2 = string.Empty;
                                string TxnsPostDateTime = string.Empty;
                                string TxnsValueDateTime = string.Empty;
                                string AuthCode = string.Empty;
                                string ProcessingCode = string.Empty;
                                string DestinationCurrencyCode = string.Empty;                                
                                string SourceCurrencyCode = string.Empty;
                                string CustBalance = "0";
                                string InterchangeBalance = "0";
                                string ATMBalance = "0";
                                string BranchCode = string.Empty;
                                string ReserveField1 = string.Empty;
                                string ReserveField2 = string.Empty;
                                string ReserveField3 = string.Empty;
                                string ReserveField4 = string.Empty;
                                string ReserveField5 = string.Empty;
                                string NoOfDuplicate = string.Empty;
                                string ECardNumber = string.Empty;


                                if (ds.Tables[0].Rows[0]["TerminalID"].ToString() != "0")
                                {
                                    TerminalID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TerminalID"].ToString()) - Incr].ToString();

                                }
                                if (ds.Tables[0].Rows[0]["AcquirerID"].ToString() != "0")
                                {
                                    AcquirerID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AcquirerID"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReferenceNumber"].ToString() != "0")
                                {
                                    ReferenceNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReferenceNumber"].ToString()) - Incr].ToString();
                                    if (ReferenceNumber == "009218371847")
                                    {

                                    }
                                }
                                if (ds.Tables[0].Rows[0]["CardNumber"].ToString() != "0")
                                {
                                    CardNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CardNumber"].ToString()) - Incr].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["CustAccountNo"].ToString() != "0")
                                {
                                    CustAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CustAccountNo"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["CustAccountNo"].ToString() != "0")
                                {
                                    CustAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CustAccountNo"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["InterchangeAccountNo"].ToString() != "0")
                                {
                                    InterchangeAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["InterchangeAccountNo"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ATMAccountNo"].ToString() != "0")
                                {
                                    ATMAccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ATMAccountNo"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsDateTime"].ToString() != "0")
                                {
                                    TxnsDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsDateTime"].ToString()) - Incr].ToString();
                                    
                                }
                                if (ds.Tables[0].Rows[0]["TxnsDate"].ToString() != "0")
                                {
                                    TxnsDate = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsDate"].ToString()) - Incr].ToString();

                                }
                                if (ds.Tables[0].Rows[0]["TxnsTime"].ToString() != "0")
                                {
                                    TxnsTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsTime"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsAmount"].ToString() != "0")
                                {
                                    TxnsAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Amount1"].ToString() != "0")
                                {
                                    Amount1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Amount1"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["DestinationAmount"].ToString() != "0")
                                {
                                    DestinationAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["DestinationAmount"].ToString()) - Incr].ToString();
                                }                                
                                if (ds.Tables[0].Rows[0]["TxnsSubType"].ToString() != "0")
                                {
                                    TxnsSubType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsSubType"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ChannelType"].ToString() != "0")
                                {
                                    ChannelType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ChannelType"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsNumber"].ToString() != "0")
                                {
                                    TxnsNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsNumber"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsPerticulars"].ToString() != "0")
                                {
                                    TxnsPerticulars = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsPerticulars"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["DrCrType"].ToString() != "0")
                                {
                                    DrCrType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["DrCrType"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ResponseCode1"].ToString() != "0")
                                {
                                    ResponseCode1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode1"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ResponseCode2"].ToString() != "0")
                                {
                                    ResponseCode2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReversalCode1"].ToString() != "0")
                                {
                                    ReversalCode1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReversalCode1"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReversalCode2"].ToString() != "0")
                                {
                                    ReversalCode2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReversalCode2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsPostDateTime"].ToString() != "0")
                                {
                                    TxnsPostDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsPostDateTime"].ToString()) - Incr].ToString();
                                    TxnsPostDateTime = TxnsPostDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsValueDateTime"].ToString() != "0")
                                {
                                    TxnsValueDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsValueDateTime"].ToString()) - Incr].ToString();
                                    TxnsValueDateTime = TxnsValueDateTime.Replace("AM", "").Replace("PM", "").Trim();
                                }
                                if (ds.Tables[0].Rows[0]["AuthCode"].ToString() != "0")
                                {
                                    AuthCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AuthCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ProcessingCode"].ToString() != "0")
                                {
                                    ProcessingCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ProcessingCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["FeeAmount"].ToString() != "0")
                                {
                                    FeeAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["FeeAmount"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["SourceCurrencyCode"].ToString() != "0")
                                {
                                    SourceCurrencyCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SourceCurrencyCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["DestinationCurrencyCode"].ToString() != "0")
                                {
                                    DestinationCurrencyCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["DestinationCurrencyCode"].ToString()) - Incr].ToString();
                                }                                
                                

                                if (ds.Tables[0].Rows[0]["CustBalance"].ToString() != "0")
                                {
                                    CustBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CustBalance"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["InterchangeBalance"].ToString() != "0")
                                {
                                    InterchangeBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["InterchangeBalance"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ATMBalance"].ToString() != "0")
                                {
                                    ATMBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ATMBalance"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["BranchCode"].ToString() != "0")
                                {
                                    BranchCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["BranchCode"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField1"].ToString() != "0")
                                {
                                    ReserveField1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField1"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField2"].ToString() != "0")
                                {
                                    ReserveField2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField2"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField3"].ToString() != "0")
                                {
                                    ReserveField3 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField3"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField4"].ToString() != "0")
                                {
                                    ReserveField4 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField4"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ReserveField5"].ToString() != "0")
                                {
                                    ReserveField5 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField5"].ToString()) - Incr].ToString();
                                }

                                #region StanderedFields
                                string SplitType = ",";
                                int ModeID = 0;
                                int ChannelID = 0;
                                bool ReversalFlag = false;
                                string ResponseCode = string.Empty;
                                string TxnsStatus = string.Empty;
                                string DebitCreditType = string.Empty;
                                string TxnsType = string.Empty;
                                string TxnsSubTypeMain = string.Empty;
                                string TxnsEntryType = string.Empty;
                                string CardType = string.Empty;
                                DateTime? TxnsDateTimeMain;

                                TxnsDateTimeMain = null;
                                DateTime? TxnsPostDateTimeMain;
                                TxnsPostDateTimeMain = null;

                                string[] TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] AcquirerIDArray = dt.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ReversalCode1Array = dt.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ReversalCode2Array = dt.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string ReversalType = dt.Rows[0]["ReversalType"].ToString();
                                string[] ATMType = dt.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] CDMType = dt.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] POSType = dt.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ECOMType = dt.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] IMPType = dt.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] UPIType = dt.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] MicroATMType = dt.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] MobileRechargeType = dt.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] BalanceEnquiry = dt.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] MiniStatement = dt.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] PinChange = dt.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ChequeBookReq = dt.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string ResponseType = dt.Rows[0]["ResponseType"].ToString();
                                string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] ResponseCode2Array = dt.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] OfflineCode = dt.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] TxnDateTime = dt.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] TxnPostDateTime = dt.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] DebitCode = dt.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                                string[] CreditCode = dt.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);


                                bool card = false;
                                bool Terminal = false;
                                bool Acquirer = false;
                                bool Rev1 = false;
                                bool Rev2 = false;
                                bool ATM = false;
                                bool CDM = false;
                                bool POS = false;
                                bool ECOM = false;
                                bool IMPS = false;
                                bool UPI = false;
                                bool MicroATM = false;
                                bool MobileRecharge = false;
                                bool BAL = false;
                                bool MS = false;
                                bool PC = false;
                                bool CB = false;
                                bool RCA1 = false;
                                bool RCA2 = false;
                                bool MC = false;
                                bool VC = false;
                                bool OC = false;
                                bool D = false;
                                bool C = false;


                                #region ValidateField
                                if (TxnsDate != "" && TxnsTime != "")
                                {

                                    if (TxnDateTime[0].ToString() != "")
                                    {
                                        for (int i = 0; i < TxnDateTime.Length; i++)
                                        {
                                            string TxnsDateTimeDiff = TxnsDate + TxnsTime;
                                            if (TxnsDateTimeDiff.Contains("/") || TxnsDateTimeDiff.Contains(".") || TxnsDateTimeDiff.Contains("-"))
                                            {
                                                TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTimeDiff);
                                            }
                                            else
                                            {
                                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                            }
                                        }
                                    }
                                }

                                if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                                {

                                    for (int i = 0; i < TxnDateTime.Length; i++)
                                    {
                                        if (TxnsDateTime.Contains("/") || TxnsDateTime.Contains(".") || TxnsDateTime.Contains("-"))
                                        {
                                            TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTime);
                                        }
                                        else
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                        }

                                    }

                                }

                                if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                                {
                                    for (int i = 0; i < TxnPostDateTime.Length; i++)
                                    {
                                        if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                                        {
                                            TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                                        }
                                        else
                                        {
                                            TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                        }
                                    }
                                }

                                if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "")//&& ReversalCode1 != ""
                                {
                                    for (int i = 0; i < ReversalCode1Array.Length; i++)
                                    {
                                        if (ReserveField1.Contains("Reversal"))
                                        {
                                            Rev1 = true;
                                        }


                                    }
                                }
                                if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                                {
                                    for (int i = 0; i < ReversalCode1Array.Length; i++)
                                    {
                                        if (ReversalCode1Array[i].ToString() == ReversalCode1)
                                        {
                                            Rev1 = true;
                                        }
                                    }
                                    for (int i = 0; i < ReversalCode2Array.Length; i++)
                                    {
                                        if (ReversalCode2Array[i].ToString() == ReversalCode2)
                                        {
                                            Rev2 = true;
                                        }
                                    }
                                }

                                if (ChannelType == "IMPS" || ChannelType == "NFS")
                                {


                                    if (IMPType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < IMPType.Length; i++)
                                        {

                                            IMPS = true;

                                        }
                                    }
                                }
                                else
                                {
                                    if (IMPType[0].ToString() != "")
                                    {
                                        for (int i = 0; i < IMPType.Length; i++)
                                        {
                                            if (IMPType[i].ToString() == ChannelType)
                                            {
                                                IMPS = true;
                                            }
                                        }
                                    }
                                }

                                if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode1 != "")
                                {
                                    for (int i = 0; i < ResponseCode1Array.Length; i++)
                                    {
                                        if (ResponseCode1Array[i].ToString() == ResponseCode1)
                                        {
                                            RCA1 = true;
                                        }
                                    }
                                }
                                if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode1 != "" || ResponseCode2 != "")
                                {
                                    for (int i = 0; i < ResponseCode1Array.Length; i++)
                                    {
                                        if (ResponseCode1Array[i].ToString() == ResponseCode1)
                                        {
                                            RCA1 = true;
                                        }
                                    }

                                    for (int i = 0; i < ResponseCode2Array.Length; i++)
                                    {
                                        if (ResponseCode2Array[i].ToString() == ResponseCode2)
                                        {
                                            RCA2 = true;
                                        }
                                    }
                                }

                                if (ResponseCode1Array[0].ToString() == "")
                                {
                                    RCA1 = true;
                                }


                               

                                if (DebitCode[0].ToString() != "")
                                {
                                    for (int i = 0; i < DebitCode.Length; i++)
                                    {
                                        if (DebitCode[i].ToString() == DrCrType)
                                        {
                                            D = true;
                                        }
                                    }
                                }

                                if (CreditCode[0].ToString() != "")
                                {
                                    for (int i = 0; i < CreditCode.Length; i++)
                                    {
                                        if (CreditCode[i].ToString() == DrCrType)
                                        {
                                            C = true;
                                        }
                                    }
                                }

                                /*
                                if (VISACode[0].ToString() != "" && CardNumber != "")
                                    {
                                    for (int i = 0; i < VISACode.Length; i++)
                                        {
                                        if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                            {
                                            CardType = "VISA";
                                            }
                                        }
                                    }

                                if (MasterCode[0].ToString() != "" && CardNumber != "")
                                    {
                                    for (int i = 0; i < MasterCode.Length; i++)
                                        {
                                        if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                            {
                                            CardType = "MASTER";
                                            }
                                        }
                                    }

                                    */

                                #endregion ValidateField

                                #region InitilizedField

                                if (TxnsSubType.ToUpper().Trim().Contains("INWARD"))
                                {
                                    ModeID = (int)TxnsMode.INWARD;
                                }
                                else if (TxnsSubType.ToUpper().Trim().Contains("INTRA"))
                                {
                                    ModeID = (int)TxnsMode.INTRA;
                                }
                                else
                                {
                                    ModeID = (int)TxnsMode.OUTWARD;
                                }

                                if (Rev1 == true || Rev1 == true && Rev2 == true)
                                {
                                    ReversalFlag = true;
                                }
                                else
                                {
                                    ReversalFlag = false;
                                }

                                if (ATM)
                                {
                                    if (TxnsSubType == "Withdrawal")
                                    {
                                        TxnsSubTypeMain = "Withdrawal";
                                    }
                                    ChannelID = (int)TxnsChannelID.ATM;
                                }

                                if (CDM)
                                {
                                    TxnsSubTypeMain = "Deposit";
                                    ChannelID = (int)TxnsChannelID.ATM;
                                }

                                if (POS)
                                {
                                    ChannelID = (int)TxnsChannelID.POS;
                                    TxnsSubTypeMain = "Purchase";
                                }

                                if (ECOM)
                                {
                                    ChannelID = (int)TxnsChannelID.E_COMMERCE;
                                    TxnsSubTypeMain = "Transfer";
                                }

                                if (IMPS)
                                {
                                    ChannelID = (int)TxnsChannelID.IMPS;
                                    TxnsSubTypeMain = "Transfer";
                                }

                                if (MicroATM)
                                {
                                    ChannelID = (int)TxnsChannelID.MICRO_ATM;
                                    TxnsSubTypeMain = "Withdrawal";
                                }

                                if (MobileRecharge)
                                {
                                    ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                                    TxnsSubTypeMain = "Transfer";
                                }

                                if (UPI)
                                {
                                    ChannelID = (int)TxnsChannelID.UPI;
                                    TxnsSubTypeMain = "Transfer";
                                }

                                if (RCA1 == true)
                                {
                                    ResponseCode = "00";
                                    TxnsStatus = "Sucessfull";
                                }
                                else
                                {
                                    ResponseCode = ResponseCode1;
                                    TxnsStatus = "Unsucessfull";
                                }

                                if (BAL)
                                {
                                    TxnsSubTypeMain = "Balance enquiry";
                                }

                                if (MS)
                                {
                                    TxnsSubTypeMain = "Mini statement";
                                }

                                if (PC)
                                {
                                    TxnsSubTypeMain = "Pin change";
                                }

                                if (CB)
                                {
                                    TxnsSubTypeMain = "Cheque book request";
                                }


                                if (BAL || MS || PC || CB)
                                {
                                    TxnsType = "Non-Financial";
                                }
                                else
                                {
                                    TxnsType = "Financial";
                                }
                                if (OC)
                                {
                                    TxnsEntryType = "Manual";
                                }
                                else
                                {
                                    TxnsEntryType = "Auto";
                                }
                                if (D)
                                {
                                    DebitCreditType = "D";
                                }

                                if (C)
                                {
                                    DebitCreditType = "C";
                                }

                                #endregion InitilizedField


                                #endregion StanderedFields

                                if (ClientID == 49 && ModeID == 4)
                                {
                                    CustAccountNo = InterchangeAccountNo;
                                }
                                 
                                if (CardNumber != "")
                                {
                                    ECardNumber = AesEncryption.EncryptString(CardNumber);
                                }

                                if (CardNumber != "")
                                {
                                    string dummy = "XXXXXXXXXX";
                                    CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();

                                }
                                if (TxnsDateTime != null)
                                {
                                    _DataTable.Rows.Add(ClientID
                                                    , ChannelID
                                                    , ModeID
                                                    , TerminalID
                                                    , ReferenceNumber
                                                    , CardNumber.Trim()
                                                    , CardType
                                                    , CustAccountNo
                                                    , InterchangeAccountNo
                                                    , ATMAccountNo
                                                    , TxnsDateTime
                                                    , Convert.ToDecimal(TxnsAmount)
                                                    , Convert.ToDecimal(Amount1)
                                                    , Convert.ToDecimal(DestinationAmount)
                                                    , Convert.ToDecimal(FeeAmount)
                                                    , TxnsStatus
                                                    , TxnsType
                                                    , TxnsSubTypeMain
                                                    , TxnsEntryType
                                                    , TxnsNumber
                                                    , TxnsPerticulars
                                                    , DebitCreditType
                                                    , ResponseCode
                                                    , ReversalFlag
                                                    , TxnsPostDateTimeMain
                                                    , TxnsPostDateTimeMain
                                                    , AuthCode
                                                    , ProcessingCode                                                    
                                                    ,SourceCurrencyCode
                                                    ,DestinationCurrencyCode
                                                    , Convert.ToDecimal(CustBalance)
                                                    , Convert.ToDecimal(InterchangeBalance)
                                                    , Convert.ToDecimal(ATMBalance)
                                                    , BranchCode
                                                    , ReserveField1
                                                    , ReserveField2
                                                    , ReserveField3
                                                    , ReserveField4
                                                    , ReserveField5
                                                    , RevEntryLeg
                                                    , 0
                                                    , FileName
                                                    , path
                                                    , null
                                                    , DateTime.Now
                                                    , DateTime.Now
                                                    , UserName
                                                    , ""
                                                    , ECardNumber.Trim()
                                                    );
                                }

                            }
                            catch (Exception ex)
                            {
                                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                            }
                            j++;
                        }
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
                objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, FileName, UserName, 'E');
            }
            return _DataTable;

        }

    }
}
