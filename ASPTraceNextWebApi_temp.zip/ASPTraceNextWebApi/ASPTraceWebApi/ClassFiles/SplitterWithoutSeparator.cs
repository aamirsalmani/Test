﻿
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Utility;

namespace ASPTraceWebApi
{
    public class SplitterWithoutSeparator
    { 
        DateTimeConverter objDateTimeConverter = new DateTimeConverter();
        System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");

        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public SplitterWithoutSeparator(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }

        public DataTable SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode, DataTable _DataTable)
        {
            int errorCount = 0;
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
              // ConfigurationSettings.AppSettings["EMekKey1"].ToString();
            string relativePath = _configuration["AppSettings:MekKey2Path"];  //ConfigurationSettings.AppSettings["EMekKey2"].ToString();

            
            

            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            bool TxnAmountIsDecimal = Convert.ToBoolean(dt.Rows[0]["TxnAmountIsDecimal"]);

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            foreach (string line in File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    string line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                    //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                    int Incr = 1;
                    string TerminalID = string.Empty;
                    string AcquirerID = string.Empty;
                    string ReferenceNumber = string.Empty;
                    string CardNumber = string.Empty;
                    string CustAccountNo = string.Empty;
                    string InterchangeAccountNo = string.Empty;
                    string ATMAccountNo = string.Empty;
                    string TxnsDateTime = string.Empty;
                    string TxnsDate = string.Empty;
                    string TxnsTime = string.Empty;
                    string TxnsAmount = "0";
                    string Amount1 = "0";
                    string Amount2 = "0";
                    string Amount3 = "0";
                    string ChannelType = string.Empty;
                    string TxnsSubType = string.Empty;
                    string TxnsNumber = string.Empty;
                    string TxnsPerticulars = string.Empty;
                    string DrCrType = string.Empty;
                    string ResponseCode1 = string.Empty;
                    string ResponseCode2 = string.Empty;
                    string ReversalCode1 = string.Empty;
                    string ReversalCode2 = string.Empty;
                    string TxnsPostDateTime = string.Empty;
                    string TxnsValueDateTime = string.Empty;
                    string AuthCode = string.Empty;
                    string ProcessingCode = string.Empty;
                    string FeeAmount = "0";
                    string CurrencyCode = string.Empty;
                    string CustBalance = "0";
                    string InterchangeBalance = "0";
                    string ATMBalance = "0";
                    string BranchCode = string.Empty;
                    string ReserveField1 = string.Empty;
                    string ReserveField2 = string.Empty;
                    string ReserveField3 = string.Empty;
                    string ReserveField4 = string.Empty;
                    string ReserveField5 = string.Empty;
                    string NoOfDuplicate = string.Empty;
                    string ECardNumber = string.Empty;
                    decimal AMT;

                    if (ds.Tables["TerminalID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalID"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["TerminalID"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["TerminalID"].Rows[0]["Length"].ToString());
                        TerminalID = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["AcquirerID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AcquirerID"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["AcquirerID"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["AcquirerID"].Rows[0]["Length"].ToString());
                        AcquirerID = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReferenceNumber"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ReferenceNumber"].Rows[0]["Length"].ToString());
                        ReferenceNumber = line1.Substring(Start - Incr, End).Trim();
                        if (ReferenceNumber == "304917700236")
                        {

                        }
                    }
                    if (ds.Tables["CardNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardNumber"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["CardNumber"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["CardNumber"].Rows[0]["Length"].ToString());
                        CardNumber = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["CustAccountNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CustAccountNo"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["CustAccountNo"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["CustAccountNo"].Rows[0]["Length"].ToString());
                        CustAccountNo = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["InterchangeAccountNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["InterchangeAccountNo"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["InterchangeAccountNo"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["InterchangeAccountNo"].Rows[0]["Length"].ToString());
                        InterchangeAccountNo = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ATMAccountNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ATMAccountNo"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ATMAccountNo"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ATMAccountNo"].Rows[0]["Length"].ToString());
                        ATMAccountNo = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsDateTime"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["TxnsDateTime"].Rows[0]["Length"].ToString());
                        TxnsDateTime = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["TxnsDate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsDate"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["TxnsDate"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["TxnsDate"].Rows[0]["Length"].ToString());
                        TxnsDate = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["TxnsTime"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsTime"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["TxnsTime"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["TxnsTime"].Rows[0]["Length"].ToString());
                        TxnsTime = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["TxnsAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsAmount"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["TxnsAmount"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["TxnsAmount"].Rows[0]["Length"].ToString());
                        TxnsAmount = line1.Substring(Start - Incr, End).Trim();

                        try
                        {
                            if (TxnAmountIsDecimal == true)
                            {
                                AMT = decimal.Parse(TxnsAmount);
                                decimal AMT1 = (AMT / 100);
                                TxnsAmount = Convert.ToString(AMT1);
                            }
                            else
                            {
                                TxnsAmount = line1.Substring(Start - Incr, End).Trim();
                            }
                        }
                        catch (Exception)
                        {

                        }

                        //if (Convert.ToInt32(ClientID) == 27 || Convert.ToInt32(ClientID) == 9 || Convert.ToInt32(ClientID) == 20)
                        //{
                        //    if (TxnsAmount.Contains('.'))
                        //    {
                        //        TxnsAmount = TxnsAmount.Replace(".", "");
                        //    }
                        //    else
                        //    {
                        //        TxnsAmount = TxnsAmount + "00";
                        //    }
                        //}
                        //TxnsAmount = TxnsAmount.Replace(".", "");
                    }
                    if (ds.Tables["Amount1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Amount1"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["Amount1"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["Amount1"].Rows[0]["Length"].ToString());
                        Amount1 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["Amount2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Amount2"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["Amount2"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["Amount2"].Rows[0]["Length"].ToString());
                        Amount2 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["Amount3"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Amount3"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["Amount3"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["Amount3"].Rows[0]["Length"].ToString());
                        Amount3 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["TxnsSubType"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsSubType"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["TxnsSubType"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["TxnsSubType"].Rows[0]["Length"].ToString());
                        TxnsSubType = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ChannelType"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ChannelType"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ChannelType"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ChannelType"].Rows[0]["Length"].ToString());
                        ChannelType = line1.Trim().Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["TxnsNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsNumber"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["TxnsNumber"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["TxnsNumber"].Rows[0]["Length"].ToString());
                        TxnsNumber = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["TxnsPerticulars"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsPerticulars"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["TxnsPerticulars"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["TxnsPerticulars"].Rows[0]["Length"].ToString());
                        TxnsPerticulars = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["DrCrType"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DrCrType"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["DrCrType"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["DrCrType"].Rows[0]["Length"].ToString());
                        DrCrType = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ResponseCode1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ResponseCode1"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ResponseCode1"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ResponseCode1"].Rows[0]["Length"].ToString());
                        ResponseCode1 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ResponseCode2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ResponseCode2"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ResponseCode2"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ResponseCode2"].Rows[0]["Length"].ToString());
                        ResponseCode2 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ReversalCode1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReversalCode1"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ReversalCode1"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ReversalCode1"].Rows[0]["Length"].ToString());
                        ReversalCode1 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ReversalCode2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReversalCode2"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ReversalCode2"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ReversalCode2"].Rows[0]["Length"].ToString());
                        ReversalCode2 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["TxnsPostDateTime"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsPostDateTime"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["TxnsPostDateTime"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["TxnsPostDateTime"].Rows[0]["Length"].ToString());
                        TxnsPostDateTime = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["TxnsValueDateTime"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsValueDateTime"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["TxnsValueDateTime"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["TxnsValueDateTime"].Rows[0]["Length"].ToString());
                        TxnsValueDateTime = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["AuthCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthCode"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["AuthCode"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["AuthCode"].Rows[0]["Length"].ToString());
                        AuthCode = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ProcessingCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ProcessingCode"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ProcessingCode"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ProcessingCode"].Rows[0]["Length"].ToString());
                        ProcessingCode = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["FeeAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FeeAmount"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["FeeAmount"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["FeeAmount"].Rows[0]["Length"].ToString());
                        FeeAmount = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["CurrencyCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CurrencyCode"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["CurrencyCode"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["CurrencyCode"].Rows[0]["Length"].ToString());
                        CurrencyCode = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["CustBalance"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CustBalance"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["CustBalance"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["CustBalance"].Rows[0]["Length"].ToString());
                        CustBalance = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["InterchangeBalance"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["InterchangeBalance"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["InterchangeBalance"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["InterchangeBalance"].Rows[0]["Length"].ToString());
                        InterchangeBalance = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ATMBalance"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ATMBalance"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ATMBalance"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ATMBalance"].Rows[0]["Length"].ToString());
                        ATMBalance = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["BranchCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BranchCode"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["BranchCode"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["BranchCode"].Rows[0]["Length"].ToString());
                        BranchCode = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ReserveField1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReserveField1"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ReserveField1"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ReserveField1"].Rows[0]["Length"].ToString());
                        ReserveField1 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ReserveField2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReserveField2"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ReserveField2"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ReserveField2"].Rows[0]["Length"].ToString());
                        ReserveField2 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ReserveField3"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReserveField3"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ReserveField3"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ReserveField3"].Rows[0]["Length"].ToString());
                        ReserveField3 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ReserveField4"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReserveField4"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ReserveField4"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ReserveField4"].Rows[0]["Length"].ToString());
                        ReserveField4 = line1.Substring(Start - Incr, End).Trim();
                    }
                    if (ds.Tables["ReserveField5"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReserveField5"].Rows[0]["Length"].ToString() != "0")
                    {
                        int Start = int.Parse(ds.Tables["ReserveField5"].Rows[0]["StartPosition"].ToString());
                        int End = int.Parse(ds.Tables["ReserveField5"].Rows[0]["Length"].ToString());
                        ReserveField5 = line1.Substring(Start - Incr, End).Trim();
                    }

                    if (ReferenceNumber == "225620000529")
                    {

                    }

                    #region StanderedFields
                    string SplitType = ",";
                    int ModeID = 0;
                    int ChannelID = 0;
                    bool ReversalFlag = false;
                    string ResponseCode = string.Empty;
                    string TxnsStatus = string.Empty;
                    string DebitCreditType = string.Empty;
                    string TxnsType = string.Empty;
                    string TxnsSubTypeMain = string.Empty;
                    string TxnsEntryType = string.Empty;
                    string CardType = string.Empty;
                    DateTime? TxnsDateTimeMain;

                    TxnsDateTimeMain = null;
                    DateTime? TxnsPostDateTimeMain;
                    TxnsPostDateTimeMain = null;

                    string[] TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] AcquirerIDArray = dt.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] ReversalCode1Array = dt.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] ReversalCode2Array = dt.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string ReversalType = dt.Rows[0]["ReversalType"].ToString();
                    string[] ATMType = dt.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] CDMType = dt.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] POSType = dt.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] ECOMType = dt.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] IMPType = dt.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] UPIType = dt.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] MicroATMType = dt.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] MobileRechargeType = dt.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] BalanceEnquiry = dt.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] MiniStatement = dt.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] PinChange = dt.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] ChequeBookReq = dt.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string ResponseType = dt.Rows[0]["ResponseType"].ToString();
                    string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] ResponseCode2Array = dt.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] OfflineCode = dt.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] TxnDateTime = dt.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] TxnPostDateTime = dt.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] DebitCode = dt.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                    string[] CreditCode = dt.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);

                    bool card = false;
                    bool Terminal = false;
                    bool Acquirer = false;
                    bool Rev1 = false;
                    bool Rev2 = false;
                    bool ATM = false;
                    bool CDM = false;
                    bool POS = false;
                    bool ECOM = false;
                    bool IMPS = false;
                    bool UPI = false;
                    bool MicroATM = false;
                    bool MobileRecharge = false;
                    bool BAL = false;
                    bool MS = false;
                    bool PC = false;
                    bool CB = false;
                    bool RCA1 = false;
                    bool RCA2 = false;
                    bool MC = false;
                    bool VC = false;
                    bool OC = false;
                    bool D = false;
                    bool C = false;

                    #region ValidateField
                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        if (TxnDateTime[0].ToString() != "")
                        {
                            for (int i = 0; i < TxnDateTime.Length; i++)
                            {
                                string TxnsDateTimeDiff = TxnsDate + TxnsTime;
                                if (TxnsDateTimeDiff.Contains("/") || TxnsDateTimeDiff.Contains(".") || TxnsDateTimeDiff.Contains("-"))
                                {
                                    TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTimeDiff);
                                }
                                else
                                {
                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                }
                            }
                        }
                    }

                    if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                    {
                        for (int i = 0; i < TxnDateTime.Length; i++)
                        {
                            if (TxnsDateTime.Contains("/") || TxnsDateTime.Contains(".") || TxnsDateTime.Contains("-"))
                            {
                                TxnsDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnDateTime[i].ToString(), TxnsDateTime);
                            }
                            else
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[i].ToString(), CultureInfo.InvariantCulture);
                                //TxnsDateTimeMain = Convert.ToDateTime(TxnsDateTime);
                            }
                        }
                    }

                    if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                    {
                        for (int i = 0; i < TxnPostDateTime.Length; i++)
                        {
                            if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                            {
                                TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                            }
                            else
                            {
                                TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), CultureInfo.InvariantCulture);
                            }
                        }
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (int i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                            }
                        }
                    }

                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (int i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (int i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                            {
                                card = true;
                            }
                        }
                    }

                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (int i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                    }

                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (int i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                        for (int i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                            }
                        }
                    }

                    if (ChannelType == "" && TxnsSubType != "")
                    {
                        if (CDMType[0].ToString() != "")
                        {
                            for (int i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (int i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == TxnsSubType)
                                {
                                    POS = true;
                                }
                            }
                        }

                        if (ECOMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == TxnsSubType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (int i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == TxnsSubType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (int i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == TxnsSubType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType || TerminalID.Substring(0, 2) == MicroATMType[i].ToString())
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (int i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }

                    else
                    {
                        if (CDMType[0].ToString() != "")
                        {
                            for (int i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType && TerminalID.Substring(0, 2) != MicroATMType[i].ToString())
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (int i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == ChannelType)
                                {
                                    POS = true;
                                }
                            }
                        }

                        if (ECOMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == ChannelType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (int i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == ChannelType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (int i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == ChannelType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType || TerminalID.Substring(0, 2) == MicroATMType[i].ToString())
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (int i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }

                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (int i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (int i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (int i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (int i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode1 != "")
                    {
                        for (int i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                            }
                        }
                    }

                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode1 != "" || ResponseCode2 != "")
                    {
                        for (int i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                            }
                        }

                        for (int i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode2)
                            {
                                RCA2 = true;
                            }
                        }
                    }

                    if (ResponseCode1Array[0].ToString() == "")
                    {
                        RCA1 = true;
                    }

                    try
                    {
                        if (reNum.Match(CardNumber.Substring(0, 6)).Success)
                        {
                            
                        }
                    }
                    catch (Exception)
                    {

                    }

                    if (DebitCode[0].ToString() != "")
                    {
                        for (int i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (int i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                            }
                        }
                    }

                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (int i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (int i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    if (IMPS == true || UPI == true)
                    {
                        Terminal = false;
                        if (TxnsSubType == "IIN" || TxnsSubType == "UIN")
                        {
                            ModeID = (int)TxnsMode.INWARD;
                        }
                        if (TxnsSubType == "INT")
                        {
                            ModeID = (int)TxnsMode.INTRA;
                        }
                        if (TxnsSubType == "IOW" || TxnsSubType == "UOUT" || TxnsSubType == "UOW")
                        {
                            ModeID = (int)TxnsMode.OUTWARD;
                        }

                    }

                    if (AcquirerID == string.Empty || AcquirerID == "" || AcquirerIDArray[0].ToString() == "")
                    {
                        if (Terminal == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Terminal == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Terminal == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }

                    else
                    {
                        if (Acquirer == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Acquirer == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Acquirer == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }

                    if (ClientID == 20 || ClientID == 27)
                    {
                        if (TxnsSubType.ToUpper() == "INWARD")
                        {
                            ModeID = (int)TxnsMode.INWARD;
                        }
                        if (TxnsSubType.ToUpper() == "OUTWARD")
                        {
                            ModeID = (int)TxnsMode.OUTWARD;
                        }
                    }

                    else
                    {
                        if (ClientID != 45)
                        {
                            if ((ChannelType == "I" || ChannelType.StartsWith("I")) && (ChannelType != "IWT"))
                            {
                                ModeID = (int)TxnsMode.INWARD;
                            }
                            if (ChannelType == "A" || ChannelType.StartsWith("O"))
                            {
                                ModeID = (int)TxnsMode.OUTWARD;
                            }
                            if (ChannelType == "INTRA")
                            {
                                ModeID = (int)TxnsMode.INTRA;
                            }
                        }
                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }

                    else
                    {
                        ReversalFlag = false;
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (POS)
                    {
                        ChannelID = (int)TxnsChannelID.POS;
                        TxnsSubTypeMain = "Purchase";
                    }

                    if (ECOM)
                    {
                        ChannelID = (int)TxnsChannelID.E_COMMERCE;
                        TxnsSubTypeMain = "Purchase";
                    }

                    if (IMPS)
                    {
                        ChannelID = (int)TxnsChannelID.IMPS;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (MicroATM)
                    {
                        ChannelID = (int)TxnsChannelID.MICRO_ATM;
                        TxnsSubTypeMain = "Withdrawal";
                    }

                    if (MobileRecharge)
                    {
                        ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (UPI)
                    {
                        ChannelID = (int)TxnsChannelID.UPI;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (RCA1 == true || RCA1 == true && RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }

                    else
                    {
                        ResponseCode = "99";
                        TxnsStatus = "Unsucessfull";
                    }

                    if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }

                    if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }

                    if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }

                    if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }

                    if (BAL || MS || PC || CB)
                    {
                        TxnsType = "Non-Financial";
                    }
                    else
                    {
                        TxnsType = "Financial";
                    }

                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }

                    else
                    {
                        TxnsEntryType = "Auto";
                    }

                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    #endregion InitilizedField

                    #endregion StanderedFields

                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }
                    
                    if (CardNumber != "" && CardNumber.Length < 16)
                    {
                        CardNumber = "";
                    }
                    
                    if (CardNumber != "" && CardNumber.Length == 16)
                    {
                        string dummy = "XXXXXXXXXX";
                        CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                    }

                    _DataTable.Rows.Add(ClientID
                                    , ChannelID
                                    , ModeID
                                    , TerminalID
                                    , ReferenceNumber
                                    , CardNumber.Trim()
                                    , CardType
                                    , CustAccountNo
                                    , InterchangeAccountNo
                                    , ATMAccountNo
                                    , TxnsDateTimeMain
                                    , Convert.ToDecimal(TxnsAmount)
                                    , Convert.ToDecimal(Amount1)
                                    , Convert.ToDecimal(Amount2)
                                    , Convert.ToDecimal(Amount3)
                                    , TxnsStatus
                                    , TxnsType
                                    , TxnsSubTypeMain
                                    , TxnsEntryType
                                    , TxnsNumber
                                    , TxnsPerticulars
                                    , DebitCreditType
                                    , ResponseCode
                                    , ReversalFlag
                                    , TxnsPostDateTimeMain
                                    , TxnsPostDateTimeMain
                                    , AuthCode
                                    , ProcessingCode
                                    , Convert.ToDecimal(FeeAmount)
                                    , CurrencyCode
                                    , Convert.ToDecimal(CustBalance)
                                    , Convert.ToDecimal(InterchangeBalance)
                                    , Convert.ToDecimal(ATMBalance)
                                    , BranchCode
                                    , ReserveField1
                                    , ReserveField2
                                    , ReserveField3
                                    , ReserveField4
                                    , ReserveField5
                                    , RevEntryLeg
                                    , 0
                                    , FileName
                                    , path
                                    , null
                                    , DateTime.Now
                                    , DateTime.Now
                                    , UserName
                                    , ""
                                    , ECardNumber.Trim()
                                    );
                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    errorCount++;
                    objCommon.InsertLogs(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;

        }
    }
}
