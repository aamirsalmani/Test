﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ASPTraceWebApi
{
    public class SwitchBBPSFileSplitter
    {
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon objCommon;

        public SwitchBBPSFileSplitter()
        {

        }

        public SwitchBBPSFileSplitter(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objCommon = _Common;
        }
        public DataTable SWFile_BBPS_Process(string FilePath, DataTable _DataTable, string UserName, string BankCode, string FileName, out int InsertCount, out int TotalCount)
        {
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataSet ds = new DataSet();
            try
            {
                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
               "Data Source=" + FilePath + ";Extended Properties=Excel 8.0;";
                string extension = Path.GetExtension(FilePath);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03                     
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FilePath + ";Extended Properties='Excel 8.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                }

                try
                {
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }
                catch
                {
                    switch (extension.ToLower())
                    {
                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FilePath + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }

                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                int j = 0;

                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    excelSheets[j] = row["TABLE_NAME"].ToString();
                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                    OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataTable dtSheet = new DataTable();
                    da.Fill(dtSheet);
                    objConn.Close();
                    if (dtSheet.Rows.Count > 1)
                    {
                        for (int k = 1; k < dtSheet.Rows.Count; k++)
                        {

                            string ClientID = string.Empty;
                            string ChannelID = string.Empty;
                            string ModeID = string.Empty;
                            string TransID = string.Empty;
                            string CCTransID = string.Empty;
                            string PartnerReferenceNumber = string.Empty;
                            string TerminalID = string.Empty;
                            string BankName = string.Empty;
                            string FranchiseID = string.Empty;
                            string FranchiseName = string.Empty;
                            string BCAgentId = string.Empty;
                            string AgentName = string.Empty;
                            string BillNumber = string.Empty;
                            string BillCat = string.Empty;
                            string BillerName = string.Empty;
                            DateTime? TransDate = null;
                            decimal? TransAmount = 0;
                            string TransType = string.Empty;
                            decimal? CCF = 0;
                            decimal? BaseAmount = 0;
                            decimal? GST = 0;
                            decimal? GrossAmount = 0;
                            string TransStatus = string.Empty;
                            string ConsumerNo = string.Empty;
                            string DateSortID = string.Empty;
                            string BillerID = string.Empty;
                            string BillerCoverage = string.Empty;
                            string BillType = string.Empty;
                            decimal CCFGST = 0;
                            string CCAResponseCode = string.Empty;
                            string NPCIResponseCode = string.Empty;
                            string ChannelPartnerRefNo = string.Empty;
                            string DeviceType = string.Empty;
                            string State = string.Empty;
                            string City = string.Empty;
                            string Area = string.Empty;
                            string Pincode = string.Empty;
                            string Tdate = string.Empty;


                            try
                            {
                                ClientID = BankCode;
                                TransType = dtSheet.Rows[k][0].ToString().Trim();
                                BillCat = dtSheet.Rows[k][1].ToString().Trim();
                                BillerName = dtSheet.Rows[k][3].ToString().Trim();
                                BillNumber = dtSheet.Rows[k][5].ToString().Trim();
                                ConsumerNo = dtSheet.Rows[k][6].ToString().Trim();
                                TransID = dtSheet.Rows[k][8].ToString().Trim();
                                CCTransID = dtSheet.Rows[k][9].ToString().Trim();
                                PartnerReferenceNumber = dtSheet.Rows[k][10].ToString().Trim();

                                Tdate = dtSheet.Rows[k][11].ToString().Trim() + " " + dtSheet.Rows[k][12].ToString().Trim();
                                TransDate = DateTime.ParseExact(Tdate, new[] { "MM-dd-yyyy HH:mm", "dd-MM-yyyy HH:mm"
                                   , "dd/MM/yyyy HH:mm", "dd-MM-yyyy hhmmss", "ddMMyy" }, null, System.Globalization.DateTimeStyles.None);

                                TransAmount = Convert.ToDecimal(dtSheet.Rows[k][13].ToString().Trim());
                                BaseAmount = Convert.ToDecimal(dtSheet.Rows[k][15].ToString().Trim());
                                GST = Convert.ToDecimal(dtSheet.Rows[k][16].ToString().Trim());
                                GrossAmount = Convert.ToDecimal(dtSheet.Rows[k][17].ToString().Trim());
                                TerminalID = dtSheet.Rows[k][22].ToString().Trim();
                                BCAgentId = dtSheet.Rows[k][24].ToString().Trim();
                                AgentName = dtSheet.Rows[k][25].ToString().Trim();
                                FranchiseID = dtSheet.Rows[k][26].ToString().Trim();
                                FranchiseName = dtSheet.Rows[k][27].ToString().Trim();
                                BankName = dtSheet.Rows[k][28].ToString().Trim();


                                BillerID = dtSheet.Rows[k][2].ToString().Trim();
                                BillerCoverage = dtSheet.Rows[k][4].ToString().Trim();
                                BillType = dtSheet.Rows[k][7].ToString().Trim();
                                CCFGST = Convert.ToDecimal(dtSheet.Rows[k][14].ToString().Trim());
                                CCAResponseCode = dtSheet.Rows[k][18].ToString().Trim();
                                NPCIResponseCode = dtSheet.Rows[k][20].ToString().Trim();
                                ChannelPartnerRefNo = dtSheet.Rows[k][21].ToString().Trim();
                                DeviceType = dtSheet.Rows[k][23].ToString().Trim();
                                State = dtSheet.Rows[k][29].ToString().Trim();
                                City = dtSheet.Rows[k][30].ToString().Trim();
                                Area = dtSheet.Rows[k][31].ToString().Trim();
                                Pincode = dtSheet.Rows[k][32].ToString().Trim();

                                if (NPCIResponseCode == "00")
                                {
                                    TransStatus = "Successful";

                                }
                                else
                                {
                                    TransStatus = dtSheet.Rows[k][19].ToString().Trim();
                                }

                            }
                            catch (Exception ex)
                            {
                            }
                            LineNo++;

                            _DataTable.Rows.Add(ClientID, ChannelID, ModeID
                                                  , TransID
                                                  , CCTransID
                                                  , PartnerReferenceNumber
                                                  , TerminalID
                                                  , BankName
                                                  , FranchiseID
                                                  , FranchiseName
                                                  , BCAgentId
                                                  , AgentName
                                                  , BillNumber
                                                  , BillCat
                                                  , BillerName
                                                  , TransDate
                                                  , TransAmount
                                                  , TransType
                                                  , CCF
                                                  , BaseAmount
                                                  , GST
                                                  , GrossAmount
                                                  , TransStatus
                                                  , ConsumerNo
                                                  , DateSortID,
                                                  System.DateTime.Now,
                                                  UserName,
                                                  System.DateTime.Now,
                                                  UserName,
                                                  FileName,
                                                  FilePath
                                                  , BillerID
                                                  , BillerCoverage
                                                  , BillType
                                                  , CCFGST
                                                  , CCAResponseCode
                                                  , NPCIResponseCode
                                                  , ChannelPartnerRefNo
                                                  , DeviceType
                                                  , State
                                                  , City
                                                  , Area
                                                  , Pincode
                                               );

                            InsertCount++;

                        }
                    }
                    j++;
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {

                objCommon.InsertLogs(ex.Message.ToString(), BankCode, "SwitchBBPSFileSplitter.cs", "SWFile_BBPS_Process", LineNo, FileName, UserName, 'E');

            }
            return _DataTable;
        }
    }
}
