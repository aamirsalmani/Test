﻿using ASPTrace.Contracts;
using ASPTrace.Models;
using DocumentFormat.OpenXml.Drawing;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AlertConfigController : ControllerBase
    {
        private readonly IAlertConfig _objAlertConfig;

        public AlertConfigController(IAlertConfig objAlertConfig)
        {
            _objAlertConfig = objAlertConfig;
        }

        [Route("[action]")]
        [HttpPost]
        public object SaveAlertConfig([FromBody] SaveAlertConfigRequest saveAlertConfigRequest)
        {
            string Result = string.Empty;
            try
            {
                var alertTable = CleanAndMapAlertToDataTable(saveAlertConfigRequest);

                var escalationTable = CleanAndMapEscalationsToDataTable(saveAlertConfigRequest.escalations, saveAlertConfigRequest.alertName,saveAlertConfigRequest.userName?.Trim());

                Result = _objAlertConfig.SaveAlertConfig(alertTable, escalationTable);
            }
            catch (Exception ex)
            {
                return "Error occurred in API";
            }
            return Result;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetAlertConfigData([FromBody] AlertFilterModel filter)
        {
            return _objAlertConfig.GetAlertConfigDataList(filter.ClientID, filter.AlertTypeID, filter.AlertSeverityID, filter.CreatedBy);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAdditionalDataByAlertID(int AlertID , string Type)
        {
            return _objAlertConfig.GetAdditionalDataByAlertID(AlertID , Type);
        }


        private DataTable CleanAndMapAlertToDataTable(SaveAlertConfigRequest req)
        {
            var dt = new DataTable();
            dt.Columns.Add("ClientID", typeof(string));
            dt.Columns.Add("AlertTypeID", typeof(string));
            dt.Columns.Add("AlertName", typeof(string));
            dt.Columns.Add("AlertSeverityID", typeof(string));
            dt.Columns.Add("Description", typeof(string));
            dt.Columns.Add("SpName", typeof(string));
            dt.Columns.Add("ScheduleTypeID", typeof(string));
            dt.Columns.Add("MonthsCsv", typeof(string));
            dt.Columns.Add("DaysCsv", typeof(string));
            dt.Columns.Add("HoursCsv", typeof(string));
            dt.Columns.Add("MinutesCsv", typeof(string));
            dt.Columns.Add("ChannelsCsv", typeof(string));
            dt.Columns.Add("EmailRecipients", typeof(string));
            dt.Columns.Add("EmailSubject", typeof(string));
            dt.Columns.Add("EmailBody", typeof(string));
            dt.Columns.Add("EmailFooter", typeof(string));
            dt.Columns.Add("SmsRecipients", typeof(string));
            dt.Columns.Add("SmsBody", typeof(string));
            dt.Columns.Add("SmsFooter", typeof(string));
            dt.Columns.Add("IsEscalationEnabled", typeof(bool));
            dt.Columns.Add("UserName", typeof(string));

            dt.Rows.Add(
                req.clientID?.Trim(),
                req.alertTypeID?.Trim(),
                req.alertName?.Trim(),
                req.alertSeverityID?.Trim(),
                req.description?.Trim(),
                req.spName?.Trim(),
                req.scheduleTypeID?.Trim(),
                string.Join(",", req.scheduleConfig?.months?.Select(m => m?.Trim()) ?? new List<string>()),
                string.Join(",", req.scheduleConfig?.days?.Select(d => d?.Trim()) ?? new List<string>()),
                string.Join(",", req.scheduleConfig?.hours?.Select(h => h?.Trim()) ?? new List<string>()),
                string.Join(",", req.scheduleConfig?.minutes?.Select(m => m?.Trim()) ?? new List<string>()),
                string.Join(",", req.channels?.Select(c => c.channelID?.Trim()) ?? new List<string>()),
                (req.emailConfig?.recipients ?? "").Trim().TrimEnd(','),
                req.emailConfig?.subject?.Trim() ?? "",
                req.emailConfig?.body?.Trim() ?? "",
                req.emailConfig?.footer?.Trim() ?? "",
                (req.smsConfig?.recipients ?? "").Trim().TrimEnd(','),
                req.smsConfig?.body?.Trim() ?? "",
                req.smsConfig?.footer?.Trim() ?? "",
                req.isEscalationEnabled,
                req.userName?.Trim()
            );

            return dt;
        }

        private DataTable CleanAndMapEscalationsToDataTable(List<EscalationConfig> escalations, string alertName, string userName)
        {
            var dt = new DataTable();
            dt.Columns.Add("AlertName", typeof(string));
            dt.Columns.Add("Level", typeof(int));
            dt.Columns.Add("UserID", typeof(string));
            dt.Columns.Add("DelayType", typeof(string));
            dt.Columns.Add("Month", typeof(string));
            dt.Columns.Add("Day", typeof(string));
            dt.Columns.Add("Hour", typeof(string));
            dt.Columns.Add("Minute", typeof(string));
            dt.Columns.Add("ChannelsCsv", typeof(string));
            dt.Columns.Add("EmailRecipients", typeof(string));
            dt.Columns.Add("EmailSubject", typeof(string));
            dt.Columns.Add("EmailBody", typeof(string));
            dt.Columns.Add("EmailFooter", typeof(string));
            dt.Columns.Add("SmsRecipients", typeof(string));
            dt.Columns.Add("SmsBody", typeof(string));
            dt.Columns.Add("SmsFooter", typeof(string));
            dt.Columns.Add("UserName", typeof(string));

            if (escalations == null) return dt;

            foreach (var esc in escalations)
            {
                dt.Rows.Add(
                    alertName,
                    esc.level,
                    esc.userID?.Trim(),
                    esc.delayType?.Trim(),
                    esc.month?.Trim(),
                    esc.day?.Trim(),
                    esc.hour?.Trim(),
                    esc.minute?.Trim(),
                    string.Join(",", esc.channels?.Select(c => c.channelID?.Trim()) ?? new List<string>()),
                    (esc.emailConfig?.recipients ?? "").Trim().TrimEnd(','),
                    esc.emailConfig?.subject?.Trim() ?? "",
                    esc.emailConfig?.body?.Trim() ?? "",
                    esc.emailConfig?.footer?.Trim() ?? "",
                    (esc.smsConfig?.recipients ?? "").Trim().TrimEnd(','),
                    esc.smsConfig?.body?.Trim() ?? "",
                    esc.smsConfig?.footer?.Trim() ?? "",
                    userName
                );
            }

            return dt;
        }
    }
}
