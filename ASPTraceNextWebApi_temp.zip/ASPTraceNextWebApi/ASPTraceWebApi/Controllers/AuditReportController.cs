﻿
 
using ASPTrace.Contracts;
using ASPTrace.Models;
using ASPTraceWebApi.ClassFiles;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc; 
using Newtonsoft.Json;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Data;
using System.Text;
using System.Text.Json;
using Utility; 

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class AuditReportController : ControllerBase
    {
        private readonly IAuditReport _objAuditReport;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;
        public AuditReportController(IAuditReport objAuditReport, IConfiguration Configuration, ASPTrace.Contracts.ICommon Common)
        {
            _objAuditReport = objAuditReport;
            _configuration = Configuration;
            _objCommon = Common;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetATMChargesReportDetailsList(ATMChargesReportModel aTMChargesReportModel)
        {
            return _objAuditReport.GetATMChargesReportDetails(aTMChargesReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetBankSettlementReportDetailsList(BankReportModel bankSettlementReportModel)
        {
            System.Data.DataTable dt = _objAuditReport.GetBankSettlementReportDetails(bankSettlementReportModel);

            DynamicTable dynamicTable = new DynamicTable();

            dynamicTable.Columns = Common.GetColumns(dt);

            dynamicTable.JsonData = Common.DataTableToJSONWithJSONNet(dt);

            return dynamicTable;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetSettledTransactionsReportList(SettledTransactionsReportModel settledTransactionsReportModel)
        {
            List<SettledTransactionsReportDetailsModel> settledTransactionsReportDetailsList = _objAuditReport.GetSettledTransactionsReport(settledTransactionsReportModel);
            
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();            
            

            foreach (SettledTransactionsReportDetailsModel settledTransactionsReportDetailsModel in settledTransactionsReportDetailsList)
            {
                try
                {
                    settledTransactionsReportDetailsModel.CardNumber = AesEncryption.DecryptString(settledTransactionsReportDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            return settledTransactionsReportDetailsList;

        }

        [Route("[action]")]
        [HttpPost]
        public object GetSettledTransactionsReportByReferenceNumberList(SettledTransactionsReportModel settledTransactionsReportModel)
        {
            SettledTransactionsReportByReferenceNumber settledTransactionsReportByReferenceNumbers = _objAuditReport.GetSettledTransactionsReportByReferenceNumber(settledTransactionsReportModel);
             
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim(); 

            foreach (SettledTransactionsReportDetails1Model settledTransactionsReportDetails1Model in settledTransactionsReportByReferenceNumbers.EJTxnDetails)
            {
                try
                {
                    settledTransactionsReportDetails1Model.CardNumber = AesEncryption.DecryptString(settledTransactionsReportDetails1Model.CardNumber);
                }
                catch
                {

                }
            }

            foreach (SettledTransactionsReportDetails1Model settledTransactionsReportDetails1Model in settledTransactionsReportByReferenceNumbers.GLTxnDetails)
            {
                try
                {
                    settledTransactionsReportDetails1Model.CardNumber = AesEncryption.DecryptString(settledTransactionsReportDetails1Model.CardNumber);
                }
                catch
                {

                }
            }

            foreach (SettledTransactionsReportDetails1Model settledTransactionsReportDetails1Model in settledTransactionsReportByReferenceNumbers.NWTxnDetails)
            {
                try
                {
                    settledTransactionsReportDetails1Model.CardNumber = AesEncryption.DecryptString(settledTransactionsReportDetails1Model.CardNumber);
                }
                catch
                {

                }
            }

            foreach (SettledTransactionsReportDetails1Model settledTransactionsReportDetails1Model in settledTransactionsReportByReferenceNumbers.SWTxnDetails)
            {
                try
                {
                    settledTransactionsReportDetails1Model.CardNumber = AesEncryption.DecryptString(settledTransactionsReportDetails1Model.CardNumber);
                }
                catch
                {

                }
            }
            return settledTransactionsReportByReferenceNumbers;

        }

        [Route("[action]")]
        [HttpPost]
        public object GetUPISettlementReportDetailsList(UPISettlementReportModel uPISettlementReportModel)
        { 
            System.Data.DataTable dt = _objAuditReport.GetUPISettlementReportDetails(uPISettlementReportModel);

            DynamicTable dynamicTable = new DynamicTable();

            dynamicTable.Columns = Common.GetColumns(dt);

            dynamicTable.JsonData = Common.DataTableToJSONWithJSONNet(dt);

            return dynamicTable;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetRefundTxnsReportDetailsList(RefundTxnsReportModel refundTxnsReportModel)
        {
            List<RefundTxnsReportDetailsModel> refundTxnsReportDetailsModelList = _objAuditReport.GetRefundTxnsReportDetails(refundTxnsReportModel);
 
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim(); 

            foreach (RefundTxnsReportDetailsModel refundTxnsReportDetailsModel in refundTxnsReportDetailsModelList)
            {
                try
                {
                    refundTxnsReportDetailsModel.CardNo = AesEncryption.DecryptString(refundTxnsReportDetailsModel.CardNo);
                }
                catch
                {

                }
            }

            return refundTxnsReportDetailsModelList;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetPOSSettlementReportDetailsList(POSSettlementReportModel pOSSettlementReportModel)
        {
            return _objAuditReport.GetPOSSettlementReportDetails(pOSSettlementReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetIMPSSettlementReportDetailsList(IMPSSettlementReportModel iMPSSettlementReportModel)
        {
            System.Data.DataTable dt = _objAuditReport.GetIMPSSettlementReport(iMPSSettlementReportModel);

            DynamicTable dynamicTable = new DynamicTable();

            dynamicTable.Columns = Common.GetColumns(dt);

            dynamicTable.JsonData = Common.DataTableToJSONWithJSONNet(dt);

            return dynamicTable;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetAdjustmentTxnsReportList(AdjustmentTxnsModel adjustmentTxnsModel)
        {
            return _objAuditReport.GetAdjustmentTxnsReport(adjustmentTxnsModel); 
        }

        //File Status Report
        [Route("[action]")]
        [HttpPost]
        public object GetFileStatusReportDetailsList(FileStatusModel fileStatusReportModel)
        {
            return _objAuditReport.GetFileStatusReportDetails(fileStatusReportModel);
        }

        //NPCI Bulk Upload 
        [Route("[action]")]
        [HttpPost]
        public object GetNPCIBulkUploadDetailsList(NPCIBulkUploadModel npciBulkUploadModel)
        {
            return _objAuditReport.GetNPCIBulkUploadDetails(npciBulkUploadModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetBankFormatSettlementReports(BankReportModel upiBankFormatSettlementInputModel)
        {
            ASPTrace.Models.DynamicTable dynamicTable = new ASPTrace.Models.DynamicTable();

            System.Data.DataSet ds = null;

            if (upiBankFormatSettlementInputModel.ReportType == "UPI")
            {
                ds = _objAuditReport.GetBankFormatSettlementdetailsUPI(upiBankFormatSettlementInputModel);

            }
            else if (upiBankFormatSettlementInputModel.ReportType == "IMPS")
            {
                ds = _objAuditReport.GetBankFormatSettlementdetailsIMPS(upiBankFormatSettlementInputModel);
            }

            if (ds != null && ds.Tables.Count > 1)
            {
                dynamicTable.Columns = Common.GetColumns(ds.Tables[0]);

                DataTable dt1 = ds.Tables[0];

                dt1.Merge(ds.Tables[1]);

                dynamicTable.JsonData = Common.DataTableToJSONWithJSONNet(dt1);

            }

            return dynamicTable;
        }

        [Route("[action]")]
        [HttpPost]
        public string ReUploadStatusChange([FromBody] FileData fileData)
        {
            return _objAuditReport.ChangeUploadStatus(fileData.fileName);
        }



        //------------------------ BY KUNDAN --------------------------------


        //Export Raw Data
        [Route("[action]")]
        [HttpPost]
        public object GetExportRawDataDetailsList(ExportRawDataModel exportRawDataModel)
        {
            
            DataTable dataTable = _objAuditReport.GetExportRawDataDetails(exportRawDataModel);
            JsonDocument jsonDocument = JsonDocument.Parse(dataTable.ToJson());
            return jsonDocument.RootElement;
        }

        [Route("[action]")]
        [HttpPost]
        public object ExportExcelReportKS(DownloadRawDataModel downloadRawDataModel)
        {

            DataTable Report = _objAuditReport.ExportExcelReportKS(downloadRawDataModel); 
            // Debugging point to check column count
            Console.WriteLine($"Number of columns in Report DataTable: {Report.Columns.Count}"); 

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                // Debugging point
                Console.WriteLine($"Number of columns in Report DataTable: {Report.Columns.Count}");

                // Load the DataTable into the worksheet, starting from cell A1  //typeof(UnmatchedTxnsReportModel).GetProperties().Length
                worksheet.Cells["A1"].LoadFromDataTable(Report, PrintHeaders: true);

                using (var range = worksheet.Cells[1, 1, 1, Report.Columns.Count])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightBlue);
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                // Format all cells with borders  //typeof(UnmatchedTxnsReportModel).GetProperties().Length]
                using (var range = worksheet.Cells[1, 1, Report.Rows.Count + 1, Report.Columns.Count])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }


                // Convert the package to a byte array
                byte[] fileContents = package.GetAsByteArray();

                // Return the Excel file as a download
                return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"RawDataTxnsReport_{downloadRawDataModel.TR_POSTDATE}.xlsx");
            }

        }
        [Route("[action]")]
        [HttpPost]

        public object ExportCsvReportKS(DownloadRawDataModel downloadRawDataModel)
        {

            DataTable Reporttbl = _objAuditReport.ExportCsvReportKS(downloadRawDataModel);  

            var csv = GenerateCsv(Reporttbl);

            var bytes = Encoding.UTF8.GetBytes(csv);
            return File(bytes, "text/csv", $"RawDataTxnsReport_{downloadRawDataModel.TR_POSTDATE}.csv");


        }

        private string GenerateCsv(DataTable table)
        {
            var sb = new StringBuilder();

            // Add the column headers
            IEnumerable<string> columnNames = table.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
            sb.AppendLine(string.Join(",", columnNames));

            // Add the rows
            foreach (DataRow row in table.Rows)
            {
                IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                sb.AppendLine(string.Join(",", fields));
            }

            return sb.ToString();
        }

        [Route("[action]")]
        [HttpGet]
        public List<logTypeModel> GetLogFileList(string ChannelID)
        {
            List<logTypeModel> data = new List<logTypeModel>();
            data = _objAuditReport.GetLogList(ChannelID);
            return data;

        }

        //------------------------ BY KUNDAN --------------------------------

        [Route("[action]")]
        [HttpPost]
        public object GetGLReconReport(GLReconModel GLReconModel)
        {
            DataSet GLReconReport = _objAuditReport.GetGLReconReport(GLReconModel);

            return JsonConvert.SerializeObject(GLReconReport);

        }

        //------------------------ BY KUNDAN --------------------------------

        [Route("[action]")]
        [HttpPost]
        public object ExportExcelGLReconReport(GLReconModel GLReconModel)
        {

            DataSet GLReconReports = _objAuditReport.GetGLReconReport(GLReconModel); 
            
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            int count = 0;
            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("GLReconReport");
                int currentRow = 1;

                foreach (DataTable GLReconReport in GLReconReports.Tables)
                {
                    // Load the DataTable into the worksheet, starting from the current row
                    worksheet.Cells[currentRow, 1].LoadFromDataTable(GLReconReport, PrintHeaders: true);

                    // Format the header row
                    using (var range = worksheet.Cells[currentRow, 1, currentRow, GLReconReport.Columns.Count])
                    {
                        range.Style.Font.Bold = true;
                        range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightBlue);
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    }

                    // Format all cells with borders
                    using (var range = worksheet.Cells[currentRow, 1, currentRow + GLReconReport.Rows.Count, GLReconReport.Columns.Count])
                    {
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    }
                    foreach (DataColumn column in GLReconReport.Columns)
                    {
                        if (column.DataType == typeof(DateTime))
                        {
                            int colIndex = column.Ordinal + 1;
                            worksheet.Cells[currentRow + 1, colIndex, currentRow + GLReconReport.Rows.Count, colIndex].Style.Numberformat.Format = "yyyy-mm-dd";
                        }
                    }
                    // Update the current row to be 4 rows below the last row of the current table
                    currentRow += GLReconReport.Rows.Count + 5; // Adding 5 to leave a space of 4 rows
                }



                // Convert the package to a byte array
                byte[] fileContents = package.GetAsByteArray();

                // Return the Excel file as a download
                return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"UnmatchedTxnsReport_{GLReconModel.FromDateTxns}.xlsx");
            }

        }


    }
}