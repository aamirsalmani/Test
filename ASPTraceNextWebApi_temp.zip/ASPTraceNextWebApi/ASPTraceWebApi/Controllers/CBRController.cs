﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;
using OfficeOpenXml.Style;
using OfficeOpenXml;
using System.Data;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.Drawing;
using Utility;

namespace TraceReact.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CBRController : ControllerBase
    {
        private readonly ICBR _objCBR;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;

        public CBRController(ICBR objCBR, IConfiguration Configuration, ASPTrace.Contracts.ICommon Common)
        {
            _objCBR = objCBR;
            _configuration = Configuration;
            _objCommon = Common;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetC3RReportDetailsList(C3RReportModel c3RReportModel)
        {
            return _objCBR.GetC3RReportDetails(c3RReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetCBRReportDetailsList(CBRReportModel cBRReportModel)
        {
            return _objCBR.GetCBRReportDetails(cBRReportModel);
        }



        [Route("[action]")]
        [HttpPost]
        public object GetCBRMissingDatalist(CBRMissingReportModel CBRMissingModel)
        {
            return _objCBR.GetCBRMissingData(CBRMissingModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetCBROpeningClosingList(C3RReportModel c3RReportModel)
        {
            return _objCBR.GetCBROpeningClosingDetails(c3RReportModel);
        }

        ////------------------------ BY KUNDAN --------------------------------

        [Route("[action]")]
        [HttpPost]
        public object ExportExcelReportCBRM(CBRMissingReportModelData cBRMissingReportModelData)
        {

            DataTable Report = _objCBR.CBRmissingDataTable(cBRMissingReportModelData);
            // Debugging point to check column count
            Console.WriteLine($"Number of columns in Report DataTable: {Report.Columns.Count}"); 

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                // Debugging point
                Console.WriteLine($"Number of columns in Report DataTable: {Report.Columns.Count}");

                // Load the DataTable into the worksheet, starting from cell A1  //typeof(UnmatchedTxnsReportModel).GetProperties().Length
                worksheet.Cells["A1"].LoadFromDataTable(Report, PrintHeaders: true);

                using (var range = worksheet.Cells[1, 1, 1, Report.Columns.Count])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(Color.LightBlue);
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                // Format all cells with borders  //typeof(UnmatchedTxnsReportModel).GetProperties().Length]
                using (var range = worksheet.Cells[1, 1, Report.Rows.Count + 1, Report.Columns.Count])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }


                // Convert the package to a byte array
                byte[] fileContents = package.GetAsByteArray();

                // Return the Excel file as a download
                return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"CBRmissingReport_{cBRMissingReportModelData.FROMDATE}.xlsx");
            }

        }
        [Route("[action]")]
        [HttpPost]

        public object ExportCsvReportCBRM(CBRMissingReportModelData cBRMissingReportModelData)
        {

            DataTable MissingReports = _objCBR.CBRmissingDataTable(cBRMissingReportModelData); 

            var csv = GenerateCsv(MissingReports);

            var bytes = Encoding.UTF8.GetBytes(csv);
            return File(bytes, "text/csv", $"CBRmissingReport_{cBRMissingReportModelData.FROMDATE}.csv");
        }

        private string GenerateCsv(DataTable table)

        {
            var sb = new StringBuilder();

            // Add the column headers
            IEnumerable<string> columnNames = table.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
            sb.AppendLine(string.Join(",", columnNames));

            // Add the rows
            foreach (DataRow row in table.Rows)
            {
                IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                sb.AppendLine(string.Join(",", fields));
            }

            return sb.ToString();
        }

        //------------------------ BY KUNDAN --------------------------------

        [Route("[action]")]
        [HttpPost]
        public object ExportExcelReportK(CBRReportModel cBRDownloadDataModel)
        {

            DataTable Report = _objCBR.CBRReportDatatable(cBRDownloadDataModel);

            // Debugging point to check column count
            Console.WriteLine($"Number of columns in Report DataTable: {Report.Columns.Count}");

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                // Debugging point
                Console.WriteLine($"Number of columns in Report DataTable: {Report.Columns.Count}");

                // Load the DataTable into the worksheet, starting from cell A1  //typeof(UnmatchedTxnsReportModel).GetProperties().Length
                worksheet.Cells["A1"].LoadFromDataTable(Report, PrintHeaders: true);

                using (var range = worksheet.Cells[1, 1, 1, Report.Columns.Count])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(Color.LightBlue);
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                // Format all cells with borders  //typeof(UnmatchedTxnsReportModel).GetProperties().Length]
                using (var range = worksheet.Cells[1, 1, Report.Rows.Count + 1, Report.Columns.Count])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }


                // Convert the package to a byte array
                byte[] fileContents = package.GetAsByteArray();

                // Return the Excel file as a download
                return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"UnmatchedTxnsReport_{cBRDownloadDataModel.FROMDATE}.xlsx");
            }

        }
        [Route("[action]")]
        [HttpPost]

        public object ExportCsvReportK(CBRReportModel cBRDownloadDataModel)
        {

            DataTable Reporttbl = _objCBR.CBRReportDatatable(cBRDownloadDataModel);
            var csv = GenerateCsv(Reporttbl);
            var bytes = Encoding.UTF8.GetBytes(csv);
            return File(bytes, "text/csv", $"UnmatchedTxnsReport_{cBRDownloadDataModel.FROMDATE}.csv");
        }


        [Route("[action]")]
        [HttpPost]
        public object ExportExcelReportCBROpeningClosing(C3RReportModel cBROCDataModel)
        {

            DataTable Report = _objCBR.CBROpeningClosingDatatable(cBROCDataModel);

            // Debugging point to check column count
            Console.WriteLine($"Number of columns in Report DataTable: {Report.Columns.Count}"); 

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                // Debugging point
                Console.WriteLine($"Number of columns in Report DataTable: {Report.Columns.Count}");

                // Load the DataTable into the worksheet, starting from cell A1  //typeof(UnmatchedTxnsReportModel).GetProperties().Length
                worksheet.Cells["A1"].LoadFromDataTable(Report, PrintHeaders: true);

                using (var range = worksheet.Cells[1, 1, 1, Report.Columns.Count])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(Color.LightBlue);
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                // Format all cells with borders  //typeof(UnmatchedTxnsReportModel).GetProperties().Length]
                using (var range = worksheet.Cells[1, 1, Report.Rows.Count + 1, Report.Columns.Count])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }


                // Convert the package to a byte array
                byte[] fileContents = package.GetAsByteArray();

                // Return the Excel file as a download
                return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"CBROpeningClosingReport_{cBROCDataModel.FROMDATE}.xlsx");
            }

        }
        [Route("[action]")]
        [HttpPost]

        public object ExportCsvReportCBROpeningClosing(C3RReportModel cBROCDataModel)
        {

            DataTable Reporttbl = _objCBR.CBROpeningClosingDatatable(cBROCDataModel); 

            var csv = GenerateCsv(Reporttbl);

            var bytes = Encoding.UTF8.GetBytes(csv);
            return File(bytes, "text/csv", $"CBROpeningClosingReport_{cBROCDataModel.FROMDATE}.csv");

        } 


        //------------------------ BY KUNDAN --------------------------------




        [Route("[action]")]
        [HttpGet]
        public object GetTerminalDetails(string TerminalId)
        {
            return _objCBR.GetTerminalData(TerminalId);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetTerminalOptionListOld(string ClientId, string UserName)
        {
            return _objCBR.GetTerminalOptionsOld(ClientId, UserName);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetTerminalOptionList(string UserName)
        {
            return _objCBR.GetTerminalOptions(UserName);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetPreviousClosingDetails(string TerminalId, string TimeStamp)
        {
            return _objCBR.GetPreviousClosing(TerminalId, TimeStamp);
        }

        [Route("[action]")]
        [HttpPost]
        public object CBRInsertUpdate(CBRCounterModel cBRCounterModel)
        {
            string TerminalType = _objCBR.GetTerminalType(cBRCounterModel.TerminalId);

            bool DateError = false;

            try
            {
                DateTime dtTest = Convert.ToDateTime(cBRCounterModel.TR_TIMESTAMP);
            }
            catch
            {
                DateError = true;
            }

            if (DateError)
            {
                return "Kindly Check Date and Time";
            }

            string OVTxtDupTA = string.Empty;
            string ShTxtDupTA = string.Empty;
            string TxtdupSat1 = string.Empty;
            string TxtdupSat2 = string.Empty;
            string TxtdupSat3 = string.Empty;
            string TxtdupSat4 = string.Empty;

            string DisTxtDup50 = string.Empty;
            string DisTxtDup100 = string.Empty;
            string DisTxtDup500 = string.Empty;
            string DisTxtDup1000 = string.Empty;

            string TCTxtdup50 = string.Empty;
            string TCTxtdup100 = string.Empty;
            string TCTxtdup500 = string.Empty;
            string TCTxtdup1000 = string.Empty;
            string PCTxtdup50 = string.Empty;
            string PCTxtdup100 = string.Empty;
            string PCTxtdup500 = string.Empty;
            string PCTxtdup1000 = string.Empty;

            if (TerminalType == "CDM")
            {
                DisTxtDup50 = (Convert.ToInt32(cBRCounterModel.Atmopeningbalance50) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter50) + Convert.ToInt32(cBRCounterModel.Atmdepositcounter50)).ToString();
                DisTxtDup100 = (Convert.ToInt32(cBRCounterModel.Atmopeningbalance100) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter100) + Convert.ToInt32(cBRCounterModel.Atmdepositcounter100)).ToString();
                DisTxtDup500 = (Convert.ToInt32(cBRCounterModel.Atmopeningbalance500) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter500) + Convert.ToInt32(cBRCounterModel.Atmdepositcounter500)).ToString();
                DisTxtDup1000 = (Convert.ToInt32(cBRCounterModel.Atmopeningbalance1000) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter1000) + Convert.ToInt32(cBRCounterModel.Atmdepositcounter1000)).ToString();
            }
            else
            {
                DisTxtDup50 = (Convert.ToInt32(cBRCounterModel.Atmopeningbalance50) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter50)).ToString();
                DisTxtDup100 = (Convert.ToInt32(cBRCounterModel.Atmopeningbalance100) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter100)).ToString();
                DisTxtDup500 = (Convert.ToInt32(cBRCounterModel.Atmopeningbalance500) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter500)).ToString();
                DisTxtDup1000 = (Convert.ToInt32(cBRCounterModel.Atmopeningbalance1000) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter1000)).ToString();
            }

            TCTxtdup50 = (Convert.ToInt32(cBRCounterModel.Cashincassettes50) + Convert.ToInt32(cBRCounterModel.CASHFROMPURGEBIN50)).ToString();
            TCTxtdup100 = (Convert.ToInt32(cBRCounterModel.Cashincassettes100) + Convert.ToInt32(cBRCounterModel.CASHFROMPURGEBIN100)).ToString();
            TCTxtdup500 = (Convert.ToInt32(cBRCounterModel.Cashincassettes500) + Convert.ToInt32(cBRCounterModel.CASHFROMPURGEBIN500)).ToString();
            TCTxtdup1000 = (Convert.ToInt32(cBRCounterModel.Cashincassettes1000) + Convert.ToInt32(cBRCounterModel.CASHFROMPURGEBIN1000)).ToString();

            PCTxtdup50 = (Convert.ToInt32(cBRCounterModel.Amountreplenished50) - Convert.ToInt32(cBRCounterModel.Amountreturned50) + Convert.ToInt32(TCTxtdup50)).ToString();
            PCTxtdup100 = (Convert.ToInt32(cBRCounterModel.Amountreplenished100) - Convert.ToInt32(cBRCounterModel.Amountreturned100) + Convert.ToInt32(TCTxtdup100)).ToString();
            PCTxtdup500 = (Convert.ToInt32(cBRCounterModel.Amountreplenished500) - Convert.ToInt32(cBRCounterModel.Amountreturned500) + Convert.ToInt32(TCTxtdup500)).ToString();
            PCTxtdup1000 = (Convert.ToInt32(cBRCounterModel.Amountreplenished1000) - Convert.ToInt32(cBRCounterModel.Amountreturned1000) + Convert.ToInt32(TCTxtdup1000)).ToString();

            string ATMTxtDupSum = (Convert.ToInt32(cBRCounterModel.Atmopeningbalance50) * 200 + Convert.ToInt32(cBRCounterModel.Atmopeningbalance100) * 100 + Convert.ToInt32(cBRCounterModel.Atmopeningbalance500) * 500 + Convert.ToInt32(cBRCounterModel.Atmopeningbalance1000) * 2000).ToString();
            string DisTxtDupSum = (Convert.ToInt32(DisTxtDup50) * 200 + Convert.ToInt32(DisTxtDup100) * 100 + Convert.ToInt32(DisTxtDup500) * 500 + Convert.ToInt32(DisTxtDup1000) * 2000).ToString();
            string RMCtxtDupSum = (Convert.ToInt32(cBRCounterModel.Atmremaingcounter50) * 200 + Convert.ToInt32(cBRCounterModel.Atmremaingcounter100) * 100 + Convert.ToInt32(cBRCounterModel.Atmremaingcounter500) * 500 + Convert.ToInt32(cBRCounterModel.Atmremaingcounter1000) * 2000).ToString();
            string DvtDupSum = (Convert.ToInt32(cBRCounterModel.Atmdivertcounter50) * 200 + Convert.ToInt32(cBRCounterModel.Atmdivertcounter100) * 100 + Convert.ToInt32(cBRCounterModel.Atmdivertcounter500) * 500 + Convert.ToInt32(cBRCounterModel.Atmdivertcounter1000) * 2000).ToString();
            string ARxtDupAMT = (Convert.ToInt32(cBRCounterModel.Atmdivertcounter50) * 200 + Convert.ToInt32(cBRCounterModel.Atmdivertcounter100) * 100 + Convert.ToInt32(cBRCounterModel.Atmdivertcounter500) * 500 + Convert.ToInt32(cBRCounterModel.Atmdivertcounter1000) * 2000).ToString();
            string ATRtxtDupATM = (Convert.ToInt32(cBRCounterModel.Amountreturned50) * 200 + Convert.ToInt32(cBRCounterModel.Amountreturned100) * 100 + Convert.ToInt32(cBRCounterModel.Amountreturned500) * 500 + Convert.ToInt32(cBRCounterModel.Amountreturned1000) * 2000).ToString();
            string NBtxtDupATM = (Convert.ToInt32(cBRCounterModel.Newbalperatmcounters50) * 200 + Convert.ToInt32(cBRCounterModel.Newbalperatmcounters100) * 100 + Convert.ToInt32(cBRCounterModel.Newbalperatmcounters500) * 500 + Convert.ToInt32(cBRCounterModel.Newbalperatmcounters1000) * 2000).ToString();
            string CCTxtDupTA = (Convert.ToInt32(cBRCounterModel.Cashincassettes50) * 200 + Convert.ToInt32(cBRCounterModel.Cashincassettes100) * 100 + Convert.ToInt32(cBRCounterModel.Cashincassettes500) * 500 + Convert.ToInt32(cBRCounterModel.Cashincassettes1000) * 2000).ToString();
            string CPTxtDupTA = (Convert.ToInt32(cBRCounterModel.CASHFROMPURGEBIN50) * 200 + Convert.ToInt32(cBRCounterModel.CASHFROMPURGEBIN100) * 100 + Convert.ToInt32(cBRCounterModel.CASHFROMPURGEBIN500) * 500 + Convert.ToInt32(cBRCounterModel.CASHFROMPURGEBIN1000) * 2000).ToString();
            string TCTxtDupTA = (Convert.ToInt32(TCTxtdup50) * 200 + Convert.ToInt32(TCTxtdup100) * 100 + Convert.ToInt32(TCTxtdup500) * 500 + Convert.ToInt32(TCTxtdup1000) * 2000).ToString();
            string PCTxtDupTA = (Convert.ToInt32(PCTxtdup50) * 200 + Convert.ToInt32(PCTxtdup100) * 100 + Convert.ToInt32(PCTxtdup500) * 500 + Convert.ToInt32(PCTxtdup1000) * 2000).ToString();
            string OpTxtDupTA = (Convert.ToInt32(cBRCounterModel.Switchopeningbal50) * 200 + Convert.ToInt32(cBRCounterModel.Switchopeningbal100) * 100 + Convert.ToInt32(cBRCounterModel.Switchopeningbal500) * 500 + Convert.ToInt32(cBRCounterModel.Switchopeningbal1000) * 2000).ToString();
            string DiTxtDupTA = (Convert.ToInt32(cBRCounterModel.Switchdispensebal50) * 200 + Convert.ToInt32(cBRCounterModel.Switchdispensebal100) * 100 + Convert.ToInt32(cBRCounterModel.Switchdispensebal500) * 500 + Convert.ToInt32(cBRCounterModel.Switchdispensebal1000) * 2000).ToString();
            string ReTxtDupTA = (Convert.ToInt32(cBRCounterModel.Switchremainingcounter50) * 200 + Convert.ToInt32(cBRCounterModel.Switchremainingcounter100) * 100 + Convert.ToInt32(cBRCounterModel.Switchremainingcounter500) * 500 + Convert.ToInt32(cBRCounterModel.Switchremainingcounter1000) * 2000).ToString();
            string PhcTxtDupTA = (Convert.ToInt32(PCTxtdup50) * 200 + Convert.ToInt32(PCTxtdup100) * 100 + Convert.ToInt32(PCTxtdup500) * 500 + Convert.ToInt32(PCTxtdup1000) * 2000).ToString();
            string TxtGldiffduppc = (Convert.ToInt32(CCTxtDupTA) + Convert.ToInt32(CPTxtDupTA) - Convert.ToInt32(cBRCounterModel.Glamount)).ToString();
            string ATMTxtDepSum = (Convert.ToInt32(cBRCounterModel.Atmdepositcounter50) * 200 + Convert.ToInt32(cBRCounterModel.Atmdepositcounter100) * 100 + Convert.ToInt32(cBRCounterModel.Atmdepositcounter500) * 500 + Convert.ToInt32(cBRCounterModel.Atmdepositcounter1000) * 2000).ToString();
            string SwitchDepSum = (Convert.ToInt32(cBRCounterModel.Switchdepositcounter50) * 200 + Convert.ToInt32(cBRCounterModel.Switchdepositcounter100) * 100 + Convert.ToInt32(cBRCounterModel.Switchdepositcounter500) * 500 + Convert.ToInt32(cBRCounterModel.Switchdepositcounter1000) * 2000).ToString();

            if (Convert.ToInt32(TCTxtdup50) > Convert.ToInt32(cBRCounterModel.Atmremaingcounter50) || Convert.ToInt32(TCTxtdup100) > Convert.ToInt32(cBRCounterModel.Atmremaingcounter100) || Convert.ToInt32(TCTxtdup500) > Convert.ToInt32(cBRCounterModel.Atmremaingcounter500) || Convert.ToInt32(TCTxtdup1000) > Convert.ToInt32(cBRCounterModel.Atmremaingcounter1000))
            {
                string OVTxtDup50 = (((Convert.ToInt32(TCTxtdup50) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter50)) > 0) ? (Convert.ToInt32(TCTxtdup50) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter50)) : 0).ToString();
                string OVTxtDup100 = (((Convert.ToInt32(TCTxtdup100) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter100)) > 0) ? (Convert.ToInt32(TCTxtdup100) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter100)) : 0).ToString();
                string OVTxtDup500 = (((Convert.ToInt32(TCTxtdup500) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter500)) > 0) ? (Convert.ToInt32(TCTxtdup500) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter500)) : 0).ToString();
                string OVTxtDup1000 = (((Convert.ToInt32(TCTxtdup1000) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter1000)) > 0) ? (Convert.ToInt32(TCTxtdup1000) - Convert.ToInt32(cBRCounterModel.Atmremaingcounter1000)) : 0).ToString();
                OVTxtDupTA = (Convert.ToInt32(OVTxtDup50) * 200 + Convert.ToInt32(OVTxtDup100) * 100 + Convert.ToInt32(OVTxtDup500) * 500 + Convert.ToInt32(OVTxtDup1000) * 2000).ToString();
            }
            else
            {
                OVTxtDupTA = "0";
            }
            if (Convert.ToInt32(TCTxtdup50) < Convert.ToInt32(cBRCounterModel.Atmremaingcounter50) || Convert.ToInt32(TCTxtdup100) < Convert.ToInt32(cBRCounterModel.Atmremaingcounter50) || Convert.ToInt32(TCTxtdup500) < Convert.ToInt32(cBRCounterModel.Atmremaingcounter500) || Convert.ToInt32(TCTxtdup1000) < Convert.ToInt32(cBRCounterModel.Atmremaingcounter1000))
            {
                string ShTxtDup50 = (((Convert.ToInt32(cBRCounterModel.Atmremaingcounter50) - Convert.ToInt32(TCTxtdup50)) > 0) ? (Convert.ToInt32(cBRCounterModel.Atmremaingcounter50) - Convert.ToInt32(TCTxtdup50)) : 0).ToString();
                string ShTxtDup100 = (((Convert.ToInt32(cBRCounterModel.Atmremaingcounter100) - Convert.ToInt32(TCTxtdup100)) > 0) ? (Convert.ToInt32(cBRCounterModel.Atmremaingcounter100) - Convert.ToInt32(TCTxtdup100)) : 0).ToString();
                string ShTxtDup500 = (((Convert.ToInt32(cBRCounterModel.Atmremaingcounter500) - Convert.ToInt32(TCTxtdup500)) > 0) ? (Convert.ToInt32(cBRCounterModel.Atmremaingcounter500) - Convert.ToInt32(TCTxtdup500)) : 0).ToString();
                string ShTxtDup1000 = (((Convert.ToInt32(cBRCounterModel.Atmremaingcounter1000) - Convert.ToInt32(TCTxtdup1000)) > 0) ? (Convert.ToInt32(cBRCounterModel.Atmremaingcounter1000) - Convert.ToInt32(TCTxtdup1000)) : 0).ToString();
                ShTxtDupTA = (Convert.ToInt32(ShTxtDup50) * 200 + Convert.ToInt32(ShTxtDup100) * 100 + Convert.ToInt32(ShTxtDup500) * 500 + Convert.ToInt32(ShTxtDup1000) * 2000).ToString();
            }
            else
            {
                ShTxtDupTA = "0";
            }
            if (Convert.ToInt32(NBtxtDupATM) == Convert.ToInt32(PCTxtDupTA))
            {
                TxtdupSat1 = "OK";
            }
            else
            {
                TxtdupSat1 = "New Counter Mismatch";
            }
            if (Convert.ToInt32(ReTxtDupTA) == Convert.ToInt32(CCTxtDupTA))
            {
                TxtdupSat2 = "OK";
            }
            else
            {
                TxtdupSat2 = "Switch Counters Mismatch";
            }
            if (Convert.ToInt32(DvtDupSum) == Convert.ToInt32(CPTxtDupTA))
            {
                TxtdupSat3 = "OK";
            }
            else
            {
                TxtdupSat3 = "ATM Counters Mismatch";

            }
            if (Convert.ToInt32(ReTxtDupTA) == Convert.ToInt32(RMCtxtDupSum))
            {
                TxtdupSat4 = "OK";
            }
            else
            {
                TxtdupSat4 = "S Diff";
            }

            if (TxtdupSat1.Contains("New Counter Mismatch") || Convert.ToDateTime(cBRCounterModel.TR_TIMESTAMP) > System.DateTime.Now)
            {
                return "Kindly Check (CBR Dispense should not be greater than ATM Diffrence and Status should not contain New Counter Mismatch and ATM opening amount total should not be Zero";
            }
            else
            {

                string NewBalAsPerATMCounter = (Convert.ToInt32(cBRCounterModel.Newbalperatmcounters50) * 200 + Convert.ToInt32(cBRCounterModel.Newbalperatmcounters100) * 100 + Convert.ToInt32(cBRCounterModel.Newbalperatmcounters500) * 500 + Convert.ToInt32(cBRCounterModel.Newbalperatmcounters1000) * 2000).ToString();
                string TotalCashFromATM = (Convert.ToInt32(CCTxtDupTA) + Convert.ToInt32(CPTxtDupTA)).ToString();
                string AmountReplenishment = (Convert.ToInt32(cBRCounterModel.Amountreplenished50) * 200 + Convert.ToInt32(cBRCounterModel.Amountreplenished100) * 100 + Convert.ToInt32(cBRCounterModel.Amountreplenished500) * 500 + Convert.ToInt32(cBRCounterModel.Amountreplenished1000) * 2000).ToString();
                string AmountReturned = (Convert.ToInt32(cBRCounterModel.Amountreturned50) * 200 + Convert.ToInt32(cBRCounterModel.Amountreturned100) * 100 + Convert.ToInt32(cBRCounterModel.Amountreturned500) * 500 + Convert.ToInt32(cBRCounterModel.Amountreturned1000) * 2000).ToString();

                string Bycalculate = ((Convert.ToInt32(TotalCashFromATM) + Convert.ToInt32(AmountReplenishment)) - Convert.ToInt32(AmountReturned)).ToString();

                if (Bycalculate != NewBalAsPerATMCounter)
                {
                    return "Total New Bal As Per ATM Counter and Total Physical Cash Balance is Mismatch.   [ Total New Bal As Per ATM Counter =(Total Cash From ATM  +  Total Amount Replenishment) - Total Amount Returned ]";

                }
                else
                {
                    if (int.Parse(NewBalAsPerATMCounter) <= 0)
                    {
                        return "New Bal As Per ATM Counter should not be zero";
                    }
                    else
                    {
                        int rowrowsaffectedCBRData = 0 , rowrowsaffectedCBRCounter=0;

                        cBRCounterModel.Atmdispensecounter50 = DisTxtDup50;
                        cBRCounterModel.Atmdispensecounter100 = DisTxtDup100;
                        cBRCounterModel.Atmdispensecounter500 = DisTxtDup500;
                        cBRCounterModel.Atmdispensecounter1000 = DisTxtDup1000;

                        cBRCounterModel.ClosingCounter50 = PCTxtdup50;
                        cBRCounterModel.ClosingCounter100 = PCTxtdup100;
                        cBRCounterModel.ClosingCounter500 = PCTxtdup500;
                        cBRCounterModel.ClosingCounter1000 = PCTxtdup1000;

                        rowrowsaffectedCBRCounter = _objCBR.CBRCounterInsertUpdate(cBRCounterModel);

                        CBRDataModel cBRDataModel = new CBRDataModel();

                        cBRDataModel.BANK = cBRCounterModel.ClientCode;
                        cBRDataModel.TR_TIMESTAMP = cBRCounterModel.TR_TIMESTAMP;
                        cBRDataModel.TERMINALID = cBRCounterModel.TerminalId;
                        cBRDataModel.BRANCH = cBRCounterModel.Branchlocation;
                        cBRDataModel.BRANCHLOCATION = cBRCounterModel.Branchlocation;
                        cBRDataModel.ATMPREVIOUSBALANCE= ATMTxtDupSum;
                        cBRDataModel.ATMDISPANSECOUNTER = DisTxtDupSum;
                        cBRDataModel.ATMREMAINGCOUNTER = RMCtxtDupSum;
                        cBRDataModel.ATMDIVERTCOUNTER = DvtDupSum;
                        cBRDataModel.AMOUNTREPLENISHED = ARxtDupAMT;
                        cBRDataModel.AMOUNTRETURNED = ATRtxtDupATM;
                        cBRDataModel.NEWBALPERATMCOUNTERS = NBtxtDupATM;
                        cBRDataModel.CASHINCASSETTES = CCTxtDupTA;
                        cBRDataModel.CASHFROMPURGEBIN = CPTxtDupTA;
                        cBRDataModel.TOTALCASHINATM = TCTxtDupTA;
                        cBRDataModel.PHYSICALBALANCE = PCTxtDupTA;
                        cBRDataModel.GLAMOUNT = cBRCounterModel.Glamount;
                        cBRDataModel.SWITCHOPENINGBAL = OpTxtDupTA;
                        cBRDataModel.SWITCHDISPENSEBAL = DiTxtDupTA;
                        cBRDataModel.SWITCHCLOSINGBAL = PhcTxtDupTA;
                        cBRDataModel.GLANDPHYSICALCASHDIFF = TxtGldiffduppc;
                        cBRDataModel.OVERAGE = OVTxtDupTA;
                        cBRDataModel.SHORTAGE = ShTxtDupTA;
                        cBRDataModel.STATUS = TxtdupSat1;
                        cBRDataModel.UserName = cBRCounterModel.UserName;
                        cBRDataModel.Atmdepositcounter = ATMTxtDepSum;
                        cBRDataModel.Switchdepositcounter = SwitchDepSum;
                        cBRDataModel.CDAMOUNT = cBRCounterModel.CDamount;
                        cBRDataModel.GLANDCDCASHDIFF ="0"; 
                        cBRDataModel.ClientCode = cBRCounterModel.ClientCode;
                        cBRDataModel.ISMANUALEntry = "1";

                        rowrowsaffectedCBRData = _objCBR.CBRInsertUpdate(cBRDataModel);

                        if (rowrowsaffectedCBRData > 0 && rowrowsaffectedCBRCounter > 0)
                        {
                            return "CBR Import Successfully";
                        }
                        else
                        {
                            return "Error Occurred";
                        }
                    }
                }

            }
           
        }
    }
}