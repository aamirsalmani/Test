﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using ASPTrace.Contracts;
using ASPTrace.Models;
using ASPTraceWebApi.Controllers;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ChannelRegController : ControllerBase
    {
        private readonly IChannelReg _objChannelReg;

        public ChannelRegController(IChannelReg objChannelReg)
        {
            _objChannelReg = objChannelReg;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetChannelRegList()
        {
            return _objChannelReg.GetChannelReg();

        }

        [Route("[action]")]
        [HttpPost]
        public object ChannelRegAdd(ChannelRegDetailsModel channelRegDetailsModel)
        {
            return _objChannelReg.ChannelRegAdd(channelRegDetailsModel);

        }

        [Route("[action]/{channelID}")]
        [HttpGet]
        public object GetChannelRegById(string channelID)
        {
            return _objChannelReg.GetChannelRegById(channelID);
        }


        //UspDeleteChannelMaster
        [Route("[action]")]
        [HttpPost]
        public object ChannelRegDelete(DeleteChannelDetails deleteChannelDetails)
        {
            return _objChannelReg.ChannelRegDelete(deleteChannelDetails);
        }
    }
}





//'api/VendorReg/VendorRegAddList'
//axios.post('api/ChannelReg/ChannelRegDelete', {
//        axios.get('api/VendorReg/GetVendorRegList
//             axios.get('api/VendorReg/GetVendorTypeList'
// public List<ChannelRegModel> GetChannelReg()
//             axios.get('api/VendorReg/GetVendorDetails?ChannelID='     private readonly IVendorReg _objVendorReg;

//public VendorRegController(IVendorReg objVendorReg)
//{
//    _objVendorReg = objVendorReg;
//}