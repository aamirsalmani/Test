﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ClientRegController : ControllerBase
    {
        private readonly IClientRegistration _objClientReg;

        public ClientRegController(IClientRegistration objClientReg)
        {
            _objClientReg = objClientReg;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientRegModelList()
        {
            return _objClientReg.GetClientRegModel();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientDetailsList(string BankID)
        {
            return _objClientReg.GetClientDetails(BankID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientCountryList()
        {
            return _objClientReg.GetClientCountry();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientCurrencyList(string CountryID)
        {
            return _objClientReg.GetClientCurrency(CountryID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientDomainList()
        {
            return _objClientReg.GetClientDomain();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientModuleList()
        {
            return _objClientReg.GetClientModule();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientChannelList()
        {
            return _objClientReg.GetClientChannel();
        }

        [Route("[action]")]
        [HttpPost]
        public object GetClientMasterList(ClientRegModel clientRegModel)
        {
            return _objClientReg.GetClientMasterGridData(clientRegModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientMasterList(int status)
        {
            return _objClientReg.GetClientMasterGridData(status);
        }

        [Route("[action]")]
        [HttpPost]
        public object AddUpdateClientMaster([FromForm] ClientConfig ClientData)
        {
            try
            {
                if (Convert.ToInt32(ClientData.ClientID) > 0)
                {
                    ClientData.Mode = "UPDATE";
                }
                else
                {
                    ClientData.Mode = "ADD";
                }

                if (ClientData.ClientLogoFile != null)
                {
                    string path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\ClientLogo\\", ClientData.ClientLogoFile.FileName);

                    using (System.IO.Stream stream = new System.IO.FileStream(path, System.IO.FileMode.Create))
                    {
                        ClientData.ClientLogoFile.CopyTo(stream);
                    }

                    ClientData.ClientLogo = ClientData.ClientLogoFile.FileName;
                }

                int rowsAffected = _objClientReg.AddUpdateClientMaster(ClientData);                

                int k = 0;

                IList<ClientChannelDetails> clientChannelModeDetails = System.Text.Json.JsonSerializer.Deserialize<IList<ClientChannelDetails>>(ClientData.ClientChannelModes);

                if (rowsAffected > 0)
                {
                   
                    ClientChannelModeDetails clientChannelModeDetail = new ClientChannelModeDetails();

                    clientChannelModeDetail.ClientCode = ClientData.ClientCode;
                    clientChannelModeDetail.CreatedBy = ClientData.UserName;                   

                    foreach (ClientChannelDetails rows in clientChannelModeDetails)
                    {
                        clientChannelModeDetail.ChannelID = rows.channelID;

                        if (!String.IsNullOrEmpty(rows.channelName))
                        {
                            string ONUS = string.Empty; string ACQ = string.Empty; string ISS = string.Empty;

                            if (rows.onus == true) ONUS = "1";
                            if (rows.acquirer == true) ACQ = "2";
                            if (rows.issuer == true) ISS = "3";
                            if (rows.channelID == "4" && ACQ == "2") ACQ = "5";
                            if (rows.channelID == "4" && ISS == "3") ISS = "4";
                            if (rows.channelID == "7" && ACQ == "2") ACQ = "5";
                            if (rows.channelID == "7" && ISS == "3") ISS = "4";

                            var array = new[] { ONUS, ACQ, ISS };

                            clientChannelModeDetail.ModeID = string.Join(",", array.Where(s => !string.IsNullOrEmpty(s)));
                        }

                        k = k + _objClientReg.AddClientChannelMode(clientChannelModeDetail);

                    }

                    clientChannelModeDetail = null;
                }               

                if (rowsAffected > 0 && k == clientChannelModeDetails.Count && ClientData.Mode == "UPDATE")
                {
                    return "Client Details Updated Successfully.";
                }
                else if (rowsAffected > 0 && k == clientChannelModeDetails.Count && ClientData.Mode == "ADD")
                {
                    return "Client Details Registered Successfully.";
                }
                else
                {
                    return "Error occurred while processing your request.";
                }

            }
            catch (Exception ex)
            {
                return "Error occurred while processing your request";
            }
        }

        [Route("[action]")]
        [HttpGet]
        public object GetChannelModeList(string ClientID)
        {
            List<ClientChannelModeDetails> ChannelDataList = _objClientReg.GetChannelData(ClientID);

            List<ClientChannelDetails> clientChannelModeList = new List<ClientChannelDetails>();

            foreach (ClientChannelModeDetails obj in ChannelDataList)
            {
                ClientChannelDetails clientChannelDetails = new ClientChannelDetails();

                clientChannelDetails.channelID = obj.ChannelID;
                clientChannelDetails.channelName = obj.ChannelName;
                try
                {

                    if (obj.ModeID.Contains("1"))
                        clientChannelDetails.onus = true;

                    if (obj.ModeID.Contains("2"))
                        clientChannelDetails.acquirer = true;

                    if (obj.ModeID.Contains("3"))
                        clientChannelDetails.issuer = true;

                    if (obj.ModeID.Contains("4"))
                        clientChannelDetails.acquirer = true;

                    if (obj.ModeID.Contains("5"))
                        clientChannelDetails.issuer = true;

                    clientChannelModeList.Add(clientChannelDetails);
                }
                catch (Exception e)
                {
                }
            }

            return clientChannelModeList;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientData(string ClientID)
        {
            return _objClientReg.GetClientMasterData(ClientID);
        }

        [Route("[action]")]
        [HttpGet]
        public object CheckClientCode(string ClientID, string ClientCode)
        {
            return _objClientReg.CheckClientCodeExists(ClientID, ClientCode);
        }
    }
}
