﻿using OfficeOpenXml.Style;
using OfficeOpenXml;
using System; 
using System.Data; 
using System.Text; 
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using ASPTrace.Models;
using System.IO; 
using ASPTrace.Contracts;

namespace ASPTraceWebApi
{
    public class Common
    {
        private static readonly string _excelPassword;  // ✅ store password

        static Common()
        {
            var config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())   // read from app root
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .Build();

            _excelPassword = config["ExportKeys:Password"];
        }
        public static string GetColumns(System.Data.DataTable table)
        {
            var JSONString = new System.Text.StringBuilder();
            JSONString.Append("[");
            for (int j = 0; j < table.Columns.Count; j++)
            {
                if (j < table.Columns.Count - 1)
                {
                    JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\",");
                }
                else if (j == table.Columns.Count - 1)
                {
                    JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\"");
                }
            }
            JSONString.Append("]");

            return JSONString.ToString();
        }

        public static string DataTableToJSONWithJSONNet(System.Data.DataTable table)
        {
            string JSONString = string.Empty;
            JSONString = Newtonsoft.Json.JsonConvert.SerializeObject(table);
            return JSONString;
        }

        public static string GenerateCsv(DataTable table)
        {
            var sb = new StringBuilder();

            // Add the column headers
            IEnumerable<string> columnNames = table.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
            sb.AppendLine(string.Join(",", columnNames));

            // Add the rows
            foreach (DataRow row in table.Rows)
            {
                IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                sb.AppendLine(string.Join(",", fields));
            }

            return sb.ToString();
        }

        public static string GenerateTokens(string userId, string Secret, string SessionTimout)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = System.Text.Encoding.ASCII.GetBytes(Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                   new Claim(ClaimTypes.NameIdentifier, userId)
                }),
                Expires = DateTime.UtcNow.AddMinutes(Convert.ToInt16(SessionTimout)),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);

            return tokenString;
        }
        public static string ConvertFileSize(long bytes)
        {
            double size = bytes;

            if (size >= 1073741824) // GB
            {
                return (size / 1073741824).ToString("F2") + " GB";
            }
            else if (size >= 1048576) // MB
            {
                return (size / 1048576).ToString("F2") + " MB";
            }
            else if (size >= 1024) // KB
            {
                return (size / 1024).ToString("F2") + " KB";
            }
            else
            {
                return size + " Bytes";
            }
        }

        public static byte[] ExportExcel(DataTable dtTxns)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                // Load the DataTable into the worksheet, starting from cell A1
                worksheet.Cells["A1"].LoadFromDataTable(dtTxns, PrintHeaders: true);

                // Header formatting
                using (var range = worksheet.Cells[1, 1, 1, dtTxns.Columns.Count])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightBlue);
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                    // Center align headers
                    range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                }

                // Format all cells with borders + alignment
                using (var range = worksheet.Cells[1, 1, dtTxns.Rows.Count + 1, dtTxns.Columns.Count])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                    // Center align all cells
                    range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    range.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                }

                package.Encryption.Password = _excelPassword; // make this dynamic if needed
                package.Encryption.Algorithm = OfficeOpenXml.EncryptionAlgorithm.AES256;

                // Convert the package to a byte array
                return package.GetAsByteArray();
            }
        }


        //public static byte[] ExportExcel(DataTable dtTxns)
        //{
        //    ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

        //    using (ExcelPackage package = new ExcelPackage())
        //    {
        //        // Add a new worksheet to the Excel package
        //        ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

        //        // Load the DataTable into the worksheet, starting from cell A1  //typeof(UnmatchedTxnsReportModel).GetProperties().Length
        //        worksheet.Cells["A1"].LoadFromDataTable(dtTxns, PrintHeaders: true);

        //        using (var range = worksheet.Cells[1, 1, 1, dtTxns.Columns.Count])
        //        {
        //            range.Style.Font.Bold = true;
        //            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
        //            range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightBlue);
        //            range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
        //            range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
        //            range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
        //            range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
        //        }

        //        // Format all cells with borders  //typeof(UnmatchedTxnsReportModel).GetProperties().Length]
        //        using (var range = worksheet.Cells[1, 1, dtTxns.Rows.Count + 1, dtTxns.Columns.Count])
        //        {
        //            range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
        //            range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
        //            range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
        //            range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
        //        }

        //        package.Encryption.Password = _excelPassword;// <-- you can make this dynamic (e.g. UserID, ClientID)
        //        package.Encryption.Algorithm = OfficeOpenXml.EncryptionAlgorithm.AES256;
        //        // Convert the package to a byte array
        //        return package.GetAsByteArray();               
        //    }
        //}

        public static byte[] CreatePasswordProtectedZip(string fileName, byte[] fileBytes, string password)
        {
            using (var ms = new MemoryStream())
            {
                using (var zip = new Ionic.Zip.ZipFile())
                {
                    zip.Password = password;
                    zip.Encryption = Ionic.Zip.EncryptionAlgorithm.WinZipAes256;
                    zip.AddEntry(fileName, fileBytes);
                    zip.Save(ms);
                }
                return ms.ToArray();
            }
        }
    }

  
}
