﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CommonController : ControllerBase
    {
        private readonly ICommon _objCommon;

        public CommonController(ICommon objCommon)
        {
            _objCommon = objCommon;
        }


        [Route("[action]")]
        [HttpGet]
        public object GetLogOptionList(string ChannelID)
        {
            return _objCommon.GetLogOptions(ChannelID);
        }
        [Route("[action]")]
        [HttpGet]
        public object GetClientOptionList(string UserID)
        {
            return _objCommon.GetClientOptions(UserID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetUserRole(string UserID)
        {
            return _objCommon.GetUserRole(UserID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetChannelOptionList(string ClientId, string UserID)
        {
            return _objCommon.GetChannelOptions(ClientId, UserID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetModeOptionList(string ClientId, string ChannelID, string UserID)
        {
            return _objCommon.GetModeOptions(ClientId, ChannelID, UserID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetModeIMPSOptionList(string ClientId, string ChannelID)
        {
            return _objCommon.GetModeIMPSOptions(ClientId, ChannelID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetTerminalOptionList(string ClientId, string ChannelID, string UserName)
        {
            return _objCommon.GetTerminals(ClientId, ChannelID, UserName);
        }


        [Route("[action]")]
        [HttpGet]
        public object GetFileTypeOptionList(string ClientId)
        {
            return _objCommon.GetFileTypeOptions(ClientId);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetUserMenuList(string UserID)
        {
            List<SideBarMenuModel> sideBarMenuModels =  _objCommon.GetMenuList(UserID, "1");

            List<SideBarMenuModel> subMenuList = _objCommon.GetMenuList(UserID, "2");

            List<SubMenuModel> SubMenus = null;

            foreach (SideBarMenuModel item in sideBarMenuModels)
            {
                SubMenus = new List<SubMenuModel>();

                if (subMenuList.Any(p => p.ParentMenuID == item.MenuID))
                { 
                    foreach (SideBarMenuModel sub in subMenuList)
                    {                       
                        if (sub.ParentMenuID == item.MenuID)
                        {
                            SubMenuModel subMenuModel = new SubMenuModel();
                            subMenuModel.MenuID = sub.MenuID;
                            subMenuModel.MenuName = sub.MenuName;
                            subMenuModel.ParentMenuID = sub.ParentMenuID;
                            subMenuModel.SequenceNo = sub.SequenceNo;
                            subMenuModel.FilePath = sub.FilePath; 
                            SubMenus.Add(subMenuModel);
                        }
                    }
                }
                item.SubMenus = SubMenus;
            }

            return sideBarMenuModels;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetMenuList(string UserID)
        {
            return _objCommon.GetMenuList(UserID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetLeftLogo(string ClientId)
        {
            ClientLogoDetails clientLogoDetails = _objCommon.GetClientLogo(ClientId);

            string path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\ClientLogo\\", clientLogoDetails.ClientLogo);

            var contents = System.IO.File.ReadAllBytes(path);

            clientLogoDetails.ClientLogo = $"data:image/png;base64,{Convert.ToBase64String(contents)}"; 

            return clientLogoDetails;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientLogoImage(string ClientId)
        {
            ClientLogoDetails clientLogoDetails = _objCommon.GetClientLogo(ClientId);

            string path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\ClientLogo\\", clientLogoDetails.ClientLogo);

            var contents = System.IO.File.ReadAllBytes(path);

            clientLogoDetails.ClientLogo = $"data:image/png;base64,{Convert.ToBase64String(contents)}";

            path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\ClientLogo\\", clientLogoDetails.TraceLogo);

            var Logo = System.IO.File.ReadAllBytes(path);

            clientLogoDetails.TraceLogo = $"data:image/png;base64,{Convert.ToBase64String(Logo)}";

            return clientLogoDetails;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetNPCIReportTypeList(string ClientId, string ChannelID, string UserID)
        {
            return _objCommon.GetNPCIReportTypeOptions(ClientId, ChannelID, UserID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetReactFileTypeList()
        {
            return _objCommon.GetReactFileTypes();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAlertTypeList()
        {
            return _objCommon.GetAlertTypes();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAlertSeverityList()
        {
            return _objCommon.GetAlertSeverity();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAlertScheduleTypeList()
        {
            return _objCommon.GetAlertScheduleType();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAlertNotificationChannelList()
        {
            return _objCommon.GetAlertNotificationChannel();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAlertEscalationUserList()
        {
            return _objCommon.GetAlertEscalationUser();
        }

    }
}