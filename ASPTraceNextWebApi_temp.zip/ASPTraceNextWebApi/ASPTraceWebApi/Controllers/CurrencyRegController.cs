﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class CurrencyRegController : ControllerBase
    {
        private readonly ICurrencyReg _objCurrencyReg;

        public CurrencyRegController(ICurrencyReg objCurrencyReg)
        {
            _objCurrencyReg = objCurrencyReg;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientCurrencyRegList()
        {
            return _objCurrencyReg.GetClientCurrencyReg();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetCurrencyRegList()
        {
            return _objCurrencyReg.GetCurrencyRegGrid();
        }
        [Route("[action]")]
        [HttpGet]
        public object SetCountryCode(string CountryName)
        {
            return _objCurrencyReg.GetCountryCodeByCountryName(CountryName);
        }

        [Route("[action]")]
        [HttpPost]
        public object CurrencyRegAddUpdate(CurrencyRegModel currencyRegDetailsModel)
        {
            return _objCurrencyReg.CurrencyAddUpdate(currencyRegDetailsModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetCurrencyDetails(string CurrencyID)
        {
            return _objCurrencyReg.GetCurrencyDetails(CurrencyID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetCountryRegList()
        {
            return _objCurrencyReg.GetCountryReg();
        }

        [Route("[action]")]
        [HttpPost]
        public object DeleteCurrency(DeleteCurrencyRegModel currencyRegDetailsModel)
        {
            return _objCurrencyReg.DeleteCurrencyReg(currencyRegDetailsModel);
        }
    }
}