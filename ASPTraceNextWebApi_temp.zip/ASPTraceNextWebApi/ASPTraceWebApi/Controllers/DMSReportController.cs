﻿using System;
using System.Collections.Generic;
using System.Data;
using ASPTrace.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc; 
using ASPTrace.Models;
using Utility;  


namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class DMSReportController : ControllerBase
    {
        private readonly IDMS _objReport;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;

        public DMSReportController(IDMS objReport, IConfiguration Configuration, ASPTrace.Contracts.ICommon Common)
        {
            _objReport = objReport;
            _configuration = Configuration;
            _objCommon = Common;
        }


        [Route("[action]")]
        [HttpGet]
        public object GetReasonCodeOptionList(string ClientID, int ChannelID, string AdjType)
        {
            return _objReport.GetReasonCodeOptionList(ClientID, ChannelID, AdjType);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAdjTypeOptionList(string ClientID, int ChannelID)
        {
            return _objReport.GetAdjTypeOptionList(ClientID, ChannelID);
        }

        // -------------------------------  NPCI Dispute Tracking Report ---------------------------------------------------------

        [Route("[action]")]
        [HttpPost]
        public object GetNPCIDisputeTracking(AdjustmentTxnsNPCIModel ParamsModel)
        {

            List<DisputeDetails> NPCIDisputeTracking = _objReport.GetNPCIDisputeTracking(ParamsModel);

            return NPCIDisputeTracking;
        }


        // -------------------------------   Dispute Tracking Report ---------------------------------------------------------

        [Route("[action]")]
        [HttpPost]
        public object GetUnmatchDisputes(AdjustmentTxnsIputModel unmatchedTxnsModel)
        {

            List<dynamic> AdjustmentTxnsReport = _objReport.GetAdjustmentTxnsReport(unmatchedTxnsModel);

            return AdjustmentTxnsReport;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetDisputeByReferenceNumber(AdjustmentTxnsReferenceNumberModel unmatchedTxnsModel)
        {

            List<AdjustmentTxnsReportModel> AdjustmentTxnsReport = _objReport.GetDisputeByReferenceNumber(unmatchedTxnsModel);

            return AdjustmentTxnsReport;
        }


        [Route("[action]")]
        [HttpPost]
        public object GetUnmatchedTxnByReferenceNumberList(UnmatchedTxnsModel unmatchedTxnsModel)
        {
            UnmatchedTxnByReferenceNumber unmatchedTxnByReferenceNumbers = _objReport.GetUnmatchedTxnByReferenceNumberReport(unmatchedTxnsModel);

            
            

            string EMekKey1 = this._configuration.GetValue<string>("AppSettings:EMekKey1");
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            foreach (UnmatchedTxnDetailsModel unmatchedTxnDetailsModel in unmatchedTxnByReferenceNumbers.EJTxnDetails)
            {
                try
                {
                    unmatchedTxnDetailsModel.CardNumber = AesEncryption.DecryptString(unmatchedTxnDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            foreach (UnmatchedTxnDetailsModel unmatchedTxnDetailsModel in unmatchedTxnByReferenceNumbers.GLTxnDetails)
            {
                try
                {
                    unmatchedTxnDetailsModel.CardNumber = AesEncryption.DecryptString(unmatchedTxnDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            foreach (UnmatchedTxnDetailsModel unmatchedTxnDetailsModel in unmatchedTxnByReferenceNumbers.NWTxnDetails)
            {
                try
                {
                    unmatchedTxnDetailsModel.CardNumber = AesEncryption.DecryptString(unmatchedTxnDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            foreach (UnmatchedTxnDetailsModel unmatchedTxnDetailsModel in unmatchedTxnByReferenceNumbers.SWTxnDetails)
            {
                try
                {
                    unmatchedTxnDetailsModel.CardNumber = AesEncryption.DecryptString(unmatchedTxnDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            return unmatchedTxnByReferenceNumbers;
        }


        //Adjustment Report

        [Route("[action]")]
        [HttpGet]
        public object GetAdjustmentTerminalDetailsList(string UserName, string ClientID)
        {
            return _objReport.GetAdjustmentTerminalDetails(UserName, ClientID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAdjustmentModeList(string ClientID, string ChannelID)
        {
            return _objReport.GetAdjustmentMode(ClientID, ChannelID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetDisputeTypeList(string ClientID, string ChannelID)
        {
            return _objReport.GetDisputeTypeList(ClientID, ChannelID);
        }

        [Route("[action]")]
        [HttpGet]
        public string IsUserChecker(string UserName)
        {
            return _objReport.IsUserChecker(UserName);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetAdjustmentTxnsReportList(AdjustmentTxnsIputModel adjustmentTxnsModel)
        {
            return _objReport.GetAdjustmentTxnsReport(adjustmentTxnsModel);
        }
        [Route("[action]")]
        [HttpPost]
        public IActionResult GetAttachmentFile(AttachmentModel AttachmentDetails)
        {
            byte[] attachment = _objReport.GetAttachmentsFile(AttachmentDetails);


            if (attachment == null)
            {
                return NotFound();
            }

            return File(attachment, AttachmentDetails.ContentType, AttachmentDetails.FileName);



        }
        [Route("[action]")]
        [HttpPost]
        public IActionResult BulkSubmitRemarks([FromQuery]string ChannelID,[FromBody] List<SubmitRemarksModel> SubmitRemarks)
        {
            string Output = _objReport.BulkUpdateDisputeRemarks(ChannelID,SubmitRemarks);


            if (Output == null)
            {
                return NotFound();
            }

            return Ok(Output);


        }
        [Route("[action]")]
        [HttpPost]
        public IActionResult BulkRaiseDispute([FromBody] List<BulkDisputeRaiseModel> SubmitRemarks)
        {
            string Output = string.Empty;
            if (SubmitRemarks.Count > 0)
            {

                Output = _objReport.BulkRaiseDispute(SubmitRemarks);
            }


            if (string.IsNullOrEmpty(Output))
            {
                return NotFound();
            }

            return Ok(Output);


        }

        [Route("[action]")]
        [HttpPost]
        public IActionResult SubmitRemarks(SubmitRemarksModel SubmitRemarks)
        {
            string Output = _objReport.UpdateDisputeRemarks(SubmitRemarks);


            if (Output == null)
            {
                return NotFound();
            }

            return Ok(Output);


        }
        [Route("[action]")]
        [HttpPost]
        public IActionResult DeleteAttachmentFile(AttachmentModel AttachmentDetails)
        {
            string Output = _objReport.DeleteAttachmentFile(AttachmentDetails);


            if (Output == null)
            {
                return NotFound();
            }

            return Ok(Output);


        }
        [Route("[action]")]
        [HttpPost]
        public object GetAttachmentsData(DisputeModel adjustmentTxnsModel)
        {
            List<AttachmentModel> DisputeDataList = _objReport.GetAttachmentsData(adjustmentTxnsModel);

            return DisputeDataList;
        }
        [Route("[action]")]
        [HttpPost]
        public IActionResult UploadDisputeAttachments([FromForm] DisputeUpload attachment)
        {
            string ext = attachment.Attachment.FileName.Split('.').Last();
            bool isValid = _objReport.checkFileType(ext);
            if (isValid)
            {

                string Data = _objReport.UploadDisputeAttachments(attachment);
                return Ok(Data);
            }
            else
            {
                return Ok("Invalid File!!");
            }


        }

        [Route("[action]")]
        [HttpPost]
        public List<dynamic> GetDisputeRaiseData(GetDisputeRaiseDataModel getDisputeRaiseDataModel)
        {
            return _objReport.GetDisputeRaiseData(getDisputeRaiseDataModel);
        }

    }
}