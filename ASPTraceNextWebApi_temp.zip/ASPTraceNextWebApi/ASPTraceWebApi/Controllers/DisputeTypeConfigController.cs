﻿
using Microsoft.AspNetCore.Authorization; 
using Microsoft.AspNetCore.Mvc; 
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class DisputeTypeConfigController : ControllerBase
    {
        private readonly IDisputeTypeConfig _objDisputeTypeConfig;
        public DisputeTypeConfigController(IDisputeTypeConfig objDisputeTypeConfig)
        {
            _objDisputeTypeConfig = objDisputeTypeConfig;
        }

        //public DisputeTypeConfigController(IDynamicStatus objDynamicStatus)
        //{
        //    _objDynamicStatus = objDynamicStatus;
        //}

        //[Route("[action]")]
        //[HttpPost]
        //public object GetDynamicStatusDataList(GetStatusModel getStatusModel)
        //{
        //    return _objDynamicStatus.GetDynamicStatusData(getStatusModel);
        //}


        [Route("[action]")]
        [HttpPost]
        public object GetDisputeTypeconfigData(GetDisputeTypeConfigModel getDisputeTypeConfigModel)
        {
            return _objDisputeTypeConfig.GetDisputeTypeconfigData(getDisputeTypeConfigModel);
        }


        [Route("[action]")] 
        [HttpPost]
        public object EditDisputeTypeconfigData(EditDisputeTypeConfigModel editDisputeTypeConfigModel)
        {
            return _objDisputeTypeConfig.EditDisputeTypeconfigData(editDisputeTypeConfigModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object AddNewDisputeTypeconfigData(AddNewDisputeTypeConfigModel addNewDisputeTypeConfigModel)
        {
            return _objDisputeTypeConfig.AddNewDisputeTypeconfigData(addNewDisputeTypeConfigModel);
        }


        [Route("[action]")]
        [HttpPost]
        public object DeleteDisputeTypeConfigData(DeleteDisputeTypeConfigModel deleteDisputeTypeConfigModel)
        {
            return _objDisputeTypeConfig.DeleteDisputeTypeConfigData(deleteDisputeTypeConfigModel);
        }

        //[Route("[action]")]
        //[HttpPost]
        //public object AddDynamicStatus(GetStatusModelData getStatusModelData)
        //{
        //    return _objDynamicStatus.AddDynamicStatusData(getStatusModelData);
        //}
        //[Route("[action]")]
        //[HttpPost]
        //public object UpdateDynamicStatus(GetStatusModelData getStatusModelData)
        //{
        //    return _objDynamicStatus.UpdateDynamicStatusData(getStatusModelData);
        //}

        //[Route("[action]")]
        //[HttpPost]
        //public object UploadExcelFile([FromForm] FormDataModel formDataModel)
        //{
        //    IFormFile file = formDataModel.file;
        //    int clientId = Convert.ToInt32(formDataModel.ClientID);
        //    int channelId = Convert.ToInt32(formDataModel.ChannelID);
        //    int modeId = Convert.ToInt32(formDataModel.ModeID);
        //    int reconType = Convert.ToInt32(formDataModel.ReconType);
        //    int InsertCount = 0;
        //    int ErrorCount = 0;
        //    string fileExtension = Path.GetExtension(file.FileName);
        //    try
        //    {
        //        if (fileExtension.StartsWith("."))
        //        {
        //            fileExtension = fileExtension.Substring(1);
        //        }
        //        if (file == null || file.Length == 0)
        //            return "No file uploaded.";

        //        if ((_objDynamicStatus.CheckExtension(fileExtension) != "Valid"))
        //        {
        //            return "Invalid file Extension";
        //        }
        //        if (fileExtension != "xlsx" && fileExtension != "xls")
        //        {
        //            return "Invalid file Extension";
        //        }

        //        using (var memoryStream = new MemoryStream())
        //        {
        //            file.CopyToAsync(memoryStream);
        //            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        //            using (var package = new ExcelPackage(memoryStream))
        //            {
        //                var worksheet = package.Workbook.Worksheets.FirstOrDefault();
        //                if (worksheet == null)
        //                    return "No worksheet found in the uploaded file.";

        //                var dataTable = new DataTable();
        //                foreach (var firstRowCell in worksheet.Cells[1, 1, 1, worksheet.Dimension.End.Column])
        //                {
        //                    dataTable.Columns.Add(firstRowCell.Text);
        //                }

        //                try
        //                {
        //                    for (var rowNumber = 2; rowNumber <= worksheet.Dimension.End.Row; rowNumber++)
        //                    {
        //                        var row = worksheet.Cells[rowNumber, 1, rowNumber, worksheet.Dimension.End.Column];
        //                        var newRow = dataTable.Rows.Add();
        //                        InsertCount++;
        //                        foreach (var cell in row)
        //                        {
        //                            if (cell.Start.Column != worksheet.Dimension.End.Column)
        //                            {
        //                                if (int.TryParse(cell.Text, out int cellValue) && cellValue >= 1 && cellValue <= 11)
        //                                {
        //                                    newRow[cell.Start.Column - 1] = cellValue;
        //                                }
        //                                else
        //                                {
        //                                    ErrorCount++;
        //                                    continue;
        //                                }
        //                            }
        //                            else
        //                            {
        //                                newRow[cell.Start.Column - 1] = cell.Text;
        //                            }

        //                        }
        //                    }
        //                }
        //                catch (Exception ex)
        //                {
        //                    ErrorCount++;
        //                }
        //                return _objDisputeTypeConfig.UploadExcelFile(dataTable, clientId, channelId, modeId, reconType, InsertCount, ErrorCount);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, "An error occurred while processing the uploaded Excel file.");
        //    }
        //}
    }
}

