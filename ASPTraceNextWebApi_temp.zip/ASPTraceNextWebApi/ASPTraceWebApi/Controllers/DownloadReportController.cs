﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using ASPTrace.Models;  // Replace with your actual models namespace
using ASPTrace.Contracts; 
using System.IO;
using Microsoft.AspNetCore.StaticFiles;
namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class DownloadReportController : Controller
    {
        private readonly IDownloadService _objReport;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;

        public DownloadReportController(IDownloadService objReport, IConfiguration Configuration, ICommon Common)
        {
            _objReport = objReport;
            _configuration = Configuration;
            _objCommon = Common;
        }


        [Route("[action]")]
        [HttpPost]
        public object GetReport([FromBody]DownloadReportRequest details)
        {
            _objReport.CheckFilesAndInsertToDb(details.UserID);

            List<dynamic> DownloadReportList = _objReport.DownloadReport(details);

            return DownloadReportList;

        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> DownloadFile([FromBody] DownloadReportRequest details)
        {
            List<dynamic> DownloadReportList = _objReport.DownloadReportByID(details);

            string FilePath = DownloadReportList[0].FilePath;

            if (!System.IO.File.Exists(FilePath))
            {
                return NotFound("File not found.");
            }

            // Get the file name
            string fileName = Path.GetFileName(FilePath);

            string contentType = "application/octet-stream"; 
            new FileExtensionContentTypeProvider().TryGetContentType(fileName, out contentType);

            
            var fileBytes = await System.IO.File.ReadAllBytesAsync(FilePath);

            Response.Headers.Append("Content-Disposition", $"attachment; filename=\"{fileName}\"");

            return File(fileBytes, contentType, fileName);


        }

    }
}
