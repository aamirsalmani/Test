﻿using ASPTrace.Contracts;
using ASPTrace.Models;
using ASPTraceWebApi.ClassFiles;
using DocumentFormat.OpenXml.Spreadsheet;
using HtmlAgilityPack;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic; 
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text.Json;
using TextFieldParserCore;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class DynamicFileConfigController : ControllerBase
    {
        private readonly IDynamicFile _objDynamicFile;

        public DynamicFileConfigController(IDynamicFile objDynamicFile)
        {
            _objDynamicFile = objDynamicFile;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetVendorOptionList(string VendorType)
        {
            return _objDynamicFile.GetVendorFileConfig(VendorType);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetChannelOptionList(string ClientID)
        {
            return _objDynamicFile.GetDynamicChannelList(ClientID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetLogTypeOptionList(string ClientID)
        {
            return _objDynamicFile.GetLogTypeFileConfig(ClientID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetNetworkTypeOptionList(string ClientID)
        {
            return _objDynamicFile.GetNetworkTypeFileConfig(ClientID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetModeOptionList(string ClientID, int ChannelID)
        {
            return _objDynamicFile.GetModeFileConfig(ClientID, ChannelID);
        }
        [Route("[action]")]
        [HttpGet]
        public object GetDynamicModeOptionList(string ClientID, int ChannelID)
        {
            return _objDynamicFile.GetDynamicModeFileConfig(ClientID, ChannelID);
        }

        //Sidd
        [Route("[action]")]
        [HttpGet]
        public object GetDynamicFileIdOptionList()
        {
            return _objDynamicFile.GetDynamicFileID();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetDynamicNetworkTypeOptionList()
        {
            return _objDynamicFile.GetDynamicNetworkType();
        }

       

        [HttpPost("[action]")]
        public string AddUpdateDynamicFileConfig(ASPTrace.Models.DynamicFileConfigModel ConfigModel)
        {
            try
            {
                string MSG = string.Empty;

                string res = _objDynamicFile.AddUpdateFileConfig(ConfigModel);

                if (res == "Save")
                {
                    MSG = "Added successfully";
                }
                else if (res == "Exists")
                {
                    MSG = "Already Exists";
                }
                else
                {
                    MSG = "Error Occurred";
                }

                return MSG;
            }
            catch (Exception ex)
            {
                return "Failure :" + ex.Message;
            }

        }

        //[Route("[action]")]
        //[HttpGet]
        //public object GetFileConfigList(string ClientID, string LogTypeID)
        //{
        //    return _objDynamicFile.GetFileConfigGrid(ClientID, LogTypeID);
        //}

        [Route("[action]")]
        [HttpGet]
        public object GetFileConfigList(string ClientID, string NetworkType, string LogTypeID, string ChannelID)
        {
            return _objDynamicFile.GetFileConfigGrid(ClientID, NetworkType, LogTypeID, ChannelID);
        }


        [HttpPost("UploadFile")]
        public object UploadFile([FromForm] ASPTrace.Models.DynamicFileUploadModel file)
        {
            string MSG = string.Empty;
            DynamicImportFileStatus dynamicImportFileStatus = new DynamicImportFileStatus();

            try
            {
                if (file.ImportFile == null)
                {
                    MSG = "Error : File not selected";
                }
                else
                {
                    Guid objGuid = Guid.NewGuid();

                    string sFileExt1 = System.IO.Path.GetExtension(file.ImportFile.FileName);

                    string sFileName = "Trace_" + objGuid.ToString().Replace("-", "") + sFileExt1;

                    string path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\ReconConfig\\", sFileName);

                    using (System.IO.Stream stream = new System.IO.FileStream(path, System.IO.FileMode.Create))
                    {
                        file.ImportFile.CopyTo(stream);
                    }

                    //file.Separator = sFileExt1.ToLower() == ".csv" ? "," : file.Separator;

                    string res = _objDynamicFile.AddUpdateFileUploadDetails(file, sFileName, path, file.ImportFile.FileName);

                    if (Convert.ToInt32(res) > 0)
                    {
                        DynamicImportFileConfigModel dynamicImportFileConfigModel = _objDynamicFile.GetDynamicFileUploadDetails(res);

                        if (dynamicImportFileConfigModel != null)
                        {
                            UpdateFileContent(dynamicImportFileConfigModel);
                        } 

                        if (sFileExt1 == ".xls" || sFileExt1 == ".xlsx" || sFileExt1 == ".csv")
                        {
                            dynamicImportFileStatus.Type = "Excel";
                            dynamicImportFileStatus.MSG = "Success";
                            dynamicImportFileStatus.FileConfigID = res;
                        }
                        else if (file.FileType == "2")
                        {
                            dynamicImportFileStatus.Type = "PlaintextWithoutSeparator";
                            dynamicImportFileStatus.MSG = "Success";
                            dynamicImportFileStatus.FileConfigID = res;
                        }
                        else if (file.FileType == "3" || file.FileType == "4")
                        {
                            dynamicImportFileStatus.Type = "Excel";
                            dynamicImportFileStatus.MSG = "Success";
                            dynamicImportFileStatus.FileConfigID = res;
                        }
                        else if (file.FileType == "6")
                        {
                            dynamicImportFileStatus.Type = "Delimiter";
                            dynamicImportFileStatus.MSG = "Success";
                            dynamicImportFileStatus.FileConfigID = res;
                        }
                        else
                        {
                            dynamicImportFileStatus.Type = "Invalid";
                            dynamicImportFileStatus.MSG = "Format Not Found";
                            dynamicImportFileStatus.FileConfigID = "0";
                        }
                    }
                    else
                    {
                        dynamicImportFileStatus.Type = "Invalid";
                        dynamicImportFileStatus.MSG = "Error Occurred";
                        dynamicImportFileStatus.FileConfigID = "0";
                    }
                }

            }
            catch (Exception ex)
            {
                dynamicImportFileStatus.Type = "Error";
                string s = file.ImportFile != null ? file.ImportFile.FileName : "No File";
                dynamicImportFileStatus.MSG = "" + s + "<br/>" + ex.Message + "";
            }
            return dynamicImportFileStatus;
        }

        [HttpGet("[action]")]
        public object GetExcelDataTable(string FileConfigID)
        {
            DynamicImportFileConfigModel dynamicImportFileConfigModel = _objDynamicFile.GetDynamicFileUploadDetails(FileConfigID);

            DynamicFileContentModel dynamicFileContentModel = _objDynamicFile.GetFileContent(FileConfigID);

            if (dynamicImportFileConfigModel != null && dynamicFileContentModel == null)
            {

                dynamicFileContentModel = UpdateFileContent(dynamicImportFileConfigModel);

                //if (extension == ".xls" || extension == ".xlsx")
                //{
                //    return ExcelTable(dynamicImportFileConfigModel.FilePath, dynamicImportFileConfigModel.ConnectionString, dynamicImportFileConfigModel.FileName);
                //}
                //else if (extension == ".csv")
                //{
                //    return CSVTable(dynamicImportFileConfigModel.FilePath, dynamicImportFileConfigModel.ConnectionString, dynamicImportFileConfigModel.FileName);
                //}
                //else if (dynamicImportFileConfigModel.FileType == "Plaintext With Separator")
                //{
                //    return PlaintextTable(dynamicImportFileConfigModel.FilePath, dynamicImportFileConfigModel.FileSeparator, dynamicImportFileConfigModel.FileName);
                //}
                //else
                //{
                //    return new DataTable().ToJson(); ;
                //}

            }

            return dynamicFileContentModel;
        }

        private DynamicFileContentModel UpdateFileContent(DynamicImportFileConfigModel dynamicImportFileConfigModel)
        {
            DynamicFileContentModel dynamicFileContentModel = new DynamicFileContentModel();

            DataTable returnDataTable = new DataTable();

            string extension = System.IO.Path.GetExtension(dynamicImportFileConfigModel.FilePath);


            if((extension == ".xls" || extension == ".xlsx") && dynamicImportFileConfigModel.ClientID=="84")
            {
                returnDataTable = HtmlToDataTable(dynamicImportFileConfigModel.FilePath);
            }
            else if (extension == ".xls" || extension == ".xlsx")
            {
                returnDataTable = ExcelDataTable(dynamicImportFileConfigModel.FilePath, dynamicImportFileConfigModel.ConnectionString, dynamicImportFileConfigModel.FileName);
            } 
            else if (dynamicImportFileConfigModel.FileType == "Plaintext With Separator")
            {
                returnDataTable = PlaintextDataTable(dynamicImportFileConfigModel.FilePath, dynamicImportFileConfigModel.FileSeparator, dynamicImportFileConfigModel.FileName, dynamicImportFileConfigModel.TableName);
            }
            else if (dynamicImportFileConfigModel.FileType == "Plaintext Without Separator")
            {
                returnDataTable = PlaintextWithoutSeparatorTable(dynamicImportFileConfigModel.FilePath);
            }
            else if (extension == ".csv")
            {
                returnDataTable = CSVDataTable(dynamicImportFileConfigModel.FilePath, dynamicImportFileConfigModel.FileSeparator, dynamicImportFileConfigModel.ConnectionString, dynamicImportFileConfigModel.FileName, dynamicImportFileConfigModel.FileType);
            }

            var columnNames = new string[returnDataTable.Columns.Count];
            for (int i = 0; i < returnDataTable.Columns.Count; i++)
            {
                columnNames[i] = returnDataTable.Columns[i].ColumnName;
            }

            dynamicFileContentModel.FileColumnString = JsonConvert.SerializeObject(columnNames);

            for (int i = 0; i < returnDataTable.Rows.Count; i++)
            {
                var row = returnDataTable.Rows[i];

                if (i == 0)
                {
                    dynamicFileContentModel.FirstRow = JsonConvert.SerializeObject(row.ItemArray);
                }
                else if (i == 1)
                {
                    dynamicFileContentModel.SecondRow = JsonConvert.SerializeObject(row.ItemArray);
                }
                else if (i == 2)
                {
                    dynamicFileContentModel.ThirdRow = JsonConvert.SerializeObject(row.ItemArray);
                }
                else if (i == 3)
                {
                    dynamicFileContentModel.FourthRow = JsonConvert.SerializeObject(row.ItemArray);
                }
                else if (i == 4)
                {
                    dynamicFileContentModel.FifthRow = JsonConvert.SerializeObject(row.ItemArray);
                }

            }

            dynamicFileContentModel.UserName = dynamicImportFileConfigModel.UserName;
            dynamicFileContentModel.ConfigID = dynamicImportFileConfigModel.ConfigID;

            if (dynamicFileContentModel.FileColumnString.Length > 0)
            {
                _objDynamicFile.AddUpdateFileContent(dynamicFileContentModel);
            }

            return dynamicFileContentModel;
        }

        [HttpGet("[action]")]
        public DynamicFileContentModel GetPlaintextWithoutSeparatorDataTable(string FileConfigID)
        {
            DynamicImportFileConfigModel dynamicImportFileConfigModel = _objDynamicFile.GetDynamicFileUploadDetails(FileConfigID);

            DynamicFileContentModel dynamicFileContentModel = _objDynamicFile.GetFileContent(FileConfigID);

            if (dynamicImportFileConfigModel != null && dynamicFileContentModel == null)
            {
                dynamicFileContentModel = UpdateFileContent(dynamicImportFileConfigModel);
            }

            return dynamicFileContentModel;
        }

        private object CSVTable(string path, string ConnectionString, string FileName)
        {
            DataTable dataTable = new DataTable();

            string connString = string.Format(ConnectionString, path.Replace(FileName, ""));

            try
            {
                string Getdatafromsheet1 = "SELECT * FROM [" + FileName + "]";

                using (OleDbConnection connExcelSheet = new OleDbConnection(connString))
                {
                    using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                    {
                        using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                        {
                            //Read Data from First Sheet.
                            cmdExcelSheet.Connection = connExcelSheet;
                            connExcelSheet.Open();
                            cmdExcelSheet.CommandText = Getdatafromsheet1;
                            odaExcelSheet.SelectCommand = cmdExcelSheet;
                            odaExcelSheet.Fill(dataTable);
                            connExcelSheet.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                dataTable = new DataTable();
            }

            if (dataTable.Rows.Count >= 1)
            {
                for (int i = dataTable.Rows.Count - 1; i >= 4; i--)
                {
                    dataTable.Rows.RemoveAt(i);
                }

                List<DataRow> nonDigitRows = new List<DataRow>();
                for (int i = dataTable.Rows.Count - 1; i >= 0; i--)
                {
                    string concatenatedString = string.Join("", dataTable.Rows[i].ItemArray);


                    bool containsDigit = concatenatedString.Any(char.IsDigit);

                    if (!containsDigit)
                    {
                        DataRow headerRow = dataTable.Rows[i];

                        // Rename the columns in the DataTable based on the values in the header row
                        for (int columnIndex = 0; columnIndex < dataTable.Columns.Count; columnIndex++)
                        {
                            dataTable.Columns[columnIndex].ColumnName = headerRow[columnIndex].ToString();
                        }

                        // Remove the header row from the DataTable (optional)
                        dataTable.Rows.Remove(headerRow);

                        for (int NonHeader = i; NonHeader >= 0; NonHeader--)
                        {
                            dataTable.Rows.RemoveAt(NonHeader);
                        }
                        break;
                    }
                }
            }

            JsonDocument jsonDocument = JsonDocument.Parse(dataTable.ToJson());

            return jsonDocument.RootElement;
        }

        private object PlaintextTable(string path, string Seperator, string FileName)
        {
            //int RowCount = 1;
            //DataTable dataTable = new DataTable();

            //using (StreamReader reader = new StreamReader(path))
            //{
            //    string headerLine = reader.ReadLine();
            //    string[] headers = headerLine.Split(separator);

            //    foreach (string header in headers)
            //    {
            //        dataTable.Columns.Add(header);
            //    }

            //    while (!reader.EndOfStream)
            //    {
            //        string dataLine = reader.ReadLine();
            //        string[] data = dataLine.Split(separator);
            //        dataTable.Rows.Add(data);
            //        RowCount++;
            //        if (RowCount >= 5)
            //            break;
            //    }
            //}

            //return dataTable;

            DataTable dataTable = new DataTable("PlainText");
            int LineNo = 0, count = 0, MaxLength = 0;
            string line1 = string.Empty;
            string[] lineArr;
            bool ColumnAdded = false;

            foreach (string line in System.IO.File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty).Trim();

                    lineArr = line1.Split(new[] { Seperator }, StringSplitOptions.None);

                    if (lineArr.Length > MaxLength)
                    {
                        MaxLength = lineArr.Length;
                    }

                    if (LineNo > 5)
                    {
                        break;
                    }
                }
                catch (Exception ex)
                {
                }
            }

            LineNo = 0;

            foreach (string line in System.IO.File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty).Trim();

                    lineArr = line1.Split(new[] { Seperator }, StringSplitOptions.None);

                    if (MaxLength == lineArr.Length && !ColumnAdded)
                    {
                        foreach (string columnName in lineArr)
                        {
                            count++;
                            DataColumn column = new DataColumn("Column" + count.ToString(), typeof(string));
                            dataTable.Columns.Add(column);
                        }

                        if (dataTable.Columns.Count > 0)
                        {
                            ColumnAdded = true;
                        }
                    }

                    if (MaxLength == lineArr.Length)
                    {
                        DataRow row = dataTable.NewRow();
                        // Assign values from lineArr to the DataRow
                        for (int i = 0; i < lineArr.Length; i++)
                        {
                            row[i] = lineArr[i];
                        }

                        dataTable.Rows.Add(row);
                    }

                    if (LineNo > 4)
                    {
                        break;
                    }
                }
                catch (Exception ex)
                {
                }
            }

            JsonDocument jsonDocument = JsonDocument.Parse(dataTable.ToJson());

            return jsonDocument.RootElement;
        }

        private object ExcelTable(string path, string connString, string FileName)
        {
            DataTable dataTable = new DataTable();
            DataTable dt = new DataTable();

            System.Data.OleDb.OleDbConnection objConn = null; 
            DataTable dtexcelsheetname = null;

            int TotalCount = 0;

            connString = string.Format(connString, path);

            bool ErrorOccurred=false; 

            try
            {
                objConn = new OleDbConnection(connString);
                objConn.Open();
            }
            catch (Exception ex)
            {
                ErrorOccurred = true;
            }

            if (!ErrorOccurred)
            {
                using (OleDbConnection connExcel = new OleDbConnection(connString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }

                
                int j = 0;
                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    DataTable dtSheet = new DataTable(); 

                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                    try
                    {
                        OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);

                        da.Fill(dtSheet);

                        objConn.Close();
                    }
                    catch
                    {
                        objConn.Close();
                    }

                    TotalCount = dtSheet.Rows.Count;

                    if (dtSheet.Rows.Count > 0)
                    {
                        dataTable = dtSheet;

                        for (int i = dataTable.Rows.Count - 1; i >= 4; i--)
                        {
                            dataTable.Rows.RemoveAt(i);
                        }

                        List<DataRow> nonDigitRows = new List<DataRow>();
                        for (int i = dataTable.Rows.Count - 1; i >= 0; i--)
                        {
                            string concatenatedString = string.Join("", dataTable.Rows[i].ItemArray);


                            bool containsDigit = concatenatedString.Any(char.IsDigit);

                            if (!containsDigit)
                            {
                                DataRow headerRow = dataTable.Rows[i];

                                // Rename the columns in the DataTable based on the values in the header row
                                for (int columnIndex = 0; columnIndex < dataTable.Columns.Count; columnIndex++)
                                {
                                    dataTable.Columns[columnIndex].ColumnName = Convert.ToString(headerRow[columnIndex]).Length > 0 ? Convert.ToString(headerRow[columnIndex]) : "f" + (columnIndex + 1);
                                }

                                // Remove the header row from the DataTable (optional)
                                dataTable.Rows.Remove(headerRow);

                                //if (dataTable.Rows.Count > i)
                                //{
                                //    for (int NonHeader = i; NonHeader >= 0; NonHeader--)
                                //    {
                                //        dataTable.Rows.RemoveAt(NonHeader);
                                //    }
                                //}
                                break;
                            }
                        }
                        break;

                    }
                }
            }
            JsonDocument jsonDocument = JsonDocument.Parse(dataTable.ToJson());

            return jsonDocument.RootElement;
        }

        private DataTable PlaintextWithoutSeparatorTable(string path)
        {
            DataTable dataTable = new DataTable();
            DataColumn column = new DataColumn("lineData", typeof(string));
            dataTable.Columns.Add(column);
            int LineNo = 0;

            foreach (string line in System.IO.File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    dataTable.Rows.Add(line);
                    if (LineNo > 2)
                    {
                        break;
                    }
                }
                catch
                {
                }
            } 

            return dataTable;            
        }

        [HttpGet("[action]")]
        public object GetXMLSchemaColumn(string FileConfigID)
        {
            return _objDynamicFile.GetDynamicColumnsForMapping(FileConfigID);
        }

        [HttpGet("[action]")]
        public object GetConfiguredColumnString(string FileConfigID)
        {
            return _objDynamicFile.GetConfiguredColumnJsonString(FileConfigID);
        }

        [HttpGet("[action]")]
        public object GetFileConfigData(string FileConfigID)
        {
            return _objDynamicFile.GetDynamicFileConfigData(FileConfigID);
        }

        [HttpPost("[action]")]
        public object UpdateMappedColumn(DynamicFileMappedColumn objModel)
        {
            return _objDynamicFile.UpdateMappedColumnJsonString(objModel);
        }

        [HttpGet("[action]")]
        public object GetDynamicRawTableColumns(string FileConfigID)
        {
            string ConfiguredColumns = _objDynamicFile.GetConfiguredRawColumnString(FileConfigID);

            if (ConfiguredColumns != null && ConfiguredColumns.Length > 0)
            {
                return Newtonsoft.Json.JsonConvert.DeserializeObject<List<XMLColumnModel>>(ConfiguredColumns);
            }
            else
            {
                return _objDynamicFile.GetRawTableSelectedColumns(FileConfigID);
            }
        }

        [HttpGet("[action]")]
        public object GetRawTableSelectedColumns(string FileConfigID)
        {
            return _objDynamicFile.GetRawTableSelectedColumns(FileConfigID);
        }



        [HttpPost("[action]")]
        public object UpdateXMLString(DynamicFileXMLModel objModel)
        {
            if (Convert.ToInt32(objModel.FileConfigID) > 0)
            {

                List<ReconAliasColumnsModel> arrayOfRawColumns = Newtonsoft.Json.JsonConvert.DeserializeObject<List<ReconAliasColumnsModel>>(objModel.RawColumnString);

                DynamicFileConfigDataModel dynamicImportFileConfigModel = _objDynamicFile.GetDynamicFileConfigData(objModel.FileConfigID);

                string TableName = dynamicImportFileConfigModel.TableName;

                List<RawTableColumn> rawColumns = _objDynamicFile.GetRawTableAllColumns(objModel.FileConfigID);

                string commaSeparatedString = "ECardNumber,Cycle,CardType,CardScheme,IssuingNetwork";

                string[] stringArray = commaSeparatedString.Split(',');

                string sqlQuery = "Select ";



                foreach (RawTableColumn objRow in rawColumns)
                {
                    ReconAliasColumnsModel objRawColumn = arrayOfRawColumns.FirstOrDefault(x => x.AliasColumn == objRow.ColumnName);

                    if (objRawColumn != null && objRawColumn.IsChanged)
                    {
                        if (objRawColumn.CaseCondition.Length > 0)
                        {
                            sqlQuery += objRawColumn.CaseCondition + ", ";
                        }
                        else if (objRawColumn.DataColumn == objRawColumn.AliasColumn)
                        {
                            sqlQuery += objRawColumn.DataColumn + ", ";
                        }
                        else if (objRawColumn.DataColumn != objRawColumn.AliasColumn)
                        {
                            sqlQuery += objRawColumn.DataColumn + " as " + objRawColumn.AliasColumn + ", ";
                        }
                    }
                    else
                    {
                        if (objRow.ColumnName == "ClientID")
                        {
                            sqlQuery += dynamicImportFileConfigModel.ClientID + " as " + objRow.ColumnName + ", ";
                        }
                        else if (objRow.ColumnName == "ChannelID")
                        {
                            if (Convert.ToInt32(dynamicImportFileConfigModel.ChannelID) > 0)
                            {
                                sqlQuery += dynamicImportFileConfigModel.ChannelID + " as " + objRow.ColumnName + ", ";
                            }
                            else
                            {
                                sqlQuery += " NULL as " + objRow.ColumnName + ", ";
                            }
                        }
                        else if (objRow.ColumnName == "ModeID")
                        {
                            if (Convert.ToInt32(dynamicImportFileConfigModel.ModeID) > 0)
                            {
                                sqlQuery += dynamicImportFileConfigModel.ModeID + " as " + objRow.ColumnName + ", ";
                            }
                            else
                            {
                                sqlQuery += " NULL as " + objRow.ColumnName + ", ";
                            }
                        }
                        else if (objRow.ColumnName == "NoOfDuplicate")
                        {
                            sqlQuery += "";
                        }
                        else if (Array.Exists(stringArray, s => s.Trim() == objRow.ColumnName))
                        {
                            sqlQuery += objRow.ColumnName + ", ";
                        }
                        else
                        {
                            sqlQuery += " NULL as " + objRow.ColumnName + ", ";
                        }
                    }
                    objRawColumn = null;
                }

                sqlQuery = sqlQuery.Replace("Delete", string.Empty, StringComparison.OrdinalIgnoreCase);

                sqlQuery = sqlQuery.Replace("Truncate", string.Empty, StringComparison.OrdinalIgnoreCase);

                sqlQuery = sqlQuery.Replace("Update", string.Empty, StringComparison.OrdinalIgnoreCase);

                sqlQuery = sqlQuery.Replace("Drop", string.Empty, StringComparison.OrdinalIgnoreCase);

                sqlQuery = sqlQuery.Trim();


                if (sqlQuery.EndsWith(","))
                {
                    sqlQuery = sqlQuery.Substring(0, sqlQuery.Length - 1);
                }


                sqlQuery += "  From @" + TableName;


                List<XMLColumnModel> XMLSchemaColumnList = _objDynamicFile.GetDynamicColumnsForMapping(objModel.FileConfigID);

                string xmlContent = "<?xml version=\"1.0\" encoding=\"utf-16\"?><FileFormat>";

                if (dynamicImportFileConfigModel.FileType == "Plaintext Without Separator")
                {
                    List<DynamicFilePlaintextMappedColumnModel> arrayOfMappedColumns = Newtonsoft.Json.JsonConvert.DeserializeObject<List<DynamicFilePlaintextMappedColumnModel>>(objModel.MappedColumnString);

                    foreach (XMLColumnModel objXML in XMLSchemaColumnList)
                    {
                        DynamicFilePlaintextMappedColumnModel objRawColumn = arrayOfMappedColumns.FirstOrDefault(x => x.MappedColumn == objXML.AliasColumn);

                        if (objRawColumn != null && Convert.ToInt32(objRawColumn.StartPosition) > 0)
                        {
                            xmlContent += "<" + objRawColumn.MappedColumn + ">";
                            xmlContent += "<StartPosition>" + objRawColumn.StartPosition + "</StartPosition><Length>" + objRawColumn.TxtLength + "</Length>";
                            xmlContent += "</" + objRawColumn.MappedColumn + ">";
                        }
                        else
                        {
                            xmlContent += "<" + objXML.AliasColumn + "><StartPosition>0</StartPosition><Length>0</Length></" + objXML.AliasColumn + ">";
                        }
                    }
                }
                else
                {
                    List<DynamicFileMappedColumnModel> arrayOfMappedColumns = Newtonsoft.Json.JsonConvert.DeserializeObject<List<DynamicFileMappedColumnModel>>(objModel.MappedColumnString);

                    foreach (XMLColumnModel objXML in XMLSchemaColumnList)
                    {
                        DynamicFileMappedColumnModel objRawColumn = arrayOfMappedColumns.FirstOrDefault(x => x.MappedColumn == objXML.AliasColumn);

                        if (objRawColumn != null && Convert.ToInt32(objRawColumn.Position) > 0)
                        {
                            xmlContent += "<" + objRawColumn.MappedColumn + ">" + objRawColumn.Position + "</" + objRawColumn.MappedColumn + ">";
                        }
                        else
                        {
                            xmlContent += "<" + objXML.AliasColumn + ">" + "0" + "</" + objXML.AliasColumn + ">";
                        }
                    }
                }

                xmlContent += "</FileFormat>";

                objModel.XMLString = xmlContent;
                objModel.QueryString = sqlQuery;

                return _objDynamicFile.UpdateQueryXMLString(objModel);
            }
            else
            {
                return "Not Found";
            }

        }

        [HttpPost("[action]")]
        public object ParseQuery(DynamicFileMappedColumn objModel)
        {
            List<ReconAliasColumnsModel> arrayOfRawColumns = Newtonsoft.Json.JsonConvert.DeserializeObject<List<ReconAliasColumnsModel>>(objModel.MappedColumnString);

            string sqlQuery = "Select Top 1 ";

            DynamicFileConfigDataModel dynamicImportFileConfigModel = _objDynamicFile.GetDynamicFileConfigData(objModel.FileConfigID);

            string TableName = dynamicImportFileConfigModel.TableName;

            foreach (ReconAliasColumnsModel objRawColumn in arrayOfRawColumns)
            {

                if (objRawColumn != null && objRawColumn.IsChanged)
                {
                    if (objRawColumn.CaseCondition.Length > 0)
                    {
                        sqlQuery += objRawColumn.CaseCondition + " as " + objRawColumn.AliasColumn + ", ";
                    }
                    else if (objRawColumn.DataColumn == objRawColumn.AliasColumn)
                    {
                        sqlQuery += objRawColumn.DataColumn + ", ";
                    }
                    else if (objRawColumn.DataColumn != objRawColumn.AliasColumn)
                    {
                        sqlQuery += objRawColumn.DataColumn + " as " + objRawColumn.AliasColumn + ", ";
                    }
                }
            }

            sqlQuery = sqlQuery.Replace("Delete", string.Empty, StringComparison.OrdinalIgnoreCase);

            sqlQuery = sqlQuery.Replace("Truncate", string.Empty, StringComparison.OrdinalIgnoreCase);

            sqlQuery = sqlQuery.Replace("Update", string.Empty, StringComparison.OrdinalIgnoreCase);

            sqlQuery = sqlQuery.Replace("Drop", string.Empty, StringComparison.OrdinalIgnoreCase);

            sqlQuery = sqlQuery.Trim();

            if (sqlQuery.EndsWith(","))
            {
                sqlQuery = sqlQuery.Substring(0, sqlQuery.Length - 1);
            }

            string TypeTableName = _objDynamicFile.GetDynamicFileConfigTable(objModel.FileConfigID);

            //if (TableName == "SWITCH")
            //{
            //    TableName = "tempSwitchData";
            //}
            //else if (TableName == "EJ")
            //{
            //    TableName = "tempEJData";
            //}
            //else if (TableName == "CBS")
            //{
            //    TableName = "tempGLData";
            //}
            //else if (TableName == "NETWORK")
            //{
            //    if (dynamicImportFileConfigModel.ChannelID == "7" && dynamicImportFileConfigModel.ModeID == "4" && dynamicImportFileConfigModel.VendorName == "NPCI")
            //    {
            //        TableName = "tempUPIISSUERDATA";
            //    }
            //    else if (dynamicImportFileConfigModel.ChannelID == "7" && dynamicImportFileConfigModel.ModeID == "5" && dynamicImportFileConfigModel.VendorName == "NPCI")
            //    {
            //        TableName = "tempUPIAcquierData";
            //    }
            //    else if (dynamicImportFileConfigModel.ChannelID == "4" && dynamicImportFileConfigModel.ModeID == "4" && dynamicImportFileConfigModel.VendorName == "NPCI")
            //    {
            //        TableName = "tempIMPSISSUERDATA";
            //    }
            //    else if (dynamicImportFileConfigModel.ChannelID == "4" && dynamicImportFileConfigModel.ModeID == "5" && dynamicImportFileConfigModel.VendorName == "NPCI")
            //    {
            //        TableName = "tempIMPSAcquirerDATA";
            //    }
            //    else if (dynamicImportFileConfigModel.ChannelID == "2" && dynamicImportFileConfigModel.ModeID == "3" && dynamicImportFileConfigModel.VendorName == "NPCI")
            //    {
            //        TableName = "tempPOSIssuerNPCI";
            //    }
            //    else if (dynamicImportFileConfigModel.ChannelID == "1" && dynamicImportFileConfigModel.ModeID == "3" && dynamicImportFileConfigModel.VendorName == "NPCI")
            //    {
            //        TableName = "tempNPCIIssuerATM";
            //    }
            //    else if (dynamicImportFileConfigModel.ChannelID == "1" && dynamicImportFileConfigModel.ModeID == "2" && dynamicImportFileConfigModel.VendorName == "NPCI")
            //    {
            //        TableName = "tempPOSIssuerNPCI";
            //    }
            //}

            sqlQuery += " INTO #Temp From " + TypeTableName;

            objModel.MappedColumnString = sqlQuery;

            return _objDynamicFile.ParseSqlQuery(objModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetFileTypeList(string FileExtension)
        {
            return _objDynamicFile.GetFileTypeConfig(FileExtension);
        }

        [HttpPost("[action]")]
        public object UpdateDateTimeFormate(DateTimeFormat dateTimeFormat)
        {
            if (Convert.ToInt32(dateTimeFormat.FileConfigID) > 0)
            {
                return _objDynamicFile.UpdateDateTimeFormat(dateTimeFormat);
            }
            else
            {
                return "Not Found";
            }

        }

        [HttpGet("[action]")]
        public object GetDateTimeFormate(string FileConfigID, string TableName)
        {
            return _objDynamicFile.GetDateTimeFormat(FileConfigID, TableName);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAllChannelOptionList()
        {
            return _objDynamicFile.GetChannelList();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAllModeOptionList()
        {
            return _objDynamicFile.GetModeList();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetDynamicChannelConfigList(string ClientID)
        {
            return _objDynamicFile.GetDynamicChannelConfigGrid(ClientID);
        }

        [HttpPost("[action]")]
        public string AddUpdateDynamicChannelConfig(ASPTrace.Models.DynamicChannelModeConfigModel ConfigModel)
        {
            try
            {
                string MSG = string.Empty;

                string res = _objDynamicFile.AddUpdateChannelConfig(ConfigModel);

                if (res == "Save")
                {
                    MSG = "Added successfully";
                }
                else if (res == "Exists")
                {
                    MSG = "Already Exists";
                }
                else
                {
                    MSG = "Error Occurred";
                }

                return MSG;
            }
            catch (Exception ex)
            {
                return "Failure :" + ex.Message;
            }

        }

        private DataTable HtmlToDataTable(string htmlPath)
        {
           string html = System.IO.File.ReadAllText(htmlPath);
            HtmlDocument doc = new HtmlDocument();
            doc.LoadHtml(html);

            var tables = doc.DocumentNode.SelectNodes("//table");
            if (tables == null || tables.Count == 0)
                throw new Exception("No <table> found in file: " + htmlPath);

            // Pick the last table (your transaction data)
            var table = tables.Last();
            var rows = table.SelectNodes(".//tr");
            if (rows == null || rows.Count == 0)
                throw new Exception("No <tr> found in last table.");

            DataTable dt = new DataTable();

            var headers = rows[0].SelectNodes(".//td|.//th");
            if (headers == null)
                throw new Exception("No headers found in last table.");

            foreach (var header in headers)
                dt.Columns.Add(header.InnerText.Trim());

            for (int i = 1; i < rows.Count; i++)
            {
                var cells = rows[i].SelectNodes(".//td");
                if (cells == null)
                    continue;

                DataRow dr = dt.NewRow();
                for (int j = 0; j < dt.Columns.Count && j < cells.Count; j++)
                    dr[j] = cells[j].InnerText.Trim();

                dt.Rows.Add(dr);
            }

            return dt;
        }
        private DataTable ExcelDataTable(string path, string connString, string FileName)
        {
            DataTable dataTable = new DataTable();
            DataTable dt = new DataTable();

            System.Data.OleDb.OleDbConnection objConn = null;
            DataTable dtexcelsheetname = null;

            int TotalCount = 0;

            connString = string.Format(connString, path);

            bool ErrorOccurred = false;

            try
            {
                objConn = new OleDbConnection(connString);
                objConn.Open();
            }
            catch (Exception ex)
            {
                ErrorOccurred = true;
            }

            if (!ErrorOccurred)
            {
                using (OleDbConnection connExcel = new OleDbConnection(connString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }

                
                int j = 0;
                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    DataTable dtSheet = new DataTable(); 

                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                    try
                    {
                        OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);

                        da.Fill(dtSheet);

                        objConn.Close();
                    }
                    catch
                    {
                        objConn.Close();
                    }

                    TotalCount = dtSheet.Rows.Count;

                    if (dtSheet.Rows.Count > 0)
                    {
                        dataTable = dtSheet;

                        for (int i = dataTable.Rows.Count - 1; i >= 4; i--)
                        {
                            dataTable.Rows.RemoveAt(i);
                        }

                        List<DataRow> nonDigitRows = new List<DataRow>();
                        for (int i = dataTable.Rows.Count - 1; i >= 0; i--)
                        {
                            string concatenatedString = string.Join("", dataTable.Rows[i].ItemArray);


                            bool containsDigit = concatenatedString.Any(char.IsDigit);

                            if (!containsDigit)
                            {
                                DataRow headerRow = dataTable.Rows[i];

                                // Rename the columns in the DataTable based on the values in the header row
                                for (int columnIndex = 0; columnIndex < dataTable.Columns.Count; columnIndex++)
                                {
                                    dataTable.Columns[columnIndex].ColumnName = Convert.ToString(headerRow[columnIndex]).Length > 0 ? Convert.ToString(headerRow[columnIndex]) : "f" + (columnIndex + 1);
                                }

                                // Remove the header row from the DataTable (optional)
                                dataTable.Rows.Remove(headerRow);

                                //if (dataTable.Rows.Count > i)
                                //{
                                //    for (int NonHeader = i; NonHeader >= 0; NonHeader--)
                                //    {
                                //        dataTable.Rows.RemoveAt(NonHeader);
                                //    }
                                //}
                                break;
                            }
                        }
                        break;

                    }
                }
            }


            return dataTable;
        }

        private DataTable CSVDataTable(string path, string Seperator, string ConnectionString, string FileName, string FileType)
        {
            DataTable dataTable = new DataTable();
            string line1 = string.Empty;
            string[] lineArr;
            string[] fields;
            string connString = string.Format(ConnectionString, path.Replace(FileName, ""));
            int largestIndex = 0;
            bool ColumnAdded = false;
            try
            {
                dataTable = new DataTable();

                using (TextFieldParser parser = new TextFieldParser(path))
                {
                    parser.TextFieldType = FieldType.Delimited;
                    parser.SetDelimiters(Seperator);

                    while (!parser.EndOfData)
                    {
                        fields = parser.ReadFields();

                        for (int i = 0; i < fields.Length; i++)
                        {
                            if (i > largestIndex) largestIndex = i;
                        }

                        Array.Clear(fields);
                    }
                }

                largestIndex = largestIndex + 1;

                using (TextFieldParser parser = new TextFieldParser(path))
                {
                    parser.TextFieldType = FieldType.Delimited;
                    parser.SetDelimiters(Seperator);

                    while (!parser.EndOfData)
                    {
                        fields = parser.ReadFields();

                        if (fields.Length == largestIndex)
                        {
                            if (fields[largestIndex - 1].Trim().Length >= 0)
                            {
                                if (!ColumnAdded)
                                {
                                    if (FileType == "CSV file with header")
                                    {
                                        for (int i = 0; i < fields.Length; i++)
                                        {
                                            if (Convert.ToString(fields[i]).Trim().Length > 0)
                                            {
                                                dataTable.Columns.Add(fields[i].Trim(), typeof(string));
                                            }
                                            else
                                            {
                                                dataTable.Columns.Add("f" + (i + 1), typeof(string));
                                            }

                                        }

                                        ColumnAdded = true;
                                    }
                                    else
                                    {
                                        for (int i = 1; i <= fields.Length; i++)
                                        {
                                            dataTable.Columns.Add("f" + (i + 1), typeof(string));
                                        }

                                        ColumnAdded = true;
                                    }
                                }

                                dataTable.Rows.Add(fields);

                                if (dataTable.Rows.Count >= 4) break;
                            }

                            Array.Clear(fields);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                dataTable = new DataTable();
            } 

            return dataTable;
        }

        private DataTable PlaintextDataTable(string path, string Seperator, string FileName, string Logtype)
        {             

            DataTable dataTable = new DataTable("PlainText");
            int LineNo = 0, count = 0, MaxLength = 0;
            string line1 = string.Empty;
            string[] lineArr;
            bool ColumnAdded = false;

            foreach (string line in System.IO.File.ReadAllLines(path))
            {
                LineNo++;
                if (Logtype == "GLAdjustment" && LineNo < 4)
                {
                    continue; ;
                }
                try
                {
                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty).Trim();

                    lineArr = line1.Split(new[] { Seperator }, StringSplitOptions.None);

                    if (lineArr.Length > MaxLength)
                    {
                        MaxLength = lineArr.Length;
                    }
                    if (Logtype == "GLAdjustment")
                    {
                        if (LineNo > 6)
                        {
                            break;
                        }
                    }
                    else
                    {
                        if (LineNo > 2)
                        {
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }

            LineNo = 0;

            foreach (string line in System.IO.File.ReadAllLines(path))
            {
                LineNo++;
                if (Logtype == "GLAdjustment" && LineNo < 4)
                {
                    continue; ;
                }
                try
                {
                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty).Trim();

                    lineArr = line1.Split(new[] { Seperator }, StringSplitOptions.None);

                    if (MaxLength == lineArr.Length && !ColumnAdded)
                    {
                        foreach (string columnName in lineArr)
                        {
                            count++;
                            DataColumn column = new DataColumn("Column" + count.ToString(), typeof(string));
                            dataTable.Columns.Add(column);
                        }

                        if (dataTable.Columns.Count > 0)
                        {
                            ColumnAdded = true;
                        }
                    }

                    if (MaxLength == lineArr.Length)
                    {
                        DataRow row = dataTable.NewRow();
                        // Assign values from lineArr to the DataRow
                        for (int i = 0; i < lineArr.Length; i++)
                        {
                            row[i] = lineArr[i];
                        }

                        dataTable.Rows.Add(row);
                    }

                    if (Logtype == "GLAdjustment")
                    {
                        if (LineNo > 9)
                        {
                            break;
                        }
                    }
                    else
                    {
                        if (LineNo > 4)
                        {
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }             

            return dataTable;
        }


        [HttpPost("[action]")]
        public object GetClientList(ASPTrace.Models.DynamicFileConfigModel ConfigModel)
        {
            return _objDynamicFile.GetClientListByConfig(ConfigModel);
        }

        [HttpPost("[action]")]
        public string CopyExistingDynamicFileConfig(ASPTrace.Models.tempDynamicFileConfigModel ConfigModel)
        {
            try
            {
                string MSG = string.Empty;

                string res = _objDynamicFile.CopyDynamicFileConfig(ConfigModel);

                if (res == "Save")
                {
                    MSG = "Copied successfully";
                }
                else if (res == "Exists")
                {
                    MSG = "Already Exists";
                }
                else
                {
                    MSG = "Error Occurred";
                }

                return MSG;
            }
            catch (Exception ex)
            {
                return "Failure :" + ex.Message;
            }

        }

        [Route("[action]")]
        [HttpPost]
        public object DeleteChannelConfig(DeleteChannelConfigModel obj)
        {
            return _objDynamicFile.DeleteChannelModeConfig(obj);
        }
    }
}