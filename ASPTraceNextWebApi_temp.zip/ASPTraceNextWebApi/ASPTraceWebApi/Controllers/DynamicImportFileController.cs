﻿using ASPTrace.Models;
using CBS; 
using ImportData;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc; 
using NetworkNPCI;
using SWITCH;
using System;
using System.Data;  
using System.Globalization;
using System.Text.RegularExpressions;
using Utility;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class DynamicImportFileController : ControllerBase
    {
        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.IDynamicImportLogs objIImportLogs;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        int  FileUploadStatus = 0;
        string tempFiletype = string.Empty;
        DateTime? StartTime = null;

        public DynamicImportFileController(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.IDynamicImportLogs _objIImportLogs, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objIImportLogs = _objIImportLogs;
            objCommon = _Common;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientOptionList(string UserID)
        {
            return objIImportLogs.GetClientOptions(UserID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetFileTypeOptionList(string ClientId)
        {
            return objIImportLogs.GetFileTypeOptions(ClientId);
        }

        //[Route("[action]")]
        [HttpPost]  
        public object Post([FromForm] ASPTrace.Models.ImportFileModel file)
        {
            ASPTrace.Models.ImportFileStatus importFileStatus = new ASPTrace.Models.ImportFileStatus();

            try
            {
                bool IsEncryption = System.Convert.ToBoolean(_configuration.GetValue<string>("AppSettings:IsEncryption"));
                string EMekKey1 = _configuration["AppSettings:EMekKey1"];
                string relativePath = _configuration["AppSettings:MekKey2Path"];
                string EMekKey2 = System.IO.File.ReadAllText(relativePath).Trim();

                string Connectionstring = IsEncryption ? AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMekKey1, EMekKey2) : _configuration.GetConnectionString("TraceConnection");


                string MSG = string.Empty;
                string tempMSG = string.Empty;

                DateTime? FileDateTime = null;

                if (file.ImportFile == null || file.ImportFile.Length == 0)
                {
                    importFileStatus.MSG = "Error";
                    importFileStatus.Status = "File not selected";
                }
                else
                {
                    Random rnd = new Random();
                    int randomNumber = rnd.Next(1, 1000001);

                    string sFileName = "T_" + DateTime.Now.ToString("HHmmssfffff") + "_" + file.ImportFile.FileName;

                    string path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\Switch\\", sFileName);

                    DataTable dt = objIImportLogs.GetDynamicFieldDetailsById(file.ClientID, file.FileFormatId);

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        string FileNameContains = Convert.ToString(dt.Rows[0]["FileNameContains"]);
                        string allowedExtStr = Convert.ToString(dt.Rows[0]["AllowedExtensions"]);
                        string[] allowedExtensions = allowedExtStr.Split(',', StringSplitOptions.RemoveEmptyEntries);

                        // Check if file name contains a string
                        if (file.ImportFile.FileName.Contains(FileNameContains, StringComparison.OrdinalIgnoreCase))
                        {
                            // Check if file extension is allowed
                            if (allowedExtensions.Any(ext => ext.Equals(System.IO.Path.GetExtension(file.ImportFile.FileName).TrimStart('.'), StringComparison.OrdinalIgnoreCase)))
                            {
                                using (System.IO.Stream stream = new System.IO.FileStream(path, System.IO.FileMode.Create))
                                {
                                    file.ImportFile.CopyTo(stream);
                                }

                                string sFileExt1 = System.IO.Path.GetExtension(file.ImportFile.FileName);
                                string FileImportID = string.Empty;

                                FileImportRequest fileImportRequest = new FileImportRequest();
                                fileImportRequest.Path = path;
                                fileImportRequest.FileName = file.ImportFile.FileName;
                                fileImportRequest.ConfigData = dt;
                                fileImportRequest.UserName = file.UserName;
                                fileImportRequest.ClientCode = file.ClientID;
                                fileImportRequest.UserName = file.UserName;


                                StartTime = DateTime.Now;
                                string VendorType = Convert.ToString(dt.Rows[0]["VendorType"]);
                                tempFiletype = Convert.ToString(dt.Rows[0]["VendorType"]);
                                int QClientID = Convert.ToString(dt.Rows[0]["ClientID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ClientID"]);
                                int QChannelID = Convert.ToString(dt.Rows[0]["ChannelID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ChannelID"]);
                                int QModeID = Convert.ToString(dt.Rows[0]["ModeID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ModeID"]);
                                //int QVendorID = Convert.ToString(dt.Rows[0]["VendorID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["VendorID"]);

                                FileUploadStatusModel objInsert = new FileUploadStatusModel();
                                objInsert.ClientID = QClientID;
                                objInsert.ChannelID = QChannelID;
                                objInsert.ModeID = QModeID;
                                objInsert.FileFormatId = file.FileFormatId;
                                objInsert.FileName = file.ImportFile.FileName;
                                objInsert.FilePath = path;
                                objInsert.FileDate = FileDateTime;
                                objInsert.CreatedBy = file.UserName;

                                FileImportID = objCommon.InsertFileUploadDetail(objInsert);

                                if (Convert.ToInt64(FileImportID) == 0)
                                {
                                    throw new Exception("Failed to insert file upload details. ");
                                }

                                fileImportRequest.FileImportID = FileImportID;

                                fileImportRequest.FailedBatches = objIImportLogs.GetStartBatchPosition(sFileName, QClientID, QChannelID, QModeID);

                                string FileDateFormat = dt.Rows[0]["FileDateFormat"].ToString();
                                int? StartPosition = dt.Rows[0]["StartPosition"] != DBNull.Value ? Convert.ToInt32(dt.Rows[0]["StartPosition"]) : (int?)null;
                                int? EndPosition = dt.Rows[0]["EndPosition"] != DBNull.Value ? Convert.ToInt32(dt.Rows[0]["EndPosition"]) : (int?)null;
                                //GetDate
                                DtDetails details = new DtDetails();
                                FileDateTime = GetFileDate(file, path, QChannelID, QModeID, FileDateFormat, StartPosition, EndPosition);

                                fileImportRequest.FileDateTime = FileDateTime;

                                DataTable _DataTable = new DataTable();

                                switch (VendorType)
                                {
                                    case "GL":
                                    case "CBS":
                                        MSG = string.Empty;
                                        ASP_CBS_Splitter cbsSplitter = new ASP_CBS_Splitter(Connectionstring, EMekKey1, EMekKey2);

                                        if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                        {
                                            if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" || Convert.ToString(dt.Rows[0]["ChannelID"]) == "21")
                                            {
                                                MSG = cbsSplitter.SplitterExcel_Dynamic_UPI(fileImportRequest);
                                            }
                                            else
                                            {
                                                MSG = cbsSplitter.SplitterExcel_Dynamic(fileImportRequest);
                                            }
                                        }
                                        else if (Convert.ToString(dt.Rows[0]["FileType"]) == "Delimiter")
                                        {
                                            if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" || Convert.ToString(dt.Rows[0]["ChannelID"]) == "21")
                                            {
                                                if (Convert.ToString(dt.Rows[0]["ClientID"]) == "100")
                                                {
                                                    MSG = cbsSplitter.SplitterDelimiter_Dynamic_QR(fileImportRequest);
                                                }
                                                else
                                                {
                                                    MSG = cbsSplitter.SplitterDelimiter_Dynamic_UPI(fileImportRequest);
                                                }
                                            }
                                            else
                                            {
                                                MSG = cbsSplitter.SplitterDelimiter_Dynamic(fileImportRequest);
                                            }
                                        }
                                        else if (Convert.ToString(dt.Rows[0]["FileType"]) == "Plaintext Without Separator")
                                        {
                                            if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" || Convert.ToString(dt.Rows[0]["ChannelID"]) == "21")
                                            {
                                                MSG = cbsSplitter.SplitterText_Dynamic_UPI(fileImportRequest);
                                            }
                                            else
                                            {
                                                MSG = cbsSplitter.SplitterText_Dynamic(fileImportRequest);
                                            }
                                        }


                                        break;

                                    case "Switch":
                                        MSG = string.Empty;
                                        ASP_SWITCH_Splitter sWITCH_Splitter = new ASP_SWITCH_Splitter(Connectionstring, EMekKey1, EMekKey2);

                                        DataSet _dataSetUpi = new DataSet();

                                        if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                        {
                                            if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" || Convert.ToString(dt.Rows[0]["ChannelID"]) == "21")
                                            {
                                                MSG = sWITCH_Splitter.SplitterExcel_Dynamic_UPI(fileImportRequest);
                                            }
                                            else
                                            {
                                                MSG = sWITCH_Splitter.SplitterExcel_Dynamic(fileImportRequest);
                                            }
                                        }
                                        else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                        {
                                            if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" || Convert.ToString(dt.Rows[0]["ChannelID"]) == "21")
                                            {
                                                MSG = sWITCH_Splitter.SplitterDelimiter_Dynamic_UPI(fileImportRequest);
                                            }
                                            else
                                            {
                                                MSG = sWITCH_Splitter.SplitterDelimiter_Dynamic(fileImportRequest);
                                            }
                                        }
                                        else if (Convert.ToString(dt.Rows[0]["FileType"]) == "Plaintext Without Separator")
                                        {
                                            MSG = sWITCH_Splitter.SplitterText_Dynamic(fileImportRequest);
                                        }

                                        break;
                                    case "Log":
                                        if ((Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" && Convert.ToString(dt.Rows[0]["ModeID"]) == "4") || (Convert.ToString(dt.Rows[0]["ChannelID"]) == "21" && Convert.ToString(dt.Rows[0]["ModeID"]) == "4"))
                                        {
                                            NPCIUPI _upiSpliter = new NPCIUPI(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _upiSpliter.Splitter_UPI_Issuer_Excel_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = _upiSpliter.Splitter_UPI_Issuer_Delimiter_Dynamic(fileImportRequest);
                                            }


                                        }
                                        else if ((Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" && Convert.ToString(dt.Rows[0]["ModeID"]) == "5") || (Convert.ToString(dt.Rows[0]["ChannelID"]) == "21" && Convert.ToString(dt.Rows[0]["ModeID"]) == "5"))
                                        {
                                            NPCIUPI _upiSpliter = new NPCIUPI(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _upiSpliter.Splitter_UPI_Acquirer_Excel_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = _upiSpliter.Splitter_UPI_Acquirer_Delimiter_Dynamic(fileImportRequest);
                                            }


                                        }

                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "4" && Convert.ToString(dt.Rows[0]["ModeID"]) == "4")
                                        {
                                            NPCIIMPS _upiSpliter = new NPCIIMPS(Connectionstring);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _upiSpliter.Splitter_IMPS_Issuer_Excel_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = _upiSpliter.Splitter_IMPS_Issuer_Delimiter_Dynamic(fileImportRequest);
                                            }

                                        }
                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "4" && Convert.ToString(dt.Rows[0]["ModeID"]) == "5")
                                        {
                                            NPCIIMPS _upiSpliter = new NPCIIMPS(Connectionstring);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _upiSpliter.Splitter_IMPS_Acquirer_Excel_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = _upiSpliter.Splitter_IMPS_Acquirer_Delimiter_Dynamic(fileImportRequest);
                                            }

                                        }

                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "2" && Convert.ToString(dt.Rows[0]["ModeID"]) == "3")
                                        {
                                            NPCIPOSECOM _upiSpliter = new NPCIPOSECOM(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Plaintext"))
                                            {
                                                MSG = _upiSpliter.Splitter_POS_Issuer_Text_Dynamic(fileImportRequest);
                                            }

                                        }
                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "1" && Convert.ToString(dt.Rows[0]["ModeID"]) == "3")
                                        {
                                            NPCIATM _upiSpliter = new NPCIATM(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Plaintext"))
                                            {
                                                MSG = _upiSpliter.Splitter_NPCI_Issuer_ATM_Text_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = _upiSpliter.Splitter_NPCI_Issuer_ATM_Delimiter_Dynamic(fileImportRequest);
                                            }

                                        }
                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "1" && Convert.ToString(dt.Rows[0]["ModeID"]) == "2")
                                        {
                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Plaintext"))
                                            {
                                                NPCIATM _upiSpliter = new NPCIATM(Connectionstring, EMekKey1, EMekKey2);
                                                MSG = _upiSpliter.Splitter_NPCI_Acquirer_ATM_Text_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                NPCIATM _upiSpliter = new NPCIATM(Connectionstring, EMekKey1, EMekKey2);
                                                MSG = _upiSpliter.Splitter_NPCI_Acquirer_ATM_Delimiter_Dynamic(fileImportRequest);
                                            }
                                        }

                                        //MATM start
                                        //ACQ
                                        else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Plaintext") && Convert.ToString(dt.Rows[0]["ChannelID"]) == "5" && Convert.ToString(dt.Rows[0]["ModeID"]) == "2")
                                        {
                                            NPCIATM _upiSpliter = new NPCIATM(Connectionstring, EMekKey1, EMekKey2);
                                            MSG = _upiSpliter.Splitter_NPCI_Acquirer_ATM_Text_Dynamic(fileImportRequest);
                                        }

                                        //Issuer
                                        else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Plaintext") && Convert.ToString(dt.Rows[0]["ChannelID"]) == "5" && Convert.ToString(dt.Rows[0]["ModeID"]) == "3")
                                        {
                                            NPCIATM _upiSpliter = new NPCIATM(Connectionstring, EMekKey1, EMekKey2);
                                            MSG = _upiSpliter.Splitter_NPCI_Issuer_ATM_Text_Dynamic(fileImportRequest);

                                        }

                                        //MATM End

                                        //AEPS Start
                                        else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Plaintext") && Convert.ToString(dt.Rows[0]["ChannelID"]) == "13" && Convert.ToString(dt.Rows[0]["ModeID"]) == "2")
                                        {
                                            NPCIAEPS _aepsSpliter = new NPCIAEPS(Connectionstring);
                                            MSG = _aepsSpliter.Splitter_NPCI_Acquirer_AEPS_Dynamic(fileImportRequest);
                                        }

                                        else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Plaintext") && Convert.ToString(dt.Rows[0]["ChannelID"]) == "13" && Convert.ToString(dt.Rows[0]["ModeID"]) == "3")
                                        {
                                            NPCIAEPS _aepsSpliter = new NPCIAEPS(Connectionstring);
                                            MSG = _aepsSpliter.Splitter_NPCI_Issuer_AEPS_Dynamic(fileImportRequest);

                                        }
                                        //   AEPS END

                                        break;

                                    case "Adjustment":
                                        //UPI Adjustment (DynamicImportFileController)
                                        if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" || Convert.ToString(dt.Rows[0]["ChannelID"]) == "21")
                                        {
                                            NPCIUPI _upiSpliter1 = new NPCIUPI(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = _upiSpliter1.Splitter_UPI_Adjustment_Delimiter_Dynamic(fileImportRequest);
                                            }

                                        }
                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "1")
                                        {
                                            NPCIATM _upiSpliter = new NPCIATM(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _upiSpliter.Splitter_NPCI_ATM_Adjustment_Excel_Dynamic(fileImportRequest);
                                            }

                                        }
                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "4")
                                        {
                                            NPCIIMPS _impsSpliter = new NPCIIMPS(Connectionstring);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _impsSpliter.Splitter_IMPS_Adjustment_Excel_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = _impsSpliter.Splitter_IMPS_Adjustment_Delimiter_Dynamic(fileImportRequest);
                                            }

                                        }


                                        break;

                                    case "Settlement":

                                        if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "5")
                                        {
                                            NPCIATM _upiSpliter = new NPCIATM(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _upiSpliter.Splitter_NPCI_Settlement_ATM_Excel_Dynamic(fileImportRequest);
                                            }

                                        }

                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" || Convert.ToString(dt.Rows[0]["ChannelID"]) == "21")
                                        {
                                            NPCIUPI _Spliter = new NPCIUPI(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _Spliter.Splitter_NPCI_Settlement_UPI_Excel_Dynamic(fileImportRequest);
                                            }

                                        }
                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "4")
                                        {
                                            NPCIIMPS _Spliter = new NPCIIMPS(Connectionstring);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _Spliter.Splitter_NPCI_Settlement_IMPS_Excel_Dynamic(fileImportRequest);
                                            }


                                        }
                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "1")
                                        {
                                            NPCIATM _upiSpliter = new NPCIATM(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                ////  string htmlPath = path;
                                                //string xlsPath = System.IO.Path.ChangeExtension(path, ".xls");

                                                //new ExcelHtmlConverter().ConvertExcelHtmlToXlsx(path, xlsPath);

                                                MSG = _upiSpliter.Splitter_NPCI_Settlement_ATM_Excel_Dynamic(fileImportRequest);
                                            }

                                        }
                                        else if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "13")
                                        {
                                            NPCIAEPS _aepsSpliter = new NPCIAEPS(Connectionstring);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _aepsSpliter.Splitter_NPCI_Settlement_AEPS_Excel_Dynamic(fileImportRequest);
                                            }

                                        }


                                        break;

                                    case "MerchantFile":

                                        if ((Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" && Convert.ToString(dt.Rows[0]["ModeID"]) == "4") || (Convert.ToString(dt.Rows[0]["ChannelID"]) == "21" && Convert.ToString(dt.Rows[0]["ModeID"]) == "4"))
                                        {
                                            NPCIUPI _upiSpliterIn = new NPCIUPI(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _upiSpliterIn.Splitter_UPI_Issuer_Excel_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = _upiSpliterIn.Splitter_UPI_Issuer_Delimiter_Dynamic(fileImportRequest);
                                            }


                                        }
                                        else if ((Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" && Convert.ToString(dt.Rows[0]["ModeID"]) == "5") || (Convert.ToString(dt.Rows[0]["ChannelID"]) == "21" && Convert.ToString(dt.Rows[0]["ModeID"]) == "5"))
                                        {
                                            NPCIUPI _upiSpliterOut = new NPCIUPI(Connectionstring, EMekKey1, EMekKey2);

                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = _upiSpliterOut.Splitter_UPI_Acquirer_Excel_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = _upiSpliterOut.Splitter_UPI_Acquirer_Delimiter_Dynamic(fileImportRequest);
                                            }

                                        }
                                        //AEPS Start
                                        else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Plaintext") && Convert.ToString(dt.Rows[0]["ChannelID"]) == "13" && Convert.ToString(dt.Rows[0]["ModeID"]) == "2")
                                        {
                                            NPCIAEPS _aepsSpliter = new NPCIAEPS(Connectionstring);
                                            MSG = _aepsSpliter.Splitter_NPCI_Acquirer_AEPS_Dynamic(fileImportRequest);
                                        }

                                        else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Plaintext") && Convert.ToString(dt.Rows[0]["ChannelID"]) == "13" && Convert.ToString(dt.Rows[0]["ModeID"]) == "3")
                                        {
                                            NPCIAEPS _aepsSpliter = new NPCIAEPS(Connectionstring);
                                            MSG = _aepsSpliter.Splitter_NPCI_Issuer_AEPS_Dynamic(fileImportRequest);

                                        }
                                        break;

                                    case "GLAdjustment":
                                        MSG = string.Empty;
                                        ASP_CBS_Splitter glcbsSplitter = new ASP_CBS_Splitter(Connectionstring, EMekKey1, EMekKey2);
                                        MSG = glcbsSplitter.Splitter_GL_Adjustment_Delimiter_Dynamic(fileImportRequest);
                                        break;


                                    case "DRC":
                                        MSG = string.Empty;
                                        NPCIUPI objDRC = new NPCIUPI(Connectionstring, EMekKey1, EMekKey2);

                                        if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" || Convert.ToString(dt.Rows[0]["ChannelID"]) == "21")
                                        {
                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = objDRC.Splitter_NPCI_UPI_DRC_Excel_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = objDRC.Splitter_NPCI_UPI_DRC_Delimiter_Dynamic(fileImportRequest);
                                            }
                                        }
                                        break;

                                    case "SummaryPresentmentSettlement":
                                        MSG = string.Empty;

                                        if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "2")
                                        {
                                            fileImportRequest.FileName = sFileName;
                                            NPCIPOSECOM _POSSetFileSpliter = new NPCIPOSECOM(Connectionstring, EMekKey1, EMekKey2);
                                            MSG = _POSSetFileSpliter.ProcessSummaryPresentmentSettlementSpliter(fileImportRequest);
                                        }
                                        break;

                                    case "Refund":
                                        MSG = string.Empty;

                                        if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "2")
                                        {
                                            fileImportRequest.FileName = sFileName;
                                            NPCIPOSECOM _POSSetFileSpliter = new NPCIPOSECOM(Connectionstring, EMekKey1, EMekKey2);
                                            MSG = _POSSetFileSpliter.Splitter_POS_RefundLog(fileImportRequest);
                                        }
                                        break;

                                    case "LateReversal":
                                        MSG = string.Empty;

                                        if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "1")
                                        {
                                            fileImportRequest.FileName = sFileName;
                                            NPCIATM _POSSetFileSpliter = new NPCIATM(Connectionstring, EMekKey1, EMekKey2);
                                            MSG = _POSSetFileSpliter.Splitter_ATM_Late_Reversal_Excel_Dynamic(fileImportRequest);
                                        }
                                        break;

                                    #region IMPS_UPI_TimeOut
                                    case "TimeOut":
                                        MSG = string.Empty;
                                        NPCIUPI objTimeOut = new NPCIUPI(Connectionstring, EMekKey1, EMekKey2);

                                        if (Convert.ToString(dt.Rows[0]["ChannelID"]) == "7" || Convert.ToString(dt.Rows[0]["ChannelID"]) == "4" || Convert.ToString(dt.Rows[0]["ChannelID"]) == "21")
                                        {
                                            if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Delimiter"))
                                            {
                                                MSG = objTimeOut.Splitter_NPCI_IMPS_UPI_TimeOut_Delimiter_Dynamic(fileImportRequest);
                                            }
                                            else if (Convert.ToString(dt.Rows[0]["FileType"]).Contains("Excel"))
                                            {
                                                MSG = objTimeOut.Splitter_NPCI_IMPS_UPI_TimeOut_Excel_Dynamic(fileImportRequest);
                                            }

                                        }
                                        break;
                                        #endregion
                                }

                                //Check Upload Status
                                bool isPartial = fileImportRequest.FinalBatchDetails == null ? false : fileImportRequest.FinalBatchDetails.Contains("partial") ? true : false;

                                bool isatleastSucessful = fileImportRequest.FinalBatchDetails == null ? false : fileImportRequest.FinalBatchDetails.Contains("Successful") ? true : false;


                                if (isatleastSucessful)
                                {
                                    MSG = "Successful";
                                }
                                else
                                {
                                    fileImportRequest.InsertCount = 0;
                                }


                                if (MSG == "Successful" && fileImportRequest.InsertCount > 0)
                                {
                                    if (isPartial)
                                    {
                                        MSG = "Partial";
                                        FileUploadStatus = 3;
                                    }
                                    else
                                    {
                                        MSG = "Successful";
                                        FileUploadStatus = 1;
                                    }
                                }
                                else
                                {
                                    if (fileImportRequest.ErrorMessage == "The file is empty or contains no data.")
                                    {
                                        FileUploadStatus = 1;
                                    }
                                    else if (fileImportRequest.ErrorMessage.Length == 0 || fileImportRequest.InsertCount <= 0)
                                    {
                                        fileImportRequest.ErrorMessage = MSG;
                                        FileUploadStatus = 0;
                                    }
                                    else
                                    {
                                        FileUploadStatus = 2;
                                    }
                                }

                                importFileStatus.MSG = MSG;
                                if (fileImportRequest.TotalCount >= fileImportRequest.InsertCount)
                                {
                                    MSG = file.ImportFile.FileName + " <br/>" + MSG;
                                    MSG += "<br/>" + fileImportRequest.InsertCount + " out of " + fileImportRequest.TotalCount;
                                    MSG += "<br/>" + (fileImportRequest.TotalCount - fileImportRequest.InsertCount);
                                }
                                else
                                {
                                    MSG = file.ImportFile.FileName + " <br/>" + MSG;
                                    MSG += "<br/>" + fileImportRequest.InsertCount + " out of " + fileImportRequest.TotalCount;
                                    MSG += "<br/>" + (fileImportRequest.InsertCount - fileImportRequest.TotalCount);
                                }
                                importFileStatus.Status = importFileStatus.Status + MSG;


                                FileUploadStatusModel fileUploadStatusModel = new FileUploadStatusModel();
                                fileUploadStatusModel.ClientID = QClientID;
                                fileUploadStatusModel.ChannelID = QChannelID;
                                fileUploadStatusModel.ModeID = QModeID;
                                fileUploadStatusModel.CreatedBy = file.UserName;
                                fileUploadStatusModel.ErrorMessage = fileImportRequest.ErrorMessage;
                                fileUploadStatusModel.FileDate = FileDateTime;
                                fileUploadStatusModel.FileName = file.ImportFile.FileName;
                                fileUploadStatusModel.FilePath = path;
                                fileUploadStatusModel.FileFormatId = file.FileFormatId;
                                fileUploadStatusModel.FileType = tempFiletype;
                                fileUploadStatusModel.TotalRowCount = fileImportRequest.TotalCount;
                                fileUploadStatusModel.InsertCount = fileImportRequest.InsertCount;
                                fileUploadStatusModel.StartTime = StartTime;
                                fileUploadStatusModel.UploadStatus = FileUploadStatus;
                                fileUploadStatusModel.FinalBatchDetails = fileImportRequest.FinalBatchDetails;

                                objCommon.UpdateFileUploadStatus(fileUploadStatusModel, FileImportID);
                            }
                            else
                            {
                                importFileStatus.MSG = importFileStatus.MSG + "Error :: File Name" + file.ImportFile.FileName;
                                importFileStatus.Status = "" + file.ImportFile.FileName + "<br/>" + importFileStatus.Status + " Invalid file type. Allowed extensions are: " + allowedExtStr + ". <br/>0<br/>0";
                            }
                        }
                        else
                        {
                            importFileStatus.MSG = importFileStatus.MSG + "Error :: File Name" + file.ImportFile.FileName;
                            importFileStatus.Status = "" + file.ImportFile.FileName + "<br/>" + importFileStatus.Status + " Invalid file name. It must contain '" + FileNameContains + "'. <br/>0<br/>0";
                        }
                    }
                    else
                    {
                        importFileStatus.MSG = importFileStatus.MSG + "Error :: File Name" + file.ImportFile.FileName;
                        importFileStatus.Status = "" + file.ImportFile.FileName + "<br/>" + importFileStatus.Status + " File _configuration not found<br/>0<br/>0";
                    }

                    System.IO.File.Delete(path);
                }
            }
            catch (Exception ex)
            {
                importFileStatus.MSG = "Error";
                string s = file.ImportFile != null ? file.ImportFile.FileName : "No File";
                importFileStatus.Status = "" + s + "<br/>" + ex.Message + "<br/>0<br/>0";
            }
            return importFileStatus;
        }

        private static DateTime? GetFileDate(ImportFileModel file, string path, int QChannelID, int QModeID, string FileDateFormat, int? StartPosition, int? EndPosition)
        {
            DateTime? FileDateTime;
            string dateFile = string.Empty;

            if (FileDateFormat.Length > 0)
            {
                if (file.ImportFile.FileName.Contains("HDR") && QChannelID == 2 && QModeID == 3)
                {
                    try
                    {
                        using (StreamReader reader = new StreamReader(path))
                        {
                            string firstLine = reader.ReadLine();
                            string FileFormat = firstLine.Substring(3, 6).Trim();

                            if (firstLine.StartsWith("HDR"))
                            {
                                FileDateTime = DateTime.ParseExact(FileFormat.ToString(), FileDateFormat, System.Globalization.CultureInfo.InvariantCulture);
                                dateFile = FileFormat;
                            }
                        }
                    }
                    catch
                    {
                        FileDateTime = DateTime.Now.AddDays(-1);
                    }
                }
                else if (file.ImportFile.FileName.Contains("000ATM"))
                {
                    dateFile = new string(file.ImportFile.FileName.Replace("000ATM", "").Where(c => Char.IsDigit(c)).ToArray());
                    if (dateFile.Length >= FileDateFormat.Length)
                    {
                        dateFile = dateFile.Substring(0, FileDateFormat.Length);
                    }
                }
                else if (FileDateFormat == "dd-MMM-yyyy")
                {
                    string pattern = @"\d{2}-[A-Za-z]{3}-\d{4}";
                    MatchCollection matches = Regex.Matches(file.ImportFile.FileName, pattern);

                    if (matches.Count > 0)
                    {
                        dateFile = matches[0].Value;
                    }
                }
                else
                {
                    if (StartPosition.HasValue)
                    {
                        dateFile = new string(file.ImportFile.FileName);
                    }
                    else
                    {
                        dateFile = new string(file.ImportFile.FileName.Where(c => Char.IsDigit(c)).ToArray());
                    }
                    if (dateFile.Length >= FileDateFormat.Length)
                    {
                        dateFile = dateFile.Substring(StartPosition ?? 0, (EndPosition - StartPosition) ?? FileDateFormat.Length);
                    }
                }
                try
                {
                    if (dateFile.Length > 0)
                    {
                        FileDateTime = DateTime.ParseExact(dateFile, FileDateFormat, CultureInfo.InvariantCulture);
                    }
                    else
                    {
                        FileDateTime = DateTime.Now.AddDays(-1);
                    }
                }
                catch (Exception ex)
                {
                    FileDateTime = DateTime.Now.AddDays(-1);
                }

            }
            else
            {
                FileDateTime = DateTime.Now.AddDays(-1);
            }

            return FileDateTime;
        }

        private string ExtractNumber(string original)
        {
            return new string(original.Where(c => Char.IsDigit(c)).ToArray());
        }

        private void FileImportStatus(string path, string sFileName,string FileType,string FileFormatId, string UserName, DateTime FileDateTime, DataTable dt)
        {
             
            int QClientID = Convert.ToString(dt.Rows[0]["ClientID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ClientID"]);
            int QChannelID = Convert.ToString(dt.Rows[0]["ChannelID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ChannelID"]);
            int QModeID = Convert.ToString(dt.Rows[0]["ModeID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ModeID"]);

            

        }
    }
}