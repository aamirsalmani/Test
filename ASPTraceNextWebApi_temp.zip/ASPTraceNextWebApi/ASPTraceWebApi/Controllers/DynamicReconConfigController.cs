﻿using System;
using System.Collections.Generic;
using ASPTrace.Contracts;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Models;
using System.Data;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json.Linq;
using OfficeOpenXml;

namespace ASPTraceWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DynamicReconConfigController : ControllerBase
    {
        private readonly IDynamicReconConfig _objDynamicRecon;
        public DynamicReconConfigController(IDynamicReconConfig objDynamicRecon)
        {
            _objDynamicRecon = objDynamicRecon;
        }

        [HttpGet("[action]")]
        public object GetReconTables(int ChannelID, int ModeID)
        {
            return _objDynamicRecon.GetReconTables(ChannelID, ModeID);
        }
        [HttpGet("[action]")]
        public object GetNetworkList(string ClientId)
        {
            return _objDynamicRecon.GetNetworkList(ClientId);
        }

        [HttpGet("[action]")]
        public object GetPreset(int ClientID, int NetworkType, int ChannelID, int ModeID)
        {
            return _objDynamicRecon.GetPreset(ClientID, NetworkType, ChannelID, ModeID);
        }
        [HttpGet("[action]")]
        public object GetOthersPreset( int NetworkType, int ChannelID, int ModeID, int Type)
        {
            return _objDynamicRecon.GetOtherPreset( NetworkType, ChannelID, ModeID,Type);
        }
        [HttpGet("[action]")]
        public object GetTablesColumns(string TableName)
        {
            return _objDynamicRecon.GetTablesColumns(TableName);
        }
        [HttpGet("[action]")]
        public object GetOperations(string type = "0")
        {
            return _objDynamicRecon.GetOperations(type);
        }
        [HttpGet("[action]")]
        public string GetUnmatchedColumns(int ChannelID)
        {
            return _objDynamicRecon.GetUnmatchedColumns(ChannelID);
        }

        [HttpGet("[action]")]
        public string GetUnmatchedAllColumns(int ChannelID)
        {
            return _objDynamicRecon.GetUnmatchedAllColumns(ChannelID);
        }

        [HttpPost("[action]")]
        public string PostJoinTables([FromForm] JoinTablesWrapper joinTablesWrapper)
        {

            return _objDynamicRecon.PostJoinTables(joinTablesWrapper.Clientdetails, joinTablesWrapper.JoinTables);

        }
        [HttpGet("[action]")]
        public string GetReconAliasColumns(int ChannelID, int ModeID, int VendorType, int Type)
        {
            return _objDynamicRecon.GetReconAliasColumns(ChannelID, ModeID, VendorType, Type);
        }
        [HttpPost("[action]")]
        public string PostFormData([FromForm] FormValues FormValues)
        {
            try
            {
                //var Tabledata = JsonConvert.DeserializeObject<List<AliasReconColumnsModel>>(FormValues.FormData);

                return _objDynamicRecon.PostFormData(FormValues);
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        [HttpPost("[action]")]
        public string PostCaseTable([FromForm] CaseTableForm formData)
        {
            try
            {
                var Tabledata = JsonConvert.DeserializeObject<List<AliasReconColumnsModel>>(formData.ConfigData);//(AliasReconColumnsModel);


                var ClientParameters = formData;


                return _objDynamicRecon.PostCaseTable(ClientParameters, Tabledata);
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        [HttpGet("[action]")]
        public string GenerateReconQuery(int ClientID, int NetworkType, int ChannelID, int ModeID)
        {
            return _objDynamicRecon.GenerateReconQuery(ClientID, NetworkType, ChannelID, ModeID);
        }
        [HttpPost("[action]")]
        public object GenerateRecon(ReconQueryFields addReconQueryFields)
        {
            string jsonString = string.Empty;
            ReconQueryBlocks ReconQueryBlocks = new ReconQueryBlocks();

            DataTable dt = _objDynamicRecon.GenerateRecon(addReconQueryFields);

            int ReconTablesCount = addReconQueryFields.ReconType != "" ? Convert.ToInt16(addReconQueryFields.ReconType) : 0;

            List<ReconRawTableFields> table = new List<ReconRawTableFields>();

            List<List<ReconRawTableFields>> TablesList = new List<List<ReconRawTableFields>>();

            for (int k = 0; k < ReconTablesCount; k++)
            {
                string Data = dt.Rows[k]["Query"].ToString();
                string Reversal = dt.Rows[k]["Reversal"].ToString();
                string TableName = dt.Rows[k]["TableName"].ToString();
                string TableNo = dt.Rows[k]["TableNo"].ToString();
                string ReconTypeID = dt.Rows[k]["ReconTypeID"].ToString();

                object Fields = new
                {
                    ValTableName = TableName,
                    ValTableNo = TableNo,
                    ValReconTypeID = ReconTypeID,
                    ValData = Data
                };

                Data = ReconConfigGen.FormatSQLQueries(Data);

                if (Data != "")
                {
                    table = ReconConfigGen.ColumnsExtract(Fields);
                    TablesList.Add(table);
                }

                if (Data != "" && Reversal.ToLower() == "true")
                {
                    Data = ReconConfigGen.ReversalMergeBlock(Data);
                }
                else
                {
                    Data = ReconConfigGen.WrapperBlock(Data, TableName);
                }



                if (addReconQueryFields.ChannelName == null && addReconQueryFields.ModeName == null)
                {
                    string ChannelName = dt.Rows[k]["ChannelName"].ToString();
                    string ModeName = dt.Rows[k]["ModeName"].ToString();

                    addReconQueryFields.ChannelName = ChannelName;
                    addReconQueryFields.ModeName = ModeName;
                }

                if (k == 0)
                {
                    ReconQueryBlocks.RawTable1 = Data;
                    ReconQueryBlocks.Reversal1 = Reversal;
                }
                if (k == 1)
                {
                    ReconQueryBlocks.RawTable2 = Data;
                    ReconQueryBlocks.Reversal2 = Reversal;
                }
                if (k == 2)
                {
                    ReconQueryBlocks.RawTable3 = Data;
                    ReconQueryBlocks.Reversal3 = Reversal;
                }
                if (k == 3)
                {
                    ReconQueryBlocks.RawTable4 = Data;
                    ReconQueryBlocks.Reversal4 = Reversal;
                }
                if (k == 4)
                {
                    ReconQueryBlocks.RawTable5 = Data;
                    ReconQueryBlocks.Reversal5 = Reversal;
                }


            }

            string Query = ReconConfigGen.ReconQueryConstructorKS(addReconQueryFields, ReconQueryBlocks, TablesList);
            JObject myObject = new JObject();
            myObject.Add("QueryString", Query);

            // convert the JObject to a JSON string
            jsonString = JsonConvert.SerializeObject(myObject);

            return jsonString;

        }
    }
}