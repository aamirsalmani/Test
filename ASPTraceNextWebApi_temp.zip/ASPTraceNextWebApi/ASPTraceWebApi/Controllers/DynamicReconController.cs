﻿using System;
using System.Collections.Generic;
using ASPTrace.Contracts;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Models;
using System.Data;
using Microsoft.Extensions.Configuration;

namespace ASPTraceWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DynamicReconController : ControllerBase
    {
        private readonly IDynamicRecon _objDynamicRecon;
        public DynamicReconController(IDynamicRecon objDynamicRecon)
        {
            _objDynamicRecon = objDynamicRecon;
        }

        [HttpGet("[action]")]
        public object GetDynamicReconList(string ClientID)
        {
            return _objDynamicRecon.GetDynamicRecon(ClientID);
        }
        
        [HttpGet("[action]")]
        public object GetModeDynamicReconList(string ClientID, int ChannelID)
        {
            return _objDynamicRecon.GetModeDynamicRecon(ClientID, ChannelID);
        }

        [HttpGet("[action]")]
        public object GetRunReconHistoryDynamicReconList(string ClientID)
        {
            return _objDynamicRecon.GetRunReconHistoryDynamicRecon(ClientID);
        }

        [HttpPost("[action]")]
        public object GetRunReconAddDynamicReconList(ReconStatusDynamicReconModel reconStatusDynamicReconModel)
        {
            return _objDynamicRecon.GetRunReconAddDynamicRecon(reconStatusDynamicReconModel);
        }

    }
}