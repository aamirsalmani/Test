﻿using System;
using System.Collections.Generic;
using ASPTrace.Contracts;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;
using System.Data; 
using System.Linq;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class DynamicReportController : Controller
    {
        private readonly IDynamicReport _objDynamicReport;

        public DynamicReportController(IDynamicReport objDynamicReport)
        {
            _objDynamicReport = objDynamicReport;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetReportTypeList()
        {
            return _objDynamicReport.GetReportTypeList();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetDynamicReportColumnList(string ReportID)
        {
            return _objDynamicReport.GetDynamicReportColumns(ReportID);
        }
    }
}
