﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;

namespace TraceReact.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EjErrorConfigController: ControllerBase
    {
        private readonly IEjErrorConfig _objEjErrorConfig;

        public EjErrorConfigController(IEjErrorConfig objEjErrorConfig)
        {
            _objEjErrorConfig = objEjErrorConfig;
        }


        [Route("[action]")]
        [HttpGet]
        public object GetEjErrorList()
        {
            return _objEjErrorConfig.GetEjErrorListGrid();
        }

        [Route("[action]")]
        [HttpPost]
        public object EJErroraddupdate(EjErrorConfigModelssOperations ejErrorConfigModelsOps)
        {
            return _objEjErrorConfig.EjErroraddupdate(ejErrorConfigModelsOps);
        }

        //[Route("[action]")]
        //[HttpGet]
        //public object GetCurrencyDetails(string CurrencyID)
        //{
        //    return _objCurrencyReg.GetCurrencyDetails(CurrencyID);
        //}

        //[Route("[action]")]
        //[HttpGet]
        //public object GetCountryRegList()
        //{
        //    return _objCurrencyReg.GetCountryReg();
        //}

        //[Route("[action]")]
        //[HttpPost]
        //public object DeleteEjError(EjErrorConfigModelss ejErrorConfigModels)
        //{
        //    return _objEjErrorConfig.DeleteEjErrorConfig(ejErrorConfigModels);
        //}
    }
}
