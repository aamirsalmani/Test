﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml.Style;
using OfficeOpenXml;
using System.Data;
using ASPTrace.Models;
using ASPTrace.Contracts;
using Utility;
using System.Text;
using Ionic.Zip;  
using System.IO;
using DocumentFormat.OpenXml.Spreadsheet;
using ASPTraceWebApi.ClassFiles;
using DocumentFormat.OpenXml.Wordprocessing;
using static MassTransit.ValidationResultExtensions;

namespace ASPTraceWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExcelController : ControllerBase
    {
        private readonly IExport _objExport;
        private IConfiguration _configuration;
        private readonly ICommon _objCommon; 
        private readonly IDownloadService _downloadService;
        private readonly INotificationDispatcher _dispatcher;


        public ExcelController(IExport objExport, IConfiguration Configuration, ICommon Common, INotificationDispatcher dispatcher, IDownloadService downloadService)
        {
            _objExport = objExport;
            _configuration = Configuration;
            _objCommon = Common;
            _dispatcher = dispatcher;
            _downloadService = downloadService;
        }
        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportExcelReconTxns(InputReportModel reportModel, string? searchText)
        {

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 18,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for {reportModel.ClientName} {reportModel.ReportType} of {reportModel.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };

            await PushNotification(NotificationEventData);

            try
            {
                string folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", reportModel.UserID);

                string FileName = reportModel.ClientName+"_" + reportModel.ReportType+"TxnsReport_" + reportModel.ChannelName + "_" + reportModel.ModeName + "_" + reportModel.FromDate.ToString() + ".xlsx";  
                
                string fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = reportModel.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable dtReport = null;

                if (reportModel.ReportType == "Unmatched")
                {
                    dtReport = _objExport.GetUnmatchedTxnsDataTable(reportModel, searchText);
                }
                else if (reportModel.ReportType == "Matched")
                {
                    dtReport = _objExport.GetMatchedTxnsDataTable(reportModel, searchText);
                }
                else if (reportModel.ReportType == "Unsuccessful")
                {
                    dtReport = _objExport.GetUnsuccessfulTxnsDataTable(reportModel, searchText);
                }
                else if (reportModel.ReportType == "Reversal")
                {
                    dtReport = _objExport.GetReversalTxnsDataTable(reportModel);
                }
                else if (reportModel.ReportType == "Duplicate")
                {
                    dtReport = _objExport.GetDuplicateTxnsDataTable(reportModel);
                } 

                byte[] fileContents = Common.ExportExcel(dtReport); 

                if (fileContents != null)
                {
                    Filedetails.FileSize = Common.ConvertFileSize(fileContents.LongLength);
                    Filedetails.DownloadStatus = 1;
                    await System.IO.File.WriteAllBytesAsync(fullPath, fileContents);
                }

                var ID = await BulkInsertDownloads(Filedetails, InsertID);

                NotificationEvent NotificationEventData1 = new NotificationEvent
                {
                    MenuID = 18,
                    NotificationTypeID = "2",
                    NotificationType = "Download Status",
                    Message = $"Download Completed for {reportModel.ClientName} UnmatchTxnsReport of {reportModel.FromDate}",
                    QueryData = "",
                    IsSent = false,
                    ButtonText = "",
                    HasButton = false
                };

                await PushNotification(NotificationEventData1);

                var objFile = File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"Excel.xlsx");

                return objFile;
            }
            catch (Exception ex)
            {

                NotificationEvent NotificationEventData2 = new NotificationEvent
                {
                    MenuID = 18,
                    NotificationTypeID = "2",
                    NotificationType = "Download Status",
                    Message = $"Download Failed for {reportModel.ClientName} UnmatchTxnsReport of {reportModel.FromDate}",
                    QueryData = "",
                    IsSent = false,
                    ButtonText = "",
                    HasButton = false
                };

                await PushNotification(NotificationEventData2);

                return NotFound("File Download Failed");
            }
        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportCsvReconTxns(InputReportModel Details, string? searchText)
        {
            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 18,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for {Details.ClientName} {Details.ReportType} of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };
            bool Status = await PushNotification(NotificationEventData);

            var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            string FileName = Details.ClientName + "_" + Details.TxnType + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".csv";
            string zipFileName = FileName.Replace(".csv", ".zip");
            var fullPath = Path.Combine(folderPath, zipFileName);

            var Filedetails = new DownloadsModel
            {
                FileName = zipFileName,
                FilePath = fullPath,
                FileSize = "0KB",
                DownloadDate = DateTime.Now,
                UserID = Details.UserID,
                DownloadStatus = 0,
                FileType = Path.GetExtension(zipFileName),
                IPAddress = ""
            };

            var InsertID = await BulkInsertDownloads(Filedetails, null);

            DataTable dtReport = null;
            if (Details.ReportType == "Unmatched")
                dtReport = _objExport.GetUnmatchedTxnsDataTable(Details, searchText);
            else if (Details.ReportType == "Matched")
                dtReport = _objExport.GetMatchedTxnsDataTable(Details, searchText);
            else if (Details.ReportType == "Unsuccessful")
                dtReport = _objExport.GetUnsuccessfulTxnsDataTable(Details, searchText);
            else if (Details.ReportType == "Reversal")
                dtReport = _objExport.GetReversalTxnsDataTable(Details);
            else if (Details.ReportType == "Duplicate")
                dtReport = _objExport.GetDuplicateTxnsDataTable(Details);

            try
            {
                // 1. Generate CSV
                var csv = Common.GenerateCsv(dtReport);
                var csvBytes = Encoding.UTF8.GetBytes(csv);

                // 2. Create password protected ZIP
                var zipBytes = Common.CreatePasswordProtectedZip(FileName, csvBytes, _configuration["ExportKeys:Password"]);

                // 3. Save to disk
                if (zipBytes.LongLength > 0)
                {
                    Filedetails.FileSize = Common.ConvertFileSize(zipBytes.LongLength);
                    Filedetails.DownloadStatus = 1;
                    await System.IO.File.WriteAllBytesAsync(fullPath, zipBytes);
                }
                await BulkInsertDownloads(Filedetails, InsertID);

                // 4. Push success notification
                NotificationEvent NotificationEventData2 = new NotificationEvent
                {
                    MenuID = 18,
                    NotificationTypeID = "2",
                    NotificationType = "Download Status",
                    Message = $"Download Completed for {Details.ClientName} {Details.ReportType} of {Details.FromDate}",
                    QueryData = "",
                    IsSent = false,
                    ButtonText = "",
                    HasButton = false
                };
                await PushNotification(NotificationEventData2);

                // ✅ Return file directly
                return File(zipBytes, "application/zip", zipFileName);
            }
            catch (Exception ex)
            {
                NotificationEvent NotificationEventData3 = new NotificationEvent
                {
                    MenuID = 18,
                    NotificationTypeID = "2",
                    NotificationType = "Download Status",
                    Message = $"Download Failed for {Details.ClientName} {Details.ReportType} of {Details.FromDate}",
                    QueryData = "",
                    IsSent = false,
                    ButtonText = "",
                    HasButton = false
                };

                await PushNotification(NotificationEventData3);
                return NotFound("File Download Failed");
            }
        }

        private async Task<int?> BulkInsertDownloads(DownloadsModel Filedetails, int? InsertID)
        {
            DataTable downloadsData = new DataTable();
            downloadsData.Columns.Add("FileName", typeof(string));
            downloadsData.Columns.Add("FilePath", typeof(string));
            downloadsData.Columns.Add("FileSize", typeof(string));
            downloadsData.Columns.Add("DownloadDate", typeof(DateTime));
            downloadsData.Columns.Add("UserID", typeof(string)); // Match the UserID type as VARCHAR(100)
            downloadsData.Columns.Add("DownloadStatus", typeof(int));
            downloadsData.Columns.Add("FileType", typeof(string));
            downloadsData.Columns.Add("IPAddress", typeof(string));


            // Add rows to the DataTable (this data can come from any source, e.g., API request)
            downloadsData.Rows.Add(Filedetails.FileName, Filedetails.FilePath, Filedetails.FileSize, Filedetails.DownloadDate, Filedetails.UserID, Filedetails.DownloadStatus, Filedetails.FileType, Filedetails.IPAddress);

            // Call the repository method to perform bulk insert
            int? ID = await _downloadService.BulkInsertDownloadsAsync(downloadsData, InsertID);

            downloadsData.Clear();

            return ID;
        }

        private async Task<IActionResult> ExportExcel(DataTable dtTxns, int DateColumnIndex)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                if (DateColumnIndex > 0)
                {
                    // Write a DateTime
                    worksheet.Cells[1, DateColumnIndex].Value = DateTime.Now.ToShortDateString();
                    // Apply Excel built-in short date format
                    worksheet.Column(DateColumnIndex).Style.Numberformat.Format = "dd-MM-yyyy";   // explicit short date  OR (better, auto regional short date)
                } 

                // Load the DataTable into the worksheet, starting from cell A1  //typeof(UnmatchedTxnsReportModel).GetProperties().Length
                worksheet.Cells["A1"].LoadFromDataTable(dtTxns, PrintHeaders: true);

                // Auto-fit the column widths
                // worksheet.Cells.AutoFitColumns();        

                using (var range = worksheet.Cells[1, 1, 1, dtTxns.Columns.Count])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightBlue);
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                // Format all cells with borders  //typeof(UnmatchedTxnsReportModel).GetProperties().Length]
                using (var range = worksheet.Cells[1, 1, dtTxns.Rows.Count + 1, dtTxns.Columns.Count])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                //Apply password protection
                package.Encryption.Password = _configuration["ExportKeys:Password"];  // <-- you can make this dynamic (e.g. UserID, ClientID)
                package.Encryption.Algorithm = OfficeOpenXml.EncryptionAlgorithm.AES256;

                // Convert the package to a byte array
                byte[] fileContents = package.GetAsByteArray();

                // Return the Excel file as a download
                return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"Excel.xlsx");
            }
        }

        


        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportExcelUnmatchedTxnsKS(InputReportModel Details, string? searchText)
        {


            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }
            //DataTable NotificationsData = new DataTable();
            //NotificationsData.Columns.Add("MenuID", typeof(int));
            //NotificationsData.Columns.Add("NotificationType", typeof(int));
            //NotificationsData.Columns.Add("Message", typeof(string));
            //NotificationsData.Columns.Add("QueryData", typeof(string));
            //NotificationsData.Columns.Add("IsSent", typeof(bool));
            //NotificationsData.Columns.Add("ButtonText", typeof(string));
            //NotificationsData.Columns.Add("HasButton", typeof(int));
            //NotificationsData.Columns.Add("CreatedBy", typeof(string));

            //NotificationsData.Rows.Add(18, 2, $"Download Started for UnmatchTxnsReport of {unmatchedTxnsModel.FromDate}", "", false, null, false, "System");

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 18,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for {Details.TxnType} of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };

            bool Status = await PushNotification(NotificationEventData);

            return await Task.Run(async () =>
            {               

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "UnmatchedTxnsReport_" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".xlsx";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable unmatchedTxnsReportList = _objExport.GetUnmatchedTxnsDataTable(Details, searchText);
                try
                {

                    var File = await ExportExcel(unmatchedTxnsReportList, 0);
                    if (File is FileContentResult fileContentResult)
                    {
                        Filedetails.FileSize = Common.ConvertFileSize(fileContentResult.FileContents.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, fileContentResult.FileContents);

                    }


                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 18,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for UnmatchTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return File;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 18,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for UnmatchTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });




        }


        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportExcelMatchedTxns(InputReportModel Details, string? SearchText)
        {

            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 19,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for MatchedTxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };
            bool Status = await PushNotification(NotificationEventData);

            return await Task.Run(async () =>
            {
                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "MatchedTxnsReport_" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".xlsx";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable matchedTxnsReportList = _objExport.GetMatchedTxnsDataTable(Details, SearchText);
                try
                {

                    var File = await ExportExcel(matchedTxnsReportList, 0);
                    if (File is FileContentResult fileContentResult)
                    {
                        Filedetails.FileSize = Common.ConvertFileSize(fileContentResult.FileContents.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, fileContentResult.FileContents);

                    }


                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 19,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for MatchedTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);


                    return File;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 19,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for MatchedTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });
        }


        //[Route("[action]")]
        //[HttpPost]
        //public object ExportExcelMatchedTxns(InputReportModel unmatchedTxnsModel)
        //{

        //    DataTable unmatchedTxnsReportList = _objExport.GetMatchedTxnsDataTable(unmatchedTxnsModel);

        //    

        //    
        //    return ExportExcel(unmatchedTxnsReportList);

        //}

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportExcelReversalTxns(InputReportModel Details)
        {

            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 24,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for ReversalTxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };
            bool Status = await PushNotification(NotificationEventData);

            return await Task.Run(async () =>
            {
                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "ReversalTxnsReport" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".xlsx";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable matchedTxnsReportList = _objExport.GetReversalTxnsDataTable(Details);
                try
                {

                    var File = await ExportExcel(matchedTxnsReportList, 0);
                    if (File is FileContentResult fileContentResult)
                    {
                        Filedetails.FileSize = Common.ConvertFileSize(fileContentResult.FileContents.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, fileContentResult.FileContents);

                    }


                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 24,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for ReversalTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);


                    return File;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 24,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for ReversalTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });

        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportExcelUnsuccessfulTxns(InputReportModel Details, string? SearchText)
        {

            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }

            //DataTable unmatchedTxnsReportList = _objExport.GetUnsuccessfulTxnsDataTable(unmatchedTxnsModel);
            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 69,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for UnsuccessfulTxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };
            bool Status = await PushNotification(NotificationEventData);

            return await Task.Run(async () =>
            {
                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "UnsuccessfulTxnsReport" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".xlsx";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable unsuccessfulTxnsReportList = _objExport.GetUnsuccessfulTxnsDataTable(Details, SearchText);
                try
                {

                    var File = await ExportExcel(unsuccessfulTxnsReportList, 0);
                    if (File is FileContentResult fileContentResult)
                    {
                        Filedetails.FileSize = Common.ConvertFileSize(fileContentResult.FileContents.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, fileContentResult.FileContents);

                    }


                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 69,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for UnsuccessfulTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);


                    return File;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 69,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for UnsuccessfulTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });

        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportExcelDuplicateTxns(InputReportModel Details)
        {

            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }
            //DataTable unmatchedTxnsReportList = _objExport.GetDuplicateTxnsDataTable(unmatchedTxnsModel);

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 65,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for DuplicateTxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };
            bool Status = await PushNotification(NotificationEventData);

            return await Task.Run(async () =>
            {
                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "DuplicateTxnsReport" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".xlsx";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable unsuccessfulTxnsReportList = _objExport.GetDuplicateTxnsDataTable(Details);
                try
                {

                    var File = await ExportExcel(unsuccessfulTxnsReportList, 0);
                    if (File is FileContentResult fileContentResult)
                    {
                        Filedetails.FileSize = Common.ConvertFileSize(fileContentResult.FileContents.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, fileContentResult.FileContents);

                    }


                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 65,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for DuplicateTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);


                    return File;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 65,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for DuplicateTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });

        }


        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportCsvUnmatchedTxnsKS(InputReportModel Details, string? searchText)
        {
            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 18,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for {Details.ClientName} UnmatchTxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };

            bool Status = await PushNotification(NotificationEventData);



            return await Task.Run(async () =>
            {


                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = Details.ClientName+"_"+"UnmatchedTxnsReport_" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".csv";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable unmatchedTxnsReportList = _objExport.GetUnmatchedTxnsDataTable(Details, searchText);
                try
                {

                    var csv = Common.GenerateCsv(unmatchedTxnsReportList);

                    var bytes = Encoding.UTF8.GetBytes(csv);

                    if (bytes.LongLength > 0)
                    {

                        Filedetails.FileSize = Common.ConvertFileSize(bytes.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, bytes);
                    }




                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 18,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for {Details.ClientName} UnmatchTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);
                    IActionResult Data = File(bytes, "text/csv", FileName);

                    return Data;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 18,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for {Details.ClientName} UnmatchTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });




        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportCsvMatchedTxns(InputReportModel Details, string? SearchText)
        {
            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }
            //DataTable unmatchedTxnsReportList = _objExport.GetMatchedTxnsDataTable(unmatchedTxnsModel);

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 19,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for MatchedTxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };

            bool Status = await PushNotification(NotificationEventData);



            return await Task.Run(async () =>
            {


                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "MatchedTxnsReport" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".csv";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable matchedTxnsReportList = _objExport.GetMatchedTxnsDataTable(Details, SearchText);
                try
                {

                    var csv = Common.GenerateCsv(matchedTxnsReportList);

                    var bytes = Encoding.UTF8.GetBytes(csv);

                    if (bytes.LongLength > 0)
                    {

                        Filedetails.FileSize = Common.ConvertFileSize(bytes.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, bytes);
                    }




                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 19,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for MatchedTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);
                    IActionResult Data = File(bytes, "text/csv", FileName);

                    return Data;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 19,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for MatchedTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });


        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportCsvReversalTxns(InputReportModel Details)
        {
            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }
            // DataTable unmatchedTxnsReportList = _objExport.GetReversalTxnsDataTable(unmatchedTxnsModel);

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 24,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for ReversalTxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };

            bool Status = await PushNotification(NotificationEventData);



            return await Task.Run(async () =>
            {


                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "ReversalTxnsReport" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".csv";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable matchedTxnsReportList = _objExport.GetReversalTxnsDataTable(Details);
                try
                {

                    var csv = Common.GenerateCsv(matchedTxnsReportList);

                    var bytes = Encoding.UTF8.GetBytes(csv);

                    if (bytes.LongLength > 0)
                    {

                        Filedetails.FileSize = Common.ConvertFileSize(bytes.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, bytes);
                    }




                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 24,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for ReversalTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);
                    IActionResult Data = File(bytes, "text/csv", FileName);

                    return Data;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 24,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for ReversalTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });


        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportCsvUnsuccessfulTxns(InputReportModel Details, string? SearchText)
        {
            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }
            //DataTable unmatchedTxnsReportList = _objExport.GetUnsuccessfulTxnsDataTable(unmatchedTxnsModel);
            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 69,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for UnsuccessfulTxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };

            bool Status = await PushNotification(NotificationEventData);



            return await Task.Run(async () =>
            {


                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "UnsuccessfulTxnsReport" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".csv";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable matchedTxnsReportList = _objExport.GetUnsuccessfulTxnsDataTable(Details, SearchText);
                try
                {

                    var csv = Common.GenerateCsv(matchedTxnsReportList);

                    var bytes = Encoding.UTF8.GetBytes(csv);

                    if (bytes.LongLength > 0)
                    {

                        Filedetails.FileSize = Common.ConvertFileSize(bytes.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, bytes);
                    }




                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 69,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for UnsuccessfulTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);
                    IActionResult Data = File(bytes, "text/csv", FileName);

                    return Data;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 69,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for UnsuccessfulTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });


        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportCsvDuplicateTxns(InputReportModel Details)
        {
            if (Details.ModeName == "ACQUIRER/ONUS")
            {
                Details.ModeName = "ACQUIRER_ONUS";
            }
            // DataTable unmatchedTxnsReportList = _objExport.GetDuplicateTxnsDataTable(unmatchedTxnsModel);

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 65,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for DuplicateTxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };

            bool Status = await PushNotification(NotificationEventData);



            return await Task.Run(async () =>
            {


                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "DuplicateTxnsReport" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".csv";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable duplicateTxnsReportList = _objExport.GetDuplicateTxnsDataTable(Details);
                try
                {

                    var csv = Common.GenerateCsv(duplicateTxnsReportList);

                    var bytes = Encoding.UTF8.GetBytes(csv);

                    if (bytes.LongLength > 0)
                    {

                        Filedetails.FileSize = Common.ConvertFileSize(bytes.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, bytes);
                    }




                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 65,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for DuplicateTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);
                    IActionResult Data = File(bytes, "text/csv", FileName);

                    return Data;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 65,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for DuplicateTxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });


        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportExcelAdjustment(AdjustmentTxnsModel Details)
        {

            return await Task.Run(async () =>
            {

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserName);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                string FileName = Details.ChannelName + " Report_" + Details.TR_POSTDATE.ToString() + ".xlsx";

                var fullPath = Path.Combine(folderPath, FileName);


                DataTable unmatchedTxnsReportList = _objExport.GetAdjustmentDataTable(Details);
                try
                {

                    var File = await ExportExcel(unmatchedTxnsReportList, 0);
                    if (File is FileContentResult fileContentResult)
                    {
                        await System.IO.File.WriteAllBytesAsync(fullPath, fileContentResult.FileContents);

                    }

                    return File;
                }
                catch (Exception ex)
                {
                    return NotFound("File Download Failed");
                }
            });




        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportCsvAdjustment(AdjustmentTxnsModel Details)
        {

            return await Task.Run(async () =>
            {

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserName);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                string FileName = Details.ChannelName + " Report_" + Details.TR_POSTDATE.ToString() + ".csv";

                var fullPath = Path.Combine(folderPath, FileName);

                DataTable unmatchedTxnsReportList = _objExport.GetAdjustmentDataTable(Details);
                try
                {
                    var csv = Common.GenerateCsv(unmatchedTxnsReportList);

                    var bytes = Encoding.UTF8.GetBytes(csv);

                    IActionResult Data = File(bytes, "text/csv", FileName);

                    return Data;
                }
                catch (Exception ex)
                {
                    return NotFound("File Download Failed");
                }
            });




        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportCsvDMSTxns(InputReportModel Details)
        {

            // DataTable unmatchedTxnsReportList = _objExport.GetDuplicateTxnsDataTable(unmatchedTxnsModel);

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 124,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for POS DMS TxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };

            bool Status = await PushNotification(NotificationEventData);



            return await Task.Run(async () =>
            {


                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "POSDMSTxnsReport" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".csv";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable dmsTxnsReportList = _objExport.GetDmsTxnsDataTable(Details);
                try
                {

                    var csv = Common.GenerateCsv(dmsTxnsReportList);

                    var bytes = Encoding.UTF8.GetBytes(csv);

                    if (bytes.LongLength > 0)
                    {

                        Filedetails.FileSize = Common.ConvertFileSize(bytes.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, bytes);
                    }




                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 124,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for  POS DMS TxnsReport  of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);
                    IActionResult Data = File(bytes, "text/csv", FileName);

                    return Data;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 124,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for  POS DMS TxnsReport  of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });


        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportExcelDMSTxns(InputReportModel Details)
        {

            //DataTable unmatchedTxnsReportList = _objExport.GetDuplicateTxnsDataTable(unmatchedTxnsModel);

            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 124,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for POS DMS TxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };
            bool Status = await PushNotification(NotificationEventData);

            return await Task.Run(async () =>
            {
                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "POSDMSTxnsReport" + Details.ChannelName + "_" + Details.ModeName + "_" + Details.FromDate.ToString() + ".xlsx";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                var InsertID = await BulkInsertDownloads(Filedetails, null);

                DataTable dmsTxnsReportList = _objExport.GetDmsTxnsDataTable(Details);
                try
                {

                    var File = await ExportExcel(dmsTxnsReportList, 0);
                    if (File is FileContentResult fileContentResult)
                    {
                        Filedetails.FileSize = Common.ConvertFileSize(fileContentResult.FileContents.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, fileContentResult.FileContents);

                    }


                    var ID = await BulkInsertDownloads(Filedetails,  InsertID);

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 124,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Completed for POS DMS TxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);


                    return File;
                }
                catch (Exception ex)
                {

                    NotificationEvent NotificationEventData = new NotificationEvent
                    {
                        MenuID = 124,
                        NotificationTypeID = "2",
                        NotificationType = "Download Status",
                        Message = $"Download Failed for POS DMS TxnsReport of {Details.FromDate}",
                        QueryData = "",
                        IsSent = false,
                        ButtonText = "",
                        HasButton = false
                    };

                    bool Status = await PushNotification(NotificationEventData);

                    return NotFound("File Download Failed");
                }
            });

        }


        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> SettlementTxnsReport(InputSettlementReportModel Details)
        {
            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 19,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for SettlementTxnsReport of {Details.FromDate}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };
            bool Status = await PushNotification(NotificationEventData);

            return await Task.Run(async () =>
            {
                

                

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "SettlementTxnsReport_" + Details.ReportName + "_" + Details.FromDate.ToString() + ".xlsx";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                //var InsertID = await BulkInsertDownloads(Filedetails, null);


                DataTable settlementTxnsReportList = _objExport.GetSettlementTxnsDataTable(Details);
                try
                {

                    var File = await ExportExcel(settlementTxnsReportList, 1);
                    if (File is FileContentResult fileContentResult)
                    {
                        Filedetails.FileSize = Common.ConvertFileSize(fileContentResult.FileContents.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, fileContentResult.FileContents);

                    }

                    return File;
                }
                catch (Exception ex)
                {
                    return NotFound("File Download Failed");
                }
            });
        }


        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> SwitchingFeeTxnsReport(SwitchFeeReportModel Details)
        {
            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 19,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for ConsoleSetTxnReport of {Details.FromDateTxns}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };
            bool Status = await PushNotification(NotificationEventData);

            return await Task.Run(async () =>
            {




                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "Switching_Fee_Txn_Report" + "_" + Details.FromDateTxns.ToString() + ".xlsx";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                //var InsertID = await BulkInsertDownloads(Filedetails, null);


                DataTable settlementTxnsReportList = _objExport.GetSwitchFeeTxnsDataTable(Details);
                try
                {

                    var File = await ExportExcel(settlementTxnsReportList, 1);
                    if (File is FileContentResult fileContentResult)
                    {
                        Filedetails.FileSize = Common.ConvertFileSize(fileContentResult.FileContents.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, fileContentResult.FileContents);

                    }

                    return File;
                }
                catch (Exception ex)
                {
                    return NotFound("File Download Failed");
                }
            });
        }
        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ConsoleSetTxnsReport(ConsoleSetReportModel Details)
        {
            NotificationEvent NotificationEventData = new NotificationEvent
            {
                MenuID = 19,
                NotificationTypeID = "2",
                NotificationType = "Download Status",
                Message = $"Download Started for Approval_Fee_GST_Report of {Details.FromDateTxns}",
                QueryData = "",
                IsSent = false,
                ButtonText = "",
                HasButton = false
            };
            bool Status = await PushNotification(NotificationEventData);

            return await Task.Run(async () =>
            {




                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", Details.UserID);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                string FileName = "Approval_Fee_GST_Report" + "_" + Details.FromDateTxns.ToString() + ".xlsx";
                var fullPath = Path.Combine(folderPath, FileName);

                var Filedetails = new DownloadsModel
                {
                    FileName = FileName,
                    FilePath = fullPath,
                    FileSize = "0KB",
                    DownloadDate = DateTime.Now,
                    UserID = Details.UserID,
                    DownloadStatus = 0,
                    FileType = Path.GetExtension(FileName),
                    IPAddress = ""
                };

                //var InsertID = await BulkInsertDownloads(Filedetails, null);


                DataTable settlementTxnsReportList = _objExport.GetConsoleSetTxnsDataTable(Details);
                try
                {

                    var File = await ExportExcel(settlementTxnsReportList, 1);
                    if (File is FileContentResult fileContentResult)
                    {
                        Filedetails.FileSize = Common.ConvertFileSize(fileContentResult.FileContents.LongLength);
                        Filedetails.DownloadStatus = 1;
                        await System.IO.File.WriteAllBytesAsync(fullPath, fileContentResult.FileContents);

                    }

                    return File;
                }
                catch (Exception ex)
                {
                    return NotFound("File Download Failed");
                }
            });
        }

        

        private async Task<bool> PushNotification(NotificationEvent notificationEvent)
        {
            try
            {
                await _dispatcher.HandleNotification(notificationEvent);

                await Task.Run(async () =>
                {
                    System.Data.DataTable NotificationsData = new System.Data.DataTable();
                    NotificationsData.Columns.Add("MenuID", typeof(int));
                    NotificationsData.Columns.Add("NotificationType", typeof(int));
                    NotificationsData.Columns.Add("Message", typeof(string));
                    NotificationsData.Columns.Add("QueryData", typeof(string));
                    NotificationsData.Columns.Add("IsSent", typeof(bool));
                    NotificationsData.Columns.Add("ButtonText", typeof(string));
                    NotificationsData.Columns.Add("HasButton", typeof(int));
                    NotificationsData.Columns.Add("CreatedBy", typeof(string));

                    NotificationsData.Rows.Add(notificationEvent.MenuID, notificationEvent.NotificationTypeID, notificationEvent.Message, notificationEvent.QueryData, notificationEvent.IsSent, notificationEvent.ButtonText, notificationEvent.HasButton, "System");

                    string Status = await _objCommon.PushNotification(NotificationsData);

                    return Status;
                });

                return true; // Success
            }
            catch (Exception ex)
            {

                return false; // Failure
            }
        }
    }
}
