﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models; 
using System.Data; 
using OfficeOpenXml.Style;
using OfficeOpenXml;
using System.Text; 
using Utility;
using System.Drawing;

namespace ASPTraceWebApi.Controllers 
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ExceptionReportController : Controller
    {
        private readonly IExceptionsReport _objExceptionReport;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;

        public ExceptionReportController(IExceptionsReport objExceptionReport, IConfiguration Configuration, ASPTrace.Contracts.ICommon Common)
        {
            _objExceptionReport = objExceptionReport;
            _configuration = Configuration;
            _objCommon = Common;
        }

       

        [Route("[action]")]
        [HttpPost]
        public object GetEJMissingDatalist(EJMissingReportModel eJMissingModel)
        {
            return _objExceptionReport.GetEJMissingData(eJMissingModel);
        }

        //------------------------ BY KUNDAN --------------------------------

        [Route("[action]")]
        [HttpPost]
        public object ExportExcelReportKS(RawDataInputModel rawDataInput)
        {

            DataTable Report = _objExceptionReport.ExportExcelReportKS(rawDataInput); 

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                // Debugging point
                Console.WriteLine($"Number of columns in Report DataTable: {Report.Columns.Count}");

                // Load the DataTable into the worksheet, starting from cell A1  //typeof(UnmatchedTxnsReportModel).GetProperties().Length
                worksheet.Cells["A1"].LoadFromDataTable(Report, PrintHeaders: true);

                using (var range = worksheet.Cells[1, 1, 1, Report.Columns.Count])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(Color.LightBlue);
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                // Format all cells with borders  //typeof(UnmatchedTxnsReportModel).GetProperties().Length]
                using (var range = worksheet.Cells[1, 1, Report.Rows.Count + 1, Report.Columns.Count])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }


                // Convert the package to a byte array
                byte[] fileContents = package.GetAsByteArray();

                // Return the Excel file as a download
                return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"UnmatchedTxnsReport_{rawDataInput.FROMDATE}.xlsx");
            }

        }
        [Route("[action]")]
        [HttpPost]

        public object ExportCsvReportKS(RawDataInputModel rawDataInput)
        {

            DataTable Reporttbl = _objExceptionReport.ExportCsvReportKS(rawDataInput); 
            var csv = GenerateCsv(Reporttbl);

            var bytes = Encoding.UTF8.GetBytes(csv);
            return File(bytes, "text/csv", $"UnmatchedTxnsReport_{rawDataInput.FROMDATE}.csv");


        }

        private string GenerateCsv(DataTable table)
        {
            var sb = new StringBuilder();

            // Add the column headers
            IEnumerable<string> columnNames = table.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
            sb.AppendLine(string.Join(",", columnNames));

            // Add the rows
            foreach (DataRow row in table.Rows)
            {
                IEnumerable<string> fields = row.ItemArray.Select(field => field.ToString());
                sb.AppendLine(string.Join(",", fields));
            }

            return sb.ToString();
        }

        [Route("[action]")]
        [HttpGet]

        public object GetAllTerminals(int clientID)
        {
            return _objExceptionReport.GetTerminalOptions(clientID);

        } 

    }

  

}

