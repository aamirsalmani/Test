﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;


namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class FieldController : ControllerBase
    {
        private readonly IField _objField;

        public FieldController(IField objField)
        {
            _objField = objField;
        }

        //[HttpPost]
        //public object GetChannelModeDetailsFieldList(string ClientID)
        //{
        //    return _objField.GetChannelModeDetailsField(ClientID);
        //}

        [Route("[action]")]
        [HttpPost]
        public object AddFieldConfig(AddFieldConfigModel addFieldConfigModel)
        {
            string alertMessage = string.Empty;
            DataTable dtRecords = _objField.GetChannelModeDetailsField(addFieldConfigModel.ClientID);
            bool flag = false;

            if (dtRecords.Rows.Count > 0)
            {
                for (int k = 0; k < dtRecords.Rows.Count; k++)
                {
                    string col1 = dtRecords.Rows[k]["ONUS"].ToString();
                    string col2 = dtRecords.Rows[k]["ACQUIRER"].ToString();
                    string col3 = dtRecords.Rows[k]["ISSUER"].ToString();

                    if (dtRecords.Rows[k]["ChannelName"].ToString() == "ATM" && (addFieldConfigModel.ChannelID == "1" || addFieldConfigModel.ChannelID == "0"))
                    {
                        if ((col1 != "" || col2 != "") && (addFieldConfigModel.TerminalCode == "" || addFieldConfigModel.BinNo == ""))
                        {
                            if (addFieldConfigModel.TerminalCode == "")
                                alertMessage = "Enter Terminal Code.";
                            else if (addFieldConfigModel.BinNo == "")
                                alertMessage = "Enter BIN No.";
                            //else
                            //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter Acquirer ID')", true);
                        }
                        else if (col3 != "" && addFieldConfigModel.BinNo == "")
                            alertMessage = "Enter BIN No.";
                        else
                            flag = true;
                    }
                    else
                        flag = true;

                    #region Commented
                    //else if (txtATM.Text == "")
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter ATM Code')", true);
                    //else
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter Acquirer ID')", true);
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "POS" && txtPOS.Text == "" )
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter POS Code')", true);
                    //}
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "E-COMMERCE" && txtECOM.Text == "")
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter E-COMMERCE Code')", true);
                    //}
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "IMPS" && txtECOM.Text == "")
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter IMPS Code')", true);
                    //}
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "MICRO_ATM" && txtMicroATM.Text == "")
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter MICROATM Code')", true);
                    //}
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "UPI" && txtUPI.Text == "")
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter UPI Code')", true);
                    //}
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "MOBILERECHARGE" && txtMblRchrg.Text == "")
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter MOBILERECHARGE Code')", true);
                    //}
                    #endregion
                }
            }

            if (flag == true && alertMessage.Length == 0)
            {
                DataTable dtRecord = _objField.AddFieldConfig(addFieldConfigModel);

                if (dtRecord.Rows[0]["Status"].ToString() == "Save")
                {
                    alertMessage = "Field Identifications _configuration Set Successfully.";
                }
                else if (dtRecord.Rows[0]["Status"].ToString() == "Update")
                {
                    alertMessage = "Field Identifications _configuration Updated Successfully";
                }
                else
                {
                    alertMessage = "Field Identifications _configuration Failed.";
                }
            }
            else
            {
                if (alertMessage.Length == 0)
                {
                    alertMessage = "Field Identifications _configuration Failed.";
                }               
            }
            return alertMessage;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetVendorFieldList(string ClientId)
        {
            return _objField.GetVendorFields(ClientId);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetChannelFieldList(string ClientId)
        {
            return _objField.GetChannelFields(ClientId);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetModeFieldList(string ClientId, string ChannelID)
        {
            return _objField.GetModeFields(ClientId, ChannelID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetFormatIdFieldList(string ClientID, string VendorID, string ChannelID, string ModeID)
        {
            return _objField.GetFormatIdFields( ClientID,  VendorID,  ChannelID,  ModeID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetFieldIdentificationDetailsList(string ClientID, string VendorID, string ChannelID, string ModeID,string FormatID)
        {
            return _objField.GetFieldIdentificationDetails(ClientID, VendorID, ChannelID, ModeID, FormatID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetFieldIdentificationVendorDetailsList(string VendorID, string ChannelID)
        {
            return _objField.GetFieldIdentificationVendorDetails(VendorID, ChannelID);
        }
    }
}