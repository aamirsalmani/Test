﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASPTrace.Contracts;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class FileConfigController : ControllerBase
    {
        private readonly IFileConfig _objFileConfig;

        public FileConfigController(IFileConfig objFileConfig)
        {
            _objFileConfig = objFileConfig;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetClientFileConfigList()
        {
            return _objFileConfig.GetClientFileConfig();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetConfiguredFormatFileConfigList(string ClientID)
        {
            return _objFileConfig.GetConfiguredFormatFileConfig(ClientID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetLogTypeFileConfigList(string ClientID)
        {
            return _objFileConfig.GetLogTypeFileConfig(ClientID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetChannelFileConfigList(string ClientID)
        {
            return _objFileConfig.GetChannelFileConfig(ClientID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetModeFileConfigList(string ClientID, int ChannelID)
        {
            return _objFileConfig.GetModeFileConfig(ClientID, ChannelID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetVendorFileConfigList(string VendorType)
        {
            return _objFileConfig.GetVendorFileConfig(VendorType);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetFileFormatActiveFileConfigList(string VendorType, string ClientID, string ChannelID, string ModeID, string VendorID)
        {
            ReturnFileFormatActive returnFileFormatActive = new ReturnFileFormatActive();

            returnFileFormatActive.fileFormatActiveFileConfigModel = _objFileConfig.GetFileFormatActiveFileConfig(VendorType, ClientID, ChannelID, ModeID, VendorID);

            returnFileFormatActive.fileFormatConfigModelList = new List<FileFormatConfigModel>();

            if (returnFileFormatActive.fileFormatActiveFileConfigModel != null)
            {
                string xmlFile = returnFileFormatActive.fileFormatActiveFileConfigModel.FormatDescriptionXml;

                if (xmlFile != null && xmlFile.Length > 0)
                {
                    System.Data.DataSet ds = new System.Data.DataSet();
                    ds.ReadXml(new System.Xml.XmlTextReader(new System.IO.StringReader(xmlFile)));

                    System.Data.DataTable dt = new System.Data.DataTable();
                    if (ds.Tables.Count > 1)
                    {
                        dt.Columns.AddRange(new System.Data.DataColumn[4] {
                            new System.Data.DataColumn("FieldName", typeof(string)),
                            new System.Data.DataColumn("StartPosition", typeof(string)),
                            new System.Data.DataColumn("Length",typeof(string)),
                            new System.Data.DataColumn("Position", typeof(string))
                            });

                        for (int i = 0; i < ds.Tables.Count; i++)
                        {
                            string col1 = ds.Tables[i].TableName;
                            dt.Rows.Add(col1, ds.Tables[col1].Rows[0][0].ToString(), ds.Tables[col1].Rows[0][1].ToString(), null);
                        }
                    }
                    else
                    {
                        dt.Columns.AddRange(new System.Data.DataColumn[4] {
                                new System.Data.DataColumn("FieldName", typeof(string)),
                                new System.Data.DataColumn("StartPosition", typeof(string)),
                                new System.Data.DataColumn("Length",typeof(string)),
                                new System.Data.DataColumn("Position", typeof(string))});

                        for (int i = 0; i < ds.Tables[0].Columns.Count; i++)
                        {
                            string col = ds.Tables[0].Columns[i].ColumnName;
                            dt.Rows.Add(col, null, null, ds.Tables[0].Rows[0][col].ToString());
                        }
                    }

                    foreach (System.Data.DataRow dr in dt.Rows)
                    {
                        FileFormatConfigModel fileFormatConfigModel = new FileFormatConfigModel();

                        fileFormatConfigModel.FieldName = Convert.ToString(dr["FieldName"]);
                        fileFormatConfigModel.StartPosition = Convert.ToString(dr["StartPosition"]);
                        fileFormatConfigModel.Length = Convert.ToString(dr["Length"]);
                        fileFormatConfigModel.Position = Convert.ToString(dr["Position"]);

                        returnFileFormatActive.fileFormatConfigModelList.Add(fileFormatConfigModel);
                    }
                }
            }

            if (returnFileFormatActive.fileFormatConfigModelList == null)
            {
                returnFileFormatActive.fileFormatConfigModelList = new List<FileFormatConfigModel>();
            }

            return returnFileFormatActive;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetFileFormatHistoryFileConfigList(string VendorType, string ClientID, string ChannelID, string ModeID, string VendorID)
        {
            return _objFileConfig.GetFileFormatHistoryFileConfig(VendorType, ClientID, ChannelID, ModeID, VendorID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetFileFormatFileConfig(string ClientID, string ChannelID, string ModeID, string VendorID, string FileExt, string SeparatorType, string FilePrefix)
        {
            //return _objFileConfig.GetFileFormatFileConfig(ClientID, ChannelID, ModeID, VendorID, FileExt, SeparatorType, FilePrefix);

            ReturnFileFormatActive returnFileFormatActive = new ReturnFileFormatActive();

            returnFileFormatActive.fileFormatActiveFileConfigModel = _objFileConfig.GetFileFormatFileConfig(ClientID, ChannelID, ModeID, VendorID, FileExt, SeparatorType, FilePrefix);

            returnFileFormatActive.fileFormatConfigModelList = new List<FileFormatConfigModel>();

            if (returnFileFormatActive.fileFormatActiveFileConfigModel != null)
            {
                string xmlFile = returnFileFormatActive.fileFormatActiveFileConfigModel.FormatDescriptionXml;

                if (xmlFile != null && xmlFile.Length > 0)
                {
                    System.Data.DataSet ds = new System.Data.DataSet();
                    ds.ReadXml(new System.Xml.XmlTextReader(new System.IO.StringReader(xmlFile)));

                    System.Data.DataTable dt = new System.Data.DataTable();
                    if (ds.Tables.Count > 1)
                    {
                        dt.Columns.AddRange(new System.Data.DataColumn[4] {
                            new System.Data.DataColumn("FieldName", typeof(string)),
                            new System.Data.DataColumn("StartPosition", typeof(string)),
                            new System.Data.DataColumn("Length",typeof(string)),
                            new System.Data.DataColumn("Position", typeof(string))
                            });

                        for (int i = 0; i < ds.Tables.Count; i++)
                        {
                            string col1 = ds.Tables[i].TableName;
                            dt.Rows.Add(col1, ds.Tables[col1].Rows[0][0].ToString(), ds.Tables[col1].Rows[0][1].ToString(), null);
                        }
                    }
                    else
                    {
                        dt.Columns.AddRange(new System.Data.DataColumn[4] {
                                new System.Data.DataColumn("FieldName", typeof(string)),
                                new System.Data.DataColumn("StartPosition", typeof(string)),
                                new System.Data.DataColumn("Length",typeof(string)),
                                new System.Data.DataColumn("Position", typeof(string))});

                        for (int i = 0; i < ds.Tables[0].Columns.Count; i++)
                        {
                            string col = ds.Tables[0].Columns[i].ColumnName;
                            dt.Rows.Add(col, null, null, ds.Tables[0].Rows[0][col].ToString());
                        }
                    }

                    foreach (System.Data.DataRow dr in dt.Rows)
                    {
                        FileFormatConfigModel fileFormatConfigModel = new FileFormatConfigModel();

                        fileFormatConfigModel.FieldName = Convert.ToString(dr["FieldName"]);
                        fileFormatConfigModel.StartPosition = Convert.ToString(dr["StartPosition"]);
                        fileFormatConfigModel.Length = Convert.ToString(dr["Length"]);
                        fileFormatConfigModel.Position = Convert.ToString(dr["Position"]);

                        returnFileFormatActive.fileFormatConfigModelList.Add(fileFormatConfigModel);
                    }
                }
            }

            if (returnFileFormatActive.fileFormatConfigModelList == null)
            {
                returnFileFormatActive.fileFormatConfigModelList = new List<FileFormatConfigModel>();
            }

            return returnFileFormatActive;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetFileFormatDefualtFileConfig(string FileExt, string SeparatorType, string ChannelID, string ModeID, string VendorID)
        {
            ReturnFileFormatActive returnFileFormatActive = new ReturnFileFormatActive();

            returnFileFormatActive.fileFormatActiveFileConfigModel = _objFileConfig.GetFileFormatDefualtFileConfig(FileExt, SeparatorType, ChannelID, ModeID, VendorID);

            returnFileFormatActive.fileFormatConfigModelList = new List<FileFormatConfigModel>();

            if (returnFileFormatActive.fileFormatActiveFileConfigModel != null)
            {
                string xmlFile = returnFileFormatActive.fileFormatActiveFileConfigModel.FormatDescriptionXml;

                if (xmlFile != null && xmlFile.Length > 0)
                {
                    System.Data.DataSet ds = new System.Data.DataSet();
                    ds.ReadXml(new System.Xml.XmlTextReader(new System.IO.StringReader(xmlFile)));

                    System.Data.DataTable dt = new System.Data.DataTable();
                    if (ds.Tables.Count > 1)
                    {
                        dt.Columns.AddRange(new System.Data.DataColumn[4] {
                            new System.Data.DataColumn("FieldName", typeof(string)),
                            new System.Data.DataColumn("StartPosition", typeof(string)),
                            new System.Data.DataColumn("Length",typeof(string)),
                            new System.Data.DataColumn("Position", typeof(string))
                            });

                        for (int i = 0; i < ds.Tables.Count; i++)
                        {
                            string col1 = ds.Tables[i].TableName;
                            dt.Rows.Add(col1, ds.Tables[col1].Rows[0][0].ToString(), ds.Tables[col1].Rows[0][1].ToString(), null);
                        }
                    }
                    else
                    {
                        dt.Columns.AddRange(new System.Data.DataColumn[4] {
                                new System.Data.DataColumn("FieldName", typeof(string)),
                                new System.Data.DataColumn("StartPosition", typeof(string)),
                                new System.Data.DataColumn("Length",typeof(string)),
                                new System.Data.DataColumn("Position", typeof(string))});

                        for (int i = 0; i < ds.Tables[0].Columns.Count; i++)
                        {
                            string col = ds.Tables[0].Columns[i].ColumnName;
                            dt.Rows.Add(col, null, null, ds.Tables[0].Rows[0][col].ToString());
                        }
                    }

                    foreach (System.Data.DataRow dr in dt.Rows)
                    {
                        FileFormatConfigModel fileFormatConfigModel = new FileFormatConfigModel();

                        fileFormatConfigModel.FieldName = Convert.ToString(dr["FieldName"]);
                        fileFormatConfigModel.StartPosition = Convert.ToString(dr["StartPosition"]);
                        fileFormatConfigModel.Length = Convert.ToString(dr["Length"]);
                        fileFormatConfigModel.Position = Convert.ToString(dr["Position"]);

                        returnFileFormatActive.fileFormatConfigModelList.Add(fileFormatConfigModel);
                    }
                }
            }

            if (returnFileFormatActive.fileFormatConfigModelList == null)
            {
                returnFileFormatActive.fileFormatConfigModelList = new List<FileFormatConfigModel>();
            }

            return returnFileFormatActive;

        }

        [Route("[action]")]
        [HttpPost]
        public object GetFileFormatByFileTypeFileConfigList(FileFormatFileConfigModel fileFormatFileConfigModel)
        {
            return _objFileConfig.GetFileFormatByFileTypeFileConfig(fileFormatFileConfigModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object InsertFileFormat([FromForm] FileFormatHistoryFileConfigModel fileFormatHistoryFileConfigModel)
        {
            return _objFileConfig.InsertFileFormat(fileFormatHistoryFileConfigModel);
        }
    }
}
