﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASPTrace.Contracts;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Models;
using System.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using Utility;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ForceSettlementController : ControllerBase
    {
        private readonly IForceSettlement _objForceSettlement;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;

        public ForceSettlementController(IForceSettlement objForceSettlement, IConfiguration Configuration, ASPTrace.Contracts.ICommon Common)
        {
            _objForceSettlement = objForceSettlement;
            _configuration = Configuration;
            _objCommon = Common;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetStatusMasterForceSettlementList()
        {
            return _objForceSettlement.GetStatusMasterForceSettlement();
        }

        [Route("[action]")]
        [HttpPost]
        public object GetClientForceSettlementDetailsList(ClientForceSettlementModel clientForceSettlementModel)
        {
            List<ClientForceSettlementDetailsModel> ClientForceSettlementList = _objForceSettlement.GetClientForceSettlementDetails(clientForceSettlementModel);
 
            return ClientForceSettlementList;
        }

        [Route("[action]")]
        [HttpPost]
        public object InsertForceSettlementDetails(ForceSettledModel forceSettledModel)
        {
            return _objForceSettlement.InsertForceSettlementDetails(forceSettledModel);
        }

    

    }
}
