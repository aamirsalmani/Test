﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;
using Utility;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class FraudReportController : ControllerBase
    {
        private readonly IFraudReport _objFraudReport;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;
        public FraudReportController(IFraudReport objFraudReport, IConfiguration Configuration, ASPTrace.Contracts.ICommon Common)
        {
            _objFraudReport = objFraudReport;
            _configuration = Configuration;
            _objCommon = Common;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetFrequentReversalReportDetailsList(FraudReportModel frequentReversalReportModel)
        {
            List<FrequentReversalReportDetailsModel> frequentReversalReportDetailsModelList = _objFraudReport.GetFrequentReversalReportDetails(frequentReversalReportModel);

            
            

            string EMekKey1 = this._configuration.GetValue<string>("AppSettings:EMekKey1");
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            //foreach (FrequentReversalReportDetailsModel frequentReversalReportDetailsModel in frequentReversalReportDetailsModelList)
            //{
            //    try
            //    {
            //        frequentReversalReportDetailsModel.CardNo = AesEncryption.DecryptString(frequentReversalReportDetailsModel.CardNo);
            //    }
            //    catch
            //    {

            //    }
            //}

            return frequentReversalReportDetailsModelList; 
        }

        [Route("[action]")]
        [HttpPost]
        public object GetFrequentReversalTxnByTxnCountList(FrequentReversalsReportModel frequentReversalReportModel)
        {
            FrequentReversalTxnByTxnCount frequentReversalTxnByTxnCounts = _objFraudReport.GetFrequentReversalTxnByTxnCount(frequentReversalReportModel);

            
            

            string EMekKey1 = this._configuration.GetValue<string>("AppSettings:EMekKey1");
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            //foreach (FrequentReversalTxnDetailsModel frequentReversalTxnDetailsModel in frequentReversalTxnByTxnCounts.FrequentReversalTxnDetails)
            //{
            //    try
            //    {
            //        frequentReversalTxnDetailsModel.CardNumber = AesEncryption.DecryptString(frequentReversalTxnDetailsModel.CardNumber);
            //    }
            //    catch
            //    {

            //    }
            //}

            return frequentReversalTxnByTxnCounts;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetHighValueTerminalTransactionsList(string ClientId, string ChannelID, string UserName)
        {
            return _objFraudReport.GetHighValueTerminalTransactions(ClientId, ChannelID, UserName);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetHighValueTransactionsReportList(HighValueTransactionsModel highValueTransactionsModel)
        {
            List<HighValueTransactionsReportModel> highValueTransactionsReportModelList = _objFraudReport.GetHighValueTransactionsReport(highValueTransactionsModel);

            
            

            string EMekKey1 = this._configuration.GetValue<string>("AppSettings:EMekKey1");
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            //foreach (HighValueTransactionsReportModel highValueTransactionsReportModel in highValueTransactionsReportModelList)
            //{
            //    try
            //    {
            //        highValueTransactionsReportModel.CardNumber = AesEncryption.DecryptString(highValueTransactionsReportModel.CardNumber);
            //    }
            //    catch
            //    {

            //    }
            //}

            return highValueTransactionsReportModelList;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetHighValueTransactionsOnTxnCountList(HighValueTransactionModel highValueTransactionsModel)
        {
            HighValueTransactionsOnTxnCountModel highValueTransactionsOnTxnCountModels = _objFraudReport.GetHighValueTransactionsOnTxnCount(highValueTransactionsModel);

            
            

            string EMekKey1 = this._configuration.GetValue<string>("AppSettings:EMekKey1");
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            //foreach (HighValueTransactionsFraudCardDetailsReportModel highValueTransactionsFraudCardDetailsReportModel in highValueTransactionsOnTxnCountModels.FraudCardDetails)
            //{
            //    try
            //    {
            //        highValueTransactionsFraudCardDetailsReportModel.CardNumber = AesEncryption.DecryptString(highValueTransactionsFraudCardDetailsReportModel.CardNumber);
            //    }
            //    catch
            //    {

            //    }
            //}

            return highValueTransactionsOnTxnCountModels;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetMidnightTransactionsTxnCountList(MidnightTransactionsModel midnightTransactionsModel)
        {
            List<MidnightTransactionsReportModel> MidnightTransactionsReportModelList = _objFraudReport.GetMidnightTransactionsTxnCount(midnightTransactionsModel);

            
            

            string EMekKey1 = this._configuration.GetValue<string>("AppSettings:EMekKey1");
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            //foreach (MidnightTransactionsReportModel midnightTransactionsReportModel in MidnightTransactionsReportModelList)
            //{
            //    try
            //    {
            //        midnightTransactionsReportModel.CardNumber = AesEncryption.DecryptString(midnightTransactionsReportModel.CardNumber);
            //    }
            //    catch
            //    {

            //    }
            //}

            return MidnightTransactionsReportModelList;
        }


        [Route("[action]")]
        [HttpPost]
        public object GetMultipleTxnsWithDiffTerminalList(MultipleTxnsDiffModel multipleTxnsDiffModel)
        {
            List<MultipleTxnsWithDiffTerminalModel> multipleTxnsWithDiffTerminalModelList = _objFraudReport.GetMultipleTxnsWithDiffTerminal(multipleTxnsDiffModel);

            
            

            string EMekKey1 = this._configuration.GetValue<string>("AppSettings:EMekKey1");
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            //foreach (MultipleTxnsWithDiffTerminalModel multipleTxnsWithDiffTerminalModel in multipleTxnsWithDiffTerminalModelList)
            //{
            //    try
            //    {
            //        multipleTxnsWithDiffTerminalModel.CardNo = AesEncryption.DecryptString(multipleTxnsWithDiffTerminalModel.CardNo);
            //    }
            //    catch
            //    {

            //    }
            //}

            return multipleTxnsWithDiffTerminalModelList;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetFraudReportDiffByTxnCountList(MultipleTxnDiffModel multipleTxnsDiffModel)
        {
            FraudReportDiffByTxnCount fraudReportDiffByTxnCounts = _objFraudReport.GetFraudReportDiffByTxnCount(multipleTxnsDiffModel);

            
            

            string EMekKey1 = this._configuration.GetValue<string>("AppSettings:EMekKey1");
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            //foreach (FraudReportDiffModel fraudReportDiffModel in fraudReportDiffByTxnCounts.FraudReports)
            //{
            //    try
            //    {
            //        fraudReportDiffModel.CardNumber = AesEncryption.DecryptString(fraudReportDiffModel.CardNumber);
            //    }
            //    catch
            //    {

            //    }
            //}

            return fraudReportDiffByTxnCounts;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetMultipleTxnsWithSameTerminalList(FraudReportModel multipleTxnsSameModel)
        {
            List<MultipleTxnsWithSameTerminalModel> multipleTxnsWithSameTerminalModelList = _objFraudReport.GetMultipleTxnsWithSameTerminal(multipleTxnsSameModel);

            
            

            string EMekKey1 = this._configuration.GetValue<string>("AppSettings:EMekKey1");
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            //foreach (MultipleTxnsWithSameTerminalModel multipleTxnsWithSameTerminalModel in multipleTxnsWithSameTerminalModelList)
            //{
            //    try
            //    {
            //        multipleTxnsWithSameTerminalModel.CardNo = AesEncryption.DecryptString(multipleTxnsWithSameTerminalModel.CardNo);
            //    }
            //    catch
            //    {

            //    }
            //}

            return multipleTxnsWithSameTerminalModelList;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetFraudReportSameByTxnCountList(MultipleTxnsSameModel multipleTxnsSameModel)
        {
            FraudReportSameByTxnCount fraudReportSameByTxnCounts = _objFraudReport.GetFraudReportSameByTxnCount(multipleTxnsSameModel);

            
            

            string EMekKey1 = this._configuration.GetValue<string>("AppSettings:EMekKey1");
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            foreach (FraudReportSameModel fraudReportSameModel in fraudReportSameByTxnCounts.FraudReports)
            {
                try
                {
                    fraudReportSameModel.CardNumber = AesEncryption.DecryptString(fraudReportSameModel.CardNumber);
                }
                catch
                {

                }
            }

            return fraudReportSameByTxnCounts;
        }
    }
}