﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using ASPTrace.Models;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    { 
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;
        private readonly SessionSettings _settings;
        public HomeController(IConfiguration Configuration, ASPTrace.Contracts.ICommon Common, Microsoft.Extensions.Options.IOptions<SessionSettings> Settings)
        { 
            _configuration = Configuration;
            _objCommon = Common;
            _settings = Settings.Value;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetPowerBIURL(string UserID)
        {
            return _objCommon.GetPowerBIURL_Link(UserID);
        }

        [Route("[action]")]
        [HttpGet]
        public object CheckUserLogin(string UserID)
       {
            return _objCommon.GetUserLogin(UserID);
        }


        [Route("[action]")]
        [HttpGet]
        public List<GetSuccessfulUnSuccessfulCount> GetDashBoardData(string UserID) 
        {
            return _objCommon.GetSuccessfulUnSuccessRecords(UserID); ;
        }


        [HttpPost("GetATMDashBoardData")]
        public List<GetSuccessfulUnSuccessfulCount> GetATMDashBoardData([FromBody] ATMChartInput aTMChartInput)
        {
            return _objCommon.GetATMSuccessfulUnSuccessRecords(aTMChartInput);
        }


        [Route("[action]")]
        [HttpGet]
        public List<GetSuccessfulUnSuccessfulCount> GetATMSuUnDashBoardData(string UserID)
        {
            return _objCommon.GetATMSuccessfulUnSuccessRecords(UserID); ;
        }

        [Route("[action]")]
        [HttpGet]
        public IActionResult CheckAccess([FromQuery] string path)
        {
            //var userId = User.Claims.FirstOrDefault(c => c.Type == "UserID")?.Value;
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            // Await your async DB or service method
            string permission = _objCommon.UserHasAccessAsync(userId, path);

            bool allowed = (permission == "Access");

            return Ok(new { allowed });
        }

        //[Route("[action]")]
        //[HttpPost]
        //public IActionResult RefreshToken([FromBody] RefreshTokenRequest model)
        //{
        //    var fake_refreshToken = model.RefreshToken;

        //    var refreshToken = Request.Cookies["refreshToken"];

        //    if (string.IsNullOrEmpty(refreshToken))
        //    {
        //        return Unauthorized(new { Message = "No refresh token found." });
        //    }

        //    var userId = _objCommon.GetUserIdFromRefreshToken(refreshToken); // Validate refresh token

        //    if (userId != null)
        //    {
        //        LoginSuccessModel loginSuccessModel = _objCommon.GetById(userId);

        //        if (loginSuccessModel != null && loginSuccessModel.UserID != null)
        //        {
        //            var tokenString = Common.GenerateTokens(userId, _settings.Secret, _settings.SessionTimout);
        //            var newRefreshToken = _objCommon.AddRefreshToken(loginSuccessModel.UserID, DateTime.UtcNow.AddDays(7));

        //            return Ok(new
        //            {
        //                Username = loginSuccessModel.UserID,
        //                Role = loginSuccessModel.RoleName,
        //                FirstName = loginSuccessModel.FirstName,
        //                ClientLogo = loginSuccessModel.ClientLogo,
        //                AccessToken = tokenString,
        //                RefreshToken = newRefreshToken
        //            });
        //        }
        //    }

        //    return Unauthorized();
        //}

    }

   
}