﻿using System;
using System.Data;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using NetworkNPCI;
using Utility;
using SWITCH;
using CBS;
using EJ;
using VISA;
using Master;
using BFS;
using System.Linq;
using ASPTrace.Models;
using DocumentFormat.OpenXml.Drawing;
using ASPTraceWebApi.ClassFiles;
using ImportData;
 

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ImportFileController : ControllerBase
    {

        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.IImportLogs objIImportLogs;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public ImportFileController(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.IImportLogs __objIImportLogs, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objIImportLogs = __objIImportLogs;
            objCommon = _Common; ;
        }

        //[Route("[action]")]
        [HttpPost]
        public object Post([FromForm] ASPTrace.Models.ImportFileModel file)
        {
            ASPTrace.Models.ImportFileStatus importFileStatus = new ASPTrace.Models.ImportFileStatus();

            try
            {
                bool IsEncryption = System.Convert.ToBoolean(_configuration.GetValue<string>("AppSettings:IsEncryption"));
                string EMekKey1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
                string relativePath = _configuration["AppSettings:MekKey2Path"];
                string EMekKey2 = System.IO.File.ReadAllText(relativePath).Trim();

                int FileUploadStatus = 0;
                string Connectionstring = IsEncryption ? AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMekKey1, EMekKey2) : _configuration.GetConnectionString("TraceConnection");


                string MSG = string.Empty;

                DateTime? FileDateTime = null;
                DateTime? MainFileDate = DateTime.Now;
                DateTime? StartTime = null;
                string tempFiletype = string.Empty;

                if (file.ImportFile == null)
                {
                    importFileStatus.MSG = "Error";
                    importFileStatus.Status = "File not selected";
                }
                else
                {
                    Guid objGuid = Guid.NewGuid();

                    string sFileName = "Trace_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + objGuid.ToString().Replace("-", "") + file.ImportFile.FileName;

                    string sFileExt1 = System.IO.Path.GetExtension(sFileName);

                    string path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\Switch\\", sFileName);

                    using (System.IO.Stream stream = new System.IO.FileStream(path, System.IO.FileMode.Create))
                    {
                        file.ImportFile.CopyTo(stream);
                    }

                    string FileImportID = string.Empty;

                    DataTable dt = objIImportLogs.GetFileTypeFormatById(file.ClientID, file.FileFormatId);


                    FileImportRequest fileImportRequest = new FileImportRequest();
                    fileImportRequest.Path = path;
                    fileImportRequest.FileName = file.ImportFile.FileName;
                    fileImportRequest.ConfigData = dt;
                    fileImportRequest.UserName = file.UserName;
                    fileImportRequest.ClientCode = file.ClientID;
                    fileImportRequest.UserName = file.UserName;

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        StartTime = DateTime.Now;

                        bool Invalid = true;
                        bool isDynamic = false;

                        tempFiletype = Convert.ToString(dt.Rows[0]["VendorType"]);

                        try
                        {
                            FileDateTime = DateTime.ParseExact(ExtractNumber(file.ImportFile.FileName.Substring(file.ImportFile.FileName.IndexOf("_") + 1, 8).Trim()), Convert.ToString(dt.Rows[0]["FileDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None), System.Globalization.CultureInfo.InvariantCulture);
                        }
                        catch
                        {

                        }

                        FileUploadStatusModel objInsert = new FileUploadStatusModel();
                        objInsert.ClientID = Convert.ToString(dt.Rows[0]["ClientID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ClientID"]);
                        objInsert.ChannelID = Convert.ToString(dt.Rows[0]["ChannelID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ChannelID"]);
                        objInsert.ModeID = Convert.ToString(dt.Rows[0]["ModeID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ModeID"]);
                        objInsert.FileFormatId = file.FileFormatId;
                        objInsert.FileName = file.ImportFile.FileName;
                        objInsert.FilePath = path;
                        objInsert.FileDate = FileDateTime;
                        objInsert.CreatedBy = file.UserName;

                        FileImportID = objCommon.InsertFileUploadDetail(objInsert);

                        DataTable _DataTable = new DataTable();
                        List<BatchDetails> GetFailedBatch = new List<BatchDetails>();

                        DataTable _DataTableMCCounter = new DataTable();

                        DataTable _DataTableSWCounter = new DataTable();

                        DataTable dt1 = objIImportLogs.GetFileNameNotContain(file.ClientID, file.FileFormatId);

                        if (dt1 != null && dt1.Rows.Count > 0)
                        {
                            string FileNameContain = dt1.Rows[0]["FileNameNotContain"].ToString();
                            string VendorType2 = dt1.Rows[0]["VendorType"].ToString();

                            if (VendorType2 == "NETWORK")
                            {
                                if (FileNameContain == "")
                                {
                                    Invalid = true;
                                }
                                else
                                {

                                    {
                                        if (!sFileName.Contains(dt1.Rows[0]["FileNameNotContain"].ToString()))
                                        {
                                            importFileStatus.MSG = "Error";
                                            importFileStatus.Status = "Invalid bank file upload";
                                            Invalid = false;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                Invalid = true;
                            }
                        }
                        else
                        {
                            Invalid = false;
                        }

                        if (Invalid)
                        {

                            int count = 0;
                            int errorCount = 0;
                            int InsertMachineCount = 0;
                            int TotalCount = 1;
                            int InsertCount = 0;
                            int FinalInsertCount = 0;
                            int TotalRowCount = 1;
                            int FinalTotalRowCount = 0;
                            string sTerminalId = string.Empty;
                            string BOBSplitter = string.Empty;
                            DataSet _Dataset = new DataSet(); 

                            switch (file.FileFormatText)
                            { 
                                #region InsertDataEJ
                                case "EJ_ATM_Common":
                                    //Clear(); 

                                    if (dt.Rows[0][3].ToString() == "11")
                                    {
                                        SplitterNCR objSplitterNCR = new SplitterNCR(Connectionstring, EMekKey1, EMekKey2);
                                        _DataTable = objSplitterNCR.ASP_SplitData1(fileImportRequest);
                                    }
                                    else if (dt.Rows[0][7].ToString() == "59")
                                    {
                                        if (sFileName.Contains("AD021001"))
                                        {
                                            SplitterPerto objSplitterPerto = new SplitterPerto(Connectionstring, EMekKey1, EMekKey2);
                                            _DataTable = objSplitterPerto.ASP_SplitData(fileImportRequest);
                                        }
                                        else
                                        {
                                            SplitterInfinity objSplitterInfinity = new SplitterInfinity(Connectionstring, EMekKey1, EMekKey2);
                                            _DataTable = objSplitterInfinity.ASP_SplitData(fileImportRequest);
                                        }
                                    }
                                    else if (dt.Rows[0][7].ToString() == "56")
                                    {
                                        SplitterESAF objSplitterBhutan = new SplitterESAF(Connectionstring, EMekKey1, EMekKey2);
                                        _DataTable = objSplitterBhutan.ASP_SplitData1(fileImportRequest);
                                        objSplitterBhutan = null;
                                    }
                                    else if (dt.Rows[0][7].ToString() == "100")
                                    {
                                        SplitterCommon objSplitter = new SplitterCommon(Connectionstring, EMekKey1, EMekKey2);
                                        _DataTable = objSplitter.SplitterSrilanka(fileImportRequest);
                                        objSplitter = null;
                                    }
                                    else if (dt.Rows[0][7].ToString() == "28")
                                    {
                                        SplitterBhutan objSplitterBhutan = new SplitterBhutan(Connectionstring, EMekKey1, EMekKey2);
                                        _DataTable = objSplitterBhutan.ASP_SplitDataMaster(fileImportRequest);
                                        objSplitterBhutan = null;
                                    }
                                    else if (dt.Rows[0][7].ToString() == "46")
                                    {
                                        SplitterBhutan objSplitterBhutan = new SplitterBhutan(Connectionstring, EMekKey1, EMekKey2);
                                        _DataTable = objSplitterBhutan.BDB_SplitData(fileImportRequest);
                                        objSplitterBhutan = null;
                                    }
                                    else if (dt.Rows[0][7].ToString() == "71")
                                    {
                                        SplitterBhutan objSplitterBhutan = new SplitterBhutan(Connectionstring, EMekKey1, EMekKey2);

                                        sTerminalId = sFileName.Substring(6, 8);

                                        DataTable TerminalTable = Utility.Common.GetBOBInfoByTerminalId(Connectionstring, file.ClientID, sTerminalId);

                                        if (TerminalTable != null && TerminalTable.Rows.Count > 0)
                                        {
                                            BOBSplitter = Convert.ToString(TerminalTable.Rows[0]["Splitter"]);
                                        }


                                        if (BOBSplitter == "1")
                                        {
                                            _DataTable = objSplitterBhutan.ATMEJFileSpliter1(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                        }
                                        else if (BOBSplitter == "2")
                                        {

                                            _DataTable = objSplitterBhutan.ATMEJFileSpliter2(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                        }
                                        else
                                        {
                                            _DataTable = objSplitterBhutan.ATMEJFileSpliter3(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                        }
                                    }
                                    else if (dt.Rows[0][7].ToString() == "108")
                                    {
                                        if (sFileName != null)
                                        {
                                            string afterUnderscore = sFileName.Substring(sFileName.LastIndexOf('_') + 1);
                                            string datePart = new string(afterUnderscore.Where(char.IsDigit).ToArray());
                                            if (datePart.Length == 8)
                                            {
                                                MainFileDate = DateTime.ParseExact(datePart, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                            }
                                            else
                                            {
                                                MainFileDate = DateTime.Now;
                                            }
                                        }
                                        else
                                        {
                                            MainFileDate = DateTime.Now;
                                        }

                                        SplitterCommon NagpurEjspliter = new SplitterCommon(Connectionstring, EMekKey1, EMekKey2);
                                        _Dataset = NagpurEjspliter.SplitterNagpur(fileImportRequest);
                                        NagpurEjspliter = null;

                                        if (_Dataset != null && _Dataset.Tables.Count > 0)
                                        {
                                            if (_Dataset.Tables[0].Rows.Count > 0)
                                            {
                                                MSG = objIImportLogs.BulkInsertEJData(_Dataset.Tables[0], FileImportID);
                                            }
                                            if (_Dataset.Tables[1].Rows.Count > 0)
                                            {
                                                //objIImportLogs.BulkInsertEJMachineCounterData(_Dataset.Tables[1]);
                                            }
                                            if (_Dataset.Tables[2].Rows.Count > 0)
                                            {
                                                // objIImportLogs.BulkInsertEJSwitchCounterData(_Dataset.Tables[2]);
                                            }
                                        }
                                        break;
                                    }

                                    else
                                    {
                                        if ((dt.Rows[0][3].ToString() == "11") || (dt.Rows[0][3].ToString() == "18") || (dt.Rows[0][3].ToString() == "24"))
                                        {
                                            SplitterNCR objSplitterNCR = new SplitterNCR(Connectionstring, EMekKey1, EMekKey2);
                                            _DataTable = objSplitterNCR.ASP_SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        }
                                        else if (dt.Rows[0][3].ToString() == "13")
                                        {
                                            SplitterDIEBOLD objSplitterDIEBOLD = new SplitterDIEBOLD(Connectionstring, EMekKey1, EMekKey2);
                                            _DataTable = objSplitterDIEBOLD.ASP_SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        }
                                        else if (dt.Rows[0][3].ToString() == "2")
                                        {
                                            SplitterCommon objSplitterCommon = new SplitterCommon(Connectionstring, EMekKey1, EMekKey2);
                                            _DataTable = objSplitterCommon.ASP_SplitData(fileImportRequest);
                                        }
                                    }
                                    // string char = dt.Rows[0][3].ToString();
                                    //FinalInsertCount += InsertCount;
                                    //FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertEJData(_DataTable, FileImportID);

                                        if (dt.Rows[0][7].ToString() == "72" || dt.Rows[0][7].ToString() == "62")
                                        {
                                            SplitterNCR objSplitterCITIZEN = new SplitterNCR(Connectionstring, EMekKey1, EMekKey2);

                                            _DataTableMCCounter = objSplitterCITIZEN.ASP_SplitDataMachineCounter2(path, sFileName, dt, out InsertMachineCount, file.UserName, file.ClientID);

                                            if (_DataTableMCCounter.Rows.Count > 0)
                                            {
                                                objIImportLogs.BulkInsertEJMachineCounterData(_DataTableMCCounter);
                                            }

                                            _DataTableSWCounter = objSplitterCITIZEN.ASP_SplitDataSwitchCounter(path, sFileName, dt, out InsertMachineCount, file.UserName, file.ClientID);

                                            if (_DataTableSWCounter.Rows.Count > 0)
                                            {
                                                objIImportLogs.BulkInsertEJSwitchCounterData(_DataTableSWCounter);
                                            }

                                            objSplitterCITIZEN = null;
                                        }
                                        else if (dt.Rows[0][7].ToString() == "56")
                                        {
                                            SplitterESAF objSplitterESAF = new SplitterESAF(Connectionstring, EMekKey1, EMekKey2);

                                            _DataTableMCCounter = objSplitterESAF.ASP_SplitDataMachineCounter2(path, sFileName, dt, out InsertMachineCount, file.UserName, file.ClientID);

                                            if (_DataTableMCCounter.Rows.Count > 0)
                                            {
                                                objIImportLogs.BulkInsertEJMachineCounterData(_DataTableMCCounter);
                                            }

                                            _DataTableSWCounter = objSplitterESAF.ASP_SplitDataSwitchCounter(path, sFileName, dt, out InsertMachineCount, file.UserName, file.ClientID);

                                            if (_DataTableSWCounter.Rows.Count > 0)
                                            {
                                                objIImportLogs.BulkInsertEJSwitchCounterData(_DataTableSWCounter);
                                            }

                                            objSplitterESAF = null;
                                        }
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;
                                    break;
                                #endregion InsertDataEJ 
                            }


                            if (MSG == "Successful" && fileImportRequest.InsertCount > 0)
                            {
                                FileUploadStatus = 1;
                            }
                            else
                            {
                                FileUploadStatus = 0;
                            }


                            importFileStatus.MSG = MSG;

                            if (fileImportRequest.TotalCount >= fileImportRequest.InsertCount)
                            {
                                MSG = file.ImportFile.FileName + " <br/>" + MSG;
                                MSG += "<br/>" + fileImportRequest.InsertCount + " out of " + fileImportRequest.TotalCount;
                                MSG += "<br/>" + (fileImportRequest.TotalCount - fileImportRequest.InsertCount);
                            }
                            else
                            {
                                MSG = file.ImportFile.FileName + " <br/>" + MSG;
                                MSG += "<br/>" + fileImportRequest.InsertCount + " out of " + fileImportRequest.TotalCount;
                                MSG += "<br/>" + (fileImportRequest.InsertCount - fileImportRequest.TotalCount);
                            }
                            importFileStatus.Status = importFileStatus.Status + MSG;
                        }

                        FileUploadStatusModel fileUploadStatusModel = new FileUploadStatusModel();
                        fileUploadStatusModel.ClientID = Convert.ToString(dt.Rows[0]["ClientID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ClientID"]);
                        fileUploadStatusModel.ChannelID = Convert.ToString(dt.Rows[0]["ChannelID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ChannelID"]);
                        fileUploadStatusModel.ModeID = Convert.ToString(dt.Rows[0]["ModeID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ModeID"]);
                        fileUploadStatusModel.CreatedBy = file.UserName;
                        fileUploadStatusModel.ErrorMessage = importFileStatus.MSG;
                        fileUploadStatusModel.FileDate = FileDateTime;
                        fileUploadStatusModel.FileName = file.ImportFile.FileName;
                        fileUploadStatusModel.FilePath = path;
                        fileUploadStatusModel.FileFormatId = file.FileFormatId; 
                        fileUploadStatusModel.FileType = tempFiletype;
                        fileUploadStatusModel.TotalRowCount = fileImportRequest.TotalCount;
                        fileUploadStatusModel.InsertCount = fileImportRequest.InsertCount;
                        fileUploadStatusModel.StartTime = StartTime;
                        fileUploadStatusModel.UploadStatus = FileUploadStatus;
                        fileUploadStatusModel.FinalBatchDetails = string.Empty;

                        objCommon.UpdateFileUploadStatus(fileUploadStatusModel, FileImportID);
                    }
                    else
                    {
                        importFileStatus.MSG = importFileStatus.MSG + "Error :: File Name" + sFileName;
                        importFileStatus.Status = "" + sFileName + "<br/>" + importFileStatus.Status + " File _configuration not found<br/>0<br/>0";

                        FileUploadStatusModel fileUploadStatusModel = new FileUploadStatusModel();

                        fileUploadStatusModel.ClientID = Convert.ToString(dt.Rows[0]["ClientID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ClientID"]);
                        fileUploadStatusModel.ChannelID = Convert.ToString(dt.Rows[0]["ChannelID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ChannelID"]);
                        fileUploadStatusModel.ModeID = Convert.ToString(dt.Rows[0]["ModeID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ModeID"]);

                        fileUploadStatusModel.CreatedBy = file.UserName;
                        fileUploadStatusModel.ErrorMessage = " File _configuration not found";
                        fileUploadStatusModel.FileDate = FileDateTime;
                        fileUploadStatusModel.FileName = file.ImportFile.FileName;
                        fileUploadStatusModel.FilePath = path;
                        fileUploadStatusModel.FileFormatId = FileImportID;
                        fileUploadStatusModel.FileType = tempFiletype;
                        fileUploadStatusModel.TotalRowCount = 0;
                        fileUploadStatusModel.InsertCount = 0;
                        fileUploadStatusModel.StartTime = StartTime;
                        fileUploadStatusModel.UploadStatus = 2;
                        fileUploadStatusModel.FinalBatchDetails = fileImportRequest.FinalBatchDetails;

                        objCommon.UpdateFileUploadStatus(fileUploadStatusModel, FileImportID);
                    }


                    System.IO.File.Delete(path);
                }
            }
            catch (Exception ex)
            {
                importFileStatus.MSG = "Error";
                string s = file.ImportFile != null ? file.ImportFile.FileName : "No File";
                importFileStatus.Status = "" + s + "<br/>" + ex.Message + "<br/>0<br/>0";
            }

            return importFileStatus;
        }

         
        private string ExtractNumber(string original)
        {
            return new string(original.Where(c => Char.IsDigit(c)).ToArray());
        }
    }


}