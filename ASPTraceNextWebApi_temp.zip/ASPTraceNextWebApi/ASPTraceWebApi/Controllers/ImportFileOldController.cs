﻿using System;
using System.Data;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using NetworkNPCI;
using Utility;
using SWITCH;
using CBS;
using EJ;
using VISA;
using Master;
using BFS;
using System.Linq;
using ASPTrace.Models;
using DocumentFormat.OpenXml.Drawing;
using ASPTraceWebApi.ClassFiles;
using ImportData;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ImportFileOldController : ControllerBase
    {

        private IWebHostEnvironment Environment;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.IImportLogs objIImportLogs;
        private readonly ASPTrace.Contracts.ICommon objCommon;
        public ImportFileOldController(IWebHostEnvironment _environment, IConfiguration Configuration, ASPTrace.Contracts.IImportLogs __objIImportLogs, ASPTrace.Contracts.ICommon _Common)
        {
            Environment = _environment;
            _configuration = Configuration;
            objIImportLogs = __objIImportLogs;
            objCommon = _Common; ;
        }

        //[Route("[action]")]
        [HttpPost]
        public object Post([FromForm] ASPTrace.Models.ImportFileModel file)
        {
            ASPTrace.Models.ImportFileStatus importFileStatus = new ASPTrace.Models.ImportFileStatus();

            try
            {
                bool IsEncryption = System.Convert.ToBoolean(_configuration.GetValue<string>("AppSettings:IsEncryption"));
                string EMekKey1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
                string relativePath = _configuration["AppSettings:MekKey2Path"];
                string EMekKey2 = System.IO.File.ReadAllText(relativePath).Trim();

                int FileUploadStatus = 0;
                string Connectionstring = IsEncryption ? AesEncryption.DecryptWithTwoMeks(_configuration.GetConnectionString("TraceConnection"), EMekKey1, EMekKey2) : _configuration.GetConnectionString("TraceConnection");
                              

                string MSG = string.Empty;
                string FileImportID = string.Empty;
                DateTime? FileDateTime = null;
                DateTime? MainFileDate = DateTime.Now;
                DateTime? StartTime = null; 
                string tempFiletype = string.Empty;

                if (file.ImportFile == null)
                {
                    importFileStatus.MSG = "Error";
                    importFileStatus.Status = "File not selected";
                }
                else
                {
                    Guid objGuid = Guid.NewGuid();

                    string sFileName = "Trace_"+ DateTime.Now.ToString("yyyyMMdd_HHmmss") + objGuid.ToString().Replace("-", "") + file.ImportFile.FileName;

                    string sFileExt1 = System.IO.Path.GetExtension(sFileName);

                    string path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\Switch\\", sFileName);

                    using (System.IO.Stream stream = new System.IO.FileStream(path, System.IO.FileMode.Create))
                    {
                        file.ImportFile.CopyTo(stream);
                    }

                    DataTable dt = objIImportLogs.GetFileTypeFormatById(file.ClientID, file.FileFormatId);
                    bool Invalid = true;
                    bool isDynamic = false;
                    int InsertCount = 0;
                    int TotalRowCount = 0;

                    FileUploadStatusModel objInsert = new FileUploadStatusModel();
                    objInsert.ClientID = Convert.ToString(dt.Rows[0]["ClientID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ClientID"]);
                    objInsert.ChannelID = Convert.ToString(dt.Rows[0]["ChannelID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ChannelID"]);
                    objInsert.ModeID = Convert.ToString(dt.Rows[0]["ModeID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ModeID"]);
                    objInsert.FileFormatId = file.FileFormatId;
                    objInsert.FileName = file.ImportFile.FileName;
                    objInsert.FilePath = path;
                    objInsert.FileDate = FileDateTime;
                    objInsert.CreatedBy = file.UserName;

                    FileImportID = objCommon.InsertFileUploadDetail(objInsert);

                    DataTable _DataTable = new DataTable();
                    List<BatchDetails> GetFailedBatch = new List<BatchDetails>();

                    DataTable _DataTableMCCounter = new DataTable();

                    DataTable _DataTableSWCounter = new DataTable();

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        StartTime = DateTime.Now;

                        DataTable dt1 = objIImportLogs.GetFileNameNotContain(file.ClientID, file.FileFormatId);

                        if (dt1 != null && dt1.Rows.Count > 0)
                        {
                            string FileNameContain = dt1.Rows[0]["FileNameNotContain"].ToString();
                            string VendorType2 = dt1.Rows[0]["VendorType"].ToString();

                            string Dyn = dt.Rows[0]["ReservedField1"].ToString();

                            if (Dyn.Contains("Dynamic")) isDynamic = true;

                            if (VendorType2 == "NETWORK")
                            {
                                if (FileNameContain == "")
                                {
                                    Invalid = true;
                                }
                                else
                                {

                                    {
                                        if (!sFileName.Contains(dt1.Rows[0]["FileNameNotContain"].ToString()))
                                        {
                                            importFileStatus.MSG = "Error";
                                            importFileStatus.Status = "Invalid bank file upload";
                                            Invalid = false;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                Invalid = true;
                            }
                        }
                        else
                        {
                            Invalid = false;
                        }

                        if (Invalid)
                        {

                            int count = 0;
                            int errorCount = 0;
                            int InsertMachineCount = 0;
                            int TotalCount = 1;
                            int FinalInsertCount = 0;
                            int FinalTotalRowCount = 0;
                            string sTerminalId = string.Empty;
                            string BOBSplitter = string.Empty;
                            DataSet _Dataset = new DataSet();

                            tempFiletype = file.FileFormatText;

                            switch (file.FileFormatText)
                            {

                                #region InsertDataNPCIAcquirerATM

                                case "ATM_ACQUIRER_NPCI":
                                case "ATM_ATM_ACQUIRER_NPCI":
                                    //case "ATM_ATM_ISSUER_NPCI":

                                    //Clear();
                                    string NPCIextension = System.IO.Path.GetExtension(sFileName);
                                    string[] filePaths = path.Split('\\'); ;
                                    if (NPCIextension == ".zip")
                                    {
                                        //path = UnPasswordzipfiles(path, sFileName);
                                        filePaths = System.IO.Directory.GetFiles(path);
                                        foreach (string NPCIfile in filePaths)
                                        {
                                            if (NPCIfile.Contains("ACQ"))
                                            {
                                                path = NPCIfile;
                                                break;
                                            }
                                        }
                                        string[] extension1 = path.Split('\\');
                                        sFileName = Convert.ToString(extension1[extension1.Length - 1]);
                                    }


                                    Splitter objSplitterNPCIAcquirerATM = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = objSplitterNPCIAcquirerATM.SplitterNPCIAcquirerATM(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.AcquirerDataNPCIATM(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;

                                    break;
                                #endregion InsertDataNPCIAcquirerATM

                                #region InsertDataNPCIIssuerATM

                                case "ATM_ATM_ISSUER_NPCI":

                                    //Clear();
                                    // string[] filePaths = Directory.GetFiles(path);
                                    string NPCIextension1 = System.IO.Path.GetExtension(sFileName);
                                    string[] filePaths1 = path.Split('\\'); ;
                                    if (NPCIextension1 == ".zip")
                                    {
                                        foreach (string NPCIfile in filePaths1)
                                        {
                                            if (NPCIfile.Contains("ISS"))
                                            {
                                                path = NPCIfile;
                                                break;
                                            }
                                        }
                                        string[] extension1 = path.Split('\\');
                                        sFileName = Convert.ToString(extension1[extension1.Length - 1]);
                                    }
                                    //SplitterNPCIIssuerATM objSplitterNPCIIssuerATM = new SplitterNPCIIssuerATM(Environment, _configuration, objCommon);
                                    Splitter objSplitterNPCIIssuerATM = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = objSplitterNPCIIssuerATM.SplitterNPCIIssuerATM(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.IssuerDataNPCIATM(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;

                                    break;
                                #endregion InsertDataNPCIIssuerATM

                                #region InsertDataNPCIIssuerPOS

                                case "POS_POS_ISSUER_NPCI":

                                    //Clear();

                                    DataSet _DataSetNW = new DataSet();

                                    //SplitterNPCIIssuerPOS objSplitterNPCIIssuerPOS = new SplitterNPCIIssuerPOS(Environment, _configuration, objCommon);
                                    NPCIPOSECOM objSplitterNPCIIssuerPOS = new NPCIPOSECOM(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = objSplitterNPCIIssuerPOS.SplitterNPCIIssuerPOS(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.IssuerDataNPCIPOS(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;

                                    break;
                                #endregion InsertDataNPCIIssuerPOS

                                #region InsertDataEJ
                                case "EJ_ATM_Common":
                                    //Clear(); 

                                    if (dt.Rows[0][3].ToString() == "11")
                                    {
                                        SplitterNCR objSplitterNCR = new SplitterNCR(Connectionstring, EMekKey1, EMekKey2);
                                        //_DataTable = objSplitterNCR.ASP_SplitData1(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    }
                                    else if (dt.Rows[0][7].ToString() == "59")
                                    {
                                        if (sFileName.Contains("AD021001"))
                                        {
                                            SplitterPerto objSplitterPerto = new SplitterPerto(Connectionstring, EMekKey1, EMekKey2);
                                            //_DataTable = objSplitterPerto.ASP_SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        }
                                        else
                                        {
                                            SplitterInfinity objSplitterInfinity = new SplitterInfinity(Connectionstring, EMekKey1, EMekKey2);
                                            //_DataTable = objSplitterInfinity.ASP_SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        }
                                    }
                                    //else if (dt.Rows[0][7].ToString() == "72" || dt.Rows[0][7].ToString() == "62" || dt.Rows[0][7].ToString() == "20" || dt.Rows[0][7].ToString() == "8" || (dt.Rows[0][7].ToString() == "107" || dt.Rows[0][7].ToString() == "82"))
                                    //{
                                    //    SplitterCITIZEN objSplitterCITIZEN = new SplitterCITIZEN(Connectionstring, EMekKey1, EMekKey2);
                                    //    _DataTable = objSplitterCITIZEN.ASP_SplitData1(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    //    objSplitterCITIZEN = null;
                                    //}
                                    else if (dt.Rows[0][7].ToString() == "56")
                                    {
                                        SplitterESAF objSplitterBhutan = new SplitterESAF(Connectionstring, EMekKey1, EMekKey2);
                                        //_DataTable = objSplitterBhutan.ASP_SplitData1(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        objSplitterBhutan = null;
                                    }
                                    else if (dt.Rows[0][7].ToString() == "100")
                                    {
                                        SplitterCommon objSplitter = new SplitterCommon(Connectionstring, EMekKey1, EMekKey2);
                                        //_DataTable = objSplitter.SplitterSrilanka(path, sFileName, file.ImportFile.FileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        objSplitter = null;
                                    }
                                    else if (dt.Rows[0][7].ToString() == "28")
                                    {
                                        SplitterBhutan objSplitterBhutan = new SplitterBhutan(Connectionstring, EMekKey1, EMekKey2);
                                        //_DataTable = objSplitterBhutan.ASP_SplitDataMaster(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        objSplitterBhutan = null;
                                    }
                                    else if (dt.Rows[0][7].ToString() == "46")
                                    {
                                        SplitterBhutan objSplitterBhutan = new SplitterBhutan(Connectionstring, EMekKey1, EMekKey2);
                                        //_DataTable = objSplitterBhutan.BDB_SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        objSplitterBhutan = null;
                                    }
                                    else if (dt.Rows[0][7].ToString() == "71")
                                    {
                                        SplitterBhutan objSplitterBhutan = new SplitterBhutan(Connectionstring, EMekKey1, EMekKey2);

                                        sTerminalId = sFileName.Substring(6, 8);

                                        DataTable TerminalTable = Utility.Common.GetBOBInfoByTerminalId(Connectionstring, file.ClientID, sTerminalId);

                                        if (TerminalTable != null && TerminalTable.Rows.Count > 0)
                                        {
                                            BOBSplitter = Convert.ToString(TerminalTable.Rows[0]["Splitter"]);
                                        }


                                        if (BOBSplitter == "1")
                                        {
                                            _DataTable = objSplitterBhutan.ATMEJFileSpliter1(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                        }
                                        else if (BOBSplitter == "2")
                                        {

                                            _DataTable = objSplitterBhutan.ATMEJFileSpliter2(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                        }
                                        else
                                        {
                                            _DataTable = objSplitterBhutan.ATMEJFileSpliter3(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                        }
                                    }
                                    else if (dt.Rows[0][7].ToString() == "108")
                                    {
                                        if (sFileName != null)
                                        {
                                            string afterUnderscore = sFileName.Substring(sFileName.LastIndexOf('_') + 1);
                                            string datePart = new string(afterUnderscore.Where(char.IsDigit).ToArray());
                                            if (datePart.Length == 8)
                                            {
                                                MainFileDate = DateTime.ParseExact(datePart, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                                            }
                                            else
                                            {
                                                MainFileDate = DateTime.Now;
                                            }
                                        }
                                        else
                                        {
                                            MainFileDate = DateTime.Now;
                                        }

                                        SplitterCommon NagpurEjspliter = new SplitterCommon(Connectionstring, EMekKey1, EMekKey2);
                                        //_Dataset = NagpurEjspliter.SplitterNagpur(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        NagpurEjspliter = null;

                                        if (_Dataset != null && _Dataset.Tables.Count > 0)
                                        {
                                            if (_Dataset.Tables[0].Rows.Count > 0)
                                            {
                                                MSG = objIImportLogs.BulkInsertEJData(_Dataset.Tables[0], FileImportID);
                                            }
                                            if (_Dataset.Tables[1].Rows.Count > 0)
                                            {
                                                //objIImportLogs.BulkInsertEJMachineCounterData(_Dataset.Tables[1]);
                                            }
                                            if (_Dataset.Tables[2].Rows.Count > 0)
                                            {
                                                // objIImportLogs.BulkInsertEJSwitchCounterData(_Dataset.Tables[2]);
                                            }
                                        }
                                        break;
                                    }

                                    else
                                    {
                                        if ((dt.Rows[0][3].ToString() == "11") || (dt.Rows[0][3].ToString() == "18") || (dt.Rows[0][3].ToString() == "24"))
                                        {
                                            SplitterNCR objSplitterNCR = new SplitterNCR(Connectionstring, EMekKey1, EMekKey2);
                                            //_DataTable = objSplitterNCR.ASP_SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        }
                                        else if (dt.Rows[0][3].ToString() == "13")
                                        {
                                            SplitterDIEBOLD objSplitterDIEBOLD = new SplitterDIEBOLD(Connectionstring, EMekKey1, EMekKey2);
                                            //_DataTable = objSplitterDIEBOLD.ASP_SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        }
                                        else if (dt.Rows[0][3].ToString() == "2")
                                        {
                                            SplitterCommon objSplitterCommon = new SplitterCommon(Connectionstring, EMekKey1, EMekKey2);
                                            //_DataTable = objSplitterCommon.ASP_SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        }
                                    }
                                    // string char = dt.Rows[0][3].ToString();
                                    //FinalInsertCount += InsertCount;
                                    //FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertEJData(_DataTable, FileImportID);

                                        if (dt.Rows[0][7].ToString() == "72" || dt.Rows[0][7].ToString() == "62")
                                        {
                                            SplitterNCR objSplitterCITIZEN = new SplitterNCR(Connectionstring, EMekKey1, EMekKey2);

                                            _DataTableMCCounter = objSplitterCITIZEN.ASP_SplitDataMachineCounter2(path, sFileName, dt, out InsertMachineCount, file.UserName, file.ClientID);

                                            if (_DataTableMCCounter.Rows.Count > 0)
                                            {
                                                objIImportLogs.BulkInsertEJMachineCounterData(_DataTableMCCounter);
                                            }

                                            _DataTableSWCounter = objSplitterCITIZEN.ASP_SplitDataSwitchCounter(path, sFileName, dt, out InsertMachineCount, file.UserName, file.ClientID);

                                            if (_DataTableSWCounter.Rows.Count > 0)
                                            {
                                                objIImportLogs.BulkInsertEJSwitchCounterData(_DataTableSWCounter);
                                            }

                                            objSplitterCITIZEN = null;
                                        }
                                        else if (dt.Rows[0][7].ToString() == "56")
                                        {
                                            SplitterESAF objSplitterESAF = new SplitterESAF(Connectionstring, EMekKey1, EMekKey2);

                                            _DataTableMCCounter = objSplitterESAF.ASP_SplitDataMachineCounter2(path, sFileName, dt, out InsertMachineCount, file.UserName, file.ClientID);

                                            if (_DataTableMCCounter.Rows.Count > 0)
                                            {
                                                objIImportLogs.BulkInsertEJMachineCounterData(_DataTableMCCounter);
                                            }

                                            _DataTableSWCounter = objSplitterESAF.ASP_SplitDataSwitchCounter(path, sFileName, dt, out InsertMachineCount, file.UserName, file.ClientID);

                                            if (_DataTableSWCounter.Rows.Count > 0)
                                            {
                                                objIImportLogs.BulkInsertEJSwitchCounterData(_DataTableSWCounter);
                                            }

                                            objSplitterESAF = null;
                                        }
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;
                                    break;
                                #endregion InsertDataEJ

                                #region NPCISettlementFile
                                case "ATM_ATM_Common_NPCI":
                                    //Clear();

                                    Splitter objSplitterNPCISettlement = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = objSplitterNPCISettlement.SplitterSettlementIssuer(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.NPCISettlementDataTable(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;

                                    break;
                                #endregion NPCISettlementFile //Product // Prodc

                                #region IMPSSettlementFile
                                case "IMPS_IMPS_Common_NPCI":
                                    //Clear(); 
                                    Splitter objSplitterIMPSSettlement = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = objSplitterIMPSSettlement.SplitterSettlementIMPS(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.IMPSSettlementDataTable(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }
                                    _DataTable = null;
                                    break;
                                #endregion IMPSSettlementFile

                                #region InsertDataVISAIssuerALL

                                case "Common_ISSUER_VISA":

                                    //Clear();
                                    SplitterVISAIssuer objSplitterVISAIssuer = new SplitterVISAIssuer(Environment, _configuration, objCommon);
                                    _DataSetNW = objSplitterVISAIssuer.SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataSetNW.Tables[1].Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.IssuerDataVISA(_DataSetNW);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    break;
                                #endregion InsertDataVISAIssuerALL

                                #region Common_Common_BFS
                                case "Common_Common_BFS":
                                    //Clear(); 

                                    SplitterBFSCommon objSplitterBFSCommon = new SplitterBFSCommon(Environment, _configuration, objCommon);
                                    DataSet DSBFS = objSplitterBFSCommon.SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (DSBFS.Tables[0].Rows.Count > 0 || DSBFS.Tables[1].Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BFSDataCommon(DSBFS);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }
                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }

                                    DSBFS = null;

                                    break;
                                #endregion

                                #region PossettlementFiles
                                case "POS_POS_Common_NPCI":
                                    //POSSetFileSpliter _POSSetFileSpliter = new POSSetFileSpliter(Environment, _configuration, objCommon);
                                    NPCIPOSECOM _POSSetFileSpliter = new NPCIPOSECOM(Connectionstring, EMekKey1, EMekKey2);
                                    BulkImports bulkimports = new BulkImports(Connectionstring, EMekKey1, EMekKey2);
                                    
                                    _DataTable = _POSSetFileSpliter.SpliterPOSSummaryNPCI(path, sFileName, dt, file.UserName, file.ClientID, "", out InsertCount, out TotalRowCount);
                                    
                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        if (_DataTable.Rows[0][12].ToString() == "NPCIBillingSummary")
                                        {
                                            _DataTable.Columns.Remove("FirstSP");
                                            MSG = bulkimports.NPCIBillingSummarryDataTable(_DataTable);
                                        }
                                        else if (_DataTable.Rows[0][13].ToString() == "InterchangeSummaryReport")
                                        {
                                            _DataTable.Columns.Remove("FirstSP");
                                            MSG = bulkimports.InterchangeSummarryDataTable(_DataTable);
                                        }
                                        else if (_DataTable.Rows[0][13].ToString() == "NetSettlementReport")
                                        {
                                            _DataTable.Columns.Remove("FirstSP");
                                            MSG = bulkimports.NetSettlementDataTable(_DataTable);
                                        }
                                        else if (_DataTable.Rows[0][26].ToString() == "DSRSummaryReport")
                                        {
                                            _DataTable.Columns.Remove("FirstSP");
                                           
                                        }
                                        else if (_DataTable.Rows[0][41].ToString() == "Presentment")
                                        {
                                            _DataTable.Columns.Remove("FirstSP");
                                            MSG = bulkimports.PresentmentDataTable(_DataTable);
                                        }

                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;

                                    break;
                                #endregion possettlementFiles

                                #region BANKNEFTRTGS_Import(Bank Sponsor File)
                                case "IMPS_IMPS_Common_NPCI_old":

                                    // Bank Sponsor File

                                    if (dt.Rows[0]["FileName"].ToString().Contains("IMPS") && dt.Rows[0]["FileExtention"].ToString() == ".xls")
                                    {
                                        SplitterBankIssuerNEFTRTGSSpreadsheet _objneftrtgsFileSpliter = new SplitterBankIssuerNEFTRTGSSpreadsheet(Environment, _configuration, objCommon);
                                        _DataTable = _objneftrtgsFileSpliter.SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    }
                                    else
                                    {
                                        SplitterBankIssuerNEFTRTGSSpreadsheet _objneftrtgsFileSpliterwithseparatar = new SplitterBankIssuerNEFTRTGSSpreadsheet(Environment, _configuration, objCommon);
                                        _DataTable = _objneftrtgsFileSpliterwithseparatar.SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    }

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.NEFTRTGSImportdata(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;

                                    break;
                                #endregion BANKNEFTRTGS_Import

                                #region BankNEFTRTGSINWARD
                                case "IMPS_IMPS_INWARD_NPCI_OLD":

                                    SplitterNEFTRTGSwithseparaterINWARD _objneftrtgsFileSpliterwithseparatarinward = new SplitterNEFTRTGSwithseparaterINWARD(Environment, _configuration, objCommon);
                                    _DataTable = _objneftrtgsFileSpliterwithseparatarinward.SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.NEFTRTGSImportdataBankINWARD(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;



                                    break;
                                #endregion BankNEFTRTGSINWARD

                                #region PossRefundFiles
                                case "POS_POS_REFUND_NPCI":

                                    //RefundLog _refundFileSpliter = new RefundLog(Environment, _configuration, objCommon);
                                    NPCIPOSECOM _refundFileSpliter = new NPCIPOSECOM(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = _refundFileSpliter.ESAF_RefundLog(path, sFileName, file.UserName, file.ClientID, dt, out InsertCount, out TotalRowCount);

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        //MSG = objIImportLogs.RefundlogImportdata(_DataTable);
                                        MSG = objIImportLogs.BulkInsertRefundlogs(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;

                                    break;
                                #endregion PossRefundFiles                                

                                #region UPISettlementFile
                                case "UPI_UPI_Common_NPCI":
                                    //Clear();


                                    //ExpandExcel(string OldFileName)
                                    // SplitterMaximusEJ objSplitterMaximusEJ = new SplitterMaximusEJ();
                                    //SplitterSettlementUPI objSplitterUPISettlement = new SplitterSettlementUPI(Environment, _configuration, objCommon);
                                    Splitter objSplitterUPISettlement = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = objSplitterUPISettlement.SplitterSettlementUPI(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.UPISettlementDataTable(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;
                                    break;
                                #endregion UPISettlementFile

                                #region ATMAdjustmentFile
                                case "ATM_ATM_Adjustment_NPCI":

                                    Splitter _AdjFileSpliter = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = _AdjFileSpliter.SplitterAdjustment(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.AdjlogImportdata(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;

                                    break;
                                #endregion ATMAdjustmentFile


                                #region NPCI_UPI_DebitReversal
                                case "UPI_UPI_DRC_NPCI":
                                    //Clear();
                                    //if (FileName.StartsWith("Pending") || FileName.StartsWith("Success Reversal") || FileName.StartsWith("UnSuccess Reversal"))
                                    if (sFileName.ToUpper().Contains(".XLS") || sFileName.ToUpper().Contains(".XLSX") || sFileName.ToUpper().Contains(".CSV"))
                                    {
                                        //UPIDebitReversalNPCI UPIDebitReversalnpci = new UPIDebitReversalNPCI(Environment, _configuration, objCommon);
                                        Splitter UPIDebitReversalnpci = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                        DataTable _DataTableUPIDebitReversalnpci = UPIDebitReversalnpci.SplitDataUPIDebitReversal(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        FinalInsertCount += InsertCount;
                                        FinalTotalRowCount += TotalRowCount;
                                        if (_DataTableUPIDebitReversalnpci.Rows.Count > 0)
                                        {
                                            MSG = objIImportLogs.UPIDRCImportdata(_DataTableUPIDebitReversalnpci);
                                        }
                                        else
                                        {
                                            MSG = "Error occrued kindly check the log file for more details";
                                        }

                                        if (MSG == "Successful")
                                        {
                                            count++;
                                        }
                                        else
                                        {
                                            //if (count < 2)
                                            //{
                                            //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                            //}
                                            errorCount++;
                                        }
                                    }

                                    break;
                                #endregion NPCI_UPI_DebitReversal


                                #region NPCI_NFS_LateReversal
                                case "ATM_ATM_LateReversal_NPCI":
                                    //Clear();
                                    //if (FileName.StartsWith("Pending") || FileName.StartsWith("Success Reversal") || FileName.StartsWith("UnSuccess Reversal"))
                                    if (sFileName.ToUpper().Contains(".XLS") || sFileName.ToUpper().Contains(".XLSX"))
                                    {
                                        //ProcessBFSFileSpliterBFS _BFSFileSpliter = new ProcessBFSFileSpliterBFS(Environment, _configuration, objCommon);
                                        Splitter _BFSFileSpliter = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                        _DataTable = _BFSFileSpliter.ProcessBFSFileSpliter(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                        FinalInsertCount += InsertCount;
                                        FinalTotalRowCount += TotalRowCount;
                                        if (_DataTable.Rows.Count > 0)
                                        {
                                            MSG = objIImportLogs.BFSDataBFSTable(_DataTable);
                                        }
                                        else
                                        {
                                            MSG = "Error occrued kindly check the log file for more details";
                                        }

                                        if (MSG == "Successful")
                                        {
                                            count++;
                                        }
                                        else
                                        {
                                            //if (count < 2)
                                            //{
                                            //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                            //}
                                            errorCount++;
                                        }
                                    }
                                    _DataTable = null;
                                    break;
                                #endregion NPCI_BFS_LateReversal

                                #region C3RSPLITER
                                case "ATM_ATM_C3R_NPCI":
                                    C3RSpliter _C3RSpliter = new C3RSpliter(Environment, _configuration, objCommon);
                                    _DataTable = _C3RSpliter.SplitData(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.C3Rimportdata(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;

                                case "CIT_ATM_C3R":

                                    C3RSpliter CIT_ATM_C3R = new C3RSpliter(Environment, _configuration, objCommon);

                                    if (dt.Rows[0][7].ToString() == "72")
                                    {
                                        _DataTable = CIT_ATM_C3R.SplitData_FIS_SWAP(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    }
                                    else
                                    {
                                        _DataTable = CIT_ATM_C3R.SplitData_INDUSIND_CMS(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    }

                                    DateTime? FileDate = null;

                                    string dateFile = ExtractNumber(sFileName).Substring(0, 8);
                                    try
                                    {
                                        FileDate = DateTime.ParseExact(dateFile, new string[] { "ddMMyyyy" }, System.Globalization.CultureInfo.InvariantCulture);
                                    }
                                    catch (Exception ex)
                                    {
                                        FileDate = DateTime.Now;
                                    }

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        if (dt.Rows[0][7].ToString() == "72")
                                        {
                                            MSG = objIImportLogs.BulkInsertSwapCBRDataNCR(_DataTable, FileDate, sFileName, path, file.UserName, file.ClientID);
                                        }
                                        else
                                        {
                                            MSG = objIImportLogs.BulkInsertCBRData(_DataTable, FileDate, sFileName, path, file.UserName);
                                        }
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;
                                    break;
                                #endregion C3RSPLITER

                                #region chargeback pos
                                case "ATM_ATM_ECOM-CashBack_NPCI":
                                    ChargebackFileSplitercs _chargebackFileSplitercs = new ChargebackFileSplitercs(Environment, _configuration, objCommon);

                                    //_DataTable = _chargebackFileSplitercs.chargebackFileSpliter(path, sFileName, Session["UserName"].ToString(), Session["BankCode"].ToString(), "", out InsertCount, out TotalRowCount);
                                    _DataTable = _chargebackFileSplitercs.ChargebackFileSpliter(path, sFileName, dt, file.UserName, file.ClientID, "", out InsertCount, out TotalRowCount);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.chargebackTable(_DataTable);
                                        //MSG = mRepo.chargebackTable(_DataTable, "", Session["BankCode"].ToString(), sFileName, Session["UserName"].ToString());
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }

                                    _DataTable = null;
                                    break;
                                #endregion chargeback pos

                                #region VISA and Master
                                case "VISA_VISA_VISAISSUER_VISA":

                                    DataSet dsXML = new DataSet();
                                    dsXML.ReadXml(System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\VISA.xml"));
                                    VISA_Splitter _IssuerFileSplitvisa = new VISA_Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    DataSet dsVISA = _IssuerFileSplitvisa.SplitDataISSUER(path, sFileName, dsXML, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (dsVISA.Tables[0].Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.IssuerDataVISA(dsVISA);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }

                                    dsVISA = null;

                                    break;

                                case "VISA_VISA_VISAACQUIRER_VISA":


                                    VISA_Splitter _AcquirerFileSplitVisa = new VISA_Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = _AcquirerFileSplitVisa.SplitDataAcquirer(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.AcquirerDataVISA(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;

                                case "MASTER_MASTER_Common_MASTER":

                                    Master_Splitter _MASTERFileSpliter = new Master_Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = _MASTERFileSpliter.SpliterAcquirerExcel(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {

                                        MSG = objIImportLogs.AcquirerDataMASTER(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }



                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;
                                    break;

                                case "MASTER_MASTER_ACQUIRER_MASTER":

                                    Master_Splitter _MASTERAcquirerFileSpliter = new Master_Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = _MASTERAcquirerFileSpliter.SpliterAcquirerExcel(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {

                                        MSG = objIImportLogs.AcquirerDataMASTER(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }



                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }
                                    _DataTable = null;
                                    break;

                                case "ATM_ATM_Common_RMA":
                                    //Clear();
                                    BFS_Splitter objSplitterBFS = new BFS_Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    DataSet DSBFSAcquirerIssuer = objSplitterBFS.SplitterBFSCommon(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (DSBFSAcquirerIssuer.Tables[0].Rows.Count > 0 || DSBFSAcquirerIssuer.Tables[1].Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BFSDataCommon(DSBFSAcquirerIssuer);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }
                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        //if (count < 2)
                                        //{
                                        //    ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + MSG + "');", true);
                                        //}
                                        errorCount++;
                                    }

                                    break;
                                #endregion

                                #region IMPSAdjustmentNPCI
                                case "IMPS_IMPS_Adjustment_NPCI":

                                    //IMPSAdjSplitter _impsAdjustmentFileSpliter = new IMPSAdjSplitter(Environment, _configuration, objCommon);
                                    Splitter _impsAdjustmentFileSpliter = new Splitter(Connectionstring, EMekKey1, EMekKey2); 
                                    _DataTable = _impsAdjustmentFileSpliter.SplitterIMPSAdjustment(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.impsAdjustmentimportlogImportdata(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion IMPSAdjustmentNPCI

                                #region AEPSACQUIRERNPCI
                                case "AEPS_AEPS_ACQUIRER_NPCI":

                                    if (sFileName.Contains("ACQR"))
                                    {
                                        Splitter _aepsacquirerFileSpliter = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                        _DataTable = _aepsacquirerFileSpliter.SplitterNPCIAEPSACQUIRER(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);


                                        FinalInsertCount += InsertCount;
                                        FinalTotalRowCount += TotalRowCount;

                                        if (_DataTable.Rows.Count > 0)
                                        {
                                            MSG = objIImportLogs.BulkInsertAEPSAcquirerData(_DataTable);
                                        }
                                        else
                                        {
                                            MSG = "Error occrued kindly check the log file for more details";
                                        }

                                        if (MSG == "Successful")
                                        {
                                            count++;
                                        }
                                        else
                                        {
                                            errorCount++;
                                        }
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion AEPSACQUIRERNPCI 

                                #region AEPSISSUERNPCI
                                case "AEPS_AEPS_ISSUER_NPCI":

                                    if (sFileName.Contains("ISSR"))
                                    {
                                        Splitter _aepsacquirerFileSpliter = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                        _DataTable = _aepsacquirerFileSpliter.SplitterNPCIAEPSISSUER(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);


                                        FinalInsertCount += InsertCount;
                                        FinalTotalRowCount += TotalRowCount;

                                        if (_DataTable.Rows.Count > 0)
                                        {
                                            MSG = objIImportLogs.BulkInsertAEPSIssuerData(_DataTable);
                                        }
                                        else
                                        {
                                            MSG = "Error occrued kindly check the log file for more details";
                                        }

                                        if (MSG == "Successful")
                                        {
                                            count++;
                                        }
                                        else
                                        {
                                            errorCount++;
                                        }
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion AEPSISSUERNPCI

                                #region AEPSNTSLNPCI
                                case "AEPS_AEPS_Common_NPCI":

                                    Splitter objSplitterAEPSSettlement = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = objSplitterAEPSSettlement.SplitterNPCIAEPSSettlement(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);


                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertAEPSSettlement(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion AEPSNTSLNPCI

                                #region AEPSAdjustmentNPCI
                                case "AEPS_AEPS_Adjustment_NPCI":

                                    Splitter _AEPSAdjustmentSplitter = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = _AEPSAdjustmentSplitter.SplitterNPCIAEPSAdjustment(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);


                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertAEPSAdjustment(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion AEPSAdjustmentNPCI

                                #region SWITCH_Mobiware
                                case "SWITCH_BBPS_MOBIWARE":
                                    PayrakkamSplitter sWITCH_Splitter3 = new PayrakkamSplitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = sWITCH_Splitter3.SwitchFileMobiware_TLFSpliter(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BBPSPaySWDataTableDynamic(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }
                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }
                                    _DataTable = null;

                                    break;
                                #endregion SWITCH_Mobiware

                                #region Payrakkam GL File CycleWise(AEPS/MATM/IMPS)
                                case "GL CycleWise_GL CycleWise_Common_NPCI":
                                    PayrakkamSplitter _payrakkamCycle = new PayrakkamSplitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = _payrakkamCycle.GLFilesSProcessCycleWise(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);
                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertGLFilesDataCycleWise(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }
                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }
                                    _DataTable = null;
                                    break;
                                #endregion Payrakkam GL File CycleWise(AEPS/MATM/IMPS)

                                #region FranchiseESAFPAYRAKKAM
                                case "Franchise Ledger_Franchise Ledger_Common_NPCI":
                                    PayrakkamSplitter franchise_Ledger_File = new PayrakkamSplitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = franchise_Ledger_File.PayrakkamFranchiseLedger(path, sFileName, file.UserName, file.ClientID, out InsertCount, out TotalRowCount);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertPayrakkamFranchiseLedger(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                case "Franchise Ledger CycleWise_Franchise Ledger CycleWise_Common_NPCI":
                                    PayrakkamSplitter franchise_Ledger_File1 = new PayrakkamSplitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = franchise_Ledger_File1.PayrakkamFranchiseLedgerCycleWise(path, sFileName, file.UserName, file.ClientID, out InsertCount, out TotalRowCount);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertPayrakkamFranchiseLedgerCycleWise(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion

                                #region BBPSNPCI
                                case "BBPS_BBPS_Common_NPCI":

                                    //IMPSAdjSplitter _impsAdjustmentFileSpliter = new IMPSAdjSplitter(Environment, _configuration, objCommon);
                                    PayrakkamSplitter npcibbps = new PayrakkamSplitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = npcibbps.PayrakamBBPSNetwork(path, sFileName, file.UserName, file.ClientID, out InsertCount, out TotalRowCount);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertPayrakkamBBPSNetworkXML(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion BBPSNPCI

                                #region BBPSSettlementNPCI
                                case "BBPS_BBPS_Settlement_NPCI":

                                    //IMPSAdjSplitter _impsAdjustmentFileSpliter = new IMPSAdjSplitter(Environment, _configuration, objCommon);
                                    BBPSSettlement bbpsSettlement = new BBPSSettlement(Connectionstring, EMekKey1, EMekKey2);

                                    _DataTable = bbpsSettlement.BBPSSettlementSplitter(path, sFileName, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertPayrakkamBBPSSettlementCSV(_DataTable);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion BBPSSettlementNPCI

                                #region AdjustmentAllESAFPAYRAKKAM
                                case "Common_Common_Adjustment_NPCI":
                                    PayrakkamSplitter adjAllPAYRAKKAM = new PayrakkamSplitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = adjAllPAYRAKKAM.AdjustmentFilesSpliter(path, sFileName, file.UserName, file.ClientID, out InsertCount, out TotalRowCount);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        if (sFileName.Contains("IMPS"))
                                        {
                                            MSG = objIImportLogs.BulkInsertPayrakkamIMPSAdjData(_DataTable);
                                        }
                                        else if (sFileName.Contains("EBU"))
                                        {
                                            MSG = objIImportLogs.BulkInsertPayrakamAdjustmentData(_DataTable);
                                        }
                                        else
                                        {
                                            MSG = objIImportLogs.BulkInsertPayrakkamMATMAdjustmentData(_DataTable);
                                        }
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion

                                #region TimeOut
                                case "Common_Common_IMPS_UPI_TimeOut_NPCI":
                                    ESAF_Splitter TimeOut = new ESAF_Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = TimeOut.Splitter_TIMEOUT_IMPS(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertTimeout(_DataTable, file.ClientID, path, sFileName, file.UserName);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion

                                #region DebitReversal
                                case "Common_Common_DebitReversal_NPCI":
                                    ESAF_Splitter DebitReversal = new ESAF_Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = DebitReversal.Splitter_DebitReversal(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertDebitReversal(_DataTable, file.ClientID, path, sFileName, file.UserName);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                #endregion

                                #region GLAdjustment
                                case "Common_Common_GLAdjustment_NPCI":
                                    Splitter GL_ADJ = new Splitter(Connectionstring, EMekKey1, EMekKey2);
                                    _DataTable = GL_ADJ.Splitter_GL_Adjustment_Delimiter_Dynamic_old(path, sFileName, dt, out InsertCount, out TotalRowCount, file.UserName, file.ClientID);

                                    FinalInsertCount += InsertCount;
                                    FinalTotalRowCount += TotalRowCount;
                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        MSG = objIImportLogs.BulkInsertGLAdjustmentALL(_DataTable, path, sFileName, file.UserName);
                                    }
                                    else
                                    {
                                        MSG = "Error occrued kindly check the log file for more details";
                                    }

                                    if (MSG == "Successful")
                                    {
                                        count++;
                                    }
                                    else
                                    {
                                        errorCount++;
                                    }

                                    _DataTable = null;

                                    break;
                                    #endregion

                            }


                            if (MSG == "Successful" && InsertCount > 0)
                            {
                                FileUploadStatus = 1;
                            }
                            else
                            {
                                FileUploadStatus = 0;
                            }


                            importFileStatus.MSG = MSG;

                            //MSG = string.Empty;

                            //if (count != TotalCount || InsertCount != TotalRowCount)
                            //{
                            //    MSG += "" + sFileName + " <br/>Error occrued kindly check the log file for more details."; 
                            //    MSG += "<br/>" + FinalInsertCount + " out of " + FinalTotalRowCount;
                            //    MSG += "<br/>" + (FinalTotalRowCount - FinalInsertCount);
                            //}
                            //else
                            //{
                            //    MSG += "" + sFileName + " <br/>Successfully uploaded."; 
                            //    MSG += "<br/>" + FinalInsertCount + " out of " + FinalTotalRowCount;
                            //    MSG += "<br/>" + (FinalTotalRowCount - FinalInsertCount);

                            //}
                            if (TotalRowCount >= InsertCount)
                            {
                                MSG = file.ImportFile.FileName + " <br/>" + MSG;
                                MSG += "<br/>" + InsertCount + " out of " + TotalRowCount;
                                MSG += "<br/>" + (TotalRowCount - InsertCount);
                            }
                            else
                            {
                                MSG = file.ImportFile.FileName + " <br/>" + MSG;
                                MSG += "<br/>" + InsertCount + " out of " + TotalRowCount;
                                MSG += "<br/>" + (InsertCount - TotalRowCount);
                            }
                            importFileStatus.Status = importFileStatus.Status + MSG;
                        }
                    }
                    else
                    {
                        importFileStatus.MSG = importFileStatus.MSG + "Error :: File Name" + sFileName;
                        importFileStatus.Status = "" + sFileName + "<br/>" + importFileStatus.Status + " File _configuration not found<br/>0<br/>0";
                    }

                    FileUploadStatusModel fileUploadStatusModel = new FileUploadStatusModel();
                    fileUploadStatusModel.ClientID = Convert.ToString(dt.Rows[0]["ClientID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ClientID"]);
                    fileUploadStatusModel.ChannelID = Convert.ToString(dt.Rows[0]["ChannelID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ChannelID"]);
                    fileUploadStatusModel.ModeID = Convert.ToString(dt.Rows[0]["ModeID"]) == "" ? 0 : Convert.ToInt16(dt.Rows[0]["ModeID"]);
                    fileUploadStatusModel.CreatedBy = file.UserName;
                    fileUploadStatusModel.ErrorMessage = importFileStatus.MSG;
                    fileUploadStatusModel.FileDate = FileDateTime;
                    fileUploadStatusModel.FileName = file.ImportFile.FileName;
                    fileUploadStatusModel.FilePath = path;
                    fileUploadStatusModel.FileFormatId = file.FileFormatId;
                    fileUploadStatusModel.FileType = tempFiletype;
                    fileUploadStatusModel.TotalRowCount = TotalRowCount;
                    fileUploadStatusModel.InsertCount = InsertCount;
                    fileUploadStatusModel.StartTime = StartTime;
                    fileUploadStatusModel.UploadStatus = FileUploadStatus;
                    fileUploadStatusModel.FinalBatchDetails = string.Empty;

                    objCommon.UpdateFileUploadStatus(fileUploadStatusModel, FileImportID);

                    System.IO.File.Delete(path);
                }
            }
            catch (Exception ex)
            {
                importFileStatus.MSG = "Error";
                string s = file.ImportFile != null ? file.ImportFile.FileName : "No File";
                importFileStatus.Status = "" + s + "<br/>" + ex.Message + "<br/>0<br/>0";
            }

            return importFileStatus;
        }

        //public string UnPasswordzipfiles(string OldFilepath, string OldFileName)
        //{
        //    string NewFileName = "";
        //    try
        //    {
        //        NewFileName = OldFilepath.Replace(OldFileName, "");
        //        string extension = System.IO.Path.GetExtension(OldFileName);
        //        string[] Date = OldFileName.Replace("NFSRawData", "").Split('_'); //   Split NFSRawDataSMU020919_1C

        //        string BankCode = System.Text.RegularExpressions.Regex.Replace(Convert.ToString(Date[0]), @"[\d-]", string.Empty); // remove integer from string
        //        string FileDate = System.Text.RegularExpressions.Regex.Replace(Convert.ToString(Date[0]), "[^0-9.]", ""); // remove alphabets from string
        //        string PasswordDate = "20" + FileDate.Substring(4, 2) + FileDate.Substring(2, 2) + FileDate.Substring(0, 2);
        //        //NewFileName = NewFileName + OldFileName.Replace(extension, "") + "_New" + extension;
        //        //Excel.Workbook openWorkBook = null;
        //        string xmlPathName = OldFilepath;
        //        ZipArchive oZip = new ZipArchive("TryIt");
        //        oZip.Load(OldFilepath);
        //        //oZip.Create(@"D:\Rupali\SVN_Live\Ankita\sachinSir\files\NFSRawDataSMU020919_1C.zip", true); //create a new zip file;
        //        string password = BankCode + PasswordDate;// "SMU20190902";
        //        //add a single file to zip file.
        //        //oZip.AddFile("c:\\temp\\test.gif", "", password);
        //        // oZip.AddDirectory(@"D:\Rupali\SVN_Live\Ankita\sachinSir\files\Unzip", password);
        //        oZip.ExtractAll(NewFileName, password);
        //    }
        //    catch (Exception)
        //    {
        //        NewFileName = OldFileName;
        //    }
        //    return NewFileName;
        //}

        private string ExtractNumber(string original)
        {
            return new string(original.Where(c => Char.IsDigit(c)).ToArray());
        }
    }


}