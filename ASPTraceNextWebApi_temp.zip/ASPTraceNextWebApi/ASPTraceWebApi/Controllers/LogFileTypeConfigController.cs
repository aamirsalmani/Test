﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTraceWebApi.Controllers

{ 

    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class LogFileTypeConfigController : ControllerBase
    {
        private readonly ILogFileTypeConfig _objLogFileTypeConfig;
        public LogFileTypeConfigController(ILogFileTypeConfig objLogFileTypeConfig)
        {
            _objLogFileTypeConfig = objLogFileTypeConfig;
        }


        [Route("[action]")]
        [HttpPost]
        public object LogFileTypeConfigData(GetLogFileTypeConfigModel getLogFileTypeConfigModel)
        {

            return _objLogFileTypeConfig.GetLogFileTypeConfigData(getLogFileTypeConfigModel);
        }  

        [Route("[action]")]
        [HttpPost]
        public object AddNewLogfileTypeconfigData(LogfileTypeConfigModel addNewLogfileTypeConfigModel)
        {
            return _objLogFileTypeConfig.AddNewLogfileTypeconfigData(addNewLogfileTypeConfigModel);
        }



        [Route("[action]")]
        [HttpPost]
        public object EditLogfileTypeconfigData(LogfileTypeConfigModel editLogfileTypeConfigModel)
        {
            return _objLogFileTypeConfig.EditLogfileTypeconfigData(editLogfileTypeConfigModel);
        }


        [Route("[action]")]
        [HttpPost]
        public object DeleteLogFileTypeConfiglist(DeleteLogFileTypeConfigModel deleteLogFileTypeConfigModel)
        {
            return _objLogFileTypeConfig.DeleteLogFileTypeConfigData(deleteLogFileTypeConfigModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetLogTypeConfigurationDetails(int ID)
        {
            return _objLogFileTypeConfig.GetLogTypeConfigurationDetails(ID);
        }
    }
}
