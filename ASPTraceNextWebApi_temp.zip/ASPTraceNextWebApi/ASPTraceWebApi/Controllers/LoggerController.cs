﻿using Microsoft.AspNetCore.Authorization; 
using Microsoft.AspNetCore.Mvc; 
using ASPTrace.Contracts;
using ASPTrace.Models;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class LoggerController : ControllerBase
    {
        private readonly ILogging _objLogger;

        public LoggerController(ILogging objLogger)
        {
            _objLogger = objLogger;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetUserLoginReport(UserLoginReportModel userLoginReportModel)
        {
            return _objLogger.GetUserLoginReport(userLoginReportModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetUserList()
        {
            return _objLogger.GetUserList();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetMenuList()
        {
            return _objLogger.GetMenuList();
        }

        [Route("[action]")]
        [HttpPost]
        public object EnableMenuItem(MenuEnableModel menuEnableModel)
        {
            return _objLogger.EnableMenuItem(menuEnableModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetDbExceptionList(DbExceptionModel dbExceptionModel)
        {
            return _objLogger.GetDbExceptionList(dbExceptionModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetErrorLogList(ErrorLogModel errorLogModel)
        {
            return _objLogger.GetErrorLogList(errorLogModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetUserActivityReport(UserLoginReportModel userLoginReportModel)
        {
            return _objLogger.GetUserActivityReport(userLoginReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object  InsertUserActivityReport(UserActivityReportInsertModel userLoginReportModel)
        {
            return _objLogger.InsertUserActivityReport(userLoginReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object UserAudit(UserAuditReportModel usermodel)
        {
            return _objLogger.GetUserAddedModifiedDetails(usermodel);
        }
    }
}
