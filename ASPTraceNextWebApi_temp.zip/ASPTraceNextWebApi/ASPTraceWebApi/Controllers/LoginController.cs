﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using SkiaSharp;
using Microsoft.Extensions.Configuration;
using System.Security.Cryptography;
using DocumentFormat.OpenXml.InkML;
using System.Text;
using DocumentFormat.OpenXml.Drawing;
using ASPTraceWebApi.ClassFiles;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ASPTraceWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : Controller
    {
        private readonly ILogin _objlogin;
        private IConfiguration _configuration;
        private readonly ICommon _Common;
        private readonly SessionSettings _settings;

        private readonly string _privateKey = @"-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDWhIrqPbylJrR5
oAsPpejBJdgJqqL4A67np+p4GCJZUMvUQ2NxUhTrEv9SeFE5dSwzIDOvK2Z5/vuE
NAEi+xW/sLJKl38vszpPYQbHaRlk2KnRi1aWyvVyOJ0qxPOwjp0gPSEtRafhvDYs
TFUJ2d5AtmMNc9F9UOHIiIMWaLXqHA13tOSzrHBvDXVT5Gsx169mcEicFWPgspuO
AIW8fcfnPQK7/cCYMe65X851VNC+EX6CNU2BsDtM8dQzdI1W9eZVcAcLUnt1T6dT
F5jC4p6FUBSBhDK53oQMlRVlzLoXZpBL8DBTDK3VY57PB7joC3eFs8RTSCfEVduW
lpwaUuF/AgMBAAECggEBAJUtcQk6S6CxzNmzwV1ta/I9pgH65wAAV7aDYBuJ9QEV
ndmLz3CzuxZKjMHGJ/4EDOu03hxX2xjFiBVEsPGpmFNIxoP23JzIT6l5+OPdo6os
vdOZyWpt08hNtIZUln7WflA4EoVQJlJlt2qQ3qZOGy/3ZeSqASnbgFgbDsYbpT4a
Y/pwQzKLXm4JGsxfGgofax4QWSMcvKLSASginEaQfKNhI/DG5e4UVV7z1saEOQmb
SPCkmgSLzH4XEvV2hIMHThqRQXFKeFkyzD7x9ueSzmsx/JplEJQoQiA6HBHrlQko
a3pqhExogHgTRhplvpdxdsKWAv4/bzukmNfPXeJGRskCgYEA8LQcfUraQWAQnHh9
KI18k9Ypo/lJCiiuVaaszCD9fcrKJb2EDpdRBDUbGCU6GdIfNLoCBbsF3mPw2I6r
xeneB/xtKolinDSnr0vrHHPfc/qZ+Hhn2K726Cwwtc7qhpzoskFCaCMLkwlkz4tH
qoXQ/Y2tdn4mPH5c6eYcyto/hW0CgYEA5CZtVu4PuZ6HsR5wRgLSa2FMIrFQRoLB
2c6c8RqBY6oEoCZhWMaTupE/ldO/P3mEtNsavylPBGbkNMt46M47JK4otCxx6+pX
vLOVlSfeSjScJfnKBCZpo0y0oQozBTemrA/BuW6JAA5fzhHu0Zgf0+SYp5qTyVcE
BiC0YhWAqxsCgYBJik3V/eOW67nHhIyAslGofVs1jPlC0FELPCQ5La8lGqsOQsux
BYwsI+mGRAFvWCJOorHxfEV7v78a+uQCUMSUXgwgXd8x6Gh/B0vq4oAX2C3omyjn
K/Wl07KCKZi/zfrOU1/tnx9vKgSR4HTh5YaHoRypQjt+agELOVH8rBeSNQKBgQCC
DyXlmHB+cFEKNz/pqVIqxJySamJIz+GSOKZfC60XE6TvZvG3mfw9LvAAiWVM2gk8
0Gq+7t2MtNsC/bs/e9FbZ6zsiSmoQz8g438yODgQNU2OmIcBNqSh4uhVpWrQXpk1
HQZinxCaZ5dV8gMimIYMVRRw9z2oWWKB28L45ykiYQKBgE57knB9XZU+tsGFTlrZ
B5MXHSTL0PE9Ct5kWe/IREXcd8Om5vmYI7i2f3w9bYYKKLBCJQzWU0p7NumlJQR2
ZiFl4pn2Q8uDFlpvDf7qKmN2Z5huQ5K16ZKms8/dU9LGAW8WhNLu3DNREtYZ9i9h
CYafrfL5bdqir+Ahi6AmUx1K
-----END PRIVATE KEY-----";

        public LoginController(ILogin objlogin, IConfiguration objConfiguration, ICommon objCommon, Microsoft.Extensions.Options.IOptions<SessionSettings> Settings)
        {
            _objlogin = objlogin;
            _configuration = objConfiguration;
            _Common = objCommon;
            _settings = Settings.Value;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetCaptchaCode(string UniqueId)
        {
            CAPTCHAModel obj = _objlogin.GetCAPTCHA(UniqueId);

            CaptchaImageModel captchaImageModel = new CaptchaImageModel();

            captchaImageModel.webtoken = obj.WEBTOKEN;

            byte[] imageByteArray = GenerateDifficultCaptchaImage(250, 50, obj.CAPTCHACODE);

            captchaImageModel.captchaimagebase64 = $"data:image/png;base64,{Convert.ToBase64String(imageByteArray)}";

            return captchaImageModel;
        }

        private byte[] GenerateDifficultCaptchaImage(int ImageWidth, int ImageHeight, string captchaCode)
        {            

            if (captchaCode != null)
            {

                using (var surface = SKSurface.Create(new SKImageInfo(ImageWidth, ImageHeight)))
                {
                    Random random = new Random();

                    var canvas = surface.Canvas;

                    // Clear the canvas with a random background color 
                    canvas.Clear(SKColors.White);

                    using (var paint = new SKPaint())
                    {
                        paint.Color = SKColors.Black;
                        paint.IsAntialias = true;
                        paint.TextSize = 30;
                        paint.FakeBoldText = true;

                        float x = 5;

                        // Draw each character with distortion
                        foreach (var character in captchaCode)
                        {
                            float y = 30 - random.Next(-10, 10);
                            float rotation = random.Next(-20, 20);
                            float scale = random.Next(80, 120) / 100f;

                            canvas.Save();
                            canvas.RotateDegrees(rotation, x, y);
                            canvas.Scale(scale, 1, x, y);

                            canvas.DrawText(character.ToString(), x, y, paint);

                            canvas.Restore();

                            x += 30 + random.Next(0, 10);
                        }


                    }

                    // Add noise to the image
                    AddNoise(canvas, ImageWidth, ImageHeight);

                    // Save the image to a memory stream
                    using (var image = surface.Snapshot())
                    using (var data = image.Encode(SKEncodedImageFormat.Png, 100))
                    using (var memoryStream = new System.IO.MemoryStream())
                    {
                        data.SaveTo(memoryStream);
                        return memoryStream.ToArray();
                    }
                }
            }
            else 
            {
                return null;
            }
        }

        private void AddNoise(SKCanvas canvas, int ImageWidth, int ImageHeight)
        {
            Random random = new Random();
            using (var paint = new SKPaint())
            {
                paint.Color = SKColors.LightSlateGray;
                paint.IsAntialias = true;
                paint.TextSize = 24;
                paint.Style = SKPaintStyle.Fill;

                var numNoiseDots = random.Next(100, 200);

                for (var i = 0; i < numNoiseDots; i++)
                {
                    var startXy = random.Next(0, ImageWidth);
                    var startYz = random.Next(0, ImageHeight);

                    canvas.DrawText(".", startXy, startYz, paint);
                }
            }

            using (var paintLine = new SKPaint())
            {
                paintLine.IsAntialias = true;
                paintLine.Color = SKColors.LightSlateGray;
                paintLine.Style = SKPaintStyle.Fill;
                paintLine.StrokeWidth = 1;

                var numNoiseLines = random.Next(5, 15);

                for (var i = 0; i < numNoiseLines; i++)
                {
                    var startX = random.Next(0, ImageWidth);
                    var startY = random.Next(0, ImageHeight);
                    var endX = random.Next(0, ImageWidth);
                    var endY = random.Next(0, ImageHeight);

                    canvas.DrawLine(startX, startY, endX, endY, paintLine);

                }
            }

        }

        private string DecryptAesKey(string encryptedAesKey)
        {
            try
            {
                using (RSA rsa = RSA.Create())
                {
                    rsa.ImportFromPem(_privateKey.ToCharArray());
                    byte[] decryptedBytes = rsa.Decrypt(
                        Convert.FromBase64String(encryptedAesKey),
                        RSAEncryptionPadding.Pkcs1
                    );
                    return Encoding.UTF8.GetString(decryptedBytes);
                }
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        private string DecryptPassword(string encryptedData, string aesKeyHex, string aesIvHex)
        {
            try
            {
                // Convert AES key and IV from hex string to byte array
                byte[] keyBytes = ConvertHexStringToByteArray(aesKeyHex);
                byte[] ivBytes = ConvertHexStringToByteArray(aesIvHex);

                // Convert encrypted data from Base64 to byte array
                byte[] encryptedBytes = Convert.FromBase64String(encryptedData);

                using (var aes = Aes.Create())
                {
                    aes.Key = keyBytes;
                    aes.IV = ivBytes;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;

                    using (var decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                    using (var memoryStream = new MemoryStream(encryptedBytes))
                    using (var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                    using (var reader = new StreamReader(cryptoStream))
                    {
                        return reader.ReadToEnd(); // Returns the decrypted password as a string
                    }
                }
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        // Helper method to convert hex string to byte array
        private static byte[] ConvertHexStringToByteArray(string hex)
        {
            byte[] bytes = new byte[hex.Length / 2];
            for (int i = 0; i < hex.Length; i += 2)
            {
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            }
            return bytes;
        }


        [AllowAnonymous]
        [Route("[action]")]
        [HttpPost]
        public IActionResult ValidateUser(LoginModel VerifyLoginModel)
        {
            string username = VerifyLoginModel.UserName == null ? "" : VerifyLoginModel.UserName;
            string WebToken = string.Empty; string UserAgent = string.Empty;

            if (String.IsNullOrEmpty(username))
            {
                return BadRequest(new { message = "Username or password is incorrect" });
            }
            else
            {
                WebToken = VerifyLoginModel.WebToken;
                UserAgent = VerifyLoginModel.UserAgent;

                // Step 1: Decrypt the AES key with the RSA private key
                string aesKey = DecryptAesKey(VerifyLoginModel.KeyToken);

                // Step 1: Decrypt the AES IV with the RSA private key
                string aesIV = DecryptAesKey(VerifyLoginModel.IVToken);

                // Step 2: Decrypt the password with the AES key
                string decryptedPassword = DecryptPassword(VerifyLoginModel.Password, aesKey, aesIV);

                if (String.IsNullOrEmpty(decryptedPassword))
                {
                    return BadRequest(new { message = "password key is incorrect" });
                }

                try
                {
                    string result = _objlogin.VERIFY_CAPTCHA(VerifyLoginModel.CAPTCHACODE, VerifyLoginModel.WebToken);

                    if (result == "Success")
                    {
                        UserClientModel userClientModel = _objlogin.GetClientCodeDetails(VerifyLoginModel.UserName);

                        int LoginAttemptCount = Convert.ToInt16(_settings.LoginAttemptCount);

                        if (userClientModel != null && userClientModel.ClientID != null)
                        {
                            int LoginFailedCount = Convert.ToInt16(userClientModel.IsCount);
                            int Locked = Convert.ToInt16(userClientModel.IsLocked);

                            if (LoginAttemptCount >= LoginFailedCount && Locked == 0)
                            { 
                                LoginModel loginModel = new LoginModel
                                {
                                    Password = Utility.AesEncryption.EncryptUsingSHA2Algorithm(decryptedPassword),
                                    UserName = VerifyLoginModel.UserName,
                                    ClientID = userClientModel.ClientID
                                };

                                LoginSuccessModel loginSuccessModel = _objlogin.ValidateUser(loginModel); 

                                VerifyLoginModel = null;
                                userClientModel = null;

                                if (loginSuccessModel != null && loginSuccessModel.UserID != null)
                                {

                                    var tokenString = Common.GenerateTokens(loginSuccessModel.UserID, _settings.Secret, _settings.SessionTimout);

                                    UserLoginCountModel userLoginCountModel = new UserLoginCountModel
                                    {
                                        UserID = loginSuccessModel.UserID,
                                        LoginFailedCount = 0,
                                        LoginAttemptCount = LoginAttemptCount
                                    };
                                     
                                    int z = _objlogin.UpdateLoginCount(userLoginCountModel);

                                    var refreshToken = _objlogin.AddRefreshToken(loginSuccessModel.UserID, DateTime.UtcNow.AddHours(8));

                                    LoginRequest loginRequest = new LoginRequest();
                                    loginRequest.IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString();
                                    loginRequest.Success = true;
                                    loginRequest.UserId = loginSuccessModel.UserID;
                                    loginRequest.Webtoken = WebToken;
                                    loginRequest.UserAgent = UserAgent;
                                    loginRequest.RefreshToken = refreshToken;

                                    _objlogin.InsertUserLoginAuditAsync(loginRequest);

                                    loginRequest = null;

                                    // Optionally set the refresh token as an HttpOnly cookie
                                    Response.Cookies.Append("refreshToken", refreshToken, new CookieOptions
                                    {
                                        HttpOnly = true,
                                        Secure = true, // HTTPS only
                                        SameSite = SameSiteMode.None,
                                        Expires = DateTime.UtcNow.AddDays(1) // Long-lived cookie
                                    });

                                    // return basic user info (without password) and token to store client side
                                    return Ok(new
                                    {
                                        Username = loginSuccessModel.UserID,
                                        Role = loginSuccessModel.RoleName,
                                        FirstName = loginSuccessModel.FirstName, 
                                        ClientLogo = loginSuccessModel.ClientLogo,
                                        AccessToken = tokenString,
                                        RefreshToken = refreshToken,
                                        Theme=loginSuccessModel.theme
                                    });
                                }
                                else
                                {
                                    LoginFailedCount = LoginFailedCount + 1;

                                    UserLoginCountModel userLoginCountModel = new UserLoginCountModel
                                    {
                                        UserID = loginModel.UserName,
                                        LoginFailedCount = LoginFailedCount,
                                        LoginAttemptCount = LoginAttemptCount
                                    };

                                    loginModel = null;

                                    int z = _objlogin.UpdateLoginCount(userLoginCountModel);

                                    userLoginCountModel = null;

                                    if (LoginFailedCount >= LoginAttemptCount)
                                    {
                                        return BadRequest(new { message = "You have tried " + LoginAttemptCount + " failed login attempts. Your account has been blocked .Kindly contact Admin" });
                                    }
                                    else
                                    {
                                        return BadRequest(new { message = "You have made " + LoginFailedCount + " unsuccessful attempt(s).  If " + LoginAttemptCount + " is exceeded, then you will be disabled to use this access mode." });
                                    }
                                }
                            }
                            else
                            {
                                LoginFailedCount = LoginFailedCount + 1;

                                UserLoginCountModel userLoginCountModel = new UserLoginCountModel
                                {
                                    UserID = username,
                                    LoginFailedCount = LoginFailedCount,
                                    LoginAttemptCount = LoginAttemptCount
                                };

                                VerifyLoginModel = null;
                                userClientModel = null;

                                int z = _objlogin.UpdateLoginCount(userLoginCountModel);

                                userLoginCountModel = null;

                                LoginRequest loginRequest = new LoginRequest();
                                loginRequest.IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString();
                                loginRequest.Success = false;
                                loginRequest.UserId = username;
                                loginRequest.Webtoken = WebToken;
                                loginRequest.FailureReason = "Username or password is incorrect";
                                loginRequest.UserAgent = UserAgent; 

                                _objlogin.InsertUserLoginAuditAsync(loginRequest);

                                loginRequest = null;

                                return BadRequest(new { message = "You have tried " + LoginAttemptCount + " failed login attempts. Your account has been blocked .Kindly contact Admin" });
                            }
                        }
                        else
                        {
                            LoginRequest loginRequest = new LoginRequest();
                            loginRequest.IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString();
                            loginRequest.Success = false;
                            loginRequest.UserId = username;
                            loginRequest.Webtoken = WebToken;
                            loginRequest.FailureReason = "Username is incorrect";
                            loginRequest.UserAgent = UserAgent;

                            _objlogin.InsertUserLoginAuditAsync(loginRequest);

                            loginRequest = null;

                            return BadRequest(new { message = "Username or password is incorrect" });
                        }
                    }
                    else
                    {
                        LoginRequest loginRequest = new LoginRequest();
                        loginRequest.IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString();
                        loginRequest.Success = false;
                        loginRequest.UserId = username;
                        loginRequest.Webtoken = WebToken;
                        loginRequest.FailureReason = "CAPTCHA code is incorrect";
                        loginRequest.UserAgent = UserAgent;

                        _objlogin.InsertUserLoginAuditAsync(loginRequest);

                        loginRequest = null;

                        return BadRequest(new { message = "CAPTCHA code is incorrect" });
                    }

                }
                catch (Exception ex)
                {
                    Utility.LogWriter objLogWriter = new Utility.LogWriter();
                    objLogWriter.FunErrorLog(ex.Message.ToString(), "1", "LoginController.cs", "ValidateUser", 0, "", username, 'E');
                }

                return BadRequest(new { message = "Username or password is incorrect" });
            }


        }

        private byte[] Generate256BitKey()
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                byte[] key = new byte[32]; // 32 bytes = 256 bits
                rng.GetBytes(key);
                return key;
            }
        }

        [AllowAnonymous]
        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> LogUserLogout(LogoutRequest request)
        {
            try
            {
                await _objlogin.InsertUserLogoutAuditAsync(request);
                return Ok(new { message = "Logout recorded" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error recording logout", error = ex.Message });
            }
        }

        [AllowAnonymous]
        [Route("[action]")]
        [HttpPost]
        public IActionResult RefreshToken([FromBody] RefreshTokenRequest model)
        {
            var fake_refreshToken = model.RefreshToken;

            var refreshToken = Request.Cookies["refreshToken"];

            if (string.IsNullOrEmpty(refreshToken))
            {
                return Unauthorized(new { Message = "No refresh token found." });
            }

            var userId = _objlogin.GetUserIdFromRefreshToken(refreshToken); // Validate refresh token

            if (userId != null)
            {
                LoginSuccessModel loginSuccessModel = _objlogin.GetById(userId);

                if (loginSuccessModel != null && loginSuccessModel.UserID != null)
                {
                    var tokenString = Common.GenerateTokens(userId, _settings.Secret, _settings.SessionTimout);
                    var newRefreshToken = _objlogin.AddRefreshToken(loginSuccessModel.UserID, DateTime.UtcNow.AddHours(10));

                    return Ok(new
                    {
                        Username = loginSuccessModel.UserID,
                        Role = loginSuccessModel.RoleName,
                        FirstName = loginSuccessModel.FirstName,
                        ClientLogo = loginSuccessModel.ClientLogo,
                        AccessToken = tokenString,
                        RefreshToken = newRefreshToken
                    });
                }
            }

            return Unauthorized();
        }

        [AllowAnonymous]
        [HttpPost("[action]")]
        public IActionResult ValidateEmailId(ForgotModel forgotModel)
        {
            string EmailID = forgotModel.EmailID == null ? "" : forgotModel.EmailID;

            if (ValidateUsingEmailAddressAttribute(EmailID))
            {
                try
                {
                    string result = _objlogin.VERIFY_CAPTCHA(forgotModel.CAPTCHACODE, forgotModel.WebToken);
                    if (result == "Success")
                    {

                        FirstLoginModel tempModel = _objlogin.GetUserDetailsByEmailId(EmailID);

                        if (tempModel != null)
                        {
                            if (tempModel.IsFirstLogin == "Login")
                            {
                                ResetPasswordModel resetModel = new ResetPasswordModel();

                                resetModel.ClientCode = tempModel.ClientCode;
                                resetModel.UserID = tempModel.UserID;

                                string TempPass = GeneratePassword(8, true, true, true, true);
                                resetModel.NewSalt = Utility.AesEncryption.EncryptUsingSHA2Algorithm(Utility.AesEncryption.RandomStringGenerator());
                                resetModel.NewPassword = Utility.AesEncryption.EncryptUsingSHA2Algorithm(TempPass);
                                resetModel.CreatedBy = "ForgotPassword";
                                string result1 = _Common.ResetPassword(resetModel);

                                if (result1 == "Login")
                                {

                                    SmtpMail smtpMail = new SmtpMail(_configuration, _Common);
                                    EmailModel emailModel = new EmailModel();
                                    emailModel.To = EmailID;

                                    emailModel.Body = "<b>Dear</b>" + "<B>&nbsp;&nbsp;" + resetModel.UserID + "</b> ,<br><br><b>Please find below the login credentials for Trace Portal:</b>" +
                                                            "<br>UserID:  " + resetModel.UserID +
                                                            "<br>One Time Password: " + TempPass
                                                        + "</div>" + "<br><br><strong>Regards,<br>PSS";

                                    emailModel.Subject = "Password Reset";
                                    smtpMail.SendEmail(emailModel);

                                    return Ok(new { message = "Password sent successfully. Please check your email." });

                                }
                                else
                                {
                                    return BadRequest(new { message = "Error Occurred" });
                                }
                            }
                            else
                            {
                                return BadRequest(new { message = "Your password has already been sent successfully. Please check your email." });
                            }
                        }
                        else
                        {
                            return BadRequest(new { message = "The email address is not valid." });
                        }
                    }
                    else
                    {
                        return BadRequest(new { message = "CAPTCHA code is incorrect" });
                    }
                }
                catch (Exception ex)
                {
                    Utility.LogWriter objEx = new Utility.LogWriter();
                    objEx.FunErrorLog(ex.Message.ToString(), "1", "LoginController.cs", "ValidateEmailId", 0, "", EmailID, 'E');
                }
            }
            else
            {
                return BadRequest(new { message = "The email address is not in the proper format. Please correct it." });
            }

            return BadRequest(new { message = "The email address is not valid" });
        }

        private static string GeneratePassword(int length, bool useLowercase, bool useUppercase, bool useNumbers, bool useSpecialChars)
        {
            const string lowercaseChars = "abcdefghijklmnopqrstuvwxyz";
            const string uppercaseChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string numberChars = "123456789";
            const string specialChars = "!@#$";

            string validChars = "";
            if (useLowercase)
                validChars += lowercaseChars;
            if (useUppercase)
                validChars += uppercaseChars;
            if (useNumbers)
                validChars += numberChars;
            if (useSpecialChars)
                validChars += specialChars;

            if (string.IsNullOrEmpty(validChars))
                throw new ArgumentException("At least one character set must be selected for the password.");

            var rng = new System.Security.Cryptography.RNGCryptoServiceProvider();
            byte[] randomBytes = new byte[length * 4]; // Four random bytes per character

            rng.GetBytes(randomBytes);

            var password = new System.Text.StringBuilder(length);
            for (int i = 0; i < length; i++)
            {
                uint randomInt = BitConverter.ToUInt32(randomBytes, i * 4);
                password.Append(validChars[(int)(randomInt % validChars.Length)]);
            }

            return password.ToString();
        }

        private bool ValidateUsingEmailAddressAttribute(string emailAddress)
        {
            var emailValidation = new System.ComponentModel.DataAnnotations.EmailAddressAttribute();
            return emailValidation.IsValid(emailAddress);
        }

        [HttpPost("[action]")]
        public IActionResult AddOrUpdateTheme(ThemeModel themeModel)
        {
            string updatedTheme = _objlogin.AddOrUpdateThemes(themeModel);

            if (!string.IsNullOrEmpty(updatedTheme))
            {
                return Ok(new { theme = updatedTheme });
            }
            else
            {
                return StatusCode(500, new { Message = "Failed to update theme." });
            }
        }
    }
}
