﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization; 

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class MatchingRuleController : ControllerBase
    {
        private readonly IMatchingRule _objMatchingRule;

        public MatchingRuleController(IMatchingRule objMatchingRule)
        {
            _objMatchingRule = objMatchingRule;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetChannelMatchingList(string ClientId)
        {
            return _objMatchingRule.GetChannelMatching(ClientId);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetModeMatchingList(string ClientId, string ChannelID)
        {
            return _objMatchingRule.GetModeMatching(ClientId, ChannelID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetMatchingRuleSetForClientList(string ClientId, string ChannelID, string RuleType)
        {
            return _objMatchingRule.GetMatchingRuleSetForClient(ClientId, ChannelID, RuleType);
        }

        [Route("[action]")]
        [HttpPost]
        public object AddMatchingRuleConfigList(AddMatchingRuleConfig addMatchingRuleConfig)
        {

            string returnMessage = string.Empty;

            int MatchingRuleCount = 0;  DataSet ds = new DataSet(); DataTable dt = new DataTable();

            try
            {
                if (addMatchingRuleConfig.RRNInclude == false && addMatchingRuleConfig.CardNoInclude == false && addMatchingRuleConfig.TerminalIdInclude ==false && addMatchingRuleConfig.DateInclude == false && addMatchingRuleConfig.AmountInclude == false)
                {
                    returnMessage = "Please select atleast one Matching Rule.";
                    return returnMessage;
                }
                else
                {
                    dt.Columns.Add("ClientID");
                    dt.Columns.Add("ColumnName");
                    dt.Columns.Add("ChannelID");
                    dt.Columns.Add("ModeID");
                    dt.Columns.Add("RuleType");
                    dt.Columns.Add("Username");
                    dt.Columns.Add("IsRemoved");

                    DataTable dtMatchingRule = _objMatchingRule.GetMatchingRuleSetForClient(addMatchingRuleConfig.ClientID,addMatchingRuleConfig.ChannelID,addMatchingRuleConfig.RuleType);
                    for (int i = 0; i < dtMatchingRule.Rows.Count; i++)
                    {
                        if (dtMatchingRule.Rows[i]["RuleType"].ToString() == addMatchingRuleConfig.RuleType)
                        {
                            string ColumnName = dtMatchingRule.Rows[i]["ColumnName"].ToString();
                            if (ColumnName == "ReferenceNumber" && addMatchingRuleConfig.RRNInclude == false) dt.Rows.Add(addMatchingRuleConfig.ClientID,"ReferenceNumber", addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, addMatchingRuleConfig.IsRemoved);
                            if (ColumnName == "CardNumber" && addMatchingRuleConfig.CardNoInclude == false) dt.Rows.Add(addMatchingRuleConfig.ClientID, "CardNumber", addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, addMatchingRuleConfig.IsRemoved);
                            if (ColumnName == "TerminalId" && addMatchingRuleConfig.TerminalIdInclude == false) dt.Rows.Add(addMatchingRuleConfig.ClientID, "TerminalId", addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, addMatchingRuleConfig.IsRemoved);
                            if (ColumnName == "TxnsDateTime" && addMatchingRuleConfig.DateInclude == false) dt.Rows.Add(addMatchingRuleConfig.ClientID, "TxnsDateTime", addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, addMatchingRuleConfig.IsRemoved);
                            if (ColumnName == "TxnsAmount" && addMatchingRuleConfig.AmountInclude == false) dt.Rows.Add(addMatchingRuleConfig.ClientID, "TxnsAmount", addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, addMatchingRuleConfig.IsRemoved);
                        }
                    }

                    if (addMatchingRuleConfig.RRNInclude == true) {addMatchingRuleConfig.IsRemoved = "0"; dt.Rows.Add(addMatchingRuleConfig.ClientID, "ReferenceNumber", addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, addMatchingRuleConfig.IsRemoved); }
                    if (addMatchingRuleConfig.CardNoInclude == true) { addMatchingRuleConfig.IsRemoved = "0"; dt.Rows.Add(addMatchingRuleConfig.ClientID, "CardNumber", addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, addMatchingRuleConfig.IsRemoved); }
                    if (addMatchingRuleConfig.TerminalIdInclude == true) { addMatchingRuleConfig.IsRemoved = "0"; dt.Rows.Add(addMatchingRuleConfig.ClientID, "TerminalId", addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, addMatchingRuleConfig.IsRemoved); }
                    if (addMatchingRuleConfig.DateInclude == true) { addMatchingRuleConfig.IsRemoved = "0"; dt.Rows.Add(addMatchingRuleConfig.ClientID, "TxnsDateTime", addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, addMatchingRuleConfig.IsRemoved); }
                    if (addMatchingRuleConfig.AmountInclude == true) { addMatchingRuleConfig.IsRemoved = "0"; dt.Rows.Add(addMatchingRuleConfig.ClientID, "TxnsAmount", addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, addMatchingRuleConfig.IsRemoved); }

          
                    MatchingRuleCount = _objMatchingRule.ChannelModeDetailsField(dt);
                    if (MatchingRuleCount > 0)
                    {
                        returnMessage = "Matching Rule Configured Successfully.";
                        return returnMessage;
                    }
                    else
                    {
                        returnMessage = "Matching Rule Set is already Configured";
                        return returnMessage;
                    }
                }

            }
            catch (Exception ex)
            {
                return "Error";
            }
        }

        [Route("[action]")]
        [HttpGet]
        public object GetMatchingGrid(string ClientId)
        {
            return _objMatchingRule.GetMatchingListByClient(ClientId);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetImportConfigModes(string ClientId, string ChannelID)
        {
            return _objMatchingRule.GetImportConfigModeList(ClientId, ChannelID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetImportTables(string ClientId, string ChannelID, string ModeID)
        {
            return _objMatchingRule.GetMatchingColumnTableList(ClientId, ChannelID, ModeID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetMatchingColumns(string ClientId, string ChannelID, string ModeID)
        {
            return _objMatchingRule.GetMatchingColumnList(ClientId, ChannelID, ModeID);
        }

        [Route("[action]")]
        [HttpPost]
        public object AddMatchingRuleConfig(MatchingRuleConfig addMatchingRuleConfig)
        {

            string returnMessage = string.Empty;

            int MatchingRuleCount = 0; DataSet ds = new DataSet(); DataTable dt = new DataTable();

            try
            {
                if (addMatchingRuleConfig.SelectedColumn.Length == 0)
                {
                    returnMessage = "Please select atleast one Matching Rule.";
                    return returnMessage;
                }
                else
                {
                    dt.Columns.Add("ClientID");
                    dt.Columns.Add("ColumnName");
                    dt.Columns.Add("ChannelID");
                    dt.Columns.Add("ModeID");
                    dt.Columns.Add("RuleType");
                    dt.Columns.Add("Username");
                    dt.Columns.Add("IsRemoved");

                    string[] SelectedColumnList= addMatchingRuleConfig.SelectedColumn.Split(',');

                    foreach (string ColumnName in SelectedColumnList)
                    {
                        if (ColumnName.Length > 0)
                        {
                            dt.Rows.Add(addMatchingRuleConfig.ClientID, ColumnName, addMatchingRuleConfig.ChannelID, addMatchingRuleConfig.ModeID, addMatchingRuleConfig.RuleType, addMatchingRuleConfig.Username, 0);
                        }
                    } 
                     

                    MatchingRuleCount = _objMatchingRule.AddMatchingRuleConfig(dt);
                    if (MatchingRuleCount > 0)
                    {
                        returnMessage = "Matching Rule Configured Successfully.";
                        return returnMessage;
                    }
                    else
                    {
                        returnMessage = "Matching Rule Set is already Configured";
                        return returnMessage;
                    }
                }

            }
            catch (Exception ex)
            {
                return "Error";
            }
        }

        [Route("[action]")]
        [HttpGet]
        public object GetImportConfigGrid(string ClientId)
        {
            return _objMatchingRule.GetImportConfigListByClient(ClientId);
        }

        [Route("[action]")]
        [HttpPost]
        public object DeleteMatchingRuleConfig(DeleteMatchingModel addMatchingRuleConfig)
        {
            return _objMatchingRule.DeleteMatchingRuleConfig(addMatchingRuleConfig);
        }

            

    }
}