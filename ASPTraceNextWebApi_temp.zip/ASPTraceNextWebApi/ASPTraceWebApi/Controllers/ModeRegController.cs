﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ModeRegController : ControllerBase
    {
        private readonly IModeReg _objModeReg;

        public ModeRegController(IModeReg objModeReg)
        {
            _objModeReg = objModeReg;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetModeRegList()
        {
            return _objModeReg.GetModeReg();
        }

        [Route("[action]")]
        [HttpPost]
        public object ModeRegAddList(ModeRegAddModel modeRegAddModel)
        {
            return _objModeReg.ModeRegAdd(modeRegAddModel);
        }

        [HttpGet]
        [Route("[action]/{ModeID}")]
        public object GetModeDetails(string ModeID)
        {
            return _objModeReg.GetModeDetails(ModeID);
        }

        [Route("[action]")]
        [HttpPost]
        public object ModeRegDelete(ModeRegDeleteModel modeRegDeleteModel)
        {
            return _objModeReg.ModeRegDelete(modeRegDeleteModel);
        }
    }
}
