﻿using Microsoft.AspNetCore.Mvc; 
using ASPTrace.Contracts;
using Microsoft.AspNetCore.Authorization;

namespace ASPTraceWebApi.Controllers
{

    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class NotificationsController : ControllerBase
    {
        private readonly INotifications _notifications;
        public NotificationsController(INotifications notifications)
        {
            _notifications = notifications;
        }

        [Route("[action]")]
        [HttpGet]
        public async Task<object> GetNotifications()
        {
            return await _notifications.GetNotificationListAsync();
        }

        [Route("[action]")]
        [HttpPost]
        public async Task<string> MarkNotification([FromQuery] string notificationId, [FromQuery] string Type)
        {
            return await _notifications.SetNotificationAsReadAsync(notificationId, Type);
        }
    }
}
