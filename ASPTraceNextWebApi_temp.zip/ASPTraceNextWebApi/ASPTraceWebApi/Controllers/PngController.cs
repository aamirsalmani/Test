﻿using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PngController : Controller
    {
        [HttpGet]
        public IActionResult GetPngFile(string ImageFileName)
        {

            string _pngFilePath = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\ClientLogo\\", ImageFileName);
            // Check if the file exists
            if (!System.IO.File.Exists(_pngFilePath))
            {
                return NotFound();
            }

            // Serve the file
            var fileBytes = System.IO.File.ReadAllBytes(_pngFilePath);
            return File(fileBytes, "image/png");
        }
    }
}
