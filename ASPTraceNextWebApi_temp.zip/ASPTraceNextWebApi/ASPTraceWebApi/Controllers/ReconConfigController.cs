﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections; 
using Microsoft.AspNetCore.Authorization;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.OleDb;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ReconConfigController : ControllerBase
    {
        private readonly IReconConfig _objField;
        private readonly IImportLogs objIImportLogs;
        private readonly ICommon objCommon;

        public ReconConfigController(IReconConfig objField, IImportLogs __objIImportLogs, ICommon _Common)
        {
            _objField = objField;
            objIImportLogs = __objIImportLogs;
            objCommon = _Common; ;
        }


        [HttpPost("[action]")]
        public string FileConfig([FromForm] ASPTrace.Models.ReconImportConfigModel FileConfigData)
        {
            try
            {
                int ClientID = Convert.ToInt16(FileConfigData.ClientID);
                int ChannelID = Convert.ToInt16(FileConfigData.ChannelID);
                int ModeID = Convert.ToInt16(FileConfigData.ModeID);
                int VendorID = Convert.ToInt16(FileConfigData.VendorID);
                int ReconType = Convert.ToInt16(FileConfigData.ReconType);

                string MSG = string.Empty;
                string Status = string.Empty;

                var DateFormatArray = JsonConvert.DeserializeObject<List<DateArray>>(FileConfigData.DateFieldArray);

                DataTable DateFormats = new DataTable();
                DateFormats.Columns.Add("ColumnName", typeof(string));
                DateFormats.Columns.Add("DateFormatString", typeof(string));

                foreach (var ColumnData in DateFormatArray)
                {
                    string ColumnName = ColumnData.DateColumn;
                    string DateFormatString = string.Join(",", ColumnData.DateFormat);
                    DateFormats.Rows.Add(ColumnName, DateFormatString);
                }


                var FileDataArray = JsonConvert.DeserializeObject<List<FileDataArray>>(FileConfigData.FileData);

                DataTable UploadedFileData = new DataTable();
                UploadedFileData.Columns.Add("ColumnNames", typeof(string));
                UploadedFileData.Columns.Add("ColumnAlias", typeof(string));
                UploadedFileData.Columns.Add("ColumnsData", typeof(string));
                UploadedFileData.Columns.Add("ColumnsDataTypes", typeof(string));
                string ColumnNames = string.Empty;
                string ColumnAlias = string.Empty;
                string ColumnsData = string.Empty;
                string ColumnsDataTypes = string.Empty;

                foreach (var ColumnData in FileDataArray)
                {

                    string ID = ColumnData.ID;
                    string columnName = ColumnData.columnName;
                    string columnAlia = ColumnData.columnAlias;
                    string position = ColumnData.position;
                    string dataType = ColumnData.dataType;
                    string dataValue = ColumnData.dataValue;

                    ColumnNames         += ColumnNames      =="" ? columnName: ","  +columnName;
                    ColumnAlias         += ColumnAlias      =="" ? columnAlia: ","  +columnAlia;
                    ColumnsData         += ColumnsData      =="" ? dataValue : ","  +dataValue ;
                    ColumnsDataTypes    += ColumnsDataTypes =="" ? dataType  : ","  +dataType  ;

                }


                UploadedFileData.Rows.Add(ColumnNames, ColumnAlias,  ColumnsData, ColumnsDataTypes);


                if (FileConfigData.FormatXML != "")
                {
                    MSG = _objField.XMLConfig(ClientID, ChannelID, ModeID, VendorID, FileConfigData.FormatXML, FileConfigData.FileData);
                }
                if (DateFormats.Rows.Count > 0)
                {
                    MSG = _objField.DateFormatArray(ClientID, ChannelID, ModeID, VendorID, DateFormats);
                }

                Status = _objField.SubmitReconConfig(FileConfigData);


                return MSG;
            }
            catch (Exception ex)
            {
                return "Failure :" + ex.Message;
            }

        }

        [HttpPost("[action]")]
        public string QueryConfig([FromForm] ASPTrace.Models.ReconImportConfigModel FileConfigData)
        {
            try
            {
                int ClientID = Convert.ToInt16(FileConfigData.ClientID);
                int ChannelID = Convert.ToInt16(FileConfigData.ChannelID);
                int ModeID = Convert.ToInt16(FileConfigData.ModeID);
                int VendorID = Convert.ToInt16(FileConfigData.VendorID);
                int ReconType = Convert.ToInt16(FileConfigData.ReconType);

                string MSG = string.Empty;
                string Status = string.Empty;


                if (FileConfigData.FormatXML != "")
                {
                    MSG = _objField.RawFileUploadQuery(ClientID, ChannelID, ModeID, VendorID, ReconType, FileConfigData.FormatXML, FileConfigData.UserName);
                }

                Status = _objField.SubmitReconConfig(FileConfigData);


                return MSG;
            }
            catch (Exception ex)
            {
                return "Failure :" + ex.Message;
            }

        }


        [HttpPost]
        public string Post([FromForm] ASPTrace.Models.ReconImportFileModel file)
        {
            ASPTrace.Models.ImportFileStatus importFileStatus = new ASPTrace.Models.ImportFileStatus();

            try
            {
                string MSG = string.Empty;
                DataTable dataTable = new DataTable();
                string jsonString = string.Empty;


                if (file.ImportFile == null)
                {
                    importFileStatus.MSG = "Error";
                    importFileStatus.Status = "File not selected";
                }
                else
                {
                    Guid objGuid = Guid.NewGuid();

                    string sFileName = file.ImportFile.FileName; // "Trace_" + objGuid.ToString().Replace("-", "") + 

                    string path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\Upload\\ReconConfig\\", sFileName);
                    string FileDir = Path.GetDirectoryName(path);

                    if (!Directory.Exists(FileDir))
                    {
                        Directory.CreateDirectory(FileDir);
                    }
                    else if (System.IO.File.Exists(path))
                    {

                        System.IO.File.Delete(path);
                    }

                    using (Stream stream = new FileStream(path, FileMode.Create))
                    {
                        file.ImportFile.CopyTo(stream);
                    }

                    string sFileExt1 = System.IO.Path.GetExtension(sFileName);

                    // Create a DataTable to store the Excel data
                    string Contenttype = file.ImportFile.ContentType;

                    bool Invalid = true;

                    string withSeperator = file.Seperator;

                    if (sFileExt1.Contains("xls"))
                    {

                        if (Invalid)
                        {
                            dataTable = _objField.ExcelTable(path);
                        }

                    }
                    else if (Contenttype.Contains("text/plain") || Contenttype.Contains("text/csv"))
                    {
                        if (withSeperator != "" && withSeperator != null)
                        {

                            if (Invalid)
                            {
                                dataTable = _objField.txtTableWithSeperator(path, withSeperator);
                            }
                        }
                        else
                        {
                            if (Invalid)
                            {
                                dataTable = _objField.txtTableWithoutSeperator(path);
                            }


                        }

                    }
                    else
                    {
                        importFileStatus.MSG = importFileStatus.MSG + "Error :: File Name" + sFileName;
                        importFileStatus.Status = "" + sFileName + "<br/>" + importFileStatus.Status + " File _configuration not found<br/>0<br/>0";
                    }


                    System.IO.File.Delete(path);
                }


                JObject myObject = new JObject();
                myObject.Add("DataTable", JToken.FromObject(dataTable));

                // convert the JObject to a JSON string
                jsonString = JsonConvert.SerializeObject(myObject);
                return jsonString;
            }
            catch (Exception ex)
            {
                importFileStatus.MSG = "Error";
                string s = file.ImportFile != null ? file.ImportFile.FileName : "No File";
                return s;
            }


        }

        private DataTable GetTableWithSeperator(string path, string Seperator)
        {
            DataTable dataTable = new DataTable();
            int LineNo = 0, count = 0, MaxLength = 0;
            string line1 = string.Empty;
            string[] lineArr;
            bool ColumnAdded = false;

            foreach (string line in System.IO.File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty).Trim();

                    lineArr = line1.Split(new[] { Seperator }, StringSplitOptions.None);

                    if (lineArr.Length > MaxLength)
                    {
                        MaxLength = lineArr.Length;
                    }

                    if (LineNo > 5)
                    {
                        break;
                    }
                }
                catch (Exception ex)
                {
                }
            }

            LineNo = 0;

            foreach (string line in System.IO.File.ReadAllLines(path))
            {
                LineNo++;
                try
                {
                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty).Trim();

                    lineArr = line1.Split(new[] { Seperator }, StringSplitOptions.None);

                    if (MaxLength == lineArr.Length && !ColumnAdded)
                    {
                        foreach (string columnName in lineArr)
                        {
                            count++;
                            DataColumn column = new DataColumn("Column" + count.ToString(), typeof(string));
                            dataTable.Columns.Add(column);
                        }

                        if (dataTable.Columns.Count > 0)
                        {
                            ColumnAdded = true;
                        }
                    }

                    if (MaxLength == lineArr.Length)
                    {
                        DataRow row = dataTable.NewRow();
                        // Assign values from lineArr to the DataRow
                        for (int i = 0; i < lineArr.Length; i++)
                        {
                            row[i] = lineArr[i];
                        }

                        dataTable.Rows.Add(row);
                    }

                    if (LineNo > 5)
                    {
                        break;
                    }
                }
                catch (Exception ex)
                {
                }
            }





            return dataTable;
        }

        [HttpPost("[action]")]
        public object AddFieldConfig(AddFieldConfigModel addFieldConfigModel)
        {
            string alertMessage = string.Empty;
            DataTable dtRecords = _objField.GetChannelModeDetailsField(addFieldConfigModel.ClientID);
            bool flag = false;

            if (dtRecords.Rows.Count > 0)
            {
                for (int k = 0; k < dtRecords.Rows.Count; k++)
                {
                    string col1 = dtRecords.Rows[k]["ONUS"].ToString();
                    string col2 = dtRecords.Rows[k]["ACQUIRER"].ToString();
                    string col3 = dtRecords.Rows[k]["ISSUER"].ToString();

                    if (dtRecords.Rows[k]["ChannelName"].ToString() == "ATM" && (addFieldConfigModel.ChannelID == "1" || addFieldConfigModel.ChannelID == "0"))
                    {
                        if ((col1 != "" || col2 != "") && (addFieldConfigModel.TerminalCode == "" || addFieldConfigModel.BinNo == ""))
                        {
                            if (addFieldConfigModel.TerminalCode == "")
                                alertMessage = "Enter Terminal Code.";
                            else if (addFieldConfigModel.BinNo == "")
                                alertMessage = "Enter BIN No.";
                            //else
                            //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter Acquirer ID')", true);
                        }
                        else if (col3 != "" && addFieldConfigModel.BinNo == "")
                            alertMessage = "Enter BIN No.";
                        else
                            flag = true;
                    }
                    else
                        flag = true;

                    #region Commented
                    //else if (txtATM.Text == "")
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter ATM Code')", true);
                    //else
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter Acquirer ID')", true);
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "POS" && txtPOS.Text == "" )
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter POS Code')", true);
                    //}
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "E-COMMERCE" && txtECOM.Text == "")
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter E-COMMERCE Code')", true);
                    //}
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "IMPS" && txtECOM.Text == "")
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter IMPS Code')", true);
                    //}
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "MICRO_ATM" && txtMicroATM.Text == "")
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter MICROATM Code')", true);
                    //}
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "UPI" && txtUPI.Text == "")
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter UPI Code')", true);
                    //}
                    //if (dtRecords.Rows[k]["ChannelName"].ToString() == "MOBILERECHARGE" && txtMblRchrg.Text == "")
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Enter MOBILERECHARGE Code')", true);
                    //}
                    #endregion
                }
            }

            if (flag == true && alertMessage.Length == 0)
            {
                DataTable dtRecord = _objField.AddFieldConfig(addFieldConfigModel);

                if (dtRecord.Rows[0]["Status"].ToString() == "Save")
                {
                    alertMessage = "Field Identifications _configuration Set Successfully.";
                }
                else if (dtRecord.Rows[0]["Status"].ToString() == "Update")
                {
                    alertMessage = "Field Identifications _configuration Updated Successfully";
                }
                else
                {
                    alertMessage = "Field Identifications _configuration Failed.";
                }
            }
            else
            {
                if (alertMessage.Length == 0)
                {
                    alertMessage = "Field Identifications _configuration Failed.";
                }
            }
            return alertMessage;
        }

        [HttpPost("[action]")]
        public object StatusConditions([FromBody] List<StatusConditionsModel> StatusConditions)
        {
            string alertMessage = string.Empty;
            string TempQuery = string.Empty;
            string jsonString = string.Empty;
            try
            {

                DataSet DataS = _objField.tblStatusConditions(StatusConditions);

                DataTable DataRaw = DataS.Tables[0];
                DataTable DataTable = DataS.Tables[1];
                bool flag = false;
                string Query = string.Empty;



                if (DataRaw.Rows.Count > 0)
                {
                    for (int k = 0; k < DataRaw.Rows.Count; k++)
                    {
                        if (DataRaw.Rows[k]["Query"].ToString() != "")
                        {
                            TempQuery = DataRaw.Rows[k]["Query"].ToString();
                            Query = ReconConfigGen.FormatSQLQueries(TempQuery);


                        }
                        else
                            flag = true;


                    }


                }



                // create a JObject and add the string and DataTable as properties
                JObject myObject = new JObject();
                myObject.Add("QueryString", Query);
                myObject.Add("DataTable", JToken.FromObject(DataTable));

                // convert the JObject to a JSON string
                jsonString = JsonConvert.SerializeObject(myObject);

            }
            catch (Exception ex)
            {

            }

            //return alertMessage;//TempQuery
            return jsonString;
        }

        [HttpPost("[action]")]
        public object AddRawTableFields([FromBody] List<ReconRawTableFields> addRawTableModel)
        {
            string alertMessage = string.Empty;
            string TempQuery = string.Empty;
            string jsonString = string.Empty;
            try
            {

                DataSet DataS = _objField.AddRawTableFields(addRawTableModel);

                DataTable DataRaw = DataS.Tables[0];
                DataTable DataTable = DataS.Tables[1];
                bool flag = false;
                string Query = string.Empty;

                if (DataRaw.Rows.Count > 0)
                {
                    for (int k = 0; k < DataRaw.Rows.Count; k++)
                    {
                        if (DataRaw.Rows[k]["Query"].ToString() != "")
                        {
                            TempQuery = DataRaw.Rows[k]["Query"].ToString();
                            Query = ReconConfigGen.FormatSQLQueries(TempQuery);


                        }
                        else
                            flag = true;


                    }


                }



                // create a JObject and add the string and DataTable as properties
                JObject myObject = new JObject();
                myObject.Add("QueryString", Query);
                myObject.Add("DataTable", JToken.FromObject(DataTable));

                // convert the JObject to a JSON string
                jsonString = JsonConvert.SerializeObject(myObject);

            }
            catch (Exception ex)
            {

            }

            //return alertMessage;//TempQuery
            return jsonString;
        }
        [HttpPost("[action]")]
        public object GenerateRecon(ReconQueryFields addReconQueryFields)
        {
            string jsonString = string.Empty;
            ReconQueryBlocks ReconQueryBlocks = new ReconQueryBlocks();

            DataTable dt = _objField.GenerateRecon(addReconQueryFields);

            int ReconTablesCount = addReconQueryFields.ReconType != "" ? Convert.ToInt16(addReconQueryFields.ReconType) : 0;

            List<ReconRawTableFields> table = new List<ReconRawTableFields>();

            List<List<ReconRawTableFields>> TablesList = new List<List<ReconRawTableFields>>();

            for (int k = 0; k < ReconTablesCount; k++)
            {
                string Data = dt.Rows[k]["Query"].ToString();
                string Reversal = dt.Rows[k]["Reversal"].ToString();
                string TableName = dt.Rows[k]["TableName"].ToString();
                string TableNo = dt.Rows[k]["TableNo"].ToString();
                string ReconTypeID = dt.Rows[k]["ReconTypeID"].ToString();

                object Fields = new
                {
                    ValTableName = TableName,
                    ValTableNo = TableNo,
                    ValReconTypeID = ReconTypeID,
                    ValData = Data
                };

                Data = ReconConfigGen.FormatSQLQueries(Data);

                if (Data != "")
                {
                    table = ReconConfigGen.ColumnsExtract(Fields);
                    TablesList.Add(table);
                }

                if (Data != "" && Reversal.ToLower() == "true")
                {
                    Data = ReconConfigGen.ReversalMergeBlock(Data);
                }
                else
                {
                    Data = ReconConfigGen.WrapperBlock(Data, TableName);
                }



                if (addReconQueryFields.ChannelName == null && addReconQueryFields.ModeName == null)
                {
                    string ChannelName = dt.Rows[k]["ChannelName"].ToString();
                    string ModeName = dt.Rows[k]["ModeName"].ToString();

                    addReconQueryFields.ChannelName = ChannelName;
                    addReconQueryFields.ModeName = ModeName;
                }

                if (k == 0)
                {
                    ReconQueryBlocks.RawTable1 = Data;
                    ReconQueryBlocks.Reversal1 = Reversal;
                }
                if (k == 1)
                {
                    ReconQueryBlocks.RawTable2 = Data;
                    ReconQueryBlocks.Reversal2 = Reversal;
                }
                if (k == 2)
                {
                    ReconQueryBlocks.RawTable3 = Data;
                    ReconQueryBlocks.Reversal3 = Reversal;
                }
                if (k == 3)
                {
                    ReconQueryBlocks.RawTable4 = Data;
                    ReconQueryBlocks.Reversal4 = Reversal;
                }
                if (k == 4)
                {
                    ReconQueryBlocks.RawTable5 = Data;
                    ReconQueryBlocks.Reversal5 = Reversal;
                }


            }

            string Query = ReconConfigGen.ReconQueryConstructorKS(addReconQueryFields, ReconQueryBlocks, TablesList);
            JObject myObject = new JObject();
            myObject.Add("QueryString", Query);

            // convert the JObject to a JSON string
            jsonString = JsonConvert.SerializeObject(myObject);

            return jsonString;

        }
        [HttpGet("[action]")]
        public object GetPreset(int ClientID, int ChannelID,int ModeID)
        {
            return _objField.GetPreset(ClientID, ChannelID, ModeID);
        }
        [HttpGet("[action]")]
        public object GetVendorFieldList(string ClientId)
        {
            return _objField.GetVendorFields(ClientId);
        }
        [HttpGet("[action]")]
        public object GetDateFormats()
        {
            return _objField.GetDateFormats();
        }
        [HttpGet("[action]")]
        public object GetChannelFieldList(string ClientId)
        {
            return _objField.GetChannelFields(ClientId);
        }

        [HttpGet("[action]")]
        public object GetModeFieldList(string ClientId, int ChannelID)
        {
            return _objField.GetModeFields(ClientId, ChannelID);
        }

        [HttpGet("[action]")]
        public object GetReconType()
        {
            return _objField.GetReconType();
        }
        [HttpGet("[action]")]
        public object GetReconTables(int ChannelID, int ModeID)
        {
            return _objField.GetReconTables(ChannelID, ModeID);
        }
        [HttpGet("[action]")]
        public object GetOperations()
        {
            return _objField.GetOperations();
        }
        [HttpGet("[action]")]
        public object GetParameters()
        {
            return _objField.GetParameters();
        }
        [HttpGet("[action]")]
        public object GetReconColumns(string Tablename)
        {
            return _objField.GetReconColumns(Tablename);
        }
        [HttpGet("[action]")]
        public object GetReconAliasColumns(int ChannelID, int ModeID, int VendorType, int Type)
        {
            return _objField.GetReconAliasColumns(ChannelID, ModeID, VendorType, Type);
        }

        [HttpGet("[action]")]
        public object GetFormatIdFieldList(string ClientID, string VendorID, int ChannelID, string ModeID)
        {
            return _objField.GetFormatIdFields(ClientID, VendorID, ChannelID, ModeID);
        }

        [HttpGet("[action]")]
        public object GetFieldIdentificationDetailsList(string ClientID, string VendorID, int ChannelID, string ModeID, string FormatID)
        {
            return _objField.GetFieldIdentificationDetails(ClientID, VendorID, ChannelID, ModeID, FormatID);
        }

        [HttpGet("[action]")]
        public object GetFieldIdentificationVendorDetailsList(string VendorID, int ChannelID)
        {
            return _objField.GetFieldIdentificationVendorDetails(VendorID, ChannelID);
        }

        [HttpGet("[action]")]
        public object CaseOutputList(string ClientID)
        {
            return _objField.CaseOutputList(ClientID);
        }

        [HttpGet("[action]")]
        public object GetReconTableList(int ChannelID, int ModeID)
        {
            return _objField.GetReconTableList(ChannelID, ModeID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetChannelOptionList(string ClientId)
        {
            return _objField.GetChannelOptions(ClientId);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetModeOptionList(string ClientId, string ChannelID)
        {
            List<ModeOptionModel> modeOptionModels = _objField.GetModeOptions(ClientId, ChannelID);

            if (ChannelID == "7")
            {
                ModeOptionModel modeOptionModel = new ModeOptionModel();
                modeOptionModel.ModeID = "0";
                modeOptionModel.ModeName = "All";
                modeOptionModels.Add(modeOptionModel);
            }

            return modeOptionModels;
        }

        [HttpPost("[action]")]
        public string AddUpdateReconFileConfig(ASPTrace.Models.ReconConfigModel reconConfigModel)
        {
            try
            {                
                string MSG = string.Empty;

                List<OptionModel> ReconTables = JsonConvert.DeserializeObject<List<OptionModel>>(reconConfigModel.ReconTables);

                ReconConfigTableModel reconConfigTableModel = new ReconConfigTableModel();

                foreach (OptionModel obj in ReconTables)
                {
                    if (obj.value == "1")
                    {
                        reconConfigTableModel.Table1 = obj.label == "CBS" ? "GL" : obj.label;
                    }
                    else if (obj.value == "2")
                    {
                        reconConfigTableModel.Table2 = obj.label == "CBS" ? "GL" : obj.label;
                    }
                    else if (obj.value == "3")
                    {
                        reconConfigTableModel.Table3 = obj.label == "CBS" ? "GL" : obj.label;
                    }
                    else if (obj.value == "4")
                    {
                        reconConfigTableModel.Table4 = obj.label == "CBS" ? "GL" : obj.label;
                    }
                }

                string res = _objField.AddUpdateReconImportConfig(reconConfigModel, reconConfigTableModel);

                if (res == "Save")
                {
                    MSG = "Configured successfully";
                }
                else
                {
                    MSG = "Error Occurred";
                }

                return MSG;
            }
            catch (Exception ex)
            {
                return "Failure :" + ex.Message;
            }

        }

        [HttpGet("[action]")]
        public object GetReconConfigGrid(string ClientID, string ChannelID, string ModeID, string ReconType)
        {
            return _objField.GetReconConfigGrid(ClientID, ChannelID, ModeID, ReconType);
        }

        [HttpGet("[action]")]
        public object GetSelectedTables(string ClientID, string ChannelID, string ModeID, string ReconType)
        {
            return _objField.GetSelectedTables(ClientID, ChannelID, ModeID, ReconType);
        }

        [HttpPost("[action]")]
        public object UploadFile([FromForm] ASPTrace.Models.DynamicImportFileModel file)
        {
            string MSG = string.Empty;
            DynamicImportFileStatus dynamicImportFileStatus = new DynamicImportFileStatus();

            try
            {
                if (file.ImportFile == null)
                {
                    MSG = "Error : File not selected";
                }
                else
                {
                    Guid objGuid = Guid.NewGuid();

                    string sFileExt1 = System.IO.Path.GetExtension(file.ImportFile.FileName);

                    string sFileName = "Trace_" + objGuid.ToString().Replace("-", "") + sFileExt1;

                    string path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\ReconConfig\\", sFileName);

                    using (System.IO.Stream stream = new System.IO.FileStream(path, System.IO.FileMode.Create))
                    {
                        file.ImportFile.CopyTo(stream);
                    }

                    string res = _objField.AddUpdateReconFileConfig(file, sFileName, path, file.ImportFile.FileName);

                    if (Convert.ToInt32(res) > 0)
                    {
                        if (sFileExt1 == ".xls" || sFileExt1 == ".xlsx")
                        {
                            dynamicImportFileStatus.Type = "Excel";
                            dynamicImportFileStatus.MSG = "Success";
                            dynamicImportFileStatus.FileConfigID = res;
                        }
                        else
                        {
                            dynamicImportFileStatus.Type = "Invalid";
                            dynamicImportFileStatus.MSG = "Format Not Found";
                            dynamicImportFileStatus.FileConfigID = "0";
                        }
                    }
                    else
                    {
                        dynamicImportFileStatus.Type = "Invalid";
                        dynamicImportFileStatus.MSG = "Error Occurred";
                        dynamicImportFileStatus.FileConfigID = "0";
                    }
                }

            }
            catch (Exception ex)
            {
                dynamicImportFileStatus.Type = "Error";
                string s = file.ImportFile != null ? file.ImportFile.FileName : "No File";
                dynamicImportFileStatus.MSG = "" + s + "<br/>" + ex.Message + "";
            }
            return dynamicImportFileStatus;
        }

        [HttpGet("[action]")]
        public object GetDynamicImportFileConfig(string FileConfigID)
        {
            return _objField.GetDynamicImportFileConfig(FileConfigID);
        }

        [HttpGet("[action]")]
        public object GetExcelDataTable(string FileConfigID)
        {
            DynamicImportFileConfigModel dynamicImportFileConfigModel = _objField.GetDynamicImportFileConfig(FileConfigID);

            if (dynamicImportFileConfigModel != null)
            { 
                return ExcelTable(dynamicImportFileConfigModel.FilePath);  
            }
            else
            {
                return new DataTable();
            }
        }

        [HttpGet("[action]")]
        public object GetXMLSchemaColumn(string FileConfigID)
        {
            return _objField.GetXMLSchemaColumn(FileConfigID);
        }

        [HttpGet("[action]")]
        public object GetConfiguredColumnString(string FileConfigID)
        {
            return _objField.GetConfiguredColumnJsonString(FileConfigID); 
        }

        private DataTable ExcelTable(string path)
        {
            DataTable dataTable = new DataTable();
            DataTable dt = new DataTable();
            int TotalCount = 0;

            String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
            System.Data.OleDb.OleDbConnection objConn;
            string extension = Path.GetExtension(path);
            DataTable dtexcelsheetname = null;

            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR=YES'";

            connString = string.Format(connString, path);

            try
            {
                objConn = new OleDbConnection(connString);
                objConn.Open();
            }
            catch (Exception ex)
            {
                connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";

                objConn = new OleDbConnection(connString);
                objConn.Open();
            }

            using (OleDbConnection connExcel = new OleDbConnection(connString))
            {
                using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                {
                    connExcel.Open();
                    //Get the name of First Sheet. 
                    dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    connExcel.Close();
                }
            }

            String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
            int j = 0;
            foreach (DataRow row in dtexcelsheetname.Rows)
            {
                DataTable dtSheet = new DataTable();
                excelSheets[j] = row["TABLE_NAME"].ToString();
                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                try
                {
                    OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);

                    da.Fill(dtSheet);

                    objConn.Close();
                }
                catch  
                {
                    objConn.Close();
                }

                TotalCount = dtSheet.Rows.Count;

                if (dtSheet.Rows.Count >= 1)
                {
                    dataTable = dtSheet;

                    for (int i = dataTable.Rows.Count - 1; i >= 4; i--)
                    {
                        dataTable.Rows.RemoveAt(i);
                    }

                    List<DataRow> nonDigitRows = new List<DataRow>();
                    for (int i = dataTable.Rows.Count - 1; i >= 0; i--)
                    {
                        string concatenatedString = string.Join("", dataTable.Rows[i].ItemArray);


                        bool containsDigit = concatenatedString.Any(char.IsDigit);

                        if (!containsDigit)
                        {
                            DataRow headerRow = dataTable.Rows[i];

                            // Rename the columns in the DataTable based on the values in the header row
                            for (int columnIndex = 0; columnIndex < dataTable.Columns.Count; columnIndex++)
                            {
                                dataTable.Columns[columnIndex].ColumnName = headerRow[columnIndex].ToString();
                            }

                            // Remove the header row from the DataTable (optional)
                            dataTable.Rows.Remove(headerRow);

                            for (int NonHeader = i; NonHeader >= 0; NonHeader--)
                            {
                                dataTable.Rows.RemoveAt(NonHeader);
                            }
                            break;
                        }
                    }


                } 

                break;
            }
              


            return dataTable;
        }

        [HttpPost("[action]")]
        public object UpdateMappedColumn(DynamicFileMappedColumn objModel)
        {
            return _objField.UpdateMappedColumnString(objModel);
        }

        [HttpGet("[action]")]
        public object GetReconFileConfigData(string FileConfigID)
        {
            return _objField.GetDynamicReconFileConfigData(FileConfigID);
        }

        [HttpGet("[action]")]
        public object GetDynamicRawTableColumns(string FileConfigID)
        {
            string ConfiguredColumns = _objField.GetConfiguredRawColumnString(FileConfigID);

            if (ConfiguredColumns != null && ConfiguredColumns.Length > 0)
            {
                return JsonConvert.DeserializeObject<List<ReconAliasColumnsModel>>(ConfiguredColumns);
            }
            else
            {
                return _objField.GetRawTableSelectedColumns(FileConfigID);
            }
        }

        [HttpPost("[action]")]
        public object UpdateXMLString(DynamicFileXMLModel objModel)
        {
            if (Convert.ToInt32(objModel.FileConfigID) > 0)
            {

                List<ReconAliasColumnsModel> arrayOfRawColumns = JsonConvert.DeserializeObject<List<ReconAliasColumnsModel>>(objModel.RawColumnString);

                List<DynamicFileMappedColumnModel> arrayOfMappedColumns = JsonConvert.DeserializeObject<List<DynamicFileMappedColumnModel>>(objModel.MappedColumnString);

                DynamicImportFileConfigModel dynamicImportFileConfigModel = _objField.GetDynamicImportFileConfig(objModel.FileConfigID);

                string TableName = dynamicImportFileConfigModel.TableName; 

                List<RawTableColumn> rawColumns = _objField.GetRawTableAllColumns(objModel.FileConfigID);

                string commaSeparatedString = "Amount2,Amount3,FileName,FilePath,FileDate,CreatedOn,ModifiedOn,CreatedBy,ModifiedBy,ECardNumber";

                string[] stringArray = commaSeparatedString.Split(',');

                string sqlQuery = "Select ";



                foreach (RawTableColumn objRow in rawColumns)
                {
                    ReconAliasColumnsModel objRawColumn = arrayOfRawColumns.FirstOrDefault(x => x.AliasColumn == objRow.ColumnName);

                    if (objRawColumn != null && objRawColumn.IsChanged)
                    {
                        if (objRawColumn.CaseCondition.Length > 0)
                        {
                            sqlQuery += objRawColumn.CaseCondition + ", ";
                        }
                        else if (objRawColumn.DataColumn == objRawColumn.AliasColumn)
                        {
                            sqlQuery += objRawColumn.DataColumn + ", ";
                        }
                        else if (objRawColumn.DataColumn != objRawColumn.AliasColumn)
                        {
                            sqlQuery += objRawColumn.DataColumn + " as " + objRawColumn.AliasColumn + ", ";
                        }
                    }
                    else
                    {
                        if (objRow.ColumnName == "ClientID")
                        {
                            sqlQuery += dynamicImportFileConfigModel.ClientID + " as " + objRow.ColumnName + ", ";
                        }
                        else if (objRow.ColumnName == "ChannelID")
                        {
                            sqlQuery += dynamicImportFileConfigModel.ChannelID + " as " + objRow.ColumnName + ", ";
                        }
                        else if (objRow.ColumnName == "NoOfDuplicate")
                        {
                            sqlQuery += "";
                        }
                        else if (Array.Exists(stringArray, s => s.Trim() == objRow.ColumnName))
                        {
                            sqlQuery +=  objRow.ColumnName + ", ";
                        }
                        else
                        {
                            sqlQuery +=  " NULL as " + objRow.ColumnName + ", ";
                        }
                    }
                    objRawColumn = null;
                }

                sqlQuery = sqlQuery.Trim();

                if (sqlQuery.EndsWith(","))
                {
                    sqlQuery = sqlQuery.Substring(0, sqlQuery.Length - 1);
                }


                sqlQuery += "  From #" + TableName;


                List<ReconAliasColumnsModel> XMLSchemaColumnList = _objField.GetXMLSchemaColumn(objModel.FileConfigID);

                string xmlContent = "<? xml version = \"1.0\" encoding = \"utf-16\" ?><FileFormat>";

                foreach (ReconAliasColumnsModel objXML in XMLSchemaColumnList)
                {
                    DynamicFileMappedColumnModel objRawColumn = arrayOfMappedColumns.FirstOrDefault(x => x.MappedColumn == objXML.AliasColumn);

                    if (objRawColumn != null && Convert.ToInt32(objRawColumn.Position) > 0)
                    {
                        xmlContent += "<" + objRawColumn.MappedColumn + ">" + objRawColumn.Position + "<" + objRawColumn.MappedColumn + ">";
                    }
                    else
                    {
                        xmlContent += "<" + objXML.AliasColumn + ">" + "0" + "<" + objXML.AliasColumn + ">";
                    }
                }
                xmlContent += "</FileFormat>";

                objModel.XMLString = xmlContent;
                objModel.QueryString = sqlQuery;

                return _objField.UpdateQueryXMLString(objModel);
            }
            else
            {
                return "Not Found";
            }
            
        }

       
    }
}