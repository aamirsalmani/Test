﻿using System; 
using System.Data; 
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;  
using OfficeOpenXml.Style;
using OfficeOpenXml;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Utility;  
using Newtonsoft.Json; 

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        private readonly IReport _objReport;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;

        public ReportController(IReport objReport, IConfiguration Configuration, ASPTrace.Contracts.ICommon Common)
        {
            _objReport = objReport;
            _configuration = Configuration;
            _objCommon = Common;
        }
        //Unmatched Report
        [Route("[action]")]
        [HttpPost]
        public IActionResult GetUnmatchedTxnsList(InputUnmatchedReportModel unmatchedTxnsModel, int pageNumber, int pageSize) //,string searchBar
        {
            DailyReportInputReportModel searchModel = new DailyReportInputReportModel();
            searchModel.ChannelID = unmatchedTxnsModel.ChannelID;
            searchModel.ClientID = unmatchedTxnsModel.ClientID;
            searchModel.ModeID = unmatchedTxnsModel.ModeID;
            searchModel.TerminalID = unmatchedTxnsModel.TerminalID;
            searchModel.TxnType = unmatchedTxnsModel.TxnType;
            searchModel.FromDate = unmatchedTxnsModel.FromDate;
            searchModel.ToDate = unmatchedTxnsModel.ToDate;
            searchModel.search = unmatchedTxnsModel.search;

            var result = _objReport.GetUnmatchedTxnsReport(searchModel, pageNumber, pageSize);
            Console.Write(unmatchedTxnsModel.search);
            // If result is null, return an empty object with total record count as 0
            if (result.Data == null || result.Data.Count == 0)
            {
                return Ok(new
                {   
                    Data = new List<dynamic>(),
                    TotalRecords = 0
                });
            }

            return Ok(new
            {
                Data = result.Data,
                TotalRecords = result.TotalRecords
            });
        }

        [Route("[action]")]
        [HttpPost]
        public IActionResult GetReconTxnsList(InputReconReportModel reportModel, int pageNumber, int pageSize) //,string searchBar
        {
            var result = new PaginatedResult
            {
                Data = new List<dynamic>(),
                TotalRecords = 0
            };

            DailyReportInputReportModel searchModel = new DailyReportInputReportModel();
            searchModel.ChannelID = reportModel.ChannelID;  
            searchModel.ClientID = reportModel.ClientID;
            searchModel.ModeID = reportModel.ModeID;
            searchModel.TerminalID = reportModel.TerminalID;
            searchModel.TxnType = reportModel.TxnType;
            searchModel.FromDate = reportModel.FromDate;
            searchModel.ToDate = reportModel.ToDate;
            searchModel.search = reportModel.search;

            if (reportModel.ReportType == "Unmatched")
            {
                result = _objReport.GetUnmatchedTxnsReport(searchModel, pageNumber, pageSize);
            }
            else if (reportModel.ReportType == "Matched")
            {
                result = _objReport.GetMatchedTxnsReport(searchModel, pageNumber, pageSize);
            }
            else if (reportModel.ReportType == "Unsuccessful")
            {
                result = _objReport.GetUnsuccessfulTxnsReport(searchModel, pageNumber, pageSize);
            }
            else if (reportModel.ReportType == "Reversal")
            {
                result = _objReport.GetReversalTxnsReport(searchModel, pageNumber, pageSize);
            }
            else if (reportModel.ReportType == "Duplicate")
            {
                result = _objReport.GetDuplicateTxnsReport(searchModel, pageNumber, pageSize);
            }


            //Console.Write(unmatchedTxnsModel.search);
            // If result is null, return an empty object with total record count as 0
            if (result.Data == null || result.Data.Count == 0)
            {
                return Ok(new
                {
                    Data = new List<dynamic>(),
                    TotalRecords = 0
                });
            }

            return Ok(new
            {
                Data = result.Data,
                TotalRecords = result.TotalRecords
            });
        }

  

        [Route("[action]")]
        [HttpPost]
        public object GetUnmatchedTxnByReferenceNumberList(InputReferenceNumberModel unmatchedTxnsModel)
        {
            TxnByReferenceNumber unmatchedTxnByReferenceNumbers = _objReport.GetUnmatchedTxnByReferenceNumberReport(unmatchedTxnsModel); 
             
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim(); 

            foreach (TxnDetailsModel unmatchedTxnDetailsModel in unmatchedTxnByReferenceNumbers.EJTxnDetails)
            {
                try
                {
                    unmatchedTxnDetailsModel.CardNumber = AesEncryption.DecryptString(unmatchedTxnDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            foreach (TxnDetailsModel unmatchedTxnDetailsModel in unmatchedTxnByReferenceNumbers.GLTxnDetails)
            {
                try
                {
                    unmatchedTxnDetailsModel.CardNumber = AesEncryption.DecryptString(unmatchedTxnDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            foreach (TxnDetailsModel unmatchedTxnDetailsModel in unmatchedTxnByReferenceNumbers.NWTxnDetails)
            {
                try
                {
                    unmatchedTxnDetailsModel.CardNumber = AesEncryption.DecryptString(unmatchedTxnDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            foreach (TxnDetailsModel unmatchedTxnDetailsModel in unmatchedTxnByReferenceNumbers.SWTxnDetails)
            {
                try
                {
                    unmatchedTxnDetailsModel.CardNumber = AesEncryption.DecryptString(unmatchedTxnDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            return unmatchedTxnByReferenceNumbers;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetTxnsDetailsByReferenceNumberList(InputReferenceNumberModel unmatchedTxnsModel)
        {
            TxnDetailsByReferenceNumber model = _objReport.GetTxnsReportByReferenceNumber(unmatchedTxnsModel); 

            return model;
        }


        //Matched Report
        [Route("[action]")]
        [HttpPost]
        public IActionResult GetMatchedTxnsList(DailyReportInputReportModel matchedTxnsModel, int pageNumber, int pageSize)
        {
            var result  = _objReport.GetMatchedTxnsReport(matchedTxnsModel, pageNumber, pageSize);

            if (result.Data == null || result.Data.Count == 0)
            {
                return Ok(new
                {
                    Data = new List<dynamic>(),
                    TotalRecords = 0
                });
            }

            return Ok(new
            {
                Data = result.Data,
                TotalRecords = result.TotalRecords
            });

        }

        [Route("[action]")]
        [HttpPost]
        public object GetMatchedTxnByReferenceNumberList(InputReferenceNumberModel matchedTxnsModel)
        {
            TxnDetailsByReferenceNumber matchedTxnByReferenceNumbers = _objReport.GetTxnsReportByReferenceNumber(matchedTxnsModel);

            return matchedTxnByReferenceNumbers;
        }


        //Reversal Report 
        [Route("[action]")]
        [HttpPost]
        public object GetReversalTxnsList(DailyReportInputReportModel reversalTxnsModel, int pageNumber, int pageSize)
        {
            var result = _objReport.GetReversalTxnsReport(reversalTxnsModel, pageNumber, pageSize); 

            return result.Data;

        }

   
 
        //Unsuccessful Report
        [Route("[action]")]
        [HttpPost]
        public IActionResult GetUnsuccessfulTxnsList(DailyReportInputReportModel unsuccessfulTxnsModel, int pageNumber, int pageSize)
        {
            var  unsuccessfulTxnsReportModelList = _objReport.GetUnsuccessfulTxnsReport(unsuccessfulTxnsModel, pageNumber, pageSize);

            if (unsuccessfulTxnsReportModelList.Data == null || unsuccessfulTxnsReportModelList.Data.Count == 0)
            {
                return Ok(new
                {
                    Data = new List<dynamic>(),
                    TotalRecords = 0
                });
            }

            return Ok(new
            {
                Data = unsuccessfulTxnsReportModelList.Data,
                TotalRecords = unsuccessfulTxnsReportModelList.TotalRecords
            });

        }

      

        //Duplicate Report
        [Route("[action]")]
        [HttpPost]
        public object GetDuplicateTxnsList(DailyReportInputReportModel duplicateTxnsModel, int pageNumber, int pageSize)
        {
            var result = _objReport.GetDuplicateTxnsReport(duplicateTxnsModel, pageNumber, pageSize);
            return result.Data;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetPosDmsTxnsList(DailyReportInputReportModel PosDmsTxnsModel)
        {
            List<dynamic> dmsTxnsReportList = _objReport.GetPosDmsTxnsReports(PosDmsTxnsModel); 

            return dmsTxnsReportList;
        }
 

        [Route("[action]")]
        [HttpGet]       
        public object GetAdjustmentTerminalDetailsList(string UserName, string ClientID)
        {
            return _objReport.GetAdjustmentTerminalDetails(UserName, ClientID);
        }

        [Route("[action]")]
        [HttpGet]        
        public object GetAdjustmentModeList(string ClientID, string ChannelID)
        {
            return _objReport.GetAdjustmentMode(ClientID, ChannelID);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetAdjustmentTxnsReportList(AdjustmentTxnsModel adjustmentTxnsModel)
        {
            return _objReport.GetAdjustmentTxnsReport(adjustmentTxnsModel);
        }

        //File Status Report
        [Route("[action]")]
        [HttpPost]
        public object GetFileStatusReportDetailsList(FileStatusReportModel fileStatusReportModel)
        {
            return _objReport.GetFileStatusReportDetails(fileStatusReportModel);
        }

        //Dispense Unmatched Report
        [Route("[action]")]
        [HttpPost]
        public object GetDispenseUnmatchedReportList(DispenseUnmatchedModel dispenseUnmatchedModel)
        {
            if (dispenseUnmatchedModel.ModeID == "1")
            {
                dispenseUnmatchedModel.ModeID = "2";
            }
            else if (dispenseUnmatchedModel.ModeID == "2")
            {
                dispenseUnmatchedModel.ModeID = "3";
            }
            else if (dispenseUnmatchedModel.ModeID == "3")
            {
                dispenseUnmatchedModel.ModeID = "3";
            }
            else if (dispenseUnmatchedModel.ModeID == "4")
            {
                dispenseUnmatchedModel.ModeID = "4";
            }
            else if (dispenseUnmatchedModel.ModeID == "5")
            {
                dispenseUnmatchedModel.ModeID = "5";
            }

            List<DispenseUnmatchedReportModel> dispenseUnmatchedReportList = _objReport.GetDispenseUnmatchedReport(dispenseUnmatchedModel); 
 
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim(); 

            foreach (DispenseUnmatchedReportModel dispenseUnmatchedReportModel in dispenseUnmatchedReportList)
            {
                try
                {
                    dispenseUnmatchedReportModel.CardNumber = AesEncryption.DecryptString(dispenseUnmatchedReportModel.CardNumber);
                }
                catch
                {

                }
            }

            return dispenseUnmatchedReportList;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetDispenseUnmatchedReportByReferenceNumberClickList(DispenseUnmatchedReferenceNumberModel dispenseUnmatchedModel)
        {

            DispenseUnmatchedReportByReferenceNumberClick dispenseUnmatchedReportByReferenceNumberClicks = _objReport.GetDispenseUnmatchedReportByReferenceNumberClick(dispenseUnmatchedModel);
 
            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();
            
            

            foreach (DispenseUnmatchedDetailsModel dispenseUnmatchedDetailsModel in dispenseUnmatchedReportByReferenceNumberClicks.EJTxnDetails)
            {
                try
                {
                    dispenseUnmatchedDetailsModel.CardNumber = AesEncryption.DecryptString(dispenseUnmatchedDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            foreach (DispenseUnmatchedDetailsModel dispenseUnmatchedDetailsModel in dispenseUnmatchedReportByReferenceNumberClicks.GLTxnDetails)
            {
                try
                {
                    dispenseUnmatchedDetailsModel.CardNumber = AesEncryption.DecryptString(dispenseUnmatchedDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            foreach (DispenseUnmatchedDetailsModel dispenseUnmatchedDetailsModel in dispenseUnmatchedReportByReferenceNumberClicks.NWTxnDetails)
            {
                try
                {
                    dispenseUnmatchedDetailsModel.CardNumber = AesEncryption.DecryptString(dispenseUnmatchedDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            foreach (DispenseUnmatchedDetailsModel dispenseUnmatchedDetailsModel in dispenseUnmatchedReportByReferenceNumberClicks.SWTxnDetails)
            {
                try
                {
                    dispenseUnmatchedDetailsModel.CardNumber = AesEncryption.DecryptString(dispenseUnmatchedDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            return dispenseUnmatchedReportByReferenceNumberClicks;
        }

        //-------------------------------------------------nk----------------------------------------------//
        [Route("[action]")]
        [HttpPost]
        public object GetALLTTUMReportDetailsList(AllTTUMReportModelNew allTTUMReportModel)
        {
            return _objReport.GetALLTTUMReportDetailsList(allTTUMReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object UpdateCheckedDataNew(UpdateNewCheckerModel updateCheckerModel)
        {
            return _objReport.UpdateCheckedDataNew(updateCheckerModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object UpdateCheckedData(UpdateCheckerModel updateCheckerModel)
        {
            DataTable dataTable;
            try
            {
                var reportItems = System.Text.Json.JsonSerializer.Deserialize<List<CreditAdjustmentTTUMData>>(updateCheckerModel.TempTTumReport);

                dataTable = ToDataTable(reportItems);
            }
            catch (System.Text.Json.JsonException ex)
            {
                return BadRequest($"Error deserializing TempTTumReport: {ex.Message}");
            }

            return _objReport.UpdateCheckedData(updateCheckerModel, dataTable);
        }

        private DataTable ToDataTable<T>(List<T> items)
        {
            var dataTable = new DataTable();

            if (items == null || !items.Any())
            {
                return dataTable;
            }

            // Get the type of the items
            var itemType = typeof(T);

            // Get the properties of the item type
            var properties = itemType.GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);

            // Create columns based on properties
            foreach (var property in properties)
            {
                dataTable.Columns.Add(property.Name, Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType);
            }

            // Add rows to the DataTable
            foreach (var item in items)
            {
                var row = dataTable.NewRow();
                foreach (var property in properties)
                {
                    row[property.Name] = property.GetValue(item) ?? DBNull.Value;
                }
                dataTable.Rows.Add(row);
            }

            return dataTable;
        }


        [Route("[action]")]
        [HttpPost]
        public object GetCreditAdjustmentTTUM(NPCIAllTTUMReportModel allTTUMReportModel)
        {
            return _objReport.GetCreditAdjustmentTTUM(allTTUMReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object ExportCheckedExcelReport(ReportModel allTTUMReportModel)
        {

            var serializedArray = allTTUMReportModel.Report;
            List<dynamic> Report = DeserializeArray(serializedArray);

            Console.WriteLine($"Number of items in Report list: {Report.Count}");  

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                // Get column names from the first item's properties (dynamic)
                var firstItem = Report.FirstOrDefault() as IDictionary<string, object>;
                if (firstItem != null)
                {
                    // Get all headers, then skip the first four columns
                    var headers = firstItem.Keys.Skip(4).ToList();

                    // Load headers into the worksheet
                    for (int i = 0; i < headers.Count; i++)
                    {
                        worksheet.Cells[1, i + 1].Value = headers[i];
                    }

                    // Load data rows into the worksheet
                    for (int rowIndex = 0; rowIndex < Report.Count; rowIndex++)
                    {
                        var rowData = Report[rowIndex] as IDictionary<string, object>;
                        if (rowData != null)
                        {
                            for (int colIndex = 0; colIndex < headers.Count; colIndex++)
                            {
                                var header = headers[colIndex];
                                // Ensure to check if the header exists in the row data
                                worksheet.Cells[rowIndex + 2, colIndex + 1].Value = rowData.ContainsKey(header) ? rowData[header] : null;
                            }
                        }
                    }

                    // Apply styling to headers
                    using (var range = worksheet.Cells[1, 1, 1, headers.Count])
                    {
                        range.Style.Font.Bold = true;
                        range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    }

                    // Apply borders to all cells
                    using (var range = worksheet.Cells[1, 1, Report.Count + 1, headers.Count])
                    {
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    }
                }

                // Convert the package to a byte array
                byte[] fileContents = package.GetAsByteArray();

                // Return the Excel file as a download
                return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"UnmatchedTxnsReport_.xlsx");
            }
        }
        private List<dynamic> DeserializeArray(string serializedArray)
        {
            if (string.IsNullOrEmpty(serializedArray))
            {
                throw new ArgumentException("Serialized array cannot be null or empty.");
            }

            try
            {
                return JsonConvert.DeserializeObject<List<dynamic>>(serializedArray);
            }
            catch (System.Text.Json.JsonException ex)
            {
                throw new InvalidOperationException("Failed to deserialize the array.", ex);
            }
        }

        [Route("[action]")]
        [HttpPost]
        public object TTUMExportExcelReport(AllTTUMReportModelNew allTTUMReportModel)
        {

            DataTable Report = _objReport.GetALLTTUMReportDataTable(allTTUMReportModel);


            Report.Columns.Remove("ID");
            Report.Columns.Remove("MakerID");
            Report.Columns.Remove("MakerRemark");
            Report.Columns.Remove("CheckerID");
            Report.Columns.Remove("CheckerRemark");

            // Debugging point to check count
            Console.WriteLine($"Number of items in Report list: {Report.Rows.Count}");

         
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                // Debugging point
                Console.WriteLine($"Number of columns in Report DataTable: {Report.Columns.Count}");

                // Load the DataTable into the worksheet, starting from cell A1  //typeof(UnmatchedTxnsReportModel).GetProperties().Length
                worksheet.Cells["A1"].LoadFromDataTable(Report, PrintHeaders: true);

                using (var range = worksheet.Cells[1, 1, 1, Report.Columns.Count])
                {
                    range.Style.Font.Bold = true;
                    range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightBlue);
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                // Format all cells with borders  //typeof(UnmatchedTxnsReportModel).GetProperties().Length]
                using (var range = worksheet.Cells[1, 1, Report.Rows.Count + 1, Report.Columns.Count])
                {
                    range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }


                // Convert the package to a byte array
                byte[] fileContents = package.GetAsByteArray();

                // Return the Excel file as a download
                return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"TTUMReport.xlsx");
            }

        }

        [Route("[action]")]
        [HttpPost]
        public object GetSettelmentTTUMReport(AllTTUMReportModelNew aTMTtumReportModel)
        {
            return _objReport.GetSettelmentTTUMReport(aTMTtumReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetTipsAndSurchargeTTUMReport(AllTTUMReportModelNew aTMTtumReportModel)
        {
            return _objReport.GetTipsAndSurchargeTTUMReport(aTMTtumReportModel);
        }
        //-------------------------------------------------nk----------------------------------------------//

        [Route("[action]")]
        [HttpPost]
        public object GetATMTtumReportDetailsList(ATMTtumReportModel aTMTtumReportModel)
        {
            return _objReport.GetATMTtumReportDetails(aTMTtumReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetIMPSTTUMReportDetailsList(IMPSTTUMReportModel iMPSTTUMReportModel)
        {
            return _objReport.GetIMPSTTUMReportDetails(iMPSTTUMReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetIMPSTTUMInsertReportDetailsList(IMPSTTUMInsertReportModel iMPSTTUMInsertReportModel)
        {
            return _objReport.GetIMPSTTUMInsertReportDetails(iMPSTTUMInsertReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetIMPSSettlementReportDetailsList(IMPSSettlementReportModel iMPSSettlementReportModel)
        {

            System.Data.DataTable dt = _objReport.GetIMPSSettlementReport(iMPSSettlementReportModel);

            DynamicTable dynamicTable = new DynamicTable();

            dynamicTable.Columns = Common.GetColumns(dt);

            dynamicTable.JsonData = Common.DataTableToJSONWithJSONNet(dt);

            return dynamicTable;
        }

        //[Route("[action]")]
        //[HttpPost]
        //public object GetBankSettlementReportDetailsList(BankReportModel bankSettlementReportModel)
        //{
        //    return _objReport.GetBankSettlementReportDetails(bankSettlementReportModel);
        //}

        [Route("[action]")]
        [HttpPost]
        public object GetIssuerTransactionTTUMReportDetailsList(IssuerTransactionTTUMReportModel issuerTransactionTTUMReportModel)
        {
            return _objReport.GetIssuerTransactionTTUMReportDetails(issuerTransactionTTUMReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetPendingAcqEntryReportDetailsList(PendingAcqEntryReportModel pendingAcqEntryReportModel)
        {
            return _objReport.GetPendingAcqEntryReportDetails(pendingAcqEntryReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetTipsAndSurchargeDetailsList(TipsAndSurchargeModel tipsAndSurchargeModel)
        {
            return _objReport.GetTipsAndSurchargeDetails(tipsAndSurchargeModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetUPISettlementReportDetailsList(UPISettlementReportModel uPISettlementReportModel)
        {
            return _objReport.GetUPISettlementReportDetails(uPISettlementReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetSuccessfulAmountCountReportDetailsList(SuccessfulAmountCountReportModel successfulAmountCountReportModel)
        {
            return _objReport.GetSuccessfulAmountCountReportDetails(successfulAmountCountReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetSettledTransactionsReportList(SettledTransactionsReportModel settledTransactionsReportModel)
        {
            return _objReport.GetSettledTransactionsReport(settledTransactionsReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetSettledTransactionsReportByReferenceNumberList(SettledTransactionsReportModel settledTransactionsReportModel)
        {
            return _objReport.GetSettledTransactionsReportByReferenceNumber(settledTransactionsReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetRefundCashbackTTUMReportDetailsList(RefundCashbackTTUMReportModel refundCashbackTTUMReportModel)
        {
            return _objReport.GetRefundCashbackTTUMReportDetails(refundCashbackTTUMReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetReasonWiseSummaryReportDetailsList(ReasonWiseSummaryReportModel reasonWiseSummaryReportModel)
        {
            return _objReport.GetReasonWiseSummaryReportDetails(reasonWiseSummaryReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetRefundTxnsReportDetailsList(RefundTxnsReportModel refundTxnsReportModel)
        {
            return _objReport.GetRefundTxnsReportDetails(refundTxnsReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetPOSTtumReportDetailsList(POSTtumReportModel pOSTtumReportModel)
        {
            return _objReport.GetPOSTtumReportDetails(pOSTtumReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public string DispenseSummaryJobInsert(InsertDispenseSummaryModel dispenseSummarytModel)
        {
            return _objReport.InsertDispenseSummaryJob(dispenseSummarytModel);
        }


        [Route("[action]")]
        [HttpPost]
        public object GetPOSSettlementReportDetailsList(POSSettlementReportModel pOSSettlementReportModel)
        {
            return _objReport.GetPOSSettlementReportDetails(pOSSettlementReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetDispenseSummaryDetailsList(DispenseSummaryModel dispenseSummarytModel)
        {
            return _objReport.GetDispenseSummaryDetails(dispenseSummarytModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetSwitchFeeReportList(SwitchFeeModel SwitchFeeModel)
        {
            return _objReport.GetSwitchFeeReportDetails(SwitchFeeModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetConsoleSetReportList(ConsoleSetModel ConsoleSetModel)
        {
            return _objReport.GetConsoleSetReportDetails(ConsoleSetModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetTxnCountDetailsList(TxnCountModel txnCountModel)
        {
            return _objReport.GetTxnCountDetails(txnCountModel);
        }

       
        [Route("[action]")]
        [HttpPost]
        public object GetTTUMDisputeReportDetailsList(TTUMReportModel tTUMReportModel)
        {
            if (tTUMReportModel.TTUMType == "IMPS-Dispute")
            {
                return _objReport.GetIMPSTTUMDisputeReportDetails(tTUMReportModel);
            }
            else if (tTUMReportModel.TTUMType == "UPI-Dispute")
            {
                return _objReport.GetUPITTUMDisputeReportDetails(tTUMReportModel);
            }
            else
            {
                return new List<UPI_TTUM_DisputeModel>();
            }
        }

        [Route("[action]")]
        [HttpPost]
        public object GetTimeOutReportList(TTUMReportModel tTUMReportModel)
        {
            return _objReport.GetTIMEOUTReportDetails(tTUMReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object Get_NPCI_BULK_UPLOAD_List(TTUMReportModel tTUMReportModel)
        {
            return _objReport.Get_NPCI_BULK_UPLOAD_Report(tTUMReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetDrcReportList(TTUMReportModel tTUMReportModel)
        {
            return _objReport.GetDrcReportDetails(tTUMReportModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetAllTerminals(int clientID)
        {
            return _objReport.GetTerminalOptions(clientID);

        }


        //Cash Tally Report

        [Route("[action]")]
        [HttpPost]
        public object GetCashTallyReportList(CashTallyReportModel cashTallyReportModel)
        {
            return _objReport.GetCashTallyReportDetail(cashTallyReportModel);
        }


        [Route("[action]")]
        [HttpPost]
        public object ExportCashTallyExcelReport(CashTallyReportModel cashTallyReportModel)
        {

            List<dynamic> Report = _objReport.GetCashTallyReportDetail(cashTallyReportModel);

            // Debugging point to check count
            Console.WriteLine($"Number of items in Report list: {Report.Count}");  

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (ExcelPackage package = new ExcelPackage())
            {
                // Add a new worksheet to the Excel package
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                // Get column names from the first item's properties (dynamic)
                var firstItem = Report.FirstOrDefault() as IDictionary<string, object>;
                if (firstItem != null)
                {
                    var headers = firstItem.Keys.ToList();

                    // Load headers into the worksheet
                    for (int i = 0; i < headers.Count; i++)
                    {
                        worksheet.Cells[1, i + 1].Value = headers[i];
                    }

                    // Load data rows into the worksheet
                    for (int rowIndex = 0; rowIndex < Report.Count; rowIndex++)
                    {
                        var rowData = Report[rowIndex] as IDictionary<string, object>;
                        if (rowData != null)
                        {
                            for (int colIndex = 0; colIndex < headers.Count; colIndex++)
                            {
                                worksheet.Cells[rowIndex + 2, colIndex + 1].Value = rowData[headers[colIndex]];
                            }
                        }
                    }

                    // Apply styling to headers
                    using (var range = worksheet.Cells[1, 1, 1, headers.Count])
                    {
                        range.Style.Font.Bold = true;
                        range.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    }

                    // Apply borders to all cells
                    using (var range = worksheet.Cells[1, 1, Report.Count + 1, headers.Count])
                    {
                        range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    }
                }

                // Convert the package to a byte array
                byte[] fileContents = package.GetAsByteArray();

                // Return the Excel file as a download
                return File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"CashTallyTxnsReport_.xlsx");
            }

        }

        [Route("[action]")]
        [HttpPost]
        public object GetCashTallyUnmatchedReportList(DispenseUnmatchedModel cashTallyReportModel)
        {
            return _objReport.GetCashTallyUnmatchedReport(cashTallyReportModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetDispenseSummaryJobDetails([FromQuery] GetDispenseSummaryJob dispenseSummarytModel)
        {
            return _objReport.GetDispenseSummaryJobDetails(dispenseSummarytModel);

        } 

    }
}