﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;  

namespace ASPTraceWebApi.Controllers;

    [Authorize(AuthenticationSchemes=JwtBearerDefaults.AuthenticationScheme)]
    [Route("api/[controller]")]
    [ApiController]
    public class RoleCreationController : ControllerBase
    {
        private readonly IRoleCreation _objRoleCreation;

        public RoleCreationController(IRoleCreation objRoleCreation)
        {
            _objRoleCreation = objRoleCreation;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetRoleList(string ClientID)
        {
            return _objRoleCreation.GetRole(ClientID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetRoleAccessRightsList(string ClientID, string RoleID)
        {
            return _objRoleCreation.GetRoleAccessRights(ClientID, RoleID);
        }

        [Route("[action]")]
        [HttpPost]
        public object RoleAddUpdate(RoleDetailsRegModel roleDetailsRegModel)
        {
            return _objRoleCreation.RoleAddUpdate(roleDetailsRegModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object AddUpdateRole(RoleDetailsRegModel roleDetailsRegModel)
        {
            return _objRoleCreation.AddUpdateRole(roleDetailsRegModel);
        } 

        [Route("[action]")]
        [HttpGet]
        public object GetRoleDetails(string ClientID , string RoleID)
        {
            return _objRoleCreation.GetRoleDetails(ClientID , RoleID);
        }

        [Route("[action]")]
        [HttpPost]
        public object DeleteRoleReg(DeleteRoleModel roleDetailsRegModel)
        {
            return _objRoleCreation.DeleteRoleReg(roleDetailsRegModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object AssignRoleAccessRights(AssignRoleAccessRightsModel assignRoleAccessRightsModel)
        {
            return _objRoleCreation.AssignRoleAccessRights(assignRoleAccessRightsModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object AssignRoleMenuAccessRights(AssignRoleMenuAccessRightsModel assignRoleAccessRightsModel)
        {
            return _objRoleCreation.AssignRoleMenuAccessRights(assignRoleAccessRightsModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetMenuAccessList(string UserID, string RoleID, string MenuLevel, string ClientID)
        {
            return _objRoleCreation.GetMenuAccess(UserID, RoleID, MenuLevel, ClientID);
        }


        [Route("[action]")]
        [HttpPost]
        public object AddUpdateRoleDetails(RoleDetailsModel roleDetailsModel)
        {
            return _objRoleCreation.AddUpdateRoleCore(roleDetailsModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetRoleMenuList(string RoleID)
        {
            return _objRoleCreation.GetRoleAccessRightsCore(RoleID);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetRoleAccessList(UserFilterModel2 userModel )
        {
            return _objRoleCreation.GetRoleAccessGrid(userModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object UpdateRoleStatus(ActionModel nModel)
        {
            return _objRoleCreation.ActionTakenByChecker(nModel);        
        }

        [Route("[action]")]
        [HttpGet]
        public object GetRoleMenuDetails(string RoleID)
        {
            return _objRoleCreation.GetRoleDetails(RoleID);
        }

        [Route("[action]")]
        [HttpPost]
        public object DeleteRole(DeleteRoleModel roleDetailsRegModel)
        {
            return _objRoleCreation.DeleteRoleCore(roleDetailsRegModel);
        }


        [Route("[action]")]
        [HttpPost]
        public object RemoveRole(ActionModel actionModel)
        {
            return _objRoleCreation.DeleteTempRoleCore(actionModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object UpdateApprovedRoleDetails(UserFilterModel2 userModel)
        {
            return _objRoleCreation.EditApprovedRole(userModel);
        }
}

