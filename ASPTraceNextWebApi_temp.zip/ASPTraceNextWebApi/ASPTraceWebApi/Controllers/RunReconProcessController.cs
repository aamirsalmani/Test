﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;
using System.Text;
using Utility;
using OfficeOpenXml.Table.PivotTable;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class RunReconProcessController : ControllerBase
    {
        private readonly IRunReconProcess _objRunReconProcess;

        public RunReconProcessController(IRunReconProcess objRunReconProcess)
        {
            _objRunReconProcess = objRunReconProcess;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetChannelRunReconProcessList(string ClientID)
        {
            return _objRunReconProcess.GetChannelRunReconProcess(ClientID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetModeRunReconProcessList(string ClientID, int ChannelID)
        {
            return _objRunReconProcess.GetModeRunReconProcess(ClientID, ChannelID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetRunReconHistoryRunReconProcessList(string ClientID,string ChannelID, string ModeId)
        {
            return _objRunReconProcess.GetRunReconHistoryRunReconProcess(ClientID,ChannelID,ModeId);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetRunReconAddRunReconProcessList(ReconStatusRunReconProcessModel reconStatusRunReconProcessModel)
        {
            return _objRunReconProcess.GetRunReconAddRunReconProcess(reconStatusRunReconProcessModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetRunReconFileStatusList(ReconFileStatusProcessModel reconFileStatusProcessModel)
        {
            return _objRunReconProcess.GetRunReconFileStatusList(reconFileStatusProcessModel);
        }

        [Route("[action]")]
        [HttpPost]
        public string ConfirmRunReconAdd(ReconStatusRunReconProcessModel reconStatusRunReconProcessModel)
        {
            return _objRunReconProcess.ConfirmRunReconAdd(reconStatusRunReconProcessModel);
        }

        [Route("[action]")]
        [HttpPost]
        public string ForceRunRecon([FromBody] ForceRunReconRequest model)
        {
            return _objRunReconProcess.ForceRunRecon(model);
        }



        [Route("[action]")]
        [HttpPost]
        public object GetDefaultFileUploadCount(ReconFileStatusListModel defaultFileCountProcessModel)
        {
            return _objRunReconProcess.GetDefaultFileUploadCount(defaultFileCountProcessModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetTtumReportJobList(NPCIReportModel unmatchedTxnsModel)
        {
            return _objRunReconProcess.GetTtumReportJobGrid(unmatchedTxnsModel); 
        }

        [Route("[action]")]
        [HttpPost]
        public object InsertTtumReportJob(NPCIReportModel nPCIReportModel)
        {
            return  _objRunReconProcess.AddTtumReportJob(nPCIReportModel);
        }


        [Route("[action]")]
        [HttpPost]
        public object GetTtumReportList(NPCIReportModel unmatchedTxnsModel)
        {
            List<dynamic> TxnsReportList = _objRunReconProcess.GetReportGrid(unmatchedTxnsModel);

            foreach (var item in TxnsReportList)
            {
                IDictionary<string, object> expando = item as IDictionary<string, object>;
                if (expando.ContainsKey("UTXID"))
                {
                    expando.Remove("UTXID"); // This works if your dynamic is an ExpandoObject
                }
            }

            return TxnsReportList;
        }

        [Route("[action]")]
        [HttpPost]
        public object UpdateStatusByMaker(NPCIReportModel nPCIReportModel)
        {
            return _objRunReconProcess.UpdateStatusByMaker(nPCIReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object UpdateStatusByChecker(NPCIReportModel nPCIReportModel)
        {
            return _objRunReconProcess.UpdateStatusByChecker(nPCIReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object DeleteRecord(DeleteReportModel reportModel)
        {
            return _objRunReconProcess.DeleteTransaction(reportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetCheckerMakerStatus(NPCIReportModel nPCIReportModel)
        {
            return _objRunReconProcess.GetCheckerMakerStatus(nPCIReportModel);
        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportExcelReport(NPCIReportModel nPCIReportModel)
        {
            return await Task.Run(async () =>
            {
                System.Data.DataTable dtReport = _objRunReconProcess.GetReportDataTable(nPCIReportModel); 

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", nPCIReportModel.UserName);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                string FileName =  nPCIReportModel.ReportType + ".xlsx";

                var fullPath = Path.Combine(folderPath, FileName);

                byte[] fileContents = Common.ExportExcel(dtReport);

                //if (fileContents != null)
                //{
                //    await System.IO.File.WriteAllBytesAsync(fullPath, fileContents);
                //}

                var objFile = File(fileContents, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"Excel.xlsx");

                return objFile; 

            });
        }

     

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> ExportCsvReport(NPCIReportModel nPCIReportModel)
        {
            //System.Data.DataTable dtReport = _objRunReconProcess.GetReportDataTable(nPCIReportModel); 

            //return File(Encoding.UTF8.GetBytes(Common.GenerateCsv(dtReport)), "text/csv", $"{nPCIReportModel.Remark}_{nPCIReportModel.FromDateTxns}.csv");

            return await Task.Run(async () =>
            {

                var folderPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Downloads", nPCIReportModel.UserName);
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                string FileName = nPCIReportModel.ReportType + ".csv";

                var fullPath = Path.Combine(folderPath, FileName);                

                try
                {
                    System.Data.DataTable dtReport = _objRunReconProcess.GetReportDataTable(nPCIReportModel);

                    var csv = Common.GenerateCsv(dtReport);

                    var bytes = Encoding.UTF8.GetBytes(csv);

                    IActionResult Data = File(bytes, "text/csv", FileName);

                    return Data;
                }
                catch (Exception ex)
                {
                    return NotFound("File Download Failed");
                }
            });
        }

        //Siddhant
        //Get File Details                                                
        [Route("[action]")]
        [HttpPost]
        public object GetUploadedFileList(ReconFileStatusListModel defaultFileCountProcessModel, string Filetype)
        {
            return _objRunReconProcess.GetUploadedFileList(defaultFileCountProcessModel, Filetype);
        }
    }
}