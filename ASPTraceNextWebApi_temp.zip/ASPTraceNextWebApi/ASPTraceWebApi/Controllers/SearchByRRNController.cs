﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks; 
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;
using Utility;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class SearchByRRNController : ControllerBase
    {
        private readonly ISearchByRRN _objSearchByRRN;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;

        public SearchByRRNController(ISearchByRRN objSearchByRRN, IConfiguration Configuration, ASPTrace.Contracts.ICommon Common)
        {
            _objSearchByRRN = objSearchByRRN;
            _configuration = Configuration;
            _objCommon = Common;
        }

        [Route("[action]")]
        [HttpPost]
        public object GetSearchByRRNDetailsList(SearchByRRNModel searchByRRNModel)
        {
            List<SearchByRRNDetailsModel> searchByRRNDetailsModelList = _objSearchByRRN.GetSearchByRRNDetails(searchByRRNModel); 

            string relativePath = _configuration["AppSettings:MekKey2Path"];
            AesEncryption.EMEK1 = _configuration.GetValue<string>("AppSettings:EMekKey1");
            AesEncryption.EMEK2 = System.IO.File.ReadAllText(relativePath).Trim();          
            

            foreach (SearchByRRNDetailsModel searchByRRNDetailsModel in searchByRRNDetailsModelList)
            {
                try
                {
                    searchByRRNDetailsModel.CardNumber = AesEncryption.DecryptString(searchByRRNDetailsModel.CardNumber);
                }
                catch
                {

                }
            }

            return searchByRRNDetailsModelList;
        }
    }
}