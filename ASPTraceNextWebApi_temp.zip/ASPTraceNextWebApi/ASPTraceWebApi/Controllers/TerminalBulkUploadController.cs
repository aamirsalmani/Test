﻿using System;
using System.Data.OleDb;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;


namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TerminalBulkUploadController : ControllerBase
    {
        private readonly ITerminalBulkUpload _objITerminalBulkUpload;
        private IConfiguration _configuration;

        public TerminalBulkUploadController(ITerminalBulkUpload objITerminalBulkUpload, IConfiguration Configuration)
        {
            _objITerminalBulkUpload = objITerminalBulkUpload;
            _configuration = Configuration;
        }

        [Route("[action]")]
        [HttpPost]
        public async Task<IActionResult> SaveFileToServer([FromForm] TerminalBulkUploadModel terminalBulkUploadModel)
        {
            try
            {
                var path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot/Files", terminalBulkUploadModel.TerminalFile.FileName);
                var stream = new System.IO.FileStream(path, System.IO.FileMode.Create);
                await terminalBulkUploadModel.TerminalFile.CopyToAsync(stream);

                return Ok(new { length = terminalBulkUploadModel.TerminalFile.Length, name = terminalBulkUploadModel.TerminalFile.FileName });
            }
            catch
            {
                return BadRequest();
            }
        }

        [Route("[action]")]
        [HttpPost]
        public string UploadTerminal([FromForm] TerminalBulkUploadModel terminalBulkUploadModel)
        {
            try
            {
                 System.Data.DataTable dtTerminal = new System.Data.DataTable();


                string path = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), "wwwroot\\Upload\\Terminal\\", terminalBulkUploadModel.TerminalFile.FileName);

                using (System.IO.Stream stream = new System.IO.FileStream(path, System.IO.FileMode.Create))
                {
                    terminalBulkUploadModel.TerminalFile.CopyTo(stream);
                }


                string conString = this._configuration.GetConnectionString("ExcelConString");

                string conStringTerminal = string.Format(conString, path);

                System.Data.DataTable dtexcelsheetname = new System.Data.DataTable();

                using (OleDbConnection connExcel = new OleDbConnection(conStringTerminal))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }

                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {
                    string[] excelSheets = new string[dtexcelsheetname.Rows.Count];
                    int j = 0;
                    foreach (System.Data.DataRow row in dtexcelsheetname.Rows)
                    {
                        excelSheets[j] = row["TABLE_NAME"].ToString();

                        using (OleDbConnection connExcelSheet = new OleDbConnection(conStringTerminal))
                        {
                            using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                            {
                                using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                {
                                    //Read Data from First Sheet.
                                    cmdExcelSheet.Connection = connExcelSheet;
                                    connExcelSheet.Open();
                                    cmdExcelSheet.CommandText = "SELECT * From [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                                    odaExcelSheet.SelectCommand = cmdExcelSheet;
                                    odaExcelSheet.Fill(dtTerminal);
                                    connExcelSheet.Close();
                                }
                            }
                        }
                    }
                }

                int TerminalCount = 0;
                if (dtTerminal != null && dtTerminal.Rows.Count > 0)
                {
                    if (dtTerminal.Columns.Contains("TerminalID"))
                    {
                        dtTerminal.TableName = "TerminalBulkUploadData";

                        TerminalCount = _objITerminalBulkUpload.AddTerminalBulkUploadMaster(Convert.ToString(terminalBulkUploadModel.ClientID), dtTerminal);
                    }
                }


                if (TerminalCount == 0)
                {
                    return "Invalid file format.Kindly upload the file with provided template.";
                }
                else
                {
                    if (TerminalCount > 0)
                    {
                        return "Terminal Master Registered Successfully.";
                    }
                    else if (TerminalCount == 0)
                    {
                        return "Invalid Terminal Master file format.Kindly upload the file with provided template.";
                    }
                }

                return "Error";
            }
            catch (Exception ex)
            {
                return "Error : " + ex.Message;
            }
        }
    }
}