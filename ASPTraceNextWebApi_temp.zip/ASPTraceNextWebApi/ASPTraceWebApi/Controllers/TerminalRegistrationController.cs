﻿
 
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;
using Utility;
using System;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TerminalRegistrationController : ControllerBase
    {
        private readonly ITerminalRegistration _objTerminalRegistration;
        private IConfiguration _configuration;
        private readonly ASPTrace.Contracts.ICommon _objCommon;
        public TerminalRegistrationController(ITerminalRegistration objTerminalRegistration, IConfiguration Configuration, ASPTrace.Contracts.ICommon Common)
        {
            _objTerminalRegistration = objTerminalRegistration;
            _configuration = Configuration;
            _objCommon = Common;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetTerminalMasterList()
        {
            return _objTerminalRegistration.GetTerminalMasterGridData();
        }

        [Route("[action]")]
        [HttpGet]
        public object CheckTerminalID(string ID, string TerminalID)
        {
            return _objTerminalRegistration.CheckTerminalIDExists(ID, TerminalID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetTerminalStateList()
        {
            return _objTerminalRegistration.GetTerminalState();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetDistrictOptionList(string StateID)
        {
            return _objTerminalRegistration.GetDistrictOptions(StateID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetTerminalData(string ID)
        {
            return _objTerminalRegistration.GetTerminalRegConfigMasterData(ID);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetVendorMasterList()
        {
            return _objTerminalRegistration.GetVendorMaster();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetLocationTypeMasterList()
        {
            return _objTerminalRegistration.GetLocationTypeMaster();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetATMMakeTypeMasterList()
        {
            return _objTerminalRegistration.GetATMMakeTypeMaster();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetSiteTypeMasterList()
        {
            return _objTerminalRegistration.GetSiteTypeMaster();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetSiteClassMasterList()
        {
            return _objTerminalRegistration.GetSiteClassMaster();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetTerminalTypeMasterList()
        {
            return _objTerminalRegistration.GetTerminalTypeMaster();
        }

        [Route("[action]")]
        [HttpGet]
        public object GetBranchMasterList(string ClientID)
        {
            return _objTerminalRegistration.GetBranchMaster(ClientID);
        }

        [Route("[action]")]
        [HttpPost]
        public object AddUpdateTerminalMaster(TerminalConfigMasterNew terminalConfigMasterNew)
        {
            try
            {
                if (Convert.ToInt32(terminalConfigMasterNew.ID) > 0)
                {
                    terminalConfigMasterNew.Mode = "UPDATE";
                }
                else
                {
                    terminalConfigMasterNew.Mode = "ADD";
                }
                
                int rowsAffected = _objTerminalRegistration.AddUpdateTerminalMaster(terminalConfigMasterNew);
                
                

                if (rowsAffected > 0 && terminalConfigMasterNew.Mode == "UPDATE")
                {
                    return "Terminal Details Updated Successfully.";
                }
                else if (rowsAffected > 0 && terminalConfigMasterNew.Mode == "ADD")
                {
                    return "Terminal Details Registered Successfully.";
                }
                else
                {
                    return "Error occurred while processing your request.";
                }

            }
            catch (Exception ex)
            {
                return "Error occurred while processing your request";
            }
        }


        [Route("[action]")]
        [HttpPost]
        public object TerminalRegDelete(TerminalRegDeleteModel terminalRegDeleteModel)
        {
            return _objTerminalRegistration.TerminalRegDelete(terminalRegDeleteModel);
        }

    }
}