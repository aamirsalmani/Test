﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer; 

namespace ASPTraceWebApi.Controllers;

[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
[Route("api/[controller]")]
[ApiController]
public class UserDetailsController : ControllerBase
{

    private IConfiguration _configuration;
    private readonly ICommon _Common;
    private readonly IUserDetails _objUserDetails;
    public UserDetailsController(IConfiguration objConfiguration, ICommon objCommon, IUserDetails objUserDetails)
    {
        _configuration = objConfiguration;
        _Common = objCommon;
        _objUserDetails = objUserDetails; ;
    }

    [Route("[action]")]
    [HttpGet]
    public object GetUserClientDetailsList()
    {
        return _objUserDetails.GetUserClientDetails();
    }

    [Route("[action]")]
    [HttpGet]
    public object GetUserRoleDetailsList(string ClientID)
    {
        return _objUserDetails.GetUserRoleDetails(ClientID);
    }

    [Route("[action]")]
    [HttpGet]
    public object GetUserBranchDetailsList(string ClientID)
    {
        return _objUserDetails.GetUserBranchDetails(ClientID);
    }

    [Route("[action]")]
    [HttpPost]
    public object GetUserDetailsGridList(UserFilterModel userDetailsModel)
    {
        return _objUserDetails.GetUserDetailsGrid(userDetailsModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object GetUserResetPasswordList(GetUserResetPassModel userDetailsModel)
    {
        return _objUserDetails.GetUserResetPassword(userDetailsModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object DeleteUser(DeleteUserModel userDetailsModel)
    {
        return _objUserDetails.DeleteUser(userDetailsModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object AddUser(UserDetailsModel userDetailsModel)
    {
        string Message = string.Empty;

        if (userDetailsModel.Password == userDetailsModel.ConfirmPassword)
        {
            string UserId = _objUserDetails.CheckUserId(userDetailsModel.UserID, userDetailsModel.ClientID);

            if (UserId.Length > 0)
            {
                Message = "Exists";
            }
            else
            {
                userDetailsModel.ClientID = userDetailsModel.ClientID.Replace("[", "").Replace("]", "");
                string Salt = Utility.AesEncryption.EncryptUsingSHA2Algorithm(RandomStringGenerator());
                userDetailsModel.ConfirmPassword = Utility.AesEncryption.EncryptUsingSHA2Algorithm(userDetailsModel.Password);
                Message = _objUserDetails.CreateUser(userDetailsModel, Salt);
            }
        }
        else
        {
            Message = "Password Mis-match, re-enter password and Confirm Password.";
        }

        return Message;
    }

    [Route("[action]")]
    [HttpPost]
    public object ChangePassword(PasswordModel passwordModel)
    {
        string Message = string.Empty; string TempPass = string.Empty;
        if (passwordModel.OldPassword == passwordModel.NewPassword)
        {
            Message = "New Password Cannot be same as Old Password";
        }
        else
        {
            if (passwordModel.ConfirmPassword == passwordModel.NewPassword)
            {
                string ClientCode = _objUserDetails.GetClientCodeByUserName(passwordModel.UserID);

                PasswordHistoryModel passwordHistoryModel = _objUserDetails.GetLastPasswords(passwordModel.UserID, ClientCode);

                TempPass = Utility.AesEncryption.EncryptUsingSHA2Algorithm(passwordModel.ConfirmPassword);

                if (passwordHistoryModel.Password1 == TempPass || passwordHistoryModel.Password2 == TempPass || passwordHistoryModel.Password3 == TempPass || passwordHistoryModel.Password4 == TempPass)
                {
                    Message = "New password already used in last four password.";
                }
                else
                {
                    TempPass = passwordModel.ConfirmPassword;

                    passwordModel.ClientCode = ClientCode;
                    passwordModel.NewSalt = Utility.AesEncryption.EncryptUsingSHA2Algorithm(RandomStringGenerator());
                    passwordModel.ConfirmPassword = Utility.AesEncryption.EncryptUsingSHA2Algorithm(passwordModel.ConfirmPassword);
                    passwordModel.OldPassword = Utility.AesEncryption.EncryptUsingSHA2Algorithm(passwordModel.OldPassword);

                    string temp = _objUserDetails.UpdateChangePassword(passwordModel);

                    if (temp == "Login")
                    {
                        Message = "Password updated successfully.";

                        ASPTraceWebApi.ClassFiles.SmtpMail smtpMail = new ASPTraceWebApi.ClassFiles.SmtpMail(_configuration, _Common);
                        ASPTraceWebApi.ClassFiles.EmailModel emailModel = new ASPTraceWebApi.ClassFiles.EmailModel();
                        emailModel.To = _objUserDetails.GetUserEmailId(passwordModel.UserID, passwordModel.ClientCode);

                        emailModel.Body = "<b>Dear</b>" + "<B>&nbsp;&nbsp;" + passwordModel.UserID + "</b> ,<br><br><b>Please find below the login credentials for Trace Portal:</b>" +
                                            "<br>UserID:  " + passwordModel.UserID +
                                            "<br>Password: " + TempPass
                                           + "<br>Password changed successfully.</div>" + "<br><br><strong>Regards,<br>PSS";

                        emailModel.Subject = "Password Changed";
                        smtpMail.SendEmail(emailModel);
                    }
                    else
                    {
                        Message = "Old Password is wrong,Re-enter old password.";
                    }
                }
            }
            else
            {
                Message = "Password Mis-match, re-enter New password and Confirm Password.";
            }
        }


        return Message;
    }

    [Route("[action]")]
    [HttpGet]
    public object GetUserDetail(string UserID)
    {
        return _objUserDetails.GetUserDetail(UserID);
    }

    [Route("[action]")]
    [HttpPost]
    public object GetUserMasterData(UserFilterModel2 userModel)
    {
        return _objUserDetails.GetUserData(userModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object UpdateUserDetail(UpdateUserModel userDetailsModel)
    {
        return _objUserDetails.UpdateUser(userDetailsModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object UpdateApprovedUserDetails(UserFilterModel2 userModel)
    {
        return _objUserDetails.EditApprovedUser(userModel);
    }

    

    [Route("[action]")]
    [HttpPost]
    public object GetRoleAccessRightsList(RoleAccessList userDetailsModel)
    {
        return _objUserDetails.GetRoleAccessRights(userDetailsModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object AssignRoleAccessRights(AssignRoleAccessModel assignRoleAccessRightsModel)
    {
        return _objUserDetails.AssignRoleAccessRights(assignRoleAccessRightsModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object UserResetPassword(ResetPasswordModel userDetailsModel)
    {
        userDetailsModel.NewSalt = Utility.AesEncryption.EncryptUsingSHA2Algorithm(RandomStringGenerator());
        userDetailsModel.NewPassword = Utility.AesEncryption.EncryptUsingSHA2Algorithm(userDetailsModel.NewPassword);
        return _Common.ResetPassword(userDetailsModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object GetClientIDChannelModeList(RoleAccessList userDetailsModel)
    {
        return _objUserDetails.GetClientIDChannelModeConfiguration(userDetailsModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object GetClientBranchList(RoleAccessList userDetailsModel)
    {
        return _objUserDetails.GetClientBranches(userDetailsModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object GetUserChannelModeList(RoleAccessList userDetailsModel)
    {
        List<UserClientChannelModeDetails> ChannelDataList =  _objUserDetails.GetUserChannelModeConfiguration(userDetailsModel.ClientID, userDetailsModel.UserID); 

        List<UserChannelModeDetails> clientChannelModeList = new List<UserChannelModeDetails>();

        foreach (UserClientChannelModeDetails obj in ChannelDataList)
        {
            UserChannelModeDetails clientChannelDetails = new UserChannelModeDetails();

            clientChannelDetails.channelID = obj.ChannelID;
            clientChannelDetails.channelName = obj.ChannelName;
            clientChannelDetails.userID = obj.UserID;

            try
            {

                if (obj.ModeID.Contains("1"))
                    clientChannelDetails.onus = true;

                if (obj.ModeID.Contains("2"))
                    clientChannelDetails.acquirer = true;

                if (obj.ModeID.Contains("3"))
                    clientChannelDetails.issuer = true;

                if (obj.ModeID.Contains("4"))
                    clientChannelDetails.acquirer = true;

                if (obj.ModeID.Contains("5"))
                    clientChannelDetails.issuer = true;

                clientChannelModeList.Add(clientChannelDetails);
            }
            catch (Exception e)
            {
            }
        }

        return clientChannelModeList;
    }

    [Route("[action]")]
    [HttpPost]
    public object AddUpdateUserChannelMode(UserChannelModeConfig formData)
    {
        int k = 0;
        try
        {
            IList<UserChannelModeDetails> clientChannelModeDetails = System.Text.Json.JsonSerializer.Deserialize<IList<UserChannelModeDetails>>(formData.ClientChannelModes);

            UserClientChannelModeDetails clientChannelModeDetail = new UserClientChannelModeDetails();

            clientChannelModeDetail.ClientID = formData.ClientID;
            clientChannelModeDetail.UserID = formData.UserID;
            clientChannelModeDetail.CreatedBy = formData.CreatedBy;

            foreach (UserChannelModeDetails rows in clientChannelModeDetails)
            {
                clientChannelModeDetail.ChannelID = rows.channelID;

                if (!String.IsNullOrEmpty(rows.channelName))
                {
                    string ONUS = string.Empty; string ACQ = string.Empty; string ISS = string.Empty;

                    if (rows.onus == true) ONUS = "1";
                    if (rows.acquirer == true) ACQ = "2";
                    if (rows.issuer == true) ISS = "3";
                    if (rows.channelID == "4" && ACQ == "2") ACQ = "5";
                    if (rows.channelID == "4" && ISS == "3") ISS = "4";
                    if (rows.channelID == "7" && ACQ == "2") ACQ = "5";
                    if (rows.channelID == "7" && ISS == "3") ISS = "4";

                    var array = new[] { ONUS, ACQ, ISS };

                    clientChannelModeDetail.ModeID = string.Join(",", array.Where(s => !string.IsNullOrEmpty(s)));
                }

                k = k + _objUserDetails.AddUserChannelMode(clientChannelModeDetail);

            }

            clientChannelModeDetail = null;

            if (k == clientChannelModeDetails.Count )
            {
                return "Channel-Mode Details Updated Successfully.";
            } 
            else
            {
                return "Error occurred while processing your request.";
            }
        }
        catch (Exception ex)
        {
            return "Error occurred while processing your request";
        }
    }

    [Route("[action]")]
    [HttpPost]
    public object GetUserDetailsList(UserFilterModel2 userDetailsModel)
    {
        return _objUserDetails.GetUsers(userDetailsModel);
    }

    [Route("[action]")]
    [HttpGet]
    public object GetRoleList()
    {
        return _objUserDetails.GetUserRoles();
    }

    [Route("[action]")]
    [HttpPost]
    public object CreateUser(UserDetailsModel userDetailsModel)
    {
        string Message = string.Empty;

        if (userDetailsModel.Password == userDetailsModel.ConfirmPassword)
        {            
            userDetailsModel.ClientID = userDetailsModel.ClientID.Replace("[", "").Replace("]", "");
            string Salt = Utility.AesEncryption.EncryptUsingSHA2Algorithm(RandomStringGenerator());
            userDetailsModel.ConfirmPassword = Utility.AesEncryption.EncryptUsingSHA2Algorithm(userDetailsModel.Password);
            Message = _objUserDetails.CreateUserCore(userDetailsModel, Salt);
            
        }
        else
        {
            Message = "Password Mis-match, re-enter password and Confirm Password.";
        }

        return Message;
    }

    [Route("[action]")]
    [HttpPost]
    public object UpdateUserStatus(ActionModel nModel)
    {
        return _objUserDetails.ActionTakenByChecker(nModel);
    }

    [Route("[action]")]
    [HttpPost]
    public object RemoveUser(ActionModel nModel)
    {
        return _objUserDetails.DeleteTempUser(nModel);
    }

    string RandomStringGenerator()
    {
        char[] _SpecialChars = { '@', '#', '$', '%', '^', '&', '+', '=' };
        string _SpecialSymbols = "~!@#$%^&*()_+|}{:?><`-\\=][';/.,";
        string _Alphabets = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        string _Number = string.Empty;
        Random _RandomVal = new Random();
    Loop:
        _Number = _RandomVal.Next().ToString().Substring(0, 2);
        if (Convert.ToInt32(_Number) > _Alphabets.Length)
            goto Loop;
        else
            return DateTime.Now.ToString("yyddHHMMss") + _Number.Substring(1, 1) + _Alphabets[Convert.ToInt32(_Number)].ToString() + _SpecialSymbols.Substring(Convert.ToInt32(_Number.Substring(1, 1)), 2);
    }

}

