﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ASPTrace.Contracts;
using ASPTrace.Models;
using Microsoft.AspNetCore.Authorization;

namespace ASPTraceWebApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class VendorRegController : ControllerBase
    {
        private readonly IVendorReg _objVendorReg;

        public VendorRegController(IVendorReg objVendorReg)
        {
            _objVendorReg = objVendorReg;
        }

        [Route("[action]")]
        [HttpGet]
        public object GetVendorRegList()
        {
            return _objVendorReg.GetVendorReg();
        }

        [Route("[action]")]
        [HttpPost]
        public object VendorRegAddList(VendorRegDetailsModel vendorRegDetailsModel)
        {
            return _objVendorReg.VendorRegAdd(vendorRegDetailsModel);
        }

        [Route("[action]")]
        [HttpPost]
        public object GetVendorRegUpdateModelList(VendorRegDetailsModel vendorRegDetailsModel)
        {
            return _objVendorReg.GetVendorRegUpdateModel(vendorRegDetailsModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetVendorDetails(int VendorID)
        {
            return _objVendorReg.GetVendorDetails(VendorID);
        }

        [Route("[action]")]
        [HttpPost]
        public object VendorRegDelete(VendorRegDeleteModel vendorRegDeleteModel)
        {
            return _objVendorReg.VendorRegDelete(vendorRegDeleteModel);
        }

        [Route("[action]")]
        [HttpGet]
        public object GetVendorTypeList()
        {
            return _objVendorReg.GetVendorType();
        }
    }
}
