﻿using ASPTrace.Contracts;
using ASPTrace.Repository; 
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens; 
using ASPTraceWebApi.ClassFiles;
using MassTransit; 

var builder = WebApplication.CreateBuilder(args);

//// Set up the default culture for all threads
//var cultureInfo = new System.Globalization.CultureInfo("en-US");
//cultureInfo.NumberFormat.CurrencySymbol = "€";

//System.Globalization.CultureInfo.DefaultThreadCurrentCulture = cultureInfo;
//System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = cultureInfo;

// Add services to the container.


// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddTransient<ILogin, LoginRepository>();
builder.Services.AddTransient<ICommon, CommonRepository>();
builder.Services.AddTransient<IReport, ReportRepository>();
builder.Services.AddTransient<IImportLogs, ImportLogsRepository>();
builder.Services.AddTransient<IAuditReport, AuditReportRepository>();
builder.Services.AddTransient<IFraudReport, FraudReportRepository>();
builder.Services.AddTransient<IFileConfig, FileConfigRepository>();

builder.Services.AddTransient<IField, FieldRepository>();
builder.Services.AddTransient<ICurrencyReg, CurrencyRegRepository>();
builder.Services.AddTransient<IVendorReg, VendorRegRepository>();
builder.Services.AddTransient<IRoleCreation, RoleCreationRepository>();
builder.Services.AddTransient<IMatchingRule, MatchingRuleRepository>();

builder.Services.AddTransient<ICBR, CBRRepository>();
builder.Services.AddTransient<ISearchByRRN, SearchByRRNRepository>();
builder.Services.AddTransient<IRunReconProcess, RunReconProcessRepository>();
builder.Services.AddTransient<IClientRegistration, ClientRegRepository>();
builder.Services.AddTransient<IUserDetails, UserDetailsRepository>();
builder.Services.AddTransient<IForceSettlement, ForceSettlementRepository>();
builder.Services.AddTransient<IDynamicRecon, DynamicReconRepository>();
builder.Services.AddTransient<ITerminalRegistration, TerminalRegistrationRepository>();
builder.Services.AddTransient<ITerminalBulkUpload, TerminalBulkUploadRepository>();
builder.Services.AddTransient<IReconConfig, ReconConfigRepository>();
builder.Services.AddTransient<IDynamicFile, DynamicFileRepository>();
builder.Services.AddTransient<IDynamicImportLogs, DynamicImportLogsRepository>();
builder.Services.AddTransient<IChannelReg, ChannelRegRepository>();
builder.Services.AddTransient<IModeReg, ModeRegRepository>();
builder.Services.AddTransient<IDynamicStatus, DynamicStatusConfigRepository>();
builder.Services.AddTransient<IDynamicReport, DynamicReportRepository>();
builder.Services.AddTransient<IDynamicReconConfig, DynamicReconConfigRepository>();
builder.Services.AddTransient<IErrorLog, ErrorLogRepository>();
builder.Services.AddTransient<ILogging, LoggerRepository>();
builder.Services.AddTransient<IEjErrorConfig, EjErrorConfigRepository>();
builder.Services.AddTransient<IDMS, DMSRepository>();
builder.Services.AddTransient<IExport, ExportRepository>();
builder.Services.AddTransient<IExceptionsReport, ExceptionReportRepository>();   
builder.Services.AddTransient<IDisputeTypeConfig, DisputeTypeConfigRepository>();
builder.Services.AddTransient<ILogFileTypeConfig, LogFileTypeConfigRepository>(); 
builder.Services.AddTransient<IDownloadService, DownloadService>();
builder.Services.AddTransient<NotificationService>();
builder.Services.AddTransient<INotificationDispatcher, NotificationEventConsumer>();
builder.Services.AddTransient<INotifications, NotificationRepository>();
builder.Services.AddTransient<IAlertConfig, AlertConfigRepository>();

var appSettingsSection = builder.Configuration.GetSection("SessionSettings");
builder.Services.Configure<ASPTrace.Models.SessionSettings>(appSettingsSection);



builder.Services.AddHttpClient(); 
 
builder.Services.AddControllers();
// configure jwt authentication
var appSettings = appSettingsSection.Get<ASPTrace.Models.SessionSettings>();
var key = System.Text.Encoding.ASCII.GetBytes(appSettings.Secret);

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowLocalhost44448", builder =>
    {
        // You can configure CORS policy here
        builder.WithOrigins("https://asptracenext.maximusinfoware.com:8050", "https://localhost:44428", "http://172.25.57.107:8030", "http://172.18.135.104:8030", "http://172.25.57.107:8040", "http://172.18.135.104:8060", "https://demotrace.maximusinfoware.com:8060")
                .AllowAnyHeader()
               .AllowAnyMethod()
               .AllowCredentials()
               .WithExposedHeaders("Content-Disposition");
    }); 
});

builder.Services.AddAuthentication(x =>
{
    x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    x.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
})
            .AddJwtBearer(x =>
            {
                x.Events = new JwtBearerEvents
                {
                    OnTokenValidated = context =>
                    {
                        var userService = context.HttpContext.RequestServices.GetRequiredService<ILogin>();
                        var userId = Convert.ToString(context.Principal.Identity.Name);
                        var user = userService.GetById(userId);
                        if (user == null)
                        {
                            // return unauthorized if user no longer exists
                            context.Fail("Unauthorized");
                        }
                        return Task.CompletedTask;
                    }
                };
                x.RequireHttpsMetadata = false;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateLifetime = true,
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    // The token is considered expired if the current time exceeds 'exp' claim
                    ClockSkew = TimeSpan.Zero // Optional: Set to zero to ensure token expires exactly at token expiration time
                };
            });

// Register NotificationService for DI
//builder.Services.AddHostedService<NotificationBackgroundService>();

builder.Services.AddHsts(options =>
{
    options.Preload = true;
    options.IncludeSubDomains = true;
    options.MaxAge = TimeSpan.FromDays(365);
});

builder.Services.AddSignalR();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

if (!app.Environment.IsDevelopment())
{ 
    app.UseHsts();
}

//app.UseHttpsRedirection(); 

// Configure middleware
app.UseRouting();

app.UseCors("AllowLocalhost44448");

app.UseAuthentication();

app.UseAuthorization(); 

//app.MapControllers();

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
    endpoints.MapHub<NotificationHub>("/notificationhub"); //Map SignalR Hub
});


app.Run();
