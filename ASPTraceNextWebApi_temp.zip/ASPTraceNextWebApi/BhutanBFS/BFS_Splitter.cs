﻿using ImportData;
using System;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;
using TextFieldParserCore;
using Utility;

namespace BFS
{
    public class BFS_Splitter
    { 
        private readonly string _connectionString;
        BulkImports bulkimports;
        public BFS_Splitter(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString; 
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        public DataSet SplitterBFSCommon(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;

            DataSet DSCommon = new DataSet();

            DataTable dtAcquirer = new DataTable();
            DataTable dtIssuer = new DataTable();

            try
            {

                

                
                
                
                


                DataSet ds = new DataSet();            
              

                dtAcquirer.Columns.Add("ClientID", typeof(int));
                dtAcquirer.Columns.Add("AcquirerBank", typeof(string));
                dtAcquirer.Columns.Add("TxnsDateTime", typeof(string));
                dtAcquirer.Columns.Add("CardNumber", typeof(string));
                dtAcquirer.Columns.Add("TxnsTYPE", typeof(string));
                dtAcquirer.Columns.Add("AcqReferenceNumber", typeof(string));
                dtAcquirer.Columns.Add("ReferenceNumber", typeof(string));
                dtAcquirer.Columns.Add("TerminalId", typeof(string));
                dtAcquirer.Columns.Add("StanNumber", typeof(string));
                dtAcquirer.Columns.Add("TxnsAmount", typeof(decimal));
                dtAcquirer.Columns.Add("TxnsCurrency", typeof(string));
                dtAcquirer.Columns.Add("TxnsStatus", typeof(string));
                dtAcquirer.Columns.Add("FeeAmount", typeof(decimal));
                dtAcquirer.Columns.Add("FeeStatus", typeof(string));
                dtAcquirer.Columns.Add("Remarks", typeof(string));
                dtAcquirer.Columns.Add("ReserveField1", typeof(string));
                dtAcquirer.Columns.Add("ReserveField2", typeof(string));
                dtAcquirer.Columns.Add("ReserveField3", typeof(string));
                dtAcquirer.Columns.Add("ReserveField4", typeof(string));
                dtAcquirer.Columns.Add("ReserveField5", typeof(string));
                dtAcquirer.Columns.Add("RevEntryLeg", typeof(int));
                dtAcquirer.Columns.Add("NoOfDuplicate", typeof(int));
                dtAcquirer.Columns.Add("FileName", typeof(string));
                dtAcquirer.Columns.Add("FilePath", typeof(string));
                dtAcquirer.Columns.Add("FileDate", typeof(DateTime));
                dtAcquirer.Columns.Add("CreatedOn", typeof(DateTime)); 
                dtAcquirer.Columns.Add("CreatedBy", typeof(string)); 
                dtAcquirer.Columns.Add("ECardNumber", typeof(string));
                dtAcquirer.Columns.Add("IssuingNetwork", typeof(string));
                dtAcquirer.Columns.Add("CardScheme", typeof(string));
                dtAcquirer.Columns.Add("CardType", typeof(string));

                dtIssuer.Columns.Add("ClientID", typeof(int));
                dtIssuer.Columns.Add("AcquirerBank", typeof(string));
                dtIssuer.Columns.Add("TxnsDateTime", typeof(string));
                dtIssuer.Columns.Add("CardNumber", typeof(string));
                dtIssuer.Columns.Add("TxnsTYPE", typeof(string));
                dtIssuer.Columns.Add("AcqReferenceNumber", typeof(string));
                dtIssuer.Columns.Add("ReferenceNumber", typeof(string));
                dtIssuer.Columns.Add("TerminalId", typeof(string));
                dtIssuer.Columns.Add("StanNumber", typeof(string));
                dtIssuer.Columns.Add("TxnsAmount", typeof(decimal));
                dtIssuer.Columns.Add("TxnsCurrency", typeof(string));
                dtIssuer.Columns.Add("TxnsStatus", typeof(string));
                dtIssuer.Columns.Add("FeeAmount", typeof(decimal));
                dtIssuer.Columns.Add("FeeStatus", typeof(string));
                dtIssuer.Columns.Add("Remarks", typeof(string));
                dtIssuer.Columns.Add("ReserveField1", typeof(string));
                dtIssuer.Columns.Add("ReserveField2", typeof(string));
                dtIssuer.Columns.Add("ReserveField3", typeof(string));
                dtIssuer.Columns.Add("ReserveField4", typeof(string));
                dtIssuer.Columns.Add("ReserveField5", typeof(string));
                dtIssuer.Columns.Add("RevEntryLeg", typeof(int));
                dtIssuer.Columns.Add("NoOfDuplicate", typeof(int));
                dtIssuer.Columns.Add("FileName", typeof(string));
                dtIssuer.Columns.Add("FilePath", typeof(string));
                dtIssuer.Columns.Add("FileDate", typeof(DateTime));
                dtIssuer.Columns.Add("CreatedOn", typeof(DateTime));
                dtIssuer.Columns.Add("CreatedBy", typeof(string)); 
                dtIssuer.Columns.Add("ECardNumber", typeof(string));
                dtIssuer.Columns.Add("IssuingNetwork", typeof(string));
                dtIssuer.Columns.Add("CardScheme", typeof(string));
                dtIssuer.Columns.Add("CardType", typeof(string));

                string BankName = string.Empty;
                string LogType = dt.Rows[0]["FileName"].ToString();
                string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
                string ClientName = dt.Rows[0]["ClientName"].ToString();
                string RevEntryLeg = "1";
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

                
                string AcquirerBank = string.Empty;
                string TxnsDateTime = string.Empty;
                string CardNumber = string.Empty;
                string TxnsTYPE = string.Empty;
                string AcqReferenceNumber = string.Empty;
                string ReferenceNumber = string.Empty;
                string TerminalId = string.Empty;
                string StanNumber = string.Empty;
                string TxnsAmount = "0";
                string TxnsCurrency = string.Empty;
                string TxnsStatus = string.Empty;
                string FeeAmount = "0";
                string FeeStatus = string.Empty;
                string Remarks = string.Empty;
                string ECardNumber = string.Empty;
                string CardType = string.Empty;

                string CardScheme = "BFS";
                string IssuingNetwork = "BFS";

                DateTime? FileDate = null;
                try
                {
                    string numericDate = new String(FileName.Where(Char.IsDigit).ToArray());
                    FileDate = DateTime.ParseExact(numericDate, "yyyyMMdd", CultureInfo.InvariantCulture);
                }
                catch
                {
                    FileDate = DateTime.Now.Date;
                }

                string[] TotalCountArray = File.ReadAllLines(path);
                TotalCount = TotalCountArray.Length;
                using (TextFieldParser csvReader = new TextFieldParser(path))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;

                    while (!csvReader.EndOfData)
                    {
                        LineNo++;
                        try
                        {
                            string[] colFields = csvReader.ReadFields();
                            //string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                            //line1 = line1.Replace(",\"", ",").Replace("\",", ",");

                            /*
                            if (line1.Contains('"'))
                            {
                                string b = line1.Substring(line1.IndexOf('"'), line1.LastIndexOf('"') + 1 - line1.IndexOf('"'));
                                string c = b.Replace("\"", "").Replace(",", "");
                                line1 = line1.Replace(b, c);
                            }*/
                            //string[] colFields = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                            //int Incr = 1;

                            //string ClientID = string.Empty;                    
                            
                            
                            AcquirerBank = string.Empty;
                            TxnsDateTime = string.Empty;
                            CardNumber = string.Empty;
                            TxnsTYPE = string.Empty;
                            AcqReferenceNumber = string.Empty;
                            ReferenceNumber = string.Empty;
                            TerminalId = string.Empty;
                            StanNumber = string.Empty;
                            TxnsAmount = "0";
                            TxnsCurrency = string.Empty;
                            TxnsStatus = string.Empty;
                            FeeAmount = "0";
                            FeeStatus = string.Empty;
                            Remarks = string.Empty;
                            ECardNumber = string.Empty;
                            CardType = string.Empty;

                            if (FileName.Contains("Acquirer Successful Transaction Detail Report") || FileName.Contains("Issuer Successful Transaction Detail Report"))
                            {

                                if (ds.Tables[0].Rows[0]["TxnsDateTime"].ToString() != "0")
                                {
                                    TxnsDateTime = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsDateTime"].ToString())].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["CardNumber"].ToString() != "0")
                                {
                                    CardNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["CardNumber"].ToString())].ToString().Trim();

                                    if (CardNumber != "")
                                    {
                                        ECardNumber = AesEncryption.EncryptString(CardNumber);;
                                    }
                                }
                                if (ds.Tables[0].Rows[0]["TxnsTYPE"].ToString() != "0")
                                {
                                    TxnsTYPE = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsTYPE"].ToString())].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["AcqReferenceNumber"].ToString() != "0")
                                {
                                    AcqReferenceNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["AcqReferenceNumber"].ToString())].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["ReferenceNumber"].ToString() != "0")
                                {
                                    ReferenceNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["ReferenceNumber"].ToString())].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["TerminalId"].ToString() != "0")
                                {
                                    TerminalId = colFields[int.Parse(ds.Tables[0].Rows[0]["TerminalId"].ToString())].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["StanNumber"].ToString() != "0")
                                {
                                    StanNumber = colFields[int.Parse(ds.Tables[0].Rows[0]["StanNumber"].ToString())].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsAmount"].ToString() != "0")
                                {
                                    TxnsAmount = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString())].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsCurrency"].ToString() != "0")
                                {
                                    TxnsCurrency = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsCurrency"].ToString())].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsStatus"].ToString() != "0")
                                {
                                    TxnsStatus = colFields[int.Parse(ds.Tables[0].Rows[0]["TxnsStatus"].ToString())].ToString().Trim();
                                }
                                if (ds.Tables[0].Rows[0]["Remarks"].ToString() != "0")
                                {
                                    Remarks = colFields[int.Parse(ds.Tables[0].Rows[0]["Remarks"].ToString())].ToString().Trim();
                                }

                                if (TxnsCurrency == "BTN")
                                {
                                    TxnsCurrency = "064";
                                }

                                if (CardNumber != "")
                                {
                                    if (CardNumber.Substring(0, 1) == "4")
                                    {
                                        CardType = "VISA";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                                    {
                                        CardType = "MASTER";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "62")
                                    {
                                        CardType = "CUP";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                                    {
                                        CardType = "RuPay";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                                    {
                                        CardType = "Maestro";
                                    }
                                }

                                long n;
                                if (long.TryParse(ReferenceNumber, out n))
                                {
                                    if (FileName.Contains("Acquirer Successful Transaction Detail Report"))
                                    {
                                        dtAcquirer.Rows.Add(ClientID, "Acquirer Successful", DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), CardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, null, null, null, null, null, RevEntryLeg, 0, FileName, path, FileDate, DateTime.Now, UserName, ECardNumber, IssuingNetwork, CardScheme, CardType);
                                    }
                                    else if (FileName.Contains("Issuer Successful Transaction Detail Report"))
                                    {
                                        dtIssuer.Rows.Add(ClientID, "Issuer Successful", DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), CardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, null, null, null, null, null, RevEntryLeg, 0, FileName, path, FileDate, DateTime.Now, UserName, ECardNumber, IssuingNetwork, CardScheme, CardType);
                                    }
                                }
                            }
                            else if (FileName.Contains("Acquirer_Pending_Transaction_Detail_Report") || FileName.Contains("Issuer_Pending_Transaction_Detail_Report"))
                            {
                                if (colFields.Contains("Issuer Bank") || colFields.Contains("Acquirer Bank"))
                                {
                                    BankName = colFields[12].ToString().Trim();
                                }
                                TxnsDateTime = colFields[1].ToString().Trim();
                                CardNumber = colFields[2].ToString().Trim();
                                if (CardNumber != "")
                                {
                                    ECardNumber = AesEncryption.EncryptString(CardNumber);;
                                }
                                TxnsTYPE = colFields[3].ToString().Trim();
                                AcqReferenceNumber = colFields[4].ToString().Trim();
                                ReferenceNumber = colFields[5].ToString().Trim();
                                TerminalId = colFields[6].ToString().Trim();
                                StanNumber = colFields[7].ToString().Trim();
                                TxnsCurrency = colFields[9].ToString().Trim();
                                TxnsAmount = colFields[8].Replace(@",", "").ToString().Trim();
                                TxnsStatus = colFields[10].ToString().Trim();
                                Remarks = colFields[11].ToString().Trim();

                                if (TxnsCurrency == "BTN")
                                {
                                    TxnsCurrency = "064";
                                }

                                if (CardNumber != "")
                                {
                                    if (CardNumber.Substring(0, 1) == "4")
                                    {
                                        CardType = "VISA";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                                    {
                                        CardType = "MASTER";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "62")
                                    {
                                        CardType = "CUP";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                                    {
                                        CardType = "RuPay";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                                    {
                                        CardType = "Maestro";
                                    }
                                }

                                long n;
                                if (long.TryParse(ReferenceNumber, out n))
                                {
                                    //if (ClientName == BankName)
                                    if (BankName == "Issuer Bank")
                                    {
                                        dtAcquirer.Rows.Add(ClientID, "Acquirer_Pending", DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), CardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, null, null, null, null, null, RevEntryLeg, 0, FileName, path, FileDate, DateTime.Now,  UserName, ECardNumber, IssuingNetwork, CardScheme, CardType);
                                    }
                                    else
                                    {
                                        dtIssuer.Rows.Add(ClientID, "Issuer_Pending", DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), CardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, null, null, null, null, null, RevEntryLeg, 0, FileName, path, FileDate, DateTime.Now, UserName, ECardNumber, IssuingNetwork, CardScheme, CardType);
                                    }
                                }

                            }
                            else if (FileName.Contains("Pending Transaction Detail Report"))
                            {
                                if (colFields.Contains("Acquirer Bank"))
                                {
                                    BankName = colFields[2].ToString().Trim();
                                }
                                //colFields = colFields.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                TxnsDateTime = colFields[3].ToString().Trim();
                                CardNumber = colFields[5].ToString().Trim();
                                if (CardNumber != "")
                                {
                                    ECardNumber = AesEncryption.EncryptString(CardNumber);;
                                }
                                TxnsTYPE = colFields[6].ToString().Trim();
                                AcqReferenceNumber = colFields[7].ToString().Trim();
                                ReferenceNumber = colFields[9].ToString().Trim();
                                TerminalId = colFields[10].ToString().Trim();
                                StanNumber = colFields[11].ToString().Trim();
                                TxnsCurrency = colFields[12].ToString().Trim();
                                TxnsAmount = colFields[13].Replace(@",", "").ToString().Trim();
                                // FeeAmount = colFields[14].Replace(@",", "").ToString().Trim();
                                FeeStatus = colFields[14].ToString().Trim();
                                Remarks = colFields[15].ToString().Trim();

                                if (TxnsCurrency == "BTN")
                                {
                                    TxnsCurrency = "064";
                                }

                                if (CardNumber != "")
                                {
                                    if (CardNumber.Substring(0, 1) == "4")
                                    {
                                        CardType = "VISA";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                                    {
                                        CardType = "MASTER";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "62")
                                    {
                                        CardType = "CUP";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                                    {
                                        CardType = "RuPay";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                                    {
                                        CardType = "Maestro";
                                    }
                                }

                                long n;
                                if (long.TryParse(ReferenceNumber, out n))
                                {
                                    //if (ClientName == BankName)
                                    //{
                                    if (TxnsTYPE == "ATM Cash Withdrawl" || TxnsTYPE == "Charge Back" || TxnsTYPE == "Purchase" || TxnsTYPE == "BIMPS Transfer")
                                    {
                                        if (TerminalId.StartsWith("BBN") || TerminalId.StartsWith("BBD") || TerminalId.StartsWith("0DD"))
                                        {
                                            dtAcquirer.Rows.Add(ClientID, "Acquirer Pending", DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), CardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, null, null, null, null, null, RevEntryLeg, 0, FileName, path, FileDate, DateTime.Now, UserName, ECardNumber, IssuingNetwork, CardScheme, CardType);
                                        }
                                        else
                                        {
                                            dtIssuer.Rows.Add(ClientID, "Issuer Pending", DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), CardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, null, null, null, null, null, RevEntryLeg, 0, FileName, path, FileDate, DateTime.Now, UserName, ECardNumber, IssuingNetwork, CardScheme, CardType);
                                        }
                                    }
                                }

                            }
                            else if (FileName.Contains("Success Reversal Transaction Details Report") && !FileName.Contains("UnSuccess Reversal Transaction Details Report"))
                            {
                                if (colFields.Contains("Acquirer Bank"))
                                {
                                    BankName = colFields[3].ToString().Trim();
                                }
                                TxnsDateTime = colFields[4].ToString().Trim();
                                CardNumber = colFields[6].ToString().Trim();
                                if (CardNumber != "")
                                {
                                    ECardNumber = AesEncryption.EncryptString(CardNumber);;
                                }
                                TxnsTYPE = colFields[7].ToString().Trim();
                                AcqReferenceNumber = colFields[9].ToString().Trim();
                                ReferenceNumber = colFields[10].ToString().Trim();
                                TerminalId = colFields[11].ToString().Trim();
                                StanNumber = colFields[12].ToString().Trim();
                                TxnsCurrency = colFields[15].ToString().Trim();
                                TxnsAmount = colFields[13].ToString().Trim();
                                TxnsStatus = colFields[17].ToString().Trim();

                                if (TxnsCurrency == "BTN")
                                {
                                    TxnsCurrency = "064";
                                }

                                if (CardNumber != "")
                                {
                                    if (CardNumber.Substring(0, 1) == "4")
                                    {
                                        CardType = "VISA";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                                    {
                                        CardType = "MASTER";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "62")
                                    {
                                        CardType = "CUP";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                                    {
                                        CardType = "RuPay";
                                    }
                                    else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                                    {
                                        CardType = "Maestro";
                                    }
                                }

                                long n;
                                if (long.TryParse(ReferenceNumber, out n))
                                {
                                    //if (ClientName == BankName)
                                    //{
                                    if (TxnsTYPE == "ATM Cash Withdrawl" || TxnsTYPE == "Charge Back" || TxnsTYPE == "Purchase" || TxnsTYPE == "BIMPS Transfer")
                                    {
                                        if (TerminalId.Contains("BBN") || TerminalId.Contains("BBD") || TerminalId.Contains("0DD"))
                                        {
                                            dtAcquirer.Rows.Add(ClientID, "Acquirer Reversal", DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), CardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, null, null, null, null, null, RevEntryLeg, 0, FileName, path, FileDate, DateTime.Now, UserName, ECardNumber, IssuingNetwork, CardScheme, CardType);
                                        }
                                        //}
                                        else
                                        {
                                            dtIssuer.Rows.Add(ClientID, "Issuer Reversal", DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), CardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, null, null, null, null, null, RevEntryLeg, 0, FileName, path, FileDate, DateTime.Now,  UserName, ECardNumber, IssuingNetwork, CardScheme, CardType);
                                        }
                                    }
                                }
                            }
                            else if (FileName.Contains("UnSuccess Reversal Transaction Details Report"))
                            {
                                if (colFields.Contains("Acquirer Bank"))
                                {
                                    BankName = colFields[4].ToString().Trim();
                                }
                                TxnsDateTime = colFields[4].ToString().Trim();
                                CardNumber = colFields[6].ToString().Trim();
                                if (CardNumber != "")
                                {
                                    ECardNumber = AesEncryption.EncryptString(CardNumber);;
                                }
                                TxnsTYPE = colFields[7].ToString().Trim();
                                AcqReferenceNumber = colFields[9].ToString().Trim();
                                ReferenceNumber = colFields[10].ToString().Trim();
                                TerminalId = colFields[11].ToString().Trim();
                                StanNumber = colFields[12].ToString().Trim();
                                TxnsCurrency = colFields[15].ToString().Trim();
                                TxnsAmount = colFields[13].ToString().Trim();
                                TxnsStatus = colFields[18].ToString().Trim();

                                if (TxnsCurrency == "BTN")
                                {
                                    TxnsCurrency = "064";
                                }

                                long n;
                                if (long.TryParse(ReferenceNumber, out n))
                                {
                                    //if (ClientName == BankName)
                                    //{
                                    if (TxnsTYPE == "ATM Cash Withdrawl" || TxnsTYPE == "Charge Back" || TxnsTYPE == "Purchase" || TxnsTYPE == "BIMPS Transfer")
                                    {
                                        if (TerminalId.Contains("BBN") || TerminalId.Contains("BBD") || TerminalId.Contains("0DD"))
                                        {
                                            dtAcquirer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), CardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, null, null, null, null, null, RevEntryLeg, 0, FileName, path, FileDate, DateTime.Now, UserName, ECardNumber, IssuingNetwork, CardScheme, CardType);
                                        }

                                        else
                                        {
                                            dtIssuer.Rows.Add(ClientID, AcquirerBank, DateTime.ParseExact(TxnsDateTime, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture), CardNumber, TxnsTYPE, AcqReferenceNumber, ReferenceNumber, TerminalId, StanNumber, Convert.ToDecimal(TxnsAmount), TxnsCurrency, TxnsStatus, Convert.ToDecimal(FeeAmount), FeeStatus, Remarks, null, null, null, null, null, RevEntryLeg, 0, FileName, path, FileDate, DateTime.Now, UserName, ECardNumber, IssuingNetwork, CardScheme, CardType);
                                        }
                                    }
                                }

                            }


                        }

                        //}
                        catch (Exception ex)
                        {
                            //   objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterBFSCommon.cs", "SplitData", LineNo, FileName, UserName, 'E');
                            DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                    }

                }
                if (dtAcquirer.Rows.Count > 0)
                {
                    InsertCount = dtAcquirer.Rows.Count;
                }
                if (dtIssuer.Rows.Count > 0)
                {
                    InsertCount = dtIssuer.Rows.Count;
                } 
            }
            catch (Exception ex)
            {
               // DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            DSCommon.Tables.Add(dtAcquirer);
            DSCommon.Tables.Add(dtIssuer);

            return DSCommon;

        }

    }
}
