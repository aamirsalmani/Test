﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Xml;
using Utility;
using System.Text.RegularExpressions;
using System.Linq;
using System.Text.Json; 
using System.Reflection;
using ImportData;
using Microsoft.VisualBasic.FileIO;
using static System.Net.Mime.MediaTypeNames;
namespace CBS
{
    public class ASP_CBS_Splitter
    {
        private readonly string _connectionString;
        public ASP_CBS_Splitter(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
        }

        public string SplitterText_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0, LineNumber = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();
            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("AcquirerID", typeof(string));
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
            _DataTable.Columns.Add("ATMAccountNo", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
            _DataTable.Columns.Add("ATMBalance", typeof(decimal));
            _DataTable.Columns.Add("BranchCode", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            int Start = 0;
            int End = 0;
            string line1 = string.Empty;

            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string NoOfDuplicate = string.Empty;
            string ECardNumber = string.Empty;

            string NetworkType = string.Empty;

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;
            string RevEntryLeg = string.Empty;

            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;

            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;

            ushort AcquirerID_StartPosition = 0;
            ushort TerminalID_StartPosition = 0;
            ushort ReferenceNumber_StartPosition = 0;
            ushort CardNumber_StartPosition = 0;
            ushort FromAccount_StartPosition = 0;
            ushort ToAccount_StartPosition = 0;
            ushort InterchangeAccountNo_StartPosition = 0;
            ushort ATMAccountNo_StartPosition = 0;
            ushort TxnsDateTime_StartPosition = 0;
            ushort TxnsDate_StartPosition = 0;
            ushort TxnsTime_StartPosition = 0;
            ushort TxnsAmount_StartPosition = 0;
            ushort Amount1_StartPosition = 0;
            ushort DestinationAmount_StartPosition = 0;


            ushort TxnsSubType_StartPosition = 0;
            ushort ChannelType_StartPosition = 0;
            ushort TxnsNumber_StartPosition = 0;
            ushort TxnsPerticulars_StartPosition = 0;
            ushort DrCrType_StartPosition = 0;
            ushort ResponseCode1_StartPosition = 0;
            ushort ResponseCode2_StartPosition = 0;
            ushort ReversalCode1_StartPosition = 0;
            ushort ReversalCode2_StartPosition = 0;
            ushort TxnsPostDateTime_StartPosition = 0;
            ushort TxnsValueDateTime_StartPosition = 0;
            ushort AuthCode_StartPosition = 0;
            ushort ProcessingCode_StartPosition = 0;
            ushort FeeAmount_StartPosition = 0;


            ushort CustBalance_StartPosition = 0;
            ushort InterchangeBalance_StartPosition = 0;
            ushort ATMBalance_StartPosition = 0;
            ushort BranchCode_StartPosition = 0;
            ushort ReserveField1_StartPosition = 0;
            ushort ReserveField2_StartPosition = 0;
            ushort ReserveField3_StartPosition = 0;
            ushort ReserveField4_StartPosition = 0;
            ushort ReserveField5_StartPosition = 0;


            ushort AcquirerID_Length = 0;
            ushort TerminalID_Length = 0;
            ushort ReferenceNumber_Length = 0;
            ushort CardNumber_Length = 0;
            ushort FromAccount_Length = 0;
            ushort ToAccount_Length = 0;
            ushort InterchangeAccountNo_Length = 0;
            ushort ATMAccountNo_Length = 0;
            ushort TxnsDateTime_Length = 0;
            ushort TxnsDate_Length = 0;
            ushort TxnsTime_Length = 0;
            ushort TxnsAmount_Length = 0;
            ushort Amount1_Length = 0;
            ushort DestinationAmount_Length = 0;


            ushort TxnsSubType_Length = 0;
            ushort ChannelType_Length = 0;
            ushort TxnsNumber_Length = 0;
            ushort TxnsPerticulars_Length = 0;
            ushort DrCrType_Length = 0;
            ushort ResponseCode1_Length = 0;
            ushort ResponseCode2_Length = 0;
            ushort ReversalCode1_Length = 0;
            ushort ReversalCode2_Length = 0;
            ushort TxnsPostDateTime_Length = 0;
            ushort TxnsValueDateTime_Length = 0;
            ushort AuthCode_Length = 0;
            ushort ProcessingCode_Length = 0;
            ushort FeeAmount_Length = 0;


            ushort CustBalance_Length = 0;
            ushort InterchangeBalance_Length = 0;
            ushort ATMBalance_Length = 0;
            ushort BranchCode_Length = 0;
            ushort ReserveField1_Length = 0;
            ushort ReserveField2_Length = 0;
            ushort ReserveField3_Length = 0;
            ushort ReserveField4_Length = 0;
            ushort ReserveField5_Length = 0;

            ushort DestinationCurrencyCode_StartPosition = 0;
            ushort SourceCurrencyCode_StartPosition = 0;

            ushort DestinationCurrencyCode_Length = 0;
            ushort SourceCurrencyCode_Length = 0;

            bool ErrorOccurred = false;

            try
            {

                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));


                AcquirerID_StartPosition = Convert.ToUInt16(ds.Tables["AcquirerID"].Rows[0]["StartPosition"]);
                TerminalID_StartPosition = Convert.ToUInt16(ds.Tables["TerminalID"].Rows[0]["StartPosition"]);
                ReferenceNumber_StartPosition = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"]);
                CardNumber_StartPosition = Convert.ToUInt16(ds.Tables["CardNumber"].Rows[0]["StartPosition"]);
                FromAccount_StartPosition = Convert.ToUInt16(ds.Tables["FromAccount"].Rows[0]["StartPosition"]);
                ToAccount_StartPosition = Convert.ToUInt16(ds.Tables["ToAccount"].Rows[0]["StartPosition"]);
                InterchangeAccountNo_StartPosition = Convert.ToUInt16(ds.Tables["InterchangeAccountNo"].Rows[0]["StartPosition"]);
                ATMAccountNo_StartPosition = Convert.ToUInt16(ds.Tables["ATMAccountNo"].Rows[0]["StartPosition"]);
                TxnsDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"]);
                TxnsDate_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDate"].Rows[0]["StartPosition"]);
                TxnsTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsTime"].Rows[0]["StartPosition"]);
                TxnsAmount_StartPosition = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["StartPosition"]);
                Amount1_StartPosition = Convert.ToUInt16(ds.Tables["Amount1"].Rows[0]["StartPosition"]);
                DestinationAmount_StartPosition = Convert.ToUInt16(ds.Tables["DestinationAmount"].Rows[0]["StartPosition"]);

                TxnsSubType_StartPosition = Convert.ToUInt16(ds.Tables["TxnsSubType"].Rows[0]["StartPosition"]);
                ChannelType_StartPosition = Convert.ToUInt16(ds.Tables["ChannelType"].Rows[0]["StartPosition"]);
                TxnsNumber_StartPosition = Convert.ToUInt16(ds.Tables["TxnsNumber"].Rows[0]["StartPosition"]);
                TxnsPerticulars_StartPosition = Convert.ToUInt16(ds.Tables["TxnsPerticulars"].Rows[0]["StartPosition"]);
                DrCrType_StartPosition = Convert.ToUInt16(ds.Tables["DrCrType"].Rows[0]["StartPosition"]);
                ResponseCode1_StartPosition = Convert.ToUInt16(ds.Tables["ResponseCode1"].Rows[0]["StartPosition"]);
                ResponseCode2_StartPosition = Convert.ToUInt16(ds.Tables["ResponseCode2"].Rows[0]["StartPosition"]);
                ReversalCode1_StartPosition = Convert.ToUInt16(ds.Tables["ReversalCode1"].Rows[0]["StartPosition"]);
                ReversalCode2_StartPosition = Convert.ToUInt16(ds.Tables["ReversalCode2"].Rows[0]["StartPosition"]);
                TxnsPostDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsPostDateTime"].Rows[0]["StartPosition"]);
                TxnsValueDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsValueDateTime"].Rows[0]["StartPosition"]);
                AuthCode_StartPosition = Convert.ToUInt16(ds.Tables["AuthCode"].Rows[0]["StartPosition"]);
                ProcessingCode_StartPosition = Convert.ToUInt16(ds.Tables["ProcessingCode"].Rows[0]["StartPosition"]);
                FeeAmount_StartPosition = Convert.ToUInt16(ds.Tables["FeeAmount"].Rows[0]["StartPosition"]);

                CustBalance_StartPosition = Convert.ToUInt16(ds.Tables["CustBalance"].Rows[0]["StartPosition"]);
                InterchangeBalance_StartPosition = Convert.ToUInt16(ds.Tables["InterchangeBalance"].Rows[0]["StartPosition"]);
                ATMBalance_StartPosition = Convert.ToUInt16(ds.Tables["ATMBalance"].Rows[0]["StartPosition"]);
                BranchCode_StartPosition = Convert.ToUInt16(ds.Tables["BranchCode"].Rows[0]["StartPosition"]);
                ReserveField1_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField1"].Rows[0]["StartPosition"]);
                ReserveField2_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField2"].Rows[0]["StartPosition"]);
                ReserveField3_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField3"].Rows[0]["StartPosition"]);
                ReserveField4_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField4"].Rows[0]["StartPosition"]);
                ReserveField5_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField5"].Rows[0]["StartPosition"]);

                AcquirerID_Length = Convert.ToUInt16(ds.Tables["AcquirerID"].Rows[0]["Length"]);
                TerminalID_Length = Convert.ToUInt16(ds.Tables["TerminalID"].Rows[0]["Length"]);
                ReferenceNumber_Length = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["Length"]);
                CardNumber_Length = Convert.ToUInt16(ds.Tables["CardNumber"].Rows[0]["Length"]);
                FromAccount_Length = Convert.ToUInt16(ds.Tables["FromAccount"].Rows[0]["Length"]);
                ToAccount_Length = Convert.ToUInt16(ds.Tables["ToAccount"].Rows[0]["Length"]);
                InterchangeAccountNo_Length = Convert.ToUInt16(ds.Tables["InterchangeAccountNo"].Rows[0]["Length"]);
                ATMAccountNo_Length = Convert.ToUInt16(ds.Tables["ATMAccountNo"].Rows[0]["Length"]);
                TxnsDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["Length"]);
                TxnsDate_Length = Convert.ToUInt16(ds.Tables["TxnsDate"].Rows[0]["Length"]);
                TxnsTime_Length = Convert.ToUInt16(ds.Tables["TxnsTime"].Rows[0]["Length"]);
                TxnsAmount_Length = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["Length"]);
                Amount1_Length = Convert.ToUInt16(ds.Tables["Amount1"].Rows[0]["Length"]);
                DestinationAmount_Length = Convert.ToUInt16(ds.Tables["DestinationAmount"].Rows[0]["Length"]);

                TxnsSubType_Length = Convert.ToUInt16(ds.Tables["TxnsSubType"].Rows[0]["Length"]);
                ChannelType_Length = Convert.ToUInt16(ds.Tables["ChannelType"].Rows[0]["Length"]);
                TxnsNumber_Length = Convert.ToUInt16(ds.Tables["TxnsNumber"].Rows[0]["Length"]);
                TxnsPerticulars_Length = Convert.ToUInt16(ds.Tables["TxnsPerticulars"].Rows[0]["Length"]);
                DrCrType_Length = Convert.ToUInt16(ds.Tables["DrCrType"].Rows[0]["Length"]);
                ResponseCode1_Length = Convert.ToUInt16(ds.Tables["ResponseCode1"].Rows[0]["Length"]);
                ResponseCode2_Length = Convert.ToUInt16(ds.Tables["ResponseCode2"].Rows[0]["Length"]);
                ReversalCode1_Length = Convert.ToUInt16(ds.Tables["ReversalCode1"].Rows[0]["Length"]);
                ReversalCode2_Length = Convert.ToUInt16(ds.Tables["ReversalCode2"].Rows[0]["Length"]);
                TxnsPostDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsPostDateTime"].Rows[0]["Length"]);
                TxnsValueDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsValueDateTime"].Rows[0]["Length"]);
                AuthCode_Length = Convert.ToUInt16(ds.Tables["AuthCode"].Rows[0]["Length"]);
                ProcessingCode_Length = Convert.ToUInt16(ds.Tables["ProcessingCode"].Rows[0]["Length"]);
                FeeAmount_Length = Convert.ToUInt16(ds.Tables["FeeAmount"].Rows[0]["Length"]);

                CustBalance_Length = Convert.ToUInt16(ds.Tables["CustBalance"].Rows[0]["Length"]);
                InterchangeBalance_Length = Convert.ToUInt16(ds.Tables["InterchangeBalance"].Rows[0]["Length"]);
                ATMBalance_Length = Convert.ToUInt16(ds.Tables["ATMBalance"].Rows[0]["Length"]);
                BranchCode_Length = Convert.ToUInt16(ds.Tables["BranchCode"].Rows[0]["Length"]);
                ReserveField1_Length = Convert.ToUInt16(ds.Tables["ReserveField1"].Rows[0]["Length"]);
                ReserveField2_Length = Convert.ToUInt16(ds.Tables["ReserveField2"].Rows[0]["Length"]);
                ReserveField3_Length = Convert.ToUInt16(ds.Tables["ReserveField3"].Rows[0]["Length"]);
                ReserveField4_Length = Convert.ToUInt16(ds.Tables["ReserveField4"].Rows[0]["Length"]);
                ReserveField5_Length = Convert.ToUInt16(ds.Tables["ReserveField5"].Rows[0]["Length"]);

                DestinationCurrencyCode_StartPosition = Convert.ToUInt16(ds.Tables["DestinationCurrencyCode"].Rows[0]["StartPosition"]);
                SourceCurrencyCode_StartPosition = Convert.ToUInt16(ds.Tables["SourceCurrencyCode"].Rows[0]["StartPosition"]);

                DestinationCurrencyCode_Length = Convert.ToUInt16(ds.Tables["DestinationCurrencyCode"].Rows[0]["Length"]);
                SourceCurrencyCode_Length = Convert.ToUInt16(ds.Tables["SourceCurrencyCode"].Rows[0]["Length"]); 
              
                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);


            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in TotalCountArray)
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            if (TxnsDateTime_Length > 0)
                            {
                                tempTxnDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length).Trim() : string.Empty;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                            else if (TxnsDate_Length > 0 && TxnsTime_Length > 0)
                            {
                                TxnsDate = TxnsDate_StartPosition > 0 && TxnsDate_Length > 0 ? line1.Substring(TxnsDate_StartPosition - Incr, TxnsDate_Length).Trim() : string.Empty;
                                TxnsTime = TxnsTime_StartPosition > 0 && TxnsTime_Length > 0 ? line1.Substring(TxnsTime_StartPosition - Incr, TxnsTime_Length).Trim() : string.Empty;

                                tempTxnDateTime = TxnsDate + " " + TxnsTime;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }

                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (string line in TotalCountArray)
                            {
                                if (LineNo < dateStartIndex)
                                {
                                    LineNumber++;
                                    LineNo++;
                                    continue;
                                }

                                LineNo++;

                                if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                {
                                    continue;
                                }

                                LineNumber++;

                                TerminalID = string.Empty;
                                AcquirerID = string.Empty;
                                ReferenceNumber = string.Empty;
                                CardNumber = string.Empty;
                                FromAccount = string.Empty;
                                ToAccount = string.Empty;
                                InterchangeAccountNo = string.Empty;
                                ATMAccountNo = string.Empty;
                                TxnsDateTime = string.Empty;
                                TxnsDate = string.Empty;
                                TxnsTime = string.Empty;
                                TxnsAmount = "0";
                                Amount1 = "0";
                                Amount2 = "0";
                                Amount3 = "0";
                                ChannelType = string.Empty;
                                TxnsSubType = string.Empty;
                                TxnsNumber = string.Empty;
                                TxnsPerticulars = string.Empty;
                                DrCrType = string.Empty;
                                ResponseCode1 = string.Empty;
                                ResponseCode2 = string.Empty;
                                ReversalCode1 = string.Empty;
                                ReversalCode2 = string.Empty;
                                TxnsPostDateTime = string.Empty;
                                TxnsValueDateTime = string.Empty;
                                TxnsDateTimeDiff = string.Empty;
                                AuthCode = string.Empty;
                                ProcessingCode = string.Empty;
                                FeeAmount = "0";
                                CurrencyCode = string.Empty;
                                CustBalance = "0";
                                InterchangeBalance = "0";
                                ATMBalance = "0";
                                DestinationAmount = "0";
                                BranchCode = string.Empty;
                                ReserveField1 = string.Empty;
                                ReserveField2 = string.Empty;
                                ReserveField3 = string.Empty;
                                ReserveField4 = string.Empty;
                                ReserveField5 = string.Empty;
                                NoOfDuplicate = string.Empty;
                                ECardNumber = string.Empty;
                                DestinationCurrencyCode = string.Empty;
                                SourceCurrencyCode = string.Empty;
                                NetworkType = string.Empty;

                                ReversalFlag = false;
                                TxnsStatus = string.Empty;
                                DebitCreditType = string.Empty;
                                TxnsType = string.Empty;
                                TxnsSubTypeMain = string.Empty;
                                TxnsEntryType = string.Empty;
                                CardType = string.Empty;
                                TxnsDateTimeMain = null;
                                TxnsPostDateTimeMain = null;

                                try
                                {

                                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                    AcquirerID = AcquirerID_StartPosition > 0 && AcquirerID_Length > 0 ? line1.Substring(AcquirerID_StartPosition - Incr, AcquirerID_Length).Trim() : string.Empty;
                                    TerminalID = TerminalID_StartPosition > 0 && TerminalID_Length > 0 ? line1.Substring(TerminalID_StartPosition - Incr, TerminalID_Length).Trim() : string.Empty;

                                    ReferenceNumber = ReferenceNumber_StartPosition > 0 && ReferenceNumber_Length > 0 ? line1.Substring(ReferenceNumber_StartPosition - Incr, ReferenceNumber_Length).Trim() : string.Empty;
                                    CardNumber = CardNumber_StartPosition > 0 && CardNumber_Length > 0 ? line1.Substring(CardNumber_StartPosition - Incr, CardNumber_Length).Trim() : string.Empty;
                                    FromAccount = FromAccount_StartPosition > 0 && FromAccount_Length > 0 ? line1.Substring(FromAccount_StartPosition - Incr, FromAccount_Length).Trim() : string.Empty;
                                    ToAccount = ToAccount_StartPosition > 0 && ToAccount_Length > 0 ? line1.Substring(ToAccount_StartPosition - Incr, ToAccount_Length).Trim() : string.Empty;
                                    InterchangeAccountNo = InterchangeAccountNo_StartPosition > 0 && InterchangeAccountNo_Length > 0 ? line1.Substring(InterchangeAccountNo_StartPosition - Incr, InterchangeAccountNo_Length).Trim() : string.Empty;
                                    ATMAccountNo = ATMAccountNo_StartPosition > 0 && ATMAccountNo_Length > 0 ? line1.Substring(ATMAccountNo_StartPosition - Incr, ATMAccountNo_Length).Trim() : string.Empty;

                                    TxnsDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length).Trim() : string.Empty;
                                    TxnsDate = TxnsDate_StartPosition > 0 && TxnsDate_Length > 0 ? line1.Substring(TxnsDate_StartPosition - Incr, TxnsDate_Length).Trim() : string.Empty;
                                    TxnsTime = TxnsTime_StartPosition > 0 && TxnsTime_Length > 0 ? line1.Substring(TxnsTime_StartPosition - Incr, TxnsTime_Length).Trim() : string.Empty;
                                    TxnsAmount = TxnsAmount_StartPosition > 0 && TxnsAmount_Length > 0 ? line1.Substring(TxnsAmount_StartPosition - Incr, TxnsAmount_Length).Trim() : string.Empty;
                                    Amount1 = Amount1_StartPosition > 0 && Amount1_Length > 0 ? line1.Substring(Amount1_StartPosition - Incr, Amount1_Length).Trim() : string.Empty;
                                    DestinationAmount = DestinationAmount_StartPosition > 0 && DestinationAmount_Length > 0 ? line1.Substring(DestinationAmount_StartPosition - Incr, DestinationAmount_Length).Trim() : string.Empty;
                                    FeeAmount = FeeAmount_StartPosition > 0 && FeeAmount_Length > 0 ? line1.Substring(FeeAmount_StartPosition - Incr, FeeAmount_Length).Trim() : string.Empty;

                                    TxnsSubType = TxnsSubType_StartPosition > 0 && TxnsSubType_Length > 0 ? line1.Substring(TxnsSubType_StartPosition - Incr, TxnsSubType_Length).Trim() : string.Empty;
                                    ChannelType = ChannelType_StartPosition > 0 && ChannelType_Length > 0 ? line1.Substring(ChannelType_StartPosition - Incr, ChannelType_Length).Trim() : string.Empty;
                                    TxnsNumber = TxnsNumber_StartPosition > 0 && TxnsNumber_Length > 0 ? line1.Substring(TxnsNumber_StartPosition - Incr, TxnsNumber_Length).Trim() : string.Empty;
                                    TxnsPerticulars = TxnsPerticulars_StartPosition > 0 && TxnsPerticulars_Length > 0 ? line1.Substring(TxnsPerticulars_StartPosition - Incr, TxnsPerticulars_Length).Trim() : string.Empty;
                                    DrCrType = DrCrType_StartPosition > 0 && DrCrType_Length > 0 ? line1.Substring(DrCrType_StartPosition - Incr, DrCrType_Length).Trim() : string.Empty;

                                    ResponseCode1 = ResponseCode1_StartPosition > 0 && ResponseCode1_Length > 0 ? line1.Substring(ResponseCode1_StartPosition - Incr, ResponseCode1_Length).Trim() : string.Empty;
                                    ResponseCode2 = ResponseCode2_StartPosition > 0 && ResponseCode2_Length > 0 ? line1.Substring(ResponseCode2_StartPosition - Incr, ResponseCode2_Length).Trim() : string.Empty;
                                    ReversalCode1 = ReversalCode1_StartPosition > 0 && ReversalCode1_Length > 0 ? line1.Substring(ReversalCode1_StartPosition - Incr, ReversalCode1_Length).Trim() : string.Empty;
                                    ReversalCode2 = ReversalCode2_StartPosition > 0 && ReversalCode2_Length > 0 ? line1.Substring(ReversalCode2_StartPosition - Incr, ReversalCode2_Length).Trim() : string.Empty;
                                    TxnsPostDateTime = TxnsPostDateTime_StartPosition > 0 && TxnsPostDateTime_Length > 0 ? line1.Substring(TxnsPostDateTime_StartPosition - Incr, TxnsPostDateTime_Length).Trim() : string.Empty;
                                    TxnsValueDateTime = TxnsValueDateTime_StartPosition > 0 && TxnsValueDateTime_Length > 0 ? line1.Substring(TxnsValueDateTime_StartPosition - Incr, TxnsValueDateTime_Length).Trim() : string.Empty;

                                    AuthCode = AuthCode_StartPosition > 0 && AuthCode_Length > 0 ? line1.Substring(AuthCode_StartPosition - Incr, AuthCode_Length).Trim() : string.Empty;
                                    ProcessingCode = ProcessingCode_StartPosition > 0 && ProcessingCode_Length > 0 ? line1.Substring(ProcessingCode_StartPosition - Incr, ProcessingCode_Length).Trim() : string.Empty;
                                    SourceCurrencyCode = SourceCurrencyCode_StartPosition > 0 && SourceCurrencyCode_Length > 0 ? line1.Substring(SourceCurrencyCode_StartPosition - Incr, SourceCurrencyCode_Length).Trim() : string.Empty;
                                    DestinationCurrencyCode = DestinationCurrencyCode_StartPosition > 0 && DestinationCurrencyCode_Length > 0 ? line1.Substring(DestinationCurrencyCode_StartPosition - Incr, DestinationCurrencyCode_Length).Trim() : string.Empty;

                                    CustBalance = CustBalance_StartPosition > 0 && CustBalance_Length > 0 ? line1.Substring(CustBalance_StartPosition - Incr, CustBalance_Length).Trim() : string.Empty;
                                    InterchangeBalance = InterchangeBalance_StartPosition > 0 && InterchangeBalance_Length > 0 ? line1.Substring(InterchangeBalance_StartPosition - Incr, InterchangeBalance_Length).Trim() : string.Empty;
                                    ATMBalance = ATMBalance_StartPosition > 0 && ATMBalance_Length > 0 ? line1.Substring(ATMBalance_StartPosition - Incr, ATMBalance_Length).Trim() : string.Empty;
                                    BranchCode = BranchCode_StartPosition > 0 && BranchCode_Length > 0 ? line1.Substring(BranchCode_StartPosition - Incr, BranchCode_Length).Trim() : string.Empty;

                                    ReserveField1 = ReserveField1_StartPosition > 0 && ReserveField1_Length > 0 ? line1.Substring(ReserveField1_StartPosition - Incr, ReserveField1_Length).Trim() : string.Empty;
                                    ReserveField2 = ReserveField2_StartPosition > 0 && ReserveField2_Length > 0 ? line1.Substring(ReserveField2_StartPosition - Incr, ReserveField2_Length).Trim() : string.Empty;
                                    ReserveField3 = ReserveField3_StartPosition > 0 && ReserveField3_Length > 0 ? line1.Substring(ReserveField3_StartPosition - Incr, ReserveField3_Length).Trim() : string.Empty;
                                    ReserveField4 = ReserveField4_StartPosition > 0 && ReserveField4_Length > 0 ? line1.Substring(ReserveField4_StartPosition - Incr, ReserveField4_Length).Trim() : string.Empty;
                                    ReserveField5 = ReserveField5_StartPosition > 0 && ReserveField5_Length > 0 ? line1.Substring(ReserveField5_StartPosition - Incr, ReserveField5_Length).Trim() : string.Empty;


                                    if (TxnsDate != "" && TxnsTime != "")
                                    {
                                        TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }


                                    if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime != "")
                                    {
                                        TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime, CultureInfo.InvariantCulture);
                                    }

                                    if (CardNumber != "")
                                    {
                                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                                    }

                                    if (CardNumber != "" && CardNumber.Length == 16)
                                    {
                                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();
                                    }


                                    CardType = Common.GetCardType(CardNumber);

                                    TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                    Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                    DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                    FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";
                                    CustBalance = Common.IsNumeric(CustBalance) ? CustBalance : "0";
                                    InterchangeBalance = Common.IsNumeric(InterchangeBalance) ? InterchangeBalance : "0";
                                    ATMBalance = Common.IsNumeric(ATMBalance) ? ATMBalance : "0";

                                    if (TxnsDateTimeMain != null)
                                    {
                                        _DataTable.Rows.Add(AcquirerID
                                                , ChannelType
                                                , TerminalID
                                                , ReferenceNumber
                                                , CardNumber.Trim()
                                                , FromAccount
                                                , ToAccount
                                                , InterchangeAccountNo
                                                , ATMAccountNo
                                                , TxnsDateTimeMain
                                                , Convert.ToDecimal(TxnsAmount)
                                                , Convert.ToDecimal(DestinationAmount)
                                                , Convert.ToDecimal(FeeAmount)
                                                , Convert.ToDecimal(Amount1)
                                                , SourceCurrencyCode
                                                , DestinationCurrencyCode
                                                , TxnsStatus
                                                , TxnsType
                                                , TxnsSubType
                                                , TxnsEntryType
                                                , TxnsNumber
                                                , TxnsPerticulars
                                                , DrCrType
                                                , AuthCode
                                                , ProcessingCode
                                                , ResponseCode1
                                                , ResponseCode2
                                                , ReversalCode1
                                                , ReversalCode2
                                                , ReversalFlag
                                                , TxnsPostDateTimeMain
                                                , TxnsValueDateTimeMain
                                                , RevEntryLeg
                                                , Convert.ToDecimal(CustBalance)
                                                , Convert.ToDecimal(InterchangeBalance)
                                                , Convert.ToDecimal(ATMBalance)
                                                , BranchCode
                                                , ReserveField1
                                                , ReserveField2
                                                , ReserveField3
                                                , ReserveField4
                                                , ReserveField5
                                                , ECardNumber.Trim()
                                                , CardType
                                                , NetworkType
                                                );


                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;

                                            MSG = bulkimports.BulkInsertCBSTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);

                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }
                                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                                        {
                                            MSG = "Successful";
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    ErrorCount++;
                                }
                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertCBSTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                        }
                        else if (fileImportRequest.ErrorMessage.Length == 0 && _DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                            MSG = fileImportRequest.ErrorMessage;
                        }
                    }
                    else
                    {
                        BatchNo++;
                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        MSG = fileImportRequest.ErrorMessage;
                    }
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage; 
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = 1,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));
            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string SplitterText_Dynamic_UPI(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0, LineNumber = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();
            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataSet _dataSetUpi = new DataSet();
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("TxnsID", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("PayerIFSC", typeof(string));
            _DataTable.Columns.Add("PayeeIFSC", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;
            string RevEntryLeg = string.Empty;
            string ChannelType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string TxnsSubType = string.Empty;
            string TxnsStatus = string.Empty;
            string TxnsID = string.Empty;
            string PayerIFSC = string.Empty;
            string PayeeIFSC = string.Empty;

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;


            string NetworkType = string.Empty;

            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;

            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;
            string[] colFields = null;
            string line1 = string.Empty;
            bool ErrorOccurred = false;

           
            ushort ReferenceNumber_StartPosition = 0; 
            ushort FromAccount_StartPosition = 0;
            ushort ToAccount_StartPosition = 0; 
            ushort TxnsDateTime_StartPosition = 0;
            ushort TxnsDate_StartPosition = 0;
            ushort TxnsTime_StartPosition = 0;
            ushort TxnsAmount_StartPosition = 0;
            ushort Amount1_StartPosition = 0;
            ushort DestinationAmount_StartPosition = 0;


            ushort TxnsSubType_StartPosition = 0;
            ushort ChannelType_StartPosition = 0;
            ushort TxnsNumber_StartPosition = 0;
            ushort TxnsPerticulars_StartPosition = 0;
            ushort DrCrType_StartPosition = 0;
            ushort ResponseCode1_StartPosition = 0;
            ushort ResponseCode2_StartPosition = 0;
            ushort ReversalCode1_StartPosition = 0;
            ushort ReversalCode2_StartPosition = 0;
            ushort TxnsPostDateTime_StartPosition = 0;
            ushort TxnsValueDateTime_StartPosition = 0;
            ushort AuthCode_StartPosition = 0;
            ushort ProcessingCode_StartPosition = 0;
            ushort FeeAmount_StartPosition = 0;  
            ushort ReserveField1_StartPosition = 0;
            ushort ReserveField2_StartPosition = 0;
            ushort ReserveField3_StartPosition = 0;
            ushort ReserveField4_StartPosition = 0;
            ushort ReserveField5_StartPosition = 0; 

         
            ushort ReferenceNumber_Length = 0; 
            ushort FromAccount_Length = 0;
            ushort ToAccount_Length = 0; 
            ushort TxnsDateTime_Length = 0;
            ushort TxnsDate_Length = 0;
            ushort TxnsTime_Length = 0;
            ushort TxnsAmount_Length = 0;
            ushort Amount1_Length = 0;
            ushort DestinationAmount_Length = 0;


            ushort TxnsSubType_Length = 0;
            ushort ChannelType_Length = 0;
            ushort TxnsNumber_Length = 0;
            ushort TxnsPerticulars_Length = 0;
            ushort DrCrType_Length = 0;
            ushort ResponseCode1_Length = 0;
            ushort ResponseCode2_Length = 0;
            ushort ReversalCode1_Length = 0;
            ushort ReversalCode2_Length = 0;
            ushort TxnsPostDateTime_Length = 0;
            ushort TxnsValueDateTime_Length = 0;
            ushort AuthCode_Length = 0;
            ushort ProcessingCode_Length = 0;
            ushort FeeAmount_Length = 0;   
            ushort ReserveField1_Length = 0;
            ushort ReserveField2_Length = 0;
            ushort ReserveField3_Length = 0;
            ushort ReserveField4_Length = 0;
            ushort ReserveField5_Length = 0;

            ushort DestinationCurrencyCode_StartPosition = 0;
            ushort SourceCurrencyCode_StartPosition = 0;

            ushort DestinationCurrencyCode_Length = 0;
            ushort SourceCurrencyCode_Length = 0;

            ushort PayerIFSC_StartPosition = 0;
            ushort PayeeIFSC_StartPosition = 0;

            ushort PayerIFSC_Length = 0;
            ushort PayeeIFSC_Length = 0;

            int largestIndex = 0, CoulmnIndex = 0;

            try
            {
                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile))); 
                 
                ReferenceNumber_StartPosition = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"]); 
                FromAccount_StartPosition = Convert.ToUInt16(ds.Tables["FromAccount"].Rows[0]["StartPosition"]);
                ToAccount_StartPosition = Convert.ToUInt16(ds.Tables["ToAccount"].Rows[0]["StartPosition"]); 
                TxnsDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"]);
                TxnsDate_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDate"].Rows[0]["StartPosition"]);
                TxnsTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsTime"].Rows[0]["StartPosition"]);
                TxnsAmount_StartPosition = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["StartPosition"]);
                Amount1_StartPosition = Convert.ToUInt16(ds.Tables["Amount1"].Rows[0]["StartPosition"]);
                DestinationAmount_StartPosition = Convert.ToUInt16(ds.Tables["DestinationAmount"].Rows[0]["StartPosition"]);

                TxnsSubType_StartPosition = Convert.ToUInt16(ds.Tables["TxnsSubType"].Rows[0]["StartPosition"]);
                ChannelType_StartPosition = Convert.ToUInt16(ds.Tables["ChannelType"].Rows[0]["StartPosition"]);
                TxnsNumber_StartPosition = Convert.ToUInt16(ds.Tables["TxnsID"].Rows[0]["StartPosition"]);
                TxnsPerticulars_StartPosition = Convert.ToUInt16(ds.Tables["TxnsPerticulars"].Rows[0]["StartPosition"]);
                DrCrType_StartPosition = Convert.ToUInt16(ds.Tables["DrCrType"].Rows[0]["StartPosition"]);
                ResponseCode1_StartPosition = Convert.ToUInt16(ds.Tables["ResponseCode1"].Rows[0]["StartPosition"]);
                ResponseCode2_StartPosition = Convert.ToUInt16(ds.Tables["ResponseCode2"].Rows[0]["StartPosition"]);
                ReversalCode1_StartPosition = Convert.ToUInt16(ds.Tables["ReversalCode1"].Rows[0]["StartPosition"]);
                ReversalCode2_StartPosition = Convert.ToUInt16(ds.Tables["ReversalCode2"].Rows[0]["StartPosition"]);
                TxnsPostDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsPostDateTime"].Rows[0]["StartPosition"]);
                TxnsValueDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsValueDateTime"].Rows[0]["StartPosition"]);
                AuthCode_StartPosition = Convert.ToUInt16(ds.Tables["AuthCode"].Rows[0]["StartPosition"]);
                ProcessingCode_StartPosition = Convert.ToUInt16(ds.Tables["ProcessingCode"].Rows[0]["StartPosition"]);
                FeeAmount_StartPosition = Convert.ToUInt16(ds.Tables["FeeAmount"].Rows[0]["StartPosition"]);
                  
                ReserveField1_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField1"].Rows[0]["StartPosition"]);
                ReserveField2_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField2"].Rows[0]["StartPosition"]);
                ReserveField3_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField3"].Rows[0]["StartPosition"]);
                ReserveField4_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField4"].Rows[0]["StartPosition"]);
                ReserveField5_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField5"].Rows[0]["StartPosition"]);
                 
                ReferenceNumber_Length = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["Length"]); 
                FromAccount_Length = Convert.ToUInt16(ds.Tables["FromAccount"].Rows[0]["Length"]);
                ToAccount_Length = Convert.ToUInt16(ds.Tables["ToAccount"].Rows[0]["Length"]); 
                TxnsDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["Length"]);
                TxnsDate_Length = Convert.ToUInt16(ds.Tables["TxnsDate"].Rows[0]["Length"]);
                TxnsTime_Length = Convert.ToUInt16(ds.Tables["TxnsTime"].Rows[0]["Length"]);
                TxnsAmount_Length = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["Length"]);
                Amount1_Length = Convert.ToUInt16(ds.Tables["Amount1"].Rows[0]["Length"]);
                DestinationAmount_Length = Convert.ToUInt16(ds.Tables["DestinationAmount"].Rows[0]["Length"]);

                TxnsSubType_Length = Convert.ToUInt16(ds.Tables["TxnsSubType"].Rows[0]["Length"]);
                ChannelType_Length = Convert.ToUInt16(ds.Tables["ChannelType"].Rows[0]["Length"]);
                TxnsNumber_Length = Convert.ToUInt16(ds.Tables["TxnsID"].Rows[0]["Length"]);
                TxnsPerticulars_Length = Convert.ToUInt16(ds.Tables["TxnsPerticulars"].Rows[0]["Length"]);
                DrCrType_Length = Convert.ToUInt16(ds.Tables["DrCrType"].Rows[0]["Length"]);
                ResponseCode1_Length = Convert.ToUInt16(ds.Tables["ResponseCode1"].Rows[0]["Length"]);
                ResponseCode2_Length = Convert.ToUInt16(ds.Tables["ResponseCode2"].Rows[0]["Length"]);
                ReversalCode1_Length = Convert.ToUInt16(ds.Tables["ReversalCode1"].Rows[0]["Length"]);
                ReversalCode2_Length = Convert.ToUInt16(ds.Tables["ReversalCode2"].Rows[0]["Length"]);
                TxnsPostDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsPostDateTime"].Rows[0]["Length"]);
                TxnsValueDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsValueDateTime"].Rows[0]["Length"]);
                AuthCode_Length = Convert.ToUInt16(ds.Tables["AuthCode"].Rows[0]["Length"]);
                ProcessingCode_Length = Convert.ToUInt16(ds.Tables["ProcessingCode"].Rows[0]["Length"]);
                FeeAmount_Length = Convert.ToUInt16(ds.Tables["FeeAmount"].Rows[0]["Length"]); 
                 
                ReserveField1_Length = Convert.ToUInt16(ds.Tables["ReserveField1"].Rows[0]["Length"]);
                ReserveField2_Length = Convert.ToUInt16(ds.Tables["ReserveField2"].Rows[0]["Length"]);
                ReserveField3_Length = Convert.ToUInt16(ds.Tables["ReserveField3"].Rows[0]["Length"]);
                ReserveField4_Length = Convert.ToUInt16(ds.Tables["ReserveField4"].Rows[0]["Length"]);
                ReserveField5_Length = Convert.ToUInt16(ds.Tables["ReserveField5"].Rows[0]["Length"]);

                DestinationCurrencyCode_StartPosition = Convert.ToUInt16(ds.Tables["DestinationCurrencyCode"].Rows[0]["StartPosition"]);
                SourceCurrencyCode_StartPosition = Convert.ToUInt16(ds.Tables["SourceCurrencyCode"].Rows[0]["StartPosition"]);

                DestinationCurrencyCode_Length = Convert.ToUInt16(ds.Tables["DestinationCurrencyCode"].Rows[0]["Length"]);
                SourceCurrencyCode_Length = Convert.ToUInt16(ds.Tables["SourceCurrencyCode"].Rows[0]["Length"]);

                PayerIFSC_StartPosition = Convert.ToUInt16(ds.Tables["PayerIFSC"].Rows[0]["StartPosition"]);
                PayeeIFSC_StartPosition = Convert.ToUInt16(ds.Tables["PayeeIFSC"].Rows[0]["StartPosition"]);

                PayerIFSC_Length = Convert.ToUInt16(ds.Tables["PayerIFSC"].Rows[0]["Length"]);
                PayeeIFSC_Length = Convert.ToUInt16(ds.Tables["PayeeIFSC"].Rows[0]["Length"]); 
 

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty); 
                            
                            if (TxnsDateTime_Length > 0)
                            {
                                tempTxnDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length).Trim() : string.Empty;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                            else if (TxnsDate_Length > 0 && TxnsTime_Length > 0)
                            {
                                TxnsDate = TxnsDate_StartPosition > 0 && TxnsDate_Length > 0 ? line1.Substring(TxnsDate_StartPosition - Incr, TxnsDate_Length).Trim() : string.Empty;
                                TxnsTime = TxnsTime_StartPosition > 0 && TxnsTime_Length > 0 ? line1.Substring(TxnsTime_StartPosition - Incr, TxnsTime_Length).Trim() : string.Empty;

                                tempTxnDateTime = TxnsDate + " " + TxnsTime;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }

                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                try
                                {
                                    if (LineNo < dateStartIndex)
                                    {
                                        LineNumber++;
                                        LineNo++;
                                        continue;
                                    }

                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }
                                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty); 
                                   
                                    LineNumber++;

                                    AcquirerID = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    FromAccount = string.Empty;
                                    ToAccount = string.Empty;

                                    TxnsDateTime = string.Empty;
                                    TxnsDate = string.Empty;
                                    TxnsTime = string.Empty;
                                    TxnsAmount = "0";
                                    Amount1 = "0";

                                    ChannelType = string.Empty;
                                    TxnsPerticulars = string.Empty;
                                    DrCrType = string.Empty;
                                    ResponseCode1 = string.Empty;
                                    ResponseCode2 = string.Empty;
                                    ReversalCode1 = string.Empty;
                                    ReversalCode2 = string.Empty;
                                    TxnsPostDateTime = string.Empty;
                                    TxnsValueDateTime = string.Empty;
                                    TxnsDateTimeDiff = string.Empty;
                                    AuthCode = string.Empty;
                                    ProcessingCode = string.Empty;
                                    FeeAmount = "0";
                                    DestinationAmount = "0";
                                    TxnsSubType = string.Empty;
                                    TxnsStatus = string.Empty;
                                    TxnsID = string.Empty;
                                    PayerIFSC = string.Empty;
                                    PayeeIFSC = string.Empty;

                                    ReserveField1 = string.Empty;
                                    ReserveField2 = string.Empty;
                                    ReserveField3 = string.Empty;
                                    ReserveField4 = string.Empty;
                                    ReserveField5 = string.Empty;

                                    DestinationCurrencyCode = string.Empty;
                                    SourceCurrencyCode = string.Empty;
                                    NetworkType = string.Empty;

                                    //AcquirerID = AcquirerID_StartPosition > 0 && AcquirerID_Length > 0 ? line1.Substring(AcquirerID_StartPosition - Incr, AcquirerID_Length).Trim() : string.Empty;
                                    ReferenceNumber = ReferenceNumber_StartPosition > 0 && ReferenceNumber_Length > 0 ? line1.Substring(ReferenceNumber_StartPosition - Incr, ReferenceNumber_Length).Trim() : string.Empty;
                                    FromAccount = FromAccount_StartPosition > 0 && FromAccount_Length > 0 ? line1.Substring(FromAccount_StartPosition - Incr, FromAccount_Length).Trim() : string.Empty;
                                    ToAccount = ToAccount_StartPosition > 0 && ToAccount_Length > 0 ? line1.Substring(ToAccount_StartPosition - Incr, ToAccount_Length).Trim() : string.Empty;

                                    TxnsDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length).Trim() : string.Empty;
                                    TxnsDate = TxnsDate_StartPosition > 0 && TxnsDate_Length > 0 ? line1.Substring(TxnsDate_StartPosition - Incr, TxnsDate_Length).Trim() : string.Empty;
                                    TxnsTime = TxnsTime_StartPosition > 0 && TxnsTime_Length > 0 ? line1.Substring(TxnsTime_StartPosition - Incr, TxnsTime_Length).Trim() : string.Empty;
                                    TxnsAmount = TxnsAmount_StartPosition > 0 && TxnsAmount_Length > 0 ? line1.Substring(TxnsAmount_StartPosition - Incr, TxnsAmount_Length).Trim() : string.Empty;
                                    Amount1 = Amount1_StartPosition > 0 && Amount1_Length > 0 ? line1.Substring(Amount1_StartPosition - Incr, Amount1_Length).Trim() : string.Empty;
                                    DestinationAmount = DestinationAmount_StartPosition > 0 && DestinationAmount_Length > 0 ? line1.Substring(DestinationAmount_StartPosition - Incr, DestinationAmount_Length).Trim() : string.Empty;
                                    FeeAmount = FeeAmount_StartPosition > 0 && FeeAmount_Length > 0 ? line1.Substring(FeeAmount_StartPosition - Incr, FeeAmount_Length).Trim() : string.Empty;

                                    TxnsSubType = TxnsSubType_StartPosition > 0 && TxnsSubType_Length > 0 ? line1.Substring(TxnsSubType_StartPosition - Incr, TxnsSubType_Length).Trim() : string.Empty;
                                    ChannelType = ChannelType_StartPosition > 0 && ChannelType_Length > 0 ? line1.Substring(ChannelType_StartPosition - Incr, ChannelType_Length).Trim() : string.Empty;
                                    TxnsID = TxnsNumber_StartPosition > 0 && TxnsNumber_Length > 0 ? line1.Substring(TxnsNumber_StartPosition - Incr, TxnsNumber_Length).Trim() : string.Empty;
                                    TxnsPerticulars = TxnsPerticulars_StartPosition > 0 && TxnsPerticulars_Length > 0 ? line1.Substring(TxnsPerticulars_StartPosition - Incr, TxnsPerticulars_Length).Trim() : string.Empty;
                                    DrCrType = DrCrType_StartPosition > 0 && DrCrType_Length > 0 ? line1.Substring(DrCrType_StartPosition - Incr, DrCrType_Length).Trim() : string.Empty;

                                    ResponseCode1 = ResponseCode1_StartPosition > 0 && ResponseCode1_Length > 0 ? line1.Substring(ResponseCode1_StartPosition - Incr, ResponseCode1_Length).Trim() : string.Empty;
                                    ResponseCode2 = ResponseCode2_StartPosition > 0 && ResponseCode2_Length > 0 ? line1.Substring(ResponseCode2_StartPosition - Incr, ResponseCode2_Length).Trim() : string.Empty;
                                    ReversalCode1 = ReversalCode1_StartPosition > 0 && ReversalCode1_Length > 0 ? line1.Substring(ReversalCode1_StartPosition - Incr, ReversalCode1_Length).Trim() : string.Empty;
                                    ReversalCode2 = ReversalCode2_StartPosition > 0 && ReversalCode2_Length > 0 ? line1.Substring(ReversalCode2_StartPosition - Incr, ReversalCode2_Length).Trim() : string.Empty;

                                    TxnsPostDateTime = TxnsPostDateTime_StartPosition > 0 && TxnsPostDateTime_Length > 0 ? line1.Substring(TxnsPostDateTime_StartPosition - Incr, TxnsPostDateTime_Length).Trim() : string.Empty;
                                    TxnsValueDateTime = TxnsValueDateTime_StartPosition > 0 && TxnsValueDateTime_Length > 0 ? line1.Substring(TxnsValueDateTime_StartPosition - Incr, TxnsValueDateTime_Length).Trim() : string.Empty;

                                    AuthCode = AuthCode_StartPosition > 0 && AuthCode_Length > 0 ? line1.Substring(AuthCode_StartPosition - Incr, AuthCode_Length).Trim() : string.Empty;
                                    ProcessingCode = ProcessingCode_StartPosition > 0 && ProcessingCode_Length > 0 ? line1.Substring(ProcessingCode_StartPosition - Incr, ProcessingCode_Length).Trim() : string.Empty;
                                    SourceCurrencyCode = SourceCurrencyCode_StartPosition > 0 && SourceCurrencyCode_Length > 0 ? line1.Substring(SourceCurrencyCode_StartPosition - Incr, SourceCurrencyCode_Length).Trim() : string.Empty;
                                    DestinationCurrencyCode = DestinationCurrencyCode_StartPosition > 0 && DestinationCurrencyCode_Length > 0 ? line1.Substring(DestinationCurrencyCode_StartPosition - Incr, DestinationCurrencyCode_Length).Trim() : string.Empty;

                                    ReserveField1 = ReserveField1_StartPosition > 0 && ReserveField1_Length > 0 ? line1.Substring(ReserveField1_StartPosition - Incr, ReserveField1_Length).Trim() : string.Empty;
                                    ReserveField2 = ReserveField2_StartPosition > 0 && ReserveField2_Length > 0 ? line1.Substring(ReserveField2_StartPosition - Incr, ReserveField2_Length).Trim() : string.Empty;
                                    ReserveField3 = ReserveField3_StartPosition > 0 && ReserveField3_Length > 0 ? line1.Substring(ReserveField3_StartPosition - Incr, ReserveField3_Length).Trim() : string.Empty;
                                    ReserveField4 = ReserveField4_StartPosition > 0 && ReserveField4_Length > 0 ? line1.Substring(ReserveField4_StartPosition - Incr, ReserveField4_Length).Trim() : string.Empty;
                                    ReserveField5 = ReserveField5_StartPosition > 0 && ReserveField5_Length > 0 ? line1.Substring(ReserveField5_StartPosition - Incr, ReserveField5_Length).Trim() : string.Empty;

                                    PayerIFSC = PayerIFSC_StartPosition > 0 && PayerIFSC_Length > 0 ? line1.Substring(PayerIFSC_StartPosition - Incr, PayerIFSC_Length).Trim() : string.Empty;
                                    PayeeIFSC = PayeeIFSC_StartPosition > 0 && PayeeIFSC_Length > 0 ? line1.Substring(PayeeIFSC_StartPosition - Incr, PayeeIFSC_Length).Trim() : string.Empty;


                                    TxnsDateTimeMain = null;
                                    TxnsPostDateTimeMain = null;


                                    if (TxnsDate != "" && TxnsTime != "")
                                    {
                                        if (TxnsTime.Length < 6 && !TxnsTime.Contains(":"))
                                        {
                                            TxnsTime = TxnsTime.PadLeft(6, '0');
                                        }

                                        TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime != "")
                                    {
                                        DateTime dateTime = DateTime.Parse(TxnsPostDateTime);
                                        string formattedDate = dateTime.ToString(TxnPostDateTimeFormat[0]);
                                        TxnsPostDateTimeMain = DateTime.ParseExact(formattedDate, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                                    }


                                    TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                    Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                    DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                    FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";


                                    if (TxnsDateTimeMain != null)
                                    {
                                        _DataTable.Rows.Add(
                                                 ChannelType
                                                , ReferenceNumber
                                                , TxnsDateTimeMain
                                                , Convert.ToDecimal(TxnsAmount)
                                                , TxnsID
                                                , FromAccount
                                                , ToAccount
                                                , Convert.ToDecimal(DestinationAmount)
                                                , Convert.ToDecimal(FeeAmount)
                                                , Convert.ToDecimal(Amount1)
                                                , SourceCurrencyCode
                                                , DestinationCurrencyCode
                                                , TxnsSubType
                                                , TxnsStatus
                                                , TxnsPerticulars
                                                , DrCrType
                                                , AuthCode
                                                , ProcessingCode
                                                , ResponseCode1
                                                , ResponseCode2
                                                , ReversalCode1
                                                , ReversalCode2
                                                , TxnsPostDateTimeMain
                                                , TxnsValueDateTimeMain
                                                , PayerIFSC
                                                , PayeeIFSC
                                                , ReserveField1
                                                , ReserveField2
                                                , ReserveField3
                                                , ReserveField4
                                                , ReserveField5
                                                , NetworkType
                                                );


                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;

                                            MSG = bulkimports.BulkInsertCBSTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                            // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);
                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }
                                    }



                                }
                                catch (Exception ex)
                                {
                                    // _logger.LogInformation("Error At Inserting data into Datatable : ", ex);
                                    ErrorCount++;
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                }
                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;


                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertCBSTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        MSG = fileImportRequest.ErrorMessage;
                    }


                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = 1,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }

        public string SplitterExcel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;



            DtDetails DTdetails = new DtDetails();
            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("AcquirerID", typeof(string));
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
            _DataTable.Columns.Add("ATMAccountNo", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
            _DataTable.Columns.Add("ATMBalance", typeof(decimal));
            _DataTable.Columns.Add("BranchCode", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string RevEntryLeg = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string NoOfDuplicate = string.Empty;
            string ECardNumber = string.Empty;

            string NetworkType = string.Empty;

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;

            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;


            ushort AcquirerID_CoulmnIndex = 0;
            ushort TerminalID_CoulmnIndex = 0;
            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort CardNumber_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort InterchangeAccountNo_CoulmnIndex = 0;
            ushort ATMAccountNo_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Amount1_CoulmnIndex = 0;
            ushort DestinationAmount_CoulmnIndex = 0;

            ushort SourceCurrencyCode_CoulmnIndex = 0;
            ushort DestinationCurrencyCode_CoulmnIndex = 0;

            ushort TxnsSubType_CoulmnIndex = 0;
            ushort ChannelType_CoulmnIndex = 0;
            ushort TxnsNumber_CoulmnIndex = 0;
            ushort TxnsPerticulars_CoulmnIndex = 0;
            ushort DrCrType_CoulmnIndex = 0;
            ushort ResponseCode1_CoulmnIndex = 0;
            ushort ResponseCode2_CoulmnIndex = 0;
            ushort ReversalCode1_CoulmnIndex = 0;
            ushort ReversalCode2_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort TxnsValueDateTime_CoulmnIndex = 0;
            ushort AuthCode_CoulmnIndex = 0;
            ushort ProcessingCode_CoulmnIndex = 0;
            ushort FeeAmount_CoulmnIndex = 0;
            ushort CustBalance_CoulmnIndex = 0;
            ushort InterchangeBalance_CoulmnIndex = 0;
            ushort ATMBalance_CoulmnIndex = 0;
            ushort BranchCode_CoulmnIndex = 0;
            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;
            ushort ReserveField5_CoulmnIndex = 0;

            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;

            bool ErrorOccurred = false;

            try
            {

                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));


                AcquirerID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AcquirerID"]);
                TerminalID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TerminalID"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                CardNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CardNumber"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                InterchangeAccountNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InterchangeAccountNo"]);
                ATMAccountNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ATMAccountNo"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                Amount1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount1"]);
                DestinationAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationAmount"]);
                //Amount2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount2"]);
                //Amount3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount3"]);

                TxnsSubType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsSubType"]);
                ChannelType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChannelType"]);
                TxnsNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsNumber"]);
                TxnsPerticulars_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPerticulars"]);
                DrCrType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DrCrType"]);
                ResponseCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode1"]);
                ResponseCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode2"]);
                ReversalCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode1"]);
                ReversalCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode2"]);
                TxnsPostDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPostDateTime"]);
                TxnsValueDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsValueDateTime"]);
                AuthCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AuthCode"]);
                ProcessingCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ProcessingCode"]);
                FeeAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FeeAmount"]);
                //CurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CurrencyCode"]);
                CustBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CustBalance"]);
                InterchangeBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InterchangeBalance"]);
                ATMBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ATMBalance"]);
                BranchCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BranchCode"]);
                ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ReserveField3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField3"]);
                ReserveField4_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField4"]);
                ReserveField5_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField5"]);

                SourceCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SourceCurrencyCode"]);
                DestinationCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationCurrencyCode"]);


                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                string dateFile = string.Empty;
                dateFile = new string(fileImportRequest.FileName.Where(c => Char.IsDigit(c)).ToArray());

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0 && dateFile.Length >= 6)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;

                try
                {
                    // _logger.LogInformation("Ready for read");
                    batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                    DataTable dtexcelsheetname = new DataTable();
                    DataTable dtSheet = new DataTable();
                    //Read the connection string for the Excel file.
                    string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                    conString = string.Format(conString, fileImportRequest.Path);

                    using (OleDbConnection connExcel = new OleDbConnection(conString))
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            connExcel.Open();
                            //Get the name of First Sheet. 
                            dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            connExcel.Close();
                        }
                    }

                    if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                    {
                        int j = 0;
                        int SheetLineNumber = 0;

                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }
                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (DataRow row in dtexcelsheetname.Rows)
                            {
                                dtSheet = new DataTable();

                                if (conString.Contains("HTML Import") && fileImportRequest.ClientCode != "111")
                                {
                                    try
                                    {
                                        dtSheet = HtmlExcelReader.ReadHtmlExcel(fileImportRequest.Path, j + 1);
                                    }
                                    catch
                                    {
                                        j++;
                                        continue;
                                    }
                                }
                                else
                                {
                                    using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                                    {
                                        using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                        {
                                            using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                            {
                                                //Read Data from First Sheet.
                                                cmdExcelSheet.Connection = connExcelSheet;
                                                connExcelSheet.Open();
                                                cmdExcelSheet.CommandText = "SELECT * From [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                                                odaExcelSheet.SelectCommand = cmdExcelSheet;
                                                odaExcelSheet.Fill(dtSheet);
                                                connExcelSheet.Close();
                                            }
                                        }
                                    }
                                }

                                Incr = 1;

                                if (dtSheet.Rows.Count > 0)
                                {
                                    // Find first data row based on whether the "Join Date" cell can be parsed as a date
                                    int dateStartIndex = -1;

                                    for (int i = 0; i < dtSheet.Rows.Count; i++)
                                    {
                                        try
                                        {
                                            if (TxnsDateTime_CoulmnIndex > 0)
                                            {
                                                tempTxnDateTime = dtSheet.Rows[i][TxnsDateTime_CoulmnIndex - Incr]?.ToString()?.Trim();

                                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                                if (isValid)
                                                {
                                                    dateStartIndex = i;
                                                    break;
                                                }
                                            }
                                            else if (TxnsDate_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                                            {
                                                string dateStr = dtSheet.Rows[i][TxnsDate_CoulmnIndex - Incr]?.ToString()?.Trim();
                                                string timeStr = dtSheet.Rows[i][TxnsTime_CoulmnIndex - Incr]?.ToString()?.Trim();

                                                string[] partsdate = dateStr.Split(' ');
                                                string[] partstime = timeStr.Split(' ');

                                                string onlyDate = partsdate[0];
                                                string onlyTime = partstime.Length > 1 ? partstime[1] : partstime[0]; 
                                                
                                                tempTxnDateTime = onlyDate + " " + onlyTime;

                                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat,CultureInfo.InvariantCulture,DateTimeStyles.None,out DateTime tempDate);

                                                if (isValid)
                                                {
                                                    dateStartIndex = i;
                                                    break;
                                                }
                                            }

                                        }
                                        catch
                                        {
                                            SheetDateError++;
                                        }

                                        if (i > 25)
                                            break;
                                    }

                                    if (dateStartIndex > -1)
                                    {
                                        fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                                        {
                                            LineNo++;
                                            SheetLineNumber++;

                                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                            {
                                                continue;
                                            }

                                            try
                                            {
                                                TerminalID = string.Empty;
                                                AcquirerID = string.Empty;
                                                ReferenceNumber = string.Empty;
                                                CardNumber = string.Empty;
                                                FromAccount = string.Empty;
                                                ToAccount = string.Empty;
                                                InterchangeAccountNo = string.Empty;
                                                ATMAccountNo = string.Empty;
                                                TxnsDateTime = string.Empty;
                                                TxnsDate = string.Empty;
                                                TxnsTime = string.Empty;
                                                TxnsAmount = "0";
                                                Amount1 = "0";
                                                Amount2 = "0";
                                                Amount3 = "0";
                                                ChannelType = string.Empty;
                                                TxnsSubType = string.Empty;
                                                TxnsNumber = string.Empty;
                                                TxnsPerticulars = string.Empty;
                                                DrCrType = string.Empty;
                                                ResponseCode1 = string.Empty;
                                                ResponseCode2 = string.Empty;
                                                ReversalCode1 = string.Empty;
                                                ReversalCode2 = string.Empty;
                                                TxnsPostDateTime = string.Empty;
                                                TxnsValueDateTime = string.Empty;
                                                TxnsDateTimeDiff = string.Empty;
                                                AuthCode = string.Empty;
                                                ProcessingCode = string.Empty;
                                                FeeAmount = "0";
                                                CurrencyCode = string.Empty;
                                                CustBalance = "0";
                                                InterchangeBalance = "0";
                                                ATMBalance = "0";
                                                DestinationAmount = "0";
                                                BranchCode = string.Empty;
                                                ReserveField1 = string.Empty;
                                                ReserveField2 = string.Empty;
                                                ReserveField3 = string.Empty;
                                                ReserveField4 = string.Empty;
                                                ReserveField5 = string.Empty;
                                                NoOfDuplicate = string.Empty;
                                                ECardNumber = string.Empty;
                                                DestinationCurrencyCode = string.Empty;
                                                SourceCurrencyCode = string.Empty;
                                                NetworkType = string.Empty;


                                                AcquirerID = AcquirerID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AcquirerID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TerminalID = TerminalID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TerminalID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                CardNumber = CardNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CardNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                InterchangeAccountNo = InterchangeAccountNo_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][InterchangeAccountNo_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ATMAccountNo = ATMAccountNo_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ATMAccountNo_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsAmount_CoulmnIndex - Incr]) : string.Empty;
                                                Amount1 = Amount1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Amount1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DestinationAmount = DestinationAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DestinationAmount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsSubType = TxnsSubType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsSubType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ChannelType = ChannelType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ChannelType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsNumber = TxnsNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsPerticulars = TxnsPerticulars_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsPerticulars_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DrCrType = DrCrType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DrCrType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ResponseCode1 = ResponseCode1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode1_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ResponseCode2 = ResponseCode2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReversalCode1 = ReversalCode1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReversalCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReversalCode2 = ReversalCode2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReversalCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsValueDateTime = TxnsValueDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsValueDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AuthCode = AuthCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AuthCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ProcessingCode = ProcessingCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ProcessingCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                FeeAmount = FeeAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FeeAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                //CurrencyCode = CurrencyCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                CustBalance = CustBalance_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CustBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                InterchangeBalance = InterchangeBalance_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][InterchangeBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ATMBalance = ATMBalance_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ATMBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                BranchCode = BranchCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BranchCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField5 = ReserveField5_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField5_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                #region StanderedFields 

                                                ReversalFlag = false;
                                                TxnsStatus = string.Empty;
                                                DebitCreditType = string.Empty;
                                                TxnsType = string.Empty;
                                                TxnsSubTypeMain = string.Empty;
                                                TxnsEntryType = string.Empty;
                                                CardType = string.Empty;
                                                TxnsDateTimeMain = null;
                                                TxnsPostDateTimeMain = null;



                                                #region ValidateField
                                                if (TxnsDate != "" && TxnsTime != "")
                                                {
                                                    if (TxnsDate.Length > 10 && TxnsDate.Contains(" "))
                                                    {
                                                        TxnsDate = TxnsDate.Split(' ')[0];
                                                    }

                                                    if (TxnsTime.Length > 10 && TxnsTime.Contains(" "))
                                                    {
                                                        TxnsTime = TxnsTime.Split(' ')[1];
                                                    }

                                                    TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                                {
                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }
                                                if (Regex.IsMatch(ReferenceNumber, "[A-Za-z]"))
                                                {
                                                    ReferenceNumber = null;
                                                }
                                                if (Regex.IsMatch(FromAccount, "[A-Za-z]"))
                                                {
                                                    FromAccount = null;
                                                }
                                                if (Regex.IsMatch(ToAccount, "[A-Za-z]"))
                                                {
                                                    ToAccount = null;
                                                }


                                                if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime != "")
                                                {
                                                    TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                                                }


                                                #endregion ValidateField

                                                #endregion StanderedFields

                                                if (CardNumber != "")
                                                {
                                                    ECardNumber = AesEncryption.EncryptString(CardNumber);
                                                }

                                                if (CardNumber != "" && CardNumber.Length == 16)
                                                {
                                                    CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();
                                                }

                                                if (CardNumber != "" && CardNumber.Length >5)
                                                {
                                                    CardType = Common.GetCardType(CardNumber);
                                                }

                                                TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                                Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                                DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                                FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";
                                                CustBalance = Common.IsNumeric(CustBalance) ? CustBalance : "0";
                                                InterchangeBalance = Common.IsNumeric(InterchangeBalance) ? InterchangeBalance : "0";
                                                ATMBalance = Common.IsNumeric(ATMBalance) ? ATMBalance : "0";

                                                if (TxnsDateTimeMain != null)
                                                {
                                                    _DataTable.Rows.Add(AcquirerID
                                                            , ChannelType
                                                            , TerminalID
                                                            , ReferenceNumber
                                                            , CardNumber.Trim()
                                                            , FromAccount
                                                            , ToAccount
                                                            , InterchangeAccountNo
                                                            , ATMAccountNo
                                                            , TxnsDateTimeMain
                                                            , Convert.ToDecimal(TxnsAmount)
                                                            , Convert.ToDecimal(DestinationAmount)
                                                            , Convert.ToDecimal(FeeAmount)
                                                            , Convert.ToDecimal(Amount1)
                                                            , SourceCurrencyCode
                                                            , DestinationCurrencyCode
                                                            , TxnsStatus
                                                            , TxnsType
                                                            , TxnsSubType
                                                            , TxnsEntryType
                                                            , TxnsNumber
                                                            , TxnsPerticulars
                                                            , DrCrType
                                                            , AuthCode
                                                            , ProcessingCode
                                                            , ResponseCode1
                                                            , ResponseCode2
                                                            , ReversalCode1
                                                            , ReversalCode2
                                                            , ReversalFlag
                                                            , TxnsPostDateTimeMain
                                                            , TxnsValueDateTimeMain
                                                            , RevEntryLeg
                                                            , Convert.ToDecimal(CustBalance)
                                                            , Convert.ToDecimal(InterchangeBalance)
                                                            , Convert.ToDecimal(ATMBalance)
                                                            , BranchCode
                                                            , ReserveField1
                                                            , ReserveField2
                                                            , ReserveField3
                                                            , ReserveField4
                                                            , ReserveField5
                                                            , ECardNumber.Trim()
                                                            , CardType
                                                            , NetworkType
                                                            );

                                                    if (_DataTable.Rows.Count >= batchSize)
                                                    {
                                                        BatchNo++;
                                                        MSG = bulkimports.BulkInsertCBSTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                        fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                        BatchDetails batchDetailsPartial = new BatchDetails
                                                        {
                                                            BatchNo = BatchNo,
                                                            BatchSize = batchSize,
                                                            TxnUploadCount = _DataTable.Rows.Count,
                                                            TxnsCount = fileImportRequest.InsertCount,
                                                            BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                            FailedCount = ErrorCount,
                                                            BatchStartTime = batchStartTime,
                                                            BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                        };

                                                        batchDetailsList.Add(batchDetailsPartial);

                                                        _DataTable.Clear();
                                                        ErrorCount = 0;
                                                        StartTime = DateTime.Now;

                                                        if (NewEntry)
                                                        {
                                                            break;
                                                        }
                                                    }
                                                }

                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorCount++;
                                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (dtexcelsheetname.Rows.Count > 1 && conString.Contains("HTML Import"))
                                        {
                                            dateStartIndex = 0;
                                        }
                                        else
                                        {
                                            if (j == 0)
                                            {
                                                fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                                                MSG = fileImportRequest.ErrorMessage;
                                            }
                                            break;
                                        }

                                    }
                                }

                                j++;
                            }
                            LineNo = 0;
                        }
                    }
                    if (fileImportRequest.ErrorMessage.Trim().Length > 0)
                    {
                        BatchNo++;
                        MSG = fileImportRequest.ErrorMessage;
                    }
                    else
                    {
                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertCBSTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                        }
                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            MSG = "Successful";
                        }
                    }

                }
                catch (Exception ex)
                {
                    // objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "ASP_CBS_Splitter.cs", "SplitData", LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }

            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;  
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = 1,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string SplitterDelimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;

            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;

            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            string FileDateFormat = fileImportRequest.ConfigData.Rows[0]["FileDateFormat"].ToString();
            string ConfigID = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConfigID"]);

            DtDetails DTdetails = new DtDetails();

            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("AcquirerID", typeof(string));
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
            _DataTable.Columns.Add("ATMAccountNo", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
            _DataTable.Columns.Add("ATMBalance", typeof(decimal));
            _DataTable.Columns.Add("BranchCode", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string NoOfDuplicate = string.Empty;
            string ECardNumber = string.Empty;

            string NetworkType = string.Empty;

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;
            string RevEntryLeg = "1";

            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;

            string line1 = string.Empty;
            bool ErrorOccurred = false;


            ushort AcquirerID_CoulmnIndex = 0;
            ushort TerminalID_CoulmnIndex = 0;
            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort CardNumber_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort InterchangeAccountNo_CoulmnIndex = 0;
            ushort ATMAccountNo_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Amount1_CoulmnIndex = 0;
            ushort DestinationAmount_CoulmnIndex = 0;

            ushort SourceCurrencyCode_CoulmnIndex = 0;
            ushort DestinationCurrencyCode_CoulmnIndex = 0;

            ushort TxnsSubType_CoulmnIndex = 0;
            ushort ChannelType_CoulmnIndex = 0;
            ushort TxnsNumber_CoulmnIndex = 0;
            ushort TxnsPerticulars_CoulmnIndex = 0;
            ushort DrCrType_CoulmnIndex = 0;
            ushort ResponseCode1_CoulmnIndex = 0;
            ushort ResponseCode2_CoulmnIndex = 0;
            ushort ReversalCode1_CoulmnIndex = 0;
            ushort ReversalCode2_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort TxnsValueDateTime_CoulmnIndex = 0;
            ushort AuthCode_CoulmnIndex = 0;
            ushort ProcessingCode_CoulmnIndex = 0;
            ushort FeeAmount_CoulmnIndex = 0;
            ushort CustBalance_CoulmnIndex = 0;
            ushort InterchangeBalance_CoulmnIndex = 0;
            ushort ATMBalance_CoulmnIndex = 0;
            ushort BranchCode_CoulmnIndex = 0;
            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;
            ushort ReserveField5_CoulmnIndex = 0;
            //ushort CardScheme_CoulmnIndex = 0;
            //ushort NetworkType_CoulmnIndex = 0;

            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;
            string[] colFields = null;
            int largestIndex = 0, CoulmnIndex = 0, TxnAmountIsDecimal = 0, LineNumber=0;

            try
            {
                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                AcquirerID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AcquirerID"]);
                TerminalID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TerminalID"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                CardNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CardNumber"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                InterchangeAccountNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InterchangeAccountNo"]);
                ATMAccountNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ATMAccountNo"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                Amount1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount1"]);
                DestinationAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationAmount"]);

                TxnsSubType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsSubType"]);
                ChannelType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChannelType"]);
                TxnsNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsNumber"]);
                TxnsPerticulars_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPerticulars"]);
                DrCrType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DrCrType"]);
                ResponseCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode1"]);
                ResponseCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode2"]);
                ReversalCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode1"]);
                ReversalCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode2"]);
                TxnsPostDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPostDateTime"]);
                TxnsValueDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsValueDateTime"]);
                AuthCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AuthCode"]);
                ProcessingCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ProcessingCode"]);
                FeeAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FeeAmount"]);

                CustBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CustBalance"]);
                InterchangeBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InterchangeBalance"]);
                ATMBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ATMBalance"]);
                BranchCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BranchCode"]);
                ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ReserveField3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField3"]);
                ReserveField4_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField4"]);
                ReserveField5_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField5"]);

                SourceCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SourceCurrencyCode"]);
                DestinationCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationCurrencyCode"]); 

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTimeFormat Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }


            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;
                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {

                    batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            colFields = new string[0];

                            colFields = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            if (TxnsDateTime_CoulmnIndex > 0)
                            {
                                tempTxnDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                            else if (TxnsDate_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                            {
                                TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;

                                tempTxnDateTime = TxnsDate + " " + TxnsTime;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }
                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            } 

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                try
                                {
                                    if (LineNo < dateStartIndex)
                                    {
                                        LineNumber++;
                                        LineNo++;
                                        continue;
                                    }

                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                    colFields = new string[0];

                                    colFields = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                    if (colFields.Length < largestIndex) continue;

                                    LineNumber++;

                                    TerminalID = string.Empty;
                                    AcquirerID = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    CardNumber = string.Empty;
                                    FromAccount = string.Empty;
                                    ToAccount = string.Empty;
                                    InterchangeAccountNo = string.Empty;
                                    ATMAccountNo = string.Empty;
                                    TxnsDateTime = string.Empty;
                                    TxnsDate = string.Empty;
                                    TxnsTime = string.Empty;
                                    TxnsAmount = "0";
                                    Amount1 = "0";
                                    Amount2 = "0";
                                    Amount3 = "0";
                                    ChannelType = string.Empty;
                                    TxnsSubType = string.Empty;
                                    TxnsNumber = string.Empty;
                                    TxnsPerticulars = string.Empty;
                                    DrCrType = string.Empty;
                                    ResponseCode1 = string.Empty;
                                    ResponseCode2 = string.Empty;
                                    ReversalCode1 = string.Empty;
                                    ReversalCode2 = string.Empty;
                                    TxnsPostDateTime = string.Empty;
                                    TxnsValueDateTime = string.Empty;
                                    TxnsDateTimeDiff = string.Empty;
                                    AuthCode = string.Empty;
                                    ProcessingCode = string.Empty;
                                    FeeAmount = "0";
                                    CurrencyCode = string.Empty;
                                    CustBalance = "0";
                                    InterchangeBalance = "0";
                                    ATMBalance = "0";
                                    DestinationAmount = "0";
                                    BranchCode = string.Empty;
                                    ReserveField1 = string.Empty;
                                    ReserveField2 = string.Empty;
                                    ReserveField3 = string.Empty;
                                    ReserveField4 = string.Empty;
                                    ReserveField5 = string.Empty;
                                    NoOfDuplicate = string.Empty;
                                    ECardNumber = string.Empty;
                                    DestinationCurrencyCode = string.Empty;
                                    SourceCurrencyCode = string.Empty;
                                    NetworkType = string.Empty;

                                    AcquirerID = AcquirerID_CoulmnIndex > 0 ? Convert.ToString(colFields[AcquirerID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TerminalID = TerminalID_CoulmnIndex > 0 ? Convert.ToString(colFields[TerminalID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(colFields[ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    CardNumber = CardNumber_CoulmnIndex > 0 ? Convert.ToString(colFields[CardNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    //   ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    InterchangeAccountNo = InterchangeAccountNo_CoulmnIndex > 0 ? Convert.ToString(colFields[InterchangeAccountNo_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ATMAccountNo = ATMAccountNo_CoulmnIndex > 0 ? Convert.ToString(colFields[ATMAccountNo_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsAmount_CoulmnIndex - Incr]) : string.Empty;
                                    Amount1 = Amount1_CoulmnIndex > 0 ? Convert.ToString(colFields[Amount1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DestinationAmount = DestinationAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[DestinationAmount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    SourceCurrencyCode = SourceCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(colFields[SourceCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DestinationCurrencyCode = DestinationCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(colFields[DestinationCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    TxnsSubType = TxnsSubType_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsSubType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    ChannelType = ChannelType_CoulmnIndex > 0 ? Convert.ToString(colFields[ChannelType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsNumber = TxnsNumber_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsPerticulars = TxnsPerticulars_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsPerticulars_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DrCrType = DrCrType_CoulmnIndex > 0 ? Convert.ToString(colFields[DrCrType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ResponseCode1 = ResponseCode1_CoulmnIndex > 0 ? Convert.ToString(colFields[ResponseCode1_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    ResponseCode2 = ResponseCode2_CoulmnIndex > 0 ? Convert.ToString(colFields[ResponseCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReversalCode1 = ReversalCode1_CoulmnIndex > 0 ? Convert.ToString(colFields[ReversalCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReversalCode2 = ReversalCode2_CoulmnIndex > 0 ? Convert.ToString(colFields[ReversalCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsValueDateTime = TxnsValueDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsValueDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    AuthCode = AuthCode_CoulmnIndex > 0 ? Convert.ToString(colFields[AuthCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ProcessingCode = ProcessingCode_CoulmnIndex > 0 ? Convert.ToString(colFields[ProcessingCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    FeeAmount = FeeAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[FeeAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    //CurrencyCode = CurrencyCode_CoulmnIndex > 0 ? Convert.ToString(colFields[CurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    CustBalance = CustBalance_CoulmnIndex > 0 ? Convert.ToString(colFields[CustBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    InterchangeBalance = InterchangeBalance_CoulmnIndex > 0 ? Convert.ToString(colFields[InterchangeBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ATMBalance = ATMBalance_CoulmnIndex > 0 ? Convert.ToString(colFields[ATMBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    BranchCode = BranchCode_CoulmnIndex > 0 ? Convert.ToString(colFields[BranchCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField5 = ReserveField5_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField5_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    #region StanderedFields 

                                    ReversalFlag = false;
                                    TxnsStatus = string.Empty;
                                    DebitCreditType = string.Empty;
                                    TxnsType = string.Empty;
                                    TxnsSubTypeMain = string.Empty;
                                    TxnsEntryType = string.Empty;
                                    CardType = string.Empty;
                                    TxnsDateTimeMain = null;
                                    TxnsPostDateTimeMain = null;



                                    #region ValidateField
                                    if (TxnsDate.Length > 0 && TxnsTime.Length > 0 && TxnDateTimeFormat.Length > 0)
                                    {
                                        TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;
                                        if (TxnsDate.Contains("/") && TxnsTime.Contains(":"))
                                        {
                                            string[] dateAndTime = TxnsDateTimeDiff.Split(' ');
                                            string[] dateParts = dateAndTime[0].Split('/');
                                            string[] timeParts = dateAndTime[1].Split(':');
                                            TxnsDateTimeDiff = $"{dateParts[0]}{dateParts[1]}{dateParts[2]} {timeParts[0]}{timeParts[1]}{timeParts[2]}";
                                        }

                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnDateTimeFormat.Length > 0 && TxnsDateTime.Length > 0)
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }


                                    if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime.Length > 0)
                                    {
                                        if (TxnsPostDateTime.Length < 11 && TxnsTime.Length > 0)
                                        {
                                            TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime + " " + TxnsTime, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                                        }
                                        else
                                        {
                                            TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                                        }
                                    }

                                    #endregion ValidateField


                                    #endregion StanderedFields


                                    if (CardNumber != "")
                                    {
                                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                                    }

                                    if (CardNumber != "" && CardNumber.Length == 16)
                                    {
                                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();
                                    }

                                    CardType = Common.GetCardType(CardNumber);

                                    if (TxnsAmount.Contains("#"))
                                    {
                                        string[] amount = TxnsAmount.Split('#');
                                        TxnsAmount = amount[0];
                                    }
                                    if (ToAccount.Length > 14 && fileImportRequest.ClientCode == "56")
                                    {
                                        ToAccount = ToAccount.Substring(1);
                                    }

                                    TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                    Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                    DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                    FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";
                                    CustBalance = Common.IsNumeric(CustBalance) ? CustBalance : "0";
                                    InterchangeBalance = Common.IsNumeric(InterchangeBalance) ? InterchangeBalance : "0";
                                    ATMBalance = Common.IsNumeric(ATMBalance) ? ATMBalance : "0";

                                    if (TxnsDateTimeMain != null)
                                    {
                                        _DataTable.Rows.Add(AcquirerID
                                                , ChannelType
                                                , TerminalID
                                                , ReferenceNumber
                                                , CardNumber.Trim()
                                                , FromAccount
                                                , ToAccount
                                                , InterchangeAccountNo
                                                , ATMAccountNo
                                                , TxnsDateTimeMain
                                                , Convert.ToDecimal(TxnsAmount)
                                                , Convert.ToDecimal(DestinationAmount)
                                                , Convert.ToDecimal(FeeAmount)
                                                , Convert.ToDecimal(Amount1)
                                                , SourceCurrencyCode
                                                , DestinationCurrencyCode
                                                , TxnsStatus
                                                , TxnsType
                                                , TxnsSubType
                                                , TxnsEntryType
                                                , TxnsNumber
                                                , TxnsPerticulars
                                                , DrCrType
                                                , AuthCode
                                                , ProcessingCode
                                                , ResponseCode1
                                                , ResponseCode2
                                                , ReversalCode1
                                                , ReversalCode2
                                                , ReversalFlag
                                                , TxnsPostDateTimeMain
                                                , TxnsValueDateTimeMain
                                                , RevEntryLeg
                                                , Convert.ToDecimal(CustBalance)
                                                , Convert.ToDecimal(InterchangeBalance)
                                                , Convert.ToDecimal(ATMBalance)
                                                , BranchCode
                                                , ReserveField1
                                                , ReserveField2
                                                , ReserveField3
                                                , ReserveField4
                                                , ReserveField5
                                                , ECardNumber.Trim()
                                                , CardType
                                                , NetworkType
                                                );

                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;
                                            MSG = bulkimports.BulkInsertCBSTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);
                                            _DataTable.Clear();
                                            ErrorCount = 0;
                                            StartTime = DateTime.Now;

                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }


                                    }

                                }
                                catch (Exception ex)
                                {

                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    //  _logger.LogInformation("Error At Inserting data into Datatable : {ex} ", ex);
                                    ErrorCount++;

                                }
                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertCBSTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime String : " + tempTxnDateTime;
                        MSG = fileImportRequest.ErrorMessage;
                    }
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }
               
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = _DataTable.Rows.Count,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = 1,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));
            
            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string SplitterExcel_Dynamic_UPI(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();
            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataSet _dataSetUpi = new DataSet();
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("TxnsID", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("PayerIFSC", typeof(string));
            _DataTable.Columns.Add("PayeeIFSC", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;
            string RevEntryLeg = string.Empty;
            string ChannelType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";

            string TxnsSubType = string.Empty;
            string TxnsStatus = string.Empty;
            string TxnsID = string.Empty;
            string PayerIFSC = string.Empty;
            string PayeeIFSC = string.Empty;

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;


            string NetworkType = string.Empty;


            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;



            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;
            string line1 = string.Empty;
            bool ErrorOccurred = false;

            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Amount1_CoulmnIndex = 0;
            ushort DestinationAmount_CoulmnIndex = 0;
            ushort DestinationCurrencyCode_CoulmnIndex = 0;
            ushort SourceCurrencyCode_CoulmnIndex = 0;
            ushort ChannelType_CoulmnIndex = 0;
            ushort TxnsPerticulars_CoulmnIndex = 0;
            ushort DrCrType_CoulmnIndex = 0;
            ushort ResponseCode1_CoulmnIndex = 0;
            ushort ResponseCode2_CoulmnIndex = 0;
            ushort ReversalCode1_CoulmnIndex = 0;
            ushort ReversalCode2_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort TxnsValueDateTime_CoulmnIndex = 0;
            ushort AuthCode_CoulmnIndex = 0;
            ushort ProcessingCode_CoulmnIndex = 0;
            ushort FeeAmount_CoulmnIndex = 0;
            ushort TxnsID_CoulmnIndex = 0;
            ushort TxnsSubType_CoulmnIndex = 0;
            ushort TxnsStatus_CoulmnIndex = 0;
            ushort PayerIFSC_CoulmnIndex = 0;
            ushort PayeeIFSC_CoulmnIndex = 0;

            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;
            ushort ReserveField5_CoulmnIndex = 0;

            try
            {

                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));


                ChannelType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChannelType"]);
                TxnsStatus_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsStatus"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TxnsID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsID"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                DestinationAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationAmount"]);
                FeeAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FeeAmount"]);
                Amount1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount1"]);
                DestinationCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationCurrencyCode"]);
                SourceCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SourceCurrencyCode"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                TxnsSubType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsSubType"]);
                TxnsStatus_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsStatus"]);
                TxnsPerticulars_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPerticulars"]);
                DrCrType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DrCrType"]);
                AuthCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AuthCode"]);
                ProcessingCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ProcessingCode"]);
                TxnsPostDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPostDateTime"]);
                TxnsValueDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsValueDateTime"]);
                ResponseCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode1"]);
                ResponseCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode2"]);
                ReversalCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode1"]);
                ReversalCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode2"]);

                PayerIFSC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerIFSC"]);
                PayeeIFSC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeIFSC"]);

                ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ReserveField3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField3"]);
                ReserveField4_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField4"]);
                ReserveField5_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField5"]);
     
                //  _logger.LogInformation("The Total Count is : {fileImportRequest.TotalCount} ", fileImportRequest.TotalCount);

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;
                try
                {
                    //Get Batch Size
                    batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                    DataTable dtexcelsheetname = new DataTable();
                    DataTable dtSheet = new DataTable();
                    //Read the connection string for the Excel file.
                    string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                    conString = string.Format(conString, fileImportRequest.Path);

                    using (OleDbConnection connExcel = new OleDbConnection(conString))
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            connExcel.Open();
                            //Get the name of First Sheet. 
                            dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            connExcel.Close();
                        }
                    }

                    if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                    {

                        int j = 0;
                        int SheetLineNumber = 0;

                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }
                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }


                            foreach (DataRow row in dtexcelsheetname.Rows)
                            {
                                dtSheet = new DataTable();

                                if (conString.Contains("HTML Import"))
                                {
                                    try
                                    {
                                        dtSheet = HtmlExcelReader.ReadHtmlExcel(fileImportRequest.Path, j + 1);
                                    }
                                    catch
                                    {
                                        j++;
                                        continue;
                                    }
                                }
                                else
                                {
                                    using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                                    {
                                        using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                        {
                                            using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                            {
                                                //Read Data from First Sheet.
                                                cmdExcelSheet.Connection = connExcelSheet;
                                                connExcelSheet.Open();
                                                cmdExcelSheet.CommandText = "SELECT * From [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                                                odaExcelSheet.SelectCommand = cmdExcelSheet;
                                                odaExcelSheet.Fill(dtSheet);
                                                connExcelSheet.Close();
                                            }
                                        }
                                    }
                                }

                                Incr = 1;

                                if (dtSheet.Rows.Count > 0)
                                {
                                    // Find first data row based on whether the "Join Date" cell can be parsed as a date
                                    int dateStartIndex = -1;

                                    for (int i = 0; i < dtSheet.Rows.Count; i++)
                                    {
                                        try
                                        {
                                            if (TxnsDateTime_CoulmnIndex > 0)
                                            {
                                                tempTxnDateTime = dtSheet.Rows[i][TxnsDateTime_CoulmnIndex - Incr]?.ToString()?.Trim();

                                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                                if (isValid)
                                                {
                                                    dateStartIndex = i;
                                                    break;
                                                }

                                            }
                                            else if (TxnsDate_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                                            {
                                                tempTxnDateTime = dtSheet.Rows[i][TxnsDate_CoulmnIndex - Incr]?.ToString()?.Trim() + " " + dtSheet.Rows[i][TxnsTime_CoulmnIndex - Incr]?.ToString()?.Trim();

                                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                                if (isValid)
                                                {
                                                    dateStartIndex = i;
                                                    break;
                                                }

                                            }
                                        }
                                        catch
                                        {
                                            SheetDateError++;
                                        }

                                        if (i > 25)
                                            break;
                                    }

                                    if (dateStartIndex > -1)
                                    {
                                        fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                                        {
                                            LineNo++;
                                            SheetLineNumber++;

                                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                            {
                                                continue;
                                            }

                                            try
                                            {
                                                AcquirerID = string.Empty;
                                                ReferenceNumber = string.Empty;
                                                FromAccount = string.Empty;
                                                ToAccount = string.Empty;

                                                TxnsDateTime = string.Empty;
                                                TxnsDate = string.Empty;
                                                TxnsTime = string.Empty;
                                                TxnsAmount = "0";
                                                Amount1 = "0";

                                                ChannelType = string.Empty;
                                                TxnsPerticulars = string.Empty;
                                                TxnsStatus = string.Empty;
                                                DrCrType = string.Empty;
                                                ResponseCode1 = string.Empty;
                                                ResponseCode2 = string.Empty;
                                                ReversalCode1 = string.Empty;
                                                ReversalCode2 = string.Empty;
                                                TxnsPostDateTime = string.Empty;
                                                TxnsValueDateTime = string.Empty;
                                                TxnsDateTimeDiff = string.Empty;
                                                AuthCode = string.Empty;
                                                ProcessingCode = string.Empty;
                                                FeeAmount = "0";
                                                DestinationAmount = "0";

                                                TxnsSubType = string.Empty;
                                                TxnsID = string.Empty;
                                                PayerIFSC = string.Empty;
                                                PayeeIFSC = string.Empty;

                                                ReserveField1 = string.Empty;
                                                ReserveField2 = string.Empty;
                                                ReserveField3 = string.Empty;
                                                ReserveField4 = string.Empty;
                                                ReserveField5 = string.Empty;

                                                DestinationCurrencyCode = string.Empty;
                                                SourceCurrencyCode = string.Empty;
                                                NetworkType = string.Empty;

                                                ChannelType = ChannelType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ChannelType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsAmount_CoulmnIndex - Incr]) : string.Empty;
                                                Amount1 = Amount1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Amount1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DestinationAmount = DestinationAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DestinationAmount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsSubType = TxnsSubType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsSubType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsID = TxnsID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsPerticulars = TxnsPerticulars_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsPerticulars_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsStatus = TxnsStatus_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsStatus_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DrCrType = DrCrType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DrCrType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ResponseCode1 = ResponseCode1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ResponseCode2 = ResponseCode2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReversalCode1 = ReversalCode1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReversalCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReversalCode2 = ReversalCode2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReversalCode2_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsValueDateTime = TxnsValueDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsValueDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AuthCode = AuthCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AuthCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ProcessingCode = ProcessingCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ProcessingCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                FeeAmount = FeeAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FeeAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                SourceCurrencyCode = SourceCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SourceCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DestinationCurrencyCode = DestinationCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DestinationCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                PayerIFSC = PayerIFSC_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayerIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                PayeeIFSC = PayeeIFSC_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayeeIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField5 = ReserveField5_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField5_CoulmnIndex - Incr]).Trim() : string.Empty;


                                                TxnsDateTimeMain = null;
                                                TxnsPostDateTimeMain = null;


                                                if (TxnsDate != "" && TxnsTime != "")
                                                {
                                                    if (TxnsTime.Length < 6 && !TxnsTime.Contains(":"))
                                                    {
                                                        TxnsTime = TxnsTime.PadLeft(6, '0');
                                                    }

                                                    TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                                {
                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime != "")
                                                {
                                                    DateTime dateTime = DateTime.Parse(TxnsPostDateTime);
                                                    string formattedDate = dateTime.ToString(TxnPostDateTimeFormat[0]);
                                                    TxnsPostDateTimeMain = DateTime.ParseExact(formattedDate, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                                                }


                                                TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                                Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                                DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                                FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";


                                                if (TxnsDateTimeMain != null && ReferenceNumber.Trim().Length > 0)
                                                {

                                                    // _logger.LogInformation("Date time Correct : ", TxnsDateTimeMain);

                                                    _DataTable.Rows.Add(
                                                             ChannelType
                                                            , ReferenceNumber
                                                            , TxnsDateTimeMain
                                                            , Convert.ToDecimal(TxnsAmount)
                                                            , TxnsID
                                                            , FromAccount
                                                            , ToAccount
                                                            , Convert.ToDecimal(DestinationAmount)
                                                            , Convert.ToDecimal(FeeAmount)
                                                            , Convert.ToDecimal(Amount1)
                                                            , SourceCurrencyCode
                                                            , DestinationCurrencyCode
                                                            , TxnsSubType
                                                            , TxnsStatus
                                                            , TxnsPerticulars
                                                            , DrCrType
                                                            , AuthCode
                                                            , ProcessingCode
                                                            , ResponseCode1
                                                            , ResponseCode2
                                                            , ReversalCode1
                                                            , ReversalCode2
                                                            , TxnsPostDateTimeMain
                                                            , TxnsValueDateTimeMain
                                                            , PayerIFSC
                                                            , PayeeIFSC
                                                            , ReserveField1
                                                            , ReserveField2
                                                            , ReserveField3
                                                            , ReserveField4
                                                            , ReserveField5
                                                            , NetworkType
                                                            );


                                                    if (_DataTable.Rows.Count >= batchSize)
                                                    {
                                                        BatchNo++;

                                                        MSG = bulkimports.BulkInsertCBSTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                        fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                                        // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                                                        BatchDetails batchDetails = new BatchDetails
                                                        {
                                                            BatchNo = BatchNo,
                                                            BatchSize = batchSize,
                                                            TxnUploadCount = _DataTable.Rows.Count,
                                                            TxnsCount = fileImportRequest.InsertCount,
                                                            BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                            FailedCount = ErrorCount,
                                                            BatchStartTime = batchStartTime,
                                                            BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                        };

                                                        batchDetailsList.Add(batchDetails);
                                                        _DataTable.Clear();
                                                        StartTime = DateTime.Now;
                                                        ErrorCount = 0;
                                                        if (NewEntry)
                                                        {
                                                            break;
                                                        }
                                                    }
                                                }



                                            }
                                            catch (Exception ex)
                                            {
                                                // _logger.LogInformation("Error At Inserting data into Datatable : ", ex);
                                                ErrorCount++;
                                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (dtexcelsheetname.Rows.Count > 1 && conString.Contains("HTML Import"))
                                        {
                                            dateStartIndex = 0;
                                        }
                                        else
                                        {
                                            if (j == 0)
                                            {
                                                fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                                                MSG = fileImportRequest.ErrorMessage;
                                            }
                                            break;
                                        }
                                    }
                                }
                                j++;
                            }
                            LineNo = 0;
                        }
                    }

                    if (_DataTable.Rows.Count > 0)
                    {
                        BatchNo = BatchNo + 1;

                        fileImportRequest.InsertCount += _DataTable.Rows.Count;

                        MSG = bulkimports.BulkInsertCBSTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                        //  _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                        BatchDetails batchDetails = new BatchDetails
                        {
                            BatchNo = BatchNo,
                            BatchSize = batchSize,
                            TxnUploadCount = _DataTable.Rows.Count,
                            TxnsCount = fileImportRequest.InsertCount,
                            BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                            FailedCount = ErrorCount,
                            BatchStartTime = batchStartTime,
                            BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                        };

                        batchDetailsList.Add(batchDetails);
                    }
                    else if (_DataTable.Rows.Count == 0 && fileImportRequest.ErrorMessage.Length == 0 && fileImportRequest.TotalCount == 0 )
                    {
                        MSG = "Successful";
                    }
                }
                catch (Exception ex)
                {
                    // objLogWriter.FunErrorLog(ex.Message.ToString(), fileImportRequest.ClientCode, "ASP_CBS_Splitter.cs", "SplitData", LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }

            }
            else
            {
                MSG = fileImportRequest.ErrorMessage;

                BatchNo = BatchNo + 1;

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = 1,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);
            }

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }

        public string SplitterDelimiter_Dynamic_UPI(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0, LineNumber = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();
            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataSet _dataSetUpi = new DataSet();
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("TxnsID", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("PayerIFSC", typeof(string));
            _DataTable.Columns.Add("PayeeIFSC", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;
            string RevEntryLeg = string.Empty;
            string ChannelType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string TxnsSubType = string.Empty;
            string TxnsStatus = string.Empty;
            string TxnsID = string.Empty;
            string PayerIFSC = string.Empty;
            string PayeeIFSC = string.Empty;

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;


            string NetworkType = string.Empty;

            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;

            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;
            string[] colFields = null;
            string line1 = string.Empty;
            bool ErrorOccurred = false;

            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Amount1_CoulmnIndex = 0;
            ushort DestinationAmount_CoulmnIndex = 0;
            ushort DestinationCurrencyCode_CoulmnIndex = 0;
            ushort SourceCurrencyCode_CoulmnIndex = 0;
            ushort ChannelType_CoulmnIndex = 0;
            ushort TxnsSubType_CoulmnIndex = 0;
            ushort TxnsStatus_CoulmnIndex = 0;
            ushort TxnsPerticulars_CoulmnIndex = 0;
            ushort DrCrType_CoulmnIndex = 0;
            ushort ResponseCode1_CoulmnIndex = 0;
            ushort ResponseCode2_CoulmnIndex = 0;
            ushort ReversalCode1_CoulmnIndex = 0;
            ushort ReversalCode2_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort TxnsValueDateTime_CoulmnIndex = 0;
            ushort AuthCode_CoulmnIndex = 0;
            ushort ProcessingCode_CoulmnIndex = 0;
            ushort FeeAmount_CoulmnIndex = 0;
            ushort TxnsID_CoulmnIndex = 0;

            ushort PayerIFSC_CoulmnIndex = 0;
            ushort PayeeIFSC_CoulmnIndex = 0;

            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;
            ushort ReserveField5_CoulmnIndex = 0;
            int largestIndex = 0, CoulmnIndex = 0;

            try
            {
                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));


                ChannelType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChannelType"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TxnsID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsID"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                DestinationAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationAmount"]);
                FeeAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FeeAmount"]);
                Amount1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount1"]);
                DestinationCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationCurrencyCode"]);
                SourceCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SourceCurrencyCode"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                TxnsSubType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsSubType"]);
                TxnsStatus_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsStatus"]);
                TxnsPerticulars_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPerticulars"]);
                DrCrType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DrCrType"]);
                AuthCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AuthCode"]);
                ProcessingCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ProcessingCode"]);
                TxnsPostDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPostDateTime"]);
                TxnsValueDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsValueDateTime"]);
                ResponseCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode1"]);
                ResponseCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode2"]);
                ReversalCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode1"]);
                ReversalCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode2"]);

                PayerIFSC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerIFSC"]);
                PayeeIFSC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeIFSC"]);

                ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ReserveField3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField3"]);
                ReserveField4_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField4"]);
                ReserveField5_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField5"]); 
                
                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                { 
                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            colFields = new string[0];

                            colFields = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);


                            if (TxnsDateTime_CoulmnIndex > 0)
                            {
                                tempTxnDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                            else if (TxnsDate_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                            {
                                TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                tempTxnDateTime = TxnsDate + " " + TxnsTime;
                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }

                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                try
                                {
                                    if (LineNo < dateStartIndex)
                                    {
                                        LineNumber++;
                                        LineNo++;
                                        continue;
                                    }

                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }
                                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                    colFields = new string[0];

                                    colFields = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                    if (colFields.Length < largestIndex) continue;

                                    LineNumber++;

                                    AcquirerID = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    FromAccount = string.Empty;
                                    ToAccount = string.Empty;

                                    TxnsDateTime = string.Empty;
                                    TxnsDate = string.Empty;
                                    TxnsTime = string.Empty;
                                    TxnsAmount = "0";
                                    Amount1 = "0";

                                    ChannelType = string.Empty;
                                    TxnsPerticulars = string.Empty;
                                    DrCrType = string.Empty;
                                    ResponseCode1 = string.Empty;
                                    ResponseCode2 = string.Empty;
                                    ReversalCode1 = string.Empty;
                                    ReversalCode2 = string.Empty;
                                    TxnsPostDateTime = string.Empty;
                                    TxnsValueDateTime = string.Empty;
                                    TxnsDateTimeDiff = string.Empty;
                                    AuthCode = string.Empty;
                                    ProcessingCode = string.Empty;
                                    FeeAmount = "0";
                                    DestinationAmount = "0";
                                    TxnsSubType = string.Empty;
                                    TxnsStatus = string.Empty;
                                    TxnsID = string.Empty;
                                    PayerIFSC = string.Empty;
                                    PayeeIFSC = string.Empty;

                                    ReserveField1 = string.Empty;
                                    ReserveField2 = string.Empty;
                                    ReserveField3 = string.Empty;
                                    ReserveField4 = string.Empty;
                                    ReserveField5 = string.Empty;

                                    DestinationCurrencyCode = string.Empty;
                                    SourceCurrencyCode = string.Empty;
                                    NetworkType = string.Empty;

                                    ChannelType = ChannelType_CoulmnIndex > 0 ? Convert.ToString(colFields[ChannelType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(colFields[ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsAmount_CoulmnIndex - Incr]) : string.Empty;
                                    Amount1 = Amount1_CoulmnIndex > 0 ? Convert.ToString(colFields[Amount1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DestinationAmount = DestinationAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[DestinationAmount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    TxnsSubType = TxnsSubType_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsSubType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsStatus = TxnsStatus_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsStatus_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsID = TxnsID_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsPerticulars = TxnsPerticulars_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsPerticulars_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DrCrType = DrCrType_CoulmnIndex > 0 ? Convert.ToString(colFields[DrCrType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    ResponseCode1 = ResponseCode1_CoulmnIndex > 0 ? Convert.ToString(colFields[ResponseCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ResponseCode2 = ResponseCode2_CoulmnIndex > 0 ? Convert.ToString(colFields[ResponseCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReversalCode1 = ReversalCode1_CoulmnIndex > 0 ? Convert.ToString(colFields[ReversalCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReversalCode2 = ReversalCode2_CoulmnIndex > 0 ? Convert.ToString(colFields[ReversalCode2_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsValueDateTime = TxnsValueDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsValueDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    AuthCode = AuthCode_CoulmnIndex > 0 ? Convert.ToString(colFields[AuthCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ProcessingCode = ProcessingCode_CoulmnIndex > 0 ? Convert.ToString(colFields[ProcessingCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    FeeAmount = FeeAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[FeeAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    SourceCurrencyCode = SourceCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(colFields[SourceCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DestinationCurrencyCode = DestinationCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(colFields[DestinationCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    PayerIFSC = PayerIFSC_CoulmnIndex > 0 ? Convert.ToString(colFields[PayerIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    PayeeIFSC = PayeeIFSC_CoulmnIndex > 0 ? Convert.ToString(colFields[PayeeIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField5 = ReserveField5_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField5_CoulmnIndex - Incr]).Trim() : string.Empty;


                                    TxnsDateTimeMain = null;
                                    TxnsPostDateTimeMain = null;


                                    if (TxnsDate != "" && TxnsTime != "")
                                    {
                                        if (TxnsTime.Length < 6 && !TxnsTime.Contains(":"))
                                        {
                                            TxnsTime = TxnsTime.PadLeft(6, '0');
                                        }

                                        TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime != "")
                                    {
                                        DateTime dateTime = DateTime.Parse(TxnsPostDateTime);
                                        string formattedDate = dateTime.ToString(TxnPostDateTimeFormat[0]);
                                        TxnsPostDateTimeMain = DateTime.ParseExact(formattedDate, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                                    }


                                    TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                    Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                    DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                    FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";


                                    if (TxnsDateTimeMain != null && ReferenceNumber.Trim().Length > 0)
                                    {
                                        _DataTable.Rows.Add(
                                                 ChannelType
                                                , ReferenceNumber
                                                , TxnsDateTimeMain
                                                , Convert.ToDecimal(TxnsAmount)
                                                , TxnsID
                                                , FromAccount
                                                , ToAccount
                                                , Convert.ToDecimal(DestinationAmount)
                                                , Convert.ToDecimal(FeeAmount)
                                                , Convert.ToDecimal(Amount1)
                                                , SourceCurrencyCode
                                                , DestinationCurrencyCode
                                                , TxnsSubType
                                                , TxnsStatus
                                                , TxnsPerticulars
                                                , DrCrType
                                                , AuthCode
                                                , ProcessingCode
                                                , ResponseCode1
                                                , ResponseCode2
                                                , ReversalCode1
                                                , ReversalCode2
                                                , TxnsPostDateTimeMain
                                                , TxnsValueDateTimeMain
                                                , PayerIFSC
                                                , PayeeIFSC
                                                , ReserveField1
                                                , ReserveField2
                                                , ReserveField3
                                                , ReserveField4
                                                , ReserveField5
                                                , NetworkType
                                                );


                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;

                                            MSG = bulkimports.BulkInsertCBSTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                            // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);
                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }
                                    }



                                }
                                catch (Exception ex)
                                {
                                    // _logger.LogInformation("Error At Inserting data into Datatable : ", ex);
                                    ErrorCount++;
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                }
                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;


                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertCBSTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                            
                        }
                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        MSG = fileImportRequest.ErrorMessage;
                    }

                   
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = 1,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }

        public string Splitter_GL_Adjustment_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            // string localIP = bulkimports.GetLocalIPAddress();
            //string? Classname = currentMethod?.DeclaringType?.Name;


            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();
            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataTable _DataTable = new DataTable();
            //_DataTable.Columns.Add("ClientID", typeof(int));
            //_DataTable.Columns.Add("ChannelID", typeof(int));
            //_DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("DEBIT_AMOUNT", typeof(decimal));
            _DataTable.Columns.Add("CREDIT_AMOUNT", typeof(decimal));
            _DataTable.Columns.Add("BALANCE", typeof(decimal));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("Closing_BALANCE", typeof(decimal));
            _DataTable.Columns.Add("Ntr_Of_Bal", typeof(string));
            _DataTable.Columns.Add("Batch_Seq", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));

            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;
            string[] colFields = null;
            string line1 = string.Empty;
            bool ErrorOccurred = false;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;

            string Prev_TxnsPostDateTime = string.Empty;

            int Incr = 1;
            string TxnsDateTime = string.Empty;
            string ReferenceNumber = string.Empty;
            string Description = string.Empty;
            string DEBIT_AMOUNT = string.Empty;
            string CREDIT_AMOUNT = string.Empty;
            string BALANCE = string.Empty;
            string Closing_BALANCE = string.Empty;
            string Ntr_Of_Bal = string.Empty;
            string Batch_Seq = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;

            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort Description_CoulmnIndex = 0;
            ushort DEBIT_AMOUNT_CoulmnIndex = 0;
            ushort CREDIT_AMOUNT_CoulmnIndex = 0;
            ushort BALANCE_CoulmnIndex = 0;
            ushort Closing_BALANCE_CoulmnIndex = 0;
            ushort Ntr_Of_Bal_CoulmnIndex = 0;
            ushort Batch_Seq_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;

            int QChannelID = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ChannelID"]) == "" ? 0 : Convert.ToInt16(fileImportRequest.ConfigData.Rows[0]["ChannelID"]);

            try
            {
                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));


                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                Description_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Description"]);
                DEBIT_AMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DEBIT_AMOUNT"]);
                CREDIT_AMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CREDIT_AMOUNT"]);
                BALANCE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BALANCE"]);
                Closing_BALANCE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Closing_BALANCE"]);
                Ntr_Of_Bal_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Ntr_Of_Bal"]);
                Batch_Seq_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Batch_Seq"]);


                // TxnsPostDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPostDateTime"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ReserveField3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField3"]);
                ReserveField4_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField4"]);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
                fileImportRequest.TotalCount = TotalCountArray.Length;

                //  _logger.LogInformation("The Total Count is : {fileImportRequest.TotalCount} ", fileImportRequest.TotalCount);

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                //if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                //{
                //    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                //    ErrorOccurred = true;
                //}

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");


            if (!ErrorOccurred)
            {
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                foreach (var batchDetail in fileImportRequest.FailedBatches)
                {
                    if (batchDetail.BatchNo != 0)
                    {
                        BatchNo = batchDetail.BatchNo - 1;
                    }


                    bool NewEntry = false;

                    if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                    {
                        //set the flag if it is new Entry
                        NewEntry = false;
                    }
                    else
                    {
                        if (batchDetail.BatchStatus == "None")
                        {
                            break;
                        }
                        else
                        {
                            //set the flag if it is old and  Partial Entry
                            NewEntry = true;
                        }
                    }

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            LineNo++;

                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                            {
                                continue;
                            }
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            colFields = new string[0];

                            colFields = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            TxnsDateTime = string.Empty;
                            ReferenceNumber = string.Empty;
                            Description = string.Empty;
                            DEBIT_AMOUNT = string.Empty;
                            CREDIT_AMOUNT = string.Empty;
                            BALANCE = string.Empty;
                            Closing_BALANCE = string.Empty;
                            Ntr_Of_Bal = string.Empty;
                            Batch_Seq = string.Empty;
                            TxnsPostDateTime = string.Empty;
                            FromAccount = string.Empty;
                            ToAccount = string.Empty;
                            ReserveField1 = string.Empty;
                            ReserveField2 = string.Empty;
                            ReserveField3 = string.Empty;
                            ReserveField4 = string.Empty;



                            TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                            ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(colFields[ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Description = Description_CoulmnIndex > 0 ? Convert.ToString(colFields[Description_CoulmnIndex - Incr]).Trim() : string.Empty;
                            DEBIT_AMOUNT = DEBIT_AMOUNT_CoulmnIndex > 0 ? Convert.ToString(colFields[DEBIT_AMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                            CREDIT_AMOUNT = CREDIT_AMOUNT_CoulmnIndex > 0 ? Convert.ToString(colFields[CREDIT_AMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                            BALANCE = BALANCE_CoulmnIndex > 0 ? Convert.ToString(colFields[BALANCE_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Closing_BALANCE = Closing_BALANCE_CoulmnIndex > 0 ? Convert.ToString(colFields[Closing_BALANCE_CoulmnIndex - Incr]).Trim() : string.Empty; ;
                            Ntr_Of_Bal = Ntr_Of_Bal_CoulmnIndex > 0 ? Convert.ToString(colFields[Ntr_Of_Bal_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Batch_Seq = Batch_Seq_CoulmnIndex > 0 ? Convert.ToString(colFields[Batch_Seq_CoulmnIndex - Incr]).Trim() : string.Empty;
                            // TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                            FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                            ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                            ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                            ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                            ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                            ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;


                            //if (TxnsDate != "" && TxnsTime != "")
                            //{
                            //    if (TxnsTime.Length < 6 && !TxnsTime.Contains(":"))
                            //    {
                            //        TxnsTime = TxnsTime.PadLeft(6, '0');
                            //    }

                            //    TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                            //    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                            //}

                            if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                            }

                            if (ReserveField1.Length > 0 && ReserveField1 != null)
                            {
                                string[] parts = ReserveField1.Split('/');
                                TxnsPostDateTime = parts[^1];

                                if (TxnsPostDateTime.Length == 5 && QChannelID == 7)
                                {
                                    string lastTwoCharacters = Prev_TxnsPostDateTime.Substring(Prev_TxnsPostDateTime.Length - 2);
                                    string modifiedTarget = TxnsPostDateTime.Substring(0, TxnsPostDateTime.Length - 1) + lastTwoCharacters;

                                    TxnsPostDateTime = modifiedTarget;
                                }
                                else
                                {
                                    Prev_TxnsPostDateTime = TxnsPostDateTime;
                                }
                            }

                            if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime != "" && TxnPostDateTimeFormat[0] != "" && TxnPostDateTimeFormat != null)
                            {
                                TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                            }
                            DEBIT_AMOUNT = Common.IsNumeric(DEBIT_AMOUNT) ? DEBIT_AMOUNT : "0";
                            CREDIT_AMOUNT = Common.IsNumeric(CREDIT_AMOUNT) ? CREDIT_AMOUNT : "0";
                            BALANCE = Common.IsNumeric(BALANCE) ? BALANCE : "0";
                            Closing_BALANCE = Common.IsNumeric(Closing_BALANCE) ? Closing_BALANCE : "0";
                            //  Ntr_Of_Bal = Common.IsNumeric(Ntr_Of_Bal) ? Ntr_Of_Bal : "0";
                            //Batch_Seq = string.Empty;

                            if (TxnsDateTimeMain != null)
                            {

                                // _logger.LogInformation("Date time Correct : ", TxnsDateTimeMain);

                                _DataTable.Rows.Add(
                                            TxnsDateTimeMain,
                                            TxnsPostDateTimeMain,
                                            ReferenceNumber,
                                            Description,
                                            DEBIT_AMOUNT,
                                            CREDIT_AMOUNT,
                                            BALANCE,
                                            FromAccount,
                                            ToAccount,
                                            Closing_BALANCE,
                                            Ntr_Of_Bal,
                                            Batch_Seq,
                                            ReserveField1,
                                            ReserveField2,
                                            ReserveField3,
                                            ReserveField4
                                        );


                                if (_DataTable.Rows.Count >= batchSize)
                                {
                                    BatchNo++;

                                    MSG = bulkimports.BulkInsertGLAdjustmentALL(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                    // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                                    BatchDetails batchDetails = new BatchDetails
                                    {
                                        BatchNo = BatchNo,
                                        BatchSize = batchSize,
                                        TxnUploadCount = _DataTable.Rows.Count,
                                        TxnsCount = fileImportRequest.InsertCount,
                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                        FailedCount = ErrorCount,
                                        BatchStartTime = batchStartTime,
                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                    };

                                    batchDetailsList.Add(batchDetails);
                                    _DataTable.Clear();
                                    StartTime = DateTime.Now;
                                    ErrorCount = 0;
                                    if (NewEntry)
                                    {
                                        break;
                                    }
                                }
                            }



                        }
                        catch (Exception ex)
                        {
                            // _logger.LogInformation("Error At Inserting data into Datatable : ", ex);
                            ErrorCount++;
                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                        }
                    }



                    LineNo = 0;
                }

                if (_DataTable.Rows.Count > 0)
                {
                    BatchNo = BatchNo + 1;

                    fileImportRequest.InsertCount += _DataTable.Rows.Count;
                    //MSG = objIImportLogs.BulkInsertGLAdjustmentALL(_DataTable, fileImportRequest.Path, sFileName, file.fileImportRequest.UserName);
                    MSG = bulkimports.BulkInsertGLAdjustmentALL(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                    //  _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                    BatchDetails batchDetails = new BatchDetails
                    {
                        BatchNo = BatchNo,
                        BatchSize = batchSize,
                        TxnUploadCount = _DataTable.Rows.Count,
                        TxnsCount = fileImportRequest.InsertCount,
                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                        FailedCount = ErrorCount,
                        BatchStartTime = batchStartTime,
                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    };

                    batchDetailsList.Add(batchDetails);
                }
                else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                {
                    MSG = "Successful";
                }
            }
            else
            {
                MSG = fileImportRequest.ErrorMessage;

                BatchNo = BatchNo + 1;

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = 1,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);
            }

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";



            return MSG;



        }

        public DataTable Splitter_GL_Adjustment_Delimiter_Dynamic_old(FileImportRequest fileImportRequest)
        {

            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            string Description = string.Empty;
            string Typemode = string.Empty;
            fileImportRequest.ErrorMessage = string.Empty;

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(decimal));
            _DataTable.Columns.Add("ChannelID", typeof(string));
            _DataTable.Columns.Add("ModeID", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("DEBIT_AMOUNT", typeof(decimal));
            _DataTable.Columns.Add("CREDIT_AMOUNT", typeof(decimal));
            _DataTable.Columns.Add("BALANCE", typeof(string));
            _DataTable.Columns.Add("Closing_BALANCE", typeof(decimal));
            _DataTable.Columns.Add("Ntr_Of_Bal", typeof(string));
            _DataTable.Columns.Add("Batch_Seq", typeof(string));
            _DataTable.Columns.Add("Status", typeof(decimal));



            {
                string NtrOfBal = string.Empty;
                string Closing_BAL = string.Empty;

                string[] ArrayGLLines;
                // string[] scolumn = null;
                int i = 0;
                ArrayGLLines = File.ReadAllLines(fileImportRequest.Path, System.Text.Encoding.Default);
                int totalrecords = ArrayGLLines.Length;
                while (totalrecords > i)
                {
                    fileImportRequest.TotalCount++;

                    string LBRCODE = string.Empty;
                    string PRDACCTID = string.Empty;
                    string ACTUALDAT = string.Empty;
                    string SYSTRACENUM = string.Empty;
                    string ACCOUNTNUM = string.Empty;
                    string CARDNUM = string.Empty;
                    string BRBATCH = string.Empty;
                    string BRSETNUM = string.Empty;
                    string BRENTRYDA = string.Empty;
                    string TOBRCODE = string.Empty;
                    string TOBRBATCH = string.Empty;
                    string TOBRSETNUM = string.Empty;
                    string TOBRENTRY = string.Empty;
                    string TRANSTYPE = string.Empty;
                    string ENTRYTYPE = string.Empty;
                    string TRANSTIME = string.Empty;
                    string DRCR = string.Empty;
                    string AMOUNT = string.Empty;
                    string MAINACCTNUM = string.Empty;
                    string PROCESS_CODE = string.Empty;
                    string SYS_TRACENUM = string.Empty;
                    string TERMINAL_ID = string.Empty;
                    string FRM_ACNO = string.Empty;
                    string AUTH_ID = string.Empty;
                    string RRN = string.Empty;
                    string REFERENCENO = string.Empty;
                    string ACQ_INSTITUCODE = string.Empty;
                    string TERMINAL_LOC = string.Empty;
                    string CARD_NUMBER = string.Empty;
                    string LEDGER_BAL = string.Empty;
                    string NET_BAL = string.Empty;
                    DateTime TxnsDateTime;
                    DateTime FileDate;
                    string TRANSDATE = string.Empty;
                    string RESPONSE_CODE = string.Empty;
                    string REVERSAL_CASE = string.Empty;
                    string LOROMODE = string.Empty;
                    //sLine = ArrayGLLines[i];
                    DateTime? actualdate1 = null;
                    DateTime? TRANSDATE1 = null;
                    //***************************************************************************
                    string STAN_N = string.Empty;
                    string RR_NO = string.Empty;
                    string STATION_ID = string.Empty;
                    string TXN_TI = string.Empty;
                    string TXN_TI1 = string.Empty;
                    string _DateTime = string.Empty;
                    DateTime TERMDT;//= string.Empty;
                    DateTime TERMDT1;
                    string TRAN_C = string.Empty;
                    string BANCS_JOU = string.Empty;
                    string CUSTOMER_NO = string.Empty;
                    string CARD_NO = string.Empty;
                    string TRAN_AMOUNT = string.Empty;
                    string sline = string.Empty;
                    string Atm_Pos = string.Empty;
                    string CORR_JOUR = string.Empty;
                    string PSRLNO = string.Empty;
                    string TXNTYPE = string.Empty;
                    double DebitAmt = 0;
                    double CreditAmt = 0;
                    string BAL = string.Empty;
                    string BatchSeq = string.Empty;
                    int Status = 0;
                    int ModeID = 0;
                    int ChannelID = 0;
                    //string LOROMODE = string.Empty;                       
                    //*****************************************************************************************************************************************
                    try
                    {

                        sline = ArrayGLLines[i];
                        Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
                        String[] SplitArr = CSVParser.Split(sline);
                        int len = SplitArr.Count();

                        if (len == 6 && SplitArr[5].ToString() != "OPN_BAL")
                        {
                            CreditAmt = 0;
                            DebitAmt = 0;
                            Description = "Opening Balance";
                            TXNTYPE = SplitArr[2].ToString();

                            if (TXNTYPE.Contains("UPI Inward"))
                            {
                                ChannelID = 7;
                                Typemode = "UPI Inward";
                                ModeID = 4;
                            }
                            else if (TXNTYPE.Contains("UPI Outward"))
                            {
                                ChannelID = 7;
                                Typemode = "UPI Outward";
                                ModeID = 5;
                            }
                            else if (TXNTYPE.Contains("ATM") || TXNTYPE.Contains("NFS ATM"))
                            {
                                ChannelID = 1;
                                Typemode = "ATM";
                            }
                            else if (TXNTYPE.Contains("POS") || TXNTYPE.Contains("NFS - POS") || TXNTYPE.Contains("NFS-POS-adjustment"))
                            {
                                ChannelID = 2;
                                Typemode = "POS";
                            }
                            else if (TXNTYPE.Contains("IMPS Inward") || TXNTYPE.Contains("IMPS network Inward"))
                            {
                                ChannelID = 4;
                                Typemode = "IMPS Inward";
                                ModeID = 4;
                            }
                            else if (TXNTYPE.Contains("IMPS Outward") || TXNTYPE.Contains("IMPS network outward"))
                            {
                                ChannelID = 4;
                                Typemode = "IMPS Outward";
                                ModeID = 5;
                            }
                            else if (TXNTYPE.Contains("BBPS") || TXNTYPE.Contains("BBPS Adjustment Account"))
                            {
                                ChannelID = 17;
                                Typemode = "BBPS Adjustment";
                            }

                            TXNTYPE = Typemode;
                            TxnsDateTime = Convert.ToDateTime(DateTime.ParseExact(SplitArr[3].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture));
                            BAL = SplitArr[5].ToString().Replace("CR", "").Replace("DR", "").Trim();
                            BAL = BAL.Replace("-", "").Replace("\"", "");
                            _DataTable.Rows.Add(56, ChannelID, ModeID, TxnsDateTime, REFERENCENO.Replace("\"", ""), Description, Convert.ToDecimal(DebitAmt), Convert.ToDecimal(CreditAmt), BAL, Convert.ToDecimal(Closing_BAL), NtrOfBal, BatchSeq, 0);
                        }

                        else if (len == 7 && SplitArr[5].ToString() != "Closing_Bal")
                        {
                            CreditAmt = 0;
                            DebitAmt = 0;
                            Description = SplitArr[1].ToString().Replace("\"", "");
                            string[] tmpimps = Description.Split('/');



                            if (Typemode == "IMPS Inward" || Typemode == "IMPS Outward")
                            {
                                ChannelID = 4;

                                //string strRef = "";
                                //decimal number;
                                if (tmpimps.Length > 2)
                                {
                                    if (tmpimps[0].ToString().Contains("IMPS") && tmpimps[1].ToString().Contains("P2A"))
                                    {
                                        ModeID = 4;
                                        REFERENCENO = tmpimps[2].Trim();
                                    }
                                    else if (tmpimps[0].ToString().Contains("IMPS") && tmpimps[1].ToString().Contains("P2P"))
                                    {
                                        ModeID = 4;
                                        REFERENCENO = tmpimps[2].Trim();
                                    }
                                    else
                                    {
                                        ModeID = 5;
                                        REFERENCENO = tmpimps[1].Trim();
                                    }

                                    if ((tmpimps[0].ToString().Contains("Reversal IMPS")))
                                    {
                                        Status = 4;
                                    }
                                    else
                                    {
                                        Status = 1;
                                    }
                                }


                                else
                                {
                                    if (tmpimps[0].ToLower().Contains("ret") || tmpimps[0].ToLower().Contains("rev") || Typemode == "IMPS Outward")
                                    {
                                        //REFERENCENO = tmpimps[0].Trim().Substring(tmpimps[0].Length - 6, 6);
                                        REFERENCENO = Regex.Replace(tmpimps[0].Trim(), "[^0-9]+", string.Empty);
                                    }
                                    else
                                    {
                                        //REFERENCENO = tmpimps[0].Trim().Substring(0,6);
                                        REFERENCENO = Regex.Replace(tmpimps[0].Trim(), "[^0-9]+", string.Empty);
                                    }
                                }


                            }


                            else if (Typemode == "UPI Inward" || Typemode == "UPI Outward")
                            {
                                ChannelID = 7;
                                //REFERENCENO = tmpimps[1].Trim();
                                REFERENCENO = tmpimps[1].Trim().Replace("\"", "");

                                if (SplitArr[6].ToString().Replace("\"", "").Equals("DR"))
                                {
                                    ModeID = 4;
                                }
                                else if (SplitArr[6].Replace("\"", "").ToString().Equals("CR"))
                                {
                                    ModeID = 5;
                                }


                                if ((tmpimps[0].ToString().Replace("\"", "").Contains("REVUPI")))
                                {
                                    Status = 4;
                                }
                                else
                                {
                                    Status = 1;
                                }
                            }

                            else if (Typemode == "ATM")
                            {
                                ChannelID = 1;

                                DebitAmt = Convert.ToDouble(SplitArr[2].ToString().Replace(",", "").Replace("\"", ""));
                                CreditAmt = Convert.ToDouble(SplitArr[3].ToString().Replace(",", "").Replace("\"", ""));

                                Description = SplitArr[1].ToString();
                                string[] tmpatm = Description.Split('-');
                                if (DebitAmt > 0)
                                {
                                    REFERENCENO = tmpatm[1].Trim();
                                }
                                else if (CreditAmt != 0)
                                {
                                    REFERENCENO = tmpatm[0].Trim();
                                }
                                //REFERENCENO = tmpatm[1].Trim();
                            }

                            else if (Typemode == "POS")
                            {
                                ChannelID = 2;
                                ModeID = 3;

                                DebitAmt = Convert.ToDouble(SplitArr[2].ToString().Replace(",", "").Replace("\"", ""));
                                CreditAmt = Convert.ToDouble(SplitArr[3].ToString().Replace(",", "").Replace("\"", ""));

                                Description = SplitArr[1].ToString();
                                // string[] tmpatm = Description.Split('-');//commented by Nimmi
                                if (DebitAmt > 0)
                                {
                                    // REFERENCENO = tmpatm[1].Trim();//commented by Nimmi
                                    REFERENCENO = Description;
                                }
                                else if (CreditAmt > 0)
                                {
                                    //REFERENCENO = tmpatm[0].Trim();//commented by Nimmi
                                    REFERENCENO = Description;
                                }
                                //REFERENCENO = tmpatm[1].Trim();
                            }

                            else if (Typemode == "BBPS Adjustment")
                            {

                                ChannelID = 17;

                                DebitAmt = Convert.ToDouble(SplitArr[2].ToString().Replace(",", "").Replace("\"", ""));
                                CreditAmt = Convert.ToDouble(SplitArr[3].ToString().Replace(",", "").Replace("\"", ""));
                                Description = SplitArr[1].ToString();
                                string[] tmpatm = null;
                                if (Description.Contains("-"))
                                {
                                    tmpatm = Description.Split('-');
                                    if (DebitAmt > 0)
                                    {
                                        //REFERENCENO = tmpatm[0].Trim();
                                        REFERENCENO = Description;
                                    }
                                    else if (CreditAmt != 0)
                                    {
                                        //REFERENCENO = SplitArr[1].ToString();
                                        REFERENCENO = Description;
                                    }
                                }
                                else
                                {
                                    tmpatm = Description.Split('/');
                                    if (DebitAmt > 0)
                                    {
                                        REFERENCENO = tmpatm[1].Trim();
                                    }
                                    else if (CreditAmt != 0)
                                    {
                                        REFERENCENO = SplitArr[1].ToString();
                                    }
                                }
                            }

                            TXNTYPE = Typemode;
                            TxnsDateTime = Convert.ToDateTime(DateTime.ParseExact(SplitArr[0].ToString().Replace("\"", ""), "dd/MM/yyyy", CultureInfo.InvariantCulture));
                            DebitAmt = Convert.ToDouble(SplitArr[2].ToString().Replace(",", "").Replace("\"", ""));
                            CreditAmt = Convert.ToDouble(SplitArr[3].ToString().Replace(",", "").Replace("\"", ""));
                            BAL = SplitArr[5].ToString().Replace(",", "").Replace("CR", "").Replace("DR", "").Trim();
                            BAL = BAL.Replace("-", "").Replace("\"", "");
                            Closing_BAL = SplitArr[5].ToString().Replace(",", "").Replace("CR", "").Replace("DR", "").Trim();
                            Closing_BAL = Closing_BAL.Replace("-", "").Replace("\"", "");
                            NtrOfBal = SplitArr[6].ToString().Replace("\"", "");
                            _DataTable.Rows.Add(56, ChannelID, ModeID, TxnsDateTime, REFERENCENO.Replace("\"", ""), Description, Convert.ToDecimal(DebitAmt), Convert.ToDecimal(CreditAmt), BAL, Convert.ToDecimal(Closing_BAL), NtrOfBal, BatchSeq, Status);



                            if (totalrecords == fileImportRequest.TotalCount)
                            {
                                CreditAmt = 0;
                                DebitAmt = 0;
                                Description = "Closing Balance";
                                REFERENCENO = "";
                                TXNTYPE = Typemode;
                                TxnsDateTime = Convert.ToDateTime(DateTime.ParseExact(SplitArr[0].ToString(), "dd/MM/yyyy", CultureInfo.InvariantCulture));
                                BAL = SplitArr[5].ToString().Replace(",", "").Replace("CR", "").Replace("DR", "").Trim();
                                BAL = BAL.Replace("-", "").Replace("\"", "");
                                _DataTable.Rows.Add(56, ChannelID, ModeID, TxnsDateTime, REFERENCENO.Replace("\"", ""), Description, Convert.ToDecimal(DebitAmt), Convert.ToDecimal(CreditAmt), BAL, Convert.ToDecimal(Closing_BAL), NtrOfBal, BatchSeq, Status);
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                    i++;
                }
            }

            if (_DataTable.Rows.Count > 0)
            {
                fileImportRequest.InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;
        }

        public string SplitterExcel_Dynamic_QR(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();
            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataSet _dataSetUpi = new DataSet();
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("TxnsID", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("PayerIFSC", typeof(string));
            _DataTable.Columns.Add("PayeeIFSC", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;
            string RevEntryLeg = string.Empty;
            string ChannelType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";

            string TxnsSubType = string.Empty;
            string TxnsStatus = string.Empty;
            string TxnsID = string.Empty;
            string PayerIFSC = string.Empty;
            string PayeeIFSC = string.Empty;

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;


            string NetworkType = string.Empty;


            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;



            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;
            string line1 = string.Empty;
            bool ErrorOccurred = false;

            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Amount1_CoulmnIndex = 0;
            ushort DestinationAmount_CoulmnIndex = 0;
            ushort DestinationCurrencyCode_CoulmnIndex = 0;
            ushort SourceCurrencyCode_CoulmnIndex = 0;
            ushort ChannelType_CoulmnIndex = 0;
            ushort TxnsPerticulars_CoulmnIndex = 0;
            ushort DrCrType_CoulmnIndex = 0;
            ushort ResponseCode1_CoulmnIndex = 0;
            ushort ResponseCode2_CoulmnIndex = 0;
            ushort ReversalCode1_CoulmnIndex = 0;
            ushort ReversalCode2_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort TxnsValueDateTime_CoulmnIndex = 0;
            ushort AuthCode_CoulmnIndex = 0;
            ushort ProcessingCode_CoulmnIndex = 0;
            ushort FeeAmount_CoulmnIndex = 0;
            ushort TxnsID_CoulmnIndex = 0;
            ushort TxnsSubType_CoulmnIndex = 0;
            ushort TxnsStatus_CoulmnIndex = 0;
            ushort PayerIFSC_CoulmnIndex = 0;
            ushort PayeeIFSC_CoulmnIndex = 0;

            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;
            ushort ReserveField5_CoulmnIndex = 0;

            try
            {

                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                //DataSet ds = new DataSet();
                //ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));


                ChannelType_CoulmnIndex = 0;
                TxnsStatus_CoulmnIndex = 0;
                ReferenceNumber_CoulmnIndex = 2;
                TxnsDateTime_CoulmnIndex = 0;
                TxnsDate_CoulmnIndex = 1;
                TxnsTime_CoulmnIndex = 10;
                TxnsID_CoulmnIndex = 9;
                TxnsAmount_CoulmnIndex = 0;
                DestinationAmount_CoulmnIndex = 0;
                FeeAmount_CoulmnIndex = 0;
                Amount1_CoulmnIndex = 0;
                DestinationCurrencyCode_CoulmnIndex = 0;
                SourceCurrencyCode_CoulmnIndex = 0;
                FromAccount_CoulmnIndex = 0;
                ToAccount_CoulmnIndex = 0;
                TxnsSubType_CoulmnIndex = 0;
                TxnsStatus_CoulmnIndex = 0;
                TxnsPerticulars_CoulmnIndex = 3;
                DrCrType_CoulmnIndex = 0;
                AuthCode_CoulmnIndex = 0;
                ProcessingCode_CoulmnIndex = 0;
                TxnsPostDateTime_CoulmnIndex = 0;
                TxnsValueDateTime_CoulmnIndex = 4;
                ResponseCode1_CoulmnIndex = 0;
                ResponseCode2_CoulmnIndex = 0;
                ReversalCode1_CoulmnIndex = 0;
                ReversalCode2_CoulmnIndex = 0;

                PayerIFSC_CoulmnIndex = 0;
                PayeeIFSC_CoulmnIndex = 0;

                ReserveField1_CoulmnIndex = 5;
                ReserveField2_CoulmnIndex = 6;
                ReserveField3_CoulmnIndex = 0;
                ReserveField4_CoulmnIndex = 0;
                ReserveField5_CoulmnIndex = 0;

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
                fileImportRequest.TotalCount = TotalCountArray.Length;

                //  _logger.LogInformation("The Total Count is : {fileImportRequest.TotalCount} ", fileImportRequest.TotalCount);

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {
                try
                {
                    //Get Batch Size
                    batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                    DataTable dtexcelsheetname = new DataTable();
                    DataTable dtSheet = new DataTable();
                    //Read the connection string for the Excel file.
                    string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                    conString = string.Format(conString, fileImportRequest.Path);

                    using (OleDbConnection connExcel = new OleDbConnection(conString))
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            connExcel.Open();
                            //Get the name of First Sheet. 
                            dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            connExcel.Close();
                        }
                    }

                    if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                    {

                        int j = 0;
                        int SheetLineNumber = 0;

                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }
                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }


                            foreach (DataRow row in dtexcelsheetname.Rows)
                            {
                                dtSheet = new DataTable();

                                using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                                {
                                    using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                    {
                                        using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                        {
                                            //Read Data from First Sheet.
                                            cmdExcelSheet.Connection = connExcelSheet;
                                            connExcelSheet.Open();
                                            cmdExcelSheet.CommandText = "SELECT * From [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                                            odaExcelSheet.SelectCommand = cmdExcelSheet;
                                            odaExcelSheet.Fill(dtSheet);
                                            connExcelSheet.Close();
                                        }
                                    }
                                }

                                Incr = 1;

                                if (dtSheet.Rows.Count > 0)
                                {
                                    // Find first data row based on whether the "Join Date" cell can be parsed as a date
                                    int dateStartIndex = 5;

                                    if (dateStartIndex > -1)
                                    {
                                        fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                                        {
                                            LineNo++;
                                            SheetLineNumber++;

                                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                            {
                                                continue;
                                            }

                                            try
                                            {
                                                AcquirerID = string.Empty;
                                                ReferenceNumber = string.Empty;
                                                FromAccount = string.Empty;
                                                ToAccount = string.Empty;

                                                TxnsDateTime = string.Empty;
                                                TxnsDate = string.Empty;
                                                TxnsTime = string.Empty;
                                                TxnsAmount = "0";
                                                Amount1 = "0";

                                                ChannelType = string.Empty;
                                                TxnsPerticulars = string.Empty;
                                                TxnsStatus = string.Empty;
                                                DrCrType = string.Empty;
                                                ResponseCode1 = string.Empty;
                                                ResponseCode2 = string.Empty;
                                                ReversalCode1 = string.Empty;
                                                ReversalCode2 = string.Empty;
                                                TxnsPostDateTime = string.Empty;
                                                TxnsValueDateTime = string.Empty;
                                                TxnsDateTimeDiff = string.Empty;
                                                AuthCode = string.Empty;
                                                ProcessingCode = string.Empty;
                                                FeeAmount = "0";
                                                DestinationAmount = "0";

                                                TxnsSubType = string.Empty;
                                                TxnsID = string.Empty;
                                                PayerIFSC = string.Empty;
                                                PayeeIFSC = string.Empty;

                                                ReserveField1 = string.Empty;
                                                ReserveField2 = string.Empty;
                                                ReserveField3 = string.Empty;
                                                ReserveField4 = string.Empty;
                                                ReserveField5 = string.Empty;

                                                DestinationCurrencyCode = string.Empty;
                                                SourceCurrencyCode = string.Empty;
                                                NetworkType = string.Empty;

                                                ChannelType = ChannelType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ChannelType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsAmount_CoulmnIndex - Incr]) : string.Empty;
                                                Amount1 = Amount1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Amount1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DestinationAmount = DestinationAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DestinationAmount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsSubType = TxnsSubType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsSubType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsID = TxnsID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsPerticulars = TxnsPerticulars_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsPerticulars_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsStatus = TxnsStatus_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsStatus_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DrCrType = DrCrType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DrCrType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ResponseCode1 = ResponseCode1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ResponseCode2 = ResponseCode2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReversalCode1 = ReversalCode1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReversalCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReversalCode2 = ReversalCode2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReversalCode2_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsValueDateTime = TxnsValueDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsValueDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AuthCode = AuthCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AuthCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ProcessingCode = ProcessingCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ProcessingCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                FeeAmount = FeeAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FeeAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                SourceCurrencyCode = SourceCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SourceCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DestinationCurrencyCode = DestinationCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DestinationCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                PayerIFSC = PayerIFSC_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayerIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                PayeeIFSC = PayeeIFSC_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayeeIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField5 = ReserveField5_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField5_CoulmnIndex - Incr]).Trim() : string.Empty;


                                                TxnsDateTimeMain = null;
                                                TxnsPostDateTimeMain = null;


                                                if (TxnsDate != "" && TxnsTime != "")
                                                {
                                                    if (TxnsTime.Length < 6 && !TxnsTime.Contains(":"))
                                                    {
                                                        TxnsTime = TxnsTime.PadLeft(6, '0');
                                                    }

                                                    TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                                {
                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime != "")
                                                {
                                                    DateTime dateTime = DateTime.Parse(TxnsPostDateTime);
                                                    string formattedDate = dateTime.ToString(TxnPostDateTimeFormat[0]);
                                                    TxnsPostDateTimeMain = DateTime.ParseExact(formattedDate, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (ReserveField1.Length > 0)
                                                {
                                                    TxnsAmount = Common.IsNumeric(ReserveField1) ? ReserveField1 : "0";
                                                    DrCrType = "D";
                                                }
                                                else if (ReserveField2.Length > 0)
                                                {
                                                    TxnsAmount = Common.IsNumeric(ReserveField2) ? ReserveField2 : "0";
                                                    DrCrType = "C";
                                                }

                                                if (Convert.ToString(dtSheet.Rows[k][0]).Trim().ToLower() == "currency :")
                                                {
                                                    string currency = Convert.ToString(dtSheet.Rows[k][1]).Trim();
                                                    if (currency == "USD")
                                                    {
                                                        DestinationCurrencyCode = "840";
                                                    }
                                                    else if (currency == "KHR")
                                                    {
                                                        DestinationCurrencyCode = "116";
                                                    }
                                                }

                                                Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                                DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                                FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";


                                                if (TxnsDateTimeMain != null)
                                                {

                                                    // _logger.LogInformation("Date time Correct : ", TxnsDateTimeMain);

                                                    _DataTable.Rows.Add(
                                                             ChannelType
                                                            , ReferenceNumber
                                                            , TxnsDateTimeMain
                                                            , Convert.ToDecimal(TxnsAmount)
                                                            , TxnsID
                                                            , FromAccount
                                                            , ToAccount
                                                            , Convert.ToDecimal(DestinationAmount)
                                                            , Convert.ToDecimal(FeeAmount)
                                                            , Convert.ToDecimal(Amount1)
                                                            , SourceCurrencyCode
                                                            , DestinationCurrencyCode
                                                            , TxnsSubType
                                                            , TxnsStatus
                                                            , TxnsPerticulars
                                                            , DrCrType
                                                            , AuthCode
                                                            , ProcessingCode
                                                            , ResponseCode1
                                                            , ResponseCode2
                                                            , ReversalCode1
                                                            , ReversalCode2
                                                            , TxnsPostDateTimeMain
                                                            , TxnsValueDateTimeMain
                                                            , PayerIFSC
                                                            , PayeeIFSC
                                                            , ReserveField1
                                                            , ReserveField2
                                                            , ReserveField3
                                                            , ReserveField4
                                                            , ReserveField5
                                                            , NetworkType
                                                            );


                                                    if (_DataTable.Rows.Count >= batchSize)
                                                    {
                                                        BatchNo++;

                                                        MSG = bulkimports.BulkInsertCBSTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                        fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                                        // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                                                        BatchDetails batchDetails = new BatchDetails
                                                        {
                                                            BatchNo = BatchNo,
                                                            BatchSize = batchSize,
                                                            TxnUploadCount = _DataTable.Rows.Count,
                                                            TxnsCount = fileImportRequest.InsertCount,
                                                            BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                            FailedCount = ErrorCount,
                                                            BatchStartTime = batchStartTime,
                                                            BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                        };

                                                        batchDetailsList.Add(batchDetails);
                                                        _DataTable.Clear();
                                                        StartTime = DateTime.Now;
                                                        ErrorCount = 0;
                                                        if (NewEntry)
                                                        {
                                                            break;
                                                        }
                                                    }
                                                }



                                            }
                                            catch (Exception ex)
                                            {
                                                // _logger.LogInformation("Error At Inserting data into Datatable : ", ex);
                                                ErrorCount++;
                                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (j == 0)
                                        {
                                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched";
                                        }
                                        break;
                                    }
                                }
                                j++;
                            }
                            LineNo = 0;
                        }
                    }

                    if (_DataTable.Rows.Count > 0)
                    {
                        BatchNo = BatchNo + 1;

                        fileImportRequest.InsertCount += _DataTable.Rows.Count;

                        MSG = bulkimports.BulkInsertCBSTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                        //  _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                        BatchDetails batchDetails = new BatchDetails
                        {
                            BatchNo = BatchNo,
                            BatchSize = batchSize,
                            TxnUploadCount = _DataTable.Rows.Count,
                            TxnsCount = fileImportRequest.InsertCount,
                            BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                            FailedCount = ErrorCount,
                            BatchStartTime = batchStartTime,
                            BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                        };

                        batchDetailsList.Add(batchDetails);
                    }
                    else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                    {
                        MSG = "Successful";
                    }
                }
                catch (Exception ex)
                {
                    // objLogWriter.FunErrorLog(ex.Message.ToString(), fileImportRequest.ClientCode, "ASP_CBS_Splitter.cs", "SplitData", LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }

            }
            else
            {
                MSG = fileImportRequest.ErrorMessage;

                BatchNo = BatchNo + 1;

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = 1,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);
            }

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }

        public string SplitterDelimiter_Dynamic_QR(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0, LineNumber = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();
            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataSet _dataSetUpi = new DataSet();
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("TxnsID", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("PayerIFSC", typeof(string));
            _DataTable.Columns.Add("PayeeIFSC", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;
            string RevEntryLeg = string.Empty;
            string ChannelType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string TxnsSubType = string.Empty;
            string TxnsStatus = string.Empty;
            string TxnsID = string.Empty;
            string PayerIFSC = string.Empty;
            string PayeeIFSC = string.Empty;

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;

            string ReturnCode = string.Empty;
            string NetworkType = string.Empty;

            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;

            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;
            string[] nextColFields = null;
            string[] currentColFields = null; 
            string line1 = string.Empty;
            bool ErrorOccurred = false;

            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Amount1_CoulmnIndex = 0;
            ushort DestinationAmount_CoulmnIndex = 0;
            ushort DestinationCurrencyCode_CoulmnIndex = 0;
            ushort SourceCurrencyCode_CoulmnIndex = 0;
            ushort ChannelType_CoulmnIndex = 0;
            ushort TxnsSubType_CoulmnIndex = 0;
            ushort TxnsStatus_CoulmnIndex = 0;
            ushort TxnsPerticulars_CoulmnIndex = 0;
            ushort DrCrType_CoulmnIndex = 0;
            ushort ResponseCode1_CoulmnIndex = 0;
            ushort ResponseCode2_CoulmnIndex = 0;
            ushort ReversalCode1_CoulmnIndex = 0;
            ushort ReversalCode2_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort TxnsValueDateTime_CoulmnIndex = 0;
            ushort AuthCode_CoulmnIndex = 0;
            ushort ProcessingCode_CoulmnIndex = 0;
            ushort FeeAmount_CoulmnIndex = 0;
            ushort TxnsID_CoulmnIndex = 0;

            ushort PayerIFSC_CoulmnIndex = 0;
            ushort PayeeIFSC_CoulmnIndex = 0;

            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;
            ushort ReserveField5_CoulmnIndex = 0;
            int largestIndex = 0, CoulmnIndex = 0;

            try
            {
                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                //DataSet ds = new DataSet();
                //ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                ChannelType_CoulmnIndex = 0;
                TxnsStatus_CoulmnIndex = 0;
                ReferenceNumber_CoulmnIndex = 2;
                TxnsDateTime_CoulmnIndex = 0;
                TxnsDate_CoulmnIndex = 4;
                TxnsTime_CoulmnIndex = 10;
                TxnsID_CoulmnIndex = 9;
                TxnsAmount_CoulmnIndex = 0;
                DestinationAmount_CoulmnIndex = 0;
                FeeAmount_CoulmnIndex = 0;
                Amount1_CoulmnIndex = 0;
                DestinationCurrencyCode_CoulmnIndex = 0;
                SourceCurrencyCode_CoulmnIndex = 0;
                FromAccount_CoulmnIndex = 0;
                ToAccount_CoulmnIndex = 0;
                TxnsSubType_CoulmnIndex = 0;
                TxnsStatus_CoulmnIndex = 0;
                TxnsPerticulars_CoulmnIndex = 3;
                DrCrType_CoulmnIndex = 0;
                AuthCode_CoulmnIndex = 0;
                ProcessingCode_CoulmnIndex = 0;
                TxnsPostDateTime_CoulmnIndex = 0;
                TxnsValueDateTime_CoulmnIndex = 4;
                ResponseCode1_CoulmnIndex = 0;
                ResponseCode2_CoulmnIndex = 0;
                ReversalCode1_CoulmnIndex = 0;
                ReversalCode2_CoulmnIndex = 0;

                PayerIFSC_CoulmnIndex = 0;
                PayeeIFSC_CoulmnIndex = 0;

                ReserveField1_CoulmnIndex = 5;
                ReserveField2_CoulmnIndex = 6;
                ReserveField3_CoulmnIndex = 2;
                ReserveField4_CoulmnIndex = 0;
                ReserveField5_CoulmnIndex = 0;

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    int dateStartIndex = 5;

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }

                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            using (TextFieldParser parser = new TextFieldParser(fileImportRequest.Path))
                            {
                                parser.TextFieldType = FieldType.Delimited;
                                parser.SetDelimiters(fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString());

                                while (!parser.EndOfData)
                                {
                                    currentColFields = parser.ReadFields();  

                                    if (currentColFields.Length > 0)
                                    {
                                        try
                                        {
                                            if (Convert.ToString(currentColFields[0]).Trim().ToLower() == "currency :")
                                            {
                                                string currency = Convert.ToString(currentColFields[1]).Trim();
                                                if (currency == "USD")
                                                {
                                                    DestinationCurrencyCode = "840";
                                                    SourceCurrencyCode = "840";
                                                }
                                                else if (currency == "KHR")
                                                {
                                                    DestinationCurrencyCode = "116";
                                                    SourceCurrencyCode = "116";
                                                }
                                            }

                                            if (LineNo < dateStartIndex)
                                            {
                                                LineNumber++;
                                                LineNo++;
                                                continue;
                                            }

                                            LineNo++;

                                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                            {
                                                continue;
                                            }


                                            LineNumber++;

                                            if (!parser.EndOfData)
                                                nextColFields = parser.ReadFields();
                                            else
                                                nextColFields = null;

                                            ReturnCode = string.Empty;

                                            if (nextColFields != null && nextColFields.Length > 0)
                                            {
                                                if (nextColFields[2] == "RETURN FUND")
                                                {
                                                    ReturnCode = "R";

                                                    nextColFields = parser.ReadFields();
                                                }
                                            }

                                            AcquirerID = string.Empty;
                                            ReferenceNumber = string.Empty;
                                            FromAccount = string.Empty;
                                            ToAccount = string.Empty;

                                            TxnsDateTime = string.Empty;
                                            TxnsDate = string.Empty;
                                            TxnsTime = string.Empty;
                                            TxnsAmount = "0";
                                            Amount1 = "0";

                                            ChannelType = string.Empty;
                                            TxnsPerticulars = string.Empty;
                                            DrCrType = string.Empty;
                                            ResponseCode1 = string.Empty;
                                            ResponseCode2 = string.Empty;
                                            ReversalCode1 = string.Empty;
                                            ReversalCode2 = string.Empty;
                                            TxnsPostDateTime = string.Empty;
                                            TxnsValueDateTime = string.Empty;
                                            TxnsDateTimeDiff = string.Empty;
                                            AuthCode = string.Empty;
                                            ProcessingCode = string.Empty;
                                            FeeAmount = "0";
                                            DestinationAmount = "0";
                                            TxnsSubType = string.Empty;
                                            TxnsStatus = string.Empty;
                                            TxnsID = string.Empty;
                                            PayerIFSC = string.Empty;
                                            PayeeIFSC = string.Empty;

                                            ReserveField1 = string.Empty;
                                            ReserveField2 = string.Empty;
                                            ReserveField3 = string.Empty;
                                            ReserveField4 = string.Empty;
                                            ReserveField5 = string.Empty;

                                            //DestinationCurrencyCode = string.Empty;
                                            //SourceCurrencyCode = string.Empty;
                                            NetworkType = string.Empty;

                                          

                                                ChannelType = ChannelType_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ChannelType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(currentColFields[FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(currentColFields[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(currentColFields[TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(currentColFields[TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(currentColFields[TxnsAmount_CoulmnIndex - Incr]) : string.Empty;
                                            Amount1 = Amount1_CoulmnIndex > 0 ? Convert.ToString(currentColFields[Amount1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            DestinationAmount = DestinationAmount_CoulmnIndex > 0 ? Convert.ToString(currentColFields[DestinationAmount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            TxnsSubType = TxnsSubType_CoulmnIndex > 0 ? Convert.ToString(currentColFields[TxnsSubType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TxnsStatus = TxnsStatus_CoulmnIndex > 0 ? Convert.ToString(currentColFields[TxnsStatus_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TxnsID = TxnsID_CoulmnIndex > 0 ? Convert.ToString(currentColFields[TxnsID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TxnsPerticulars = TxnsPerticulars_CoulmnIndex > 0 ? Convert.ToString(currentColFields[TxnsPerticulars_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            DrCrType = DrCrType_CoulmnIndex > 0 ? Convert.ToString(currentColFields[DrCrType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            ResponseCode1 = ResponseCode1_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ResponseCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ResponseCode2 = ResponseCode2_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ResponseCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ReversalCode1 = ReversalCode1_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ReversalCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ReversalCode2 = ReversalCode2_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ReversalCode2_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(currentColFields[TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TxnsValueDateTime = TxnsValueDateTime_CoulmnIndex > 0 ? Convert.ToString(currentColFields[TxnsValueDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            AuthCode = AuthCode_CoulmnIndex > 0 ? Convert.ToString(currentColFields[AuthCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ProcessingCode = ProcessingCode_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ProcessingCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            FeeAmount = FeeAmount_CoulmnIndex > 0 ? Convert.ToString(currentColFields[FeeAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            //SourceCurrencyCode = SourceCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(currentColFields[SourceCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            //DestinationCurrencyCode = DestinationCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(currentColFields[DestinationCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            PayerIFSC = PayerIFSC_CoulmnIndex > 0 ? Convert.ToString(currentColFields[PayerIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            PayeeIFSC = PayeeIFSC_CoulmnIndex > 0 ? Convert.ToString(currentColFields[PayeeIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ReserveField5 = ReserveField5_CoulmnIndex > 0 ? Convert.ToString(currentColFields[ReserveField5_CoulmnIndex - Incr]).Trim() : string.Empty;


                                            TxnsDateTimeMain = null;
                                            TxnsPostDateTimeMain = null;


                                            if (TxnsDate != "" && TxnsTime != "")
                                            {
                                                if (TxnsTime.Length < 6 && !TxnsTime.Contains(":"))
                                                {
                                                    TxnsTime = TxnsTime.PadLeft(6, '0');
                                                }

                                                TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                            }

                                            if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                            {
                                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                            }

                                            if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime != "")
                                            {
                                                DateTime dateTime = DateTime.Parse(TxnsPostDateTime);
                                                string formattedDate = dateTime.ToString(TxnPostDateTimeFormat[0]);
                                                TxnsPostDateTimeMain = DateTime.ParseExact(formattedDate, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                                            }

                                            if (ReserveField1.Length > 0)
                                            {
                                                TxnsAmount = Common.IsNumeric(ReserveField1) ? ReserveField1 : "0";
                                                DrCrType = "D"; 
                                            }
                                            else if (ReserveField2.Length > 0)
                                            {
                                                TxnsAmount = Common.IsNumeric(ReserveField2) ? ReserveField2 : "0";
                                                DrCrType = "C";
                                            } 

                                            

                                            if (nextColFields!=null && nextColFields.Length > 0)
                                            {
                                                if (nextColFields[2].Trim().ToLower().Contains("from acc.no"))
                                                {
                                                    if (nextColFields[2].Split('-').Length == 2)
                                                    {
                                                        FromAccount = nextColFields[2].Split('-')[1].Trim();
                                                    }
                                                }
                                                else if (nextColFields[2].Trim().ToLower().Contains("to acc.no"))
                                                {
                                                    if (nextColFields[2].Split('-').Length == 2)
                                                    {
                                                        ToAccount = nextColFields[2].Split('-')[1].Trim();
                                                    }
                                                }
                                            }

                                            ReserveField4 = ReturnCode;
                                            ReversalCode1 = ReturnCode;

                                            TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                            Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                            DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                            FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";

                                            if (ReferenceNumber.Length == 0)
                                            {
                                                ReferenceNumber = ReserveField3;
                                            }

                                            if (TxnsDateTimeMain != null)
                                            {
                                                _DataTable.Rows.Add(
                                                         ChannelType
                                                        , ReferenceNumber
                                                        , TxnsDateTimeMain
                                                        , Convert.ToDecimal(TxnsAmount)
                                                        , TxnsID
                                                        , FromAccount
                                                        , ToAccount
                                                        , Convert.ToDecimal(DestinationAmount)
                                                        , Convert.ToDecimal(FeeAmount)
                                                        , Convert.ToDecimal(Amount1)
                                                        , SourceCurrencyCode
                                                        , DestinationCurrencyCode
                                                        , TxnsSubType
                                                        , TxnsStatus
                                                        , TxnsPerticulars
                                                        , DrCrType
                                                        , AuthCode
                                                        , ProcessingCode
                                                        , ResponseCode1
                                                        , ResponseCode2
                                                        , ReversalCode1
                                                        , ReversalCode2
                                                        , TxnsPostDateTimeMain
                                                        , TxnsValueDateTimeMain
                                                        , PayerIFSC
                                                        , PayeeIFSC
                                                        , ReserveField1
                                                        , ReserveField2
                                                        , ReserveField3
                                                        , ReserveField4
                                                        , ReserveField5
                                                        , NetworkType
                                                        );


                                                if (_DataTable.Rows.Count >= batchSize)
                                                {
                                                    BatchNo++;

                                                    MSG = bulkimports.BulkInsertCBSTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                                    // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                                                    BatchDetails batchDetailsPartial = new BatchDetails
                                                    {
                                                        BatchNo = BatchNo,
                                                        BatchSize = batchSize,
                                                        TxnUploadCount = _DataTable.Rows.Count,
                                                        TxnsCount = fileImportRequest.InsertCount,
                                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                        FailedCount = ErrorCount,
                                                        BatchStartTime = batchStartTime,
                                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                    };

                                                    batchDetailsList.Add(batchDetailsPartial);
                                                    _DataTable.Clear();
                                                    StartTime = DateTime.Now;
                                                    ErrorCount = 0;
                                                    if (NewEntry)
                                                    {
                                                        break;
                                                    }
                                                }
                                            }



                                        }
                                        catch (Exception ex)
                                        {
                                            // _logger.LogInformation("Error At Inserting data into Datatable : ", ex);
                                            ErrorCount++;
                                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                        }
                                    }
                                }
                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;


                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertCBSTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        MSG = fileImportRequest.ErrorMessage;
                    }


                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = 1,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }


        public string ConvertNPCIExcel(string OldFilepath, string OldFileName)
        {
            string NewFileName = "";
            try
            {
                //objLogWriter.FunErrorLog(OldFilepath, objLoginEntity._ClientCode, "ImportFile.aspx", "ConvertNPCIExcel", 0, "ImportFile.aspx", objLoginEntity._UserName, 'E');
                NewFileName = OldFilepath.Replace(OldFileName, "");
                string extension = System.IO.Path.GetExtension(OldFileName);
                NewFileName = NewFileName + OldFileName.Replace(extension, "") + "_New" + extension;

                string xmlPathName = OldFilepath;

                //NewFileName = @"D:\Rupali\SVN_Live\Ankita\sachinSir\files\NTSLSMU020919_1C_backup.xls";
                Microsoft.Office.Interop.Excel.Application activeExcel = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook openWorkBook;
                openWorkBook = activeExcel.Workbooks.Open(xmlPathName);
                openWorkBook.SaveAs(NewFileName, Microsoft.Office.Interop.Excel.XlFileFormat.xlExcel9795);
                openWorkBook.Close();
                //objLogWriter.FunErrorLog(NewFileName, objLoginEntity._ClientCode, "INewFileName", "ConvertNPCIExcel", 0, "ImportFile.aspx", objLoginEntity._UserName, 'E');
            }
            catch
            {
                //LogWriter objLogWriter = new LogWriter();
                //  objLogWriter.FunErrorLog(ex.Message.ToString(), objLoginEntity._ClientCode, "ImportFile.aspx", "ConvertNPCIExcel", 0, "ImportFile.aspx", objLoginEntity._UserName, 'E');
                NewFileName = OldFileName;
            }

            return NewFileName;
        }

    }
}
