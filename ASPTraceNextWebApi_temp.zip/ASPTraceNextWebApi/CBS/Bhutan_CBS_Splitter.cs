﻿using ImportData;
using System;
using System.Data;
using System.Data.OleDb;
using System.Reflection;
using Utility;

namespace CBS
{
    public class Bhutan_CBS_Splitter
    { 
        private readonly string _connectionString;
        BulkImports bulkimports;
        public Bhutan_CBS_Splitter(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        public DataTable BDB_SplitData(string path, string FileName, string UserName, string ClientID, string RevEntryLeg, out int InsertCount, out int TotalCount)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            try
            {
                System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");

                _DataTable.Columns.Add("ClientID", typeof(int));
                _DataTable.Columns.Add("ChannelID", typeof(int));
                _DataTable.Columns.Add("ModeID", typeof(int));
                _DataTable.Columns.Add("TerminalId", typeof(string));
                _DataTable.Columns.Add("ReferenceNumber", typeof(string));
                _DataTable.Columns.Add("CardNumber", typeof(string));
                _DataTable.Columns.Add("CardType", typeof(string));
                _DataTable.Columns.Add("CustAccountNo", typeof(string));
                _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
                _DataTable.Columns.Add("ATMAccountNo", typeof(string));
                _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
                _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
                _DataTable.Columns.Add("Amount1", typeof(decimal));
                _DataTable.Columns.Add("Amount2", typeof(decimal));
                _DataTable.Columns.Add("Amount3", typeof(decimal));
                _DataTable.Columns.Add("TxnsStatus", typeof(string));
                _DataTable.Columns.Add("TxnsType", typeof(string));
                _DataTable.Columns.Add("TxnsSubType", typeof(string));
                _DataTable.Columns.Add("TxnsEntryType", typeof(string));
                _DataTable.Columns.Add("TxnsNumber", typeof(string));
                _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
                _DataTable.Columns.Add("DrCrType", typeof(string));
                _DataTable.Columns.Add("ResponseCode", typeof(string));
                _DataTable.Columns.Add("ReversalFlag", typeof(bool));
                _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
                _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
                _DataTable.Columns.Add("AuthCode", typeof(string));
                _DataTable.Columns.Add("ProcessingCode", typeof(string));
                _DataTable.Columns.Add("FeeAmount", typeof(decimal));
                _DataTable.Columns.Add("CurrencyCode", typeof(string));
                _DataTable.Columns.Add("CustBalance", typeof(decimal));
                _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
                _DataTable.Columns.Add("ATMBalance", typeof(decimal));
                _DataTable.Columns.Add("BranchCode", typeof(string));
                _DataTable.Columns.Add("ReserveField1", typeof(string));
                _DataTable.Columns.Add("ReserveField2", typeof(string));
                _DataTable.Columns.Add("ReserveField3", typeof(string));
                _DataTable.Columns.Add("ReserveField4", typeof(string));
                _DataTable.Columns.Add("ReserveField5", typeof(string));
                _DataTable.Columns.Add("RevEntryLeg", typeof(string));
                _DataTable.Columns.Add("NoOfDuplicate", typeof(string));
                _DataTable.Columns.Add("FileName", typeof(string));
                _DataTable.Columns.Add("FilePath", typeof(string));
                _DataTable.Columns.Add("FileDate", typeof(DateTime));
                _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
                _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
                _DataTable.Columns.Add("CreatedBy", typeof(string));
                _DataTable.Columns.Add("ModifiedBy", typeof(string));
                _DataTable.Columns.Add("ECardNumber", typeof(string));

                int LineNo = 0, x = 0, y = 0;

                string GLCODE = string.Empty;
                string AccountNO = string.Empty;
                string CardNumber = string.Empty;
                string TranDate = string.Empty;
                string TranID = string.Empty;
                string DrCrType = string.Empty;
                //string ValueDate = string.Empty;
                string Amount = string.Empty;
                string TrxnDesc = string.Empty;
                string TerminalID = string.Empty;
                string ReferenceNumber = string.Empty;
                string EntryDate = string.Empty;
                string Channel = string.Empty;
                string TxnsType = string.Empty;
                string BinNo = string.Empty;

                string CurrencyCode = "064";
                string FeeAmount = "0";
                string CustBalance = "0";
                string InterchangeBalance = "0";
                string ATMBalance = "0";
                string Amount1 = "0";
                string Amount2 = "0";
                string Amount3 = "0";
                string InterchangeAccountNo = string.Empty;
                string ATMAccountNo = string.Empty;
                string AuthCode = string.Empty;
                string ProcessingCode = string.Empty;

                string ResponseCode = "00";
                string TxnsNumber = string.Empty;
                string TxnsStatus = "Sucessfull";
                string DebitCreditType = string.Empty; 
                string TxnsSubTypeMain = string.Empty;
                string TxnsEntryType = "Auto";
                string CardType = string.Empty;
                bool ReversalFlag = false;
                string BranchCode = string.Empty;
                string ReserveField1 = string.Empty;
                string ReserveField2 = string.Empty;
                string ReserveField3 = string.Empty;
                string ReserveField4 = string.Empty;
                string ReserveField5 = string.Empty;
                string NoOfDuplicate = string.Empty;
                string ECardNumber = string.Empty;

                DateTime? TxnDateTime = null;
                DateTime? TxnDate = null;
                DateTime? ValueDate = null;
                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;

                int ModeID = 0;
                int ChannelID = 0;

                //int FromRange = 0;
                //int ToRange = 0;

                
                //

                
                
              
                 
                 

                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                string extension = System.IO.Path.GetExtension(path);

                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                                 // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1\'";
                        break;
                    case ".xlsx": //Excel 07 or higher
                                  //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                }

                try
                {
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }
                catch
                {
                    switch (extension.ToLower())
                    {
                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }
                //objConn = new OleDbConnection(connString);
                //objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null); 

                string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(dtexcelsheetname.Rows[0]["TABLE_NAME"]).Replace("'", "") + "]";
                //string sht = dr[2].ToString().Replace("'", "");

                OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dtfillsheet1 = new DataTable();
                da.Fill(dtfillsheet1);

                //dtfillsheet1.Rows.RemoveAt(0);
                //dtfillsheet1.Rows.RemoveAt(dtfillsheet1.Rows.Count-1);
                objConn.Close();
                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {
                    try
                    {
                        LineNo++;
                        TotalCount++;

                        CardNumber = string.Empty;
                        ECardNumber = string.Empty;
                        CardType = string.Empty;
                        ReversalFlag = false;
                        ModeID = 0;
                        ChannelID = 0;
                        TxnsType = string.Empty;
                        TxnsSubTypeMain = string.Empty;

                        GLCODE = dtfillsheet1.Rows[i][0].ToString();
                        AccountNO = dtfillsheet1.Rows[i][1].ToString().Trim();
                        CardNumber = dtfillsheet1.Rows[i][2].ToString().Trim();
                        TxnDate = DateTime.ParseExact(dtfillsheet1.Rows[i][3].ToString().Trim(), "dd-MMM-yy", System.Globalization.CultureInfo.InvariantCulture);
                        TranID = dtfillsheet1.Rows[i][4].ToString().Trim();
                        DrCrType = dtfillsheet1.Rows[i][6].ToString().Trim();
                        ValueDate = DateTime.ParseExact(dtfillsheet1.Rows[i][7].ToString().Trim(), "dd-MMM-yy", System.Globalization.CultureInfo.InvariantCulture);
                        Amount = dtfillsheet1.Rows[i][8].ToString().Trim();
                        TrxnDesc = dtfillsheet1.Rows[i][9].ToString().Trim();

                        if (TrxnDesc.Substring(0, 4).Trim() == "CWRR" || TrxnDesc.Substring(0, 4).Trim() == "DBRR" || TrxnDesc.Substring(0, 4).Trim() == "PRRR")
                        {
                            ReversalFlag = true;
                        }

                        TerminalID = dtfillsheet1.Rows[i][10].ToString().Trim();
                        ReferenceNumber = dtfillsheet1.Rows[i][11].ToString().Trim();
                        TxnDateTime = DateTime.ParseExact(dtfillsheet1.Rows[i][12].ToString().Trim(), "dd-MM-yyyy:HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                       
                        Channel = dtfillsheet1.Rows[i][13].ToString().Trim();
                        AuthCode = dtfillsheet1.Rows[i][4].ToString().Trim();
                        TxnsNumber = dtfillsheet1.Rows[i][4].ToString().Trim();

                        if (((TerminalID.Substring(0, 4) == "BDBL") || (TerminalID.Substring(0, 4) == "BDBM")) && (!CardNumber.Contains("637053")) && ((Channel == "SWT") || (Channel == "IMP")))
                        {
                            TxnsType = "Acquirer";
                            ModeID = 2;
                        } 
                        else if (((TerminalID.Substring(0, 4) == "BDBL") && (CardNumber.Contains("637053"))) && (Channel == "IMP"))//|| (CardNumber.Contains("8888888888888888")
                        {
                            TxnsType = "Acquirer";
                            ModeID = 2;
                        }
                        else if(((TerminalID.Substring(0, 4) == "BDBL") && (CardNumber.Contains("637053"))) && (Channel == "SWT"))//|| (CardNumber.Contains("8888888888888888")
                        {
                            TxnsType = "Onus";
                            ModeID = 1;
                        }
                        else if (((TerminalID.Substring(0, 4) != "BDBL") && (TerminalID.Substring(0, 4) != "BDBM")) && (CardNumber.Contains("637053")) && ((Channel == "SWT") || (Channel == "IMP")))
                        {
                            TxnsType = "Issuer";
                            ModeID = 3;
                        }
                        else if (Channel == "MAC")
                        {
                            TxnsType = "Onus";
                            ModeID = 1;
                        }
                        else if (Channel == "POS")
                        {
                            TxnsType = "Issuer";
                            ModeID = 3;
                        }

                        if (Channel == "SWT")
                        {
                            if (TrxnDesc.Trim().Substring(0, 4) == "CWDR")
                            {
                                TxnsSubTypeMain = "Withdrawal";
                                ChannelID = (int)TxnsChannelID.ATM;
                            }
                            else if (TrxnDesc.Trim().Substring(0, 4) == "CWRR")
                            {
                                TxnsSubTypeMain = "Deposit";
                                ChannelID = (int)TxnsChannelID.ATM;
                            }
                        }
                        else if (Channel == "IMP")
                        {
                            ChannelID = (int)TxnsChannelID.UPI;
                            if (TrxnDesc.Trim().Substring(0, 4) == "DBTR")
                            {
                                TxnsSubTypeMain = "Transfer";
                                ModeID = 4;
                            }
                            else if (TrxnDesc.Trim().Substring(0, 4) == "CRTR")
                            {
                                TxnsSubTypeMain = "Transfer";
                                ModeID = 5;
                            }
                        }
                        else if (Channel == "CRM")
                        { 
                            ChannelID = (int)TxnsChannelID.IMPS;

                            if (TrxnDesc.Trim().Substring(0, 4) == "TRTR")
                            {
                                TxnsSubTypeMain = "Transfer";
                                ModeID = 22;
                            } 
                        }

                        TxnsType = "Financial";

                        if (CardNumber != "")
                        {
                            ECardNumber = AesEncryption.EncryptString(CardNumber);
                        }

                        if (CardNumber != "")
                        {
                            if (CardNumber.Substring(0, 1) == "4")
                            {
                                CardType = "VISA";
                            }
                            else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                            {
                                CardType = "MASTER";
                            }
                            else if (CardNumber.Substring(0, 2) == "62")
                            {
                                CardType = "CUP";
                            }
                            else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                            {
                                CardType = "RuPay";
                            }
                            else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                            {
                                CardType = "Maestro";
                            }
                        }

                        //if (CardNumber != "")
                        //{
                        //    string dummy = "XXXXXXXXXX";
                        //    CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                        //}


                        if (TxnDate != null)
                        {
                            _DataTable.Rows.Add(
                                              ClientID
                                            , ChannelID
                                            , ModeID
                                            , TerminalID
                                            , ReferenceNumber
                                            , CardNumber.Trim()
                                            , CardType
                                            , AccountNO
                                            , null
                                            , null
                                            , TxnDateTime
                                            , Convert.ToDecimal(Amount)
                                            , Convert.ToDecimal(Amount1)
                                            , Convert.ToDecimal(Amount2)
                                            , Convert.ToDecimal(Amount3)
                                            , TxnsStatus
                                            , TxnsType
                                            , TxnsSubTypeMain
                                            , TxnsEntryType
                                            , TxnsNumber
                                            , TrxnDesc
                                            , DrCrType
                                            , ResponseCode
                                            , ReversalFlag
                                            , TxnDate
                                            , ValueDate
                                            , AuthCode
                                            , null
                                            , Convert.ToDecimal(FeeAmount)
                                            , CurrencyCode
                                            , Convert.ToDecimal(CustBalance)
                                            , Convert.ToDecimal(InterchangeBalance)
                                            , Convert.ToDecimal(ATMBalance)
                                            , BranchCode
                                            , Channel
                                            , GLCODE 
                                            , null
                                            , null
                                            , null
                                            , RevEntryLeg
                                            , 0
                                            , FileName
                                            , path
                                            , null
                                            , DateTime.Now
                                            , null
                                            , UserName
                                            , ""
                                            , ECardNumber.Trim()
                                            );
                        }

                        InsertCount++;
                    }
                    catch (Exception ex)
                    {
                        InsertCount--;
                        DBLog.InsertLogs(ex.Message.ToString(), ClientID, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                }
                if (_DataTable.Rows.Count == 0)
                {
                   // DBLog.InsertLogs(ex.Message.ToString(), ClientID, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientID, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, 0, FileName, UserName, 'E', _connectionString);
            }

            return _DataTable;
        }

    }
}
