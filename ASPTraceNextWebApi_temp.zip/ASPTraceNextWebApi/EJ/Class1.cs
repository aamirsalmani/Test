﻿namespace EJ
{
    public class Class1
    {

    }
}
