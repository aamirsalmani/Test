﻿using ImportData;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using Utility;

namespace EJ
{
    public class SplitterCommon
    { 
        private readonly string _connectionString;
        BulkImports bulkimports;
        public SplitterCommon(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        public DataTable ASP_SplitData(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTimeConverter objDateTimeConverter = new DateTimeConverter();
            System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("CustAccountNo", typeof(string));
            _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
            _DataTable.Columns.Add("ATMAccountNo", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("Amount2", typeof(decimal));
            _DataTable.Columns.Add("Amount3", typeof(decimal));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
            _DataTable.Columns.Add("ATMBalance", typeof(decimal));
            _DataTable.Columns.Add("BranchCode", typeof(string));
            _DataTable.Columns.Add("TransSEQNumber", typeof(string));
            _DataTable.Columns.Add("OPCode", typeof(string));
            _DataTable.Columns.Add("ResultCode", typeof(string));
            _DataTable.Columns.Add("ErrorCode", typeof(string));
            _DataTable.Columns.Add("TCode", typeof(string));
            _DataTable.Columns.Add("TCode1", typeof(string));
            _DataTable.Columns.Add("FunctionID", typeof(string));
            _DataTable.Columns.Add("Amount", typeof(decimal));
            _DataTable.Columns.Add("Denomination", typeof(string));
            _DataTable.Columns.Add("RequestCount", typeof(string));
            _DataTable.Columns.Add("DispenseCount", typeof(string));
            _DataTable.Columns.Add("RemainCount", typeof(string));
            _DataTable.Columns.Add("PickupCount", typeof(string));
            _DataTable.Columns.Add("RejectCount", typeof(string));
            _DataTable.Columns.Add("Cassette1", typeof(string));
            _DataTable.Columns.Add("Cassette2", typeof(string));
            _DataTable.Columns.Add("Cassette3", typeof(string));
            _DataTable.Columns.Add("Cassette4", typeof(string));
            //_DataTable.Columns.Add("InitAmount", typeof(decimal));
            //_DataTable.Columns.Add("DispAmount", typeof(decimal));
            //_DataTable.Columns.Add("StorAmount", typeof(decimal));
            //_DataTable.Columns.Add("RemAmount", typeof(decimal));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("NoOfDuplicate", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;
            int StartIndex1 = 0;
            int EndIndex1 = 0;
            int StartIndexx = 0;
            int EndIndexx = 0; 

            DataSet ds = new DataSet();

            string LogType = fileImportRequest.ConfigData.Rows[0]["FileName"].ToString();
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = fileImportRequest.ConfigData.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
            fileImportRequest.TotalCount = TotalCountArray.Length;

            DateTime TimeStamp = System.DateTime.Now;
            DateTime TimeStamp1 = System.DateTime.Now;
            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            //DateTime? TxnsDateTime;
            //TxnsDateTime = null;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            //string TxnsAmount = "0";
            decimal TxnsAmount = 0;
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            //DateTime? TxnsPostDateTime;
            //TxnsPostDateTime = null;
            string TxnsValueDateTime = string.Empty;
            //DateTime? TxnsValueDateTime;
            //TxnsValueDateTime = null;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string line = string.Empty;
            string line1 = string.Empty;
            string ResponseCode = string.Empty;
            string EJResult = string.Empty;
            string StrDateTime = string.Empty;
            string StrTime = string.Empty;
            string ErrorCode = string.Empty;
            string terminal = string.Empty;
            string TransSeqNo = string.Empty;
            string Opcode = string.Empty;
            string FunctionId = string.Empty;
            string Denomination = string.Empty;
            string ReqCount = string.Empty;
            string DispenseCount = string.Empty;
            string PickupCount = string.Empty;
            string RemainCount = string.Empty;
            string RejectCount = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string resultCode = string.Empty;
            string Remark3 = string.Empty;
            string ECardNumber = string.Empty;


            decimal Amount = 0;
            int LineNo1 = 0;
            bool flag = false;
            terminal = fileImportRequest.FileName.Substring(0, 8);
            //int LineNo = 0;
            int ErrorLine = 0;

            string REF_NO = string.Empty;
            string TX = string.Empty;
            string CARD1 = string.Empty;
            string RESP = string.Empty;
            string AUTH = string.Empty;
            string TXN_type = string.Empty;
            string AccNumber = string.Empty;
            string DESC = string.Empty;
            string counter50 = string.Empty;
            string counter100 = string.Empty;
            string counter500 = string.Empty;
            string counter1000 = string.Empty;
            string TransSEQNumber = string.Empty;
            string CARD = string.Empty;
            string Remark1 = string.Empty;
            string Remark2 = string.Empty;
            string Remark4 = string.Empty;
            string OPCode = string.Empty;
            string FunctionID = string.Empty;
            decimal AmountTxn = 0;
            string RequestCount = string.Empty;
            string INIT_AMOUNT = string.Empty;
            string DISP_AMOUNT = string.Empty;
            string STOR_AMOUNT = string.Empty;
            string REM_AMOUNT = string.Empty;
            string TCode2 = string.Empty;

            int ModeID = 0;
            int ChannelID = 0;
            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;


            bool card = false;
            bool Terminal = false;
            bool Acquirer = false;
            bool Rev1 = false;
            bool Rev2 = false;
            bool ATM = false;
            bool CDM = false;
            bool POS = false;
            bool ECOM = false;
            bool IMPS = false;
            bool UPI = false;
            bool MicroATM = false;
            bool MobileRecharge = false;
            bool BAL = false;
            bool MS = false;
            bool PC = false;
            bool CB = false;
            bool RCA1 = false;
            bool RCA2 = false;
            bool MC = false;
            bool VC = false;
            bool OC = false;
            bool D = false;
            bool C = false;

            string SplitType = ",";
            string[] TerminalCode = fileImportRequest.ConfigData.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BIN_No = fileImportRequest.ConfigData.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] AcquirerIDArray = fileImportRequest.ConfigData.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode1Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode2Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ReversalType = fileImportRequest.ConfigData.Rows[0]["ReversalType"].ToString();
            string[] ATMType = fileImportRequest.ConfigData.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CDMType = fileImportRequest.ConfigData.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] POSType = fileImportRequest.ConfigData.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ECOMType = fileImportRequest.ConfigData.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] IMPType = fileImportRequest.ConfigData.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] UPIType = fileImportRequest.ConfigData.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MicroATMType = fileImportRequest.ConfigData.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MobileRechargeType = fileImportRequest.ConfigData.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BalanceEnquiry = fileImportRequest.ConfigData.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MiniStatement = fileImportRequest.ConfigData.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] PinChange = fileImportRequest.ConfigData.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ChequeBookReq = fileImportRequest.ConfigData.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ResponseType = fileImportRequest.ConfigData.Rows[0]["ResponseType"].ToString();
            string[] ResponseCode1Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ResponseCode2Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] OfflineCode = fileImportRequest.ConfigData.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnPostDateTime = fileImportRequest.ConfigData.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] DebitCode = fileImportRequest.ConfigData.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CreditCode = fileImportRequest.ConfigData.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);

            int i = 0;
            int FromRange = 0;
            int ToRange = 0;

            string error;
            string amountstr;
            string result1;
            string result2;
            string[] resultB;
            string[] resultA;

            for (int j = 0; j <= fileImportRequest.TotalCount; j++)
            {
                try
                {
                    //StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID");
                    //EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "------------------------------------");
                    StartIndex1 = Common.GetIndex(TotalCountArray, j, "ATM ID   :");
                    EndIndex1 = Common.GetIndex(TotalCountArray, j + 1, "------------------------------------");

                    //StartIndex = Common.GetIndex(TotalCountArray, j, "TRANSACTION START");
                    //EndIndex = Common.GetIndex(TotalCountArray, j + 1, "TRANSACTION END");
                    if (ClientID == 8)
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID");
                        EndIndex = Common.GetIndex(TotalCountArray, j + 1, "RESP CODE") + 10;
                    }
                    else if (ClientID == 74)
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID");
                        EndIndex = Common.GetIndex(TotalCountArray, j + 1, "------------------------------------");
                    }
                    else
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID");
                        EndIndex = Common.GetIndex(TotalCountArray, j + 1, "RESP CODE") + 4;
                    }

                    if (StartIndex > EndIndex)
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j, "CARD NUMBER");
                        if (StartIndex > EndIndex)
                        {
                            StartIndex = Common.GetIndex(TotalCountArray, j, "TRANSACTION REQUESTING");
                            if (StartIndex > EndIndex)
                            {
                                StartIndex = Common.GetIndex(TotalCountArray, j, "TRANSACTION REPLIED");
                            }
                        }
                    }

                    flag = false;
                    if (StartIndex > StartIndex1 && StartIndex1 != -1)
                    {
                        StartIndex = StartIndex1 - 28;
                        EndIndex = EndIndex1 + 17;
                        flag = true;
                    }

                    StartIndexx = Common.GetIndex(TotalCountArray, LineNo1, "ENTERED SUPERVISOR PROGRAM");
                    EndIndexx = Common.GetIndex(TotalCountArray, LineNo1 + 1, "GO IN-SERVICE");
                    //TotalCount++;
                    if (StartIndexx != -1 && EndIndexx != -1)
                    {
                        REF_NO = string.Empty;
                        TX = string.Empty;
                        Amount = 0;
                        CARD1 = string.Empty;
                        RESP = string.Empty;
                        AUTH = string.Empty;
                        TXN_type = string.Empty;
                        AccNumber = string.Empty;
                        DESC = string.Empty;
                        counter50 = string.Empty;
                        counter100 = string.Empty;
                        counter500 = string.Empty;
                        counter1000 = string.Empty;
                        fileImportRequest.UserName = string.Empty; 
                        TransSEQNumber = string.Empty;
                        CARD = string.Empty;
                        CARD1 = string.Empty;
                        Remark1 = string.Empty;
                        Remark2 = string.Empty;
                        //string Remark3 = string.Empty;
                        Remark4 = string.Empty;
                        //string resultCode = string.Empty;
                        ErrorCode = string.Empty;
                        //string TCode = string.Empty;
                        OPCode = string.Empty;
                        FunctionID = string.Empty;
                        AmountTxn = 0;
                        Denomination = string.Empty;
                        RequestCount = string.Empty;
                        DispenseCount = string.Empty;
                        RemainCount = string.Empty;
                        PickupCount = string.Empty;
                        RejectCount = string.Empty;
                        TransSEQNumber = string.Empty;
                        Cassette1 = string.Empty;
                        Cassette2 = string.Empty;
                        Cassette3 = string.Empty;
                        Cassette4 = string.Empty;
                        INIT_AMOUNT = string.Empty;
                        DISP_AMOUNT = string.Empty;
                        STOR_AMOUNT = string.Empty;
                        REM_AMOUNT = string.Empty;
                        TCode2 = string.Empty;

                        for (int k = StartIndexx; k <= EndIndexx; k++)
                        {
                            try
                            {
                                EJResult = Common.RemoveAdditionalChars(TotalCountArray[k].ToString());

                                string date = TotalCountArray[EndIndexx + 4].ToString().Substring(0, 20).Replace("[", "");
                                TimeStamp = Convert.ToDateTime(date);

                                string date1 = TotalCountArray[EndIndexx + 1].ToString();
                                TimeStamp1 = DateTime.ParseExact(date1, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);

                                if (EJResult.Contains("CUR DENO"))
                                {
                                    if (TotalCountArray[k + 4].ToString().Contains("002K"))
                                    {
                                        Cassette1 = TotalCountArray[k + 4].ToString().Substring(12, TotalCountArray[k + 4].ToString().Length - 12).Trim();  //2000
                                    }

                                    if (TotalCountArray[k + 3].ToString().Contains("500"))
                                    {
                                        Cassette2 = TotalCountArray[k + 3].ToString().Substring(12, TotalCountArray[k + 3].ToString().Length - 12).Trim();  //500
                                    }

                                    if (TotalCountArray[k + 2].ToString().Contains("100"))
                                    {
                                        Cassette3 = TotalCountArray[k + 2].ToString().Substring(12, TotalCountArray[k + 2].ToString().Length - 12).Trim();  //100
                                    }

                                    if (TotalCountArray[k + 5].ToString().Contains("50"))
                                    {
                                        Cassette4 = TotalCountArray[k + 5].ToString().Substring(12, TotalCountArray[k + 5].ToString().Length - 12).Trim();  //50
                                    }
                                }
                                if (EJResult.Contains("INIT AMOUNT:"))
                                {
                                    string[] INIT = EJResult.Split(':');
                                    INIT_AMOUNT = INIT[1].ToString().Trim();
                                    INIT_AMOUNT = INIT_AMOUNT.Replace("INR", "").Replace(",", "");
                                }

                                if (EJResult.Contains("DISP AMOUNT:"))
                                {
                                    string[] INIT = EJResult.Split(':');
                                    DISP_AMOUNT = INIT[1].ToString().Trim();
                                    DISP_AMOUNT = DISP_AMOUNT.Replace("INR", "").Replace(",", "");
                                }

                                if (EJResult.Contains("STOR AMOUNT:"))
                                {
                                    string[] INIT = EJResult.Split(':');
                                    STOR_AMOUNT = INIT[1].ToString().Trim();
                                    STOR_AMOUNT = STOR_AMOUNT.Replace("INR", "").Replace(",", "");
                                }

                                if (EJResult.Contains("REM AMOUNT:"))
                                {
                                    string[] INIT = EJResult.Split(':');
                                    REM_AMOUNT = INIT[1].ToString().Trim();
                                    REM_AMOUNT = REM_AMOUNT.Replace("INR", "").Replace(",", "");
                                }

                            }
                            catch (Exception ex)
                            {
                                //_frmErrorLog.FunErrorLog(ex.Message.ToString(), "FNK", "Form_ImportData", "ProcessEjLogSpliterFnk", LineNo, GLFilePath, UserName.ToString(), 'E');
                                //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", (LineNo + 1), FileName, UserName, 'E');
                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                            }
                        }

                        try
                        {
                            Guid Trans_CycleID1 = Guid.NewGuid();
                            //_DataTable.Rows.Add(TimeStamp1, terminal, REF_NO, TX, Amount, CARD1, RESP, AUTH, "ADMINREQUEST", AccNumber, false, false, Trans_CycleID1, 
                            //    DESC, counter50, counter100, counter500, counter1000, System.DateTime.Now, System.DateTime.Now, UserName, UserName, TimeStamp, 
                            //    TransSEQNumber, CARD, terminal, AmountTxn, resultCode, ErrorCode, TCode, OPCode, FunctionID, Denomination, RequestCount, DispenseCount, 
                            //    RemainCount, PickupCount, RejectCount, Cassette1, Cassette2, Cassette3, Cassette4, Remark1, Remark2, Remark3, Remark4, INIT_AMOUNT, 
                            //    DISP_AMOUNT, STOR_AMOUNT, REM_AMOUNT, TCode2, '0');

                            _DataTable.Rows.Add(ClientID, null, null, terminal, REF_NO, CARD, null, AccNumber, null, null, TimeStamp1, Amount, 0, 0, 0, null, null, null, null, null,
                                null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 0, null, null, null, null,
                                null, null, Cassette1, Cassette2, Cassette3, Cassette4,
                                //INIT_AMOUNT, DISP_AMOUNT, STOR_AMOUNT, REM_AMOUNT,
                                null, null, null, null, null, 0, 0, fileImportRequest.FileName, fileImportRequest.Path, null, DateTime.Now, DateTime.Now, fileImportRequest.UserName, "");
                        }

                        catch (Exception ex)
                        {
                            ErrorLine++;
                            //_frmErrorLog.FunErrorLog(ex.Message.ToString(), "BOB", "Form_ImportData", "ProcessEjLogSpliterBOB", (LineNo + 1), GLFilePath, UserName.ToString(), 'T');
                            //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", (LineNo + 1), FileName, UserName, 'E');
                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                        }

                        REF_NO = string.Empty;
                        TX = string.Empty;
                        Amount = 0;
                        CARD1 = string.Empty;
                        RESP = string.Empty;
                        AUTH = string.Empty;
                        TXN_type = string.Empty;
                        AccNumber = string.Empty;
                        DESC = string.Empty;
                        counter50 = string.Empty;
                        counter100 = string.Empty;
                        counter500 = string.Empty;
                        counter1000 = string.Empty;
                        fileImportRequest.UserName = string.Empty;
                        fileImportRequest.UserName = string.Empty;
                        TransSEQNumber = string.Empty;
                        CARD = string.Empty;
                        CARD1 = string.Empty;
                        Remark1 = string.Empty;
                        Remark2 = string.Empty;
                        Remark3 = string.Empty;
                        Remark4 = string.Empty;
                        resultCode = string.Empty;
                        ErrorCode = string.Empty;
                        TCode = string.Empty;
                        OPCode = string.Empty;
                        FunctionID = string.Empty;
                        AmountTxn = 0;
                        Denomination = string.Empty;
                        RequestCount = string.Empty;
                        DispenseCount = string.Empty;
                        RemainCount = string.Empty;
                        PickupCount = string.Empty;
                        RejectCount = string.Empty;
                        TransSEQNumber = string.Empty;
                        Cassette1 = string.Empty;
                        Cassette2 = string.Empty;
                        Cassette3 = string.Empty;
                        Cassette4 = string.Empty;
                        INIT_AMOUNT = string.Empty;
                        DISP_AMOUNT = string.Empty;
                        STOR_AMOUNT = string.Empty;
                        REM_AMOUNT = string.Empty;
                        TCode2 = string.Empty;
                        LineNo1 = EndIndexx;
                    }

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {
                                LineNo++;
                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);

                                if (line == "2672")
                                {
                                    line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                }

                                EJResult = Common.RemoveAdditionalChars(line);
                                if (EJResult.Contains("ATM ID"))
                                {
                                    TerminalID = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("REF NO") || EJResult.Contains("RRN NO."))
                                {
                                    ReferenceNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("DATE"))  // || TotalCountArray[k - 1].ToString().Contains("/")
                                {
                                    //StrDateTime = TotalCountArray[k - 1].ToString().Replace("BANK OF BARODADUGRI ROAD, LUDHIANALUDHIANA", "").ToString().Trim();
                                    //TxnsDateTime = StrDateTime;
                                    ////TxnsDateTime = DateTime.ParseExact(StrDateTime, "dd/MM/yy HH:mm", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);
                                    //TxnsValueDateTime = TxnsDateTime;
                                    //TxnsPostDateTime = TxnsDateTime;
                                    StrDateTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsDate = StrDateTime;
                                }

                                if (EJResult.Contains("TIME") && !(EJResult.Contains("Timeout")) && !(EJResult.Contains("TIMEOUT"))) //|| TotalCountArray[k - 1].ToString().Contains("/")
                                {
                                    //StrDateTime = TotalCountArray[k - 1].ToString().Replace("BANK OF BARODADUGRI ROAD, LUDHIANALUDHIANA", "").ToString().Trim();
                                    //TxnsDateTime = StrDateTime;
                                    ////TxnsDateTime = DateTime.ParseExact(StrDateTime, "dd/MM/yy HH:mm", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);
                                    //TxnsValueDateTime = TxnsDateTime;
                                    //TxnsPostDateTime = TxnsDateTime;
                                    StrTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsTime = StrTime;
                                }

                                if (EJResult.Contains("CARD NUMBER") || (EJResult.Contains("CARD NO")))
                                {
                                    if (!EJResult.Contains("INVALID"))
                                    {
                                        CardNumber = string.Empty;
                                        CardNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    }
                                }

                                if (EJResult.Contains("A/C NO") || EJResult.Contains("ACCOUNT NO"))
                                {
                                    CustAccountNo = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();// Str_Accs[1].ToString().Trim();                                        
                                }

                                if (EJResult.Contains("TRANSTYPE"))
                                {
                                    //string[] splitTXN_type = EJResult.Split(':');
                                    TxnsSubType = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                //if (EJResult.Contains("WITHDRAWAL"))
                                //{
                                //    //string[] splitTXN_type = EJResult.Split(':');
                                //    TxnsSubType = "WITHDRAWAL";
                                //}
                                //if (EJResult.Contains("CASHDEPOSIT"))
                                //{
                                //    TxnsSubType = "CASHDEPOSIT";
                                //}
                                //if (EJResult.Contains("BALANCEENQUIRY"))
                                //{
                                //    TxnsSubType = "Balance enquiry";
                                //}
                                //if (EJResult.Contains("MINISTATEMENT"))
                                //{
                                //    TxnsSubType = "Mini statement";
                                //}
                                //if (EJResult.Contains("PINCHANGE"))
                                //{
                                //    TxnsSubType = "Pin change";
                                //}
                                if (EJResult.Contains("SEQ NO."))
                                {
                                    //string[] splitTXN_type = EJResult.Split(':');
                                    TxnsNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("RESP CODE"))
                                {
                                    ResponseCode = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("RESP CODE"))
                                {
                                    error = TotalCountArray[k + 1].ToString();
                                    if (!error.Contains("TRANS AMOUNT") && TxnsSubType == "CASH WITHDRAWAL")
                                    {
                                        ErrorCode = error;
                                    }
                                }

                                if (EJResult.Contains("TRANS AMOUNT") || (EJResult.Contains("WDL AMT")) || (EJResult.Contains("TOTAL")))
                                {
                                    amountstr = EJResult.Substring(EJResult.IndexOf(":") + 1).Replace("RS.", "").Trim();
                                    TxnsAmount = Convert.ToDecimal(amountstr);
                                }

                                if (EJResult.Contains("TRANS SEQ NUMBER"))
                                {
                                    TransSeqNo = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                if (EJResult.Contains("OPCode") || (EJResult.Contains("OPCODE")))
                                {
                                    Opcode = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                if (EJResult.Contains("Function ID") || EJResult.Contains("FUNCTION ID"))
                                {
                                    FunctionId = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                if (EJResult.Contains("AMOUNT"))
                                {
                                    amountstr = EJResult.Substring(EJResult.IndexOf("[") + 1).Replace("RS.", "").Trim();
                                    amountstr = amountstr.TrimEnd(']');
                                    Amount = Convert.ToDecimal(amountstr);
                                }

                                if (EJResult.Contains("DENOMINATION"))
                                {
                                    Denomination = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                if (EJResult.Contains("REQUEST COUNT"))
                                {
                                    ReqCount = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                if (EJResult.Contains("DISPENSE COUNT"))
                                {
                                    DispenseCount = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                if (EJResult.Contains("REMAIN COUNT"))
                                {
                                    RemainCount = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                if (EJResult.Contains("PICKUP COUNT"))
                                {
                                    PickupCount = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                if (EJResult.Contains("REJECT COUNT"))
                                {
                                    RejectCount = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                if (EJResult.Contains("DISPENSED NOTES :Taken") || EJResult.Contains("DISPENSED NOTES :TAKEN"))
                                {
                                    Cassette1 = TotalCountArray[k + 1].ToString().Substring(11, TotalCountArray[k + 1].ToString().Length - 11).Trim();
                                    Cassette2 = TotalCountArray[k + 2].ToString().Substring(11, TotalCountArray[k + 2].ToString().Length - 11).Trim();
                                    Cassette3 = TotalCountArray[k + 3].ToString().Substring(11, TotalCountArray[k + 3].ToString().Length - 11).Trim();
                                    Cassette4 = TotalCountArray[k + 4].ToString().Substring(11, TotalCountArray[k + 4].ToString().Length - 11).Trim();
                                }

                                if (EJResult.Contains("TERM_MSG=SOL_DEVICE_FAULT"))
                                {
                                    result2 = TotalCountArray[k].ToString().Substring(21, TotalCountArray[k].ToString().Length - 21);
                                    resultB = result2.Split(',');
                                    TCode = resultB[2].ToString().Substring(6, resultB[2].ToString().Length - 6);
                                }

                                if (EJResult.Contains("TERM_MSG=UNSOL_STATUS_MESSAGE"))
                                {
                                    result2 = TotalCountArray[k].ToString().Substring(21, TotalCountArray[k].ToString().Length - 21);
                                    resultB = result2.Split(',');
                                    TCode1 = resultB[2].ToString().Substring(6, resultB[2].ToString().Length - 6);
                                }
                                if (EJResult.Contains("DEVICEERROR"))
                                {
                                    result1 = TotalCountArray[k].ToString().Substring(21, TotalCountArray[k].ToString().Length - 21);
                                    resultA = result1.Split(',');

                                    resultCode = resultA[2].ToString().Substring(8, resultA[2].ToString().Length - 8);
                                    ErrorCode = resultA[3].ToString().Substring(11, resultA[3].ToString().Length - 11);

                                    Remark3 = TotalCountArray[k].ToString().Substring(21, TotalCountArray[k].ToString().Length - 21) + "|" + TotalCountArray[k + 1].ToString().Substring(21, TotalCountArray[k + 1].ToString().Length - 21) + "|" + TotalCountArray[k + 2].ToString().Substring(21, TotalCountArray[k + 2].ToString().Length - 21);
                                }
                                //Result code, Error code
                                j = EndIndex;
                            }
                            catch
                            {
                                j = EndIndex;
                            }
                        }
                    }

                    #region StanderedFields

                    ModeID = 0;
                    ChannelID = 0;
                    ReversalFlag = false;
                    TxnsStatus = string.Empty;
                    DebitCreditType = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    CardType = string.Empty;
                    TxnsDateTimeMain = null;
                    TxnsPostDateTimeMain = null;


                    card = false;
                    Terminal = false;
                    Acquirer = false;
                    Rev1 = false;
                    Rev2 = false;
                    ATM = false;
                    CDM = false;
                    POS = false;
                    ECOM = false;
                    IMPS = false;
                    UPI = false;
                    MicroATM = false;
                    MobileRecharge = false;
                    BAL = false;
                    MS = false;
                    PC = false;
                    CB = false;
                    RCA1 = false;
                    RCA2 = false;
                    MC = false;
                    VC = false;
                    OC = false;
                    D = false;
                    C = false;

                    #region ValidateField

                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        TxnsDateTimeMain = Convert.ToDateTime(TxnsDate + " " + TxnsTime);
                        //TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + TxnsTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);
                    }

                    if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                    {

                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);

                    }


                    if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                    {
                        for (i = 0; i < TxnPostDateTime.Length; i++)
                        {
                            if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                            {
                                TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                            }
                            else
                            {
                                TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), CultureInfo.InvariantCulture);
                            }
                        }
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                            }
                        }
                    }


                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                            {
                                card = true;
                            }
                        }
                    }



                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                    }
                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                        for (i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                            }
                        }
                    }




                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == TxnsSubType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == TxnsSubType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == TxnsSubType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == TxnsSubType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType)
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == ChannelType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == ChannelType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == ChannelType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == ChannelType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType)
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }


                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                            }
                        }

                        for (i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode)
                            {
                                RCA2 = true;
                            }
                        }
                    }

                    //if (ResponseCode1Array[0].ToString() == "")
                    //    {
                    //    RCA1 = true;
                    //    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() == "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                            }
                        }
                    }

                    //if (Information.IsNumeric(CardNumber.Substring(0, 6)))
                    //{
                    //    if (CardNumber != "")
                    //    {
                    //        for (i = 0; i < dsCardNetwork.Tables[0].Rows.Count; i++)
                    //        {
                    //            string Range = dsCardNetwork.Tables[0].Rows[i]["FIXRange"].ToString();
                    //            if (CardNumber.Substring(0, 1) == Range || CardNumber.Substring(0, 2) == Range || CardNumber.Substring(0, 3) == Range || CardNumber.Substring(0, 4) == Range || CardNumber.Substring(0, 5) == Range || CardNumber.Substring(0, 6) == Range)
                    //            {
                    //                CardType = dsCardNetwork.Tables[0].Rows[i]["CardNetwork"].ToString();
                    //            }
                    //        }

                    //    }
 

                    if (DebitCode[0].ToString() != "")
                    {
                        for (i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                            }
                        }
                    }


                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    if (AcquirerID == string.Empty || AcquirerID == "")
                    {
                        if (Terminal == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Terminal == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Terminal == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }
                    else
                    {
                        if (Acquirer == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Acquirer == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Acquirer == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }

                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (POS)
                    {
                        ChannelID = (int)TxnsChannelID.POS;
                        TxnsSubTypeMain = "Purchase";
                    }

                    if (ECOM)
                    {
                        ChannelID = (int)TxnsChannelID.E_COMMERCE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (IMPS)
                    {
                        ChannelID = (int)TxnsChannelID.IMPS;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (MicroATM)
                    {
                        ChannelID = (int)TxnsChannelID.MICRO_ATM;
                        TxnsSubTypeMain = "Withdrawal";
                    }

                    if (MobileRecharge)
                    {
                        ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (UPI)
                    {
                        ChannelID = (int)TxnsChannelID.UPI;
                        TxnsSubTypeMain = "Transfer";
                    }
                    if (RCA1 == true || RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }
                    else
                    {
                        TxnsStatus = "Unsucessfull";
                    }


                    //if (RCA1 == true  || RCA1 == true && RCA2 == false)
                    //    {
                    //    ResponseCode = "00";
                    //    TxnsStatus = "Sucessfull";
                    //    }
                    //else
                    //    {
                    //    ResponseCode = ResponseCode1;
                    //    TxnsStatus = "Unsucessfull";
                    //    }

                    if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }

                    if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }

                    if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }

                    if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }


                    if (BAL || MS || PC || CB)
                    {
                        TxnsType = "Non-Financial";
                    }
                    else
                    {
                        TxnsType = "Financial";
                    }
                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    if (TxnsType == "Financial" && TxnsStatus == "Unsucessfull")
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    #endregion InitilizedField


                    #endregion StanderedFields

                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }

                    if (TxnsStatus == "")

                        if (CardNumber != "")
                        {
                            string dummy = "XXXXXXXXXX";
                            CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);

                        }

                    if (TxnsDateTimeMain != null && ReferenceNumber != "")
                    {
                        _DataTable.Rows.Add(ClientID
                                        , (int)TxnsChannelID.ATM
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , CardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , InterchangeAccountNo
                                        , ATMAccountNo
                                        , TxnsDateTimeMain
                                        , Convert.ToDecimal(TxnsAmount)
                                        , Convert.ToDecimal(Amount1)
                                        , Convert.ToDecimal(Amount2)
                                        , Convert.ToDecimal(Amount3)
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubTypeMain
                                        , TxnsEntryType
                                        , TxnsNumber
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , ReversalFlag
                                        , TxnsPostDateTimeMain
                                        , TxnsPostDateTimeMain
                                        , AuthCode
                                        , ProcessingCode
                                        , Convert.ToDecimal(FeeAmount)
                                        , CurrencyCode
                                        , Convert.ToDecimal(CustBalance)
                                        , Convert.ToDecimal(InterchangeBalance)
                                        , Convert.ToDecimal(ATMBalance)
                                        , BranchCode
                                        , TransSeqNo
                                        , Opcode
                                        , resultCode
                                        , ErrorCode
                                        , TCode
                                        , TCode1
                                        , FunctionId
                                        , Amount
                                        , Denomination
                                        , ReqCount
                                        , DispenseCount
                                        , RemainCount
                                        , PickupCount
                                        , RejectCount
                                        , Cassette1
                                        , Cassette2
                                        , Cassette3
                                        , Cassette4
                                        , ReserveField1
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , RevEntryLeg
                                        , 0
                                        , fileImportRequest.FileName
                                        , fileImportRequest.Path
                                        , null
                                        , DateTime.Now
                                        , DateTime.Now
                                        , fileImportRequest.UserName
                                        , ""
                                        , ECardNumber.Trim()
                                        );

                    }

                    TerminalID = string.Empty;
                    AcquirerID = string.Empty;
                    ReferenceNumber = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    InterchangeAccountNo = string.Empty;
                    ATMAccountNo = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsDate = string.Empty;
                    TxnsTime = string.Empty;
                    TxnsAmount = 0;
                    Amount1 = "0";
                    Amount2 = "0";
                    Amount3 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsNumber = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;
                    TxnsPostDateTime = string.Empty;
                    TxnsValueDateTime = string.Empty;
                    AuthCode = string.Empty;
                    ProcessingCode = string.Empty;
                    FeeAmount = "0";
                    CurrencyCode = string.Empty;
                    CustBalance = "0";
                    InterchangeBalance = "0";
                    ATMBalance = "0";
                    BranchCode = string.Empty;
                    Cassette1 = string.Empty;
                    Cassette2 = string.Empty;
                    Cassette3 = string.Empty;
                    Cassette4 = string.Empty;
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    ResponseCode = string.Empty;
                    EJResult = string.Empty;
                    StrDateTime = string.Empty;
                    StrTime = string.Empty;
                    ErrorCode = string.Empty;
                    terminal = string.Empty;
                    TransSeqNo = string.Empty;
                    Opcode = string.Empty;
                    FunctionId = string.Empty;
                    Denomination = string.Empty;
                    ReqCount = string.Empty;
                    DispenseCount = string.Empty;
                    PickupCount = string.Empty;
                    RemainCount = string.Empty;
                    RejectCount = string.Empty;
                    TCode = string.Empty;
                    TCode1 = string.Empty;
                    resultCode = string.Empty;
                    Remark3 = string.Empty;
                    ECardNumber = string.Empty;
                    CardType = string.Empty;

                    TxnsStatus = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    DebitCreditType = string.Empty;
                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                fileImportRequest.InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;
        }

        public DataSet SplitterNagpur( FileImportRequest fileImportRequest)
        {

            DataSet dsFinal = new DataSet();

            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            #region  Withdrawal Txns Declaration
            DataTable _DataTable = new DataTable();
            DateTimeConverter objDateTimeConverter = new DateTimeConverter();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("CustAccountNo", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("RequestAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("Amount2", typeof(decimal));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            _DataTable.Columns.Add("OPCode", typeof(string));
            _DataTable.Columns.Add("ErrorCode", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("NotesPresented1", typeof(string));
            _DataTable.Columns.Add("NotesPresented2", typeof(string));
            _DataTable.Columns.Add("NotesPresented3", typeof(string));
            _DataTable.Columns.Add("NotesPresented4", typeof(string));
            _DataTable.Columns.Add("Denomination1", typeof(string));
            _DataTable.Columns.Add("Denomination2", typeof(string));
            _DataTable.Columns.Add("Denomination3", typeof(string));
            _DataTable.Columns.Add("Denomination4", typeof(string));
            _DataTable.Columns.Add("Dispensed1", typeof(string));
            _DataTable.Columns.Add("Dispensed2", typeof(string));
            _DataTable.Columns.Add("Dispensed3", typeof(string));
            _DataTable.Columns.Add("Dispensed4", typeof(string));
            _DataTable.Columns.Add("Rejected1", typeof(string));
            _DataTable.Columns.Add("Rejected2", typeof(string));
            _DataTable.Columns.Add("Rejected3", typeof(string));
            _DataTable.Columns.Add("Rejected4", typeof(string));
            _DataTable.Columns.Add("Remaining1", typeof(string));
            _DataTable.Columns.Add("Remaining2", typeof(string));
            _DataTable.Columns.Add("Remaining3", typeof(string));
            _DataTable.Columns.Add("Remaining4", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("Status", typeof(int));
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            #endregion  Withdrawal Txns Declaration

            #region Machine Counter Declaration
            DataTable _DataTableMCCounter = new DataTable();
            _DataTableMCCounter.Columns.Add("ClientID", typeof(int));
            _DataTableMCCounter.Columns.Add("TerminalID", typeof(string));
            _DataTableMCCounter.Columns.Add("CurrentEOD", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("MachineOp100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOpTotal", typeof(string));

            _DataTableMCCounter.Columns.Add("MachineDis100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDisTotal", typeof(string));

            _DataTableMCCounter.Columns.Add("MachineRem100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRemTotal", typeof(string));

            _DataTableMCCounter.Columns.Add("MachineLoad100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoadTotal", typeof(string));

            _DataTableMCCounter.Columns.Add("MachineClosing100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosingTotal", typeof(string));

            _DataTableMCCounter.Columns.Add("RETRACTNOTESCOUNT", typeof(string));
            _DataTableMCCounter.Columns.Add("CassetteRemarks", typeof(string));
            _DataTableMCCounter.Columns.Add("Filename", typeof(string));
            _DataTableMCCounter.Columns.Add("FilePath", typeof(string));
            _DataTableMCCounter.Columns.Add("FileDate", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("CreatedON", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("Createdby", typeof(string));

            _DataTableMCCounter.Columns.Add("NoteType", typeof(string));
            _DataTableMCCounter.Columns.Add("ReplenishmentCount", typeof(string));
            _DataTableMCCounter.Columns.Add("WithdrawalSuccessCount", typeof(string));
            _DataTableMCCounter.Columns.Add("WithdrawalRejectCount", typeof(string));
            _DataTableMCCounter.Columns.Add("Deposit_Count", typeof(string));
            _DataTableMCCounter.Columns.Add("OffsetCount", typeof(string));
            _DataTableMCCounter.Columns.Add("ReTractCount", typeof(string));
            _DataTableMCCounter.Columns.Add("RemCount", typeof(string));



            _DataTableMCCounter.Columns.Add("PurgeCWDRJI100", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeCWDRJI200", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeCWDRJI500", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeCWDRJI2000", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeCWF100", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeCWF200", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeCWF500", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeCWF2000", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEP100", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEP200", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEP500", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEP2000", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEPRJI100", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEPRJI200", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEPRJI500", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEPRJI2000", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEF100", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEF200", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEF500", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeDEF2000", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeRST100", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeRST200", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeRST500", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeRST2000", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeRETRACT100", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeRETRACT200", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeRETRACT500", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeRETRACT2000", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeTotalRjectedPurgeBIN100", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeTotalRjectedPurgeBIN200", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeTotalRjectedPurgeBIN500", typeof(int));
            _DataTableMCCounter.Columns.Add("PurgeTotalRjectedPurgeBIN2000", typeof(int));


            _DataTableMCCounter.Columns.Add("REP2000", typeof(int));
            _DataTableMCCounter.Columns.Add("CWD2000", typeof(int));
            _DataTableMCCounter.Columns.Add("CWDRJO2000", typeof(int));
            _DataTableMCCounter.Columns.Add("DEP2000", typeof(int));
            _DataTableMCCounter.Columns.Add("OFFSET2000", typeof(int));
            _DataTableMCCounter.Columns.Add("RETRACT2000", typeof(int));
            _DataTableMCCounter.Columns.Add("REM2000", typeof(int));

            _DataTableMCCounter.Columns.Add("REP500", typeof(int));
            _DataTableMCCounter.Columns.Add("CWD500", typeof(int));
            _DataTableMCCounter.Columns.Add("CWDRJO500", typeof(int));
            _DataTableMCCounter.Columns.Add("DEP500", typeof(int));
            _DataTableMCCounter.Columns.Add("OFFSET500", typeof(int));
            _DataTableMCCounter.Columns.Add("RETRACT500", typeof(int));
            _DataTableMCCounter.Columns.Add("REM500", typeof(int));

            _DataTableMCCounter.Columns.Add("REP200", typeof(int));
            _DataTableMCCounter.Columns.Add("CWD200", typeof(int));
            _DataTableMCCounter.Columns.Add("CWDRJO200", typeof(int));
            _DataTableMCCounter.Columns.Add("DEP200", typeof(int));
            _DataTableMCCounter.Columns.Add("OFFSET200", typeof(int));
            _DataTableMCCounter.Columns.Add("RETRACT200", typeof(int));
            _DataTableMCCounter.Columns.Add("REM200", typeof(int));

            _DataTableMCCounter.Columns.Add("REP100", typeof(int));
            _DataTableMCCounter.Columns.Add("CWD100", typeof(int));
            _DataTableMCCounter.Columns.Add("CWDRJO100", typeof(int));
            _DataTableMCCounter.Columns.Add("DEP100", typeof(int));
            _DataTableMCCounter.Columns.Add("OFFSET100", typeof(int));
            _DataTableMCCounter.Columns.Add("RETRACT100", typeof(int));
            _DataTableMCCounter.Columns.Add("REM100", typeof(int));




            int NoteType = 0;
            int ReplenishmentCount = 0;
            int WithdrawalSuccessCount = 0;
            int WithdrawalRejectCount = 0;
            int Deposit_Count = 0;
            int OffsetCount = 0;
            int ReTractCount = 0;
            int RemCount = 0;


            decimal MCDis100 = 0;
            decimal MCDis200 = 0;
            decimal MCDis500 = 0;
            decimal MCDis2000 = 0;
            decimal MCRem100 = 0;
            decimal MCRem200 = 0;
            decimal MCRem500 = 0;
            decimal MCRem2000 = 0;
            decimal MCClosing100 = 0;
            decimal MCClosing200 = 0;
            decimal MCClosing500 = 0;
            decimal MCClosing2000 = 0;
            decimal RETRACTNOTESCOUNT = 0;



            int CWDRJI100 = 0;
            int CWDRJI200 = 0;
            int CWDRJI500 = 0;
            int CWDRJI2000 = 0;
            int CWF100 = 0;
            int CWF200 = 0;
            int CWF500 = 0;
            int CWF2000 = 0;
            int DEP100 = 0;
            int DEP200 = 0;
            int DEP500 = 0;
            int DEP2000 = 0;
            int DEPRJI100 = 0;
            int DEPRJI200 = 0;
            int DEPRJI500 = 0;
            int DEPRJI2000 = 0;
            int DEF100 = 0;
            int DEF200 = 0;
            int DEF500 = 0;
            int DEF2000 = 0;
            int RST100 = 0;
            int RST200 = 0;
            int RST500 = 0;
            int RST2000 = 0;
            int RETRACT100 = 0;
            int RETRACT200 = 0;
            int RETRACT500 = 0;
            int RETRACT2000 = 0;
            int TotalRjectedPurgeBIN100 = 0;
            int TotalRjectedPurgeBIN200 = 0;
            int TotalRjectedPurgeBIN500 = 0;
            int TotalRjectedPurgeBIN2000 = 0;


            int C2_REP2000 = 0;
            int C2_CWD2000 = 0;
            int C2_CWDRJO2000 = 0;
            int C2_DEP2000 = 0;
            int C2_OFFSET2000 = 0;
            int C2_RETRACT2000 = 0;
            int C2_REM2000 = 0;

            int C3_REP500 = 0;
            int C3_CWD500 = 0;
            int C3_CWDRJO500 = 0;
            int C3_DEP500 = 0;
            int C3_OFFSET500 = 0;
            int C3_RETRACT500 = 0;
            int C3_REM500 = 0;

            int C4_REP200 = 0;
            int C4_CWD200 = 0;
            int C4_CWDRJO200 = 0;
            int C4_DEP200 = 0;
            int C4_OFFSET200 = 0;
            int C4_RETRACT200 = 0;
            int C4_REM200 = 0;

            int C5_REP100 = 0;
            int C5_CWD100 = 0;
            int C5_CWDRJO100 = 0;
            int C5_DEP100 = 0;
            int C5_OFFSET100 = 0;
            int C5_RETRACT100 = 0;
            int C5_REM100 = 0;

            string CassetteMaster1 = string.Empty;
            string CassetteMaster2 = string.Empty;
            string CassetteMaster3 = string.Empty;
            string CassetteMaster4 = string.Empty;
            string CassetteMaster5 = string.Empty;

            string[] Type1 = new string[1];
            string[] Type2 = new string[1];
            string[] Type3 = new string[1];
            string[] Type4 = new string[1];

            DateTime? CounterDate = null;
            string[] CASSETTE = new string[3];
            Boolean purgeBinData = false;// set for insert values into datatable
            #endregion Machine Counter Declaration

            #region Switch Counter Declaration

            DataTable _DataTableSWCounter = new DataTable();
            _DataTableSWCounter.Columns.Add("TerminalID", typeof(string));
            _DataTableSWCounter.Columns.Add("CurrentEOD", typeof(DateTime));
            _DataTableSWCounter.Columns.Add("SWOp100", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWOp200", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWOp500", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWOp2000", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWOpTotal", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWDis100", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWDis200", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWDis500", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWDis2000", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWDisTotal", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWDep100", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWDep200", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWDep500", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWDep2000", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWDepTotal", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWRem100", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWRem200", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWRem500", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWRem2000", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWRemTotal", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWLoad100", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWLoad200", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWLoad500", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWLoad2000", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWLoadTotal", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWClosing100", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWClosing200", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWClosing500", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWClosing2000", typeof(decimal));
            _DataTableSWCounter.Columns.Add("SWClosingTotal", typeof(decimal));
            _DataTableSWCounter.Columns.Add("CreatedON", typeof(DateTime));
            _DataTableSWCounter.Columns.Add("Createdby", typeof(string));



            //int NotetypeCwd100 = 0;
            //int NotetypeCwd200 = 0;
            //int NotetypeCwd500 = 0;
            //int NotetypeCwd2000 = 0;

            //int SWCwd100 = 0;
            //int SWCwd200 = 0;
            //int SWCwd500 = 0;
            //int SWCwd2000 = 0;

            //int NotetypeDep100 = 0;
            //int NotetypeDep200 = 0;
            //int NotetypeDep500 = 0;
            //int NotetypeDep2000 = 0;

            int SWDep100 = 0;
            int SWDep200 = 0;
            int SWDep500 = 0;
            int SWDep2000 = 0;
            int SwDepTotal = 0;

            string SWOp100 = "0";
            string SWOp200 = "0";
            string SWOp500 = "0";
            string SWOp2000 = "0";
            string SWOpTotal = "0";
            string SWDis100 = "0";
            string SWDis200 = "0";
            string SWDis500 = "0";
            string SWDis2000 = "0";
            string SWDisTotal = "0";
            string SWRem100 = "0";
            string SWRem200 = "0";
            string SWRem500 = "0";
            string SWRem2000 = "0";
            string SWRemTotal = "0";
            string SWLoad100 = "0";
            string SWLoad200 = "0";
            string SWLoad500 = "0";
            string SWLoad2000 = "0";
            string SWLoadTotal = "0";
            string SWClosing100 = "0";
            string SWClosing200 = "0";
            string SWClosing500 = "0";
            string SWClosing2000 = "0";
            string SWClosingTotal = "0";
            string LastSWDis100 = "0";
            string LastSWDis200 = "0";
            string LastSWDis500 = "0";
            string LastSWDis2000 = "0";




            decimal NewSWOp100 = 0;
            decimal NewSWOp200 = 0;
            decimal NewSWOp500 = 0;
            decimal NewSWOp2000 = 0;
            decimal NewSWOpTotal = 0;
            decimal NewSWDis100 = 0;
            decimal NewSWDis200 = 0;
            decimal NewSWDis500 = 0;
            decimal NewSWDis2000 = 0;
            decimal NewSWDisTotal = 0;
            decimal NewSWRem100 = 0;
            decimal NewSWRem200 = 0;
            decimal NewSWRem500 = 0;
            decimal NewSWRem2000 = 0;
            decimal NewSWRemTotal = 0;
            decimal NewSWLoad100 = 0;
            decimal NewSWLoad200 = 0;
            decimal NewSWLoad500 = 0;
            decimal NewSWLoad2000 = 0;
            decimal NewSWLoadTotal = 0;
            decimal NewSWClosing100 = 0;
            decimal NewSWClosing200 = 0;
            decimal NewSWClosing500 = 0;
            decimal NewSWClosing2000 = 0;
            decimal NewSWClosingTotal = 0;
            decimal NewLastSWDis100 = 0;
            decimal NewLastSWDis200 = 0;
            decimal NewLastSWDis500 = 0;
            decimal NewLastSWDis2000 = 0;


            #endregion Switch Counter Declaration

            string SplitType = ",";
            string[] TerminalCode = fileImportRequest.ConfigData.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BIN_No = fileImportRequest.ConfigData.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] AcquirerIDArray = fileImportRequest.ConfigData.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode1Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode2Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ReversalType = fileImportRequest.ConfigData.Rows[0]["ReversalType"].ToString();
            string[] ATMType = fileImportRequest.ConfigData.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CDMType = fileImportRequest.ConfigData.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] POSType = fileImportRequest.ConfigData.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ECOMType = fileImportRequest.ConfigData.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] IMPType = fileImportRequest.ConfigData.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] UPIType = fileImportRequest.ConfigData.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MicroATMType = fileImportRequest.ConfigData.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MobileRechargeType = fileImportRequest.ConfigData.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BalanceEnquiry = fileImportRequest.ConfigData.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MiniStatement = fileImportRequest.ConfigData.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] PinChange = fileImportRequest.ConfigData.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ChequeBookReq = fileImportRequest.ConfigData.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ResponseType = fileImportRequest.ConfigData.Rows[0]["ResponseType"].ToString();
            string[] ResponseCode1Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ResponseCode2Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] OfflineCode = fileImportRequest.ConfigData.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnPostDateTime = fileImportRequest.ConfigData.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] DebitCode = fileImportRequest.ConfigData.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CreditCode = fileImportRequest.ConfigData.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);

            #region Declaration

            fileImportRequest.InsertCount = 0;
            fileImportRequest.InsertCount = 0; 
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;
            int StartIndex1 = 0;
            int EndIndex1 = 0;
            int StartIndexx = 0;
            int EndIndexx = 0; 

            DataSet ds = new DataSet();

            string LogType = fileImportRequest.ConfigData.Rows[0]["FileName"].ToString();
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = fileImportRequest.ConfigData.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
            string result = string.Empty;

            string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
            fileImportRequest.TotalCount = TotalCountArray.Length;


            // string result1 = ConvertStringArrayToString(TotalCountArray);
            // result = result1.Replace("ATM ID", "|ATM ID").Replace("REF NO", "|REF NO").Replace("DATE", "|DATE").Replace("TIME", "|TIME").Replace("CARD NO", "|CARD NO").Replace("A/C NO", "|A/C NO").Replace("TRANSTYPE", "|TRANSTYPE").Replace("RESP CODE", "|RESP CODE").Replace("WDL AMT", "|WDL AMT").Replace("DISPENSED", "|DISPENSED").Replace("BALANCE", "|BALANCE").Replace("------------------------------------", "|------------------------------------").Replace("|BALANCEENQUIRY", "BALANCEENQUIRY").Replace("a", "|").Replace("AMT", "|AMT").Replace("CRD", "|CRD").Replace("RESP CD", "|RESP CD").Replace("FR A/C#", "|FR A/C#").Trim();//.Replace("500  X", "|500  X").Replace("100  X", "|100  X").Trim();
            //TotalCountArray = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
            int totallength = TotalCountArray.Length;
            int ModeID = 0;
            DateTime TimeStamp = System.DateTime.Now;
            DateTime TimeStamp1 = System.DateTime.Now;
            DateTime FileDate = System.DateTime.Now;
            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string ModeType = string.Empty;
            int Status = 0;
            //DateTime? TxnsDateTime;
            //TxnsDateTime = null;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            //string TxnsAmount = "0";
            decimal TxnsAmount = 0;
            decimal ReqAmount = 0;
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            //DateTime? TxnsPostDateTime;
            //TxnsPostDateTime = null;
            string TxnsValueDateTime = string.Empty;
            //DateTime? TxnsValueDateTime;
            //TxnsValueDateTime = null;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string line = string.Empty;
            string line1 = string.Empty;
            string ResponseCode = string.Empty;
            string EJResult = string.Empty;
            string StrDateTime = string.Empty;
            string StrTime = string.Empty;
            string ErrorCode = string.Empty;
            string terminal = string.Empty;
            string TransSeqNo = string.Empty;
            string Opcode = string.Empty;
            string FunctionId = string.Empty;
            string Denomination = string.Empty;
            string ReqCount = string.Empty;
            string DispenseCount = string.Empty;
            string PickupCount = string.Empty;
            string RemainCount = string.Empty;
            string RejectCount = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string resultCode = string.Empty;
            string Remark3 = string.Empty;
            string Date = string.Empty;
            string Time = string.Empty;
            string TxnsStatus = string.Empty;
            string note = string.Empty;

            decimal Amount = 0;
            int LineNo1 = 0;
            bool flag = false;
            //terminal = FileName.Substring(0, 8);
            //int LineNo = 0;
            int ErrorLine = 0;
            string TempTerminalId = string.Empty;
            int AmountIndex = 0;


            #endregion Declaration

            
            //int ModeID = 0;
            int ChannelID = 0;
            bool ReversalFlag = false;
            //string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain;
            DateTime? TxnsPostDateTimeMain;
            string ECardNumber = string.Empty;

            for (int j = 0; j <= totallength; j++)
            {
                //withdrawal Splitter
                try
                {
                    LineNo = j;

                    StartIndex = Common.GetIndex(TotalCountArray, j, "TRANSACTION START");
                    EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "TRANSACTION START") - 1;

                    if (EndIndex == -2)
                    {
                        EndIndex = TotalCountArray.Length - 1;
                    }
                    if (EndIndex == -1)
                    {
                        EndIndex = TotalCountArray.Length - 1;
                    }

                    //TotalCount+

                    ModeID = 0;
                    TerminalID = string.Empty;
                    AcquirerID = string.Empty;
                    ReferenceNumber = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    InterchangeAccountNo = string.Empty;
                    ATMAccountNo = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsDate = string.Empty;
                    TxnsTime = string.Empty;
                    TxnsAmount = 0;
                    ReqAmount = 0;
                    Amount1 = "0";
                    Amount2 = "0";
                    Amount3 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsNumber = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;
                    TxnsPostDateTime = string.Empty;
                    TxnsValueDateTime = string.Empty;
                    AuthCode = string.Empty;
                    ProcessingCode = string.Empty;
                    FeeAmount = "0";
                    CurrencyCode = string.Empty;
                    CustBalance = "0";
                    InterchangeBalance = "0";
                    ATMBalance = "0";
                    BranchCode = string.Empty;
                    Cassette1 = string.Empty;
                    Cassette2 = string.Empty;
                    Cassette3 = string.Empty;
                    Cassette4 = string.Empty;
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    ResponseCode = string.Empty;
                    EJResult = string.Empty;
                    StrDateTime = string.Empty;
                    StrTime = string.Empty;
                    ErrorCode = string.Empty;
                    terminal = string.Empty;
                    TransSeqNo = string.Empty;
                    Opcode = string.Empty;
                    FunctionId = string.Empty;
                    Denomination = string.Empty;
                    ReqCount = string.Empty;
                    DispenseCount = string.Empty;
                    PickupCount = string.Empty;
                    RemainCount = string.Empty;
                    RejectCount = string.Empty;
                    TCode = string.Empty;
                    TCode1 = string.Empty;
                    resultCode = string.Empty;
                    Remark3 = string.Empty;
                    ECardNumber = string.Empty;
                    CardType = string.Empty;
                    Status = 0;
                    TxnsStatus = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    DebitCreditType = string.Empty;
                    AmountIndex = 0;
                    TxnsDateTimeMain = null;
                    TxnsPostDateTimeMain = null;

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {
                                LineNo++;
                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = Common.RemoveAdditionalChars(line);


                                //Machine Counter
                                #region Machine Counter Code
                                if (EJResult.Contains("SUPERVISOR MODE ACTIVE"))
                                {
                                    try
                                    {
                                        int StartIndex_SU = Common.GetIndex(TotalCountArray, k, "SUPERVISOR MODE ACTIVE");
                                        int EndIndex_SU = Common.GetIndex(TotalCountArray, StartIndex_SU + 1, "TRANSACTION START");

                                        if (EndIndex_SU == -1)
                                        {
                                            EndIndex_SU = TotalCountArray.Length - 1;
                                        }
                                        DateTime? RepTxnsDateTime = null;
                                        if (StartIndex_SU != -1 && EndIndex_SU != -1)
                                        {
                                            for (int l = StartIndex_SU + 1; l <= EndIndex_SU - 1; l++)
                                            {
                                                try
                                                {
                                                    line = Regex.Replace(TotalCountArray[l].ToString(), "[^ -~]+", string.Empty);
                                                    EJResult = Common.RemoveAdditionalChars(line);
                                                    if (EJResult.Contains("ATM") || EJResult.Contains("ATM"))
                                                    {
                                                        if (EJResult.Contains("BRANCH") && EJResult.Contains("ATM"))
                                                        {
                                                            TerminalID = EJResult.Substring(EJResult.LastIndexOf(":") + 1).Trim();
                                                            if (TerminalID != null)
                                                            {
                                                                TerminalID = EJResult.Substring(EJResult.LastIndexOf("A")).Trim();
                                                                if (TerminalID.Length > 0)
                                                                {
                                                                    DataTable dataTable = Common.GetCassetteInfoByTerminalId(_connectionString, fileImportRequest.ClientCode, TerminalID);

                                                                    if (dataTable != null && dataTable.Rows.Count > 0)
                                                                    {
                                                                        CassetteMaster2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                                                                        CassetteMaster3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                                                                        CassetteMaster4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);
                                                                        CassetteMaster5 = Convert.ToString(dataTable.Rows[0]["Cassette5"]);
                                                                    }
                                                                    dataTable = null;
                                                                }

                                                            }
                                                        }
                                                        else
                                                        {
                                                            TerminalID = EJResult.Split(' ').Last().Trim();
                                                        }
                                                        //TerminalID = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                                        if (TerminalID == null || TerminalID.Trim().Length == 0)
                                                        {
                                                            TerminalID = TempTerminalId;
                                                        }
                                                        else
                                                        {
                                                            TempTerminalId = TerminalID;
                                                        }
                                                    }

                                                    if (EJResult.Contains("CASSETTE1"))
                                                    {
                                                        purgeBinData = true;
                                                        int StartIndex_C1 = Common.GetIndex(TotalCountArray, l, "CASSETTE1");
                                                        int EndIndex_C1 = Common.GetIndex(TotalCountArray, StartIndex_C1 + 1, "CASSETTE2");

                                                        Dictionary<string, int[]> cassetteData = new Dictionary<string, int[]>();

                                                        for (int C1 = StartIndex_C1; C1 <= EndIndex_C1 - 1; C1++)
                                                        {
                                                            line = Regex.Replace(TotalCountArray[C1].ToString(), "[^ -~]+", string.Empty);
                                                            EJResult = Common.RemoveAdditionalChars(line);

                                                            if (EJResult.StartsWith("NOTE") || string.IsNullOrWhiteSpace(EJResult))
                                                                continue; // Skip NOTE line and empty lines
                                                            if (EJResult.Contains("CASH") && EJResult.Contains("PULL")) break;

                                                            string[] parts = EJResult.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                                                            if (parts.Length > 1)
                                                            {
                                                                string key = parts[0];
                                                                if (parts[1] == "RJI")
                                                                {
                                                                    key = parts[0] + parts[1];
                                                                }
                                                                int[] values = parts.Skip(1).Select(val => int.TryParse(val, out int x) ? x : 0).ToArray();
                                                                cassetteData[key] = values;
                                                            }
                                                        }

                                                        // Now map to your variables
                                                        CWDRJI2000 = cassetteData.ContainsKey("CWDRJI") ? cassetteData["CWDRJI"][1] : 0;
                                                        CWDRJI500 = cassetteData.ContainsKey("CWDRJI") ? cassetteData["CWDRJI"][2] : 0;
                                                        CWDRJI200 = cassetteData.ContainsKey("CWDRJI") ? cassetteData["CWDRJI"][3] : 0;
                                                        CWDRJI100 = cassetteData.ContainsKey("CWDRJI") ? cassetteData["CWDRJI"][4] : 0;

                                                        CWF2000 = cassetteData.ContainsKey("CWF") ? cassetteData["CWF"][0] : 0;
                                                        CWF500 = cassetteData.ContainsKey("CWF") ? cassetteData["CWF"][1] : 0;
                                                        CWF200 = cassetteData.ContainsKey("CWF") ? cassetteData["CWF"][2] : 0;
                                                        CWF100 = cassetteData.ContainsKey("CWF") ? cassetteData["CWF"][3] : 0;

                                                        DEP2000 = cassetteData.ContainsKey("DEP") ? cassetteData["DEP"][0] : 0;
                                                        DEP500 = cassetteData.ContainsKey("DEP") ? cassetteData["DEP"][1] : 0;
                                                        DEP200 = cassetteData.ContainsKey("DEP") ? cassetteData["DEP"][2] : 0;
                                                        DEP100 = cassetteData.ContainsKey("DEP") ? cassetteData["DEP"][3] : 0;

                                                        DEPRJI2000 = cassetteData.ContainsKey("DEPRJI") ? cassetteData["DEPRJI"][1] : 0;
                                                        DEPRJI500 = cassetteData.ContainsKey("DEPRJI") ? cassetteData["DEPRJI"][2] : 0;
                                                        DEPRJI200 = cassetteData.ContainsKey("DEPRJI") ? cassetteData["DEPRJI"][3] : 0;
                                                        DEPRJI100 = cassetteData.ContainsKey("DEPRJI") ? cassetteData["DEPRJI"][4] : 0;

                                                        DEF2000 = cassetteData.ContainsKey("DEF") ? cassetteData["DEF"][0] : 0;
                                                        DEF500 = cassetteData.ContainsKey("DEF") ? cassetteData["DEF"][1] : 0;
                                                        DEF200 = cassetteData.ContainsKey("DEF") ? cassetteData["DEF"][2] : 0;
                                                        DEF100 = cassetteData.ContainsKey("DEF") ? cassetteData["DEF"][3] : 0;

                                                        RST2000 = cassetteData.ContainsKey("RST") ? cassetteData["RST"][0] : 0;
                                                        RST500 = cassetteData.ContainsKey("RST") ? cassetteData["RST"][1] : 0;
                                                        RST200 = cassetteData.ContainsKey("RST") ? cassetteData["RST"][2] : 0;
                                                        RST100 = cassetteData.ContainsKey("RST") ? cassetteData["RST"][3] : 0;

                                                        RETRACT2000 = cassetteData.ContainsKey("RETRACT") ? cassetteData["RETRACT"][0] : 0;
                                                        RETRACT500 = cassetteData.ContainsKey("RETRACT") ? cassetteData["RETRACT"][1] : 0;
                                                        RETRACT200 = cassetteData.ContainsKey("RETRACT") ? cassetteData["RETRACT"][2] : 0;
                                                        RETRACT100 = cassetteData.ContainsKey("RETRACT") ? cassetteData["RETRACT"][3] : 0;

                                                        //REM
                                                        TotalRjectedPurgeBIN2000 = cassetteData.ContainsKey("REM") ? cassetteData["REM"][0] : 0;
                                                        TotalRjectedPurgeBIN500 = cassetteData.ContainsKey("REM") ? cassetteData["REM"][1] : 0;
                                                        TotalRjectedPurgeBIN200 = cassetteData.ContainsKey("REM") ? cassetteData["REM"][2] : 0;
                                                        TotalRjectedPurgeBIN100 = cassetteData.ContainsKey("REM") ? cassetteData["REM"][3] : 0;

                                                        l = EndIndex_C1 - 1;
                                                    }
                                                    else if (EJResult.Contains("CASSETTE2"))
                                                    {
                                                        int StartIndex_C2 = Common.GetIndex(TotalCountArray, l, "CASSETTE2");
                                                        int EndIndex_C2 = Common.GetIndex(TotalCountArray, StartIndex_C2 + 1, "CASSETTE3");

                                                        for (int C2 = StartIndex_C2; C2 <= EndIndex_C2 - 1; C2++)
                                                        {
                                                            line = Regex.Replace(TotalCountArray[C2].ToString(), "[^ -~]+", string.Empty);
                                                            EJResult = Common.RemoveAdditionalChars(line);

                                                            if (EJResult.Contains("NOTE"))
                                                                NoteType = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("REP"))
                                                                C2_REP2000 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("CWD RJO"))
                                                                C2_CWDRJO2000 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("CWD"))
                                                                C2_CWD2000 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("DEP"))
                                                                C2_DEP2000 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("OFFSET"))
                                                                C2_OFFSET2000 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("RETRACT"))
                                                                C2_RETRACT2000 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("REM"))
                                                                C2_REM2000 = Common.GetValue(EJResult);
                                                        }
                                                        l = EndIndex_C2 - 1;
                                                    }
                                                    else if (EJResult.Contains("CASSETTE3"))
                                                    {
                                                        int StartIndex_C3 = Common.GetIndex(TotalCountArray, l, "CASSETTE3");
                                                        int EndIndex_C3 = Common.GetIndex(TotalCountArray, StartIndex_C3 + 1, "CASSETTE4");

                                                        for (int C2 = StartIndex_C3; C2 <= EndIndex_C3 - 1; C2++)
                                                        {
                                                            line = Regex.Replace(TotalCountArray[C2].ToString(), "[^ -~]+", string.Empty);
                                                            EJResult = Common.RemoveAdditionalChars(line);

                                                            if (EJResult.Contains("NOTE"))
                                                                NoteType = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("REP"))
                                                                C3_REP500 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("CWD RJO"))
                                                                C3_CWDRJO500 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("CWD"))
                                                                C3_CWD500 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("DEP"))
                                                                C3_DEP500 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("OFFSET"))
                                                                C3_OFFSET500 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("RETRACT"))
                                                                C3_RETRACT500 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("REM"))
                                                                C3_REM500 = Common.GetValue(EJResult);
                                                        }
                                                        l = EndIndex_C3 - 1;
                                                    }
                                                    else if (EJResult.Contains("CASSETTE4"))
                                                    {
                                                        int StartIndex_C4 = Common.GetIndex(TotalCountArray, l, "CASSETTE4");
                                                        int EndIndex_C4 = Common.GetIndex(TotalCountArray, StartIndex_C4 + 1, "CASSETTE5");

                                                        for (int C2 = StartIndex_C4; C2 <= EndIndex_C4 - 1; C2++)
                                                        {
                                                            line = Regex.Replace(TotalCountArray[C2].ToString(), "[^ -~]+", string.Empty);
                                                            EJResult = Common.RemoveAdditionalChars(line);

                                                            if (EJResult.Contains("NOTE"))
                                                                NoteType = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("REP"))
                                                                C4_REP200 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("CWD RJO"))
                                                                C4_CWDRJO200 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("CWD"))
                                                                C4_CWD200 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("DEP"))
                                                                C4_DEP200 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("OFFSET"))
                                                                C4_OFFSET200 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("RETRACT"))
                                                                C4_RETRACT200 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("REM"))
                                                                C4_REM200 = Common.GetValue(EJResult);
                                                        }
                                                        l = EndIndex_C4 - 1;
                                                    }
                                                    else if (EJResult.Contains("CASSETTE5"))
                                                    {
                                                        int StartIndex_C5 = Common.GetIndex(TotalCountArray, l, "CASSETTE5");
                                                        int EndIndex_C5 = Common.GetIndex(TotalCountArray, StartIndex_C5 + 1, "REMAINING NOTES");

                                                        for (int C2 = StartIndex_C5; C2 <= EndIndex_C5 - 1; C2++)
                                                        {
                                                            line = Regex.Replace(TotalCountArray[C2].ToString(), "[^ -~]+", string.Empty);
                                                            EJResult = Common.RemoveAdditionalChars(line);

                                                            if (EJResult.Contains("NOTE"))
                                                                NoteType = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("REP"))
                                                                C5_REP100 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("CWD RJO"))
                                                                C5_CWDRJO100 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("CWD"))
                                                                C5_CWD100 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("DEP"))
                                                                C5_DEP100 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("OFFSET"))
                                                                C5_OFFSET100 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("RETRACT"))
                                                                C5_RETRACT100 = Common.GetValue(EJResult);
                                                            else if (EJResult.Contains("REM"))
                                                                C5_REM100 = Common.GetValue(EJResult);
                                                        }
                                                        l = EndIndex_C5 - 1;
                                                    }

                                                    //Find REPLENISHMENT dateTime
                                                    if (EJResult.StartsWith("DATE") && (EJResult.Contains("TIME")))
                                                    {
                                                        // Extract date
                                                        StrDateTime = EJResult.Substring(EJResult.IndexOf("DATE:") + "DATE:".Length).Trim();
                                                        TxnsDate = StrDateTime.Split(' ')[0].Trim();

                                                        // Extract time
                                                        StrTime = EJResult.Substring(EJResult.IndexOf("TIME:") + "TIME:".Length).Trim();
                                                        TxnsTime = StrTime.Split(' ')[0].Trim();
                                                    }


                                                    //Added Cash
                                                    if (EJResult.Contains("REPLENISHMENT"))
                                                    {
                                                        if (TxnsDate != "" && TxnsTime != "")
                                                        {
                                                            string temp = TxnsDate + " " + TxnsTime;
                                                            try
                                                            {
                                                                RepTxnsDateTime = DateTime.ParseExact(temp.ToString(), "MM/dd/yy HH:mm:ss", CultureInfo.InvariantCulture);
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                RepTxnsDateTime = DateTime.Now;
                                                            }
                                                        }

                                                        int StartIndex_Rep = Common.GetIndex(TotalCountArray, l, "REPLENISHMENT");
                                                        int EndIndex_Rep = Common.GetIndex(TotalCountArray, StartIndex_Rep + 1, "RESET");

                                                        if (EndIndex_Rep == -1)
                                                        {
                                                            EndIndex_Rep = TotalCountArray.Length - 1;
                                                        }

                                                        if (StartIndex_Rep != -1 && EndIndex_Rep != -1)
                                                        {

                                                            for (int i = StartIndex_Rep + 1; i < EndIndex_Rep - 1; i++)
                                                            {
                                                                line = Regex.Replace(TotalCountArray[i].ToString(), "[^ -~]+", string.Empty);
                                                                EJResult = Common.RemoveAdditionalChars(line);

                                                                if (line.Contains("CASSETTE"))
                                                                {
                                                                    string[] parts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                                                                    if (parts.Length >= 4 && int.TryParse(parts[2], out int denom) && int.TryParse(parts[3], out int count))
                                                                    {
                                                                        switch (denom)
                                                                        {
                                                                            case 2000:
                                                                                SWLoad2000 += count;
                                                                                break;
                                                                            case 500:
                                                                                SWLoad500 += count;
                                                                                break;
                                                                            case 200:
                                                                                SWLoad200 += count;
                                                                                break;
                                                                            case 100:
                                                                                SWLoad100 += count;
                                                                                break;
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            l = EndIndex_Rep;
                                                        }
                                                    }


                                                    //Switch counter
                                                    if (EJResult.Contains("DENOM NOTE CNT-AMOUNT") && !EJResult.Contains("REM"))
                                                    {

                                                        if (TxnsDate != "" && TxnsTime != "")
                                                        {
                                                            string temp = TxnsDate + " " + TxnsTime;
                                                            try
                                                            {
                                                                CounterDate = DateTime.ParseExact(temp.ToString(), "MM/dd/yy HH:mm:ss", CultureInfo.InvariantCulture);
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                CounterDate = DateTime.Now;
                                                            }
                                                        }


                                                        int StartIndex_SC = Common.GetIndex(TotalCountArray, l, "DENOM NOTE CNT-AMOUNT");
                                                        int EndIndex_SC = Common.GetIndex(TotalCountArray, StartIndex_SC + 1, "LAST CLEARED");

                                                        if (EndIndex_SC == -1)
                                                        {
                                                            EndIndex_SC = TotalCountArray.Length - 1;
                                                        }
                                                        Boolean CwdOrDep = false;
                                                        for (int i = StartIndex_SC + 1; i < EndIndex_SC; i++)
                                                        {
                                                            line = Regex.Replace(TotalCountArray[i].ToString(), "[^ -~]+", string.Empty);
                                                            EJResult = Common.RemoveAdditionalChars(line);

                                                            if (EJResult.Contains("DEP"))
                                                            {
                                                                CwdOrDep = true;
                                                            }

                                                            if (line.StartsWith("CWD") || line.StartsWith("DEP"))
                                                            {
                                                                // Remove prefix like "CWD" or "DEP"
                                                                int firstSpace = line.IndexOf(' ');
                                                                if (firstSpace > -1)
                                                                {
                                                                    line = line.Substring(firstSpace + 1).Trim();
                                                                }

                                                                EJResult = Common.RemoveAdditionalChars(line);
                                                            }
                                                            string[] parts = EJResult.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                                                            if (parts.Length >= 2 && int.TryParse(parts[0], out int noteType))
                                                            {
                                                                string[] countParts = parts[1].Split('-');
                                                                string rawCount = countParts[0].TrimStart('0');
                                                                if (string.IsNullOrEmpty(rawCount))
                                                                    rawCount = "0";
                                                                int.TryParse(rawCount, out int noteCount);

                                                                if (!CwdOrDep)
                                                                {
                                                                    switch (noteType)
                                                                    {
                                                                        case 100:
                                                                            SWDis100 += noteCount;
                                                                            break;
                                                                        case 200:
                                                                            SWDis200 += noteCount;
                                                                            break;
                                                                        case 500:
                                                                            SWDis500 += noteCount;
                                                                            break;
                                                                        case 2000:
                                                                            SWDis2000 += noteCount;
                                                                            break;
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    switch (noteType)
                                                                    {
                                                                        case 100:
                                                                            SWDep100 = noteCount;
                                                                            break;
                                                                        case 200:
                                                                            SWDep200 = noteCount;
                                                                            break;
                                                                        case 500:
                                                                            SWDep500 = noteCount;
                                                                            break;
                                                                        case 2000:
                                                                            SWDep2000 = noteCount;
                                                                            break;
                                                                    }
                                                                }

                                                            }
                                                        }

                                                        l = EndIndex_SC - 1;
                                                        try
                                                        {
                                                            #region Storing switch counter in datatable
                                                            SWRem100 = string.IsNullOrEmpty(SWRem100) ? "0" : SWRem100;
                                                            SWRem200 = string.IsNullOrEmpty(SWRem200) ? "0" : SWRem200;
                                                            SWRem500 = string.IsNullOrEmpty(SWRem500) ? "0" : SWRem500;
                                                            SWRem2000 = string.IsNullOrEmpty(SWRem2000) ? "0" : SWRem2000;
                                                            SWRemTotal = string.IsNullOrEmpty(SWRemTotal) ? "0" : SWRemTotal;
                                                            SWLoad100 = string.IsNullOrEmpty(SWLoad100) ? "0" : SWLoad100;
                                                            SWLoad200 = string.IsNullOrEmpty(SWLoad200) ? "0" : SWLoad200;
                                                            SWLoad500 = string.IsNullOrEmpty(SWLoad500) ? "0" : SWLoad500;
                                                            SWLoad2000 = string.IsNullOrEmpty(SWLoad2000) ? "0" : SWLoad2000;
                                                            SWLoadTotal = string.IsNullOrEmpty(SWLoadTotal) ? "0" : SWLoadTotal;


                                                            SWOp100 = string.IsNullOrEmpty(SWOp100) ? "0" : SWOp100;
                                                            SWOp200 = string.IsNullOrEmpty(SWOp200) ? "0" : SWOp200;
                                                            SWOp500 = string.IsNullOrEmpty(SWOp500) ? "0" : SWOp500;
                                                            SWOp2000 = string.IsNullOrEmpty(SWOp2000) ? "0" : SWOp2000;
                                                            SWOpTotal = string.IsNullOrEmpty(SWOpTotal) ? "0" : SWOpTotal;
                                                            SWDis100 = string.IsNullOrEmpty(SWDis100) ? "0" : SWDis100;
                                                            SWDis200 = string.IsNullOrEmpty(SWDis200) ? "0" : SWDis200;
                                                            SWDis500 = string.IsNullOrEmpty(SWDis500) ? "0" : SWDis500;
                                                            SWDis2000 = string.IsNullOrEmpty(SWDis2000) ? "0" : SWDis2000;
                                                            string tempTotalDis = Convert.ToString((Convert.ToDecimal(SWDis100) + Convert.ToDecimal(SWDis200) + Convert.ToDecimal(SWDis500) + Convert.ToDecimal(SWDis2000)));
                                                            SWDisTotal = string.IsNullOrEmpty(tempTotalDis) ? "0" : tempTotalDis;
                                                            SWClosing100 = string.IsNullOrEmpty(SWClosing100) ? "0" : SWClosing100;
                                                            SWClosing200 = string.IsNullOrEmpty(SWClosing200) ? "0" : SWClosing200;
                                                            SWClosing500 = string.IsNullOrEmpty(SWClosing500) ? "0" : SWClosing500;
                                                            SWClosing2000 = string.IsNullOrEmpty(SWClosing2000) ? "0" : SWClosing2000;
                                                            SWClosingTotal = string.IsNullOrEmpty(SWClosingTotal) ? "0" : SWClosingTotal;



                                                            try
                                                            {
                                                                NewSWOp100 = Convert.ToDecimal(SWOp100);
                                                                NewSWOp200 = Convert.ToDecimal(SWRem200);
                                                                NewSWOp500 = Convert.ToDecimal(SWRem500);
                                                                NewSWOp2000 = Convert.ToDecimal(SWRem2000);
                                                                NewSWOpTotal = Convert.ToDecimal(SWOpTotal);
                                                                NewSWDis100 = Convert.ToDecimal(SWDis100);
                                                                NewSWDis200 = Convert.ToDecimal(SWDis200);
                                                                NewSWDis500 = Convert.ToDecimal(SWRem500);
                                                                NewSWDis2000 = Convert.ToDecimal(SWRem2000);
                                                                NewSWDisTotal = Convert.ToDecimal(SWDisTotal);
                                                                NewSWRem100 = Convert.ToDecimal(SWRem100);
                                                                NewSWRem200 = Convert.ToDecimal(SWRem200);
                                                                NewSWRem500 = Convert.ToDecimal(SWRem500);
                                                                NewSWRem2000 = Convert.ToDecimal(SWRem2000);
                                                                NewSWRemTotal = Convert.ToDecimal(SWRemTotal);
                                                                NewSWLoad100 = Convert.ToDecimal(SWLoad100);
                                                                NewSWLoad200 = Convert.ToDecimal(SWLoad200);
                                                                NewSWLoad500 = Convert.ToDecimal(SWLoad500);
                                                                NewSWLoad2000 = Convert.ToDecimal(SWLoad2000);
                                                                NewSWLoadTotal = Convert.ToDecimal(SWLoadTotal);
                                                                NewSWClosing100 = Convert.ToDecimal(SWClosing100);
                                                                NewSWClosing200 = Convert.ToDecimal(SWClosing200);
                                                                NewSWClosing500 = Convert.ToDecimal(SWClosing500);
                                                                NewSWClosing2000 = Convert.ToDecimal(SWClosing2000);
                                                                NewSWClosingTotal = Convert.ToDecimal(SWClosingTotal);
                                                                NewLastSWDis100 = Convert.ToDecimal("0");
                                                                NewLastSWDis200 = Convert.ToDecimal("0");
                                                                NewLastSWDis500 = Convert.ToDecimal("0");
                                                                NewLastSWDis2000 = Convert.ToDecimal("0");
                                                            }
                                                            catch (Exception ex)
                                                            {
                                                                Console.WriteLine("Conversion Error");
                                                            }


                                                            if (CounterDate != null)
                                                            {
                                                                _DataTableSWCounter.Rows.Add(
                                                                       TerminalID,
                                                                       CounterDate,
                                                                       Convert.ToDecimal(SWOp100),
                                                                       Convert.ToDecimal(SWOp200),
                                                                       Convert.ToDecimal(SWOp500),
                                                                       Convert.ToDecimal(SWOp2000),
                                                                       ((Convert.ToDecimal(SWOp100)) * 100) + ((Convert.ToDecimal(SWOp200)) * 200) + ((Convert.ToDecimal(SWOp500)) * 500) + ((Convert.ToDecimal(SWOp2000)) * 2000),
                                                                       Convert.ToDecimal(SWDis100),
                                                                       Convert.ToDecimal(SWDis200),
                                                                       Convert.ToDecimal(SWDis500),
                                                                       Convert.ToDecimal(SWDis2000),
                                                                       ((Convert.ToDecimal(SWDis100)) * 100) + ((Convert.ToDecimal(SWDis200)) * 200) + ((Convert.ToDecimal(SWDis500)) * 500) + ((Convert.ToDecimal(SWDis2000)) * 2000),
                                                                       Convert.ToDecimal(SWDep100),
                                                                       Convert.ToDecimal(SWDep200),
                                                                       Convert.ToDecimal(SWDep500),
                                                                       Convert.ToDecimal(SWDep2000),
                                                                       ((Convert.ToDecimal(SWDep100)) * 100) + ((Convert.ToDecimal(SWDep200)) * 200) + ((Convert.ToDecimal(SWDep500)) * 500) + ((Convert.ToDecimal(SWDep2000)) * 2000),
                                                                        Convert.ToDecimal(SWRem100),
                                                                        Convert.ToDecimal(SWRem200),
                                                                        Convert.ToDecimal(SWRem500),
                                                                        Convert.ToDecimal(SWRem2000),
                                                                       ((Convert.ToDecimal(SWRem100)) * 100) + ((Convert.ToDecimal(SWRem200)) * 200) + ((Convert.ToDecimal(SWRem500)) * 500) + ((Convert.ToDecimal(SWRem2000)) * 2000),
                                                                         Convert.ToDecimal(SWLoad100),
                                                                         Convert.ToDecimal(SWLoad200),
                                                                            Convert.ToDecimal(SWLoad500),
                                                                            Convert.ToDecimal(SWLoad2000),
                                                                          (Convert.ToDecimal(SWLoad100) * 100) + (Convert.ToDecimal(SWLoad200) * 200) + (Convert.ToDecimal(SWLoad500) * 500) + (Convert.ToDecimal(SWLoad2000) * 2000),
                                                                          Convert.ToDecimal(SWClosing100),
                                                                          Convert.ToDecimal(SWClosing200),
                                                                          Convert.ToDecimal(SWClosing500),
                                                                          Convert.ToDecimal(SWClosing2000),
                                                                          ((Convert.ToDecimal(SWClosing100)) * 100) + ((Convert.ToDecimal(SWClosing200)) * 200) + ((Convert.ToDecimal(SWClosing500)) * 500) + ((Convert.ToDecimal(SWClosing2000)) * 2000),
                                                                         System.DateTime.Now,
                                                                          fileImportRequest.UserName);
                                                            }

                                                            #endregion

                                                            SWOp100 = "0";
                                                            SWOp200 = "0";
                                                            SWOp500 = "0";
                                                            SWOp2000 = "0";
                                                            SWOpTotal = "0";
                                                            SWDis100 = "0";
                                                            SWDis200 = "0";
                                                            SWDis500 = "0";
                                                            SWDis2000 = "0";
                                                            SWDisTotal = "0";
                                                            SWDep100 = 0;
                                                            SWDep200 = 0;
                                                            SWDep500 = 0;
                                                            SWDep2000 = 0;
                                                            SwDepTotal = 0;
                                                            SWRem100 = "0";
                                                            SWRem200 = "0";
                                                            SWRem500 = "0";
                                                            SWRem2000 = "0";
                                                            SWRemTotal = "0";
                                                            SWLoad100 = "0";
                                                            SWLoad200 = "0";
                                                            SWLoad500 = "0";
                                                            SWLoad2000 = "0";
                                                            SWLoadTotal = "0";
                                                            SWClosing100 = "0";
                                                            SWClosing200 = "0";
                                                            SWClosing500 = "0";
                                                            SWClosing2000 = "0";
                                                            SWClosingTotal = "0";
                                                            LastSWDis100 = "0";
                                                            LastSWDis200 = "0";
                                                            LastSWDis500 = "0";
                                                            LastSWDis2000 = "0";
                                                        }

                                                        catch (Exception ex)
                                                        {

                                                        }




                                                    }


                                                }
                                                catch (Exception ex)
                                                {
                                                    l = EndIndex_SU;
                                                }
                                            }


                                            try
                                            {
                                                if ((NoteType != null && NoteType != 0) || purgeBinData)
                                                {
                                                    _DataTableMCCounter.Rows.Add(
                                                    ClientID,
                                                    TerminalID,
                                                    CounterDate,
                                                    (MCRem100 + MCDis100),
                                                    (MCRem200 + MCDis200),
                                                    (MCRem500 + MCDis500),
                                                    (MCRem2000 + MCDis2000),
                                                    ((MCRem100 + MCDis100) * 100) + ((MCRem200 + MCDis200) * 200) + ((MCRem500 + MCDis500) * 500) + ((MCRem2000 + MCDis2000) * 2000),
                                                    MCDis100,
                                                    MCDis200,
                                                    MCDis500,
                                                    MCDis2000,
                                                    (MCDis100 * 100) + (MCDis200 * 200) + (MCDis500 * 500) + (MCDis2000 * 2000),
                                                    MCRem100,
                                                    MCRem200,
                                                    MCRem500,
                                                    MCRem2000,
                                                    (MCRem100 * 100) + (MCRem200 * 200) + (MCRem500 * 500) + (MCRem2000 * 2000),
                                                    MCClosing100 - MCRem100,
                                                    MCClosing200 - MCRem200,
                                                    MCClosing500 - MCRem500,
                                                    MCClosing2000 - MCRem2000,
                                                    ((MCClosing100 - MCRem100) * 100) + ((MCClosing200 - MCRem200) * 200) + ((MCClosing500 - MCRem500) * 500) + ((MCClosing2000 - MCRem2000) * 2000),
                                                    MCClosing100,
                                                    MCClosing200,
                                                    MCClosing500,
                                                    MCClosing2000,
                                                    (MCClosing100 * 100) + (MCClosing200 * 200) + (MCClosing500 * 500) + (MCClosing2000 * 2000),
                                                    RETRACTNOTESCOUNT,
                                                    string.Empty,
                                                    fileImportRequest.FileName,
                                                    fileImportRequest.Path,
                                                    FileDate,
                                                    System.DateTime.Now,
                                                    fileImportRequest.UserName,
                                                    NoteType
                                                    , ReplenishmentCount,
                                                    WithdrawalSuccessCount,
                                                    WithdrawalRejectCount,
                                                    Deposit_Count,
                                                    OffsetCount,
                                                    ReTractCount,
                                                    RemCount,
                                                    CWDRJI100,
                                                    CWDRJI200,
                                                    CWDRJI500,
                                                    CWDRJI2000,
                                                    CWF100,
                                                    CWF200,
                                                    CWF500,
                                                    CWF2000,
                                                    DEP100,
                                                    DEP200,
                                                    DEP500,
                                                    DEP2000,
                                                    DEPRJI100,
                                                    DEPRJI200,
                                                    DEPRJI500,
                                                    DEPRJI2000,
                                                    DEF100,
                                                    DEF200,
                                                    DEF500,
                                                    DEF2000,
                                                    RST100,
                                                    RST200,
                                                    RST500,
                                                    RST2000,
                                                    RETRACT100,
                                                    RETRACT200,
                                                    RETRACT500,
                                                    RETRACT2000,
                                                    TotalRjectedPurgeBIN100,
                                                    TotalRjectedPurgeBIN200,
                                                    TotalRjectedPurgeBIN500,
                                                    TotalRjectedPurgeBIN2000,
                                                    C2_REP2000,
                                                    C2_CWD2000,
                                                    C2_CWDRJO2000,
                                                    C2_DEP2000,
                                                    C2_OFFSET2000,
                                                    C2_RETRACT2000,
                                                    C2_REM2000
                                                     , C3_REP500
                                                    , C3_CWD500
                                                    , C3_CWDRJO500
                                                    , C3_DEP500
                                                    , C3_OFFSET500
                                                    , C3_RETRACT500
                                                    , C3_REM500
                                                    , C4_REP200
                                                    , C4_CWD200
                                                    , C4_CWDRJO200
                                                    , C4_DEP200
                                                    , C4_OFFSET200
                                                    , C4_RETRACT200
                                                    , C4_REM200
                                                    , C5_REP100
                                                    , C5_CWD100
                                                    , C5_CWDRJO100
                                                    , C5_DEP100
                                                    , C5_OFFSET100
                                                    , C5_RETRACT100
                                                    , C5_REM100
                                                  );
                                                }


                                            }
                                            catch (Exception ex)
                                            {
                                                DBLog.InsertLogs("Adding machine counter in data table => " + ex.Message, fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);

                                                // DBLog.InsertLogs(, TerminalId, "SplitterCITIZEN.cs", "ASP_SplitDataMachineCounter", LineNo, FileName, UserName, 'E', _connectionString);
                                            }

                                            NoteType = 0;
                                            ReplenishmentCount = 0;
                                            WithdrawalSuccessCount = 0;
                                            WithdrawalRejectCount = 0;
                                            Deposit_Count = 0;
                                            OffsetCount = 0;
                                            ReTractCount = 0;
                                            RemCount = 0;
                                            RepTxnsDateTime = null;

                                            MCDis100 = 0;
                                            MCDis200 = 0;
                                            MCDis500 = 0;
                                            MCDis2000 = 0;
                                            MCRem100 = 0;
                                            MCRem200 = 0;
                                            MCRem500 = 0;
                                            MCRem2000 = 0;
                                            MCClosing100 = 0;
                                            MCClosing200 = 0;
                                            MCClosing500 = 0;
                                            MCClosing2000 = 0;
                                            RETRACTNOTESCOUNT = 0;
                                            CWDRJI100 = 0;
                                            CWDRJI200 = 0;
                                            CWDRJI500 = 0;
                                            CWDRJI2000 = 0;
                                            CWF100 = 0;
                                            CWF200 = 0;
                                            CWF500 = 0;
                                            CWF2000 = 0;
                                            DEP100 = 0;
                                            DEP200 = 0;
                                            DEP500 = 0;
                                            DEP2000 = 0;
                                            DEPRJI100 = 0;
                                            DEPRJI200 = 0;
                                            DEPRJI500 = 0;
                                            DEPRJI2000 = 0;
                                            DEF100 = 0;
                                            DEF200 = 0;
                                            DEF500 = 0;
                                            DEF2000 = 0;
                                            RST100 = 0;
                                            RST200 = 0;
                                            RST500 = 0;
                                            RST2000 = 0;
                                            RETRACT100 = 0;
                                            RETRACT200 = 0;
                                            RETRACT500 = 0;
                                            RETRACT2000 = 0;
                                            TotalRjectedPurgeBIN100 = 0;
                                            TotalRjectedPurgeBIN200 = 0;
                                            TotalRjectedPurgeBIN500 = 0;
                                            TotalRjectedPurgeBIN2000 = 0;
                                            purgeBinData = false;

                                            C2_REP2000 = 0;
                                            C2_CWD2000 = 0;
                                            C2_CWDRJO2000 = 0;
                                            C2_DEP2000 = 0;
                                            C2_OFFSET2000 = 0;
                                            C2_RETRACT2000 = 0;
                                            C2_REM2000 = 0;
                                            C3_REP500 = 0;
                                            C3_CWD500 = 0;
                                            C3_CWDRJO500 = 0;
                                            C3_DEP500 = 0;
                                            C3_OFFSET500 = 0;
                                            C3_RETRACT500 = 0;
                                            C3_REM500 = 0;
                                            C4_REP200 = 0;
                                            C4_CWD200 = 0;
                                            C4_CWDRJO200 = 0;
                                            C4_DEP200 = 0;
                                            C4_OFFSET200 = 0;
                                            C4_RETRACT200 = 0;
                                            C4_REM200 = 0;
                                            C5_REP100 = 0;
                                            C5_CWD100 = 0;
                                            C5_CWDRJO100 = 0;
                                            C5_DEP100 = 0;
                                            C5_OFFSET100 = 0;
                                            C5_RETRACT100 = 0;
                                            C5_REM100 = 0;

                                            if (_DataTableSWCounter.Rows.Count > 0)
                                            {
                                                int InsertSWCount = _DataTableSWCounter.Rows.Count;
                                            }
                                            if (_DataTableMCCounter.Rows.Count > 0)
                                            {
                                                int InsertMCCount = _DataTableMCCounter.Rows.Count;
                                            }
                                            k = EndIndex_SU;

                                        }


                                        //Old
                                    }
                                    catch (Exception ex)
                                    {
                                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                                        DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    }
                                }

                                #endregion Machine Counter Code

                                #region Withdrawal & Deposit
                                //if (EJResult.Contains("WITHDRAWAL") || EJResult.Contains("DEPOSIT"))
                                //{
                                //    string[] SplitData = EJResult.Split(' ');
                                //    TxnsSubType = SplitData[1].ToString();
                                //    ReserveField1 = SplitData[1].ToString();
                                //    if (EJResult.Contains("WITHDRAWAL")) DrCrType = "D";
                                //    if (EJResult.Contains("DEPOSIT")) DrCrType = "C";

                                //    if (EJResult.Contains("DEPOSIT"))
                                //    {

                                //    }
                                //}
                                if (EJResult.Contains("TXN NO") || EJResult.Contains("TXN No"))
                                {
                                    TxnsNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.StartsWith("DATE") && (EJResult.Contains("TIME")))
                                {
                                    // Extract date
                                    StrDateTime = EJResult.Substring(EJResult.IndexOf("DATE:") + "DATE:".Length).Trim();
                                    TxnsDate = StrDateTime.Split(' ')[0].Trim();

                                    // Extract time
                                    StrTime = EJResult.Substring(EJResult.IndexOf("TIME:") + "TIME:".Length).Trim();
                                    TxnsTime = StrTime.Split(' ')[0].Trim();
                                }

                                else if ((string.IsNullOrEmpty(TxnsDate) || string.IsNullOrEmpty(TxnsTime)) && EJResult.StartsWith("------------") && EJResult.EndsWith("-------------"))
                                {
                                    // Remove leading and trailing hyphens
                                    string cleanLine = EJResult.Trim('-').Trim();
                                    // Now cleanLine = "01/10/25 10:38:20"

                                    if (!string.IsNullOrEmpty(cleanLine))
                                    {
                                        var dateTimeParts = cleanLine.Split(' ');
                                        if (dateTimeParts.Length >= 2)
                                        {
                                            TxnsDate = dateTimeParts[0].Trim();
                                            TxnsTime = dateTimeParts[1].Trim();
                                        }
                                    }
                                }


                                if (EJResult.StartsWith("---") && EJResult.Contains("ATM"))
                                {
                                    TerminalID = EJResult.Substring(EJResult.LastIndexOf("ATM")).Trim();

                                    if (TerminalID.Length > 0)
                                    {
                                        TempTerminalId = TerminalID;
                                    }
                                }

                                if (EJResult.Contains("CARD"))
                                {
                                    if (EJResult.Contains("CARD NO"))
                                    {
                                        CardNumber = string.Empty;
                                        CardNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                        int Counter = 0;

                                        for (int i = k + 1; i <= (k + 4); i++)
                                        {
                                            EJResult = Common.RemoveAdditionalChars(Regex.Replace(TotalCountArray[i].ToString(), "[^ -~]+", string.Empty));
                                            Counter = i;
                                            if ((EJResult.Trim()).Length != 0)
                                            {
                                                var parts = EJResult.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                                                ReferenceNumber = parts.Length > 0 ? parts[0].Trim() : string.Empty;
                                                ReserveField1 = parts.Length > 1 ? string.Join(" ", parts.Skip(1)) : string.Empty;

                                                if (ReserveField1 == "CASH WDL")
                                                {
                                                    ReserveField1 = "WITHDRAWAL";
                                                    TxnsSubTypeMain = "Withdrawal";
                                                }
                                                else if (ReserveField1 == "WITHDRAWAL")
                                                {
                                                    ReserveField1 = "WITHDRAWAL";
                                                    TxnsSubTypeMain = "Withdrawal";
                                                }
                                                else if (ReserveField1 == "DEPOSIT")
                                                {
                                                    ReserveField1 = "DEPOSIT";
                                                    TxnsSubTypeMain = "Deposit";
                                                }
                                                else
                                                {
                                                    ErrorCode = ReserveField1;
                                                }

                                                break;
                                            }
                                        }
                                        k = Counter;

                                    }
                                    else if (EJResult.Contains("CARD:;"))
                                    {
                                        CardNumber = string.Empty;
                                        CardNumber = EJResult.Substring(EJResult.IndexOf(":;") + 2).Trim(); // +2 for ":;"

                                        // Remove trailing '?' if present
                                        if (CardNumber.EndsWith("?"))
                                        {
                                            CardNumber = CardNumber.TrimEnd('?');
                                        }
                                    }
                                }
                                if (EJResult.Contains("REC:"))
                                {
                                    int recIndex = EJResult.IndexOf("REC:") + 4;
                                    string afterRec = EJResult.Substring(recIndex).Trim();

                                    int spaceIndex = afterRec.IndexOf(' ');
                                    if (spaceIndex > 0)
                                        ReferenceNumber = afterRec.Substring(0, spaceIndex);
                                    else
                                        ReferenceNumber = afterRec;
                                }
                                if (EJResult.Contains("A/C#"))
                                {
                                    CustAccountNo = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                if ((EJResult.Contains("ACCT NO") || EJResult.Contains("A/C#") || EJResult.Contains("ACCT No")) && CustAccountNo == "")
                                {
                                    CustAccountNo = EJResult.Substring(EJResult.IndexOf(":") + 1).Split('/').Last().Trim();
                                }
                                if (EJResult.Contains("AMOUNT") && EJResult.Contains("ENTERED"))
                                {
                                    string amountStr = EJResult.Substring(EJResult.IndexOf("AMOUNT") + "AMOUNT".Length).Trim();
                                    amountStr = amountStr.Split(' ')[0].Trim();
                                    ReqAmount = Convert.ToDecimal(amountStr);
                                }

                                if (EJResult.Contains("RESP CODE") || EJResult.Contains("RESP NO"))
                                {
                                    ResponseCode = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    AmountIndex = EJResult.IndexOf("RESP NO:", StringComparison.OrdinalIgnoreCase);

                                    if (AmountIndex > 0)
                                    {
                                        TxnsAmount = Convert.ToDecimal(EJResult.Substring(0, AmountIndex).Trim());
                                    }
                                }

                                if (TerminalID.Trim().Length == 0 && EJResult.Contains("ATM"))
                                {
                                    Match match = Regex.Match(EJResult, @"\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}\s+ATM\d+");
                                    if (match.Success)
                                    {
                                        TerminalID = EJResult.Substring(EJResult.LastIndexOf("ATM")).Trim();

                                        if (TerminalID.Length > 0)
                                        {
                                            TempTerminalId = TerminalID;
                                        }
                                    }
                                }

                                if (EJResult.Contains("WITHDRAWAL RS :"))
                                {
                                    TxnsAmount = Convert.ToDecimal(EJResult.Substring(EJResult.IndexOf("RS :") + 4).Trim());
                                    TxnsSubType = "Withdrawal";
                                    TxnsSubTypeMain = "Withdrawal";
                                }
                                else if (EJResult.Contains("WITHDRAWAL"))
                                {
                                    ReferenceNumber = EJResult.Split(' ')[0].Trim();
                                }

                                if (EJResult.Contains("RESP:"))
                                {
                                    ResponseCode = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("TXN-STATUS"))
                                {
                                    ReserveField4 = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("OPCODE"))
                                {
                                    Opcode = EJResult.Substring(EJResult.LastIndexOf(":") + 1).Trim();
                                }
                                if (EJResult.Contains("BALANCE INQ"))
                                {
                                    TxnsPerticulars = "BALANCE ENQUIRY";
                                }
                                if (EJResult.Contains("INVALID PIN"))
                                {
                                    TxnsPerticulars = "Pin Change";
                                }
                                if (EJResult.Contains("MINI STATEMENT"))
                                {
                                    TxnsPerticulars = "Mini Statement";
                                }
                                if (EJResult.Contains("ACCOUNT FUNDS INSUFFICIENT"))
                                {
                                    TxnsPerticulars = "Insufficient Balance";
                                }
                                if (EJResult.Contains("DENOMINATION"))
                                {
                                    Denomination = EJResult.Substring(EJResult.IndexOf(" ")).Trim();
                                }

                                if (EJResult.Contains("DEPOSIT"))
                                { 
                                    TxnsSubType = "Deposit"; 
                                }


                                if (EJResult.Contains("X-"))
                                {
                                    note = EJResult.Substring(EJResult.IndexOf(":") + 1).Split('-').Last().Trim();
                                    Cassette1 = note.Substring(0, 3);
                                    Cassette2 = note.Substring(4, 3);
                                    Cassette3 = note.Substring(8, 3);
                                    Cassette4 = note.Substring(12, 3);
                                }

                                //if (EJResult.StartsWith("REMAINING"))
                                //{
                                //    string[] Rem = EJResult.Split(' ');
                                //    RemainCount = Rem[1] + "," + Rem[2] + "," + Rem[3] + "," + Rem[4];
                                //}

                                if (EJResult.StartsWith("REJECTED"))
                                {
                                    string[] Rem = EJResult.Split(' ');
                                    RejectCount = Rem[1] + "," + Rem[2] + "," + Rem[3] + "," + Rem[4];
                                }

                                if (EJResult.Contains("DENOM_ALL"))
                                {
                                    string[] parts = EJResult.Split(':');
                                    string SplitData = parts[parts.Length - 1].Trim();
                                    ReserveField2 = SplitData.ToString();
                                }

                                if (EJResult.Contains("DENOM_2000"))
                                {
                                    string[] parts = EJResult.Split(':');
                                    string SplitData = parts[parts.Length - 1].Trim();
                                    Cassette1 = SplitData.ToString();
                                }
                                if (EJResult.Contains("DENOM_500"))
                                {
                                    string[] parts = EJResult.Split(':');
                                    string SplitData = parts[parts.Length - 1].Trim();
                                    Cassette2 = SplitData.ToString();
                                }

                                if (EJResult.Contains("DENOM_200"))
                                {
                                    string[] parts = EJResult.Split(':');
                                    string SplitData = parts[parts.Length - 1].Trim();
                                    Cassette3 = SplitData.ToString();
                                }

                                if (EJResult.Contains("DENOM_100"))
                                {
                                    string[] parts = EJResult.Split(':');
                                    string SplitData = parts[parts.Length - 1].Trim();
                                    Cassette4 = SplitData.ToString();
                                }

                                if (EJResult.Contains("NOTES PRESENT"))
                                {
                                    TxnsPerticulars = " NOTES PRESENT";
                                }
                                if (EJResult.Contains("NOTES TAKEN"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES TAKEN";
                                }
                                if ((EJResult.Contains("OTP") && EJResult.Contains("FAILED")) || (EJResult.Contains("INVALID") && EJResult.Contains("ENTERED")))
                                {
                                    string[] error = EJResult.Split(' ');
                                    ErrorCode = error[0] + ' ' + error[1] + ' ' + error[2];

                                    //    string[] error = EJResult.Split(' ');
                                    //    ErrorCode = error[0].ToString();
                                    //    ErrorCode = ErrorCode + ' ' + error[1].ToString();
                                    //    ErrorCode = ErrorCode + ' ' + error[2].ToString();
                                }
                                if (EJResult.Contains("TRANSACTION") && EJResult.Contains("DECLINED"))
                                {
                                    string[] error = EJResult.Split(' ');
                                    ErrorCode = error[0] + ' ' + error[1];
                                }
                                if (EJResult.Contains("REQUESTED") && EJResult.Contains("LIMIT"))
                                {

                                    string[] error = EJResult.Split(' ');
                                    ErrorCode = error[0] + ' ' + error[1] + ' ' + error[2] + ' ' + error[3] + ' ' + error[4];
                                    //ErrorCode = error[0].ToString();
                                    //ErrorCode = ErrorCode + ' ' + error[1].ToString();
                                    //ErrorCode = ErrorCode + ' ' + error[2].ToString();
                                    //ErrorCode = ErrorCode + ' ' + error[3].ToString();
                                    //ErrorCode = ErrorCode + ' ' + error[4].ToString();
                                }

                                if (EJResult.Contains("ERROR DESC"))
                                {

                                    if (EJResult.Contains("ERROR DESC"))
                                    {
                                        int startIndex = EJResult.IndexOf("ERROR DESC") + "ERROR DESC".Length;
                                        string errorPart = EJResult.Substring(startIndex).Trim();
                                        ErrorCode = errorPart.Split(' ')[0];
                                    }
                                    int Counter = 0;

                                    for (int i = k + 1; i <= (k + 5); i++)
                                    {
                                        EJResult = Common.RemoveAdditionalChars(Regex.Replace(TotalCountArray[i].ToString(), "[^ -~]+", string.Empty));
                                        Counter = i;
                                        if ((EJResult.Trim()).Length != 0)
                                        {
                                            ReserveField3 = EJResult.Trim();
                                            break;
                                        }

                                    }
                                    k = Counter;
                                }

                                if (EJResult.Contains("TNX REQUEST, OPCODE: DCD") && EJResult.Contains("TNX REQUEST, OPCODE: DCDB"))
                                {
                                    break;
                                }

                                #endregion Withdrawal & Deposit

                                j = EndIndex;
                            }
                            catch (Exception ex)
                            {
                                j = EndIndex;
                            }
                        }

                        j = EndIndex;
                    }


                    #region StanderedFields


                   
                    bool card = false;
                    bool Terminal = false;
                    bool Acquirer = false;
                    bool Rev1 = false;
                    bool Rev2 = false;
                    bool ATM = false;
                    bool CDM = false;
                    bool POS = false;
                    bool ECOM = false;
                    bool IMPS = false;
                    bool UPI = false;
                    bool MicroATM = false;
                    bool MobileRecharge = false;
                    bool BAL = false;
                    bool MS = false;
                    bool PC = false;
                    bool CB = false;
                    bool RCA1 = false;
                    bool RCA2 = false;
                    bool MC = false;
                    bool VC = false;
                    bool OC = false;
                    bool D = false;
                    bool C = false;

                    #region ValidateField

                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        //string temp = TxnsDate + " " + TxnsTime;
                        //TxnsDateTimeMain = Convert.ToDateTime(temp);
                        string temp = TxnsDate + " " + TxnsTime;
                        // TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);

                        TxnsDateTimeMain = DateTime.ParseExact(temp.ToString(), "MM/dd/yy HH:mm:ss", CultureInfo.InvariantCulture);
                        //TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + TxnsTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);
                    }

                    if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                    {

                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);

                    }

                    if (fileImportRequest.FileName != null)
                    {
                        string afterUnderscore = fileImportRequest.FileName.Substring(fileImportRequest.FileName.LastIndexOf('_') + 1);
                        string datePart = new string(afterUnderscore.Where(char.IsDigit).ToArray());
                        if (datePart.Length == 8)
                        {
                            FileDate = DateTime.ParseExact(datePart, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                        }
                        else
                        {
                            FileDate = DateTime.Now;
                        }
                    }
                    else
                    {
                        FileDate = DateTime.Now;
                    }




                    if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                    {
                        for (int i = 0; i < TxnPostDateTime.Length; i++)
                        {
                            if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                            {
                                TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                            }
                            else
                            {
                                TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), CultureInfo.InvariantCulture);
                            }
                        }
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (int i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.Contains(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                            }
                        }
                    }


                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (int i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (int i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                            {
                                card = true;
                            }
                        }
                    }



                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (int i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                    }
                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (int i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                        for (int i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                            }
                        }
                    }




                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (int i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (int i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == TxnsSubType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == TxnsSubType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (int i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == TxnsSubType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (int i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == TxnsSubType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType)
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (int i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (int i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (int i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == ChannelType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (int i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == ChannelType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (int i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == ChannelType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (int i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == ChannelType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (int i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType)
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (int i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }


                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (int i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (int i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (int i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (int i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (int i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (int i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                            }
                        }

                        for (int i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode)
                            {
                                RCA2 = true;
                            }
                        }
                    }

                    //if (ResponseCode1Array[0].ToString() == "")
                    //    {
                    //    RCA1 = true;
                    //    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() == "")
                    {
                        for (int i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                            }
                        }
                    }

                  

                    if (DebitCode[0].ToString() != "")
                    {
                        for (int i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (int i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                            }
                        }
                    }


                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (int i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (int i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    //if (AcquirerID == string.Empty || AcquirerID == "")
                    //{
                    //    if (Terminal == true && card == true)
                    //    {
                    //        ModeID = (int)TxnsMode.ONUS;
                    //    }
                    //    if (Terminal == true && card == false)
                    //    {
                    //        ModeID = (int)TxnsMode.ACQUIRER;
                    //    }
                    //    if (Terminal == false && card == true)
                    //    {
                    //        ModeID = (int)TxnsMode.ISSUER;
                    //    }
                    //}
                    //else
                    //{
                    //    if (Acquirer == true && card == true)
                    //    {
                    //        ModeID = (int)TxnsMode.ONUS;
                    //    }
                    //    if (Acquirer == true && card == false)
                    //    {
                    //        ModeID = (int)TxnsMode.ACQUIRER;
                    //    }
                    //    if (Acquirer == false && card == true)
                    //    {
                    //        ModeID = (int)TxnsMode.ISSUER;
                    //    }

                    //}

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    //if (ATM)
                    //{
                    //    TxnsSubTypeMain = "Withdrawal";
                    //    ReserveField1 = "Withdrawal";
                    //    ChannelID = (int)TxnsChannelID.ATM;
                    //}

                    //if (CDM)
                    //{
                    //    TxnsSubTypeMain = "Deposit";
                    //    ReserveField1 = "Deposit";
                    //    ChannelID = (int)TxnsChannelID.ATM;
                    //    ModeID = 1;
                    //}

                    if (POS)
                    {
                        ChannelID = (int)TxnsChannelID.POS;
                        TxnsSubTypeMain = "Purchase";
                        ReserveField1 = "Purchase";
                    }

                    if (ECOM)
                    {
                        ChannelID = (int)TxnsChannelID.E_COMMERCE;
                        TxnsSubTypeMain = "Transfer";
                        ReserveField1 = "Transfer";
                    }

                    if (IMPS)
                    {
                        ChannelID = (int)TxnsChannelID.IMPS;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (MicroATM)
                    {
                        ChannelID = (int)TxnsChannelID.MICRO_ATM;
                        TxnsSubTypeMain = "Withdrawal";
                    }

                    if (MobileRecharge)
                    {
                        ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (UPI)
                    {
                        ChannelID = (int)TxnsChannelID.UPI;
                        TxnsSubTypeMain = "Transfer";
                    }
                    if ((RCA1 == true || RCA2 == true) && TxnsPerticulars.Contains("NOTES TAKEN"))
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                        Status = 1;
                    }
                    else
                    { 
                        TxnsStatus = "Unsucessfull";
                        Status = 2;
                    }

                    if (ReserveField4 != "SUCCESS")
                    {
                        TxnsStatus = "Unsucessfull";
                        Status = 2;
                    }

                    //if (RCA1 == true  || RCA1 == true && RCA2 == false)
                    //    {
                    //    ResponseCode = "00";
                    //    TxnsStatus = "Sucessfull";
                    //    }
                    //else
                    //    {
                    //    ResponseCode = ResponseCode1;
                    //    TxnsStatus = "Unsucessfull";
                    //    }

                    if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                        ReserveField1 = "Balance enquiry";
                    }

                    if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                        ReserveField1 = "Mini statement";
                    }

                    if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                        ReserveField1 = "Pin change";
                    }

                    if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                        ReserveField1 = "Cheque book request";
                    }

                    if (TxnsSubTypeMain.Trim().Length == 0)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    } 

                    if (TxnsAmount > 0)
                    {
                        TxnsType = "Financial";
                    }
                    else
                    {
                        TxnsType = "Non-Financial";
                    }
                    //if (BAL || MS || PC || CB)
                    //{
                    //    TxnsType = "Non-Financial";
                    //}
                    //else
                    //{
                    //    TxnsType = "Financial";
                    //}
                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    #endregion InitilizedField


                    #endregion StanderedFields



                    if (CardNumber != "")
                    {
                        //Mode Calculation
                        ModeID = 2;
                        if (BIN_No[0].ToString() != "" && CardNumber != "")
                        {
                            for (int i = 0; i < BIN_No.Length; i++)
                            {
                                if (CardNumber.Contains((BIN_No[i].ToString())))
                                {
                                    ModeID = 1;
                                    break;
                                }
                            }
                        }

                        if (CardNumber != "" && CardNumber.Length == 16)
                        {
                            CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();
                        }

                        ECardNumber = AesEncryption.EncryptString(CardNumber);;
                    }

                    if (CardNumber == "717171XXXXXX7171" || CardNumber == "717171******7171")
                    {

                        if (ResponseCode == "0" && TxnsSubType == "DEPOSIT")
                        {
                            ResponseCode = "00";
                            TxnsStatus = "Sucessfull";
                            Status = 1;
                        }
                        else if (ResponseCode != "0" && TxnsSubType != "DEPOSIT")
                        {
                            TxnsStatus = "Unsucessfull";
                            Status = 2;
                        }

                        TxnsSubTypeMain = "Deposit";
                    }

                    if (TxnsDateTimeMain != null && ReferenceNumber != "")
                    {
                        _DataTable.Rows.Add(ClientID
                         , (int)TxnsChannelID.ATM
                         , ModeID
                         , TerminalID
                         , ReferenceNumber
                         , CardNumber
                         , CardType
                         , CustAccountNo
                         , CustBalance
                         , TxnsDateTimeMain
                         , TxnsAmount
                        , ReqAmount
                        , Convert.ToDecimal(Amount1)
                        , Convert.ToDecimal(Amount2)
                        , TxnsStatus
                        , TxnsType
                        , TxnsSubTypeMain
                        , TxnsEntryType
                        , TxnsPerticulars
                        , DebitCreditType
                        , ResponseCode
                        , AuthCode
                        , CurrencyCode
                        , Opcode
                        , ErrorCode
                        , ReversalFlag
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , null
                        , Cassette1
                        , Cassette2
                        , Cassette3
                        , Cassette4
                        , ReserveField1
                        , ReserveField2
                        , ReserveField3
                        , ReserveField4
                        , ReserveField5
                        , Status
                        , ECardNumber.Trim()
                                        );
                    }



                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }
            }

            if (_DataTable.Rows.Count > 0 || _DataTableSWCounter.Rows.Count > 0 || _DataTableMCCounter.Rows.Count > 0)
            {
                dsFinal.Tables.Add(_DataTable);
                dsFinal.Tables.Add(_DataTableMCCounter);
                dsFinal.Tables.Add(_DataTableSWCounter);
            }

            if (_DataTable.Rows.Count > 0)
            {
                fileImportRequest.InsertCount = _DataTable.Rows.Count;
            }

            //if (_DataTableSWCounter.Rows.Count > 0)
            //{
            //    int InsertSWCount = _DataTableSWCounter.Rows.Count;
            //}
            //if (_DataTableMCCounter.Rows.Count > 0)
            //{
            //    int InsertMCCount = _DataTableMCCounter.Rows.Count;
            //}

            return dsFinal;
        }

        public DataTable SplitterSrilanka( FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTimeConverter objDateTimeConverter = new DateTimeConverter();
            System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");



            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("CustAccountNo", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("RequestAmount", typeof(string));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("Amount2", typeof(decimal));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            _DataTable.Columns.Add("OPCode", typeof(string));
            _DataTable.Columns.Add("ErrorCode", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("NotesPresented1", typeof(string));
            _DataTable.Columns.Add("NotesPresented2", typeof(string));
            _DataTable.Columns.Add("NotesPresented3", typeof(string));
            _DataTable.Columns.Add("NotesPresented4", typeof(string));
            _DataTable.Columns.Add("Denomination1", typeof(string));
            _DataTable.Columns.Add("Denomination2", typeof(string));
            _DataTable.Columns.Add("Denomination3", typeof(string));
            _DataTable.Columns.Add("Denomination4", typeof(string));
            _DataTable.Columns.Add("Dispensed1", typeof(string));
            _DataTable.Columns.Add("Dispensed2", typeof(string));
            _DataTable.Columns.Add("Dispensed3", typeof(string));
            _DataTable.Columns.Add("Dispensed4", typeof(string));
            _DataTable.Columns.Add("Rejected1", typeof(string));
            _DataTable.Columns.Add("Rejected2", typeof(string));
            _DataTable.Columns.Add("Rejected3", typeof(string));
            _DataTable.Columns.Add("Rejected4", typeof(string));
            _DataTable.Columns.Add("Remaining1", typeof(string));
            _DataTable.Columns.Add("Remaining2", typeof(string));
            _DataTable.Columns.Add("Remaining3", typeof(string));
            _DataTable.Columns.Add("Remaining4", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("Status", typeof(int)); 
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0; 


            DataSet ds = new DataSet();

            string LogType = fileImportRequest.ConfigData.Rows[0]["FileName"].ToString();
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = fileImportRequest.ConfigData.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
            fileImportRequest.TotalCount = TotalCountArray.Length;


            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string PreviousReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string CustAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            decimal TxnsAmount = 0;
            decimal ReqAmount = 0;
            string Amount1 = "0";
            string Amount2 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;

            string CurrencyCode = "356";
            string CustBalance = "0";
            string RespLine = string.Empty;

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string line = string.Empty;
            string line1 = string.Empty;
            string ResponseCode = string.Empty;
            string EJResult = string.Empty;
            string ErrorCode = string.Empty;
            string Opcode = string.Empty;
            string ECardNumber = string.Empty;
            string Status = "0";

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            string tempCardNumber = string.Empty;
            string AuthCode = string.Empty;
            int ModeID = 0;
            string dummy = "XXXXXXXXXX";
            string FileExtension = string.Empty;
            //int ChannelID;
            DateTime? TxnsDateTimeMain = null;

            DateTime? FileDate = null;
            try
            {
                string temp = fileImportRequest.FileName.Substring(fileImportRequest.FileName.IndexOf("-") + 1, 8).Trim();
                FileDate = DateTime.ParseExact(ExtractNumber(temp), "yyyyMMdd", CultureInfo.InvariantCulture);
            }
            catch
            {

            }


            try
            {
                FileExtension = Path.GetExtension(fileImportRequest.FileName);
                TerminalID = fileImportRequest.FileName.Substring(0, fileImportRequest.FileName.IndexOf("-")).Trim();                
            }
            catch
            {

            }

            bool card = false;
            bool Terminal = false;
            bool Acquirer = false;
            bool Rev1 = false;
            bool Rev2 = false;
            bool ATM = false;
            bool CDM = false;
            bool POS = false;
            bool ECOM = false;
            bool IMPS = false;
            bool UPI = false;
            bool MicroATM = false;
            bool MobileRecharge = false;
            bool BAL = false;
            bool MS = false;
            bool PC = false;
            bool CB = false;
            bool RCA1 = false;
            bool RCA2 = false;
            //bool MC = false;
            //bool VC = false;
            bool OC = false;
            bool D = false;
            bool C = false;
            int ATRRECEIVEDT = 0;

            string SplitType = ",";
            string[] TerminalCode = fileImportRequest.ConfigData.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BIN_No = fileImportRequest.ConfigData.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] AcquirerIDArray = fileImportRequest.ConfigData.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode1Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode2Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ReversalType = fileImportRequest.ConfigData.Rows[0]["ReversalType"].ToString();
            string[] ATMType = fileImportRequest.ConfigData.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CDMType = fileImportRequest.ConfigData.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] POSType = fileImportRequest.ConfigData.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ECOMType = fileImportRequest.ConfigData.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] IMPType = fileImportRequest.ConfigData.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] UPIType = fileImportRequest.ConfigData.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MicroATMType = fileImportRequest.ConfigData.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MobileRechargeType = fileImportRequest.ConfigData.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BalanceEnquiry = fileImportRequest.ConfigData.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MiniStatement = fileImportRequest.ConfigData.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] PinChange = fileImportRequest.ConfigData.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ChequeBookReq = fileImportRequest.ConfigData.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ResponseType = fileImportRequest.ConfigData.Rows[0]["ResponseType"].ToString();
            string[] ResponseCode1Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ResponseCode2Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] OfflineCode = fileImportRequest.ConfigData.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnPostDateTime = fileImportRequest.ConfigData.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] DebitCode = fileImportRequest.ConfigData.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CreditCode = fileImportRequest.ConfigData.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);



            string[] Notes = new string[4];
            string[] Denominations = new string[5];
            string[] Dispenseds = new string[5];
            string[] Rejecteds = new string[5];
            string[] Remainings = new string[5];
            string[] CASSTYPE = new string[5];

            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;

            string Denomination1 = string.Empty;
            string Denomination2 = string.Empty;
            string Denomination3 = string.Empty;
            string Denomination4 = string.Empty;

            string PRESENTED = string.Empty;
            string THANK = string.Empty;

            bool CassetteFetch = false;

            int i = 0;

            string tempErrorCode = string.Empty;

            for (int j = 0; j <= fileImportRequest.TotalCount; j++)
            {
                try
                {
                    //StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID"); //DBA8
                    //EndIndex = Common.GetIndex(TotalCountArray, j + 1, "------------------------------------");

                    if (ATRRECEIVEDT > 1)
                    {
                        StartIndex = j - 1;
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "TRANSACTION START");
                        ATRRECEIVEDT = 0;
                    }
                    else
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j - 1, "TRANSACTION START");
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "TRANSACTION END");
                    }


                    if (StartIndex != -1 && EndIndex == -1)
                    {
                        EndIndex = StartIndex + 50;
                    }

                    ReqAmount = 0;
                    //TerminalID = string.Empty;
                    AcquirerID = string.Empty;
                    ReferenceNumber = string.Empty;
                    AuthCode = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsDate = string.Empty;
                    TxnsTime = string.Empty;
                    TxnsAmount = 0;
                    Amount1 = "0";
                    Amount2 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;

                    CustBalance = "0";
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    Status = "0";

                    ResponseCode = string.Empty;
                    EJResult = string.Empty;
                    ErrorCode = string.Empty;
                    Opcode = string.Empty;
                    ECardNumber = string.Empty;
                    CardType = string.Empty;
                    TxnsStatus = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    DebitCreditType = string.Empty;


                    Denomination1 = string.Empty;
                    Denomination2 = string.Empty;
                    Denomination3 = string.Empty;
                    Denomination4 = string.Empty;
                    PRESENTED = string.Empty;

                    RespLine = string.Empty;
                    tempCardNumber = string.Empty;
                    THANK = string.Empty;

                    Array.Clear(Notes, 0, Notes.Length);
                    Array.Clear(Dispenseds, 0, Dispenseds.Length);
                    Array.Clear(Denominations, 0, Denominations.Length);
                    Array.Clear(Rejecteds, 0, Rejecteds.Length);
                    Array.Clear(Remainings, 0, Remainings.Length);
                    Array.Clear(CASSTYPE, 0, CASSTYPE.Length);

                    card = false;
                    Terminal = false;
                    Acquirer = false;
                    Rev1 = false;
                    Rev2 = false;
                    ATM = false;
                    CDM = false;
                    POS = false;
                    ECOM = false;
                    IMPS = false;
                    UPI = false;
                    MicroATM = false;
                    MobileRecharge = false;
                    BAL = false;
                    MS = false;
                    PC = false;
                    CB = false;
                    RCA1 = false;
                    RCA2 = false;
                    //MC = false;
                    //VC = false;
                    OC = false;
                    D = false;
                    C = false;

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex + 1; k <= EndIndex - 1; k++)
                        {

                            try
                            {

                                LineNo++;

                                if (TotalCountArray.Length <= k)
                                {
                                    break;
                                }

                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = Common.RemoveAdditionalChars(line);
                                ReserveField5 = ReserveField5 + " \n " + EJResult.Trim();

                                if (EJResult.Contains("DATE") && EJResult.Contains("TIME"))
                                {
                                    TxnsDate = EJResult.Substring(4, EJResult.IndexOf("TIME") - 4).Trim();
                                    TxnsDate = TxnsDate.Replace("-", "/");
                                    TxnsTime = EJResult.Substring(EJResult.IndexOf("TIME") + 4).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("AMOUNT") && EJResult.Contains("ENTERED"))
                                {
                                    ReqAmount = Convert.ToDecimal(ExtractNumber(EJResult.Substring(EJResult.IndexOf("AMOUNT") + 1).Trim()));
                                    ReqAmount= ReqAmount==0? 0 :  ReqAmount /100;
                                }
                                else if (EJResult.Contains("TRAN TYPE :"))
                                {
                                    TxnsSubType = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    if (EJResult.Contains("WITHDRAWAL"))
                                    {
                                        TxnsSubType = "WITHDRAWAL";
                                    }
                                    else if (EJResult.Contains("BALANCE"))
                                    {
                                        TxnsSubType = "BALANCE INQUIRY";
                                    }
                                    else if (EJResult.Contains("DEPOSIT"))
                                    {
                                        TxnsSubType = "DEPOSIT";
                                    }
                                    else if (EJResult.Contains("BILL PAYMENT"))
                                    {
                                        TxnsSubType = "BILL PAYMENT";
                                    } 


                                }
                                else if (EJResult.ToUpper().Contains("AMOUNT :") && EJResult.ToUpper().Contains("LKR"))
                                {
                                    TxnsAmount = Convert.ToDecimal(EJResult.Substring(EJResult.IndexOf(":") + 1).Replace(",", "").Replace("LKR", "").Trim());
                                }
                                else if (EJResult.ToUpper().Contains("CARD NO :"))
                                {
                                    CardNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("AID :"))
                                {
                                    ReserveField2 = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("APP LABEL :"))
                                {
                                    ReserveField1 = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("ACC NO :"))
                                {
                                    CustAccountNo = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("RRN :"))
                                {
                                    ReferenceNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("OPCODE"))
                                {
                                    Opcode = EJResult.Substring(EJResult.IndexOf("=") + 1).Trim();
                                }
                                else if (EJResult.Contains("PRINT RECEIPT - SUCCESS") && ReserveField4.Contains("APPROVED"))
                                {
                                    TxnsSubType = "MINISTATEMENT";
                                }

                                else if (EJResult.Contains("AVAILABLE BALANCE: LKR"))
                                {
                                    CustBalance = Convert.ToDecimal(Regex.Match(EJResult.Substring(EJResult.IndexOf("AVAILABLE BALANCE: LKR") + 23).Trim(), @"\d+(?:\.\d+)").Value).ToString();
                                }
                                else if (EJResult.Contains("THANK YOU FOR BANKING WITH US") && TxnsDate.Length == 0)
                                {
                                    THANK = Regex.Replace(TotalCountArray[k + 1].ToString(), "[^ -~]+", string.Empty);
                                    if (THANK.Contains("CASH TAKEN"))
                                    {
                                        TxnsDate = ExtractNumber(fileImportRequest.FileName.Substring(fileImportRequest.FileName.IndexOf("-") + 1, 8).Trim());
                                        TxnsTime = THANK.Split(' ')[0];
                                        TxnsTime = TxnsTime.Replace(":", "");
                                    }
                                    else 
                                    {
                                        THANK = THANK.Replace("-", "");
                                        TxnsDate = THANK.Split(' ')[0];
                                        TxnsTime = THANK.Split(' ')[1];
                                    }
                                }

                                else if (EJResult.Contains("STACKED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES STACKED";
                                }
                                else if (EJResult.Contains("CASH TAKEN"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " CASH TAKEN";
                                    TxnsStatus = "Sucessfull";
                                    ResponseCode = "00";
                                }
                                else if (EJResult.Contains("NOTES PRESENTED"))
                                {
                                    Notes = EJResult.Substring(EJResult.IndexOf("PRESENTED") + 10).Trim().Split(',');
                                    TxnsPerticulars = TxnsPerticulars + " NOTES PRESENTED";
                                }
                                else if (EJResult.Contains("PRESENTED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES PRESENTED";
                                    PRESENTED = EJResult.Substring(EJResult.IndexOf("PRESENTED :") + 11).Trim();
                                }
                                else if (EJResult.Contains("NOTES TAKEN"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES TAKEN";
                                    TxnsStatus = "Sucessfull";
                                    ResponseCode = "00";
                                }
                                else if (EJResult.Contains("YOUR TRANSACTION IS SUCCESSFUL") && TxnsSubType == "DEPOSIT")
                                {
                                    TxnsPerticulars = "CASH DEPOSIT";
                                    TxnsStatus = "Sucessfull";
                                    ResponseCode = "00";
                                    ModeID = (int)TxnsMode.ONUS;
                                }
                                else if (EJResult.Contains("YOUR TRANSACTION IS SUCCESSFUL") && TxnsSubType == "BILL PAYMENT")
                                { 
                                    TxnsStatus = "Sucessfull";
                                    ResponseCode = "00";
                                    ModeID = (int)TxnsMode.ONUS;
                                }
                                else if (EJResult.Contains("YOUR BALANCES ARE") && TxnsSubType == "BALANCE INQUIRY")
                                {
                                    TxnsStatus = "Sucessfull";
                                    ResponseCode = "00";
                                }
                                else if (EJResult.Contains("NOTES DEPOSITED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES DEPOSITED";
                                }
                                else if (EJResult.Contains("MINISTMT"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "MINI-STATEMENT";
                                }
                                else if (EJResult.Contains("DECLINED OFFLINE-AAC"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "DECLINED OFFLINE-AAC";
                                }
                                else if (EJResult.Contains("DISPENSER FAILURE"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "DISPENSER FAILURE";
                                }
                                else if (EJResult.Contains("SPECIAL PICKUPRS"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "SPECIAL PICKUPRS";
                                }
                                else if (EJResult.Contains("POWER"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "POWER CYCLE";
                                }
                                else if (EJResult.Contains("DENOMINATION"))
                                {
                                    Denominations = EJResult.Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("DENOMINATION"))
                                {
                                    Denominations = EJResult.Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("DENOM"))
                                {
                                    Denominations = EJResult.Replace(": ", "").Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("CASS.TYPE"))
                                {
                                    CASSTYPE = EJResult.Replace(": ", "").Split(' ');

                                    if (CASSTYPE.Length == 5 && Denominations.Length == 5)
                                    {
                                        for (int x = 1; x < CASSTYPE.Length; x++)
                                        {
                                            if (Convert.ToInt32(CASSTYPE[x]) == 0)
                                            {
                                                Notes[x - 1] = "0";
                                            }
                                            else if (Convert.ToInt32(CASSTYPE[x]) > 0)
                                            {
                                                if (PRESENTED.Length > 0 && PRESENTED.Contains(";"))
                                                {
                                                    string[] PR = PRESENTED.Split(";");
                                                    foreach (string Deno in PR)
                                                    {
                                                        if (Deno.Length > 0 && Deno.Substring(Deno.IndexOf(":") - 1, 1).Trim() == CASSTYPE[x].Trim())
                                                        {
                                                            Notes[x - 1] = Deno.Substring(EJResult.IndexOf(",") + 1, 1).Trim();
                                                        }
                                                        else
                                                        {
                                                            Notes[x - 1] = "0";
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    Notes[x - 1] = "0";
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (EJResult.Contains("DISPENSED"))
                                {
                                    Dispenseds = EJResult.Replace(": ", "").Split(' ');

                                    if (Dispenseds.Length != 5)
                                    {
                                        Dispenseds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REMAINING"))
                                {
                                    Remainings = EJResult.Replace(": ", "").Split(' ');

                                    if (Remainings.Length != 5)
                                    {
                                        Remainings = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REJECTED"))
                                {
                                    Rejecteds = EJResult.Replace(": ", "").Split(' ');

                                    if (Rejecteds.Length != 5)
                                    {
                                        Rejecteds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("+PURGE"))
                                {
                                    Rejecteds = EJResult.Replace(": ", "").Split(' ');

                                    if (Rejecteds.Length != 5)
                                    {
                                        Rejecteds = new string[5];
                                    }
                                }

                                //else if (EJResult.Contains("ATR RECEIVED T=0"))
                                //{
                                //    ATRRECEIVEDT++;
                                //    if (ATRRECEIVEDT > 1)
                                //    {
                                //        break;
                                //    }
                                //}

                                else if (EJResult.Contains("USER"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("NO FUNDS AVAILABLE"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ERROR"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("UNABLE TO PROCESS"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("POWER-UP/RESET"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("LIMIT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ENTER LESSER AMOUNT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ENTER AMOUNT MULTIPLE OF"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("INCORRECT PIN"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("SECURITY KEY VOILATION"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("PIN RETRIES EXCEEDED"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("INVALID TRANSACTION"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("DO NOT HONOUR"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("NO FROM ACCOUNT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("(1*"))
                                {
                                    if (ErrorCode.IndexOf(EJResult) == -1)
                                    {
                                        ErrorCode = ErrorCode + " " + EJResult;
                                    }
                                }
                                else if ((EJResult.Contains("M-")) && (EJResult.Contains("*" + ReferenceNumber + "*")))
                                {
                                    if (ErrorCode.IndexOf(EJResult) == -1)
                                    {
                                        ErrorCode = ErrorCode + " " + EJResult;
                                    }
                                }
                                else if ((EJResult.Contains(",M-")))
                                {
                                    string Remark3 = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("HOST TX TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + "HOST TX TIMEOUT";
                                }
                                else if (EJResult.Contains("SWITCH RESP. TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + "SWITCH RESP. TIMEOUT";
                                }
                                else if (EJResult.Contains("DISPENSER FAILURE"))
                                {
                                    ErrorCode = ErrorCode + " " + "DISPENSER FAILURE";
                                }
                                else if (EJResult.Contains("DECLINED OFFLINE"))
                                {
                                    ErrorCode = ErrorCode + " " + "DECLINED OFFLINE";
                                }
                                else if (EJResult.Contains("COMMAND REJECT"))
                                {
                                    ErrorCode = ErrorCode + " " + "COMMAND REJECT";
                                }
                                else if (EJResult.Contains("ISSUER TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + "ISSUER TIMEOUT";
                                }
                                else if (EJResult.Contains("UNCERTAIN DISPENSE"))
                                {
                                    ErrorCode = ErrorCode + " " + "UNCERTAIN DISPENSE";
                                }
                                else if (EJResult.Contains("POWER CYCLE"))
                                {
                                    ErrorCode = ErrorCode + " " + "POWER CYCLE HAPPENED DURING WITHDRAWAL TRANSACTION (CASH TAKEN)";
                                }
                                else if (EJResult.Contains("ERROR"))
                                {
                                    ErrorCode = ErrorCode + " " + "DISPENSE ERROR";
                                }
                                else if (EJResult.Contains("INVALID ISSUERRS"))
                                {
                                    ErrorCode = ErrorCode + " " + "INVALID ISSUERRS";
                                }
                                else if (EJResult.Contains("UNABLE"))
                                {
                                    ErrorCode = ErrorCode + " " + "UNABLE TO PROCESS";
                                }
                                else if (EJResult.Contains("SUPERVISOR MODE ENTRY"))
                                {
                                    k = EndIndex;
                                }


                                j = EndIndex;
                            }
                            catch (Exception exx)
                            {
                                j = EndIndex;
                            }
                        }
                    }
                    #region StanderedFields

                    ReversalFlag = false;
                    TxnsStatus = string.Empty;
                    DebitCreditType = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    CardType = string.Empty;

                    TxnsDateTimeMain = null; 

                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        try
                        {
                            if (FileExtension == ".log")
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + " " + TxnsTime, "MM/dd/yy HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None);
                            }
                            else
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + " " + TxnsTime, TxnDateTime, CultureInfo.InvariantCulture, DateTimeStyles.None);
                            }
                        }
                        catch
                        {

                        }

                    }

                    if (TxnsDateTimeMain == null && Path.GetExtension(fileImportRequest.FileName) == ".jrn")
                    {
                        TxnsDateTimeMain = FileDate;
                    }

                    if (TerminalID.Length > 0 && !CassetteFetch)
                    {
                        DataTable dataTable = Common.GetCassetteInfoByTerminalId(_connectionString, fileImportRequest.ClientCode, TerminalID);

                        if (dataTable != null && dataTable.Rows.Count > 0)
                        {
                            Cassette1 = Convert.ToString(dataTable.Rows[0]["Cassette1"]);
                            Cassette2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                            Cassette3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                            Cassette4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);

                        }

                        dataTable = null;
                        CassetteFetch = true;
                    }


                    if (FileDate == null)
                    {
                        FileDate = TxnsDateTimeMain;
                    }

                    if (CassetteFetch)
                    { 

                        Denomination1 = Cassette1.Length == 0 ? "0" : Cassette1;
                        Denomination2 = Cassette2.Length == 0 ? "0" : Cassette2;
                        Denomination3 = Cassette3.Length == 0 ? "0" : Cassette3;
                        Denomination4 = Cassette4.Length == 0 ? "0" : Cassette4;
                    }
                    else
                    {
                        Denomination1 = "0";
                        Denomination2 = "0";
                        Denomination3 = "0";
                        Denomination4 = "0";
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                                break;
                            }
                        }
                    }


                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                                break;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i] == CardNumber.Substring(0, 6))
                            {
                                card = true;
                                break;
                            }
                            else if (BIN_No[i].Substring(0, 4) == CardNumber.Substring(0, 4))
                            {
                                card = true;
                                break;
                            }
                        }
                    }



                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                                break;
                            }
                        }
                    }
                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                                break;
                            }
                        }
                        for (i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                                break;
                            }
                        }
                    }




                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                    break;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                    break;
                                }
                            }
                        }

                       

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType)
                                {
                                    MicroATM = true;
                                    break;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                    break;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType)
                                {
                                    ATM = true;
                                    break;
                                }
                            }
                        }

                       
                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType)
                                {
                                    MicroATM = true;
                                    break;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                    break;
                                }
                            }
                        }
                    }


                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                                break;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                                break;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                                break;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                                break;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                                break;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                                break;
                            }
                        }

                        for (i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode)
                            {
                                RCA2 = true;
                                break;
                            }
                        }
                    }


                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() == "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                                break;
                            }
                        }
                    }



                    if (DebitCode[0].ToString() != "")
                    {
                        for (i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                                break;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                                break;
                            }
                        }
                    }



                    #endregion ValidateField

                    #region InitilizedField

                    //if (AcquirerID == string.Empty || AcquirerID == "")
                    //{
                    //    if (Terminal == true && card == true)
                    //    {
                    //        ModeID = (int)TxnsMode.ONUS;
                    //    }
                    //    else if (Terminal == true && card == false)
                    //    {
                    //        ModeID = (int)TxnsMode.ACQUIRER;
                    //    }
                    //    else if (Terminal == false && card == true)
                    //    {
                    //        ModeID = (int)TxnsMode.ISSUER;
                    //    }
                    //}
                    //else
                    //{
                    //    if (Acquirer == true && card == true)
                    //    {
                    //        ModeID = (int)TxnsMode.ONUS;
                    //    }
                    //    else if (Acquirer == true && card == false)
                    //    {
                    //        ModeID = (int)TxnsMode.ACQUIRER;
                    //    }
                    //    else if (Acquirer == false && card == true)
                    //    {
                    //        ModeID = (int)TxnsMode.ISSUER;
                    //    }

                    //}


                    if (card == true)
                    {
                        ModeID = (int)TxnsMode.ONUS;
                    }
                    else 
                    {
                        ModeID = (int)TxnsMode.ACQUIRER;
                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    if (RCA1 == true || RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }
                    else
                    {
                        TxnsStatus = "Unsucessfull";
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    else if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                    }
                    else if (POS)
                    {
                        TxnsSubTypeMain = "Purchase";
                    }
                    else if (ECOM)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (IMPS)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (MicroATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    else if (MobileRecharge)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (UPI)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }
                    else if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }
                    else if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }
                    else if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }
                    else if (TxnsSubType == "BILL PAYMENT")
                    {
                        TxnsSubTypeMain = "BILL PAYMENT";
                    }


                    if (BAL || MS || PC || CB)
                    {
                        TxnsType = "Non-Financial";
                    }
                    else
                    {
                        TxnsType = "Financial";
                    }
                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    if (TxnsSubType == "GREEN PIN")
                    {
                        TxnsType = "Non-Financial";
                        TxnsSubTypeMain = "Green Pin";
                    }

                    if (TxnsSubType.Length == 0 && TxnsSubTypeMain.Length == 0 && ReqAmount > 0)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }

                    #endregion InitilizedField 

                    //#endregion StanderedFields

                    if (CardNumber != "")
                    {
                        CardType = Common.GetCardType(CardNumber);
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }

                    if (CardNumber != "")
                    {
                        CardNumber = CardNumber.Replace("*", "X");

                        tempCardNumber = CardNumber;

                        CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);

                        ReserveField5 = ReserveField5.Replace(tempCardNumber, CardNumber);
                    }

                    if (ReserveField5.Length >= 3900)
                    {
                        ReserveField5 = ReserveField5.Substring(0, 3900);
                    }

                    if (TxnsPerticulars.Length >= 100)
                    {
                        TxnsPerticulars = TxnsPerticulars.Substring(0, 99);
                    }

                    if (ErrorCode.Length >= 1590)
                    {
                        ErrorCode = ErrorCode.Substring(0, 1590);
                    }

                    if (TxnsType == "Financial" && TxnsStatus == "Sucessfull")
                    {
                        Status = "1";
                        if (ReqAmount > 0 && TxnsAmount == 0)
                        {
                            TxnsAmount = ReqAmount;
                        }
                    }
                    else if (TxnsType == "Financial" && TxnsStatus == "Unsucessfull")
                    {
                        Status = "2";
                        if (ReqAmount > 0 && TxnsAmount == 0)
                        {
                            TxnsAmount = ReqAmount;
                        }
                    }

                    CustBalance = CustBalance == "" ? "0" : CustBalance;
                    Amount1 = Amount1 == "" ? "0" : Amount1;
                    Amount2 = Amount2 == "" ? "0" : Amount2;

                    ReserveField5 = ReserveField5.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");
 

                    tempErrorCode = ErrorCode;

                    if (TxnsDateTimeMain != null && ReferenceNumber != "")
                    {
                        _DataTable.Rows.Add(
                                        ClientID
                                        , (int)TxnsChannelID.ATM
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , CardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , Convert.ToDecimal(CustBalance)
                                        , TxnsDateTimeMain
                                        , TxnsAmount
                                        , ReqAmount
                                        , Convert.ToDecimal(Amount1)
                                        , Convert.ToDecimal(Amount2)
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubTypeMain
                                        , TxnsEntryType
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , AuthCode
                                        , CurrencyCode
                                        , Opcode
                                        , ErrorCode
                                        , ReversalFlag
                                        , Notes[0]
                                        , Notes[1]
                                        , Notes[2]
                                        , Notes[3]
                                        , Denomination1
                                        , Denomination2
                                        , Denomination3
                                        , Denomination4
                                        , Dispenseds[1]
                                        , Dispenseds[2]
                                        , Dispenseds[3]
                                        , Dispenseds[4]
                                        , Rejecteds[1]
                                        , Rejecteds[2]
                                        , Rejecteds[3]
                                        , Rejecteds[4]
                                        , Remainings[1]
                                        , Remainings[2]
                                        , Remainings[3]
                                        , Remainings[4]
                                        , ReserveField1
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , Status 
                                        , ECardNumber.Trim()
                                        );

                    }

                    if (ATRRECEIVEDT <= 1)
                    {
                        ATRRECEIVEDT = 0;
                    }
                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                fileImportRequest.InsertCount = _DataTable.Rows.Count;
            }
            return _DataTable;
        }

        public string ExtractNumber(string original)
        {
            return new string(original.Where(c => Char.IsDigit(c) || c == '.').ToArray());
        }
    }

}

