﻿using ImportData;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using Utility;

namespace EJ
{   
    public class SplitterESAF
    { 
        private readonly string _connectionString;
        BulkImports bulkimports;
        public SplitterESAF(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }
        static string ConvertStringArrayToString(string[] array)
        {
            // Concatenate all the elements into a StringBuilder.
            StringBuilder builder = new StringBuilder();
            foreach (string value in array)
            {
                builder.Append(value);
                //builder.Append('.');
            }
            return builder.ToString();
        }
        public static int GetIndex(string[] aryLines, int StartIndex, string searchStr)
        {
            int idx = -1;
            try
            {
                if (aryLines != null && aryLines.Length > 0)
                {
                    bool found = false;
                    for (idx = StartIndex; idx < aryLines.Length; idx++)
                    {
                        if (aryLines[idx].Contains(searchStr))
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        idx = -1;
                }
            }
            catch (Exception ex1) { }
            return idx;
        }

        public static string RemoveAdditionalChars(string input)
        {
            input = input.Trim().ToUpper();
            string pattern = "\\s+";
            string replacement = " ";
            System.Text.RegularExpressions.Regex rgx = new System.Text.RegularExpressions.Regex(pattern);
            string result = rgx.Replace(input, replacement);
            return result;
        }

        public static decimal[] EJDenomination(int first, int last, string[] EJdata)
        {
            decimal[] denomArr = new decimal[4];
            decimal Denom1 = 0, Denom2 = 0, Denom3 = 0, Denom4 = 0;


            for (int LineNoD = first; LineNoD <= last; LineNoD++)
            {

                try
                {


                    string result1 = RemoveAdditionalChars(EJdata[LineNoD].ToString());

                    string[] EJRequest = result1.Split(new string[] { " " }, StringSplitOptions.None);

                    result1 = RemoveAdditionalChars(EJdata[LineNoD].ToString());


                    string[] CASSETTE = null;
                    CASSETTE = result1.Split(' ');

                    if (CASSETTE[0].Contains("DENOM"))
                    {
                        Denom1 = Convert.ToDecimal(CASSETTE[2].Trim());
                        Denom2 = Convert.ToDecimal(CASSETTE[3].Trim());
                        Denom3 = Convert.ToDecimal(CASSETTE[4].Trim());
                        Denom4 = Convert.ToDecimal(CASSETTE[5].Trim());

                        denomArr[0] = Denom1;
                        denomArr[1] = Denom2;
                        denomArr[2] = Denom3;
                        denomArr[3] = Denom4;
                        break;
                    }


                }

                catch (Exception ex)
                {

                }

            }


            return denomArr;
        }


        #region add CommentCode 15102022
        public DataSet SplitDataSwapNCR(string path, string FileName, out int InsertCount, out int TotalCount, out string MSGLBL, string UserName)
        {

            #region "Declaration"
            DataSet ds = new DataSet();
            string MSG = string.Empty;
            DataSet _DataSet = new DataSet();
            DataTable _DataTableEod = new DataTable();

            //_DataTableEod.Columns.Add("ClientID", typeof(int));
            _DataTableEod.Columns.Add("TerminalID", typeof(string));
            _DataTableEod.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTableEod.Columns.Add("Cassette", typeof(string));
            _DataTableEod.Columns.Add("Denom", typeof(decimal));
            _DataTableEod.Columns.Add("CassetteType", typeof(string));

            _DataTableEod.Columns.Add("Before_INCasset", typeof(decimal));
            _DataTableEod.Columns.Add("Before_PURGE", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Remaining", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Dispensed", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Total", typeof(decimal));

            _DataTableEod.Columns.Add("After_INCasset", typeof(decimal));
            _DataTableEod.Columns.Add("After_PURGE", typeof(decimal));
            _DataTableEod.Columns.Add("After_Remaining", typeof(decimal));
            _DataTableEod.Columns.Add("After_Dispensed", typeof(decimal));
            _DataTableEod.Columns.Add("After_Total", typeof(decimal));

            _DataTableEod.Columns.Add("Total_Diff", typeof(decimal));
            _DataTableEod.Columns.Add("Remark", typeof(string));
            _DataTableEod.Columns.Add("TrTimeStamp", typeof(DateTime));
            _DataTableEod.Columns.Add("AuthCode", typeof(string));

            //==========================================================================================================================================//


            InsertCount = 0;
            TotalCount = 0;
            string[] arrLines;
            arrLines = File.ReadAllLines(path, Encoding.Default);
            string[] ErrorLines = File.ReadAllLines(path, Encoding.Default);
            int StartIndexx = 0;
            int EndIndexx = 0;
            int mngindex = 0;
            int totallength = arrLines.Length;
            string filename = Path.GetFileName(path);
            string result;
            DateTime TimeStamp = System.DateTime.Now;
            DateTime TimeStamp2 = System.DateTime.Now;
            string TimeStampchk = string.Empty;
            DateTime TimeStamp1 = System.DateTime.Now;
            DateTime TranDate = System.DateTime.Now;
            DateTime TranDate_dmy = System.DateTime.Now;
            DateTime TimeStamp_dmy = System.DateTime.Now;
            string TerminalId = string.Empty;
            string ReferenceNumber = string.Empty;
            string ECardNumber = string.Empty;
            string CardNumber = string.Empty;
            string CardType = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string ResponseCode = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string CurrencyCode = string.Empty;
            string BranchCode = string.Empty;
            string OPCode = string.Empty;
            string ResultCode = string.Empty;
            string ErrorCode = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string FunctionID = string.Empty;
            string NoOfDuplicate = string.Empty;
            string FilePath = string.Empty;
            string FileDate = string.Empty;
            string CreatedBy = string.Empty;
            string ModifiedBy = string.Empty;
            bool inact = false;
            int ErrorLine = 0;
            string Typecheck = string.Empty;
            string VortexNotes = string.Empty;
            string PreviousAuthCode = string.Empty;
            string NCRNotes = string.Empty;
            string Remark = string.Empty;
            string Remark1 = string.Empty;
            string str_TrTimstamp = string.Empty;
            DateTime TimeStamp3 = System.DateTime.Now;
            string AuthCode3 = string.Empty;

            #endregion

            #region EOD Variable
            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            decimal Denom1 = 0;
            decimal Denom2 = 0;
            decimal Denom3 = 0;
            decimal Denom4 = 0;
            string CassetteType1 = string.Empty;
            string CassetteType2 = string.Empty;
            string CassetteType3 = string.Empty;
            string CassetteType4 = string.Empty;
            string TxnDate = string.Empty;
            decimal Before_INCasset1 = 0;
            decimal Before_INCasset2 = 0;
            decimal Before_INCasset3 = 0;
            decimal Before_INCasset4 = 0;
            decimal Before_PURGE1 = 0;
            decimal Before_PURGE2 = 0;
            decimal Before_PURGE3 = 0;
            decimal Before_PURGE4 = 0;
            decimal Before_Remaining1 = 0;
            decimal Before_Remaining2 = 0;
            decimal Before_Remaining3 = 0;
            decimal Before_Remaining4 = 0;
            decimal Before_Dispensed1 = 0;
            decimal Before_Dispensed2 = 0;
            decimal Before_Dispensed3 = 0;
            decimal Before_Dispensed4 = 0;
            decimal Before_Total1 = 0;
            decimal Before_Total2 = 0;
            decimal Before_Total3 = 0;
            decimal Before_Total4 = 0;
            decimal After_INCasset1 = 0;
            decimal After_INCasset2 = 0;
            decimal After_INCasset3 = 0;
            decimal After_INCasset4 = 0;
            decimal After_PURGE1 = 0;
            decimal After_PURGE2 = 0;
            decimal After_PURGE3 = 0;
            decimal After_PURGE4 = 0;
            decimal After_Remaining1 = 0;
            decimal After_Remaining2 = 0;
            decimal After_Remaining3 = 0;
            decimal After_Remaining4 = 0;
            decimal After_Dispensed1 = 0;
            decimal After_Dispensed2 = 0;
            decimal After_Dispensed3 = 0;
            decimal After_Dispensed4 = 0;
            decimal After_Total1 = 0;
            decimal After_Total2 = 0;
            decimal After_Total3 = 0;
            decimal After_Total4 = 0;

            int count = 0;
            int Rejectcount = 0;
            int DISPENSEDcount = 0;
            int TOTAL1count = 0;
            decimal[] denomArr = null;
            bool boolremark = false;
            string authcode = string.Empty;
            #endregion EOD Variable



            #region
            bool BolCassette1 = false;
            bool Boldenom = false;
            bool BolCassetteType1 = false;
            bool BolBefore_INCasset1 = false;
            bool BolBefore_PURGE1 = false;
            bool BolBefore_Remaining1 = false;
            bool BolBefore_Dispensed1 = false;
            bool BolBefore_Total1 = false;
            bool BolAfter_INCasset1 = false;
            bool BolAfter_PURGE1 = false;
            bool BolAfter_Remaining1 = false;
            bool BolAfter_Dispensed1 = false;
            bool BolAfter_Total1 = false;
            #endregion



            TotalCount = arrLines.Length;
            string StartLine = string.Empty;
            if (arrLines.Length > 10)
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(10));
            }
            else
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(arrLines.Length));
            }
            if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
            {
                string result1 = ConvertStringArrayToString(arrLines);
                if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
                {
                    result = result1.Replace("*****START TRANSACTION*****", "|*****START TRANSACTION*****").Replace("CARD NUMBER", "|CARD NUMBER").
                        Replace("AUTH_NR", "|AUTH_NR").Replace("SEQ NUM", "|SEQ NUM").Replace("RSP CODE", "|RSP CODE")
                        .Replace("ACQUIRER_ID", "|ACQUIRER_ID").Replace("AID", "|AID").Replace("AVAIL", "|AVAIL").
                         Replace("LEDGER", "|LEDGER").Replace("WITHDRAWN", "|WITHDRAWN").Replace("a", "|").Replace("READ ERROR", "|READ ERROR").
                         Replace("a", "|").Replace("e1", "").Replace("e2", "").Replace("e3", "").Replace("e4", "").Replace("e5", "").Replace("e6", "")
                        .Replace("e7", "").Replace("e8", "").Replace("e9", "").Replace("e10", "").Replace("e;", "")
                        .Replace("IN CASSETTE", "|IN CASSETTE").Replace("DENOM", "|DENOM").Replace("CASS.TYPE", "|CASS.TYPE").Replace("+PURGE", "|+PURGE")
                        .Replace("OPCODE", "|OPCODE").Replace("NOTES PRESENTED", "|NOTES PRESENTED").Replace("NOTES TAKEN", "|NOTES TAKEN")
                        .Replace("DENOMINATION", "|DENOMINATION").Replace("DISPENSED", "|DISPENSED").Replace("REJECTED", "|REJECTED").Replace("REMAINING", "|REMAINING")
                        .Replace("REMAINING", "|REMAINING").Replace("DISPENSED", "|DISPENSED").Replace("TOTAL", "|TOTAL").Replace("CASSETTE STATUS", "|CASSETTE STATUS")
                        .Replace("LAST CASH COUNTER UPDATE", "|LAST CASH COUNTER UPDATE").Replace("LAST PURGE BIN CLEARED", "|LAST PURGE BIN CLEARED")
                        .Replace("*****END TRANSACTION*****", "|*****END TRANSACTION*****").Replace("DIVERTED NOTES", "|DIVERTED NOTES").
                        Trim();
                    arrLines = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                    arrLines = arrLines.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                }
            }

            TerminalId = Path.GetFileNameWithoutExtension(filename.Split('_').First().Trim().ToString());
            if (TerminalId != "0")
            {
                //bool valresult = ObjVF.GetTerminalID(TerminalId, TerminalId.Length);
                bool valresult = true;
                if (!valresult)
                {
                    //throw new System.ArgumentException("TerminalID data type is not valid.", "original");
                    MSGLBL = "TerminalID data type is not valid and " + "Error is : " + TerminalId;
                    _DataTableEod.Clear();
                    _DataSet.Tables.Add(_DataTableEod);
                    return _DataSet;
                }
            }
            try
            {
                int Line1 = 0;

                if (arrLines != null && arrLines.Length > 0)
                {
                    StartIndexx = -1;
                    EndIndexx = -1;

                    if (GetIndex(arrLines, Line1, "OPERATION:SYSTEM:: ATMID") != -1)
                    {


                        StartIndexx = GetIndex(arrLines, Line1, "OPERATION:SYSTEM:: ATMID");
                        EndIndexx = GetIndex(arrLines, Line1, "LAST COUNTER RESET");

                        Line1 = EndIndexx;



                    }

                    denomArr = EJDenomination(StartIndexx, EndIndexx, arrLines);

                }



                if (arrLines != null && arrLines.Length > 0)
                {
                    StartIndexx = -1;
                    EndIndexx = -1;


                    for (int Line = 0; Line <= arrLines.Length; Line++)
                    {


                        if (GetIndex(arrLines, Line, "MANAGEMENT ENTRY-ADMIN") != -1)
                        {


                            //StartIndexx = GetIndex(arrLines, Line, "TRANSACTION START");
                            //EndIndexx = arrLines.Length;

                            StartIndexx = GetIndex(arrLines, Line, "MANAGEMENT ENTRY-ADMIN") - 500;
                            EndIndexx = arrLines.Length;

                            //EndIndexx = GetIndex(arrLines, StartIndexx, "TRANSACTION START");
                            //EndIndexx = GetIndex(arrLines, Line, "MANAGEMENT EXIT-ADMIN") + 10;

                            Line = EndIndexx;

                        }


                        //else if (GetIndex(arrLines, Line, "BEFORE RESET COUNTERS:") != -1)
                        //{
                        //    StartIndexx = GetIndex(arrLines, Line, "BEFORE RESET COUNTERS:");
                        //    EndIndexx = GetIndex(arrLines, Line, "AFTER LOAD/UPDATE:") + 10;

                        //    Line = EndIndexx;
                        //}


                        ////if (StartIndexx > Line)
                        ////{

                        ////    StartIndexx = GetIndex(arrLines, Line, "BEFORE RESET COUNTERS:");
                        ////    EndIndexx = GetIndex(arrLines, Line, "AFTER RESET COUNTERS:") + 10;

                        ////    Line = EndIndexx;
                        ////}

                        //else if (GetIndex(arrLines, Line, "BEFORE LOAD/UPDATE:") != -1)
                        //{

                        //    StartIndexx = GetIndex(arrLines, Line, "BEFORE LOAD/UPDATE:");
                        //    EndIndexx = GetIndex(arrLines, Line, "AFTER LOAD/UPDATE:") + 10;

                        //    Line = EndIndexx;
                        //}





                        else
                        {
                            StartIndexx = -1;
                            EndIndexx = -1;
                        }

                        //if (GetIndex(arrLines, Line, "CASSETTE   :    C1     C2     C3     C4") != -1)
                        //{
                        //    StartIndexx = GetIndex(arrLines, Line, "BEFORE RESET COUNTERS:");
                        //    EndIndexx = GetIndex(arrLines, Line, "LAST COUNTER RESET DONE AT");
                        //}


                        if (StartIndexx != -1)
                        {


                            for (int LineNoD = StartIndexx - 2; LineNoD <= EndIndexx; LineNoD++)
                            {


                                try
                                {

                                    string strTr_Date, Time;
                                    string result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());



                                    if (result1.Contains("DATE TIME ATM-ID RESP")) //ej file index
                                    {
                                        string[] TerminalSplit = result1.Split(' ');
                                        int endline = LineNoD + 5;

                                        for (LineNoD = LineNoD; LineNoD < endline; LineNoD++)
                                        {
                                            result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());
                                            TerminalSplit = result1.Split(' ');

                                            if (TerminalSplit[0].ToString().ToUpper().Trim().Contains("DATE".Trim().ToUpper()) && TerminalSplit[1].ToString().Trim().ToUpper().Contains("TIME".Trim().ToUpper()) &&
                                                TerminalSplit[2].ToString().Trim().ToUpper().Contains("ATM-ID".Trim().ToUpper()) && TerminalSplit[3].ToString().Trim().ToUpper().Contains("RESP".Trim().ToUpper()))
                                            {
                                                result1 = RemoveAdditionalChars(arrLines[LineNoD + 1].ToString());
                                                TerminalSplit = result1.Split(' ');
                                                strTr_Date = RemoveAdditionalChars(TerminalSplit[0].Trim());
                                                Time = RemoveAdditionalChars(TerminalSplit[1].Trim());

                                                str_TrTimstamp = strTr_Date + " " + Time;
                                                TimeStamp2 = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                            }

                                            result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());

                                            //if (result1.ToUpper().Trim ().Contains("TXN".ToUpper().Trim()))
                                            //{
                                            //    result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());
                                            //    TerminalSplit = result1.Split(' ');
                                            //    authcode = TerminalSplit[2];
                                            //}

                                            TerminalSplit = result1.Split(' ');

                                            if (TerminalSplit[1].ToUpper().Trim().Contains("WITHDRAWAL".ToUpper().Trim()))
                                            {

                                                result1 = RemoveAdditionalChars(arrLines[LineNoD + 1].ToString());
                                                TerminalSplit = result1.Split(' ');
                                                authcode = TerminalSplit[2];

                                                TimeStamp3 = TimeStamp2;
                                                AuthCode3 = authcode;
                                            }


                                        }
                                    }

                                    string[] EJRequest = result1.Split(new string[] { " " }, StringSplitOptions.None);

                                    if (result1.Contains("DATE : ")) //ej file index
                                    {
                                        string[] TerminalSplit = result1.Split(' ');

                                        strTr_Date = RemoveAdditionalChars(TerminalSplit[2].Trim());
                                        Time = RemoveAdditionalChars(TerminalSplit[3].Trim());

                                        str_TrTimstamp = strTr_Date + " " + Time;
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);

                                        TimeStamp3 = TimeStamp2;
                                        AuthCode3 = authcode;

                                    }


                                    result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());


                                    string[] CASSETTE = null;
                                    CASSETTE = result1.Split(' ');


                                    if (result1.Contains("BEFORE RESET COUNTERS:"))
                                    {
                                        Remark = "BEFORE RESET COUNTERS";
                                        boolremark = true;

                                    }


                                    if (result1.Contains("AFTER RESET COUNTERS:"))
                                    {
                                        Remark = "AFTER RESET COUNTERS:";
                                        boolremark = true;
                                    }


                                    if (result1.Contains("BEFORE LOAD/UPDATE:"))
                                    {
                                        Remark = "BEFORE LOAD";
                                        boolremark = true;
                                    }


                                    if (result1.Contains("AFTER LOAD/UPDATE:"))
                                    {
                                        Remark = "AFTER LOAD";
                                        boolremark = true;
                                    }



                                    if (boolremark == true)
                                    {

                                        if (CASSETTE[0].Contains("CASSETTE") && CASSETTE[2].Contains("C1") && count == 0)
                                        {
                                            Cassette1 = CASSETTE[2].Trim().ToString();
                                            Cassette2 = CASSETTE[3].Trim().ToString();
                                            Cassette3 = CASSETTE[4].Trim().ToString();
                                            Cassette4 = CASSETTE[5].Trim().ToString();

                                            BolCassette1 = true;

                                        }

                                        if (CASSETTE[0].Contains("DENOM") && Rejectcount == 0)
                                        {
                                            Denom1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                            Denom2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                            Denom3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                            Denom4 = Convert.ToDecimal(CASSETTE[5].Trim());

                                            Denom1 = denomArr[0];
                                            Denom2 = denomArr[1];
                                            Denom3 = denomArr[2];
                                            Denom4 = denomArr[3];


                                            //if (Denom1 == 0)
                                            //{
                                            //    Denom1 = 100;
                                            //}                                               


                                            //if (Denom4 == 0)
                                            //{
                                            //    Denom4 = 500;
                                            //}


                                            Boldenom = true;
                                        }

                                        if (CASSETTE[0].Contains("CASS.TYPE") && Rejectcount == 0)
                                        {
                                            CassetteType1 = CASSETTE[2].Trim().ToString();
                                            CassetteType2 = CASSETTE[3].Trim().ToString();
                                            CassetteType3 = CASSETTE[4].Trim().ToString();
                                            CassetteType4 = CASSETTE[5].Trim().ToString();

                                            BolCassetteType1 = true;

                                        }
                                        if (CASSETTE[0].Contains("IN") && CASSETTE.Contains("CASSETTE:"))
                                        {
                                            Before_INCasset1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                            Before_INCasset2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                            Before_INCasset3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                            Before_INCasset4 = Convert.ToDecimal(CASSETTE[5].Trim());

                                            BolBefore_INCasset1 = true;
                                        }

                                        if (CASSETTE[0].Contains("+PURGE"))
                                        {
                                            Before_PURGE1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                            Before_PURGE2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                            Before_PURGE3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                            Before_PURGE4 = Convert.ToDecimal(CASSETTE[5].Trim());

                                            BolBefore_PURGE1 = true;

                                        }
                                        if (CASSETTE[0].Contains("=REMAINING"))
                                        {
                                            Before_Remaining1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                            Before_Remaining2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                            Before_Remaining3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                            Before_Remaining4 = Convert.ToDecimal(CASSETTE[5].Trim());

                                            BolBefore_Remaining1 = true;
                                        }
                                        if (CASSETTE[0].Contains("+DISPENSED") && DISPENSEDcount == 0)
                                        {
                                            Before_Dispensed1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                            Before_Dispensed2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                            Before_Dispensed3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                            Before_Dispensed4 = Convert.ToDecimal(CASSETTE[5].Trim());

                                            BolBefore_Dispensed1 = true;
                                        }

                                        if (CASSETTE[0].Contains("=TOTAL") && TOTAL1count == 0)
                                        {
                                            Before_Total1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                            Before_Total2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                            Before_Total3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                            Before_Total4 = Convert.ToDecimal(CASSETTE[5].Trim());

                                            BolBefore_Total1 = true;
                                        }

                                    }

                                    if (str_TrTimstamp != "" && BolCassette1 == true && Boldenom == true && BolCassetteType1 == true &&
                                        BolBefore_INCasset1 == true && BolBefore_PURGE1 == true && BolBefore_Remaining1 == true && BolBefore_Total1 == true && boolremark == true)
                                    {
                                        Guid Trans_CycleID1 = Guid.NewGuid();
                                        _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette1, Denom1, CassetteType1, Before_INCasset1, Before_PURGE1, Before_Remaining1, Before_Dispensed1, Before_Total1, After_INCasset1, After_PURGE1, After_Remaining1, After_Dispensed1, After_Total1, 0, Remark, TimeStamp3, AuthCode3);
                                        _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette2, Denom2, CassetteType2, Before_INCasset2, Before_PURGE2, Before_Remaining2, Before_Dispensed2, Before_Total2, After_INCasset2, After_PURGE2, After_Remaining2, After_Dispensed2, After_Total2, 0, Remark, TimeStamp3, AuthCode3);
                                        _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette3, Denom3, CassetteType3, Before_INCasset3, Before_PURGE3, Before_Remaining3, Before_Dispensed3, Before_Total3, After_INCasset3, After_PURGE3, After_Remaining3, After_Dispensed3, After_Total3, 0, Remark, TimeStamp3, AuthCode3);
                                        _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette4, Denom4, CassetteType4, Before_INCasset4, Before_PURGE4, Before_Remaining4, Before_Dispensed4, Before_Total4, After_INCasset4, After_PURGE4, After_Remaining4, After_Dispensed4, After_Total4, 0, Remark, TimeStamp3, AuthCode3);
                                        InsertCount = InsertCount + 4;

                                        BolCassette1 = false; Boldenom = false; BolCassetteType1 = false; BolBefore_INCasset1 = false; BolBefore_PURGE1 = false;
                                        BolBefore_Remaining1 = false; BolBefore_Total1 = false; boolremark = false;

                                    }


                                }

                                catch (Exception exx)
                                {

                                }

                                //Line++;
                            }



                        }


                    }
                }
            }


            catch (Exception ex)
            {
                //InsertCount = 0;
                //objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessEJ_CashtallyLogSpliter", "ProcessEJ_CashtallyLogSpliter", LineNo, FileName, UserName, 'E');
            }


            _DataSet.Tables.Add(_DataTableEod);


            MSGLBL = string.Empty;
            return _DataSet;
        }
        #endregion add CommentCode 15102022

        #region Asad CommentCode 1510202
        public DataSet SplitDataSwapNCR3(string path, string FileName, out int InsertCount, out int TotalCount, out string MSGLBL, string UserName)
        {


            #region "Declaration"
            DataSet ds = new DataSet();
            string MSG = string.Empty;
            DataSet _DataSet = new DataSet();
            DataTable _DataTableEod = new DataTable();

            //_DataTableEod.Columns.Add("ClientID", typeof(int));
            _DataTableEod.Columns.Add("TerminalID", typeof(string));
            _DataTableEod.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTableEod.Columns.Add("Cassette", typeof(string));
            _DataTableEod.Columns.Add("Denom", typeof(decimal));
            _DataTableEod.Columns.Add("CassetteType", typeof(string));

            _DataTableEod.Columns.Add("Before_INCasset", typeof(decimal));
            _DataTableEod.Columns.Add("Before_PURGE", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Remaining", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Dispensed", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Total", typeof(decimal));

            _DataTableEod.Columns.Add("After_INCasset", typeof(decimal));
            _DataTableEod.Columns.Add("After_PURGE", typeof(decimal));
            _DataTableEod.Columns.Add("After_Remaining", typeof(decimal));
            _DataTableEod.Columns.Add("After_Dispensed", typeof(decimal));
            _DataTableEod.Columns.Add("After_Total", typeof(decimal));

            _DataTableEod.Columns.Add("Total_Diff", typeof(decimal));
            _DataTableEod.Columns.Add("Remark", typeof(string));
            _DataTableEod.Columns.Add("TrTimeStamp", typeof(DateTime));
            _DataTableEod.Columns.Add("AuthCode", typeof(string));
            //==============================================================================================================================================

            DataTable _DataTableEod1 = new DataTable();
            _DataTableEod1.Columns.Add("TerminalID", typeof(string));
            _DataTableEod1.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTableEod1.Columns.Add("Cassette", typeof(string));
            _DataTableEod1.Columns.Add("Denom", typeof(decimal));
            _DataTableEod1.Columns.Add("CassetteType", typeof(string));

            _DataTableEod1.Columns.Add("Before_INCasset", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_PURGE", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_Remaining", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_Dispensed", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_Total", typeof(decimal));

            _DataTableEod1.Columns.Add("After_INCasset", typeof(decimal));
            _DataTableEod1.Columns.Add("After_PURGE", typeof(decimal));
            _DataTableEod1.Columns.Add("After_Remaining", typeof(decimal));
            _DataTableEod1.Columns.Add("After_Dispensed", typeof(decimal));
            _DataTableEod1.Columns.Add("After_Total", typeof(decimal));

            _DataTableEod1.Columns.Add("Total_Diff", typeof(decimal));
            _DataTableEod1.Columns.Add("Remark", typeof(string));
            _DataTableEod1.Columns.Add("TrTimeStamp", typeof(DateTime));
            _DataTableEod1.Columns.Add("AuthCode", typeof(string));


            InsertCount = 0;
            TotalCount = 0;
            string[] arrLines;
            arrLines = File.ReadAllLines(path, Encoding.Default);
            string[] ErrorLines = File.ReadAllLines(path, Encoding.Default);
            int StartIndexx = 0;
            int EndIndexx = 0;
            int mngindex = 0;
            int totallength = arrLines.Length;
            string filename = Path.GetFileName(path);
            string result;
            DateTime? TimeStamp = null;
            string TimeStampchk = string.Empty;
            DateTime TimeStamp1 = System.DateTime.Now;
            DateTime TranDate = System.DateTime.Now;
            DateTime TranDate_dmy = System.DateTime.Now;
            DateTime TimeStamp_dmy = System.DateTime.Now;
            string TerminalId = string.Empty;
            string ReferenceNumber = string.Empty;
            string ECardNumber = string.Empty;
            string CardNumber = string.Empty;
            string CardType = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string ResponseCode = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string CurrencyCode = string.Empty;
            string BranchCode = string.Empty;
            string OPCode = string.Empty;
            string ResultCode = string.Empty;
            string ErrorCode = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string FunctionID = string.Empty;
            string NoOfDuplicate = string.Empty;
            string FilePath = string.Empty;
            string FileDate = string.Empty;
            string CreatedBy = string.Empty;
            string ModifiedBy = string.Empty;
            bool inact = false;
            int ErrorLine = 0;
            string Typecheck = string.Empty;
            string VortexNotes = string.Empty;
            string PreviousAuthCode = string.Empty;
            string NCRNotes = string.Empty;
            string Remark = string.Empty;
            string str_TrTimstamp = string.Empty;
            DateTime TimeStamp2 = System.DateTime.Now;
            DateTime TimeStamp3 = System.DateTime.Now;
            string AuthCode3 = string.Empty;
            string authcode = string.Empty;
            #endregion

            #region EOD Variable
            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            decimal Denom1 = 0;
            decimal Denom2 = 0;
            decimal Denom3 = 0;
            decimal Denom4 = 0;
            string CassetteType1 = string.Empty;
            string CassetteType2 = string.Empty;
            string CassetteType3 = string.Empty;
            string CassetteType4 = string.Empty;
            string TxnDate = string.Empty;
            decimal Before_INCasset1 = 0;
            decimal Before_INCasset2 = 0;
            decimal Before_INCasset3 = 0;
            decimal Before_INCasset4 = 0;
            decimal Before_PURGE1 = 0;
            decimal Before_PURGE2 = 0;
            decimal Before_PURGE3 = 0;
            decimal Before_PURGE4 = 0;
            decimal Before_Remaining1 = 0;
            decimal Before_Remaining2 = 0;
            decimal Before_Remaining3 = 0;
            decimal Before_Remaining4 = 0;
            decimal Before_Dispensed1 = 0;
            decimal Before_Dispensed2 = 0;
            decimal Before_Dispensed3 = 0;
            decimal Before_Dispensed4 = 0;
            decimal Before_Total1 = 0;
            decimal Before_Total2 = 0;
            decimal Before_Total3 = 0;
            decimal Before_Total4 = 0;
            decimal After_INCasset1 = 0;
            decimal After_INCasset2 = 0;
            decimal After_INCasset3 = 0;
            decimal After_INCasset4 = 0;
            decimal After_PURGE1 = 0;
            decimal After_PURGE2 = 0;
            decimal After_PURGE3 = 0;
            decimal After_PURGE4 = 0;
            decimal After_Remaining1 = 0;
            decimal After_Remaining2 = 0;
            decimal After_Remaining3 = 0;
            decimal After_Remaining4 = 0;
            decimal After_Dispensed1 = 0;
            decimal After_Dispensed2 = 0;
            decimal After_Dispensed3 = 0;
            decimal After_Dispensed4 = 0;
            decimal After_Total1 = 0;
            decimal After_Total2 = 0;
            decimal After_Total3 = 0;
            decimal After_Total4 = 0;

            int rowsCount = 0;
            int count = 0;
            int Rejectcount = 0;
            int DISPENSEDcount = 0;
            int TOTAL1count = 0;
            #endregion EOD Variable


            #region
            bool BolCassette1 = false;
            bool Boldenom = false;
            bool BolCassetteType1 = false;
            bool BolBefore_INCasset1 = false;
            bool BolBefore_PURGE1 = false;
            bool BolBefore_Remaining1 = false;
            bool BolBefore_Dispensed1 = false;
            bool BolBefore_Total1 = false;
            bool BolAfter_INCasset1 = false;
            bool BolAfter_PURGE1 = false;
            bool BolAfter_Remaining1 = false;
            bool BolAfter_Dispensed1 = false;
            bool BolAfter_Total1 = false;
            string[] arrlist;
            bool BeforeResetcounter = false;
            bool AfterResetcounter = false;
            bool AfterLoad = false;
            #endregion



            TotalCount = arrLines.Length;
            string StartLine = string.Empty;
            if (arrLines.Length > 10)
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(10));
            }
            else
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(arrLines.Length));
            }
            if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
            {
                string result1 = ConvertStringArrayToString(arrLines);
                if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
                {
                    result = result1.Replace("*****START TRANSACTION*****", "|*****START TRANSACTION*****").Replace("CARD NUMBER", "|CARD NUMBER").
                        Replace("AUTH_NR", "|AUTH_NR").Replace("SEQ NUM", "|SEQ NUM").Replace("RSP CODE", "|RSP CODE")
                        .Replace("ACQUIRER_ID", "|ACQUIRER_ID").Replace("AID", "|AID").Replace("AVAIL", "|AVAIL").
                         Replace("LEDGER", "|LEDGER").Replace("WITHDRAWN", "|WITHDRAWN").Replace("a", "|").Replace("READ ERROR", "|READ ERROR").
                         Replace("a", "|").Replace("e1", "").Replace("e2", "").Replace("e3", "").Replace("e4", "").Replace("e5", "").Replace("e6", "")
                        .Replace("e7", "").Replace("e8", "").Replace("e9", "").Replace("e10", "").Replace("e;", "")
                        .Replace("IN CASSETTE", "|IN CASSETTE").Replace("DENOM", "|DENOM").Replace("CASS.TYPE", "|CASS.TYPE").Replace("+PURGE", "|+PURGE")
                        .Replace("OPCODE", "|OPCODE").Replace("NOTES PRESENTED", "|NOTES PRESENTED").Replace("NOTES TAKEN", "|NOTES TAKEN")
                        .Replace("DENOMINATION", "|DENOMINATION").Replace("DISPENSED", "|DISPENSED").Replace("REJECTED", "|REJECTED").Replace("REMAINING", "|REMAINING")
                        .Replace("REMAINING", "|REMAINING").Replace("DISPENSED", "|DISPENSED").Replace("TOTAL", "|TOTAL").Replace("CASSETTE STATUS", "|CASSETTE STATUS")
                        .Replace("LAST CASH COUNTER UPDATE", "|LAST CASH COUNTER UPDATE").Replace("LAST PURGE BIN CLEARED", "|LAST PURGE BIN CLEARED")
                        .Replace("*****END TRANSACTION*****", "|*****END TRANSACTION*****").Replace("DIVERTED NOTES", "|DIVERTED NOTES").
                        Trim();
                    arrLines = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                    arrLines = arrLines.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                }
            }

            TerminalId = Path.GetFileNameWithoutExtension(filename.Split('_').First().Trim().ToString());
            if (TerminalId != "0")
            {
                //bool valresult = ObjVF.GetTerminalID(TerminalId, TerminalId.Length);
                bool valresult = true;
                if (!valresult)
                {
                    //throw new System.ArgumentException("TerminalID data type is not valid.", "original");
                    MSGLBL = "TerminalID data type is not valid and " + "Error is : " + TerminalId;
                    _DataTableEod.Clear();
                    _DataSet.Tables.Add(_DataTableEod);
                    return _DataSet;
                }
            }
            try
            {
                if (arrLines != null && arrLines.Length > 0)
                {
                    StartIndexx = -1;
                    EndIndexx = -1;

                    for (int Line = 0; Line <= arrLines.Length; Line++)
                    {

                        if (GetIndex(arrLines, Line, "SUPERVISOR MODE ENTRY") != -1)
                        {



                            StartIndexx = GetIndex(arrLines, Line, "SUPERVISOR MODE ENTRY") - 500;
                            //EndIndexx = GetIndex(arrLines, StartIndexx, "SUPERVISOR MODE EXIT");
                            EndIndexx = arrLines.Length;
                            //StartIndexx = GetIndex(arrLines, Line, "TRANSACTION START");
                            //EndIndexx = arrLines.Length;
                            Line = EndIndexx;


                            //if (EndIndexx == -1)
                            //{
                            //    Line = StartIndexx;
                            //}

                            //else
                            //{
                            //    Line = EndIndexx;
                            //}
                        }

                        //else
                        //{
                        //    StartIndexx = -1;
                        //    EndIndexx = -1;
                        //}

                        //if (GetIndex(arrLines, Line, "CASSETTE   :    C1     C2     C3     C4") != -1)
                        //{
                        //    StartIndexx = GetIndex(arrLines, Line, "BEFORE RESET COUNTERS:");
                        //    EndIndexx = GetIndex(arrLines, Line, "LAST COUNTER RESET DONE AT");
                        //}


                        if (StartIndexx != -1 && EndIndexx != -1)
                        {


                            for (int LineNoD = StartIndexx - 2; LineNoD <= EndIndexx; LineNoD++)
                            {

                                try
                                {

                                    string strTr_Date, Time;
                                    string result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());

                                    string[] EJRequest = result1.Split(new string[] { " " }, StringSplitOptions.None);


                                    if (result1.Contains("DATE TIME ATM-ID RESP")) //ej file index
                                    {



                                        string[] TerminalSplit = result1.Split(' ');
                                        int endline = LineNoD + 5;

                                        for (LineNoD = LineNoD; LineNoD < endline; LineNoD++)
                                        {

                                            result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());
                                            TerminalSplit = result1.Split(' ');

                                            if (TerminalSplit[0].ToString().ToUpper().Trim().Contains("DATE".Trim().ToUpper()) && TerminalSplit[1].ToString().Trim().ToUpper().Contains("TIME".Trim().ToUpper()) &&
                                                TerminalSplit[2].ToString().Trim().ToUpper().Contains("ATM-ID".Trim().ToUpper()) && TerminalSplit[3].ToString().Trim().ToUpper().Contains("RESP".Trim().ToUpper()))
                                            {
                                                result1 = RemoveAdditionalChars(arrLines[LineNoD + 1].ToString());
                                                TerminalSplit = result1.Split(' ');
                                                strTr_Date = RemoveAdditionalChars(TerminalSplit[0].Trim());
                                                Time = RemoveAdditionalChars(TerminalSplit[1].Trim());

                                                str_TrTimstamp = strTr_Date + " " + Time;
                                                TimeStamp2 = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                            }

                                            result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());

                                            TerminalSplit = result1.Split(' ');

                                            if (TerminalSplit[1].ToUpper().Trim().Contains("WITHDRAWAL".ToUpper().Trim()))
                                            {

                                                result1 = RemoveAdditionalChars(arrLines[LineNoD + 1].ToString());
                                                TerminalSplit = result1.Split(' ');
                                                authcode = TerminalSplit[2];

                                                TimeStamp3 = TimeStamp2;
                                                AuthCode3 = authcode;
                                            }


                                        }
                                    }


                                    if (result1.Contains("DATE-TIME")) //ej file index
                                    {
                                        string[] TerminalSplit = result1.Split(' ');

                                        strTr_Date = RemoveAdditionalChars(TerminalSplit[1].Trim());
                                        strTr_Date = strTr_Date.Substring(1, 8);

                                        Time = RemoveAdditionalChars(TerminalSplit[2].Trim());

                                        Time = Time.Substring(0, 5);

                                        str_TrTimstamp = strTr_Date + " " + Time;
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, new[] { "MM/dd/yy HH:mm", "MM/dd/yy hh:mm", "dd/MM/yy HH:mm:ss", "dd/MM/yy HH:mm" }, CultureInfo.InvariantCulture.DateTimeFormat, DateTimeStyles.None);

                                        TimeStamp3 = TimeStamp3;
                                        AuthCode3 = AuthCode3;

                                    }


                                    result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());


                                    string[] CASSETTE = null;
                                    CASSETTE = result1.Split(' ');




                                    if (TimeStamp != null && str_TrTimstamp != "" && str_TrTimstamp != null)
                                    {

                                        if (CASSETTE[0].ToString() == "")
                                        {

                                        }

                                        else
                                        {
                                            if (CASSETTE[1].Contains("TYPE") || CASSETTE[2].Contains("TYPE"))
                                            {

                                                if (CASSETTE[1].Contains("TYPE") && CASSETTE[2].Contains("1") && CASSETTE[3].Contains("TYPE") && CASSETTE[4].Contains("2"))
                                                {
                                                    Cassette1 = CASSETTE[1].Trim().ToString() + CASSETTE[2].Trim().ToString();
                                                    Cassette2 = CASSETTE[3].Trim().ToString() + CASSETTE[4].Trim().ToString();
                                                    //BolCassette1 = true;
                                                }

                                                if (CASSETTE[0].Contains("TYPE") && CASSETTE[1].Contains("3") && CASSETTE[2].Contains("TYPE") && CASSETTE[3].Contains("4"))
                                                {
                                                    Cassette3 = CASSETTE[0].Trim().ToString() + CASSETTE[1].Trim().ToString();
                                                    Cassette4 = CASSETTE[2].Trim().ToString() + CASSETTE[3].Trim().ToString();

                                                    BolCassette1 = true;
                                                }
                                            }
                                        }


                                        if (CASSETTE[0].Contains("=REMAINING"))
                                        {

                                            if (Cassette1 == "TYPE1" && Cassette3 != "TYPE3")
                                            {
                                                Before_Remaining1 = Convert.ToDecimal(CASSETTE[1].Trim());
                                            }

                                            if (Cassette2 == "TYPE2" && Cassette4 != "TYPE4")
                                            {
                                                Before_Remaining2 = Convert.ToDecimal(CASSETTE[2].Trim());
                                            }


                                            if (Cassette3 == "TYPE3")
                                            {
                                                Before_Remaining3 = Convert.ToDecimal(CASSETTE[1].Trim());
                                            }

                                            if (Cassette4 == "TYPE4")
                                            {
                                                Before_Remaining4 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                BolBefore_Remaining1 = true;
                                            }


                                        }

                                        if (CASSETTE[0].Contains("+DISPENSED") && DISPENSEDcount == 0)
                                        {


                                            if (Cassette1 == "TYPE1" && Cassette3 != "TYPE3")
                                            {
                                                Before_Dispensed1 = Convert.ToDecimal(CASSETTE[1].Trim());
                                            }

                                            if (Cassette2 == "TYPE2" && Cassette4 != "TYPE4")
                                            {
                                                Before_Dispensed2 = Convert.ToDecimal(CASSETTE[2].Trim());
                                            }


                                            if (Cassette3 == "TYPE3")
                                            {
                                                Before_Dispensed3 = Convert.ToDecimal(CASSETTE[1].Trim());
                                            }

                                            if (Cassette4 == "TYPE4")
                                            {
                                                Before_Dispensed4 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                BolBefore_Dispensed1 = true;
                                            }


                                        }

                                        if (CASSETTE[0].Contains("=TOTAL") && TOTAL1count == 0)
                                        {

                                            if (Cassette1 == "TYPE1" && Cassette3 != "TYPE3")
                                            {
                                                Before_Total1 = Convert.ToDecimal(CASSETTE[1].Trim());
                                            }

                                            if (Cassette2 == "TYPE2" && Cassette4 != "TYPE4")
                                            {
                                                Before_Total2 = Convert.ToDecimal(CASSETTE[2].Trim());
                                            }


                                            if (Cassette3 == "TYPE3")
                                            {
                                                Before_Total3 = Convert.ToDecimal(CASSETTE[1].Trim());
                                            }

                                            if (Cassette4 == "TYPE4")
                                            {
                                                Before_Total4 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                BolBefore_Total1 = true;
                                            }


                                        }



                                        if (str_TrTimstamp != "" && BolCassette1 == true && BolBefore_Dispensed1 == true && BolBefore_Remaining1 == true && BolBefore_Total1 == true)
                                        {

                                            if (Cassette1 == "TYPE1" && Cassette2 == "TYPE2")
                                            {

                                                if (Cassette1 == "TYPE1" && Cassette2 == "TYPE2")
                                                {
                                                    Denom1 = 100;
                                                }

                                                if (Cassette2 == "TYPE2")
                                                {
                                                    Denom2 = 200;
                                                }
                                            }

                                            if (Cassette3 == "TYPE3" && Cassette4 == "TYPE4")
                                            {

                                                if (Cassette3 == "TYPE3")
                                                {
                                                    Denom3 = 500;
                                                }

                                                if (Cassette4 == "TYPE4")
                                                {
                                                    Denom4 = 500;
                                                }
                                            }



                                            if (Before_Remaining1 == 0 && Before_Remaining2 == 0 && Before_Remaining3 == 0 && Before_Remaining4 == 0
                                                && Before_Dispensed1 == 0 && Before_Dispensed2 == 0 && Before_Dispensed3 == 0 && Before_Dispensed4 == 0
                                                 && Before_Total1 == 0 && Before_Total2 == 0 && Before_Total3 == 0 && Before_Total4 == 0)
                                            {
                                                Remark = "AFTER RESET COUNTERS";
                                                AfterResetcounter = true;


                                            }


                                            if (Before_Dispensed1 == 0 && Before_Dispensed2 == 0 && Before_Dispensed3 == 0 && Before_Dispensed4 == 0 &&
                                                (Before_Total1 != 0 || Before_Total2 != 0 || Before_Total3 != 0 || Before_Total4 != 0))
                                            {
                                                Remark = "AFTER LOAD";
                                                AfterLoad = true;

                                            }

                                            else
                                            {
                                                Remark = "BEFORE RESET COUNTERS";
                                                BeforeResetcounter = true;


                                            }




                                            Guid Trans_CycleID1 = Guid.NewGuid();
                                            _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette1, Denom1, CassetteType1, Before_INCasset1, Before_PURGE1, Before_Remaining1, Before_Dispensed1, Before_Total1, After_INCasset1, After_PURGE1, After_Remaining1, After_Dispensed1, After_Total1, 0, Remark, TimeStamp3, AuthCode3);
                                            _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette2, Denom2, CassetteType2, Before_INCasset2, Before_PURGE2, Before_Remaining2, Before_Dispensed2, Before_Total2, After_INCasset2, After_PURGE2, After_Remaining2, After_Dispensed2, After_Total2, 0, Remark, TimeStamp3, AuthCode3);
                                            _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette3, Denom3, CassetteType3, Before_INCasset3, Before_PURGE3, Before_Remaining3, Before_Dispensed3, Before_Total3, After_INCasset3, After_PURGE3, After_Remaining3, After_Dispensed3, After_Total3, 0, Remark, TimeStamp3, AuthCode3);
                                            _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette4, Denom4, CassetteType4, Before_INCasset4, Before_PURGE4, Before_Remaining4, Before_Dispensed4, Before_Total4, After_INCasset4, After_PURGE4, After_Remaining4, After_Dispensed4, After_Total4, 0, Remark, TimeStamp3, AuthCode3);
                                            InsertCount = InsertCount + 4;






                                            //if (BeforeResetcounter == true && AfterResetcounter == true && AfterLoad == true)
                                            //{

                                            //    _DataTableEod = _DataTableEod.AsEnumerable().Reverse().Take(12).CopyToDataTable();


                                            //    for (int k = 0; _DataTableEod.Rows.Count > k; k++)
                                            //    {
                                            //        DataRow dataRow = _DataTableEod1.NewRow();
                                            //        dataRow["TerminalID"] = _DataTableEod.Rows[k][0];
                                            //        dataRow["TxnsDateTime"] = _DataTableEod.Rows[k][1];
                                            //        dataRow["Cassette"] = _DataTableEod.Rows[k][2];
                                            //        dataRow["Denom"] = _DataTableEod.Rows[k][3];
                                            //        dataRow["CassetteType"] = _DataTableEod.Rows[k][4];

                                            //        dataRow["Before_INCasset"] = _DataTableEod.Rows[k][5];
                                            //        dataRow["Before_PURGE"] = _DataTableEod.Rows[k][6];
                                            //        dataRow["Before_Remaining"] = _DataTableEod.Rows[k][7];
                                            //        dataRow["Before_Dispensed"] = _DataTableEod.Rows[k][8];
                                            //        dataRow["Before_Total"] = _DataTableEod.Rows[k][9];

                                            //        dataRow["After_INCasset"] = _DataTableEod.Rows[k][10];
                                            //        dataRow["After_PURGE"] = _DataTableEod.Rows[k][11];
                                            //        dataRow["After_Dispensed"] = _DataTableEod.Rows[k][12];
                                            //        dataRow["After_Remaining"] = _DataTableEod.Rows[k][13];
                                            //        dataRow["After_Total"] = _DataTableEod.Rows[k][14];

                                            //        dataRow["Total_Diff"] = _DataTableEod.Rows[k][15];
                                            //        dataRow["Remark"] = _DataTableEod.Rows[k][16];

                                            //        dataRow["TrTimeStamp"] = _DataTableEod.Rows[k][17];
                                            //        dataRow["AuthCode"] = _DataTableEod.Rows[k][18];


                                            //        _DataTableEod1.Rows.Add(dataRow);

                                            //    }

                                            //}


                                            //else if (BeforeResetcounter == true && AfterLoad == true)
                                            //{

                                            //    _DataTableEod = _DataTableEod.AsEnumerable().Reverse().Take(8).CopyToDataTable();


                                            //    for (int k = 0; _DataTableEod.Rows.Count > k; k++)
                                            //    {
                                            //        DataRow dataRow = _DataTableEod1.NewRow();
                                            //        dataRow["TerminalID"] = _DataTableEod.Rows[k][0];
                                            //        dataRow["TxnsDateTime"] = _DataTableEod.Rows[k][1];
                                            //        dataRow["Cassette"] = _DataTableEod.Rows[k][2];
                                            //        dataRow["Denom"] = _DataTableEod.Rows[k][3];
                                            //        dataRow["CassetteType"] = _DataTableEod.Rows[k][4];

                                            //        dataRow["Before_INCasset"] = _DataTableEod.Rows[k][5];
                                            //        dataRow["Before_PURGE"] = _DataTableEod.Rows[k][6];
                                            //        dataRow["Before_Remaining"] = _DataTableEod.Rows[k][7];
                                            //        dataRow["Before_Dispensed"] = _DataTableEod.Rows[k][8];
                                            //        dataRow["Before_Total"] = _DataTableEod.Rows[k][9];

                                            //        dataRow["After_INCasset"] = _DataTableEod.Rows[k][10];
                                            //        dataRow["After_PURGE"] = _DataTableEod.Rows[k][11];
                                            //        dataRow["After_Dispensed"] = _DataTableEod.Rows[k][12];
                                            //        dataRow["After_Remaining"] = _DataTableEod.Rows[k][13];
                                            //        dataRow["After_Total"] = _DataTableEod.Rows[k][14];

                                            //        dataRow["Total_Diff"] = _DataTableEod.Rows[k][15];
                                            //        dataRow["Remark"] = _DataTableEod.Rows[k][16];
                                            //        dataRow["TrTimeStamp"] = _DataTableEod.Rows[k][17];
                                            //        dataRow["AuthCode"] = _DataTableEod.Rows[k][18];


                                            //        _DataTableEod1.Rows.Add(dataRow);

                                            //    }

                                            //}






                                            BolCassette1 = false; Boldenom = false; BolCassetteType1 = false; BolBefore_INCasset1 = false; BolBefore_PURGE1 = false;
                                            BolBefore_Remaining1 = false; BolBefore_Total1 = false;

                                            Cassette1 = string.Empty;
                                            Cassette2 = string.Empty;
                                            Cassette3 = string.Empty;
                                            Cassette4 = string.Empty;
                                            Denom1 = 0;
                                            Denom2 = 0;
                                            Denom3 = 0;
                                            Denom4 = 0;
                                            CassetteType1 = string.Empty;
                                            CassetteType2 = string.Empty;
                                            CassetteType3 = string.Empty;
                                            CassetteType4 = string.Empty;
                                            TxnDate = string.Empty;
                                            Before_INCasset1 = 0;
                                            Before_INCasset2 = 0;
                                            Before_INCasset3 = 0;
                                            Before_INCasset4 = 0;
                                            Before_PURGE1 = 0;
                                            Before_PURGE2 = 0;
                                            Before_PURGE3 = 0;
                                            Before_PURGE4 = 0;
                                            Before_Remaining1 = 0;
                                            Before_Remaining2 = 0;
                                            Before_Remaining3 = 0;
                                            Before_Remaining4 = 0;
                                            Before_Dispensed1 = 0;
                                            Before_Dispensed2 = 0;
                                            Before_Dispensed3 = 0;
                                            Before_Dispensed4 = 0;
                                            Before_Total1 = 0;
                                            Before_Total2 = 0;
                                            Before_Total3 = 0;
                                            Before_Total4 = 0;
                                            After_INCasset1 = 0;
                                            After_INCasset2 = 0;
                                            After_INCasset3 = 0;
                                            After_INCasset4 = 0;
                                            After_PURGE1 = 0;
                                            After_PURGE2 = 0;
                                            After_PURGE3 = 0;
                                            After_PURGE4 = 0;
                                            After_Remaining1 = 0;
                                            After_Remaining2 = 0;
                                            After_Remaining3 = 0;
                                            After_Remaining4 = 0;
                                            After_Dispensed1 = 0;
                                            After_Dispensed2 = 0;
                                            After_Dispensed3 = 0;
                                            After_Dispensed4 = 0;
                                            After_Total1 = 0;
                                            After_Total2 = 0;
                                            After_Total3 = 0;
                                            After_Total4 = 0;
                                            str_TrTimstamp = "";
                                            TimeStamp = null;

                                        }
                                    }




                                    //LineNoD++;

                                    //EndIndexx = endline;


                                    // }



                                    //data insert

                                }


                                //  }


                                //}

                                catch (Exception exx)
                                {

                                }

                                //Line++;
                            }



                        }


                    }
                }
            }


            catch (Exception ex)
            {
                //InsertCount = 0;
                //objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessEJ_CashtallyLogSpliter", "ProcessEJ_CashtallyLogSpliter", LineNo, FileName, UserName, 'E');
            }





            try
            {
                // dtEj = _DataTableEod;



                //var result4444 = dtEj
                //  .AsEnumerable()
                //  .Where(myRow => myRow.Field<string>("Remark") == "BEFORE RESET COUNTERS");


                //var results = from DataRow myRow in dtEj.Rows
                //              where (string)myRow["Remark"] == "BEFORE RESET COUNTERS"
                //              select myRow;



                var varBEFORERESET = _DataTableEod.Rows.Cast<DataRow>()
               .FirstOrDefault(x => x.Field<string>("Remark") == "BEFORE RESET COUNTERS");

                var varAFTER_RESET = _DataTableEod.Rows.Cast<DataRow>()
              .FirstOrDefault(x => x.Field<string>("Remark") == "AFTER LOAD");

                string strBEFORERESET = "";
                string strAFTER_RESET = "";


                if (varBEFORERESET == null)
                {
                    strBEFORERESET = "";
                }

                else
                {
                    strBEFORERESET = varBEFORERESET.ItemArray[16].ToString();
                }


                if (varAFTER_RESET == null)
                {
                    strAFTER_RESET = "";
                }

                else
                {
                    strAFTER_RESET = varAFTER_RESET.ItemArray[16].ToString();
                }




                if (strBEFORERESET != "" && strAFTER_RESET == "")
                {
                    AfterEODSplitDataSwapNCR2(path: path, FileName: filename, InsertCount: out InsertCount, TotalCount: out TotalCount, MSGLBL: out MSGLBL, UserName: UserName, _DataTableEod1: _DataTableEod);
                }




                //var results = from myRow in dtEj.AsEnumerable()
                //              where myRow.Field<string>("Remark") == "BEFORE RESET COUNTERS"
                //              select myRow;

                //var query = dtEj.AsEnumerable().
                //    Select(remark1 => new
                //    {
                //        remark = remark1.Field<string>("BEFORE RESET COUNTERS"),

                //    });
            }

            catch (Exception ex)
            {

            }

            _DataSet.Tables.Add(_DataTableEod);


            MSGLBL = string.Empty;
            return _DataSet;
        }
        #endregion Asad CommentCode 15102022



        #region Asad CommentCode 15102022
        //    public DataSet SplitDataSwapNCR(string path, string FileName, out int InsertCount, out int TotalCount, out string MSGLBL, string UserName)
        //    {

        //        #region "Declaration"
        //        DataSet ds = new DataSet();
        //        string MSG = string.Empty;
        //        DataSet _DataSet = new DataSet();
        //        DataTable _DataTableEod = new DataTable();

        //        //_DataTableEod.Columns.Add("ClientID", typeof(int));
        //        _DataTableEod.Columns.Add("TerminalID", typeof(string));
        //        _DataTableEod.Columns.Add("TxnsDateTime", typeof(DateTime));
        //        _DataTableEod.Columns.Add("Cassette", typeof(string));
        //        _DataTableEod.Columns.Add("Denom", typeof(decimal));
        //        _DataTableEod.Columns.Add("CassetteType", typeof(string));

        //        _DataTableEod.Columns.Add("Before_INCasset", typeof(decimal));
        //        _DataTableEod.Columns.Add("Before_PURGE", typeof(decimal));
        //        _DataTableEod.Columns.Add("Before_Remaining", typeof(decimal));
        //        _DataTableEod.Columns.Add("Before_Dispensed", typeof(decimal));
        //        _DataTableEod.Columns.Add("Before_Total", typeof(decimal));

        //        _DataTableEod.Columns.Add("After_INCasset", typeof(decimal));
        //        _DataTableEod.Columns.Add("After_PURGE", typeof(decimal));
        //        _DataTableEod.Columns.Add("After_Remaining", typeof(decimal));
        //        _DataTableEod.Columns.Add("After_Dispensed", typeof(decimal));
        //        _DataTableEod.Columns.Add("After_Total", typeof(decimal));

        //        _DataTableEod.Columns.Add("Total_Diff", typeof(decimal));
        //        _DataTableEod.Columns.Add("Remark", typeof(string));

        ////==========================================================================================================================================//


        //        InsertCount = 0;
        //        TotalCount = 0;
        //        string[] arrLines;
        //        arrLines = File.ReadAllLines(path, Encoding.Default);
        //        string[] ErrorLines = File.ReadAllLines(path, Encoding.Default);
        //        int StartIndexx = 0;
        //        int EndIndexx = 0;
        //        int mngindex = 0;
        //        int totallength = arrLines.Length;
        //        string filename = Path.GetFileName(path);
        //        string result;
        //        DateTime TimeStamp = System.DateTime.Now;
        //        string TimeStampchk = string.Empty;
        //        DateTime TimeStamp1 = System.DateTime.Now;
        //        DateTime TranDate = System.DateTime.Now;
        //        DateTime TranDate_dmy = System.DateTime.Now;
        //        DateTime TimeStamp_dmy = System.DateTime.Now;
        //        string TerminalId = string.Empty;
        //        string ReferenceNumber = string.Empty;
        //        string ECardNumber = string.Empty;
        //        string CardNumber = string.Empty;
        //        string CardType = string.Empty;
        //        string CustAccountNo = string.Empty;
        //        string InterchangeAccountNo = string.Empty;
        //        string ATMAccountNo = string.Empty;
        //        string TxnsType = string.Empty;
        //        string TxnsNumber = string.Empty;
        //        string TxnsPerticulars = string.Empty;
        //        string ResponseCode = string.Empty;
        //        string AuthCode = string.Empty;
        //        string ProcessingCode = string.Empty;
        //        string CurrencyCode = string.Empty;
        //        string BranchCode = string.Empty;
        //        string OPCode = string.Empty;
        //        string ResultCode = string.Empty;
        //        string ErrorCode = string.Empty;
        //        string TCode = string.Empty;
        //        string TCode1 = string.Empty;
        //        string FunctionID = string.Empty;
        //        string NoOfDuplicate = string.Empty;
        //        string FilePath = string.Empty;
        //        string FileDate = string.Empty;
        //        string CreatedBy = string.Empty;
        //        string ModifiedBy = string.Empty;
        //        bool inact = false;
        //        int ErrorLine = 0;
        //        string Typecheck = string.Empty;
        //        string VortexNotes = string.Empty;
        //        string PreviousAuthCode = string.Empty;
        //        string NCRNotes = string.Empty;
        //        string Remark = string.Empty;
        //        string Remark1 = string.Empty;
        //        string str_TrTimstamp = string.Empty;

        //        #endregion

        //        #region EOD Variable
        //        string Cassette1 = string.Empty;
        //        string Cassette2 = string.Empty;
        //        string Cassette3 = string.Empty;
        //        string Cassette4 = string.Empty;
        //        decimal Denom1 = 0;
        //        decimal Denom2 = 0;
        //        decimal Denom3 = 0;
        //        decimal Denom4 = 0;
        //        string CassetteType1 = string.Empty;
        //        string CassetteType2 = string.Empty;
        //        string CassetteType3 = string.Empty;
        //        string CassetteType4 = string.Empty;
        //        string TxnDate = string.Empty;
        //        decimal Before_INCasset1 = 0;
        //        decimal Before_INCasset2 = 0;
        //        decimal Before_INCasset3 = 0;
        //        decimal Before_INCasset4 = 0;
        //        decimal Before_PURGE1 = 0;
        //        decimal Before_PURGE2 = 0;
        //        decimal Before_PURGE3 = 0;
        //        decimal Before_PURGE4 = 0;
        //        decimal Before_Remaining1 = 0;
        //        decimal Before_Remaining2 = 0;
        //        decimal Before_Remaining3 = 0;
        //        decimal Before_Remaining4 = 0;
        //        decimal Before_Dispensed1 = 0;
        //        decimal Before_Dispensed2 = 0;
        //        decimal Before_Dispensed3 = 0;
        //        decimal Before_Dispensed4 = 0;
        //        decimal Before_Total1 = 0;
        //        decimal Before_Total2 = 0;
        //        decimal Before_Total3 = 0;
        //        decimal Before_Total4 = 0;
        //        decimal After_INCasset1 = 0;
        //        decimal After_INCasset2 = 0;
        //        decimal After_INCasset3 = 0;
        //        decimal After_INCasset4 = 0;
        //        decimal After_PURGE1 = 0;
        //        decimal After_PURGE2 = 0;
        //        decimal After_PURGE3 = 0;
        //        decimal After_PURGE4 = 0;
        //        decimal After_Remaining1 = 0;
        //        decimal After_Remaining2 = 0;
        //        decimal After_Remaining3 = 0;
        //        decimal After_Remaining4 = 0;
        //        decimal After_Dispensed1 = 0;
        //        decimal After_Dispensed2 = 0;
        //        decimal After_Dispensed3 = 0;
        //        decimal After_Dispensed4 = 0;
        //        decimal After_Total1 = 0;
        //        decimal After_Total2 = 0;
        //        decimal After_Total3 = 0;
        //        decimal After_Total4 = 0;

        //        int count = 0;
        //        int Rejectcount = 0;
        //        int DISPENSEDcount = 0;
        //        int TOTAL1count = 0;
        //        decimal[] denomArr=null;
        //        bool boolremark = false;
        //        #endregion EOD Variable



        //        #region 
        //         bool BolCassette1 =false;
        //         bool Boldenom =false;
        //         bool BolCassetteType1 =false;
        //         bool BolBefore_INCasset1 =false;
        //         bool BolBefore_PURGE1 =false;
        //         bool BolBefore_Remaining1 =false;
        //         bool BolBefore_Dispensed1 =false;
        //         bool BolBefore_Total1 =false;
        //         bool BolAfter_INCasset1 =false;
        //         bool BolAfter_PURGE1 =false;
        //         bool BolAfter_Remaining1 =false;
        //         bool BolAfter_Dispensed1 =false;
        //         bool BolAfter_Total1 =false;
        //        #endregion



        //        TotalCount = arrLines.Length;
        //        string StartLine = string.Empty;
        //        if (arrLines.Length > 10)
        //        {
        //            StartLine = string.Join("\r\n", File.ReadLines(path).Take(10));
        //        }
        //        else
        //        {
        //            StartLine = string.Join("\r\n", File.ReadLines(path).Take(arrLines.Length));
        //        }
        //        if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
        //        {
        //            string result1 = ConvertStringArrayToString(arrLines);
        //            if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
        //            {
        //                result = result1.Replace("*****START TRANSACTION*****", "|*****START TRANSACTION*****").Replace("CARD NUMBER", "|CARD NUMBER").
        //                    Replace("AUTH_NR", "|AUTH_NR").Replace("SEQ NUM", "|SEQ NUM").Replace("RSP CODE", "|RSP CODE")
        //                    .Replace("ACQUIRER_ID", "|ACQUIRER_ID").Replace("AID", "|AID").Replace("AVAIL", "|AVAIL").
        //                     Replace("LEDGER", "|LEDGER").Replace("WITHDRAWN", "|WITHDRAWN").Replace("a", "|").Replace("READ ERROR", "|READ ERROR").
        //                     Replace("a", "|").Replace("e1", "").Replace("e2", "").Replace("e3", "").Replace("e4", "").Replace("e5", "").Replace("e6", "")
        //                    .Replace("e7", "").Replace("e8", "").Replace("e9", "").Replace("e10", "").Replace("e;", "")
        //                    .Replace("IN CASSETTE", "|IN CASSETTE").Replace("DENOM", "|DENOM").Replace("CASS.TYPE", "|CASS.TYPE").Replace("+PURGE", "|+PURGE")
        //                    .Replace("OPCODE", "|OPCODE").Replace("NOTES PRESENTED", "|NOTES PRESENTED").Replace("NOTES TAKEN", "|NOTES TAKEN")
        //                    .Replace("DENOMINATION", "|DENOMINATION").Replace("DISPENSED", "|DISPENSED").Replace("REJECTED", "|REJECTED").Replace("REMAINING", "|REMAINING")
        //                    .Replace("REMAINING", "|REMAINING").Replace("DISPENSED", "|DISPENSED").Replace("TOTAL", "|TOTAL").Replace("CASSETTE STATUS", "|CASSETTE STATUS")
        //                    .Replace("LAST CASH COUNTER UPDATE", "|LAST CASH COUNTER UPDATE").Replace("LAST PURGE BIN CLEARED", "|LAST PURGE BIN CLEARED")
        //                    .Replace("*****END TRANSACTION*****", "|*****END TRANSACTION*****").Replace("DIVERTED NOTES", "|DIVERTED NOTES").
        //                    Trim();
        //                arrLines = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
        //                arrLines = arrLines.Where(x => !string.IsNullOrEmpty(x)).ToArray();
        //            }
        //        }

        //        TerminalId = Path.GetFileNameWithoutExtension(filename.Split('_').First().Trim().ToString());
        //        if (TerminalId != "0")
        //        {
        //            //bool valresult = ObjVF.GetTerminalID(TerminalId, TerminalId.Length);
        //            bool valresult = true;
        //            if (!valresult)
        //            {
        //                //throw new System.ArgumentException("TerminalID data type is not valid.", "original");
        //                MSGLBL = "TerminalID data type is not valid and " + "Error is : " + TerminalId;
        //                _DataTableEod.Clear();
        //                _DataSet.Tables.Add(_DataTableEod);
        //                return _DataSet;
        //            }
        //        }
        //        try
        //        {
        //            int Line1 = 0;

        //            if (arrLines != null && arrLines.Length > 0)
        //            {
        //                StartIndexx = -1;
        //                EndIndexx = -1;

        //                if (GetIndex(arrLines, Line1, "OPERATION:SYSTEM:: ATMID") != -1)
        //                {


        //                    StartIndexx = GetIndex(arrLines, Line1, "OPERATION:SYSTEM:: ATMID");
        //                    EndIndexx = GetIndex(arrLines, Line1, "LAST COUNTER RESET");

        //                    Line1 = EndIndexx;



        //                }

        //              denomArr=EJDenomination(StartIndexx, EndIndexx, arrLines);

        //            }



        //            if (arrLines != null && arrLines.Length > 0)
        //            {
        //                StartIndexx = -1;
        //                EndIndexx = -1;


        //                for (int Line = 0; Line <= arrLines.Length; Line++)
        //                {


        //                    if (GetIndex(arrLines, Line, "MANAGEMENT ENTRY-ADMIN") != -1)
        //                    {

        //                        StartIndexx = GetIndex(arrLines, Line, "MANAGEMENT ENTRY-ADMIN");
        //                        EndIndexx = arrLines.Length;

        //                        //EndIndexx = GetIndex(arrLines, StartIndexx, "TRANSACTION START");
        //                        //EndIndexx = GetIndex(arrLines, Line, "MANAGEMENT EXIT-ADMIN") + 10;

        //                        Line = EndIndexx;

        //                    }


        //                    //else if (GetIndex(arrLines, Line, "BEFORE RESET COUNTERS:") != -1)
        //                    //{
        //                    //    StartIndexx = GetIndex(arrLines, Line, "BEFORE RESET COUNTERS:");
        //                    //    EndIndexx = GetIndex(arrLines, Line, "AFTER LOAD/UPDATE:") + 10;

        //                    //    Line = EndIndexx;
        //                    //}


        //                    ////if (StartIndexx > Line)
        //                    ////{

        //                    ////    StartIndexx = GetIndex(arrLines, Line, "BEFORE RESET COUNTERS:");
        //                    ////    EndIndexx = GetIndex(arrLines, Line, "AFTER RESET COUNTERS:") + 10;

        //                    ////    Line = EndIndexx;
        //                    ////}

        //                    //else if (GetIndex(arrLines, Line, "BEFORE LOAD/UPDATE:") != -1)
        //                    //{

        //                    //    StartIndexx = GetIndex(arrLines, Line, "BEFORE LOAD/UPDATE:");
        //                    //    EndIndexx = GetIndex(arrLines, Line, "AFTER LOAD/UPDATE:") + 10;

        //                    //    Line = EndIndexx;
        //                    //}





        //                    else
        //                    {
        //                        StartIndexx = -1;
        //                        EndIndexx = -1;
        //                    }

        //                    //if (GetIndex(arrLines, Line, "CASSETTE   :    C1     C2     C3     C4") != -1)
        //                    //{
        //                    //    StartIndexx = GetIndex(arrLines, Line, "BEFORE RESET COUNTERS:");
        //                    //    EndIndexx = GetIndex(arrLines, Line, "LAST COUNTER RESET DONE AT");
        //                    //}


        //                    if (StartIndexx != -1)
        //                    {


        //                        for (int LineNoD = StartIndexx-2; LineNoD <= EndIndexx; LineNoD++)
        //                        {


        //                            try
        //                            {


        //                                string strTr_Date, Time;
        //                                string result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());

        //                                string[] EJRequest = result1.Split(new string[] { " " }, StringSplitOptions.None);

        //                                if (result1.Contains("DATE : ")) //ej file index
        //                                {
        //                                    string[] TerminalSplit = result1.Split(' ');

        //                                    strTr_Date = RemoveAdditionalChars(TerminalSplit[2].Trim());
        //                                    Time = RemoveAdditionalChars(TerminalSplit[3].Trim());

        //                                    str_TrTimstamp = strTr_Date + " " + Time;
        //                                    TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);
        //                                }


        //                                    result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());


        //                                    string[] CASSETTE = null;
        //                                    CASSETTE = result1.Split(' ');


        //                                    if (result1.Contains("BEFORE RESET COUNTERS:"))
        //                                    {
        //                                        Remark = "BEFORE RESET COUNTERS";
        //                                        boolremark = true;

        //                                    }


        //                                    if (result1.Contains("AFTER RESET COUNTERS:"))
        //                                    {
        //                                        Remark = "AFTER RESET COUNTERS:";
        //                                        boolremark = true;
        //                                    }


        //                                    if (result1.Contains("BEFORE LOAD/UPDATE:"))
        //                                    {
        //                                        Remark = "BEFORE LOAD";
        //                                        boolremark = true;
        //                                    }


        //                                    if (result1.Contains("AFTER LOAD/UPDATE:"))
        //                                    {
        //                                        Remark = "AFTER LOAD";
        //                                        boolremark = true;
        //                                    }



        //                                  if(boolremark ==true)
        //                                  {

        //                                    if (CASSETTE[0].Contains("CASSETTE") && CASSETTE[2].Contains("C1") && count == 0)
        //                                    {
        //                                        Cassette1 = CASSETTE[2].Trim().ToString();
        //                                        Cassette2 = CASSETTE[3].Trim().ToString();
        //                                        Cassette3 = CASSETTE[4].Trim().ToString();
        //                                        Cassette4 = CASSETTE[5].Trim().ToString();

        //                                        BolCassette1 =true;

        //                                    }

        //                                    if (CASSETTE[0].Contains("DENOM") && Rejectcount == 0)
        //                                    {
        //                                        Denom1 = Convert.ToDecimal(CASSETTE[2].Trim());
        //                                        Denom2 = Convert.ToDecimal(CASSETTE[3].Trim());
        //                                        Denom3 = Convert.ToDecimal(CASSETTE[4].Trim());
        //                                        Denom4 = Convert.ToDecimal(CASSETTE[5].Trim());

        //                                        Denom1 = denomArr[0];
        //                                        Denom2 = denomArr[1];
        //                                        Denom3 = denomArr[2];
        //                                        Denom4 = denomArr[3];


        //                                            //if (Denom1 == 0)
        //                                            //{
        //                                            //    Denom1 = 100;
        //                                            //}                                               


        //                                            //if (Denom4 == 0)
        //                                            //{
        //                                            //    Denom4 = 500;
        //                                            //}


        //                                          Boldenom =true;
        //                                    }

        //                                    if (CASSETTE[0].Contains("CASS.TYPE") && Rejectcount == 0)
        //                                    {
        //                                        CassetteType1 = CASSETTE[2].Trim().ToString();
        //                                        CassetteType2 = CASSETTE[3].Trim().ToString();
        //                                        CassetteType3 = CASSETTE[4].Trim().ToString();
        //                                        CassetteType4 = CASSETTE[5].Trim().ToString();

        //                                        BolCassetteType1 =true;

        //                                    }
        //                                    if (CASSETTE[0].Contains("IN") && CASSETTE.Contains("CASSETTE:"))
        //                                    {
        //                                        Before_INCasset1 = Convert.ToDecimal(CASSETTE[2].Trim());
        //                                        Before_INCasset2 = Convert.ToDecimal(CASSETTE[3].Trim());
        //                                        Before_INCasset3 = Convert.ToDecimal(CASSETTE[4].Trim());
        //                                        Before_INCasset4 = Convert.ToDecimal(CASSETTE[5].Trim());

        //                                        BolBefore_INCasset1 =true;
        //                                    }

        //                                    if (CASSETTE[0].Contains("+PURGE"))
        //                                    {
        //                                        Before_PURGE1 = Convert.ToDecimal(CASSETTE[2].Trim());
        //                                        Before_PURGE2 = Convert.ToDecimal(CASSETTE[3].Trim());
        //                                        Before_PURGE3 = Convert.ToDecimal(CASSETTE[4].Trim());
        //                                        Before_PURGE4 = Convert.ToDecimal(CASSETTE[5].Trim());

        //                                        BolBefore_PURGE1 =true;

        //                                    }
        //                                    if (CASSETTE[0].Contains("=REMAINING"))
        //                                    {
        //                                        Before_Remaining1 = Convert.ToDecimal(CASSETTE[2].Trim());
        //                                        Before_Remaining2 = Convert.ToDecimal(CASSETTE[3].Trim());
        //                                        Before_Remaining3 = Convert.ToDecimal(CASSETTE[4].Trim());
        //                                        Before_Remaining4 = Convert.ToDecimal(CASSETTE[5].Trim());

        //                                        BolBefore_Remaining1 =true;
        //                                    }
        //                                    if (CASSETTE[0].Contains("+DISPENSED") && DISPENSEDcount == 0)
        //                                    {
        //                                        Before_Dispensed1 = Convert.ToDecimal(CASSETTE[2].Trim());
        //                                        Before_Dispensed2 = Convert.ToDecimal(CASSETTE[3].Trim());
        //                                        Before_Dispensed3 = Convert.ToDecimal(CASSETTE[4].Trim());
        //                                        Before_Dispensed4 = Convert.ToDecimal(CASSETTE[5].Trim());

        //                                        BolBefore_Dispensed1  =true;
        //                                    }

        //                                    if (CASSETTE[0].Contains("=TOTAL") && TOTAL1count == 0)
        //                                    {
        //                                        Before_Total1 = Convert.ToDecimal(CASSETTE[2].Trim());
        //                                        Before_Total2 = Convert.ToDecimal(CASSETTE[3].Trim());
        //                                        Before_Total3 = Convert.ToDecimal(CASSETTE[4].Trim());
        //                                        Before_Total4 = Convert.ToDecimal(CASSETTE[5].Trim());

        //                                        BolBefore_Total1 =true;
        //                                    }

        //                                  }

        //                                    if (str_TrTimstamp != "" && BolCassette1 == true && Boldenom ==true && BolCassetteType1 ==true &&
        //                                        BolBefore_INCasset1 == true && BolBefore_PURGE1 == true && BolBefore_Remaining1 == true && BolBefore_Total1 == true && boolremark ==true)
        //                                    {
        //                                        Guid Trans_CycleID1 = Guid.NewGuid();
        //                                        _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette1, Denom1, CassetteType1, Before_INCasset1, Before_PURGE1, Before_Remaining1, Before_Dispensed1, Before_Total1, After_INCasset1, After_PURGE1, After_Remaining1, After_Dispensed1, After_Total1, 0, Remark);
        //                                        _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette2, Denom2, CassetteType2, Before_INCasset2, Before_PURGE2, Before_Remaining2, Before_Dispensed2, Before_Total2, After_INCasset2, After_PURGE2, After_Remaining2, After_Dispensed2, After_Total2, 0, Remark);
        //                                        _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette3, Denom3, CassetteType3, Before_INCasset3, Before_PURGE3, Before_Remaining3, Before_Dispensed3, Before_Total3, After_INCasset3, After_PURGE3, After_Remaining3, After_Dispensed3, After_Total3, 0, Remark);
        //                                        _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette4, Denom4, CassetteType4, Before_INCasset4, Before_PURGE4, Before_Remaining4, Before_Dispensed4, Before_Total4, After_INCasset4, After_PURGE4, After_Remaining4, After_Dispensed4, After_Total4, 0, Remark);
        //                                        InsertCount = InsertCount + 4;

        //                                        BolCassette1 = false; Boldenom = false; BolCassetteType1 = false; BolBefore_INCasset1 = false; BolBefore_PURGE1 = false;
        //                                        BolBefore_Remaining1 = false; BolBefore_Total1 = false; boolremark = false;

        //                                    }


        //                                  }

        //                            catch (Exception exx)
        //                            {

        //                            }

        //                            //Line++;
        //                        }



        //                      }


        //                    }
        //                } 
        //            }


        //        catch (Exception ex)
        //        {
        //            //InsertCount = 0;
        //            //objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessEJ_CashtallyLogSpliter", "ProcessEJ_CashtallyLogSpliter", LineNo, FileName, UserName, 'E');
        //        }


        //        _DataSet.Tables.Add(_DataTableEod);


        //        MSGLBL = string.Empty;
        //        return _DataSet;
        //    }
        #endregion Asad CommentCode 15102022

        public DataSet SplitDataSwapNCR1(string path, string FileName, out int InsertCount, out int TotalCount, out string MSGLBL, string UserName)
        {

            #region "Declaration"
            DataSet ds = new DataSet();
            string MSG = string.Empty;
            DataSet _DataSet = new DataSet();
            DataTable _DataTableEod = new DataTable();

            //_DataTableEod.Columns.Add("ClientID", typeof(int));
            _DataTableEod.Columns.Add("TerminalID", typeof(string));
            _DataTableEod.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTableEod.Columns.Add("Cassette", typeof(string));
            _DataTableEod.Columns.Add("Denom", typeof(decimal));
            _DataTableEod.Columns.Add("CassetteType", typeof(string));

            _DataTableEod.Columns.Add("Before_INCasset", typeof(decimal));
            _DataTableEod.Columns.Add("Before_PURGE", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Remaining", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Dispensed", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Total", typeof(decimal));

            _DataTableEod.Columns.Add("After_INCasset", typeof(decimal));
            _DataTableEod.Columns.Add("After_PURGE", typeof(decimal));
            _DataTableEod.Columns.Add("After_Remaining", typeof(decimal));
            _DataTableEod.Columns.Add("After_Dispensed", typeof(decimal));
            _DataTableEod.Columns.Add("After_Total", typeof(decimal));

            _DataTableEod.Columns.Add("Total_Diff", typeof(decimal));
            _DataTableEod.Columns.Add("Remark", typeof(string));
            _DataTableEod.Columns.Add("TrTimeStamp", typeof(DateTime));
            _DataTableEod.Columns.Add("AuthCode", typeof(string));


            InsertCount = 0;
            TotalCount = 0;
            string[] arrLines;
            arrLines = File.ReadAllLines(path, Encoding.Default);
            string[] ErrorLines = File.ReadAllLines(path, Encoding.Default);
            int StartIndexx = 0;
            int EndIndexx = 0;
            int mngindex = 0;
            int totallength = arrLines.Length;
            string filename = Path.GetFileName(path);
            string result;
            DateTime TimeStamp = System.DateTime.Now;
            string TimeStampchk = string.Empty;
            DateTime TimeStamp1 = System.DateTime.Now;
            DateTime TranDate = System.DateTime.Now;
            DateTime TranDate_dmy = System.DateTime.Now;
            DateTime TimeStamp_dmy = System.DateTime.Now;
            string TerminalId = string.Empty;
            string ReferenceNumber = string.Empty;
            string ECardNumber = string.Empty;
            string CardNumber = string.Empty;
            string CardType = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string ResponseCode = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string CurrencyCode = string.Empty;
            string BranchCode = string.Empty;
            string OPCode = string.Empty;
            string ResultCode = string.Empty;
            string ErrorCode = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string FunctionID = string.Empty;
            string NoOfDuplicate = string.Empty;
            string FilePath = string.Empty;
            string FileDate = string.Empty;
            string CreatedBy = string.Empty;
            string ModifiedBy = string.Empty;
            bool inact = false;
            int ErrorLine = 0;
            string Typecheck = string.Empty;
            string VortexNotes = string.Empty;
            string PreviousAuthCode = string.Empty;
            string NCRNotes = string.Empty;
            #endregion

            TotalCount = arrLines.Length;
            string StartLine = string.Empty;
            if (arrLines.Length > 10)
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(10));
            }
            else
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(arrLines.Length));
            }
            if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
            {
                string result1 = ConvertStringArrayToString(arrLines);
                if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
                {
                    result = result1.Replace("*****START TRANSACTION*****", "|*****START TRANSACTION*****").Replace("CARD NUMBER", "|CARD NUMBER").
                        Replace("AUTH_NR", "|AUTH_NR").Replace("SEQ NUM", "|SEQ NUM").Replace("RSP CODE", "|RSP CODE")
                        .Replace("ACQUIRER_ID", "|ACQUIRER_ID").Replace("AID", "|AID").Replace("AVAIL", "|AVAIL").
                         Replace("LEDGER", "|LEDGER").Replace("WITHDRAWN", "|WITHDRAWN").Replace("a", "|").Replace("READ ERROR", "|READ ERROR").
                         Replace("a", "|").Replace("e1", "").Replace("e2", "").Replace("e3", "").Replace("e4", "").Replace("e5", "").Replace("e6", "")
                        .Replace("e7", "").Replace("e8", "").Replace("e9", "").Replace("e10", "").Replace("e;", "")
                        .Replace("IN CASSETTE", "|IN CASSETTE").Replace("DENOM", "|DENOM").Replace("CASS.TYPE", "|CASS.TYPE").Replace("+PURGE", "|+PURGE")
                        .Replace("OPCODE", "|OPCODE").Replace("NOTES PRESENTED", "|NOTES PRESENTED").Replace("NOTES TAKEN", "|NOTES TAKEN")
                        .Replace("DENOMINATION", "|DENOMINATION").Replace("DISPENSED", "|DISPENSED").Replace("REJECTED", "|REJECTED").Replace("REMAINING", "|REMAINING")
                        .Replace("REMAINING", "|REMAINING").Replace("DISPENSED", "|DISPENSED").Replace("TOTAL", "|TOTAL").Replace("CASSETTE STATUS", "|CASSETTE STATUS")
                        .Replace("LAST CASH COUNTER UPDATE", "|LAST CASH COUNTER UPDATE").Replace("LAST PURGE BIN CLEARED", "|LAST PURGE BIN CLEARED")
                        .Replace("*****END TRANSACTION*****", "|*****END TRANSACTION*****").Replace("DIVERTED NOTES", "|DIVERTED NOTES").
                        Trim();
                    arrLines = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                    arrLines = arrLines.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                }
            }

            TerminalId = Path.GetFileNameWithoutExtension(filename.Split('_').First().Trim().ToString());
            if (TerminalId != "0")
            {
                //bool valresult = ObjVF.GetTerminalID(TerminalId, TerminalId.Length);
                bool valresult = true;
                if (!valresult)
                {
                    //throw new System.ArgumentException("TerminalID data type is not valid.", "original");
                    MSGLBL = "TerminalID data type is not valid and " + "Error is : " + TerminalId;
                    _DataTableEod.Clear();
                    _DataSet.Tables.Add(_DataTableEod);
                    return _DataSet;
                }
            }
            try
            {
                if (arrLines != null && arrLines.Length > 0)
                {
                    StartIndexx = -1;
                    EndIndexx = -1;

                    for (int Line = 0; Line <= arrLines.Length; Line++)
                    {
                        if (GetIndex(arrLines, Line, "CASSETTE   :    C1     C2     C3     C4") != -1)
                        {
                            StartIndexx = GetIndex(arrLines, Line, "CASSETTE   :    C1     C2     C3     C4");
                            EndIndexx = StartIndexx + 10;
                            Line = EndIndexx;
                        }
                    }
                    if (StartIndexx != -1)
                    {
                        for (int LineNoD = StartIndexx - 16; LineNoD <= EndIndexx; LineNoD++)
                        {
                            try
                            {
                                string str_TrTimstamp;
                                string strTr_Date, Time;
                                string result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());
                                string[] EJRequest = result1.Split(new string[] { " " }, StringSplitOptions.None);
                                if (result1.Contains("ESAF")) //ej file index
                                {
                                    string[] TerminalSplit = result1.Split(' ');
                                    strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
                                    string[] date = strTr_Date.Split('-');
                                    strTr_Date = RemoveAdditionalChars(date[0].Trim());
                                    Time = RemoveAdditionalChars(EJRequest[1].Trim());
                                    if (TerminalSplit[3].Trim() == "61")
                                    {
                                        ResponseCode = "61";
                                    }
                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                        TimeStampchk = TimeStamp.ToString();
                                        ResponseCode = TerminalSplit[3].Trim();
                                    }
                                    catch (Exception ex)
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                                        TimeStampchk = TimeStamp.ToString();
                                        ResponseCode = TerminalSplit[3].Trim();
                                    }
                                }
                                else if (result1.Contains("TRANSACTION START"))
                                {
                                    string[] TerminalSplit = result1.Split(' ');
                                    strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
                                    string[] date = strTr_Date.Split('-');
                                    strTr_Date = RemoveAdditionalChars(date[0].Trim());
                                    Time = RemoveAdditionalChars(EJRequest[1].Trim());

                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);
                                        //ResponseCode = TerminalSplit[3].Trim();
                                        TimeStampchk = TimeStamp.ToString();
                                    }
                                    catch (Exception ex)
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                                        TimeStampchk = TimeStamp.ToString();
                                    }
                                    string[] tmp = FileName.Split('_');
                                }
                            }
                            catch { }
                        }
                    }
                    if (StartIndexx != -1 && EndIndexx != -1)
                    {
                        string Cassette1 = string.Empty;
                        string Cassette2 = string.Empty;
                        string Cassette3 = string.Empty;
                        string Cassette4 = string.Empty;
                        decimal Denom1 = 0;
                        decimal Denom2 = 0;
                        decimal Denom3 = 0;
                        decimal Denom4 = 0;
                        string CassetteType1 = string.Empty;
                        string CassetteType2 = string.Empty;
                        string CassetteType3 = string.Empty;
                        string CassetteType4 = string.Empty;
                        string TxnDate = string.Empty;
                        decimal Before_INCasset1 = 0;
                        decimal Before_INCasset2 = 0;
                        decimal Before_INCasset3 = 0;
                        decimal Before_INCasset4 = 0;
                        decimal Before_PURGE1 = 0;
                        decimal Before_PURGE2 = 0;
                        decimal Before_PURGE3 = 0;
                        decimal Before_PURGE4 = 0;
                        decimal Before_Remaining1 = 0;
                        decimal Before_Remaining2 = 0;
                        decimal Before_Remaining3 = 0;
                        decimal Before_Remaining4 = 0;
                        decimal Before_Dispensed1 = 0;
                        decimal Before_Dispensed2 = 0;
                        decimal Before_Dispensed3 = 0;
                        decimal Before_Dispensed4 = 0;
                        decimal Before_Total1 = 0;
                        decimal Before_Total2 = 0;
                        decimal Before_Total3 = 0;
                        decimal Before_Total4 = 0;
                        decimal After_INCasset1 = 0;
                        decimal After_INCasset2 = 0;
                        decimal After_INCasset3 = 0;
                        decimal After_INCasset4 = 0;
                        decimal After_PURGE1 = 0;
                        decimal After_PURGE2 = 0;
                        decimal After_PURGE3 = 0;
                        decimal After_PURGE4 = 0;
                        decimal After_Remaining1 = 0;
                        decimal After_Remaining2 = 0;
                        decimal After_Remaining3 = 0;
                        decimal After_Remaining4 = 0;
                        decimal After_Dispensed1 = 0;
                        decimal After_Dispensed2 = 0;
                        decimal After_Dispensed3 = 0;
                        decimal After_Dispensed4 = 0;
                        decimal After_Total1 = 0;
                        decimal After_Total2 = 0;
                        decimal After_Total3 = 0;
                        decimal After_Total4 = 0;

                        int count = 0;
                        int Rejectcount = 0;
                        int DISPENSEDcount = 0;
                        int TOTAL1count = 0;

                        TxnDate = Path.GetFileNameWithoutExtension(filename).Split('_')[1].ToString();
                        TxnDate = TxnDate.Substring(2);
                        if (TimeStampchk == null || TimeStampchk == "")
                        {
                            try
                            {
                                string dtm = "";
                                string[] CASSETTE = arrLines[StartIndexx - 2].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                if (CASSETTE.Contains("DATE"))
                                {
                                    dtm = CASSETTE[2].Trim().ToString();
                                    dtm = dtm + " " + CASSETTE[3].Trim().ToString();
                                }
                                TimeStamp = DateTime.ParseExact(dtm, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);
                            }
                            catch
                            {
                                try
                                {
                                    string[] txntime = arrLines[StartIndexx - 1].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray(); ;
                                    TimeStamp = DateTime.ParseExact((TxnDate + " " + txntime[0].ToString()), "ddMMyyyy HH:mm:ss", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);
                                }
                                catch
                                {
                                    TimeStamp = DateTime.ParseExact(TxnDate, "ddMMyyyy", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);}
                                }
                            }
                        }
                        #region "Reset 1st"
                        if (StartIndexx < EndIndexx)
                        {
                            try
                            {
                                for (int d = StartIndexx; d <= EndIndexx; d++)
                                {
                                    result = RemoveAdditionalChars(arrLines[d].ToString());
                                    if (!StartLine.Contains("MAC=YES") && arrLines != null && arrLines.Length > 0)
                                    {
                                        try
                                        {
                                            inact = new string[] { "CASSETTE", "*R*" }.Any(s => result.Contains(s));
                                            string[] CASSETTE = arrLines[d].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                            if (CASSETTE.Contains("CASSETTE") && count == 0)
                                            {
                                                Cassette1 = CASSETTE[2].Trim().ToString();
                                                Cassette2 = CASSETTE[3].Trim().ToString();
                                                Cassette3 = CASSETTE[4].Trim().ToString();
                                                Cassette4 = CASSETTE[5].Trim().ToString();
                                            }

                                            if (CASSETTE.Contains("DENOM") && Rejectcount == 0)
                                            {
                                                Denom1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Denom2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Denom3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Denom4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }

                                            if (CASSETTE.Contains("CASS.TYPE") && Rejectcount == 0)
                                            {
                                                CassetteType1 = CASSETTE[2].Trim().ToString();
                                                CassetteType2 = CASSETTE[3].Trim().ToString();
                                                CassetteType3 = CASSETTE[4].Trim().ToString();
                                                CassetteType4 = CASSETTE[5].Trim().ToString();
                                            }
                                            if (CASSETTE.Contains("IN") && CASSETTE.Contains("CASSETTE:"))
                                            {
                                                Before_INCasset1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Before_INCasset2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Before_INCasset3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Before_INCasset4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }

                                            if (CASSETTE.Contains("+PURGE"))
                                            {
                                                Before_PURGE1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Before_PURGE2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Before_PURGE3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Before_PURGE4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }
                                            if (CASSETTE.Contains("=REMAINING"))
                                            {
                                                Before_Remaining1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Before_Remaining2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Before_Remaining3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Before_Remaining4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }
                                            if (CASSETTE.Contains("+DISPENSED") && DISPENSEDcount == 0)
                                            {
                                                Before_Dispensed1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Before_Dispensed2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Before_Dispensed3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Before_Dispensed4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }

                                            if (CASSETTE.Contains("=TOTAL") && TOTAL1count == 0)
                                            {
                                                Before_Total1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Before_Total2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Before_Total3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Before_Total4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }
                                        }
                                        catch { }
                                    }
                                }
                                Guid Trans_CycleID1 = Guid.NewGuid();
                                _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette1, Denom1, CassetteType1, Before_INCasset1, Before_PURGE1, Before_Remaining1, Before_Dispensed1, Before_Total1, After_INCasset1, After_PURGE1, After_Remaining1, After_Dispensed1, After_Total1, 0, "", TimeStamp, "");
                                _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette2, Denom2, CassetteType2, Before_INCasset2, Before_PURGE2, Before_Remaining2, Before_Dispensed2, Before_Total2, After_INCasset2, After_PURGE2, After_Remaining2, After_Dispensed2, After_Total2, 0, "", TimeStamp, "");
                                _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette3, Denom3, CassetteType3, Before_INCasset3, Before_PURGE3, Before_Remaining3, Before_Dispensed3, Before_Total3, After_INCasset3, After_PURGE3, After_Remaining3, After_Dispensed3, After_Total3, 0, "", TimeStamp, "");
                                _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette4, Denom4, CassetteType4, Before_INCasset4, Before_PURGE4, Before_Remaining4, Before_Dispensed4, Before_Total4, After_INCasset4, After_PURGE4, After_Remaining4, After_Dispensed4, After_Total4, 0, "", TimeStamp, "");
                                InsertCount = InsertCount + 4;
                            }
                            catch (Exception ex)
                            {
                                ErrorLine++;
                            }
                        }
                        #endregion "Reset 1st"
                    }
                }
            }
            catch (Exception ex)
            {
                //InsertCount = 0;
                //objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessEJ_CashtallyLogSpliter", "ProcessEJ_CashtallyLogSpliter", LineNo, FileName, UserName, 'E');
            }
            _DataSet.Tables.Add(_DataTableEod);
            MSGLBL = string.Empty;
            return _DataSet;
        }

        public DataSet SplitDataSwapNCR2(string path, string FileName, out int InsertCount, out int TotalCount, out string MSGLBL, string UserName)
        {

            #region "Declaration"
            DataSet ds = new DataSet();
            string MSG = string.Empty;
            DataSet _DataSet = new DataSet();
            DataTable _DataTableEod = new DataTable();

            //_DataTableEod.Columns.Add("ClientID", typeof(int));
            _DataTableEod.Columns.Add("TerminalID", typeof(string));
            _DataTableEod.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTableEod.Columns.Add("LastCashCounterCleared", typeof(DateTime));
            _DataTableEod.Columns.Add("LastPurgeBinCleared", typeof(DateTime));
            _DataTableEod.Columns.Add("Denom1", typeof(string));
            _DataTableEod.Columns.Add("Denom2", typeof(string));
            _DataTableEod.Columns.Add("Denom3", typeof(string));
            _DataTableEod.Columns.Add("Denom4", typeof(string));
            _DataTableEod.Columns.Add("Cassette1", typeof(string));
            _DataTableEod.Columns.Add("Cassette2", typeof(string));
            _DataTableEod.Columns.Add("Cassette3", typeof(string));
            _DataTableEod.Columns.Add("Cassette4", typeof(string));
            _DataTableEod.Columns.Add("CassetteType1", typeof(string));
            _DataTableEod.Columns.Add("CassetteType2", typeof(string));
            _DataTableEod.Columns.Add("CassetteType3", typeof(string));
            _DataTableEod.Columns.Add("CassetteType4", typeof(string));
            _DataTableEod.Columns.Add("Rejected1", typeof(string));
            _DataTableEod.Columns.Add("Rejected2", typeof(string));
            _DataTableEod.Columns.Add("Rejected3", typeof(string));
            _DataTableEod.Columns.Add("Rejected4", typeof(string));
            _DataTableEod.Columns.Add("Remaining1", typeof(string));
            _DataTableEod.Columns.Add("Remaining2", typeof(string));
            _DataTableEod.Columns.Add("Remaining3", typeof(string));
            _DataTableEod.Columns.Add("Remaining4", typeof(string));
            _DataTableEod.Columns.Add("Dispensed1", typeof(string));
            _DataTableEod.Columns.Add("Dispensed2", typeof(string));
            _DataTableEod.Columns.Add("Dispensed3", typeof(string));
            _DataTableEod.Columns.Add("Dispensed4", typeof(string));
            _DataTableEod.Columns.Add("TotalCassette1", typeof(string));
            _DataTableEod.Columns.Add("TotalCassette2", typeof(string));
            _DataTableEod.Columns.Add("TotalCassette3", typeof(string));
            _DataTableEod.Columns.Add("TotalCassette4", typeof(string));
            _DataTableEod.Columns.Add("CassetteStatus1", typeof(string));
            _DataTableEod.Columns.Add("CassetteStatus2", typeof(string));
            _DataTableEod.Columns.Add("CassetteStatus3", typeof(string));
            _DataTableEod.Columns.Add("CassetteStatus4", typeof(string));
            _DataTableEod.Columns.Add("AddCash1", typeof(string));
            _DataTableEod.Columns.Add("AddCash2", typeof(string));
            _DataTableEod.Columns.Add("AddCash3", typeof(string));
            _DataTableEod.Columns.Add("AddCash4", typeof(string));
            _DataTableEod.Columns.Add("Remarks", typeof(string));
            _DataTableEod.Columns.Add("NoOfDuplicate", typeof(int));

            DataTable _DataTableEod1 = new DataTable();
            _DataTableEod1.Columns.Add("TerminalID", typeof(string));
            _DataTableEod1.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTableEod1.Columns.Add("Cassette", typeof(string));
            _DataTableEod1.Columns.Add("Denom", typeof(decimal));
            _DataTableEod1.Columns.Add("CassetteType", typeof(string));
            _DataTableEod1.Columns.Add("Before_INCasset", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_PURGE", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_Remaining", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_Dispensed", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_Total", typeof(decimal));
            _DataTableEod1.Columns.Add("After_INCasset", typeof(decimal));
            _DataTableEod1.Columns.Add("After_PURGE", typeof(decimal));
            _DataTableEod1.Columns.Add("After_Remaining", typeof(decimal));
            _DataTableEod1.Columns.Add("After_Dispensed", typeof(decimal));
            _DataTableEod1.Columns.Add("After_Total", typeof(decimal));
            _DataTableEod1.Columns.Add("Total_Diff", typeof(decimal));
            _DataTableEod1.Columns.Add("Remark", typeof(string));
            _DataTableEod1.Columns.Add("TrTimeStamp", typeof(DateTime));
            _DataTableEod1.Columns.Add("AuthCode", typeof(string));

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            string[] arrLines;
            arrLines = File.ReadAllLines(path, Encoding.Default);
            string[] ErrorLines = File.ReadAllLines(path, Encoding.Default);
            int StartIndex = 0;
            int EndIndex = 0;
            int StartIndex1 = 0;
            int EndIndex1 = 0;
            int StartIndexx = 0;
            int EndIndexx = 0;
            int totallength = arrLines.Length;
            string filename = Path.GetFileName(path);
            string result;
            DateTime TimeStamp = System.DateTime.Now;
            DateTime TimeStamp1 = System.DateTime.Now;
            DateTime? CounterDate = null;
            DateTime? ClearedDate = null;
            DateTime TranDate = System.DateTime.Now;
            DateTime TranDate_dmy = System.DateTime.Now;
            DateTime TimeStamp_dmy = System.DateTime.Now;
            string Remark1 = string.Empty;
            string Remark2 = string.Empty;
            string Remark3 = string.Empty;
            string Remark4 = string.Empty;
            string Remarks = string.Empty;
            string Denomination = string.Empty;
            string RequestCount = string.Empty;
            string DispenseCount = string.Empty;
            string RemainCount = string.Empty;
            string PickupCount = string.Empty;
            string RejectCount = string.Empty;
            string TransSEQNumber = string.Empty;
            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            string Denom1 = string.Empty;
            string Denom2 = string.Empty;
            string Denom3 = string.Empty;
            string Denom4 = string.Empty;
            string CassetteType1 = string.Empty;
            string CassetteType2 = string.Empty;
            string CassetteType3 = string.Empty;
            string CassetteType4 = string.Empty;
            string Rejected1 = string.Empty;
            string Rejected2 = string.Empty;
            string Rejected3 = string.Empty;
            string Rejected4 = string.Empty;
            string Remaining1 = string.Empty;
            string Remaining2 = string.Empty;
            string Remaining3 = string.Empty;
            string Remaining4 = string.Empty;
            string Dispense1 = string.Empty;
            string Dispense2 = string.Empty;
            string Dispense3 = string.Empty;
            string Dispense4 = string.Empty;
            string TotalDispense1 = string.Empty;
            string TotalDispense2 = string.Empty;
            string TotalDispense3 = string.Empty;
            string TotalDispense4 = string.Empty;
            string CassetteStatus1 = string.Empty;
            string CassetteStatus2 = string.Empty;
            string CassetteStatus3 = string.Empty;
            string CassetteStatus4 = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string EJDataID = string.Empty;
            string AddCash1 = string.Empty;
            string AddCash2 = string.Empty;
            string AddCash3 = string.Empty;
            string AddCash4 = string.Empty;
            string TerminalId = string.Empty;
            string ReferenceNumber = string.Empty;
            string ECardNumber = string.Empty;
            string CardNumber = string.Empty;
            string CardType = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            DateTime? TxnsDateTime = null;
            DateTime? TxnsDateTimeFailed = null;
            decimal TxnsAmount = 0;
            decimal Amount1 = 0;
            decimal Amount2 = 0;
            decimal Amount3 = 0;
            string TxnsType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string ResponseCode = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            decimal FeeAmount = 0;
            string CurrencyCode = string.Empty;
            decimal CustBalance = 0;
            decimal InterchangeBalance = 0;
            decimal ATMBalance = 0;
            string BranchCode = string.Empty;
            string OPCode = string.Empty;
            string ResultCode = string.Empty;
            string ErrorCode = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string FunctionID = string.Empty;
            decimal InitAmount = 0;
            decimal DispAmount = 0;
            decimal StorAmount = 0;
            decimal RemAmount = 0;
            string NoOfDuplicate = string.Empty;
            string FilePath = string.Empty;
            string FileDate = string.Empty;
            DateTime? CreatedOn = null;
            DateTime? ModifiedOn = null;
            string CreatedBy = string.Empty;
            string ModifiedBy = string.Empty;
            bool inact = false;
            int LineNo1 = 0;
            bool flag = false;
            int ErrorLine = 0;
            string Typecheck = string.Empty;
            string VortexNotes = string.Empty;
            string PreviousAuthCode = string.Empty;
            string NCRNotes = string.Empty;
            #endregion
            string StartLine = string.Empty;
            if (arrLines.Length > 10)
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(10));
            }
            else
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(arrLines.Length));
            }
            if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
            {
                string result1 = ConvertStringArrayToString(arrLines);
                if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
                {
                    result = result1.Replace("*****START TRANSACTION*****", "|*****START TRANSACTION*****").Replace("CARD NUMBER", "|CARD NUMBER").
                        Replace("AUTH_NR", "|AUTH_NR").Replace("SEQ NUM", "|SEQ NUM").Replace("RSP CODE", "|RSP CODE")
                        .Replace("ACQUIRER_ID", "|ACQUIRER_ID").Replace("AID", "|AID").Replace("AVAIL", "|AVAIL").
                         Replace("LEDGER", "|LEDGER").Replace("WITHDRAWN", "|WITHDRAWN").Replace("a", "|").Replace("READ ERROR", "|READ ERROR").
                         Replace("a", "|").Replace("e1", "").Replace("e2", "").Replace("e3", "").Replace("e4", "").Replace("e5", "").Replace("e6", "")
                        .Replace("e7", "").Replace("e8", "").Replace("e9", "").Replace("e10", "").Replace("e;", "")
                        .Replace("IN CASSETTE", "|IN CASSETTE").Replace("DENOM", "|DENOM").Replace("CASS.TYPE", "|CASS.TYPE").Replace("+PURGE", "|+PURGE")
                        .Replace("OPCODE", "|OPCODE").Replace("NOTES PRESENTED", "|NOTES PRESENTED").Replace("NOTES TAKEN", "|NOTES TAKEN")
                        .Replace("DENOMINATION", "|DENOMINATION").Replace("DISPENSED", "|DISPENSED").Replace("REJECTED", "|REJECTED").Replace("REMAINING", "|REMAINING")
                        .Replace("REMAINING", "|REMAINING").Replace("DISPENSED", "|DISPENSED").Replace("TOTAL", "|TOTAL").Replace("CASSETTE STATUS", "|CASSETTE STATUS")
                        .Replace("LAST CASH COUNTER UPDATE", "|LAST CASH COUNTER UPDATE").Replace("LAST PURGE BIN CLEARED", "|LAST PURGE BIN CLEARED")
                        .Replace("*****END TRANSACTION*****", "|*****END TRANSACTION*****").Replace("DIVERTED NOTES", "|DIVERTED NOTES").
                        Trim();
                    arrLines = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                    arrLines = arrLines.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                }
            }

            TerminalId = Path.GetFileNameWithoutExtension(filename.Split('_').First().Trim().ToString());
            if (TerminalId != "0")
            {

            }

            try
            {
                if (arrLines != null && arrLines.Length > 0)
                {
                    StartIndex = -1;
                    EndIndex = -1;
                    for (LineNo = 0; LineNo <= arrLines.Length; LineNo++)
                    {
                        if (GetIndex(arrLines, LineNo, "CASH TOTAL       TYPE1 TYPE2 TYPE3 TYPE4") != -1)
                        {
                            StartIndex = GetIndex(arrLines, LineNo, "CASH TOTAL       TYPE1 TYPE2 TYPE3 TYPE4");
                            EndIndex = StartIndex + 6;
                        }
                    }

                    if (StartIndex != -1)
                    {
                        for (int LineNoD = StartIndex - 18; LineNoD <= EndIndex; LineNoD++)
                        {
                            try
                            {
                                string str_TrTimstamp;
                                string strTr_Date, Time;
                                string result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());
                                string[] EJRequest = result1.Split(new string[] { " " }, StringSplitOptions.None);

                                if (result1.Contains("DATE") && result1.Contains("TIME"))
                                {
                                    string[] TerminalSplit = result1.Split(' ');
                                    // strTr_Date = RemoveAdditionalChars(TerminalSplit[0].ToString());
                                    //string[] date = strTr_Date.Split('-');
                                    strTr_Date = RemoveAdditionalChars(TerminalSplit[1].Trim());
                                    Time = RemoveAdditionalChars(TerminalSplit[3].Trim());

                                    strTr_Date = strTr_Date.Replace("-", "/");
                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);
                                        CounterDate = TimeStamp;
                                        //ResponseCode = TerminalSplit[3].Trim();
                                    }
                                    catch (Exception ex)
                                    {

                                        try
                                        {
                                            TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm", CultureInfo.InvariantCulture);
                                            CounterDate = TimeStamp;
                                            // ResponseCode = TerminalSplit[3].Trim();
                                        }
                                        catch (Exception E11)
                                        {


                                        }

                                    }
                                }
                                if (result1.Contains("DATE        TIME      ATM-ID   RESP"))
                                {
                                    result1 = RemoveAdditionalChars(arrLines[LineNoD + 1].ToString());
                                    string[] TerminalSplit = result1.Split(' ');
                                    strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
                                    if (strTr_Date.Contains("-"))
                                    {
                                        string[] date = strTr_Date.Split('-');
                                        strTr_Date = RemoveAdditionalChars(date[0].Trim());
                                        Time = RemoveAdditionalChars(EJRequest[1].Trim());
                                    }
                                    else
                                    {
                                        // string[] date = strTr_Date.Split('-');
                                        strTr_Date = RemoveAdditionalChars(TerminalSplit[0].Trim());
                                        Time = RemoveAdditionalChars(TerminalSplit[1].Trim());
                                    }
                                    //if (TerminalSplit[3].Trim() == "61")
                                    //{
                                    //    ResponseCode = "61";
                                    //}
                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                        CounterDate = TimeStamp;
                                        ResponseCode = TerminalSplit[3].Trim();
                                    }
                                    catch (Exception ex)
                                    {
                                        try
                                        {
                                            TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                                            CounterDate = TimeStamp;
                                        }
                                        catch (Exception EX1)
                                        {


                                        }

                                        //ResponseCode = TerminalSplit[3].Trim();
                                    }

                                }
                                if (result1.Contains("ESAF")) //ej file index
                                {
                                    string[] TerminalSplit = result1.Split(' ');
                                    strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
                                    if (strTr_Date.Contains("-"))
                                    {
                                        string[] date = strTr_Date.Split('-');
                                        strTr_Date = RemoveAdditionalChars(date[0].Trim());
                                        Time = RemoveAdditionalChars(EJRequest[1].Trim());
                                    }
                                    else
                                    {
                                        // string[] date = strTr_Date.Split('-');
                                        strTr_Date = RemoveAdditionalChars(TerminalSplit[0].Trim());
                                        Time = RemoveAdditionalChars(TerminalSplit[1].Trim());
                                    }
                                    //if (TerminalSplit[3].Trim() == "61")
                                    //{
                                    //    ResponseCode = "61";
                                    //}
                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                        CounterDate = TimeStamp;
                                        ResponseCode = TerminalSplit[3].Trim();
                                    }
                                    catch (Exception ex)
                                    {
                                        try
                                        {
                                            TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                                            CounterDate = TimeStamp;
                                        }
                                        catch (Exception EX3)
                                        {


                                        }

                                        //ResponseCode = TerminalSplit[3].Trim();
                                    }

                                }
                                else if (result1.Contains("TRANSACTION START"))
                                {
                                    string[] TerminalSplit = result1.Split(' ');
                                    strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
                                    string[] date = strTr_Date.Split('-');
                                    strTr_Date = RemoveAdditionalChars(date[0].Trim());
                                    Time = RemoveAdditionalChars(EJRequest[1].Trim());

                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);
                                        //ResponseCode = TerminalSplit[3].Trim();
                                        CounterDate = TimeStamp;
                                    }
                                    catch (Exception ex)
                                    {
                                        try
                                        {
                                            TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                                            CounterDate = TimeStamp;
                                        }
                                        catch (Exception EX2)
                                        {


                                        }

                                    }
                                    string[] tmp = FileName.Split('_');
                                }
                            }
                            catch { }
                        }
                    }

                    #region Upload Ej
                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        Cassette1 = string.Empty;
                        Cassette2 = string.Empty;
                        Cassette3 = string.Empty;
                        Cassette4 = string.Empty;
                        Denom1 = string.Empty;
                        Denom2 = string.Empty;
                        Denom3 = string.Empty;
                        Denom4 = string.Empty;
                        CassetteType1 = string.Empty;
                        CassetteType2 = string.Empty;
                        CassetteType3 = string.Empty;
                        CassetteType4 = string.Empty;
                        Remaining1 = string.Empty;
                        Remaining2 = string.Empty;
                        Remaining3 = string.Empty;
                        Remaining4 = string.Empty;
                        Dispense1 = string.Empty;
                        Dispense2 = string.Empty;
                        Dispense3 = string.Empty;
                        Dispense4 = string.Empty;
                        TotalDispense1 = string.Empty;
                        TotalDispense2 = string.Empty;
                        TotalDispense3 = string.Empty;
                        TotalDispense4 = string.Empty;
                        CassetteStatus1 = string.Empty;
                        CassetteStatus2 = string.Empty;
                        CassetteStatus3 = string.Empty;
                        CassetteStatus4 = string.Empty;
                        AddCash1 = string.Empty;
                        AddCash2 = string.Empty;
                        AddCash3 = string.Empty;
                        AddCash4 = string.Empty;
                        string TxnDate = string.Empty;

                        TxnDate = Path.GetFileNameWithoutExtension(filename).Split('_')[1].ToString();
                        TxnDate = TxnDate.Substring(2);
                        try
                        {
                            TimeStamp = DateTime.ParseExact(TxnDate, "yyyyMMdd", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);

                        }
                        catch
                        {

                            TimeStamp = DateTime.ParseExact(TxnDate, "ddMMyyyy", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);

                        }
                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            #region "EOD"
                            try
                            {
                                result = RemoveAdditionalChars(arrLines[k].ToString());
                                if (!StartLine.Contains("MAC=YES") && arrLines != null && arrLines.Length > 0)
                                {
                                    inact = new string[] { "CASSETTE", "*R*" }.Any(s => result.Contains(s));
                                    int Rejectcount = 0;
                                    int REMAINING1count = 0;
                                    int DISPENSEDcount = 0;
                                    int TOTAL1count = 0;

                                    string[] CASSETTE = arrLines[k].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    if (CASSETTE.Contains("CASH") && CASSETTE.Contains("TOTAL"))
                                    {
                                        Cassette1 = CASSETTE[1].Trim().ToString();
                                        Cassette2 = CASSETTE[2].Trim().ToString();
                                        Cassette3 = CASSETTE[1].Trim().ToString();
                                        Cassette4 = CASSETTE[2].Trim().ToString();
                                    }

                                    if (CASSETTE.Contains("REJECTED"))
                                    {
                                        Rejected1 = CASSETTE[1].Trim().ToString();
                                        Rejected2 = CASSETTE[2].Trim().ToString();
                                        Rejected3 = CASSETTE[3].Trim().ToString();
                                        Rejected4 = CASSETTE[4].Trim().ToString();
                                    }

                                    if (CASSETTE.Contains("REMAINING"))
                                    {
                                        Remaining1 = CASSETTE[1].Trim().ToString();
                                        Remaining2 = CASSETTE[2].Trim().ToString();
                                        Remaining3 = CASSETTE[3].Trim().ToString();
                                        Remaining4 = CASSETTE[4].Trim().ToString();
                                    }
                                    if (CASSETTE.Contains("+DISPENSED"))
                                    {
                                        Dispense1 = CASSETTE[1].Trim().ToString();
                                        Dispense2 = CASSETTE[2].Trim().ToString();
                                        Dispense3 = CASSETTE[3].Trim().ToString();
                                        Dispense4 = CASSETTE[4].Trim().ToString();

                                    }

                                    if (CASSETTE.Contains("=TOTAL") && TOTAL1count == 0)
                                    {
                                        TOTAL1count++;
                                        TotalDispense1 = CASSETTE[1].Trim().ToString();
                                        TotalDispense2 = CASSETTE[2].Trim().ToString();
                                        TotalDispense3 = CASSETTE[1].Trim().ToString();
                                        TotalDispense4 = CASSETTE[2].Trim().ToString();

                                    }

                                }
                            }
                            catch (Exception ex)
                            {
                            }
                        }

                        try
                        {
                            Guid Trans_CycleID1 = Guid.NewGuid();
                            _DataTableEod.Rows.Add(TerminalId, CounterDate, CounterDate, ClearedDate, Denom1, Denom2, Denom3, Denom4, Cassette1, Cassette2, Cassette3, Cassette4, CassetteType1, CassetteType2, CassetteType3, CassetteType4, Rejected1, Rejected2, Rejected3, Rejected4, Remaining1, Remaining2, Remaining3, Remaining4, Dispense1, Dispense2, Dispense3, Dispense4, TotalDispense1, TotalDispense2, TotalDispense3, TotalDispense4, CassetteStatus1, CassetteStatus2, CassetteStatus3, CassetteStatus4, AddCash1, AddCash2, AddCash3, AddCash4, Remarks, '0');
                            #endregion
                        }
                        catch (Exception ex)
                        {
                            ErrorLine++;
                        }
                        Remark1 = string.Empty;
                        Remark2 = string.Empty;
                        Remark3 = string.Empty;
                        Remark4 = string.Empty;
                        Remarks = string.Empty;
                        Denomination = string.Empty;
                        RequestCount = string.Empty;
                        DispenseCount = string.Empty;
                        RemainCount = string.Empty;
                        PickupCount = string.Empty;
                        RejectCount = string.Empty;
                        TransSEQNumber = string.Empty;
                        Cassette1 = string.Empty;
                        Cassette2 = string.Empty;
                        Cassette3 = string.Empty;
                        Cassette4 = string.Empty;
                        Denom1 = string.Empty;
                        Denom2 = string.Empty;
                        Denom3 = string.Empty;
                        Denom4 = string.Empty;
                        CassetteType1 = string.Empty;
                        CassetteType2 = string.Empty;
                        CassetteType3 = string.Empty;
                        CassetteType4 = string.Empty;
                        Rejected1 = string.Empty;
                        Rejected2 = string.Empty;
                        Rejected3 = string.Empty;
                        Rejected4 = string.Empty;
                        Remaining1 = string.Empty;
                        Remaining2 = string.Empty;
                        Remaining3 = string.Empty;
                        Remaining4 = string.Empty;
                        Dispense1 = string.Empty;
                        Dispense2 = string.Empty;
                        Dispense3 = string.Empty;
                        Dispense4 = string.Empty;
                        TotalDispense1 = string.Empty;
                        TotalDispense2 = string.Empty;
                        TotalDispense3 = string.Empty;
                        TotalDispense4 = string.Empty;
                        CassetteStatus1 = string.Empty;
                        CassetteStatus2 = string.Empty;
                        CassetteStatus3 = string.Empty;
                        CassetteStatus4 = string.Empty;
                        ReserveField1 = string.Empty;
                        ReserveField2 = string.Empty;
                        ReserveField3 = string.Empty;
                        ReserveField4 = string.Empty;
                        ReserveField5 = string.Empty;
                        EJDataID = string.Empty;
                        LineNo1 = EndIndexx;
                    }
                    #endregion Upload Ej

                }
            }

            catch (Exception ex)
            {
                //objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessEJ_DIEBOLDLogSpliter", "ProcessLogSpliterBOB", LineNo, FileName, UserName, 'E');
            }


            //_DataSet.Tables.Add(_DataTableEod);
            foreach (DataRow row in _DataTableEod.Rows)
            {
                try
                {
                    //if (row["TxnsDateTime"].ToString().Length > 1)
                    {

                        _DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 100, "Type 1", 0, 0, row["Remaining1"], 0, 0, 0, 0, 0, 0, 0, 0, "", row["TxnsDateTime"], "");
                        _DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 200, "Type 2", 0, 0, row["Remaining2"], 0, 0, 0, 0, 0, 0, 0, 0, "", row["TxnsDateTime"], "");
                        _DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 500, "Type 3", 0, 0, row["Remaining3"], 0, 0, 0, 0, 0, 0, 0, 0, "", row["TxnsDateTime"], "");
                        _DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 500, "Type 4", 0, 0, row["Remaining4"], 0, 0, 0, 0, 0, 0, 0, 0, "", row["TxnsDateTime"], "");

                        //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 100, "Type 1", row["Cassette1"], 0, row["Remaining1"], row["Dispensed1"], row["TotalCassette1"], 0, 0, 0, 0, 0, 0);
                        //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 200, "Type 2", row["Cassette2"], 0, row["Remaining2"], row["Dispensed2"], row["TotalCassette2"], 0, 0, 0, 0, 0, 0);
                        //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 500, "Type 3", row["Cassette3"], 0, row["Remaining3"], row["Dispensed3"], row["TotalCassette3"], 0, 0, 0, 0, 0, 0);
                        //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 0, "Type 4", row["Cassette4"], 0, row["Remaining4"], row["Dispensed4"], row["TotalCassette4"], 0, 0, 0, 0, 0, 0);
                        //InsertCount = InsertCount + 4;
                    }
                }
                catch (Exception ex)
                {

                }
            }
            _DataSet.Tables.Add(_DataTableEod1);
            MSGLBL = string.Empty;
            return _DataSet;
        }

        public DataTable ASP_SplitData1(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTimeConverter objDateTimeConverter = new DateTimeConverter();
            System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");



            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("CustAccountNo", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("RequestAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("Amount2", typeof(decimal));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            _DataTable.Columns.Add("OPCode", typeof(string));
            _DataTable.Columns.Add("ErrorCode", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("NotesPresented1", typeof(string));
            _DataTable.Columns.Add("NotesPresented2", typeof(string));
            _DataTable.Columns.Add("NotesPresented3", typeof(string));
            _DataTable.Columns.Add("NotesPresented4", typeof(string));
            _DataTable.Columns.Add("Denomination1", typeof(string));
            _DataTable.Columns.Add("Denomination2", typeof(string));
            _DataTable.Columns.Add("Denomination3", typeof(string));
            _DataTable.Columns.Add("Denomination4", typeof(string));
            _DataTable.Columns.Add("Dispensed1", typeof(string));
            _DataTable.Columns.Add("Dispensed2", typeof(string));
            _DataTable.Columns.Add("Dispensed3", typeof(string));
            _DataTable.Columns.Add("Dispensed4", typeof(string));
            _DataTable.Columns.Add("Rejected1", typeof(string));
            _DataTable.Columns.Add("Rejected2", typeof(string));
            _DataTable.Columns.Add("Rejected3", typeof(string));
            _DataTable.Columns.Add("Rejected4", typeof(string));
            _DataTable.Columns.Add("Remaining1", typeof(string));
            _DataTable.Columns.Add("Remaining2", typeof(string));
            _DataTable.Columns.Add("Remaining3", typeof(string));
            _DataTable.Columns.Add("Remaining4", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("Status", typeof(int));
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0; 
            

            DataSet ds = new DataSet();

            string LogType = fileImportRequest.ConfigData.Rows[0]["FileName"].ToString();
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = fileImportRequest.ConfigData.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
            fileImportRequest.TotalCount = TotalCountArray.Length;


            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string PreviousReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string CustAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            decimal TxnsAmount = 0;
            decimal ReqAmount = 0;
            string Amount1 = "0";
            string Amount2 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;

            string CurrencyCode = "356";
            string CustBalance = "0";
            string RespLine = string.Empty;

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string line = string.Empty;
            string line1 = string.Empty;
            string ResponseCode = string.Empty;
            string EJResult = string.Empty;
            string ErrorCode = string.Empty;
            string Opcode = string.Empty;
            string ECardNumber = string.Empty;
            string Status = "0";

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            string tempCardNumber = string.Empty;
            string AuthCode = string.Empty;
            int ModeID = 0;
            string dummy = "XXXXXXXXXX";
            //int ChannelID;
            DateTime? TxnsDateTimeMain = null;

            DateTime? FileDate = null;
            try
            {
                FileDate = DateTime.ParseExact(fileImportRequest.FileName.Substring(fileImportRequest.FileName.IndexOf("_") + 1, 8).Trim(), "ddMMyyyy", CultureInfo.InvariantCulture);
            }
            catch
            {

            }


            try
            {
                TerminalID = fileImportRequest.FileName.Substring(0, fileImportRequest.FileName.IndexOf("_")).Trim();
            }
            catch
            {

            }

            bool card = false;
            bool Terminal = false;
            bool Acquirer = false;
            bool Rev1 = false;
            bool Rev2 = false;
            bool ATM = false;
            bool CDM = false;
            bool POS = false;
            bool ECOM = false;
            bool IMPS = false;
            bool UPI = false;
            bool MicroATM = false;
            bool MobileRecharge = false;
            bool BAL = false;
            bool MS = false;
            bool PC = false;
            bool CB = false;
            bool RCA1 = false;
            bool RCA2 = false;
            //bool MC = false;
            //bool VC = false;
            bool OC = false;
            bool D = false;
            bool C = false;
            int ATRRECEIVEDT = 0;

            string SplitType = ",";
            string[] TerminalCode = fileImportRequest.ConfigData.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BIN_No = fileImportRequest.ConfigData.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] AcquirerIDArray = fileImportRequest.ConfigData.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode1Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode2Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ReversalType = fileImportRequest.ConfigData.Rows[0]["ReversalType"].ToString();
            string[] ATMType = fileImportRequest.ConfigData.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CDMType = fileImportRequest.ConfigData.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] POSType = fileImportRequest.ConfigData.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ECOMType = fileImportRequest.ConfigData.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] IMPType = fileImportRequest.ConfigData.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] UPIType = fileImportRequest.ConfigData.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MicroATMType = fileImportRequest.ConfigData.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MobileRechargeType = fileImportRequest.ConfigData.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BalanceEnquiry = fileImportRequest.ConfigData.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MiniStatement = fileImportRequest.ConfigData.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] PinChange = fileImportRequest.ConfigData.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ChequeBookReq = fileImportRequest.ConfigData.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ResponseType = fileImportRequest.ConfigData.Rows[0]["ResponseType"].ToString();
            string[] ResponseCode1Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ResponseCode2Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] OfflineCode = fileImportRequest.ConfigData.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnPostDateTime = fileImportRequest.ConfigData.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] DebitCode = fileImportRequest.ConfigData.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CreditCode = fileImportRequest.ConfigData.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);



            string[] Notes = new string[4];
            string[] Denominations = new string[5];
            string[] Dispenseds = new string[5];
            string[] Rejecteds = new string[5];
            string[] Remainings = new string[5];
            string[] CASSTYPE = new string[5];

            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;

            string Denomination1 = string.Empty;
            string Denomination2 = string.Empty;
            string Denomination3 = string.Empty;
            string Denomination4 = string.Empty;

            string PRESENTED = string.Empty;

            bool CassetteFetch = false;

            int i = 0;

            string tempErrorCode = string.Empty;

            for (int j = 0; j <= fileImportRequest.TotalCount; j++)
            {
                try
                {
                    //StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID"); //DBA8
                    //EndIndex = Common.GetIndex(TotalCountArray, j + 1, "------------------------------------");

                    if (ATRRECEIVEDT > 1)
                    {
                        StartIndex = j - 1;
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "TRANSACTION START");
                        ATRRECEIVEDT = 0;
                    }
                    else
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j - 1, "TRANSACTION START");
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "TRANSACTION START");
                    }


                    if (StartIndex != -1 && EndIndex == -1)
                    {
                        EndIndex = StartIndex + 50;
                    }

                    ReqAmount = 0;
                    //TerminalID = string.Empty;
                    AcquirerID = string.Empty;
                    ReferenceNumber = string.Empty;
                    AuthCode = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsDate = string.Empty;
                    TxnsTime = string.Empty;
                    TxnsAmount = 0;
                    Amount1 = "0";
                    Amount2 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;

                    CustBalance = "0";
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    Status = "0";

                    ResponseCode = string.Empty;
                    EJResult = string.Empty;
                    ErrorCode = string.Empty;
                    Opcode = string.Empty;
                    ECardNumber = string.Empty;
                    CardType = string.Empty;
                    TxnsStatus = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    DebitCreditType = string.Empty;


                    Denomination1 = string.Empty;
                    Denomination2 = string.Empty;
                    Denomination3 = string.Empty;
                    Denomination4 = string.Empty;
                    PRESENTED = string.Empty;

                    RespLine = string.Empty;
                    tempCardNumber = string.Empty;
                   

                    Array.Clear(Notes, 0, Notes.Length);
                    Array.Clear(Dispenseds, 0, Dispenseds.Length);
                    Array.Clear(Denominations, 0, Denominations.Length);
                    Array.Clear(Rejecteds, 0, Rejecteds.Length);
                    Array.Clear(Remainings, 0, Remainings.Length);
                    Array.Clear(CASSTYPE, 0, CASSTYPE.Length);

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex + 1; k <= EndIndex - 1; k++)
                        {

                            try
                            {

                                LineNo++;

                                if (TotalCountArray.Length <= k)
                                {
                                    break;
                                }

                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = Common.RemoveAdditionalChars(line);
                                ReserveField5 = ReserveField5 + " \n " + EJResult.Trim();

                                if (EJResult.ToUpper().Contains("CARD NO:"))
                                {
                                    CardNumber = EJResult.Substring(EJResult.IndexOf("CARD NO:") + 8).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("CARD:"))
                                {
                                    CardNumber = EJResult.Substring(EJResult.IndexOf("CARD:") + 5).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("AMOUNT") && EJResult.Contains("ENTERED"))
                                {
                                    ReqAmount = Convert.ToDecimal(ExtractNumber(EJResult.Substring(EJResult.IndexOf("AMOUNT") + 6).Trim()));
                                }
                                else if (EJResult.ToUpper().Contains("AMOUNT:") && ReqAmount == 0)
                                {
                                    ReqAmount = Convert.ToDecimal(EJResult.Substring(EJResult.IndexOf("AMOUNT:") + 7).Trim());
                                }
                                else if (EJResult.ToUpper().Contains("TXN SN NO="))
                                {
                                    AuthCode = EJResult.Substring(EJResult.IndexOf("TXN SN NO=") + "TXN SN NO=".Length).Trim();
                                    AuthCode = AuthCode.Replace("]", "");
                                }
                                else if (EJResult.ToUpper().Contains("TXN NO"))
                                {
                                    AuthCode = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("OPCODE"))
                                {
                                    Opcode = EJResult.Substring(EJResult.IndexOf("=") + 1).Trim();
                                }

                                else if (EJResult.Contains("TRANSTYPE"))
                                {
                                    TxnsSubType = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("DATE") && EJResult.Contains("TIME") && !EJResult.Contains("ATM-ID"))
                                {
                                    TxnsDate = EJResult.Substring(4, EJResult.IndexOf("TIME") - 4).Trim();
                                    TxnsDate = TxnsDate.Replace("-", "/");
                                    TxnsTime = EJResult.Substring(EJResult.IndexOf("TIME") + 4).Trim();
                                }
                                else if (EJResult.Contains("DATE") && EJResult.Contains("TIME") && EJResult.Contains("ATM-ID") && EJResult.Contains("RESP"))
                                {
                                    RespLine = Common.RemoveAdditionalChars(Regex.Replace(TotalCountArray[k + 1].ToString(), "[^ -~]+", string.Empty));

                                    if (RespLine.Split(" ").Length > 3)
                                    {
                                        TxnsDate = RespLine.Split(" ")[0].Trim();
                                        TxnsTime = RespLine.Split(" ")[1].Trim();
                                        ResponseCode = RespLine.Split(" ")[3].Trim();
                                        TerminalID = RespLine.Split(" ")[2].Trim();
                                    }
                                }
                                else if (EJResult.Contains("DATE") && EJResult.Contains("TIME") && EJResult.Contains("ATM-ID"))
                                {
                                    RespLine = Common.RemoveAdditionalChars(Regex.Replace(TotalCountArray[k + 1].ToString(), "[^ -~]+", string.Empty));

                                    if (RespLine.Split(" ").Length > 2)
                                    {
                                        TxnsDate = RespLine.Split(" ")[0].Trim();
                                        TxnsTime = RespLine.Split(" ")[1].Trim();
                                        TerminalID = RespLine.Split(" ")[2].Trim();
                                    }
                                }
                                else if (EJResult.Contains("WITHDRAWAL"))
                                {
                                    TxnsAmount = Convert.ToDecimal(ExtractNumber(EJResult));
                                    TxnsSubType = "WITHDRAWAL";
                                }
                                else if (EJResult.Contains("DESC: APPROVED"))
                                {
                                    TxnsAmount = Convert.ToDecimal(ExtractNumber(EJResult));
                                    TxnsSubType = "WITHDRAWAL";
                                }
                                else if (EJResult.Contains("DESC:"))
                                {
                                    ReserveField4 = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    if (ReserveField4.Contains("BALANCE ENQ"))
                                    {
                                        TxnsSubType = "BALANCE ENQ";
                                    }
                                    else if (EJResult.Contains("GREEN PIN"))
                                    {
                                        TxnsSubType = "GREEN PIN";
                                    }
                                    else if (EJResult.Contains("PIN CHANGE"))
                                    {
                                        TxnsSubType = "PIN CHANGE";
                                    }
                                }

                                else if (EJResult.Contains("PRINT RECEIPT - SUCCESS") && ReserveField4.Contains("APPROVED"))
                                {
                                    TxnsSubType = "MINISTATEMENT";
                                }
                                else if (EJResult.Contains("TXN") && EJResult.Contains("A/C#"))
                                {
                                    if (EJResult.Split(" ").Length > 4)
                                    {
                                        ReferenceNumber = EJResult.Split(" ")[2].Trim();
                                        CustAccountNo = EJResult.Split(" ")[4].Trim();
                                    }
                                    else if (EJResult.Split(" ").Length == 4)
                                    {
                                        ReferenceNumber = EJResult.Split(" ")[2].Trim();
                                    }
                                    else if (EJResult.Split(" ").Length == 4)
                                    {
                                        ReferenceNumber = EJResult.Split(" ")[2].Trim();
                                    }
                                }
                                else if (EJResult.Contains("TRACE:"))
                                {
                                    ReferenceNumber = EJResult.Substring(EJResult.IndexOf("TRACE:") + "TRACE:".Length).Trim();
                                }
                                else if (EJResult.Contains("ATR RECEIVED T=0"))
                                {
                                    ATRRECEIVEDT++;
                                    if (ATRRECEIVEDT > 1)
                                    {
                                        break;
                                    }
                                }
                                else if (EJResult.Contains("BALANCE"))
                                {
                                    CustBalance = Convert.ToDecimal(Regex.Match(EJResult.Substring(EJResult.IndexOf(":") + 1).Trim(), @"\d+(?:\.\d+)").Value).ToString();

                                }
                                else if (EJResult.Contains("STACKED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES STACKED";
                                }
                                else if (EJResult.Contains("CASH TAKEN"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " CASH TAKEN";
                                    TxnsStatus = "Sucessfull";
                                }
                                else if (EJResult.Contains("NOTES PRESENTED"))
                                {
                                    Notes = EJResult.Substring(EJResult.IndexOf("PRESENTED") + 10).Trim().Split(',');
                                    TxnsPerticulars = TxnsPerticulars + " NOTES PRESENTED";
                                }
                                else if (EJResult.Contains("PRESENTED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES PRESENTED";
                                    PRESENTED = EJResult.Substring(EJResult.IndexOf("PRESENTED :") + 11).Trim();
                                }
                                else if (EJResult.Contains("NOTES TAKEN"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES TAKEN";
                                    TxnsStatus = "Sucessfull";
                                    ResponseCode = "00";
                                }
                                else if (EJResult.Contains("NOTES DEPOSITED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES DEPOSITED";
                                }
                                else if (EJResult.Contains("MINISTMT"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "MINI-STATEMENT";
                                }
                                else if (EJResult.Contains("DECLINED OFFLINE-AAC"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "DECLINED OFFLINE-AAC";
                                }
                                else if (EJResult.Contains("DISPENSER FAILURE"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "DISPENSER FAILURE";
                                }
                                else if (EJResult.Contains("SPECIAL PICKUPRS"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "SPECIAL PICKUPRS";
                                }
                                else if (EJResult.Contains("POWER"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "POWER CYCLE";
                                }
                                else if (EJResult.Contains("DENOMINATION"))
                                {
                                    Denominations = EJResult.Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("DENOMINATION"))
                                {
                                    Denominations = EJResult.Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("DENOM"))
                                {
                                    Denominations = EJResult.Replace(": ", "").Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("CASS.TYPE"))
                                {
                                    CASSTYPE = EJResult.Replace(": ", "").Split(' ');

                                    if (CASSTYPE.Length == 5 && Denominations.Length == 5)
                                    {
                                        for (int x = 1; x < CASSTYPE.Length; x++)
                                        {
                                            if (Convert.ToInt32(CASSTYPE[x]) == 0)
                                            {
                                                Notes[x - 1] = "0";
                                            }
                                            else if (Convert.ToInt32(CASSTYPE[x]) > 0)
                                            {
                                                if (PRESENTED.Length > 0 && PRESENTED.Contains(";"))
                                                {
                                                    string[] PR = PRESENTED.Split(";");
                                                    foreach (string Deno in PR)
                                                    {
                                                        if (Deno.Length > 0 && Deno.Substring(Deno.IndexOf(":") - 1, 1).Trim() == CASSTYPE[x].Trim())
                                                        {
                                                            Notes[x - 1] = Deno.Substring(EJResult.IndexOf(",") + 1, 1).Trim();
                                                        }
                                                        else
                                                        {
                                                            Notes[x - 1] = "0";
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    Notes[x - 1] = "0";
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (EJResult.Contains("DISPENSED"))
                                {
                                    Dispenseds = EJResult.Replace(": ", "").Split(' ');

                                    if (Dispenseds.Length != 5)
                                    {
                                        Dispenseds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REMAINING"))
                                {
                                    Remainings = EJResult.Replace(": ", "").Split(' ');

                                    if (Remainings.Length != 5)
                                    {
                                        Remainings = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REJECTED"))
                                {
                                    Rejecteds = EJResult.Replace(": ", "").Split(' ');

                                    if (Rejecteds.Length != 5)
                                    {
                                        Rejecteds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("+PURGE"))
                                {
                                    Rejecteds = EJResult.Replace(": ", "").Split(' ');

                                    if (Rejecteds.Length != 5)
                                    {
                                        Rejecteds = new string[5];
                                    }
                                }

                                else if (EJResult.Contains("USER"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("NO FUNDS AVAILABLE"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ERROR"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("UNABLE TO PROCESS"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("POWER-UP/RESET"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("LIMIT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ENTER LESSER AMOUNT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ENTER AMOUNT MULTIPLE OF"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("INCORRECT PIN"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("SECURITY KEY VOILATION"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("PIN RETRIES EXCEEDED"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("INVALID TRANSACTION"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("DO NOT HONOUR"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("NO FROM ACCOUNT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("(1*"))
                                {
                                    if (ErrorCode.IndexOf(EJResult) == -1)
                                    {
                                        ErrorCode = ErrorCode + " " + EJResult;
                                    }
                                }
                                else if ((EJResult.Contains("M-")) && (EJResult.Contains("*" + ReferenceNumber + "*")))
                                {
                                    if (ErrorCode.IndexOf(EJResult) == -1)
                                    {
                                        ErrorCode = ErrorCode + " " + EJResult;
                                    }
                                }
                                else if ((EJResult.Contains(",M-")))
                                {
                                    string Remark3 = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("HOST TX TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + "HOST TX TIMEOUT";
                                }
                                else if (EJResult.Contains("SWITCH RESP. TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + "SWITCH RESP. TIMEOUT";
                                }
                                else if (EJResult.Contains("DISPENSER FAILURE"))
                                {
                                    ErrorCode = ErrorCode + " " + "DISPENSER FAILURE";
                                }
                                else if (EJResult.Contains("DECLINED OFFLINE"))
                                {
                                    ErrorCode = ErrorCode + " " + "DECLINED OFFLINE";
                                }
                                else if (EJResult.Contains("COMMAND REJECT"))
                                {
                                    ErrorCode = ErrorCode + " " + "COMMAND REJECT";
                                }
                                else if (EJResult.Contains("ISSUER TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + "ISSUER TIMEOUT";
                                }
                                else if (EJResult.Contains("UNCERTAIN DISPENSE"))
                                {
                                    ErrorCode = ErrorCode + " " + "UNCERTAIN DISPENSE";
                                }
                                else if (EJResult.Contains("POWER CYCLE"))
                                {
                                    ErrorCode = ErrorCode + " " + "POWER CYCLE HAPPENED DURING WITHDRAWAL TRANSACTION (CASH TAKEN)";
                                }
                                else if (EJResult.Contains("ERROR"))
                                {
                                    ErrorCode = ErrorCode + " " + "DISPENSE ERROR";
                                }
                                else if (EJResult.Contains("INVALID ISSUERRS"))
                                {
                                    ErrorCode = ErrorCode + " " + "INVALID ISSUERRS";
                                }
                                else if (EJResult.Contains("UNABLE"))
                                {
                                    ErrorCode = ErrorCode + " " + "UNABLE TO PROCESS";
                                }
                                else if (EJResult.Contains("SUPERVISOR MODE ENTRY"))
                                {
                                    k = EndIndex;
                                }


                                j = EndIndex;
                            }
                            catch (Exception exx)
                            {
                                j = EndIndex;
                            }
                        }
                    }
                    #region StanderedFields

                    ReversalFlag = false;
                    TxnsStatus = string.Empty;
                    DebitCreditType = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    CardType = string.Empty;

                    TxnsDateTimeMain = null;

                    card = false;
                    Terminal = false;
                    Acquirer = false;
                    Rev1 = false;
                    Rev2 = false;
                    ATM = false;
                    CDM = false;
                    POS = false;
                    ECOM = false;
                    IMPS = false;
                    UPI = false;
                    MicroATM = false;
                    MobileRecharge = false;
                    BAL = false;
                    MS = false;
                    PC = false;
                    CB = false;
                    RCA1 = false;
                    RCA2 = false;
                    //MC = false;
                    //VC = false;
                    OC = false;
                    D = false;
                    C = false;

                    if (CardNumber != "")
                    {
                        if (CardNumber.Substring(0, 1) == "4")
                        {
                            CardType = "VISA";
                        }
                        else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                        {
                            CardType = "MASTER";
                        }
                        else if (CardNumber.Substring(0, 2) == "62")
                        {
                            CardType = "CUP";
                        }
                        else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                        {
                            CardType = "RuPay";
                        }
                        else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                        {
                            CardType = "Maestro";
                        }
                    }


                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        try
                        {
                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + " " + TxnsTime, TxnDateTime, CultureInfo.InvariantCulture, DateTimeStyles.None);
                        }
                        catch
                        {

                        }

                    }

                    if (TerminalID.Length > 0 && !CassetteFetch)
                    {
                        DataTable dataTable = Common.GetCassetteInfoByTerminalId(_connectionString, fileImportRequest.ClientCode, TerminalID);

                        if (dataTable != null && dataTable.Rows.Count > 0)
                        {
                            Cassette1 = Convert.ToString(dataTable.Rows[0]["Cassette1"]);
                            Cassette2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                            Cassette3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                            Cassette4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);

                        }

                        dataTable = null;
                        CassetteFetch = true;
                    }


                    if (FileDate == null)
                    {
                        FileDate = TxnsDateTimeMain;
                    }

                    if (CassetteFetch)
                    {
                        //if (Notes != null && Notes.Length == 4)
                        //{
                        //    Denomination1 = Cassette1.Length == 0 ? Notes[0] : Convert.ToString(Convert.ToDecimal(Cassette1) * Convert.ToDecimal(Notes[0]));
                        //    Denomination2 = Cassette2.Length == 0 ? Notes[1] : Convert.ToString(Convert.ToDecimal(Cassette2) * Convert.ToDecimal(Notes[1]));
                        //    Denomination3 = Cassette3.Length == 0 ? Notes[2] : Convert.ToString(Convert.ToDecimal(Cassette3) * Convert.ToDecimal(Notes[2]));
                        //    Denomination4 = Cassette4.Length == 0 ? Notes[3] : Convert.ToString(Convert.ToDecimal(Cassette4) * Convert.ToDecimal(Notes[3]));
                        //}
                        //else
                        //{
                        //    Denomination1 = Notes[0];
                        //    Denomination2 = Notes[1];
                        //    Denomination3 = Notes[2];
                        //    Denomination4 = Notes[3];
                        //}

                        Denomination1 = Cassette1.Length == 0 ? "0" : Cassette1;
                        Denomination2 = Cassette2.Length == 0 ? "0" : Cassette2;
                        Denomination3 = Cassette3.Length == 0 ? "0" : Cassette3;
                        Denomination4 = Cassette4.Length == 0 ? "0" : Cassette4;
                    }
                    else
                    {
                        Denomination1 = "0";
                        Denomination2 = "0";
                        Denomination3 = "0";
                        Denomination4 = "0";
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                                break;
                            }
                        }
                    }


                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                                break;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i] == CardNumber.Substring(0, 6))
                            {
                                card = true;
                                break;
                            }
                            else if (BIN_No[i].Substring(0, 4) == CardNumber.Substring(0, 4))
                            {
                                card = true;
                                break;
                            }
                        }
                    }



                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                                break;
                            }
                        }
                    }
                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                                break;
                            }
                        }
                        for (i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                                break;
                            }
                        }
                    }




                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                    break;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                    break;
                                }
                            }
                        }

                        //if (POSType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < POSType.Length; i++)
                        //    {
                        //        if (POSType[i].ToString() == TxnsSubType)
                        //        {
                        //            POS = true;
                        //        }
                        //    }
                        //}
                        //if (ECOMType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < ECOMType.Length; i++)
                        //    {
                        //        if (ECOMType[i].ToString() == TxnsSubType)
                        //        {
                        //            ECOM = true;
                        //        }
                        //    }
                        //}

                        //if (IMPType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < IMPType.Length; i++)
                        //    {
                        //        if (IMPType[i].ToString() == TxnsSubType)
                        //        {
                        //            IMPS = true;
                        //        }
                        //    }
                        //}

                        //if (UPIType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < UPIType.Length; i++)
                        //    {
                        //        if (UPIType[i].ToString() == TxnsSubType)
                        //        {
                        //            UPI = true;
                        //        }
                        //    }
                        //}

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType)
                                {
                                    MicroATM = true;
                                    break;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                    break;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType)
                                {
                                    ATM = true;
                                    break;
                                }
                            }
                        }

                        //if (POSType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < POSType.Length; i++)
                        //    {
                        //        if (POSType[i].ToString() == ChannelType)
                        //        {
                        //            POS = true;
                        //        }
                        //    }
                        //}
                        //if (ECOMType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < ECOMType.Length; i++)
                        //    {
                        //        if (ECOMType[i].ToString() == ChannelType)
                        //        {
                        //            ECOM = true;
                        //        }
                        //    }
                        //}

                        //if (IMPType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < IMPType.Length; i++)
                        //    {
                        //        if (IMPType[i].ToString() == ChannelType)
                        //        {
                        //            IMPS = true;
                        //        }
                        //    }
                        //}

                        //if (UPIType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < UPIType.Length; i++)
                        //    {
                        //        if (UPIType[i].ToString() == ChannelType)
                        //        {
                        //            UPI = true;
                        //        }
                        //    }
                        //}

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType)
                                {
                                    MicroATM = true;
                                    break;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                    break;
                                }
                            }
                        }
                    }


                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                                break;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                                break;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                                break;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                                break;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                                break;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                                break;
                            }
                        }

                        for (i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode)
                            {
                                RCA2 = true;
                                break;
                            }
                        }
                    }


                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() == "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                                break;
                            }
                        }
                    }



                    if (DebitCode[0].ToString() != "")
                    {
                        for (i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                                break;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                                break;
                            }
                        }
                    }


                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    if (AcquirerID == string.Empty || AcquirerID == "")
                    {
                        if (Terminal == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        else if (Terminal == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        else if (Terminal == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }
                    else
                    {
                        if (Acquirer == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        else if (Acquirer == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        else if (Acquirer == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }

                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    if (RCA1 == true || RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }
                    else
                    {
                        TxnsStatus = "Unsucessfull";
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    else if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                    }
                    else if (POS)
                    {
                        TxnsSubTypeMain = "Purchase";
                    }
                    else if (ECOM)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (IMPS)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (MicroATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    else if (MobileRecharge)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (UPI)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }
                    else if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }
                    else if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }
                    else if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }


                    if (BAL || MS || PC || CB)
                    {
                        TxnsType = "Non-Financial";
                    }
                    else
                    {
                        TxnsType = "Financial";
                    }
                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    if (TxnsSubType == "GREEN PIN")
                    {
                        TxnsType = "Non-Financial";
                        TxnsSubTypeMain = "Green Pin";
                    }

                    if (TxnsSubType.Length == 0 && TxnsSubTypeMain.Length == 0 && ReqAmount > 0)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }

                    #endregion InitilizedField

                    //if (ReferenceNumber.Length == 0)
                    //{
                    //    if (AuthCode.Length == 6)
                    //    {
                    //        ReferenceNumber = AuthCode.Substring(2);
                    //    }
                    //}

                    //#endregion StanderedFields

                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }

                    if (CardNumber != "")
                    {
                        CardNumber = CardNumber.Replace("*", "X");

                        tempCardNumber = CardNumber;

                        CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);

                        ReserveField5 = ReserveField5.Replace(tempCardNumber, CardNumber);
                    }

                    if (ReserveField5.Length >= 3900)
                    {
                        ReserveField5 = ReserveField5.Substring(0, 3900);
                    }

                    if (ErrorCode.Length >= 1590)
                    {
                        ErrorCode = ErrorCode.Substring(0, 1590);
                    }

                    if (TxnsType == "Financial" && TxnsStatus == "Sucessfull")
                    {
                        Status = "1";
                        if (ReqAmount > 0 && TxnsAmount == 0)
                        {
                            TxnsAmount = ReqAmount;
                        }
                    }
                    else if (TxnsType == "Financial" && TxnsStatus == "Unsucessfull")
                    {
                        Status = "2";
                        if (ReqAmount > 0 && TxnsAmount == 0)
                        {
                            TxnsAmount = ReqAmount;
                        }
                    }

                    CustBalance = CustBalance == "" ? "0" : CustBalance;
                    Amount1 = Amount1 == "" ? "0" : Amount1;
                    Amount2 = Amount2 == "" ? "0" : Amount2;

                    ReserveField5 = ReserveField5.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");

                    //if (ReferenceNumber.Length > 0)
                    //{
                    //    PreviousReferenceNumber = ReferenceNumber;
                    //}
                    //else if (ReferenceNumber.Length == 0 && PreviousReferenceNumber.Length > 0 && tempErrorCode.Contains("HOST TX TIMEOUT"))
                    //{
                    //    ReferenceNumber = Convert.ToString(Convert.ToInt32(PreviousReferenceNumber) );
                    //    PreviousReferenceNumber = ReferenceNumber;
                    //}
                    //else if (ReferenceNumber.Length == 0 && PreviousReferenceNumber.Length > 0 )
                    //{
                    //    ReferenceNumber = Convert.ToString(Convert.ToInt32(PreviousReferenceNumber) + 1);
                    //    PreviousReferenceNumber = ReferenceNumber;
                    //}

                    tempErrorCode = ErrorCode;

                    if (TxnsDateTimeMain != null && ReferenceNumber != "")
                    {
                        _DataTable.Rows.Add(
                                        ClientID
                                        , (int)TxnsChannelID.ATM
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , CardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , Convert.ToDecimal(CustBalance)
                                        , TxnsDateTimeMain
                                        , TxnsAmount
                                        , ReqAmount
                                        , Convert.ToDecimal(Amount1)
                                        , Convert.ToDecimal(Amount2)
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubTypeMain
                                        , TxnsEntryType
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , AuthCode
                                        , CurrencyCode
                                        , Opcode
                                        , ErrorCode
                                        , ReversalFlag
                                        , Notes[0]
                                        , Notes[1]
                                        , Notes[2]
                                        , Notes[3]
                                        , Denomination1
                                        , Denomination2
                                        , Denomination3
                                        , Denomination4
                                        , Dispenseds[1]
                                        , Dispenseds[2]
                                        , Dispenseds[3]
                                        , Dispenseds[4]
                                        , Rejecteds[1]
                                        , Rejecteds[2]
                                        , Rejecteds[3]
                                        , Rejecteds[4]
                                        , Remainings[1]
                                        , Remainings[2]
                                        , Remainings[3]
                                        , Remainings[4]
                                        , ReserveField1
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , Status 
                                        , ECardNumber.Trim()
                                        );

                    }

                    if (ATRRECEIVEDT <= 1)
                    {
                        ATRRECEIVEDT = 0;
                    }
                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                fileImportRequest.InsertCount = _DataTable.Rows.Count;
            }
            return _DataTable;
        }
        public string ExtractNumber(string original)
        {
            return new string(original.Where(c => Char.IsDigit(c) || c == '.').ToArray());
        }

        public DataTable ASP_SplitDataMachineCounter2(string path, string FileName, DataTable dt, out int InsertCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTableMCCounter = new DataTable();
            _DataTableMCCounter.Columns.Add("ClientID", typeof(int));
            _DataTableMCCounter.Columns.Add("TerminalID", typeof(string));
            _DataTableMCCounter.Columns.Add("CurrentEOD", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("MachineOp100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOpTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDisTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRemTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoadTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosingTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("RETRACTNOTESCOUNT", typeof(string));
            _DataTableMCCounter.Columns.Add("CassetteRemarks", typeof(string));
            _DataTableMCCounter.Columns.Add("Filename", typeof(string));
            _DataTableMCCounter.Columns.Add("FilePath", typeof(string));
            _DataTableMCCounter.Columns.Add("FileDate", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("CreatedON", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("Createdby", typeof(string));


            InsertCount = 0;

            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;

            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            DateTime? FileDate = null;
            try
            {
                FileDate = DateTime.ParseExact(FileName.Substring(FileName.IndexOf("_") + 1, 8).Trim(), "yyyyMMdd", CultureInfo.InvariantCulture);
            }
            catch
            {

            }

            string TerminalId = string.Empty;


            //decimal MCOp100 = 0;
            //decimal MCOp200 = 0;
            //decimal MCOp500 = 0;
            //decimal MCOp2000 = 0;
            decimal MCDis100 = 0;
            decimal MCDis200 = 0;
            decimal MCDis500 = 0;
            decimal MCDis2000 = 0;
            decimal MCRem100 = 0;
            decimal MCRem200 = 0;
            decimal MCRem500 = 0;
            decimal MCRem2000 = 0;
            decimal MCClosing100 = 0;
            decimal MCClosing200 = 0;
            decimal MCClosing500 = 0;
            decimal MCClosing2000 = 0;
            decimal RETRACTNOTESCOUNT = 0;

            string CassetteMaster1 = string.Empty;
            string CassetteMaster2 = string.Empty;
            string CassetteMaster3 = string.Empty;
            string CassetteMaster4 = string.Empty;

            string[] Type1 = new string[1];
            string[] Type2 = new string[1];
            string[] Type3 = new string[1];
            string[] Type4 = new string[1];


            //string Rejected1 = string.Empty;
            //string Rejected2 = string.Empty;
            //string Rejected3 = string.Empty;
            //string Rejected4 = string.Empty;
            //string Remaining1 = string.Empty;
            //string Remaining2 = string.Empty;
            //string Remaining3 = string.Empty;
            //string Remaining4 = string.Empty;
            //string Dispense1 = string.Empty;
            //string Dispense2 = string.Empty;
            //string Dispense3 = string.Empty;
            //string Dispense4 = string.Empty;

            //string TotalDispense1 = string.Empty;
            //string TotalDispense2 = string.Empty;
            //string TotalDispense3 = string.Empty;
            //string TotalDispense4 = string.Empty; 

            DateTime? CounterDate = null;

            string line = string.Empty;
            string EJResult = string.Empty;

            string[] TotalCountArray = File.ReadAllLines(path);

            string RespLine = string.Empty;
            string[] CASSETTE = new string[3];

            if (TotalCountArray != null && TotalCountArray.Length > 0)
            {
                for (int j = 0; j <= TotalCountArray.Length; j++)
                {  
                    StartIndex = Common.GetIndex(TotalCountArray, j - 1, "TRANSACTION START");
                    EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "TRANSACTION START");

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex; k <= EndIndex - 1; k++)
                        {
                            try
                            {
                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = Common.RemoveAdditionalChars(line);

                                if (EJResult.Contains("DATE") && EJResult.Contains("TIME") && EJResult.Contains("ATM-ID") && EJResult.Contains("RESP"))
                                {
                                    RespLine = Common.RemoveAdditionalChars(Regex.Replace(TotalCountArray[k + 1].ToString(), "[^ -~]+", string.Empty));

                                    if (RespLine.Split(" ").Length > 3)
                                    { 
                                        TerminalId = RespLine.Split(" ")[2].Trim();
                                    }
                                }
                                else if (EJResult.Contains("DATE") && EJResult.Contains("TIME") && EJResult.Contains("ATM-ID"))
                                {
                                    RespLine = Common.RemoveAdditionalChars(Regex.Replace(TotalCountArray[k + 1].ToString(), "[^ -~]+", string.Empty));

                                    if (RespLine.Split(" ").Length > 2)
                                    { 
                                        TerminalId = RespLine.Split(" ")[2].Trim();
                                    }
                                }

                                if (TerminalId.Length > 0)
                                {
                                    break;
                                }

                                j = EndIndex;
                            }
                            catch
                            {
                                j = EndIndex;
                            }
                        }
                    }

                    if (TerminalId.Length > 0)
                    {
                        break;
                    }
                }
            }

            if (TerminalId.Length > 0)
            {
                DataTable dataTable = Common.GetCassetteInfoByTerminalId(_connectionString, ClientID.ToString(), TerminalId);

                if (dataTable != null && dataTable.Rows.Count > 0)
                {
                    CassetteMaster1 = Convert.ToString(dataTable.Rows[0]["Cassette1"]);
                    CassetteMaster2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                    CassetteMaster3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                    CassetteMaster4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);
                }
                else
                {
                    CassetteMaster1 = "100";
                    CassetteMaster1 = "200";
                    CassetteMaster1 = "500";
                    CassetteMaster1 = "2000";
                }

                dataTable = null;
            }

            if (TotalCountArray != null && TotalCountArray.Length > 0 && TerminalId.Length > 0)
            {
                for (int j = 0; j <= TotalCountArray.Length; j++)
                {
                    try
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j, "SUPERVISOR MODE ENTRY");
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "SUPERVISOR MODE EXIT");

                        if (StartIndex != -1 && EndIndex != -1)
                        {
                            for (int k = StartIndex + 1; k <= EndIndex - 1; k++)
                            {
                                try
                                {
                                    line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                    EJResult = Common.RemoveAdditionalChars(line);

                                    if (EJResult.Contains("CASH DISPENSED"))
                                    {
                                        string[] Type1Type2 = TotalCountArray[k + 1].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        string[] Type3Type4 = TotalCountArray[k + 2].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();

                                        if (CassetteMaster1.Length > 0 && Convert.ToInt32(CassetteMaster1) > 0)
                                        {
                                            MCDis100 += CassetteMaster1 == "100" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCDis200 += CassetteMaster1 == "200" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCDis500 += CassetteMaster1 == "500" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCDis2000 += CassetteMaster1 == "2000" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                        }

                                        if (CassetteMaster2.Length > 0 && Convert.ToInt32(CassetteMaster2) > 0)
                                        {
                                            MCDis100 += CassetteMaster2 == "100" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCDis200 += CassetteMaster2 == "200" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCDis500 += CassetteMaster2 == "500" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCDis2000 += CassetteMaster2 == "2000" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                        }

                                        if (CassetteMaster3.Length > 0 && Convert.ToInt32(CassetteMaster3) > 0)
                                        {
                                            MCDis100 += CassetteMaster3 == "100" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCDis200 += CassetteMaster3 == "200" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCDis500 += CassetteMaster3 == "500" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCDis2000 += CassetteMaster3 == "2000" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                        }


                                        if (CassetteMaster4.Length > 0 && Convert.ToInt32(CassetteMaster4) > 0)
                                        {
                                            MCDis100 += CassetteMaster4 == "100" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCDis200 += CassetteMaster4 == "200" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCDis500 += CassetteMaster4 == "500" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCDis2000 += CassetteMaster4 == "2000" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                        }

                                    }
                                    else if (EJResult.Contains("CASH REMAINING"))
                                    {
                                        string[] Type1Type2 = TotalCountArray[k + 1].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        string[] Type3Type4 = TotalCountArray[k + 2].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();

                                        if (CassetteMaster1.Length > 0 && Convert.ToInt32(CassetteMaster1) > 0)
                                        {
                                            MCRem100 += CassetteMaster1 == "100" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCRem200 += CassetteMaster1 == "200" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCRem500 += CassetteMaster1 == "500" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCRem2000 += CassetteMaster1 == "2000" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                        }

                                        if (CassetteMaster2.Length > 0 && Convert.ToInt32(CassetteMaster2) > 0)
                                        {
                                            MCRem100 += CassetteMaster2 == "100" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCRem200 += CassetteMaster2 == "200" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCRem500 += CassetteMaster2 == "500" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCRem2000 += CassetteMaster2 == "2000" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                        }

                                        if (CassetteMaster3.Length > 0 && Convert.ToInt32(CassetteMaster3) > 0)
                                        {
                                            MCRem100 += CassetteMaster3 == "100" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCRem200 += CassetteMaster3 == "200" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCRem500 += CassetteMaster3 == "500" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCRem2000 += CassetteMaster3 == "2000" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                        }


                                        if (CassetteMaster4.Length > 0 && Convert.ToInt32(CassetteMaster4) > 0)
                                        {
                                            MCRem100 += CassetteMaster4 == "100" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCRem200 += CassetteMaster4 == "200" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCRem500 += CassetteMaster4 == "500" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCRem2000 += CassetteMaster4 == "2000" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                        }

                                    }
                                    else if (EJResult.Contains("CASH ADDED"))
                                    {
                                        string[] Type1Type2 = Common.RemoveAdditionalChars(TotalCountArray[k + 1]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        string[] Type3Type4 = Common.RemoveAdditionalChars(TotalCountArray[k + 2]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();

                                        if (Convert.ToInt32(Type1Type2[3]) > 0 || Convert.ToInt32(Type1Type2[7]) > 0 || Convert.ToInt32(Type3Type4[3]) > 0 || Convert.ToInt32(Type3Type4[7]) > 0)
                                        {
                                            if (CassetteMaster1.Length > 0 && Convert.ToInt32(CassetteMaster1) > 0)
                                            {
                                                Type1 = Regex.Split(Type1Type2[3].Trim(), @"\D+");
                                                if (Type1.Length > 0)
                                                {
                                                    MCClosing100 += CassetteMaster1 == "100" ? Convert.ToDecimal(Type1[0]) : 0;
                                                    MCClosing200 += CassetteMaster1 == "200" ? Convert.ToDecimal(Type1[0]) : 0;
                                                    MCClosing500 += CassetteMaster1 == "500" ? Convert.ToDecimal(Type1[0]) : 0;
                                                    MCClosing2000 += CassetteMaster1 == "2000" ? Convert.ToDecimal(Type1[0]) : 0;
                                                }
                                            }

                                            if (CassetteMaster2.Length > 0 && Convert.ToInt32(CassetteMaster2) > 0)
                                            {
                                                Type2 = Regex.Split(Type1Type2[7].Trim(), @"\D+");
                                                if (Type2.Length > 0)
                                                {
                                                    MCClosing100 += CassetteMaster2 == "100" ? Convert.ToDecimal(Type2[0]) : 0;
                                                    MCClosing200 += CassetteMaster2 == "200" ? Convert.ToDecimal(Type2[0]) : 0;
                                                    MCClosing500 += CassetteMaster2 == "500" ? Convert.ToDecimal(Type2[0]) : 0;
                                                    MCClosing2000 += CassetteMaster2 == "2000" ? Convert.ToDecimal(Type2[0]) : 0;
                                                }
                                            }

                                            if (CassetteMaster3.Length > 0 && Convert.ToInt32(CassetteMaster3) > 0)
                                            {
                                                Type3 = Regex.Split(Type3Type4[3].Trim(), @"\D+");
                                                if (Type3.Length > 0)
                                                {
                                                    MCClosing100 += CassetteMaster3 == "100" ? Convert.ToDecimal(Type3[0]) : 0;
                                                    MCClosing200 += CassetteMaster3 == "200" ? Convert.ToDecimal(Type3[0]) : 0;
                                                    MCClosing500 += CassetteMaster3 == "500" ? Convert.ToDecimal(Type3[0]) : 0;
                                                    MCClosing2000 += CassetteMaster3 == "2000" ? Convert.ToDecimal(Type3[0]) : 0;
                                                }
                                            }


                                            if (CassetteMaster4.Length > 0 && Convert.ToInt32(CassetteMaster4) > 0)
                                            {
                                                Type4 = Regex.Split(Type3Type4[7].Trim(), @"\D+");
                                                if (Type4.Length > 0)
                                                {
                                                    MCClosing100 += CassetteMaster4 == "100" ? Convert.ToDecimal(Type4[0]) : 0;
                                                    MCClosing200 += CassetteMaster4 == "200" ? Convert.ToDecimal(Type4[0]) : 0;
                                                    MCClosing500 += CassetteMaster4 == "500" ? Convert.ToDecimal(Type4[0]) : 0;
                                                    MCClosing2000 += CassetteMaster4 == "2000" ? Convert.ToDecimal(Type4[0]) : 0;
                                                }
                                            }
                                            try
                                            {
                                                CounterDate = DateTime.ParseExact(TotalCountArray[k + 5].Substring(3, 19).Trim(), new string[] { "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyY HH:mm" }, CultureInfo.InvariantCulture);
                                            }
                                            catch
                                            {
                                            }
                                        }
                                    }
                                    //if (line.Contains(" CASSETTE") && CASSETTE_Count == 0)
                                    //{
                                    //    CASSETTE_Count++;

                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Cassette1 = CASSETTE[1].Trim().ToString();
                                    //    Cassette2 = CASSETTE[2].Trim().ToString();
                                    //}
                                    //else if (line.Contains(" CASSETTE") && CASSETTE_Count == 1)
                                    //{
                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Cassette3 = CASSETTE[1].Trim().ToString();
                                    //    Cassette4 = CASSETTE[2].Trim().ToString();
                                    //}

                                    //if (line.Contains("+REJECTED") && RejectCount == 0)
                                    //{
                                    //    RejectCount++;

                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Rejected1 = CASSETTE[1].Trim().ToString();
                                    //    Rejected2 = CASSETTE[2].Trim().ToString();
                                    //}
                                    //else if (line.Contains("+REJECTED") && RejectCount == 1)
                                    //{
                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Rejected3 = CASSETTE[1].Trim().ToString();
                                    //    Rejected4 = CASSETTE[2].Trim().ToString();

                                    //    RETRACTNOTESCOUNT = Convert.ToDecimal(Rejected1) + Convert.ToDecimal(Rejected2) + Convert.ToDecimal(Rejected3) + Convert.ToDecimal(Rejected4);
                                    //}

                                    //if (line.Contains("=REMAINING") && REMAINING_Count == 0)
                                    //{
                                    //    REMAINING_Count++;

                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Remaining1 = CASSETTE[1].Trim().ToString();
                                    //    Remaining2 = CASSETTE[2].Trim().ToString();
                                    //}
                                    //else if (line.Contains("=REMAINING") && REMAINING_Count == 1)
                                    //{
                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Remaining3 = CASSETTE[1].Trim().ToString();
                                    //    Remaining4 = CASSETTE[2].Trim().ToString();
                                    //}
                                    //if (line.Contains("+DISPENSED") && DISPENSED_Count == 0)
                                    //{
                                    //    DISPENSED_Count++;

                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Dispense1 = CASSETTE[1].Trim().ToString();
                                    //    Dispense2 = CASSETTE[2].Trim().ToString();
                                    //}
                                    //else if (line.Contains("+DISPENSED") && DISPENSED_Count == 1)
                                    //{
                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Dispense3 = CASSETTE[1].Trim().ToString();
                                    //    Dispense4 = CASSETTE[2].Trim().ToString();
                                    //}

                                    //if (line.Contains("=TOTAL") && TOTAL_Count == 0)
                                    //{
                                    //    TOTAL_Count++;

                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    TotalDispense1 = CASSETTE[1].Trim().ToString();
                                    //    TotalDispense2 = CASSETTE[2].Trim().ToString();

                                    //}
                                    //else if (line.Contains("=TOTAL") && TOTAL_Count == 1)
                                    //{
                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    TotalDispense3 = CASSETTE[1].Trim().ToString();
                                    //    TotalDispense4 = CASSETTE[2].Trim().ToString();
                                    //}

                                    //if (EJResult.Contains("DATE-TIME"))
                                    //{
                                    //    string[] date1 = EJResult.Split('=').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    CounterDate = DateTime.ParseExact(date1[1].Substring(0, 14).Trim().ToString(), "MM/dd/yy HH:mm", CultureInfo.InvariantCulture);

                                    //}

                                    j = EndIndex;

                                }
                                catch
                                {
                                    j = EndIndex;
                                }
                            }


                            try
                            {
                                if (MCClosing100 != 0 || MCClosing200 != 0 || MCClosing500 != 0 || MCClosing2000 != 0)
                                {
                                    _DataTableMCCounter.Rows.Add(
                                    ClientID, TerminalId, CounterDate,
                                    (MCRem100 + MCDis100), (MCRem200 + MCDis200), (MCRem500 + MCDis500), (MCRem2000 + MCDis2000),
                                    ((MCRem100 + MCDis100) * 100) + ((MCRem200 + MCDis200) * 200) + ((MCRem500 + MCDis500) * 500) + ((MCRem2000 + MCDis2000) * 2000),

                                    MCDis100, MCDis200, MCDis500, MCDis2000,
                                    (MCDis100 * 100) + (MCDis200 * 200) + (MCDis500 * 500) + (MCDis2000 * 2000),

                                    MCRem100, MCRem200, MCRem500, MCRem2000,
                                    (MCRem100 * 100) + (MCRem200 * 200) + (MCRem500 * 500) + (MCRem2000 * 2000),

                                    MCClosing100 - MCRem100, MCClosing200 - MCRem200, MCClosing500 - MCRem500, MCClosing2000 - MCRem2000,
                                    ((MCClosing100 - MCRem100) * 100) + ((MCClosing200 - MCRem200) * 200) + ((MCClosing500 - MCRem500) * 500) + ((MCClosing2000 - MCRem2000) * 2000),

                                    MCClosing100, MCClosing200, MCClosing500, MCClosing2000,
                                    (MCClosing100 * 100) + (MCClosing200 * 200) + (MCClosing500 * 500) + (MCClosing2000 * 2000),

                                    RETRACTNOTESCOUNT, string.Empty, FileName, path, FileDate, System.DateTime.Now, UserName);
                                }

                                MCDis100 = 0;
                                MCDis200 = 0;
                                MCDis500 = 0;
                                MCDis2000 = 0;
                                MCRem100 = 0;
                                MCRem200 = 0;
                                MCRem500 = 0;
                                MCRem2000 = 0;
                                MCClosing100 = 0;
                                MCClosing200 = 0;
                                MCClosing500 = 0;
                                MCClosing2000 = 0;
                                RETRACTNOTESCOUNT = 0;

                            }
                            catch (Exception ex)
                            {
                                DBLog.InsertLogs("Adding machine counter in data table => " + ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                               // DBLog.InsertLogs("Adding machine counter in data table => " + ex.Message, TerminalId, "SplitterCITIZEN.cs", "ASP_SplitDataMachineCounter", LineNo, FileName, UserName, 'E', _connectionString);
                            }
                        }

                        //MCOp100 = 0;
                        //MCOp200 = 0;
                        //MCOp500 = 0;
                        //MCOp2000 = 0;
                     

                        Array.Clear(Type1, 0, Type1.Length);
                        Array.Clear(Type2, 0, Type2.Length);
                        Array.Clear(Type3, 0, Type3.Length);
                        Array.Clear(Type4, 0, Type4.Length);

                        //Rejected1 = string.Empty;
                        //Rejected2 = string.Empty;
                        //Rejected3 = string.Empty;
                        //Rejected4 = string.Empty;
                        //Remaining1 = string.Empty;
                        //Remaining2 = string.Empty;
                        //Remaining3 = string.Empty;
                        //Remaining4 = string.Empty;
                        //Dispense1 = string.Empty;
                        //Dispense2 = string.Empty;
                        //Dispense3 = string.Empty;
                        //Dispense4 = string.Empty;

                        //TotalDispense1 = string.Empty;
                        //TotalDispense2 = string.Empty;
                        //TotalDispense3 = string.Empty;
                        //TotalDispense4 = string.Empty;


                    }
                    catch (Exception ex)
                    {
                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }
                }



            }

            if (_DataTableMCCounter.Rows.Count > 0)
            {
                InsertCount = _DataTableMCCounter.Rows.Count;
            }

            return _DataTableMCCounter;
        }

        public DataTable ASP_SplitDataSwitchCounter(string path, string FileName, DataTable dt, out int InsertCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTableSWCounter = new DataTable();
            _DataTableSWCounter.Columns.Add("ClientID", typeof(int));
            _DataTableSWCounter.Columns.Add("TerminalID", typeof(string));
            _DataTableSWCounter.Columns.Add("CurrentEOD", typeof(DateTime));
            _DataTableSWCounter.Columns.Add("SWOp100", typeof(string));
            _DataTableSWCounter.Columns.Add("SWOp200", typeof(string));
            _DataTableSWCounter.Columns.Add("SWOp500", typeof(string));
            _DataTableSWCounter.Columns.Add("SWOp2000", typeof(string));
            _DataTableSWCounter.Columns.Add("SWOpTotal", typeof(string));
            _DataTableSWCounter.Columns.Add("SWDis100", typeof(string));
            _DataTableSWCounter.Columns.Add("SWDis200", typeof(string));
            _DataTableSWCounter.Columns.Add("SWDis500", typeof(string));
            _DataTableSWCounter.Columns.Add("SWDis2000", typeof(string));
            _DataTableSWCounter.Columns.Add("SWDisTotal", typeof(string));
            _DataTableSWCounter.Columns.Add("SWRem100", typeof(string));
            _DataTableSWCounter.Columns.Add("SWRem200", typeof(string));
            _DataTableSWCounter.Columns.Add("SWRem500", typeof(string));
            _DataTableSWCounter.Columns.Add("SWRem2000", typeof(string));
            _DataTableSWCounter.Columns.Add("SWRemTotal", typeof(string));
            _DataTableSWCounter.Columns.Add("SWLoad100", typeof(string));
            _DataTableSWCounter.Columns.Add("SWLoad200", typeof(string));
            _DataTableSWCounter.Columns.Add("SWLoad500", typeof(string));
            _DataTableSWCounter.Columns.Add("SWLoad2000", typeof(string));
            _DataTableSWCounter.Columns.Add("SWLoadTotal", typeof(string));
            _DataTableSWCounter.Columns.Add("SWClosing100", typeof(string));
            _DataTableSWCounter.Columns.Add("SWClosing200", typeof(string));
            _DataTableSWCounter.Columns.Add("SWClosing500", typeof(string));
            _DataTableSWCounter.Columns.Add("SWClosing2000", typeof(string));
            _DataTableSWCounter.Columns.Add("SWClosingTotal", typeof(string));
            _DataTableSWCounter.Columns.Add("Filename", typeof(string));
            _DataTableSWCounter.Columns.Add("FilePath", typeof(string));
            _DataTableSWCounter.Columns.Add("FileDate", typeof(DateTime));
            _DataTableSWCounter.Columns.Add("CreatedON", typeof(DateTime));
            _DataTableSWCounter.Columns.Add("Createdby", typeof(string));

            InsertCount = 0;

            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;


            string SWOp100 = "0";
            string SWOp200 = "0";
            string SWOp500 = "0";
            string SWOp2000 = "0";
            string SWOpTotal = "0";
            string SWDis100 = "0";
            string SWDis200 = "0";
            string SWDis500 = "0";
            string SWDis2000 = "0";
            string SWDisTotal = "0";
            string SWRem100 = "0";
            string SWRem200 = "0";
            string SWRem500 = "0";
            string SWRem2000 = "0";
            string SWRemTotal = "0";
            string SWLoad100 = "0";
            string SWLoad200 = "0";
            string SWLoad500 = "0";
            string SWLoad2000 = "0";
            string SWLoadTotal = "0";
            string SWClosing100 = "0";
            string SWClosing200 = "0";
            string SWClosing500 = "0";
            string SWClosing2000 = "0";
            string SWClosingTotal = "0";
            string LastSWDis100 = "0";
            string LastSWDis200 = "0";
            string LastSWDis500 = "0";
            string LastSWDis2000 = "0";


            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            DateTime? FileDate = null;
            try
            {
                FileDate = DateTime.ParseExact(FileName.Substring(FileName.IndexOf("_") + 1, 8).Trim(), "yyyyMMdd", CultureInfo.InvariantCulture);
            }
            catch
            {

            }

            string TerminalId = string.Empty;

            DateTime? CounterDate = null;

            string line = string.Empty;
            string EJResult = string.Empty;

            string[] TotalCountArray = File.ReadAllLines(path);

            //if (TotalCountArray != null && TotalCountArray.Length > 0)
            //{
            //    for (int j = 0; j <= TotalCountArray.Length; j++)
            //    {
            //        StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID");
            //        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "BALANCE");

            //        if (StartIndex != -1 && EndIndex != -1)
            //        {
            //            for (int k = StartIndex; k <= EndIndex - 1; k++)
            //            {
            //                try
            //                {
            //                    line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
            //                    EJResult = Common.RemoveAdditionalChars(line);

            //                    if (EJResult.Contains("ATM ID"))
            //                    {
            //                        TerminalId = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
            //                        if (TerminalId.Length > 0)
            //                        {
            //                            break;
            //                        }
            //                    }
            //                    j = EndIndex;
            //                }
            //                catch
            //                {
            //                    j = EndIndex;
            //                }
            //            }
            //        }

            //        if (TerminalId.Length > 0)
            //        {
            //            break;
            //        }
            //    }
            //}

            string CassetteMaster1 = string.Empty;
            string CassetteMaster2 = string.Empty;
            string CassetteMaster3 = string.Empty;
            string CassetteMaster4 = string.Empty;

            if (TerminalId.Length > 0)
            {
                DataTable dataTable = Common.GetCassetteInfoByTerminalId(_connectionString, ClientID.ToString(), TerminalId);

                if (dataTable != null && dataTable.Rows.Count > 0)
                {
                    CassetteMaster1 = Convert.ToString(dataTable.Rows[0]["Cassette1"]);
                    CassetteMaster2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                    CassetteMaster3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                    CassetteMaster4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);

                }

                dataTable = null;
            }

            if (TotalCountArray != null && TotalCountArray.Length > 0 && TerminalId.Length > 0)
            {
                for (int j = 0; j <= TotalCountArray.Length; j++)
                {
                    try
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j, "C1 STR");
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "C4 OUT");

                        if (StartIndex != -1 && EndIndex != -1)
                        {
                            for (int k = StartIndex + 1; k <= EndIndex - 1; k++)
                            {
                                try
                                {
                                    line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                    EJResult = Common.RemoveAdditionalChars(line);

                                    #region Switch Opening
                                    if (EJResult.Contains("C1 STR") && string.IsNullOrEmpty(SWOp100))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 100);
                                                SWOp100 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWOp100 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C2 STR") && string.IsNullOrEmpty(SWOp200))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", ""); ;
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 200);
                                                SWOp200 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWOp200 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C3 STR") && string.IsNullOrEmpty(SWOp500))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 500);
                                                SWOp500 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWOp500 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C4 STR") && string.IsNullOrEmpty(SWOp2000))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 2000);
                                                SWOp2000 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWOp2000 = "0";
                                        }
                                    }
                                    #endregion

                                    #region Switch Loading
                                    if (EJResult.Contains("C1 INC") && (string.IsNullOrEmpty(SWLoad100) || SWLoad100.Equals("0")))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C1", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 100);
                                                SWLoad100 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWLoad100 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C2 INC") && (string.IsNullOrEmpty(SWLoad200) || SWLoad200.Equals("0")))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C2", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 200);
                                                SWLoad200 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWLoad200 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C3 INC") && (string.IsNullOrEmpty(SWLoad500) || SWLoad500.Equals("0")))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C3", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 500);
                                                SWLoad500 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWLoad500 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C4 INC") && (string.IsNullOrEmpty(SWLoad2000) || SWLoad2000.Equals("0")))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C4", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 2000);
                                                SWLoad2000 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWLoad2000 = "0";
                                        }
                                    }

                                    #endregion

                                    #region Switch Dispense &  Switch Remaining

                                    if (EJResult.Contains("C1 OUT") && string.IsNullOrEmpty(SWDis100))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C1", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 100);
                                                SWDis100 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWDis100 = "0";
                                        }

                                        amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 100);
                                                SWRem100 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWRem100 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C2 OUT") && string.IsNullOrEmpty(SWDis200))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C2", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 200);
                                                SWDis200 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWDis200 = "0";
                                        }

                                        amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", ""); ;
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 200);
                                                SWRem200 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWRem200 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C3 OUT") && string.IsNullOrEmpty(SWDis500))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C3", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 500);
                                                SWDis500 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWDis500 = "0";
                                        }


                                        amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 500);
                                                SWRem500 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWRem500 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C4 OUT") && string.IsNullOrEmpty(SWDis2000))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C4", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 2000);
                                                SWDis2000 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWDis2000 = "0";
                                        }

                                        amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 2000);
                                                SWRem2000 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWRem2000 = "0";
                                        }
                                    }

                                    //if (EJResult.Contains("DIS "))
                                    //{
                                    //    string[] result_DTTime = EJResult.Split(' ');
                                    //    SWDis100 = result_DTTime[1].TrimStart('0');
                                    //    SWDis100 = String.IsNullOrEmpty(SWDis100) ? "0" : SWDis100;
                                    //    SWDis200 = result_DTTime[2].TrimStart('0');
                                    //    SWDis200 = String.IsNullOrEmpty(SWDis200) ? "0" : SWDis200;
                                    //    SWDis500 = result_DTTime[3].TrimStart('0');
                                    //    SWDis500 = String.IsNullOrEmpty(SWDis500) ? "0" : SWDis500;
                                    //    SWDis2000 = result_DTTime[4].TrimStart('0');
                                    //    SWDis2000 = String.IsNullOrEmpty(SWDis2000) ? "0" : SWDis2000;
                                    //}

                                    #endregion



                                    #region Switch Closing
                                    if (EJResult.Contains("C1 END"))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 100);
                                                SWClosing100 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWClosing100 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C2 END"))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 200);
                                                SWClosing200 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWClosing200 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C3 END"))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 500);
                                                SWClosing500 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWClosing500 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C4 END"))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 2000);
                                                SWClosing2000 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWClosing2000 = "0";
                                        }
                                    }


                                    #endregion

                                    j = EndIndex;

                                }
                                catch
                                {
                                    j = EndIndex;
                                }
                            }
                        }

                        #region Storing switch counter in datatable
                        SWRem100 = string.IsNullOrEmpty(SWRem100) ? "0" : SWRem100;
                        SWRem200 = string.IsNullOrEmpty(SWRem200) ? "0" : SWRem200;
                        SWRem500 = string.IsNullOrEmpty(SWRem500) ? "0" : SWRem500;
                        SWRem2000 = string.IsNullOrEmpty(SWRem2000) ? "0" : SWRem2000;
                        SWRemTotal = string.IsNullOrEmpty(SWRemTotal) ? "0" : SWRemTotal;
                        SWLoad100 = string.IsNullOrEmpty(SWLoad100) ? "0" : SWLoad100;
                        SWLoad200 = string.IsNullOrEmpty(SWLoad200) ? "0" : SWLoad200;
                        SWLoad500 = string.IsNullOrEmpty(SWLoad500) ? "0" : SWLoad500;
                        SWLoad2000 = string.IsNullOrEmpty(SWLoad2000) ? "0" : SWLoad2000;
                        SWLoadTotal = string.IsNullOrEmpty(SWLoadTotal) ? "0" : SWLoadTotal;

                        if (Convert.ToDecimal(SWRem100) > 0 || Convert.ToDecimal(SWRem200) > 0 || Convert.ToDecimal(SWRem500) > 0 || Convert.ToDecimal(SWRem2000) > 0 ||
                            Convert.ToDecimal(SWLoad100) > 0 || Convert.ToDecimal(SWLoad200) > 0 || Convert.ToDecimal(SWLoad500) > 0 || Convert.ToDecimal(SWLoad2000) > 0)
                        {
                            SWOp100 = string.IsNullOrEmpty(SWOp100) ? "0" : SWOp100;
                            SWOp200 = string.IsNullOrEmpty(SWOp200) ? "0" : SWOp200;
                            SWOp500 = string.IsNullOrEmpty(SWOp500) ? "0" : SWOp500;
                            SWOp2000 = string.IsNullOrEmpty(SWOp2000) ? "0" : SWOp2000;
                            SWOpTotal = string.IsNullOrEmpty(SWOpTotal) ? "0" : SWOpTotal;
                            SWDis100 = string.IsNullOrEmpty(SWDis100) ? "0" : SWDis100;
                            SWDis200 = string.IsNullOrEmpty(SWDis200) ? "0" : SWDis200;
                            SWDis500 = string.IsNullOrEmpty(SWDis500) ? "0" : SWDis500;
                            SWDis2000 = string.IsNullOrEmpty(SWDis2000) ? "0" : SWDis2000;
                            SWDisTotal = string.IsNullOrEmpty(SWDisTotal) ? "0" : SWDisTotal;
                            SWClosing100 = string.IsNullOrEmpty(SWClosing100) ? "0" : SWClosing100;
                            SWClosing200 = string.IsNullOrEmpty(SWClosing200) ? "0" : SWClosing200;
                            SWClosing500 = string.IsNullOrEmpty(SWClosing500) ? "0" : SWClosing500;
                            SWClosing2000 = string.IsNullOrEmpty(SWClosing2000) ? "0" : SWClosing2000;
                            SWClosingTotal = string.IsNullOrEmpty(SWClosingTotal) ? "0" : SWClosingTotal;

                            _DataTableSWCounter.Rows.Add(
                                //TerminalId, TxnsDateTime,
                                TerminalId, CounterDate,
                                //-- Opening
                                Convert.ToDecimal(SWOp100), Convert.ToDecimal(SWOp200), Convert.ToDecimal(SWOp500), Convert.ToDecimal(SWOp2000),
                                ((Convert.ToDecimal(SWOp100)) * 100) + ((Convert.ToDecimal(SWOp200)) * 200) + ((Convert.ToDecimal(SWOp500)) * 500) + ((Convert.ToDecimal(SWOp2000)) * 2000),
                                //-- Dispense
                                Convert.ToDecimal(SWDis100), Convert.ToDecimal(SWDis200), Convert.ToDecimal(SWDis500), Convert.ToDecimal(SWDis2000),
                                ((Convert.ToDecimal(SWDis100)) * 100) + ((Convert.ToDecimal(SWDis200)) * 200) + ((Convert.ToDecimal(SWDis500)) * 500) + ((Convert.ToDecimal(SWDis2000)) * 2000),
                                //-- Remianing
                                SWRem100, SWRem200, SWRem500, SWRem2000,
                                (Convert.ToDecimal(SWRem100) * 100) + (Convert.ToDecimal(SWRem200) * 200) + (Convert.ToDecimal(SWRem500) * 500) + (Convert.ToDecimal(SWRem2000) * 2000),
                                //-- Loading
                                SWLoad100, SWLoad200, SWLoad500, SWLoad2000,
                                (Convert.ToDecimal(SWLoad100) * 100) + (Convert.ToDecimal(SWLoad200) * 200) + (Convert.ToDecimal(SWLoad500) * 500) + (Convert.ToDecimal(SWLoad2000) * 2000),
                                //-- Closing
                                Convert.ToDecimal(SWClosing100), Convert.ToDecimal(SWClosing200), Convert.ToDecimal(SWClosing500), Convert.ToDecimal(SWClosing2000),
                                ((Convert.ToDecimal(SWClosing100)) * 100) + ((Convert.ToDecimal(SWClosing200)) * 200) +
                                ((Convert.ToDecimal(SWClosing500)) * 500) + ((Convert.ToDecimal(SWClosing2000)) * 2000),

                                System.DateTime.Now, UserName, FileName);
                        }
                        #endregion

                        SWOp100 = "0";
                        SWOp200 = "0";
                        SWOp500 = "0";
                        SWOp2000 = "0";
                        SWOpTotal = "0";
                        SWDis100 = "0";
                        SWDis200 = "0";
                        SWDis500 = "0";
                        SWDis2000 = "0";
                        SWDisTotal = "0";
                        SWRem100 = "0";
                        SWRem200 = "0";
                        SWRem500 = "0";
                        SWRem2000 = "0";
                        SWRemTotal = "0";
                        SWLoad100 = "0";
                        SWLoad200 = "0";
                        SWLoad500 = "0";
                        SWLoad2000 = "0";
                        SWLoadTotal = "0";
                        SWClosing100 = "0";
                        SWClosing200 = "0";
                        SWClosing500 = "0";
                        SWClosing2000 = "0";
                        SWClosingTotal = "0";
                        LastSWDis100 = "0";
                        LastSWDis200 = "0";
                        LastSWDis500 = "0";
                        LastSWDis2000 = "0";
                    }
                    catch (Exception ex)
                    {
                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }
                }
            }

            if (_DataTableSWCounter.Rows.Count > 0)
            {
                InsertCount = _DataTableSWCounter.Rows.Count;
            }

            return _DataTableSWCounter;

        }


        public static int? ExtractSecondNumber(string input)
        {
            // Use a regular expression to find all numbers in the string
            var matches = Regex.Matches(input, @"\d+");

            // Check if there are at least two numbers
            if (matches.Count >= 2)
            {
                // Return the second number
                return int.Parse(matches[1].Value);
            }
            else
            {
                // Return null if there are less than two numbers
                return null;
            }
        }

        #region commentcode
        public DataTable AfterEODSplitDataSwapNCR2(string path, string FileName, out int InsertCount, out int TotalCount, out string MSGLBL, string UserName, DataTable _DataTableEod1)
        {


            #region "Declaration"
            DataSet ds = new DataSet();
            string MSG = string.Empty;
            //DataSet _DataSet = new DataSet();
            //DataTable _DataTableEod = new DataTable();

            //_DataTableEod.Columns.Add("ClientID", typeof(int));
            //_DataTableEod.Columns.Add("TerminalID", typeof(string));
            //_DataTableEod.Columns.Add("TxnsDateTime", typeof(DateTime));
            //_DataTableEod.Columns.Add("Cassette", typeof(string));
            //_DataTableEod.Columns.Add("Denom", typeof(decimal));
            //_DataTableEod.Columns.Add("CassetteType", typeof(string));

            //_DataTableEod.Columns.Add("Before_INCasset", typeof(decimal));
            //_DataTableEod.Columns.Add("Before_PURGE", typeof(decimal));
            //_DataTableEod.Columns.Add("Before_Remaining", typeof(decimal));
            //_DataTableEod.Columns.Add("Before_Dispensed", typeof(decimal));
            //_DataTableEod.Columns.Add("Before_Total", typeof(decimal));

            //_DataTableEod.Columns.Add("After_INCasset", typeof(decimal));
            //_DataTableEod.Columns.Add("After_PURGE", typeof(decimal));
            //_DataTableEod.Columns.Add("After_Remaining", typeof(decimal));
            //_DataTableEod.Columns.Add("After_Dispensed", typeof(decimal));
            //_DataTableEod.Columns.Add("After_Total", typeof(decimal));

            //_DataTableEod.Columns.Add("Total_Diff", typeof(decimal));
            //_DataTableEod.Columns.Add("Remark", typeof(string));
            //_DataTableEod.Columns.Add("TrTimeStamp", typeof(DateTime));
            //_DataTableEod.Columns.Add("AuthCode", typeof(string));
            //==============================================================================================================================================

            //DataTable _DataTableEod1 = new DataTable();
            //_DataTableEod1.Columns.Add("TerminalID", typeof(string));
            //_DataTableEod1.Columns.Add("TxnsDateTime", typeof(DateTime));
            //_DataTableEod1.Columns.Add("Cassette", typeof(string));
            //_DataTableEod1.Columns.Add("Denom", typeof(decimal));
            //_DataTableEod1.Columns.Add("CassetteType", typeof(string));

            //_DataTableEod1.Columns.Add("Before_INCasset", typeof(decimal));
            //_DataTableEod1.Columns.Add("Before_PURGE", typeof(decimal));
            //_DataTableEod1.Columns.Add("Before_Remaining", typeof(decimal));
            //_DataTableEod1.Columns.Add("Before_Dispensed", typeof(decimal));
            //_DataTableEod1.Columns.Add("Before_Total", typeof(decimal));

            //_DataTableEod1.Columns.Add("After_INCasset", typeof(decimal));
            //_DataTableEod1.Columns.Add("After_PURGE", typeof(decimal));
            //_DataTableEod1.Columns.Add("After_Remaining", typeof(decimal));
            //_DataTableEod1.Columns.Add("After_Dispensed", typeof(decimal));
            //_DataTableEod1.Columns.Add("After_Total", typeof(decimal));

            //_DataTableEod1.Columns.Add("Total_Diff", typeof(decimal));
            //_DataTableEod1.Columns.Add("Remark", typeof(string));
            //_DataTableEod1.Columns.Add("TrTimeStamp", typeof(DateTime));
            //_DataTableEod1.Columns.Add("AuthCode", typeof(string));


            InsertCount = 0;
            TotalCount = 0;
            string[] arrLines;
            arrLines = File.ReadAllLines(path, Encoding.Default);
            string[] ErrorLines = File.ReadAllLines(path, Encoding.Default);
            int StartIndexx = 0;
            int EndIndexx = 0;
            int mngindex = 0;
            int totallength = arrLines.Length;
            string filename = Path.GetFileName(path);
            string result;
            DateTime? TimeStamp = null;
            string TimeStampchk = string.Empty;
            DateTime TimeStamp1 = System.DateTime.Now;
            DateTime TranDate = System.DateTime.Now;
            DateTime TranDate_dmy = System.DateTime.Now;
            DateTime TimeStamp_dmy = System.DateTime.Now;
            string TerminalId = string.Empty;
            string ReferenceNumber = string.Empty;
            string ECardNumber = string.Empty;
            string CardNumber = string.Empty;
            string CardType = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string ResponseCode = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string CurrencyCode = string.Empty;
            string BranchCode = string.Empty;
            string OPCode = string.Empty;
            string ResultCode = string.Empty;
            string ErrorCode = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string FunctionID = string.Empty;
            string NoOfDuplicate = string.Empty;
            string FilePath = string.Empty;
            string FileDate = string.Empty;
            string CreatedBy = string.Empty;
            string ModifiedBy = string.Empty;
            bool inact = false;
            int ErrorLine = 0;
            string Typecheck = string.Empty;
            string VortexNotes = string.Empty;
            string PreviousAuthCode = string.Empty;
            string NCRNotes = string.Empty;
            string Remark = string.Empty;
            string str_TrTimstamp = string.Empty;
            DateTime TimeStamp2 = System.DateTime.Now;
            DateTime TimeStamp3 = System.DateTime.Now;
            string AuthCode3 = string.Empty;
            string authcode = string.Empty;
            #endregion

            #region EOD Variable
            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            decimal Denom1 = 0;
            decimal Denom2 = 0;
            decimal Denom3 = 0;
            decimal Denom4 = 0;
            string CassetteType1 = string.Empty;
            string CassetteType2 = string.Empty;
            string CassetteType3 = string.Empty;
            string CassetteType4 = string.Empty;
            string TxnDate = string.Empty;
            decimal Before_INCasset1 = 0;
            decimal Before_INCasset2 = 0;
            decimal Before_INCasset3 = 0;
            decimal Before_INCasset4 = 0;
            decimal Before_PURGE1 = 0;
            decimal Before_PURGE2 = 0;
            decimal Before_PURGE3 = 0;
            decimal Before_PURGE4 = 0;
            decimal Before_Remaining1 = 0;
            decimal Before_Remaining2 = 0;
            decimal Before_Remaining3 = 0;
            decimal Before_Remaining4 = 0;
            decimal Before_Dispensed1 = 0;
            decimal Before_Dispensed2 = 0;
            decimal Before_Dispensed3 = 0;
            decimal Before_Dispensed4 = 0;
            decimal Before_Total1 = 0;
            decimal Before_Total2 = 0;
            decimal Before_Total3 = 0;
            decimal Before_Total4 = 0;
            decimal After_INCasset1 = 0;
            decimal After_INCasset2 = 0;
            decimal After_INCasset3 = 0;
            decimal After_INCasset4 = 0;
            decimal After_PURGE1 = 0;
            decimal After_PURGE2 = 0;
            decimal After_PURGE3 = 0;
            decimal After_PURGE4 = 0;
            decimal After_Remaining1 = 0;
            decimal After_Remaining2 = 0;
            decimal After_Remaining3 = 0;
            decimal After_Remaining4 = 0;
            decimal After_Dispensed1 = 0;
            decimal After_Dispensed2 = 0;
            decimal After_Dispensed3 = 0;
            decimal After_Dispensed4 = 0;
            decimal After_Total1 = 0;
            decimal After_Total2 = 0;
            decimal After_Total3 = 0;
            decimal After_Total4 = 0;

            int rowsCount = 0;
            int count = 0;
            int Rejectcount = 0;
            int DISPENSEDcount = 0;
            int TOTAL1count = 0;
            #endregion EOD Variable


            #region
            bool BolCassette1 = false;
            bool Boldenom = false;
            bool BolCassetteType1 = false;
            bool BolBefore_INCasset1 = false;
            bool BolBefore_PURGE1 = false;
            bool BolBefore_Remaining1 = false;
            bool BolBefore_Dispensed1 = false;
            bool BolBefore_Total1 = false;
            bool BolAfter_INCasset1 = false;
            bool BolAfter_PURGE1 = false;
            bool BolAfter_Remaining1 = false;
            bool BolAfter_Dispensed1 = false;
            bool BolAfter_Total1 = false;
            string[] arrlist;
            bool BeforeResetcounter = false;
            bool AfterResetcounter = false;
            bool AfterLoad = false;
            #endregion



            TotalCount = arrLines.Length;
            string StartLine = string.Empty;
            if (arrLines.Length > 10)
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(10));
            }
            else
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(arrLines.Length));
            }
            if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
            {
                string result1 = ConvertStringArrayToString(arrLines);
                if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
                {
                    result = result1.Replace("*****START TRANSACTION*****", "|*****START TRANSACTION*****").Replace("CARD NUMBER", "|CARD NUMBER").
                        Replace("AUTH_NR", "|AUTH_NR").Replace("SEQ NUM", "|SEQ NUM").Replace("RSP CODE", "|RSP CODE")
                        .Replace("ACQUIRER_ID", "|ACQUIRER_ID").Replace("AID", "|AID").Replace("AVAIL", "|AVAIL").
                         Replace("LEDGER", "|LEDGER").Replace("WITHDRAWN", "|WITHDRAWN").Replace("a", "|").Replace("READ ERROR", "|READ ERROR").
                         Replace("a", "|").Replace("e1", "").Replace("e2", "").Replace("e3", "").Replace("e4", "").Replace("e5", "").Replace("e6", "")
                        .Replace("e7", "").Replace("e8", "").Replace("e9", "").Replace("e10", "").Replace("e;", "")
                        .Replace("IN CASSETTE", "|IN CASSETTE").Replace("DENOM", "|DENOM").Replace("CASS.TYPE", "|CASS.TYPE").Replace("+PURGE", "|+PURGE")
                        .Replace("OPCODE", "|OPCODE").Replace("NOTES PRESENTED", "|NOTES PRESENTED").Replace("NOTES TAKEN", "|NOTES TAKEN")
                        .Replace("DENOMINATION", "|DENOMINATION").Replace("DISPENSED", "|DISPENSED").Replace("REJECTED", "|REJECTED").Replace("REMAINING", "|REMAINING")
                        .Replace("REMAINING", "|REMAINING").Replace("DISPENSED", "|DISPENSED").Replace("TOTAL", "|TOTAL").Replace("CASSETTE STATUS", "|CASSETTE STATUS")
                        .Replace("LAST CASH COUNTER UPDATE", "|LAST CASH COUNTER UPDATE").Replace("LAST PURGE BIN CLEARED", "|LAST PURGE BIN CLEARED")
                        .Replace("*****END TRANSACTION*****", "|*****END TRANSACTION*****").Replace("DIVERTED NOTES", "|DIVERTED NOTES").
                        Trim();
                    arrLines = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                    arrLines = arrLines.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                }
            }

            TerminalId = Path.GetFileNameWithoutExtension(filename.Split('_').First().Trim().ToString());
            if (TerminalId != "0")
            {
                //bool valresult = ObjVF.GetTerminalID(TerminalId, TerminalId.Length);
                bool valresult = true;
                if (!valresult)
                {
                    //throw new System.ArgumentException("TerminalID data type is not valid.", "original");
                    MSGLBL = "TerminalID data type is not valid and " + "Error is : " + TerminalId;
                    //_DataTableEod.Clear();
                    //_DataSet.Tables.Add(_DataTableEod);
                    //return _DataSet;
                }
            }
            try
            {
                if (arrLines != null && arrLines.Length > 0)
                {
                    StartIndexx = -1;
                    EndIndexx = -1;
                    for (int LineNo = 0; LineNo <= arrLines.Length; LineNo++)
                    {
                        if (GetIndex(arrLines, LineNo, "CASH TOTAL       TYPE1 TYPE2 TYPE3 TYPE4") != -1)
                        {
                            StartIndexx = GetIndex(arrLines, LineNo, "CASH TOTAL       TYPE1 TYPE2 TYPE3 TYPE4") - 10;
                            EndIndexx = StartIndexx + 20;
                        }
                    }

                    if (StartIndexx != -1 && EndIndexx != -1)
                    {

                        for (int LineNoD = StartIndexx - 2; LineNoD <= EndIndexx; LineNoD++)
                        {

                            try
                            {

                                string strTr_Date, Time;
                                string result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());

                                string[] EJRequest = result1.Split(new string[] { " " }, StringSplitOptions.None);


                                if (result1.Contains("DATE TIME ATM-ID RESP")) //ej file index
                                {

                                    string[] TerminalSplit = result1.Split(' ');
                                    int endline = LineNoD + 5;

                                    for (LineNoD = LineNoD; LineNoD < endline; LineNoD++)
                                    {

                                        result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());
                                        TerminalSplit = result1.Split(' ');

                                        if (TerminalSplit[0].ToString().ToUpper().Trim().Contains("DATE".Trim().ToUpper()) && TerminalSplit[1].ToString().Trim().ToUpper().Contains("TIME".Trim().ToUpper()) &&
                                            TerminalSplit[2].ToString().Trim().ToUpper().Contains("ATM-ID".Trim().ToUpper()) && TerminalSplit[3].ToString().Trim().ToUpper().Contains("RESP".Trim().ToUpper()))
                                        {
                                            result1 = RemoveAdditionalChars(arrLines[LineNoD + 1].ToString());
                                            TerminalSplit = result1.Split(' ');
                                            strTr_Date = RemoveAdditionalChars(TerminalSplit[0].Trim());
                                            Time = RemoveAdditionalChars(TerminalSplit[1].Trim());

                                            str_TrTimstamp = strTr_Date + " " + Time;
                                            TimeStamp2 = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                        }



                                        TerminalSplit = result1.Split(' ');

                                        if (TerminalSplit[2].ToString().Contains("ESAF"))
                                        {
                                            TerminalId = TerminalSplit[2].ToString();
                                        }




                                        if (TerminalSplit[1].ToUpper().Trim().Contains("WITHDRAWAL".ToUpper().Trim()))
                                        {

                                            result1 = RemoveAdditionalChars(arrLines[LineNoD + 1].ToString());
                                            TerminalSplit = result1.Split(' ');
                                            authcode = TerminalSplit[2];

                                            TimeStamp3 = TimeStamp2;
                                            AuthCode3 = authcode;
                                        }


                                    }
                                }

                                #region comment code

                                //if (result1.Contains("DATE-TIME")) //ej file index
                                //{
                                //    string[] TerminalSplit = result1.Split(' ');

                                //    strTr_Date = RemoveAdditionalChars(TerminalSplit[1].Trim());
                                //    strTr_Date = strTr_Date.Substring(1, 8);

                                //    Time = RemoveAdditionalChars(TerminalSplit[2].Trim());

                                //    Time = Time.Substring(0, 5);

                                //    str_TrTimstamp = strTr_Date + " " + Time;
                                //    TimeStamp = DateTime.ParseExact(str_TrTimstamp, new[] { "MM/dd/yy HH:mm", "MM/dd/yy hh:mm", "dd/MM/yy HH:mm:ss", "dd/MM/yy HH:mm" }, CultureInfo.InvariantCulture.DateTimeFormat, DateTimeStyles.None);

                                //    TimeStamp3 = TimeStamp3;
                                //    AuthCode3 = AuthCode3;

                                //}
                                #endregion

                                result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());


                                string[] CASSETTE = null;
                                CASSETTE = result1.Split(' ');


                                if (str_TrTimstamp != "")
                                {

                                    if (CASSETTE[0].ToString() == "")
                                    {

                                    }

                                    else
                                    {
                                        if (CASSETTE[1].Contains("TYPE") || CASSETTE[2].Contains("TYPE"))
                                        {

                                            if (CASSETTE[2].Contains("TYPE1") && CASSETTE[3].Contains("TYPE2") && CASSETTE[4].Contains("TYPE3") && CASSETTE[5].Contains("TYPE4"))
                                            {
                                                Cassette1 = CASSETTE[2].Trim().ToString();
                                                Cassette2 = CASSETTE[3].Trim().ToString();
                                                Cassette3 = CASSETTE[4].Trim().ToString();
                                                Cassette4 = CASSETTE[5].Trim().ToString();

                                                BolCassette1 = true;

                                            }

                                        }
                                    }


                                    if (CASSETTE[0].Contains("DISPENSED"))
                                    {

                                        Before_Dispensed1 = Convert.ToDecimal(CASSETTE[1].Trim());
                                        Before_Dispensed2 = Convert.ToDecimal(CASSETTE[2].Trim());
                                        Before_Dispensed3 = Convert.ToDecimal(CASSETTE[3].Trim());
                                        Before_Dispensed4 = Convert.ToDecimal(CASSETTE[4].Trim());
                                        BolBefore_Dispensed1 = true;
                                    }


                                    if (CASSETTE[0].Contains("REMAINING"))
                                    {

                                        Before_Remaining1 = Convert.ToDecimal(CASSETTE[1].Trim());
                                        Before_Remaining2 = Convert.ToDecimal(CASSETTE[2].Trim());
                                        Before_Remaining3 = Convert.ToDecimal(CASSETTE[3].Trim());
                                        Before_Remaining4 = Convert.ToDecimal(CASSETTE[4].Trim());


                                        Before_Remaining1 = Before_Remaining1 + Before_Dispensed1;
                                        Before_Remaining2 = Before_Remaining2 + Before_Dispensed2;
                                        Before_Remaining3 = Before_Remaining3 + Before_Dispensed3;
                                        Before_Remaining4 = Before_Remaining4 + Before_Dispensed4;


                                        BolBefore_Remaining1 = true;



                                        Remark = "AFTER LOAD";
                                        AfterLoad = true;


                                    }


                                    #region commentcode
                                    //if (CASSETTE[0].Contains("=TOTAL") && TOTAL1count == 0)
                                    //{

                                    //    if (Cassette1 == "TYPE1" && Cassette3 != "TYPE3")
                                    //    {
                                    //        Before_Total1 = Convert.ToDecimal(CASSETTE[1].Trim());
                                    //    }

                                    //    if (Cassette2 == "TYPE2" && Cassette4 != "TYPE4")
                                    //    {
                                    //        Before_Total2 = Convert.ToDecimal(CASSETTE[2].Trim());
                                    //    }


                                    //    if (Cassette3 == "TYPE3")
                                    //    {
                                    //        Before_Total3 = Convert.ToDecimal(CASSETTE[1].Trim());
                                    //    }

                                    //    if (Cassette4 == "TYPE4")
                                    //    {
                                    //        Before_Total4 = Convert.ToDecimal(CASSETTE[2].Trim());
                                    //        BolBefore_Total1 = true;
                                    //    }

                                    //}
                                    #endregion


                                    if (str_TrTimstamp != "" && BolCassette1 == true && BolBefore_Dispensed1 == true && BolBefore_Remaining1 == true)
                                    {

                                        if (Cassette1 == "TYPE1" && Cassette2 == "TYPE2")
                                        {

                                            if (Cassette1 == "TYPE1" && Cassette2 == "TYPE2")
                                            {
                                                Denom1 = 100;
                                            }

                                            if (Cassette2 == "TYPE2")
                                            {
                                                Denom2 = 200;
                                            }
                                        }

                                        if (Cassette3 == "TYPE3" && Cassette4 == "TYPE4")
                                        {

                                            if (Cassette3 == "TYPE3")
                                            {
                                                Denom3 = 500;
                                            }

                                            if (Cassette4 == "TYPE4")
                                            {
                                                Denom4 = 500;

                                            }
                                        }


                                        #region comment code
                                        //if (Before_Remaining1 == 0 && Before_Remaining2 == 0 && Before_Remaining3 == 0 && Before_Remaining4 == 0
                                        //    && Before_Dispensed1 == 0 && Before_Dispensed2 == 0 && Before_Dispensed3 == 0 && Before_Dispensed4 == 0
                                        //     && Before_Total1 == 0 && Before_Total2 == 0 && Before_Total3 == 0 && Before_Total4 == 0)
                                        //{
                                        //    Remark = "AFTER RESET COUNTERS";
                                        //    AfterResetcounter = true;


                                        //}



                                        //if ((Before_Total1 != 0 || Before_Total2 != 0 || Before_Total3 != 0 || Before_Total4 != 0))
                                        //{
                                        //    Remark = "AFTER LOAD";
                                        //    AfterLoad = true;

                                        //}

                                        //else
                                        //{
                                        //    Remark = "BEFORE RESET COUNTERS";
                                        //    BeforeResetcounter = true;


                                        //}
                                        #endregion



                                        Guid Trans_CycleID1 = Guid.NewGuid();
                                        _DataTableEod1.Rows.Add(TerminalId, TimeStamp3, Cassette1, Denom1, CassetteType1, Before_INCasset1, Before_PURGE1, Before_Remaining1, Before_Dispensed1, Before_Total1, After_INCasset1, After_PURGE1, After_Remaining1, After_Dispensed1, After_Total1, 0, Remark, TimeStamp3, AuthCode3);
                                        _DataTableEod1.Rows.Add(TerminalId, TimeStamp3, Cassette2, Denom2, CassetteType2, Before_INCasset2, Before_PURGE2, Before_Remaining2, Before_Dispensed2, Before_Total2, After_INCasset2, After_PURGE2, After_Remaining2, After_Dispensed2, After_Total2, 0, Remark, TimeStamp3, AuthCode3);
                                        _DataTableEod1.Rows.Add(TerminalId, TimeStamp3, Cassette3, Denom3, CassetteType3, Before_INCasset3, Before_PURGE3, Before_Remaining3, Before_Dispensed3, Before_Total3, After_INCasset3, After_PURGE3, After_Remaining3, After_Dispensed3, After_Total3, 0, Remark, TimeStamp3, AuthCode3);
                                        _DataTableEod1.Rows.Add(TerminalId, TimeStamp3, Cassette4, Denom4, CassetteType4, Before_INCasset4, Before_PURGE4, Before_Remaining4, Before_Dispensed4, Before_Total4, After_INCasset4, After_PURGE4, After_Remaining4, After_Dispensed4, After_Total4, 0, Remark, TimeStamp3, AuthCode3);
                                        InsertCount = InsertCount + 4;




                                        BolCassette1 = false; Boldenom = false; BolCassetteType1 = false; BolBefore_INCasset1 = false; BolBefore_PURGE1 = false;
                                        BolBefore_Remaining1 = false; BolBefore_Total1 = false;

                                        Cassette1 = string.Empty;
                                        Cassette2 = string.Empty;
                                        Cassette3 = string.Empty;
                                        Cassette4 = string.Empty;
                                        Denom1 = 0;
                                        Denom2 = 0;
                                        Denom3 = 0;
                                        Denom4 = 0;
                                        CassetteType1 = string.Empty;
                                        CassetteType2 = string.Empty;
                                        CassetteType3 = string.Empty;
                                        CassetteType4 = string.Empty;
                                        TxnDate = string.Empty;
                                        Before_INCasset1 = 0;
                                        Before_INCasset2 = 0;
                                        Before_INCasset3 = 0;
                                        Before_INCasset4 = 0;
                                        Before_PURGE1 = 0;
                                        Before_PURGE2 = 0;
                                        Before_PURGE3 = 0;
                                        Before_PURGE4 = 0;
                                        Before_Remaining1 = 0;
                                        Before_Remaining2 = 0;
                                        Before_Remaining3 = 0;
                                        Before_Remaining4 = 0;
                                        Before_Dispensed1 = 0;
                                        Before_Dispensed2 = 0;
                                        Before_Dispensed3 = 0;
                                        Before_Dispensed4 = 0;
                                        Before_Total1 = 0;
                                        Before_Total2 = 0;
                                        Before_Total3 = 0;
                                        Before_Total4 = 0;
                                        After_INCasset1 = 0;
                                        After_INCasset2 = 0;
                                        After_INCasset3 = 0;
                                        After_INCasset4 = 0;
                                        After_PURGE1 = 0;
                                        After_PURGE2 = 0;
                                        After_PURGE3 = 0;
                                        After_PURGE4 = 0;
                                        After_Remaining1 = 0;
                                        After_Remaining2 = 0;
                                        After_Remaining3 = 0;
                                        After_Remaining4 = 0;
                                        After_Dispensed1 = 0;
                                        After_Dispensed2 = 0;
                                        After_Dispensed3 = 0;
                                        After_Dispensed4 = 0;
                                        After_Total1 = 0;
                                        After_Total2 = 0;
                                        After_Total3 = 0;
                                        After_Total4 = 0;
                                        str_TrTimstamp = "";
                                        TimeStamp = null;

                                    }
                                }
                            }

                            catch (Exception exx)
                            {

                            }

                        }

                    }

                }

            }



            catch (Exception ex)
            {
                //InsertCount = 0;
                //objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessEJ_CashtallyLogSpliter", "ProcessEJ_CashtallyLogSpliter", LineNo, FileName, UserName, 'E');
            }


            MSGLBL = string.Empty;
            return _DataTableEod1;
        }



        //public DataTable AfterEODSplitDataSwapNCR2(string path, string FileName, out int InsertCount, out int TotalCount, out string MSGLBL, string UserName, DataTable _DataTableEod1)
        //{

        //    #region "Declaration"
        //    DataSet ds = new DataSet();
        //    string MSG = string.Empty;
        //    DataSet _DataSet = new DataSet();
        //   DataTable _DataTableEod = new DataTable();

        //   _DataTableEod.Columns.Add("TerminalID", typeof(string));
        //   _DataTableEod.Columns.Add("TxnsDateTime", typeof(DateTime));
        //   _DataTableEod.Columns.Add("Cassette", typeof(string));
        //   _DataTableEod.Columns.Add("Denom", typeof(decimal));
        //   _DataTableEod.Columns.Add("CassetteType", typeof(string));

        //   _DataTableEod.Columns.Add("Before_INCasset", typeof(decimal));
        //   _DataTableEod.Columns.Add("Before_PURGE", typeof(decimal));
        //   _DataTableEod.Columns.Add("Before_Remaining", typeof(decimal));
        //   _DataTableEod.Columns.Add("Before_Dispensed", typeof(decimal));
        //   _DataTableEod.Columns.Add("Before_Total", typeof(decimal));

        //   _DataTableEod.Columns.Add("After_INCasset", typeof(decimal));
        //   _DataTableEod.Columns.Add("After_PURGE", typeof(decimal));
        //   _DataTableEod.Columns.Add("After_Remaining", typeof(decimal));
        //   _DataTableEod.Columns.Add("After_Dispensed", typeof(decimal));
        //   _DataTableEod.Columns.Add("After_Total", typeof(decimal));

        //   _DataTableEod.Columns.Add("Total_Diff", typeof(decimal));
        //   _DataTableEod.Columns.Add("Remark", typeof(string));
        //   _DataTableEod.Columns.Add("TrTimeStamp", typeof(DateTime));
        //   _DataTableEod.Columns.Add("AuthCode", typeof(string));



        //   //_DataTableEod.Columns.Add("ClientID", typeof(int));
        //   //_DataTableEod.Columns.Add("TerminalID", typeof(string));
        //   //_DataTableEod.Columns.Add("TxnsDateTime", typeof(DateTime));
        //   //_DataTableEod.Columns.Add("LastCashCounterCleared", typeof(DateTime));
        //   //_DataTableEod.Columns.Add("LastPurgeBinCleared", typeof(DateTime));
        //   //_DataTableEod.Columns.Add("Denom1", typeof(string));
        //   //_DataTableEod.Columns.Add("Denom2", typeof(string));
        //   //_DataTableEod.Columns.Add("Denom3", typeof(string));
        //   //_DataTableEod.Columns.Add("Denom4", typeof(string));
        //   //_DataTableEod.Columns.Add("Cassette1", typeof(string));
        //   //_DataTableEod.Columns.Add("Cassette2", typeof(string));
        //   //_DataTableEod.Columns.Add("Cassette3", typeof(string));
        //   //_DataTableEod.Columns.Add("Cassette4", typeof(string));
        //   //_DataTableEod.Columns.Add("CassetteType1", typeof(string));
        //   //_DataTableEod.Columns.Add("CassetteType2", typeof(string));
        //   //_DataTableEod.Columns.Add("CassetteType3", typeof(string));
        //   //_DataTableEod.Columns.Add("CassetteType4", typeof(string));
        //   //_DataTableEod.Columns.Add("Rejected1", typeof(string));
        //   //_DataTableEod.Columns.Add("Rejected2", typeof(string));
        //   //_DataTableEod.Columns.Add("Rejected3", typeof(string));
        //   //_DataTableEod.Columns.Add("Rejected4", typeof(string));
        //   //_DataTableEod.Columns.Add("Remaining1", typeof(string));
        //   //_DataTableEod.Columns.Add("Remaining2", typeof(string));
        //   //_DataTableEod.Columns.Add("Remaining3", typeof(string));
        //   //_DataTableEod.Columns.Add("Remaining4", typeof(string));
        //   //_DataTableEod.Columns.Add("Dispensed1", typeof(string));
        //   //_DataTableEod.Columns.Add("Dispensed2", typeof(string));
        //   //_DataTableEod.Columns.Add("Dispensed3", typeof(string));
        //   //_DataTableEod.Columns.Add("Dispensed4", typeof(string));
        //   //_DataTableEod.Columns.Add("TotalCassette1", typeof(string));
        //   //_DataTableEod.Columns.Add("TotalCassette2", typeof(string));
        //   //_DataTableEod.Columns.Add("TotalCassette3", typeof(string));
        //   //_DataTableEod.Columns.Add("TotalCassette4", typeof(string));
        //   //_DataTableEod.Columns.Add("CassetteStatus1", typeof(string));
        //   //_DataTableEod.Columns.Add("CassetteStatus2", typeof(string));
        //   //_DataTableEod.Columns.Add("CassetteStatus3", typeof(string));
        //   //_DataTableEod.Columns.Add("CassetteStatus4", typeof(string));
        //   //_DataTableEod.Columns.Add("AddCash1", typeof(string));
        //   //_DataTableEod.Columns.Add("AddCash2", typeof(string));
        //   //_DataTableEod.Columns.Add("AddCash3", typeof(string));
        //   //_DataTableEod.Columns.Add("AddCash4", typeof(string));
        //   //_DataTableEod.Columns.Add("Remarks", typeof(string));
        //   //_DataTableEod.Columns.Add("TrTimeStamp", typeof(DateTime));
        //   //_DataTableEod.Columns.Add("AuthCode", typeof(string));


        //    //DataTable _DataTableEod1 = new DataTable();
        //    //_DataTableEod1.Columns.Add("TerminalID", typeof(string));
        //    //_DataTableEod1.Columns.Add("TxnsDateTime", typeof(DateTime));
        //    //_DataTableEod1.Columns.Add("Cassette", typeof(string));
        //    //_DataTableEod1.Columns.Add("Denom", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("CassetteType", typeof(string));
        //    //_DataTableEod1.Columns.Add("Before_INCasset", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("Before_PURGE", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("Before_Remaining", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("Before_Dispensed", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("Before_Total", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("After_INCasset", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("After_PURGE", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("After_Remaining", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("After_Dispensed", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("After_Total", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("Total_Diff", typeof(decimal));
        //    //_DataTableEod1.Columns.Add("Remark", typeof(string));
        //    //_DataTableEod1.Columns.Add("TrTimeStamp", typeof(DateTime));
        //    //_DataTableEod1.Columns.Add("AuthCode", typeof(string));

        //    int LineNo = 0;
        //    InsertCount = 0;
        //    TotalCount = 0;
        //    string[] arrLines;
        //    arrLines = File.ReadAllLines(path, Encoding.Default);
        //    string[] ErrorLines = File.ReadAllLines(path, Encoding.Default);
        //    int StartIndex = 0;
        //    int EndIndex = 0;
        //    int StartIndex1 = 0;
        //    int EndIndex1 = 0;
        //    int StartIndexx = 0;
        //    int EndIndexx = 0;
        //    int totallength = arrLines.Length;
        //    string filename = Path.GetFileName(path);
        //    string result;
        //    DateTime TimeStamp = System.DateTime.Now;
        //    DateTime TimeStamp1 = System.DateTime.Now;
        //    DateTime? CounterDate = null;
        //    DateTime? ClearedDate = null;
        //    DateTime TranDate = System.DateTime.Now;
        //    DateTime TranDate_dmy = System.DateTime.Now;
        //    DateTime TimeStamp_dmy = System.DateTime.Now;
        //    string Remark1 = string.Empty;
        //    string Remark2 = string.Empty;
        //    string Remark3 = string.Empty;
        //    string Remark4 = string.Empty;
        //    string Remarks = string.Empty;
        //    string Denomination = string.Empty;
        //    string RequestCount = string.Empty;
        //    string DispenseCount = string.Empty;
        //    string RemainCount = string.Empty;
        //    string PickupCount = string.Empty;
        //    string RejectCount = string.Empty;
        //    string TransSEQNumber = string.Empty;
        //    string Cassette1 = string.Empty;
        //    string Cassette2 = string.Empty;
        //    string Cassette3 = string.Empty;
        //    string Cassette4 = string.Empty;
        //    string Denom1 = string.Empty;
        //    string Denom2 = string.Empty;
        //    string Denom3 = string.Empty;
        //    string Denom4 = string.Empty;
        //    string CassetteType1 = string.Empty;
        //    string CassetteType2 = string.Empty;
        //    string CassetteType3 = string.Empty;
        //    string CassetteType4 = string.Empty;
        //    string Rejected1 = string.Empty;
        //    string Rejected2 = string.Empty;
        //    string Rejected3 = string.Empty;
        //    string Rejected4 = string.Empty;
        //    string Remaining1 = string.Empty;
        //    string Remaining2 = string.Empty;
        //    string Remaining3 = string.Empty;
        //    string Remaining4 = string.Empty;
        //    string Dispense1 = string.Empty;
        //    string Dispense2 = string.Empty;
        //    string Dispense3 = string.Empty;
        //    string Dispense4 = string.Empty;
        //    string TotalDispense1 = string.Empty;
        //    string TotalDispense2 = string.Empty;
        //    string TotalDispense3 = string.Empty;
        //    string TotalDispense4 = string.Empty;
        //    string CassetteStatus1 = string.Empty;
        //    string CassetteStatus2 = string.Empty;
        //    string CassetteStatus3 = string.Empty;
        //    string CassetteStatus4 = string.Empty;
        //    string ReserveField1 = string.Empty;
        //    string ReserveField2 = string.Empty;
        //    string ReserveField3 = string.Empty;
        //    string ReserveField4 = string.Empty;
        //    string ReserveField5 = string.Empty;
        //    string EJDataID = string.Empty;
        //    string AddCash1 = string.Empty;
        //    string AddCash2 = string.Empty;
        //    string AddCash3 = string.Empty;
        //    string AddCash4 = string.Empty;
        //    string TerminalId = string.Empty;
        //    string ReferenceNumber = string.Empty;
        //    string ECardNumber = string.Empty;
        //    string CardNumber = string.Empty;
        //    string CardType = string.Empty;
        //    string CustAccountNo = string.Empty;
        //    string InterchangeAccountNo = string.Empty;
        //    string ATMAccountNo = string.Empty;
        //    DateTime? TxnsDateTime = null;
        //    DateTime? TxnsDateTimeFailed = null;
        //    decimal TxnsAmount = 0;
        //    decimal Amount1 = 0;
        //    decimal Amount2 = 0;
        //    decimal Amount3 = 0;
        //    string TxnsType = string.Empty;
        //    string TxnsNumber = string.Empty;
        //    string TxnsPerticulars = string.Empty;
        //    string ResponseCode = string.Empty;
        //    string AuthCode = string.Empty;
        //    string ProcessingCode = string.Empty;
        //    decimal FeeAmount = 0;
        //    string CurrencyCode = string.Empty;
        //    decimal CustBalance = 0;
        //    decimal InterchangeBalance = 0;
        //    decimal ATMBalance = 0;
        //    string BranchCode = string.Empty;
        //    string OPCode = string.Empty;
        //    string ResultCode = string.Empty;
        //    string ErrorCode = string.Empty;
        //    string TCode = string.Empty;
        //    string TCode1 = string.Empty;
        //    string FunctionID = string.Empty;
        //    decimal InitAmount = 0;
        //    decimal DispAmount = 0;
        //    decimal StorAmount = 0;
        //    decimal RemAmount = 0;
        //    string NoOfDuplicate = string.Empty;
        //    string FilePath = string.Empty;
        //    string FileDate = string.Empty;
        //    DateTime? CreatedOn = null;
        //    DateTime? ModifiedOn = null;
        //    string CreatedBy = string.Empty;
        //    string ModifiedBy = string.Empty;
        //    bool inact = false;
        //    int LineNo1 = 0;
        //    bool flag = false;
        //    int ErrorLine = 0;
        //    string Typecheck = string.Empty;
        //    string VortexNotes = string.Empty;
        //    string PreviousAuthCode = string.Empty;
        //    string NCRNotes = string.Empty;
        //    DateTime TimeStamp2 = System.DateTime.Now;
        //    DateTime TimeStamp3 = System.DateTime.Now;
        //    string AuthCode3 = string.Empty;
        //    string authcode = string.Empty;
        //    string remarks = "";

        //    #endregion
        //    string StartLine = string.Empty;
        //    if (arrLines.Length > 10)
        //    {
        //        StartLine = string.Join("\r\n", File.ReadLines(path).Take(10));
        //    }
        //    else
        //    {
        //        StartLine = string.Join("\r\n", File.ReadLines(path).Take(arrLines.Length));
        //    }
        //    if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
        //    {
        //        string result1 = ConvertStringArrayToString(arrLines);
        //        if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
        //        {
        //            result = result1.Replace("*****START TRANSACTION*****", "|*****START TRANSACTION*****").Replace("CARD NUMBER", "|CARD NUMBER").
        //                Replace("AUTH_NR", "|AUTH_NR").Replace("SEQ NUM", "|SEQ NUM").Replace("RSP CODE", "|RSP CODE")
        //                .Replace("ACQUIRER_ID", "|ACQUIRER_ID").Replace("AID", "|AID").Replace("AVAIL", "|AVAIL").
        //                 Replace("LEDGER", "|LEDGER").Replace("WITHDRAWN", "|WITHDRAWN").Replace("a", "|").Replace("READ ERROR", "|READ ERROR").
        //                 Replace("a", "|").Replace("e1", "").Replace("e2", "").Replace("e3", "").Replace("e4", "").Replace("e5", "").Replace("e6", "")
        //                .Replace("e7", "").Replace("e8", "").Replace("e9", "").Replace("e10", "").Replace("e;", "")
        //                .Replace("IN CASSETTE", "|IN CASSETTE").Replace("DENOM", "|DENOM").Replace("CASS.TYPE", "|CASS.TYPE").Replace("+PURGE", "|+PURGE")
        //                .Replace("OPCODE", "|OPCODE").Replace("NOTES PRESENTED", "|NOTES PRESENTED").Replace("NOTES TAKEN", "|NOTES TAKEN")
        //                .Replace("DENOMINATION", "|DENOMINATION").Replace("DISPENSED", "|DISPENSED").Replace("REJECTED", "|REJECTED").Replace("REMAINING", "|REMAINING")
        //                .Replace("REMAINING", "|REMAINING").Replace("DISPENSED", "|DISPENSED").Replace("TOTAL", "|TOTAL").Replace("CASSETTE STATUS", "|CASSETTE STATUS")
        //                .Replace("LAST CASH COUNTER UPDATE", "|LAST CASH COUNTER UPDATE").Replace("LAST PURGE BIN CLEARED", "|LAST PURGE BIN CLEARED")
        //                .Replace("*****END TRANSACTION*****", "|*****END TRANSACTION*****").Replace("DIVERTED NOTES", "|DIVERTED NOTES").
        //                Trim();
        //            arrLines = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
        //            arrLines = arrLines.Where(x => !string.IsNullOrEmpty(x)).ToArray();
        //        }
        //    }

        //    TerminalId = Path.GetFileNameWithoutExtension(filename.Split('_').First().Trim().ToString());
        //    if (TerminalId != "0")
        //    {

        //    }

        //    try
        //    {
        //        if (arrLines != null && arrLines.Length > 0)
        //        {
        //            StartIndex = -1;
        //            EndIndex = -1;
        //            for (LineNo = 0; LineNo <= arrLines.Length; LineNo++)
        //            {
        //                if (GetIndex(arrLines, LineNo, "CASH TOTAL       TYPE1 TYPE2 TYPE3 TYPE4") != -1)
        //                {
        //                    StartIndex = GetIndex(arrLines, LineNo, "CASH TOTAL       TYPE1 TYPE2 TYPE3 TYPE4");
        //                    EndIndex = StartIndex + 6;
        //                }
        //            }

        //            if (StartIndex != -1)
        //            {
        //                for (int LineNoD = StartIndex - 18; LineNoD <= EndIndex; LineNoD++)
        //                {
        //                    try
        //                    {
        //                        string str_TrTimstamp;
        //                        string strTr_Date, Time;
        //                        string result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());
        //                        string[] EJRequest = result1.Split(new string[] { " " }, StringSplitOptions.None);

        //                        if (result1.Contains("DATE") && result1.Contains("TIME"))
        //                        {
        //                            string[] TerminalSplit = result1.Split(' ');
        //                            // strTr_Date = RemoveAdditionalChars(TerminalSplit[0].ToString());
        //                            //string[] date = strTr_Date.Split('-');
        //                            strTr_Date = RemoveAdditionalChars(TerminalSplit[1].Trim());
        //                            Time = RemoveAdditionalChars(TerminalSplit[3].Trim());

        //                            strTr_Date = strTr_Date.Replace("-", "/");
        //                            str_TrTimstamp = strTr_Date + " " + Time;
        //                            try
        //                            {
        //                                TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);
        //                                CounterDate = TimeStamp;
        //                                //ResponseCode = TerminalSplit[3].Trim();
        //                            }
        //                            catch (Exception ex)
        //                            {

        //                                try
        //                                {
        //                                    TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm", CultureInfo.InvariantCulture);
        //                                    CounterDate = TimeStamp;
        //                                    // ResponseCode = TerminalSplit[3].Trim();
        //                                }
        //                                catch (Exception E11)
        //                                {


        //                                }

        //                            }
        //                        }


        //                        if (result1.Contains("DATE TIME ATM-ID RESP")) //ej file index
        //                        {

        //                            string[] TerminalSplit = result1.Split(' ');
        //                            int endline = LineNoD + 5;

        //                            for (LineNoD = LineNoD; LineNoD < endline; LineNoD++)
        //                            {

        //                                result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());
        //                                TerminalSplit = result1.Split(' ');

        //                                if (TerminalSplit[0].ToString().ToUpper().Trim().Contains("DATE".Trim().ToUpper()) && TerminalSplit[1].ToString().Trim().ToUpper().Contains("TIME".Trim().ToUpper()) &&
        //                                    TerminalSplit[2].ToString().Trim().ToUpper().Contains("ATM-ID".Trim().ToUpper()) && TerminalSplit[3].ToString().Trim().ToUpper().Contains("RESP".Trim().ToUpper()))
        //                                {
        //                                    result1 = RemoveAdditionalChars(arrLines[LineNoD + 1].ToString());
        //                                    TerminalSplit = result1.Split(' ');
        //                                    strTr_Date = RemoveAdditionalChars(TerminalSplit[0].Trim());
        //                                    Time = RemoveAdditionalChars(TerminalSplit[1].Trim());

        //                                    str_TrTimstamp = strTr_Date + " " + Time;
        //                                    TimeStamp2 = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
        //                                }

        //                                result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());

        //                                TerminalSplit = result1.Split(' ');

        //                                if (TerminalSplit[1].ToUpper().Trim().Contains("WITHDRAWAL".ToUpper().Trim()))
        //                                {

        //                                    result1 = RemoveAdditionalChars(arrLines[LineNoD + 1].ToString());
        //                                    TerminalSplit = result1.Split(' ');
        //                                    authcode = TerminalSplit[2];

        //                                    TimeStamp3 = TimeStamp2;
        //                                    AuthCode3 = authcode;
        //                                }


        //                            }
        //                        }



        //                        if (result1.Contains("DATE-TIME")) //ej file index
        //                        {
        //                            string[] TerminalSplit = result1.Split(' ');

        //                            strTr_Date = RemoveAdditionalChars(TerminalSplit[1].Trim());
        //                            strTr_Date = strTr_Date.Substring(1, 8);

        //                            Time = RemoveAdditionalChars(TerminalSplit[2].Trim());

        //                            Time = Time.Substring(0, 5);

        //                            str_TrTimstamp = strTr_Date + " " + Time;
        //                            TimeStamp = DateTime.ParseExact(str_TrTimstamp, new[] { "MM/dd/yy HH:mm", "MM/dd/yy hh:mm", "dd/MM/yy HH:mm:ss", "dd/MM/yy HH:mm" }, CultureInfo.InvariantCulture.DateTimeFormat, DateTimeStyles.None);

        //                            TimeStamp3 = TimeStamp3;
        //                            AuthCode3 = AuthCode3;

        //                        }

        //                        if (result1.Contains("ESAF")) //ej file index
        //                        {
        //                            string[] TerminalSplit = result1.Split(' ');
        //                            strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
        //                            if (strTr_Date.Contains("-"))
        //                            {
        //                                string[] date = strTr_Date.Split('-');
        //                                strTr_Date = RemoveAdditionalChars(date[0].Trim());
        //                                Time = RemoveAdditionalChars(EJRequest[1].Trim());
        //                            }
        //                            else
        //                            {
        //                                // string[] date = strTr_Date.Split('-');
        //                                strTr_Date = RemoveAdditionalChars(TerminalSplit[0].Trim());
        //                                Time = RemoveAdditionalChars(TerminalSplit[1].Trim());
        //                            }
        //                            //if (TerminalSplit[3].Trim() == "61")
        //                            //{
        //                            //    ResponseCode = "61";
        //                            //}
        //                            str_TrTimstamp = strTr_Date + " " + Time;
        //                            try
        //                            {
        //                                TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
        //                                CounterDate = TimeStamp;
        //                                ResponseCode = TerminalSplit[3].Trim();
        //                            }
        //                            catch (Exception ex)
        //                            {
        //                                try
        //                                {
        //                                    TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
        //                                    CounterDate = TimeStamp;
        //                                }
        //                                catch (Exception EX3)
        //                                {


        //                                }

        //                                //ResponseCode = TerminalSplit[3].Trim();
        //                            }

        //                        }
        //                        else if (result1.Contains("TRANSACTION START"))
        //                        {
        //                            string[] TerminalSplit = result1.Split(' ');
        //                            strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
        //                            string[] date = strTr_Date.Split('-');
        //                            strTr_Date = RemoveAdditionalChars(date[0].Trim());
        //                            Time = RemoveAdditionalChars(EJRequest[1].Trim());

        //                            str_TrTimstamp = strTr_Date + " " + Time;
        //                            try
        //                            {
        //                                TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);
        //                                //ResponseCode = TerminalSplit[3].Trim();
        //                                CounterDate = TimeStamp;
        //                            }
        //                            catch (Exception ex)
        //                            {
        //                                try
        //                                {
        //                                    TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
        //                                    CounterDate = TimeStamp;
        //                                }
        //                                catch (Exception EX2)
        //                                {


        //                                }

        //                            }
        //                            string[] tmp = FileName.Split('_');
        //                        }
        //                    }
        //                    catch { }
        //                }
        //            }

        //            #region Upload Ej
        //            if (StartIndex != -1 && EndIndex != -1)
        //            {
        //                Cassette1 = string.Empty;
        //                Cassette2 = string.Empty;
        //                Cassette3 = string.Empty;
        //                Cassette4 = string.Empty;
        //                Denom1 = string.Empty;
        //                Denom2 = string.Empty;
        //                Denom3 = string.Empty;
        //                Denom4 = string.Empty;
        //                CassetteType1 = string.Empty;
        //                CassetteType2 = string.Empty;
        //                CassetteType3 = string.Empty;
        //                CassetteType4 = string.Empty;
        //                Remaining1 = string.Empty;
        //                Remaining2 = string.Empty;
        //                Remaining3 = string.Empty;
        //                Remaining4 = string.Empty;
        //                Dispense1 = string.Empty;
        //                Dispense2 = string.Empty;
        //                Dispense3 = string.Empty;
        //                Dispense4 = string.Empty;
        //                TotalDispense1 = string.Empty;
        //                TotalDispense2 = string.Empty;
        //                TotalDispense3 = string.Empty;
        //                TotalDispense4 = string.Empty;
        //                CassetteStatus1 = string.Empty;
        //                CassetteStatus2 = string.Empty;
        //                CassetteStatus3 = string.Empty;
        //                CassetteStatus4 = string.Empty;
        //                AddCash1 = string.Empty;
        //                AddCash2 = string.Empty;
        //                AddCash3 = string.Empty;
        //                AddCash4 = string.Empty;
        //                string TxnDate = string.Empty;

        //                TxnDate = Path.GetFileNameWithoutExtension(filename).Split('_')[1].ToString();
        //                TxnDate = TxnDate.Substring(2);
        //                try
        //                {
        //                    TimeStamp = DateTime.ParseExact(TxnDate, "yyyyMMdd", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);

        //                }
        //                catch
        //                {

        //                    TimeStamp = DateTime.ParseExact(TxnDate, "ddMMyyyy", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);

        //                }
        //                for (int k = StartIndex; k <= EndIndex; k++)
        //                {
        //                    #region "EOD"
        //                    try
        //                    {
        //                        result = RemoveAdditionalChars(arrLines[k].ToString());
        //                        if (!StartLine.Contains("MAC=YES") && arrLines != null && arrLines.Length > 0)
        //                        {
        //                            inact = new string[] { "CASSETTE", "*R*" }.Any(s => result.Contains(s));
        //                            int Rejectcount = 0;
        //                            int REMAINING1count = 0;
        //                            int DISPENSEDcount = 0;
        //                            int TOTAL1count = 0;

        //                            string[] CASSETTE = arrLines[k].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
        //                            if (CASSETTE.Contains("CASH") && CASSETTE.Contains("TOTAL"))
        //                            {
        //                                Cassette1 = CASSETTE[1].Trim().ToString();
        //                                Cassette2 = CASSETTE[2].Trim().ToString();
        //                                Cassette3 = CASSETTE[1].Trim().ToString();
        //                                Cassette4 = CASSETTE[2].Trim().ToString();
        //                            }

        //                            if (CASSETTE.Contains("REJECTED"))
        //                            {
        //                                Rejected1 = CASSETTE[1].Trim().ToString();
        //                                Rejected2 = CASSETTE[2].Trim().ToString();
        //                                Rejected3 = CASSETTE[3].Trim().ToString();
        //                                Rejected4 = CASSETTE[4].Trim().ToString();
        //                            }

        //                            if (CASSETTE.Contains("REMAINING"))
        //                            {
        //                                Remaining1 = CASSETTE[1].Trim().ToString();
        //                                Remaining2 = CASSETTE[2].Trim().ToString();
        //                                Remaining3 = CASSETTE[3].Trim().ToString();
        //                                Remaining4 = CASSETTE[4].Trim().ToString();
        //                            }
        //                            if (CASSETTE.Contains("+DISPENSED"))
        //                            {
        //                                Dispense1 = CASSETTE[1].Trim().ToString();
        //                                Dispense2 = CASSETTE[2].Trim().ToString();
        //                                Dispense3 = CASSETTE[3].Trim().ToString();
        //                                Dispense4 = CASSETTE[4].Trim().ToString();

        //                            }

        //                            if (CASSETTE.Contains("=TOTAL") && TOTAL1count == 0)
        //                            {
        //                                TOTAL1count++;
        //                                TotalDispense1 = CASSETTE[1].Trim().ToString();
        //                                TotalDispense2 = CASSETTE[2].Trim().ToString();
        //                                TotalDispense3 = CASSETTE[1].Trim().ToString();
        //                                TotalDispense4 = CASSETTE[2].Trim().ToString();

        //                            }





        //                        }
        //                    }
        //                    catch (Exception ex)
        //                    {
        //                    }
        //                }

        //                try
        //                {
        //                    Remarks = "AFTER LOAD";

        //                    Guid Trans_CycleID1 = Guid.NewGuid();

        //                    _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette2, Denom, CassetteType1, "", "", "", "", "", "", "", "", "", "", 0, Remarks, TimeStamp3, AuthCode3);

        //                    //_DataTableEod.Rows.Add(TerminalId, CounterDate, CounterDate, ClearedDate, Denom1, Denom2, Denom3, Denom4, Cassette1, Cassette2, Cassette3, Cassette4, CassetteType1, CassetteType2, CassetteType3, CassetteType4, Rejected1, Rejected2, Rejected3, Rejected4, Remaining1, Remaining2, Remaining3, Remaining4, Dispense1, Dispense2, Dispense3, Dispense4, TotalDispense1, TotalDispense2, TotalDispense3, TotalDispense4, CassetteStatus1, CassetteStatus2, CassetteStatus3, CassetteStatus4, AddCash1, AddCash2, AddCash3, AddCash4, Remarks, TimeStamp3,authcode);
        //                    #endregion
        //                }
        //                catch (Exception ex)
        //                {
        //                    ErrorLine++;
        //                }
        //                Remark1 = string.Empty;
        //                Remark2 = string.Empty;
        //                Remark3 = string.Empty;
        //                Remark4 = string.Empty;
        //                Remarks = string.Empty;
        //                Denomination = string.Empty;
        //                RequestCount = string.Empty;
        //                DispenseCount = string.Empty;
        //                RemainCount = string.Empty;
        //                PickupCount = string.Empty;
        //                RejectCount = string.Empty;
        //                TransSEQNumber = string.Empty;
        //                Cassette1 = string.Empty;
        //                Cassette2 = string.Empty;
        //                Cassette3 = string.Empty;
        //                Cassette4 = string.Empty;
        //                Denom1 = string.Empty;
        //                Denom2 = string.Empty;
        //                Denom3 = string.Empty;
        //                Denom4 = string.Empty;
        //                CassetteType1 = string.Empty;
        //                CassetteType2 = string.Empty;
        //                CassetteType3 = string.Empty;
        //                CassetteType4 = string.Empty;
        //                Rejected1 = string.Empty;
        //                Rejected2 = string.Empty;
        //                Rejected3 = string.Empty;
        //                Rejected4 = string.Empty;
        //                Remaining1 = string.Empty;
        //                Remaining2 = string.Empty;
        //                Remaining3 = string.Empty;
        //                Remaining4 = string.Empty;
        //                Dispense1 = string.Empty;
        //                Dispense2 = string.Empty;
        //                Dispense3 = string.Empty;
        //                Dispense4 = string.Empty;
        //                TotalDispense1 = string.Empty;
        //                TotalDispense2 = string.Empty;
        //                TotalDispense3 = string.Empty;
        //                TotalDispense4 = string.Empty;
        //                CassetteStatus1 = string.Empty;
        //                CassetteStatus2 = string.Empty;
        //                CassetteStatus3 = string.Empty;
        //                CassetteStatus4 = string.Empty;
        //                ReserveField1 = string.Empty;
        //                ReserveField2 = string.Empty;
        //                ReserveField3 = string.Empty;
        //                ReserveField4 = string.Empty;
        //                ReserveField5 = string.Empty;
        //                EJDataID = string.Empty;
        //                LineNo1 = EndIndexx;
        //            }
        //            #endregion Upload Ej

        //        }
        //    }

        //    catch (Exception ex)
        //    {
        //        //objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessEJ_DIEBOLDLogSpliter", "ProcessLogSpliterBOB", LineNo, FileName, UserName, 'E');
        //    }


        //    //_DataSet.Tables.Add(_DataTableEod);
        //    foreach (DataRow row in _DataTableEod.Rows)
        //    {
        //        try
        //        {
        //            //if (row["TxnsDateTime"].ToString().Length > 1)
        //            {

        //                _DataTableEod1.Rows.Add();
        //                _DataTableEod1.Rows.Add();
        //                _DataTableEod1.Rows.Add();
        //                _DataTableEod1.Rows.Add();

        //                //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 100, "Type 1", row["Cassette1"], 0, row["Remaining1"], row["Dispensed1"], row["TotalCassette1"], 0, 0, 0, 0, 0, 0);
        //                //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 200, "Type 2", row["Cassette2"], 0, row["Remaining2"], row["Dispensed2"], row["TotalCassette2"], 0, 0, 0, 0, 0, 0);
        //                //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 500, "Type 3", row["Cassette3"], 0, row["Remaining3"], row["Dispensed3"], row["TotalCassette3"], 0, 0, 0, 0, 0, 0);
        //                //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 0, "Type 4", row["Cassette4"], 0, row["Remaining4"], row["Dispensed4"], row["TotalCassette4"], 0, 0, 0, 0, 0, 0);
        //                //InsertCount = InsertCount + 4;
        //            }
        //        }
        //        catch (Exception ex)
        //        {

        //        }
        //    }


        //    //try
        //    //{
        //    //   ds.Tables.Add(_DataTableEod1);
        //    //}

        //    //catch(Exception ex)
        //    //{

        //    //}


        //    MSGLBL = string.Empty;
        //    return _DataTableEod1;
        //}
        #endregion

        #region Cashtally Backupcode add by Asad 22072022

        public DataSet SplitDataNCR(string path, string FileName, out int InsertCount, out int TotalCount, out string MSGLBL, string UserName)
        {

            #region "Declaration"
            DataSet ds = new DataSet();
            string MSG = string.Empty;
            DataSet _DataSet = new DataSet();
            DataTable _DataTableEod = new DataTable();

            //_DataTableEod.Columns.Add("ClientID", typeof(int));
            _DataTableEod.Columns.Add("TerminalID", typeof(string));
            _DataTableEod.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTableEod.Columns.Add("Cassette", typeof(string));
            _DataTableEod.Columns.Add("Denom", typeof(decimal));
            _DataTableEod.Columns.Add("CassetteType", typeof(string));

            _DataTableEod.Columns.Add("Before_INCasset", typeof(decimal));
            _DataTableEod.Columns.Add("Before_PURGE", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Remaining", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Dispensed", typeof(decimal));
            _DataTableEod.Columns.Add("Before_Total", typeof(decimal));

            _DataTableEod.Columns.Add("After_INCasset", typeof(decimal));
            _DataTableEod.Columns.Add("After_PURGE", typeof(decimal));
            _DataTableEod.Columns.Add("After_Remaining", typeof(decimal));
            _DataTableEod.Columns.Add("After_Dispensed", typeof(decimal));
            _DataTableEod.Columns.Add("After_Total", typeof(decimal));

            _DataTableEod.Columns.Add("Total_Diff", typeof(decimal));


            InsertCount = 0;
            TotalCount = 0;
            string[] arrLines;
            arrLines = File.ReadAllLines(path, Encoding.Default);
            string[] ErrorLines = File.ReadAllLines(path, Encoding.Default);
            int StartIndexx = 0;
            int EndIndexx = 0;
            int mngindex = 0;
            int totallength = arrLines.Length;
            string filename = Path.GetFileName(path);
            string result;
            DateTime TimeStamp = System.DateTime.Now;
            string TimeStampchk = string.Empty;
            DateTime TimeStamp1 = System.DateTime.Now;
            DateTime TranDate = System.DateTime.Now;
            DateTime TranDate_dmy = System.DateTime.Now;
            DateTime TimeStamp_dmy = System.DateTime.Now;
            string TerminalId = string.Empty;
            string ReferenceNumber = string.Empty;
            string ECardNumber = string.Empty;
            string CardNumber = string.Empty;
            string CardType = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string ResponseCode = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string CurrencyCode = string.Empty;
            string BranchCode = string.Empty;
            string OPCode = string.Empty;
            string ResultCode = string.Empty;
            string ErrorCode = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string FunctionID = string.Empty;
            string NoOfDuplicate = string.Empty;
            string FilePath = string.Empty;
            string FileDate = string.Empty;
            string CreatedBy = string.Empty;
            string ModifiedBy = string.Empty;
            bool inact = false;
            int ErrorLine = 0;
            string Typecheck = string.Empty;
            string VortexNotes = string.Empty;
            string PreviousAuthCode = string.Empty;
            string NCRNotes = string.Empty;
            #endregion

            TotalCount = arrLines.Length;
            string StartLine = string.Empty;
            if (arrLines.Length > 10)
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(10));
            }
            else
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(arrLines.Length));
            }
            if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
            {
                string result1 = ConvertStringArrayToString(arrLines);
                if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
                {
                    result = result1.Replace("*****START TRANSACTION*****", "|*****START TRANSACTION*****").Replace("CARD NUMBER", "|CARD NUMBER").
                        Replace("AUTH_NR", "|AUTH_NR").Replace("SEQ NUM", "|SEQ NUM").Replace("RSP CODE", "|RSP CODE")
                        .Replace("ACQUIRER_ID", "|ACQUIRER_ID").Replace("AID", "|AID").Replace("AVAIL", "|AVAIL").
                         Replace("LEDGER", "|LEDGER").Replace("WITHDRAWN", "|WITHDRAWN").Replace("a", "|").Replace("READ ERROR", "|READ ERROR").
                         Replace("a", "|").Replace("e1", "").Replace("e2", "").Replace("e3", "").Replace("e4", "").Replace("e5", "").Replace("e6", "")
                        .Replace("e7", "").Replace("e8", "").Replace("e9", "").Replace("e10", "").Replace("e;", "")
                        .Replace("IN CASSETTE", "|IN CASSETTE").Replace("DENOM", "|DENOM").Replace("CASS.TYPE", "|CASS.TYPE").Replace("+PURGE", "|+PURGE")
                        .Replace("OPCODE", "|OPCODE").Replace("NOTES PRESENTED", "|NOTES PRESENTED").Replace("NOTES TAKEN", "|NOTES TAKEN")
                        .Replace("DENOMINATION", "|DENOMINATION").Replace("DISPENSED", "|DISPENSED").Replace("REJECTED", "|REJECTED").Replace("REMAINING", "|REMAINING")
                        .Replace("REMAINING", "|REMAINING").Replace("DISPENSED", "|DISPENSED").Replace("TOTAL", "|TOTAL").Replace("CASSETTE STATUS", "|CASSETTE STATUS")
                        .Replace("LAST CASH COUNTER UPDATE", "|LAST CASH COUNTER UPDATE").Replace("LAST PURGE BIN CLEARED", "|LAST PURGE BIN CLEARED")
                        .Replace("*****END TRANSACTION*****", "|*****END TRANSACTION*****").Replace("DIVERTED NOTES", "|DIVERTED NOTES").
                        Trim();
                    arrLines = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                    arrLines = arrLines.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                }
            }

            TerminalId = Path.GetFileNameWithoutExtension(filename.Split('_').First().Trim().ToString());
            if (TerminalId != "0")
            {
                //bool valresult = ObjVF.GetTerminalID(TerminalId, TerminalId.Length);
                bool valresult = true;
                if (!valresult)
                {
                    //throw new System.ArgumentException("TerminalID data type is not valid.", "original");
                    MSGLBL = "TerminalID data type is not valid and " + "Error is : " + TerminalId;
                    _DataTableEod.Clear();
                    _DataSet.Tables.Add(_DataTableEod);
                    return _DataSet;
                }
            }
            try
            {
                if (arrLines != null && arrLines.Length > 0)
                {
                    StartIndexx = -1;
                    EndIndexx = -1;

                    for (int Line = 0; Line <= arrLines.Length; Line++)
                    {
                        if (GetIndex(arrLines, Line, "CASSETTE   :    C1     C2     C3     C4") != -1)
                        {
                            StartIndexx = GetIndex(arrLines, Line, "CASSETTE   :    C1     C2     C3     C4");
                            EndIndexx = StartIndexx + 10;
                            Line = EndIndexx;
                        }
                    }
                    if (StartIndexx != -1)
                    {
                        for (int LineNoD = StartIndexx - 16; LineNoD <= EndIndexx; LineNoD++)
                        {
                            try
                            {
                                string str_TrTimstamp;
                                string strTr_Date, Time;
                                string result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());
                                string[] EJRequest = result1.Split(new string[] { " " }, StringSplitOptions.None);
                                if (result1.Contains("ESAF")) //ej file index
                                {
                                    string[] TerminalSplit = result1.Split(' ');
                                    strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
                                    string[] date = strTr_Date.Split('-');
                                    strTr_Date = RemoveAdditionalChars(date[0].Trim());
                                    Time = RemoveAdditionalChars(EJRequest[1].Trim());
                                    if (TerminalSplit[3].Trim() == "61")
                                    {
                                        ResponseCode = "61";
                                    }
                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                        TimeStampchk = TimeStamp.ToString();
                                        ResponseCode = TerminalSplit[3].Trim();
                                    }
                                    catch (Exception ex)
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                                        TimeStampchk = TimeStamp.ToString();
                                        ResponseCode = TerminalSplit[3].Trim();
                                    }
                                }
                                else if (result1.Contains("TRANSACTION START"))
                                {
                                    string[] TerminalSplit = result1.Split(' ');
                                    strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
                                    string[] date = strTr_Date.Split('-');
                                    strTr_Date = RemoveAdditionalChars(date[0].Trim());
                                    Time = RemoveAdditionalChars(EJRequest[1].Trim());

                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);
                                        //ResponseCode = TerminalSplit[3].Trim();
                                        TimeStampchk = TimeStamp.ToString();
                                    }
                                    catch (Exception ex)
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                                        TimeStampchk = TimeStamp.ToString();
                                    }
                                    string[] tmp = FileName.Split('_');
                                }
                            }
                            catch { }
                        }
                    }
                    if (StartIndexx != -1 && EndIndexx != -1)
                    {
                        string Cassette1 = string.Empty;
                        string Cassette2 = string.Empty;
                        string Cassette3 = string.Empty;
                        string Cassette4 = string.Empty;
                        decimal Denom1 = 0;
                        decimal Denom2 = 0;
                        decimal Denom3 = 0;
                        decimal Denom4 = 0;
                        string CassetteType1 = string.Empty;
                        string CassetteType2 = string.Empty;
                        string CassetteType3 = string.Empty;
                        string CassetteType4 = string.Empty;
                        string TxnDate = string.Empty;
                        decimal Before_INCasset1 = 0;
                        decimal Before_INCasset2 = 0;
                        decimal Before_INCasset3 = 0;
                        decimal Before_INCasset4 = 0;
                        decimal Before_PURGE1 = 0;
                        decimal Before_PURGE2 = 0;
                        decimal Before_PURGE3 = 0;
                        decimal Before_PURGE4 = 0;
                        decimal Before_Remaining1 = 0;
                        decimal Before_Remaining2 = 0;
                        decimal Before_Remaining3 = 0;
                        decimal Before_Remaining4 = 0;
                        decimal Before_Dispensed1 = 0;
                        decimal Before_Dispensed2 = 0;
                        decimal Before_Dispensed3 = 0;
                        decimal Before_Dispensed4 = 0;
                        decimal Before_Total1 = 0;
                        decimal Before_Total2 = 0;
                        decimal Before_Total3 = 0;
                        decimal Before_Total4 = 0;
                        decimal After_INCasset1 = 0;
                        decimal After_INCasset2 = 0;
                        decimal After_INCasset3 = 0;
                        decimal After_INCasset4 = 0;
                        decimal After_PURGE1 = 0;
                        decimal After_PURGE2 = 0;
                        decimal After_PURGE3 = 0;
                        decimal After_PURGE4 = 0;
                        decimal After_Remaining1 = 0;
                        decimal After_Remaining2 = 0;
                        decimal After_Remaining3 = 0;
                        decimal After_Remaining4 = 0;
                        decimal After_Dispensed1 = 0;
                        decimal After_Dispensed2 = 0;
                        decimal After_Dispensed3 = 0;
                        decimal After_Dispensed4 = 0;
                        decimal After_Total1 = 0;
                        decimal After_Total2 = 0;
                        decimal After_Total3 = 0;
                        decimal After_Total4 = 0;

                        int count = 0;
                        int Rejectcount = 0;
                        int DISPENSEDcount = 0;
                        int TOTAL1count = 0;

                        TxnDate = Path.GetFileNameWithoutExtension(filename).Split('_')[1].ToString();
                        TxnDate = TxnDate.Substring(2);
                        if (TimeStampchk == null || TimeStampchk == "")
                        {
                            try
                            {
                                string dtm = "";
                                string[] CASSETTE = arrLines[StartIndexx - 2].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                if (CASSETTE.Contains("DATE"))
                                {
                                    dtm = CASSETTE[2].Trim().ToString();
                                    dtm = dtm + " " + CASSETTE[3].Trim().ToString();
                                }
                                TimeStamp = DateTime.ParseExact(dtm, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);
                            }
                            catch
                            {
                                try
                                {
                                    string[] txntime = arrLines[StartIndexx - 1].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray(); ;
                                    TimeStamp = DateTime.ParseExact((TxnDate + " " + txntime[0].ToString()), "ddMMyyyy HH:mm:ss", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);
                                }
                                catch
                                {
                                    TimeStamp = DateTime.ParseExact(TxnDate, "ddMMyyyy", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);}
                                }
                            }
                        }
                        #region "Reset 1st"
                        if (StartIndexx < EndIndexx)
                        {
                            try
                            {
                                for (int d = StartIndexx; d <= EndIndexx; d++)
                                {
                                    result = RemoveAdditionalChars(arrLines[d].ToString());
                                    if (!StartLine.Contains("MAC=YES") && arrLines != null && arrLines.Length > 0)
                                    {
                                        try
                                        {
                                            inact = new string[] { "CASSETTE", "*R*" }.Any(s => result.Contains(s));
                                            string[] CASSETTE = arrLines[d].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                            if (CASSETTE.Contains("CASSETTE") && count == 0)
                                            {
                                                Cassette1 = CASSETTE[2].Trim().ToString();
                                                Cassette2 = CASSETTE[3].Trim().ToString();
                                                Cassette3 = CASSETTE[4].Trim().ToString();
                                                Cassette4 = CASSETTE[5].Trim().ToString();
                                            }

                                            if (CASSETTE.Contains("DENOM") && Rejectcount == 0)
                                            {
                                                Denom1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Denom2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Denom3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Denom4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }

                                            if (CASSETTE.Contains("CASS.TYPE") && Rejectcount == 0)
                                            {
                                                CassetteType1 = CASSETTE[2].Trim().ToString();
                                                CassetteType2 = CASSETTE[3].Trim().ToString();
                                                CassetteType3 = CASSETTE[4].Trim().ToString();
                                                CassetteType4 = CASSETTE[5].Trim().ToString();
                                            }
                                            if (CASSETTE.Contains("IN") && CASSETTE.Contains("CASSETTE:"))
                                            {
                                                Before_INCasset1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Before_INCasset2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Before_INCasset3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Before_INCasset4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }

                                            if (CASSETTE.Contains("+PURGE"))
                                            {
                                                Before_PURGE1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Before_PURGE2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Before_PURGE3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Before_PURGE4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }
                                            if (CASSETTE.Contains("=REMAINING"))
                                            {
                                                Before_Remaining1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Before_Remaining2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Before_Remaining3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Before_Remaining4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }
                                            if (CASSETTE.Contains("+DISPENSED") && DISPENSEDcount == 0)
                                            {
                                                Before_Dispensed1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Before_Dispensed2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Before_Dispensed3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Before_Dispensed4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }

                                            if (CASSETTE.Contains("=TOTAL") && TOTAL1count == 0)
                                            {
                                                Before_Total1 = Convert.ToDecimal(CASSETTE[2].Trim());
                                                Before_Total2 = Convert.ToDecimal(CASSETTE[3].Trim());
                                                Before_Total3 = Convert.ToDecimal(CASSETTE[4].Trim());
                                                Before_Total4 = Convert.ToDecimal(CASSETTE[5].Trim());
                                            }
                                        }
                                        catch { }
                                    }
                                }
                                Guid Trans_CycleID1 = Guid.NewGuid();
                                _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette1, Denom1, CassetteType1, Before_INCasset1, Before_PURGE1, Before_Remaining1, Before_Dispensed1, Before_Total1, After_INCasset1, After_PURGE1, After_Remaining1, After_Dispensed1, After_Total1, 0);
                                _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette2, Denom2, CassetteType2, Before_INCasset2, Before_PURGE2, Before_Remaining2, Before_Dispensed2, Before_Total2, After_INCasset2, After_PURGE2, After_Remaining2, After_Dispensed2, After_Total2, 0);
                                _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette3, Denom3, CassetteType3, Before_INCasset3, Before_PURGE3, Before_Remaining3, Before_Dispensed3, Before_Total3, After_INCasset3, After_PURGE3, After_Remaining3, After_Dispensed3, After_Total3, 0);
                                _DataTableEod.Rows.Add(TerminalId, TimeStamp, Cassette4, Denom4, CassetteType4, Before_INCasset4, Before_PURGE4, Before_Remaining4, Before_Dispensed4, Before_Total4, After_INCasset4, After_PURGE4, After_Remaining4, After_Dispensed4, After_Total4, 0);
                                InsertCount = InsertCount + 4;
                            }
                            catch (Exception ex)
                            {
                                ErrorLine++;
                            }
                        }
                        #endregion "Reset 1st"
                    }
                }
            }
            catch (Exception ex)
            {
                //InsertCount = 0;
                //objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessEJ_CashtallyLogSpliter", "ProcessEJ_CashtallyLogSpliter", LineNo, FileName, UserName, 'E');
            }
            _DataSet.Tables.Add(_DataTableEod);
            MSGLBL = string.Empty;
            return _DataSet;
        }

        public DataSet SplitDataNCR1(string path, string FileName, out int InsertCount, out int TotalCount, out string MSGLBL, string UserName)
        {

            #region "Declaration"
            DataSet ds = new DataSet();
            string MSG = string.Empty;
            DataSet _DataSet = new DataSet();
            DataTable _DataTableEod = new DataTable();

            //_DataTableEod.Columns.Add("ClientID", typeof(int));
            _DataTableEod.Columns.Add("TerminalID", typeof(string));
            _DataTableEod.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTableEod.Columns.Add("LastCashCounterCleared", typeof(DateTime));
            _DataTableEod.Columns.Add("LastPurgeBinCleared", typeof(DateTime));
            _DataTableEod.Columns.Add("Denom1", typeof(string));
            _DataTableEod.Columns.Add("Denom2", typeof(string));
            _DataTableEod.Columns.Add("Denom3", typeof(string));
            _DataTableEod.Columns.Add("Denom4", typeof(string));
            _DataTableEod.Columns.Add("Cassette1", typeof(string));
            _DataTableEod.Columns.Add("Cassette2", typeof(string));
            _DataTableEod.Columns.Add("Cassette3", typeof(string));
            _DataTableEod.Columns.Add("Cassette4", typeof(string));
            _DataTableEod.Columns.Add("CassetteType1", typeof(string));
            _DataTableEod.Columns.Add("CassetteType2", typeof(string));
            _DataTableEod.Columns.Add("CassetteType3", typeof(string));
            _DataTableEod.Columns.Add("CassetteType4", typeof(string));
            _DataTableEod.Columns.Add("Rejected1", typeof(string));
            _DataTableEod.Columns.Add("Rejected2", typeof(string));
            _DataTableEod.Columns.Add("Rejected3", typeof(string));
            _DataTableEod.Columns.Add("Rejected4", typeof(string));
            _DataTableEod.Columns.Add("Remaining1", typeof(string));
            _DataTableEod.Columns.Add("Remaining2", typeof(string));
            _DataTableEod.Columns.Add("Remaining3", typeof(string));
            _DataTableEod.Columns.Add("Remaining4", typeof(string));
            _DataTableEod.Columns.Add("Dispensed1", typeof(string));
            _DataTableEod.Columns.Add("Dispensed2", typeof(string));
            _DataTableEod.Columns.Add("Dispensed3", typeof(string));
            _DataTableEod.Columns.Add("Dispensed4", typeof(string));
            _DataTableEod.Columns.Add("TotalCassette1", typeof(string));
            _DataTableEod.Columns.Add("TotalCassette2", typeof(string));
            _DataTableEod.Columns.Add("TotalCassette3", typeof(string));
            _DataTableEod.Columns.Add("TotalCassette4", typeof(string));
            _DataTableEod.Columns.Add("CassetteStatus1", typeof(string));
            _DataTableEod.Columns.Add("CassetteStatus2", typeof(string));
            _DataTableEod.Columns.Add("CassetteStatus3", typeof(string));
            _DataTableEod.Columns.Add("CassetteStatus4", typeof(string));
            _DataTableEod.Columns.Add("AddCash1", typeof(string));
            _DataTableEod.Columns.Add("AddCash2", typeof(string));
            _DataTableEod.Columns.Add("AddCash3", typeof(string));
            _DataTableEod.Columns.Add("AddCash4", typeof(string));
            _DataTableEod.Columns.Add("Remarks", typeof(string));
            _DataTableEod.Columns.Add("NoOfDuplicate", typeof(int));

            DataTable _DataTableEod1 = new DataTable();
            _DataTableEod1.Columns.Add("TerminalID", typeof(string));
            _DataTableEod1.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTableEod1.Columns.Add("Cassette", typeof(string));
            _DataTableEod1.Columns.Add("Denom", typeof(decimal));
            _DataTableEod1.Columns.Add("CassetteType", typeof(string));
            _DataTableEod1.Columns.Add("Before_INCasset", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_PURGE", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_Remaining", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_Dispensed", typeof(decimal));
            _DataTableEod1.Columns.Add("Before_Total", typeof(decimal));
            _DataTableEod1.Columns.Add("After_INCasset", typeof(decimal));
            _DataTableEod1.Columns.Add("After_PURGE", typeof(decimal));
            _DataTableEod1.Columns.Add("After_Remaining", typeof(decimal));
            _DataTableEod1.Columns.Add("After_Dispensed", typeof(decimal));
            _DataTableEod1.Columns.Add("After_Total", typeof(decimal));
            _DataTableEod1.Columns.Add("Total_Diff", typeof(decimal));

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            string[] arrLines;
            arrLines = File.ReadAllLines(path, Encoding.Default);
            string[] ErrorLines = File.ReadAllLines(path, Encoding.Default);
            int StartIndex = 0;
            int EndIndex = 0;
            int StartIndex1 = 0;
            int EndIndex1 = 0;
            int StartIndexx = 0;
            int EndIndexx = 0;
            int totallength = arrLines.Length;
            string filename = Path.GetFileName(path);
            string result;
            DateTime TimeStamp = System.DateTime.Now;
            DateTime TimeStamp1 = System.DateTime.Now;
            DateTime? CounterDate = null;
            DateTime? ClearedDate = null;
            DateTime TranDate = System.DateTime.Now;
            DateTime TranDate_dmy = System.DateTime.Now;
            DateTime TimeStamp_dmy = System.DateTime.Now;
            string Remark1 = string.Empty;
            string Remark2 = string.Empty;
            string Remark3 = string.Empty;
            string Remark4 = string.Empty;
            string Remarks = string.Empty;
            string Denomination = string.Empty;
            string RequestCount = string.Empty;
            string DispenseCount = string.Empty;
            string RemainCount = string.Empty;
            string PickupCount = string.Empty;
            string RejectCount = string.Empty;
            string TransSEQNumber = string.Empty;
            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            string Denom1 = string.Empty;
            string Denom2 = string.Empty;
            string Denom3 = string.Empty;
            string Denom4 = string.Empty;
            string CassetteType1 = string.Empty;
            string CassetteType2 = string.Empty;
            string CassetteType3 = string.Empty;
            string CassetteType4 = string.Empty;
            string Rejected1 = string.Empty;
            string Rejected2 = string.Empty;
            string Rejected3 = string.Empty;
            string Rejected4 = string.Empty;
            string Remaining1 = string.Empty;
            string Remaining2 = string.Empty;
            string Remaining3 = string.Empty;
            string Remaining4 = string.Empty;
            string Dispense1 = string.Empty;
            string Dispense2 = string.Empty;
            string Dispense3 = string.Empty;
            string Dispense4 = string.Empty;
            string TotalDispense1 = string.Empty;
            string TotalDispense2 = string.Empty;
            string TotalDispense3 = string.Empty;
            string TotalDispense4 = string.Empty;
            string CassetteStatus1 = string.Empty;
            string CassetteStatus2 = string.Empty;
            string CassetteStatus3 = string.Empty;
            string CassetteStatus4 = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string EJDataID = string.Empty;
            string AddCash1 = string.Empty;
            string AddCash2 = string.Empty;
            string AddCash3 = string.Empty;
            string AddCash4 = string.Empty;
            string TerminalId = string.Empty;
            string ReferenceNumber = string.Empty;
            string ECardNumber = string.Empty;
            string CardNumber = string.Empty;
            string CardType = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            DateTime? TxnsDateTime = null;
            DateTime? TxnsDateTimeFailed = null;
            decimal TxnsAmount = 0;
            decimal Amount1 = 0;
            decimal Amount2 = 0;
            decimal Amount3 = 0;
            string TxnsType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string ResponseCode = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            decimal FeeAmount = 0;
            string CurrencyCode = string.Empty;
            decimal CustBalance = 0;
            decimal InterchangeBalance = 0;
            decimal ATMBalance = 0;
            string BranchCode = string.Empty;
            string OPCode = string.Empty;
            string ResultCode = string.Empty;
            string ErrorCode = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string FunctionID = string.Empty;
            decimal InitAmount = 0;
            decimal DispAmount = 0;
            decimal StorAmount = 0;
            decimal RemAmount = 0;
            string NoOfDuplicate = string.Empty;
            string FilePath = string.Empty;
            string FileDate = string.Empty;
            DateTime? CreatedOn = null;
            DateTime? ModifiedOn = null;
            string CreatedBy = string.Empty;
            string ModifiedBy = string.Empty;
            bool inact = false;
            int LineNo1 = 0;
            bool flag = false;
            int ErrorLine = 0;
            string Typecheck = string.Empty;
            string VortexNotes = string.Empty;
            string PreviousAuthCode = string.Empty;
            string NCRNotes = string.Empty;
            #endregion
            string StartLine = string.Empty;
            if (arrLines.Length > 10)
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(10));
            }
            else
            {
                StartLine = string.Join("\r\n", File.ReadLines(path).Take(arrLines.Length));
            }
            if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
            {
                string result1 = ConvertStringArrayToString(arrLines);
                if ((StartLine.Contains("MAC=YES") || StartLine.Contains("aLUNO")) && arrLines != null && arrLines.Length > 0)
                {
                    result = result1.Replace("*****START TRANSACTION*****", "|*****START TRANSACTION*****").Replace("CARD NUMBER", "|CARD NUMBER").
                        Replace("AUTH_NR", "|AUTH_NR").Replace("SEQ NUM", "|SEQ NUM").Replace("RSP CODE", "|RSP CODE")
                        .Replace("ACQUIRER_ID", "|ACQUIRER_ID").Replace("AID", "|AID").Replace("AVAIL", "|AVAIL").
                         Replace("LEDGER", "|LEDGER").Replace("WITHDRAWN", "|WITHDRAWN").Replace("a", "|").Replace("READ ERROR", "|READ ERROR").
                         Replace("a", "|").Replace("e1", "").Replace("e2", "").Replace("e3", "").Replace("e4", "").Replace("e5", "").Replace("e6", "")
                        .Replace("e7", "").Replace("e8", "").Replace("e9", "").Replace("e10", "").Replace("e;", "")
                        .Replace("IN CASSETTE", "|IN CASSETTE").Replace("DENOM", "|DENOM").Replace("CASS.TYPE", "|CASS.TYPE").Replace("+PURGE", "|+PURGE")
                        .Replace("OPCODE", "|OPCODE").Replace("NOTES PRESENTED", "|NOTES PRESENTED").Replace("NOTES TAKEN", "|NOTES TAKEN")
                        .Replace("DENOMINATION", "|DENOMINATION").Replace("DISPENSED", "|DISPENSED").Replace("REJECTED", "|REJECTED").Replace("REMAINING", "|REMAINING")
                        .Replace("REMAINING", "|REMAINING").Replace("DISPENSED", "|DISPENSED").Replace("TOTAL", "|TOTAL").Replace("CASSETTE STATUS", "|CASSETTE STATUS")
                        .Replace("LAST CASH COUNTER UPDATE", "|LAST CASH COUNTER UPDATE").Replace("LAST PURGE BIN CLEARED", "|LAST PURGE BIN CLEARED")
                        .Replace("*****END TRANSACTION*****", "|*****END TRANSACTION*****").Replace("DIVERTED NOTES", "|DIVERTED NOTES").
                        Trim();
                    arrLines = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                    arrLines = arrLines.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                }
            }

            TerminalId = Path.GetFileNameWithoutExtension(filename.Split('_').First().Trim().ToString());
            if (TerminalId != "0")
            {

            }

            try
            {
                if (arrLines != null && arrLines.Length > 0)
                {
                    StartIndex = -1;
                    EndIndex = -1;
                    for (LineNo = 0; LineNo <= arrLines.Length; LineNo++)
                    {
                        if (GetIndex(arrLines, LineNo, "CASH TOTAL       TYPE1 TYPE2 TYPE3 TYPE4") != -1)
                        {
                            StartIndex = GetIndex(arrLines, LineNo, "CASH TOTAL       TYPE1 TYPE2 TYPE3 TYPE4");
                            EndIndex = StartIndex + 6;
                        }
                    }

                    if (StartIndex != -1)
                    {
                        for (int LineNoD = StartIndex - 18; LineNoD <= EndIndex; LineNoD++)
                        {
                            try
                            {
                                string str_TrTimstamp;
                                string strTr_Date, Time;
                                string result1 = RemoveAdditionalChars(arrLines[LineNoD].ToString());
                                string[] EJRequest = result1.Split(new string[] { " " }, StringSplitOptions.None);

                                if (result1.Contains("DATE") && result1.Contains("TIME"))
                                {
                                    string[] TerminalSplit = result1.Split(' ');
                                    // strTr_Date = RemoveAdditionalChars(TerminalSplit[0].ToString());
                                    //string[] date = strTr_Date.Split('-');
                                    strTr_Date = RemoveAdditionalChars(TerminalSplit[1].Trim());
                                    Time = RemoveAdditionalChars(TerminalSplit[3].Trim());

                                    strTr_Date = strTr_Date.Replace("-", "/");
                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);
                                        CounterDate = TimeStamp;
                                        //ResponseCode = TerminalSplit[3].Trim();
                                    }
                                    catch (Exception ex)
                                    {

                                        try
                                        {
                                            TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm", CultureInfo.InvariantCulture);
                                            CounterDate = TimeStamp;
                                            // ResponseCode = TerminalSplit[3].Trim();
                                        }
                                        catch (Exception E11)
                                        {


                                        }

                                    }
                                }
                                if (result1.Contains("DATE        TIME      ATM-ID   RESP"))
                                {
                                    result1 = RemoveAdditionalChars(arrLines[LineNoD + 1].ToString());
                                    string[] TerminalSplit = result1.Split(' ');
                                    strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
                                    if (strTr_Date.Contains("-"))
                                    {
                                        string[] date = strTr_Date.Split('-');
                                        strTr_Date = RemoveAdditionalChars(date[0].Trim());
                                        Time = RemoveAdditionalChars(EJRequest[1].Trim());
                                    }
                                    else
                                    {
                                        // string[] date = strTr_Date.Split('-');
                                        strTr_Date = RemoveAdditionalChars(TerminalSplit[0].Trim());
                                        Time = RemoveAdditionalChars(TerminalSplit[1].Trim());
                                    }
                                    //if (TerminalSplit[3].Trim() == "61")
                                    //{
                                    //    ResponseCode = "61";
                                    //}
                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                        CounterDate = TimeStamp;
                                        ResponseCode = TerminalSplit[3].Trim();
                                    }
                                    catch (Exception ex)
                                    {
                                        try
                                        {
                                            TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                                            CounterDate = TimeStamp;
                                        }
                                        catch (Exception EX1)
                                        {


                                        }

                                        //ResponseCode = TerminalSplit[3].Trim();
                                    }

                                }
                                if (result1.Contains("ESAF")) //ej file index
                                {
                                    string[] TerminalSplit = result1.Split(' ');
                                    strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
                                    if (strTr_Date.Contains("-"))
                                    {
                                        string[] date = strTr_Date.Split('-');
                                        strTr_Date = RemoveAdditionalChars(date[0].Trim());
                                        Time = RemoveAdditionalChars(EJRequest[1].Trim());
                                    }
                                    else
                                    {
                                        // string[] date = strTr_Date.Split('-');
                                        strTr_Date = RemoveAdditionalChars(TerminalSplit[0].Trim());
                                        Time = RemoveAdditionalChars(TerminalSplit[1].Trim());
                                    }
                                    //if (TerminalSplit[3].Trim() == "61")
                                    //{
                                    //    ResponseCode = "61";
                                    //}
                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                        CounterDate = TimeStamp;
                                        ResponseCode = TerminalSplit[3].Trim();
                                    }
                                    catch (Exception ex)
                                    {
                                        try
                                        {
                                            TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                                            CounterDate = TimeStamp;
                                        }
                                        catch (Exception EX3)
                                        {


                                        }

                                        //ResponseCode = TerminalSplit[3].Trim();
                                    }

                                }
                                else if (result1.Contains("TRANSACTION START"))
                                {
                                    string[] TerminalSplit = result1.Split(' ');
                                    strTr_Date = RemoveAdditionalChars(EJRequest[0].ToString());
                                    string[] date = strTr_Date.Split('-');
                                    strTr_Date = RemoveAdditionalChars(date[0].Trim());
                                    Time = RemoveAdditionalChars(EJRequest[1].Trim());

                                    str_TrTimstamp = strTr_Date + " " + Time;
                                    try
                                    {
                                        TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yy HH:mm:ss", CultureInfo.InvariantCulture);
                                        //ResponseCode = TerminalSplit[3].Trim();
                                        CounterDate = TimeStamp;
                                    }
                                    catch (Exception ex)
                                    {
                                        try
                                        {
                                            TimeStamp = DateTime.ParseExact(str_TrTimstamp, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture);
                                            CounterDate = TimeStamp;
                                        }
                                        catch (Exception EX2)
                                        {


                                        }

                                    }
                                    string[] tmp = FileName.Split('_');
                                }
                            }
                            catch { }
                        }
                    }

                    #region Upload Ej
                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        Cassette1 = string.Empty;
                        Cassette2 = string.Empty;
                        Cassette3 = string.Empty;
                        Cassette4 = string.Empty;
                        Denom1 = string.Empty;
                        Denom2 = string.Empty;
                        Denom3 = string.Empty;
                        Denom4 = string.Empty;
                        CassetteType1 = string.Empty;
                        CassetteType2 = string.Empty;
                        CassetteType3 = string.Empty;
                        CassetteType4 = string.Empty;
                        Remaining1 = string.Empty;
                        Remaining2 = string.Empty;
                        Remaining3 = string.Empty;
                        Remaining4 = string.Empty;
                        Dispense1 = string.Empty;
                        Dispense2 = string.Empty;
                        Dispense3 = string.Empty;
                        Dispense4 = string.Empty;
                        TotalDispense1 = string.Empty;
                        TotalDispense2 = string.Empty;
                        TotalDispense3 = string.Empty;
                        TotalDispense4 = string.Empty;
                        CassetteStatus1 = string.Empty;
                        CassetteStatus2 = string.Empty;
                        CassetteStatus3 = string.Empty;
                        CassetteStatus4 = string.Empty;
                        AddCash1 = string.Empty;
                        AddCash2 = string.Empty;
                        AddCash3 = string.Empty;
                        AddCash4 = string.Empty;
                        string TxnDate = string.Empty;

                        TxnDate = Path.GetFileNameWithoutExtension(filename).Split('_')[1].ToString();
                        TxnDate = TxnDate.Substring(2);
                        try
                        {
                            TimeStamp = DateTime.ParseExact(TxnDate, "yyyyMMdd", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);

                        }
                        catch
                        {

                            TimeStamp = DateTime.ParseExact(TxnDate, "ddMMyyyy", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);

                        }
                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            #region "EOD"
                            try
                            {
                                result = RemoveAdditionalChars(arrLines[k].ToString());
                                if (!StartLine.Contains("MAC=YES") && arrLines != null && arrLines.Length > 0)
                                {
                                    inact = new string[] { "CASSETTE", "*R*" }.Any(s => result.Contains(s));
                                    int Rejectcount = 0;
                                    int REMAINING1count = 0;
                                    int DISPENSEDcount = 0;
                                    int TOTAL1count = 0;

                                    string[] CASSETTE = arrLines[k].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    if (CASSETTE.Contains("CASH") && CASSETTE.Contains("TOTAL"))
                                    {
                                        Cassette1 = CASSETTE[1].Trim().ToString();
                                        Cassette2 = CASSETTE[2].Trim().ToString();
                                        Cassette3 = CASSETTE[1].Trim().ToString();
                                        Cassette4 = CASSETTE[2].Trim().ToString();
                                    }

                                    if (CASSETTE.Contains("REJECTED"))
                                    {
                                        Rejected1 = CASSETTE[1].Trim().ToString();
                                        Rejected2 = CASSETTE[2].Trim().ToString();
                                        Rejected3 = CASSETTE[3].Trim().ToString();
                                        Rejected4 = CASSETTE[4].Trim().ToString();
                                    }

                                    if (CASSETTE.Contains("REMAINING"))
                                    {
                                        Remaining1 = CASSETTE[1].Trim().ToString();
                                        Remaining2 = CASSETTE[2].Trim().ToString();
                                        Remaining3 = CASSETTE[3].Trim().ToString();
                                        Remaining4 = CASSETTE[4].Trim().ToString();
                                    }
                                    if (CASSETTE.Contains("+DISPENSED"))
                                    {
                                        Dispense1 = CASSETTE[1].Trim().ToString();
                                        Dispense2 = CASSETTE[2].Trim().ToString();
                                        Dispense3 = CASSETTE[3].Trim().ToString();
                                        Dispense4 = CASSETTE[4].Trim().ToString();

                                    }

                                    if (CASSETTE.Contains("=TOTAL") && TOTAL1count == 0)
                                    {
                                        TOTAL1count++;
                                        TotalDispense1 = CASSETTE[1].Trim().ToString();
                                        TotalDispense2 = CASSETTE[2].Trim().ToString();
                                        TotalDispense3 = CASSETTE[1].Trim().ToString();
                                        TotalDispense4 = CASSETTE[2].Trim().ToString();

                                    }

                                }
                            }
                            catch (Exception ex)
                            {
                            }
                        }

                        try
                        {
                            Guid Trans_CycleID1 = Guid.NewGuid();
                            _DataTableEod.Rows.Add(TerminalId, CounterDate, CounterDate, ClearedDate, Denom1, Denom2, Denom3, Denom4, Cassette1, Cassette2, Cassette3, Cassette4, CassetteType1, CassetteType2, CassetteType3, CassetteType4, Rejected1, Rejected2, Rejected3, Rejected4, Remaining1, Remaining2, Remaining3, Remaining4, Dispense1, Dispense2, Dispense3, Dispense4, TotalDispense1, TotalDispense2, TotalDispense3, TotalDispense4, CassetteStatus1, CassetteStatus2, CassetteStatus3, CassetteStatus4, AddCash1, AddCash2, AddCash3, AddCash4, Remarks, '0');
                            #endregion
                        }
                        catch (Exception ex)
                        {
                            ErrorLine++;
                        }
                        Remark1 = string.Empty;
                        Remark2 = string.Empty;
                        Remark3 = string.Empty;
                        Remark4 = string.Empty;
                        Remarks = string.Empty;
                        Denomination = string.Empty;
                        RequestCount = string.Empty;
                        DispenseCount = string.Empty;
                        RemainCount = string.Empty;
                        PickupCount = string.Empty;
                        RejectCount = string.Empty;
                        TransSEQNumber = string.Empty;
                        Cassette1 = string.Empty;
                        Cassette2 = string.Empty;
                        Cassette3 = string.Empty;
                        Cassette4 = string.Empty;
                        Denom1 = string.Empty;
                        Denom2 = string.Empty;
                        Denom3 = string.Empty;
                        Denom4 = string.Empty;
                        CassetteType1 = string.Empty;
                        CassetteType2 = string.Empty;
                        CassetteType3 = string.Empty;
                        CassetteType4 = string.Empty;
                        Rejected1 = string.Empty;
                        Rejected2 = string.Empty;
                        Rejected3 = string.Empty;
                        Rejected4 = string.Empty;
                        Remaining1 = string.Empty;
                        Remaining2 = string.Empty;
                        Remaining3 = string.Empty;
                        Remaining4 = string.Empty;
                        Dispense1 = string.Empty;
                        Dispense2 = string.Empty;
                        Dispense3 = string.Empty;
                        Dispense4 = string.Empty;
                        TotalDispense1 = string.Empty;
                        TotalDispense2 = string.Empty;
                        TotalDispense3 = string.Empty;
                        TotalDispense4 = string.Empty;
                        CassetteStatus1 = string.Empty;
                        CassetteStatus2 = string.Empty;
                        CassetteStatus3 = string.Empty;
                        CassetteStatus4 = string.Empty;
                        ReserveField1 = string.Empty;
                        ReserveField2 = string.Empty;
                        ReserveField3 = string.Empty;
                        ReserveField4 = string.Empty;
                        ReserveField5 = string.Empty;
                        EJDataID = string.Empty;
                        LineNo1 = EndIndexx;
                    }
                    #endregion Upload Ej

                }
            }

            catch (Exception ex)
            {
                //objLogWriter.FunErrorLog("Transaction not found", BankCode, "ProcessEJ_DIEBOLDLogSpliter", "ProcessLogSpliterBOB", LineNo, FileName, UserName, 'E');
            }


            //_DataSet.Tables.Add(_DataTableEod);
            foreach (DataRow row in _DataTableEod.Rows)
            {
                try
                {
                    //if (row["TxnsDateTime"].ToString().Length > 1)
                    {

                        _DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 100, "Type 1", 0, 0, row["Remaining1"], 0, 0, 0, 0, 0, 0, 0, 0);
                        _DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 200, "Type 2", 0, 0, row["Remaining2"], 0, 0, 0, 0, 0, 0, 0, 0);
                        _DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 500, "Type 3", 0, 0, row["Remaining3"], 0, 0, 0, 0, 0, 0, 0, 0);
                        _DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 500, "Type 4", 0, 0, row["Remaining4"], 0, 0, 0, 0, 0, 0, 0, 0);

                        //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 100, "Type 1", row["Cassette1"], 0, row["Remaining1"], row["Dispensed1"], row["TotalCassette1"], 0, 0, 0, 0, 0, 0);
                        //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 200, "Type 2", row["Cassette2"], 0, row["Remaining2"], row["Dispensed2"], row["TotalCassette2"], 0, 0, 0, 0, 0, 0);
                        //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 500, "Type 3", row["Cassette3"], 0, row["Remaining3"], row["Dispensed3"], row["TotalCassette3"], 0, 0, 0, 0, 0, 0);
                        //_DataTableEod1.Rows.Add(TerminalId, row["TxnsDateTime"], "", 0, "Type 4", row["Cassette4"], 0, row["Remaining4"], row["Dispensed4"], row["TotalCassette4"], 0, 0, 0, 0, 0, 0);
                        //InsertCount = InsertCount + 4;
                    }
                }
                catch { }
            }
            _DataSet.Tables.Add(_DataTableEod1);
            MSGLBL = string.Empty;
            return _DataSet;
        }

        #endregion Cashtally Backupcode



    }
}