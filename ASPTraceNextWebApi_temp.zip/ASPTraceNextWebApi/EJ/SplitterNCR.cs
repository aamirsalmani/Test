﻿using ImportData;
using System; 
using System.Data; 
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Xml;
using Utility;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace EJ
{
    public class SplitterNCR
    { 
        private readonly string _connectionString;
        BulkImports bulkimports;
        public SplitterNCR(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        public DataTable ASP_SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTimeConverter objDateTimeConverter = new DateTimeConverter();
            System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("CustAccountNo", typeof(string));
            _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
            _DataTable.Columns.Add("ATMAccountNo", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("Amount2", typeof(decimal));
            _DataTable.Columns.Add("Amount3", typeof(decimal));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
            _DataTable.Columns.Add("ATMBalance", typeof(decimal));
            _DataTable.Columns.Add("BranchCode", typeof(string));
            _DataTable.Columns.Add("TransSEQNumber", typeof(string));
            _DataTable.Columns.Add("OPCode", typeof(string));
            _DataTable.Columns.Add("ResultCode", typeof(string));
            _DataTable.Columns.Add("ErrorCode", typeof(string));
            _DataTable.Columns.Add("TCode", typeof(string));
            _DataTable.Columns.Add("TCode1", typeof(string));
            _DataTable.Columns.Add("FunctionID", typeof(string));
            _DataTable.Columns.Add("Amount", typeof(decimal));
            _DataTable.Columns.Add("Denomination", typeof(string));
            _DataTable.Columns.Add("RequestCount", typeof(string));
            _DataTable.Columns.Add("DispenseCount", typeof(string));
            _DataTable.Columns.Add("RemainCount", typeof(string));
            _DataTable.Columns.Add("PickupCount", typeof(string));
            _DataTable.Columns.Add("RejectCount", typeof(string));
            _DataTable.Columns.Add("Cassette1", typeof(string));
            _DataTable.Columns.Add("Cassette2", typeof(string));
            _DataTable.Columns.Add("Cassette3", typeof(string));
            _DataTable.Columns.Add("Cassette4", typeof(string));
            //_DataTable.Columns.Add("InitAmount", typeof(decimal));
            //_DataTable.Columns.Add("DispAmount", typeof(decimal));
            //_DataTable.Columns.Add("StorAmount", typeof(decimal));
            //_DataTable.Columns.Add("RemAmount", typeof(decimal));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("NoOfDuplicate", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;
            int StartIndex1 = 0;
            int EndIndex1 = 0;
            int StartIndexx = 0;
            int EndIndexx = 0;

            
            

            
            
            
            

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            DateTime TimeStamp = System.DateTime.Now;
            DateTime TimeStamp1 = System.DateTime.Now;
            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            //DateTime? TxnsDateTime;
            //TxnsDateTime = null;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            //string TxnsAmount = "0";
            decimal TxnsAmount = 0;
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            //DateTime? TxnsPostDateTime;
            //TxnsPostDateTime = null;
            string TxnsValueDateTime = string.Empty;
            //DateTime? TxnsValueDateTime;
            //TxnsValueDateTime = null;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string line = string.Empty;
            string line1 = string.Empty;
            string ResponseCode = string.Empty;
            string EJResult = string.Empty;
            string StrDateTime = string.Empty;
            string StrTime = string.Empty;
            string ErrorCode = string.Empty;
            string terminal = string.Empty;
            string TransSeqNo = string.Empty;
            string Opcode = string.Empty;
            string FunctionId = string.Empty;
            string Denomination = string.Empty;
            string ReqCount = string.Empty;
            string DispenseCount = string.Empty;
            string PickupCount = string.Empty;
            string RemainCount = string.Empty;
            string RejectCount = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string resultCode = string.Empty;
            string Remark3 = string.Empty;
            string ECardNumber = string.Empty;

            decimal Amount = 0;
            int LineNo1 = 0;
            bool flag = false;
            terminal = FileName.Substring(0, 8);
            //int LineNo = 0;
            int ErrorLine = 0;


            int ModeID = 0;
            int ChannelID = 0;
            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;

            string SplitType = ",";
            string[] TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] AcquirerIDArray = dt.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode1Array = dt.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode2Array = dt.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ReversalType = dt.Rows[0]["ReversalType"].ToString();
            string[] ATMType = dt.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CDMType = dt.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] POSType = dt.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ECOMType = dt.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] IMPType = dt.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] UPIType = dt.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MicroATMType = dt.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MobileRechargeType = dt.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BalanceEnquiry = dt.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MiniStatement = dt.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] PinChange = dt.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ChequeBookReq = dt.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ResponseType = dt.Rows[0]["ResponseType"].ToString();
            string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ResponseCode2Array = dt.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] OfflineCode = dt.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnDateTime = dt.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnPostDateTime = dt.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] DebitCode = dt.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CreditCode = dt.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);

            bool card = false;
            bool Terminal = false;
            bool Acquirer = false;
            bool Rev1 = false;
            bool Rev2 = false;
            bool ATM = false;
            bool CDM = false;
            bool POS = false;
            bool ECOM = false;
            bool IMPS = false;
            bool UPI = false;
            bool MicroATM = false;
            bool MobileRecharge = false;
            bool BAL = false;
            bool MS = false;
            bool PC = false;
            bool CB = false;
            bool RCA1 = false;
            bool RCA2 = false;
            bool MC = false;
            bool VC = false;
            bool OC = false;
            bool D = false;
            bool C = false;

            int FromRange = 0;
            int ToRange = 0;

            string error;
            string amountstr;
            string[] Dis;
            string[] Rem;
            string[] Note;
            string[] Notes;

            int i = 0;

            for (int j = 0; j <= TotalCount; j++)
            {
                try
                {
                    //StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID");
                    //EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "------------------------------------");
                    StartIndex1 = Common.GetIndex(TotalCountArray, j, "ATM ID   :");
                    EndIndex1 = Common.GetIndex(TotalCountArray, j + 1, "------------------------------------");

                    //StartIndex = Common.GetIndex(TotalCountArray, j, "TRANSACTION START");
                    //EndIndex = Common.GetIndex(TotalCountArray, j + 1, "TRANSACTION END");

                    StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID");
                    if (ClientID == 40)
                    {
                        EndIndex = Common.GetIndex(TotalCountArray, j + 1, "RESP CODE") + 3;
                    }
                    else
                    {
                        EndIndex = Common.GetIndex(TotalCountArray, j + 1, "RESP CODE") + 5;
                    }

                    if (StartIndex > EndIndex)
                    {

                        StartIndex = Common.GetIndex(TotalCountArray, j, "CARD NUMBER");
                        if (StartIndex > EndIndex)
                        {
                            StartIndex = Common.GetIndex(TotalCountArray, j, "TRANSACTION REQUESTING");
                            if (StartIndex > EndIndex)
                            {
                                StartIndex = Common.GetIndex(TotalCountArray, j, "TRANSACTION REPLIED");
                            }
                        }
                    }

                    flag = false;
                    if (StartIndex > StartIndex1 && StartIndex1 != -1)
                    {
                        StartIndex = StartIndex1 - 28;
                        EndIndex = EndIndex1 + 17;
                        flag = true;
                    }

                    StartIndexx = Common.GetIndex(TotalCountArray, LineNo1, "ENTERED SUPERVISOR PROGRAM");
                    EndIndexx = Common.GetIndex(TotalCountArray, LineNo1 + 1, "GO IN-SERVICE");
                    //TotalCount++;                  

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {
                                LineNo++;
                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = Common.RemoveAdditionalChars(line);
                                if (EJResult.Contains("ATM ID"))
                                {
                                    TerminalID = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                if (EJResult.Contains("REF NO") || EJResult.Contains("RRN NO.") || EJResult.Contains("REF NO   :"))
                                {
                                    ReferenceNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    if (ReferenceNumber == "925717009979")
                                    {

                                    }
                                }

                                if (EJResult.Contains("DATE"))  // || TotalCountArray[k - 1].ToString().Contains("/")
                                {
                                    //StrDateTime = TotalCountArray[k - 1].ToString().Replace("BANK OF BARODADUGRI ROAD, LUDHIANALUDHIANA", "").ToString().Trim();
                                    //TxnsDateTime = StrDateTime;
                                    ////TxnsDateTime = DateTime.ParseExact(StrDateTime, "dd/MM/yy HH:mm", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);
                                    //TxnsValueDateTime = TxnsDateTime;
                                    //TxnsPostDateTime = TxnsDateTime;
                                    StrDateTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsDate = StrDateTime;
                                }

                                if (EJResult.Contains("TIME") && !(EJResult.Contains("Timeout")) && !(EJResult.Contains("TIMEOUT")) && !(EJResult.Contains("PRESENT TIMER EXPIRED"))) //|| TotalCountArray[k - 1].ToString().Contains("/")                                   
                                {
                                    //StrDateTime = TotalCountArray[k - 1].ToString().Replace("BANK OF BARODADUGRI ROAD, LUDHIANALUDHIANA", "").ToString().Trim();
                                    //TxnsDateTime = StrDateTime;
                                    ////TxnsDateTime = DateTime.ParseExact(StrDateTime, "dd/MM/yy HH:mm", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);
                                    //TxnsValueDateTime = TxnsDateTime;
                                    //TxnsPostDateTime = TxnsDateTime;
                                    StrTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsTime = StrTime;
                                }

                                if (EJResult.Contains("CARD NO"))
                                {
                                    CardNumber = string.Empty;
                                    CardNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("A/C NO") || EJResult.Contains("ACCOUNT NO") || EJResult.Contains("ACCT NO"))
                                {
                                    CustAccountNo = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();// Str_Accs[1].ToString().Trim();                                        
                                }

                                //if (EJResult.Contains("WITHDRAWAL"))
                                //{
                                //    //string[] splitTXN_type = EJResult.Split(':');
                                //    TxnsSubType = "WITHDRAWAL";
                                //}
                                if (EJResult.Contains("TRANSTYPE"))
                                {
                                    //string[] splitTXN_type = EJResult.Split(':');
                                    TxnsSubType = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("SEQ NO."))
                                {
                                    //string[] splitTXN_type = EJResult.Split(':');
                                    TxnsNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("RESP CODE"))
                                {
                                    ResponseCode = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("RESP CODE"))
                                {
                                    error = TotalCountArray[k + 1].ToString();
                                    if (!error.Contains("TRANS AMOUNT") && TxnsSubType == "CASH WITHDRAWAL")
                                    {
                                        ErrorCode = error;
                                    }
                                }

                                if (EJResult.Contains("TRANS AMOUNT") || (EJResult.Contains("WDL AMT")))
                                {
                                    amountstr = EJResult.Substring(EJResult.IndexOf(":") + 1).Replace("RS.", "").Trim();
                                    TxnsAmount = Convert.ToDecimal(amountstr);
                                }

                                if (EJResult.Contains("TRANS SEQ NUMBER"))
                                {
                                    TransSeqNo = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                if (EJResult.Contains("OPCode") || (EJResult.Contains("OPCODE")))
                                {
                                    Opcode = EJResult.Substring(EJResult.IndexOf("=") + 2).Trim();
                                }

                                if (EJResult.Contains("Function ID") || EJResult.Contains("FUNCTION ID"))
                                {
                                    FunctionId = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                }

                                //if (EJResult.Contains("AMOUNT"))
                                //{
                                //    string amountstr = EJResult.Substring(EJResult.IndexOf("[") + 1).Replace("RS.", "").Trim();
                                //    amountstr = amountstr.TrimEnd(']');
                                //    Amount = Convert.ToDecimal(amountstr);
                                //}

                                if (EJResult.Contains("DENOMINATION"))
                                {
                                    //Denomination = EJResult.Substring(EJResult.IndexOf(" ")).Trim();
                                    //Denomination = Denomination.Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                }

                                if (EJResult.Contains("DISPENSED"))
                                {
                                    Dis = EJResult.Split(' ');
                                    DispenseCount = Dis[1] + "," + Dis[2] + "," + Dis[3] + "," + Dis[4];
                                    //DispenseCount = EJResult.Substring(EJResult.IndexOf(" ")).Trim();
                                }

                                if (EJResult.Contains("REMAINING"))
                                {
                                    Rem = EJResult.Split(' ');
                                    RemainCount = Rem[1] + "," + Rem[2] + "," + Rem[3] + "," + Rem[4];
                                }

                                if (EJResult.Contains("REJECTED"))
                                {
                                    Rem = EJResult.Split(' ');
                                    RejectCount = Rem[1] + "," + Rem[2] + "," + Rem[3] + "," + Rem[4];
                                }

                                if (EJResult.Contains("NOTES PRESENTED"))
                                {
                                    Note = EJResult.Split(' ');
                                    Notes = Note[4].Split(',');

                                    Cassette1 = Notes[0];
                                    Cassette2 = Notes[1];
                                    Cassette3 = Notes[2];
                                    Cassette4 = Notes[3];
                                }

                                //if (EJResult.Contains("TERM_MSG=SOL_DEVICE_FAULT"))
                                //{
                                //    string result2 = TotalCountArray[k].ToString().Substring(21, TotalCountArray[k].ToString().Length - 21);
                                //    string[] resultB = result2.Split(',');
                                //    TCode = resultB[2].ToString().Substring(6, resultB[2].ToString().Length - 6);

                                //}

                                //if (EJResult.Contains("TERM_MSG=UNSOL_STATUS_MESSAGE"))
                                //{
                                //    string result2 = TotalCountArray[k].ToString().Substring(21, TotalCountArray[k].ToString().Length - 21);
                                //    string[] resultB = result2.Split(',');
                                //    TCode1 = resultB[2].ToString().Substring(6, resultB[2].ToString().Length - 6);

                                //}
                                //if (EJResult.Contains("DEVICEERROR"))
                                //{
                                //    string result1 = TotalCountArray[k].ToString().Substring(21, TotalCountArray[k].ToString().Length - 21);
                                //    string[] resultA = result1.Split(',');

                                //    resultCode = resultA[2].ToString().Substring(8, resultA[2].ToString().Length - 8);
                                //    ErrorCode = resultA[3].ToString().Substring(11, resultA[3].ToString().Length - 11);

                                //    Remark3 = TotalCountArray[k].ToString().Substring(21, TotalCountArray[k].ToString().Length - 21) + "|" + TotalCountArray[k + 1].ToString().Substring(21, TotalCountArray[k + 1].ToString().Length - 21) + "|" + TotalCountArray[k + 2].ToString().Substring(21, TotalCountArray[k + 2].ToString().Length - 21);
                                //}
                                //Result code, Error code
                                j = EndIndex;
                            }
                            catch
                            {
                                j = EndIndex;
                            }
                        }
                    }

                    #region StanderedFields
                    SplitType = ",";
                    ModeID = 0;
                    ChannelID = 0;
                    ReversalFlag = false;
                    TxnsStatus = string.Empty;
                    DebitCreditType = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    CardType = string.Empty;
                    TxnsDateTimeMain = null;
                    TxnsPostDateTimeMain = null;



                    card = false;
                    Terminal = false;
                    Acquirer = false;
                    Rev1 = false;
                    Rev2 = false;
                    ATM = false;
                    CDM = false;
                    POS = false;
                    ECOM = false;
                    IMPS = false;
                    UPI = false;
                    MicroATM = false;
                    MobileRecharge = false;
                    BAL = false;
                    MS = false;
                    PC = false;
                    CB = false;
                    RCA1 = false;
                    RCA2 = false;
                    MC = false;
                    VC = false;
                    OC = false;
                    D = false;
                    C = false;

                    #region ValidateField

                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        TxnsDateTimeMain = Convert.ToDateTime(TxnsDate + " " + TxnsTime);
                        //TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + TxnsTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);
                    }

                    if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                    {

                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);

                    }


                    if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                    {
                        for (i = 0; i < TxnPostDateTime.Length; i++)
                        {
                            if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                            {
                                TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                            }
                            else
                            {
                                TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), CultureInfo.InvariantCulture);
                            }
                        }
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                            }
                        }
                    }


                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                            {
                                card = true;
                            }
                        }
                    }



                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                    }
                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                        for (i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                            }
                        }
                    }




                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == TxnsSubType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == TxnsSubType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == TxnsSubType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == TxnsSubType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType)
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == ChannelType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == ChannelType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == ChannelType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == ChannelType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType)
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }


                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                            }
                        }

                        for (i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode)
                            {
                                RCA2 = true;
                            }
                        }
                    }

                    //if (ResponseCode1Array[0].ToString() == "")
                    //    {
                    //    RCA1 = true;
                    //    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() == "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                            }
                        }
                    }

                    //if (Information.IsNumeric(CardNumber.Substring(0, 6)))
                    //{
                    //    if (CardNumber != "")
                    //    {
                    //        for (i = 0; i < dsCardNetwork.Tables[0].Rows.Count; i++)
                    //        {
                    //            string Range = dsCardNetwork.Tables[0].Rows[i]["FIXRange"].ToString();
                    //            if (CardNumber.Substring(0, 1) == Range || CardNumber.Substring(0, 2) == Range || CardNumber.Substring(0, 3) == Range || CardNumber.Substring(0, 4) == Range || CardNumber.Substring(0, 5) == Range || CardNumber.Substring(0, 6) == Range)
                    //            {
                    //                CardType = dsCardNetwork.Tables[0].Rows[i]["CardNetwork"].ToString();
                    //            }
                    //        }

                    //    }

                    

                    if (DebitCode[0].ToString() != "")
                    {
                        for (i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                            }
                        }
                    }


                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    if (AcquirerID == string.Empty || AcquirerID == "")
                    {
                        if (Terminal == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Terminal == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Terminal == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }
                    else
                    {
                        if (Acquirer == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Acquirer == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Acquirer == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }

                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (POS)
                    {
                        ChannelID = (int)TxnsChannelID.POS;
                        TxnsSubTypeMain = "Purchase";
                    }

                    if (ECOM)
                    {
                        ChannelID = (int)TxnsChannelID.E_COMMERCE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (IMPS)
                    {
                        ChannelID = (int)TxnsChannelID.IMPS;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (MicroATM)
                    {
                        ChannelID = (int)TxnsChannelID.MICRO_ATM;
                        TxnsSubTypeMain = "Withdrawal";
                    }

                    if (MobileRecharge)
                    {
                        ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (UPI)
                    {
                        ChannelID = (int)TxnsChannelID.UPI;
                        TxnsSubTypeMain = "Transfer";
                    }
                    if (RCA1 == true || RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }
                    else
                    {
                        TxnsStatus = "Unsucessfull";
                    }


                    //if (RCA1 == true  || RCA1 == true && RCA2 == false)
                    //    {
                    //    ResponseCode = "00";
                    //    TxnsStatus = "Sucessfull";
                    //    }
                    //else
                    //    {
                    //    ResponseCode = ResponseCode1;
                    //    TxnsStatus = "Unsucessfull";
                    //    }

                    if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }

                    if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }

                    if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }

                    if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }


                    if (BAL || MS || PC || CB)
                    {
                        TxnsType = "Non-Financial";
                    }
                    else
                    {
                        TxnsType = "Financial";
                    }
                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    #endregion InitilizedField


                    #endregion StanderedFields
                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }

                    if (CardNumber != "")
                    {
                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);

                    }

                    if (TxnsDateTimeMain != null && ReferenceNumber != "")
                    {
                        _DataTable.Rows.Add(ClientID
                                        , (int)TxnsChannelID.ATM
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , CardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , InterchangeAccountNo
                                        , ATMAccountNo
                                        , TxnsDateTimeMain
                                        , Convert.ToDecimal(TxnsAmount)
                                        , Convert.ToDecimal(Amount1)
                                        , Convert.ToDecimal(Amount2)
                                        , Convert.ToDecimal(Amount3)
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubTypeMain
                                        , TxnsEntryType
                                        , TxnsNumber
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , ReversalFlag
                                        , TxnsPostDateTimeMain
                                        , TxnsPostDateTimeMain
                                        , AuthCode
                                        , ProcessingCode
                                        , Convert.ToDecimal(FeeAmount)
                                        , CurrencyCode
                                        , Convert.ToDecimal(CustBalance)
                                        , Convert.ToDecimal(InterchangeBalance)
                                        , Convert.ToDecimal(ATMBalance)
                                        , BranchCode
                                        , TransSeqNo
                                        , Opcode
                                        , resultCode
                                        , ErrorCode
                                        , TCode
                                        , TCode1
                                        , FunctionId
                                        , Amount
                                        , Denomination
                                        , ReqCount
                                        , DispenseCount
                                        , RemainCount
                                        , PickupCount
                                        , RejectCount
                                        , Cassette1
                                        , Cassette2
                                        , Cassette3
                                        , Cassette4
                                        , ReserveField1
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , RevEntryLeg
                                        , 0
                                        , FileName
                                        , path
                                        , null
                                        , DateTime.Now
                                        , DateTime.Now
                                        , UserName
                                        , ""
                                        , ECardNumber
                                        );

                    }

                    TerminalID = string.Empty;
                    AcquirerID = string.Empty;
                    ReferenceNumber = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    InterchangeAccountNo = string.Empty;
                    ATMAccountNo = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsDate = string.Empty;
                    TxnsTime = string.Empty;
                    TxnsAmount = 0;
                    Amount1 = "0";
                    Amount2 = "0";
                    Amount3 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsNumber = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;
                    TxnsPostDateTime = string.Empty;
                    TxnsValueDateTime = string.Empty;
                    AuthCode = string.Empty;
                    ProcessingCode = string.Empty;
                    FeeAmount = "0";
                    CurrencyCode = string.Empty;
                    CustBalance = "0";
                    InterchangeBalance = "0";
                    ATMBalance = "0";
                    BranchCode = string.Empty;
                    Cassette1 = string.Empty;
                    Cassette2 = string.Empty;
                    Cassette3 = string.Empty;
                    Cassette4 = string.Empty;
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    ResponseCode = string.Empty;
                    EJResult = string.Empty;
                    StrDateTime = string.Empty;
                    StrTime = string.Empty;
                    ErrorCode = string.Empty;
                    terminal = string.Empty;
                    TransSeqNo = string.Empty;
                    Opcode = string.Empty;
                    FunctionId = string.Empty;
                    Denomination = string.Empty;
                    ReqCount = string.Empty;
                    DispenseCount = string.Empty;
                    PickupCount = string.Empty;
                    RemainCount = string.Empty;
                    RejectCount = string.Empty;
                    TCode = string.Empty;
                    TCode1 = string.Empty;
                    resultCode = string.Empty;
                    Remark3 = string.Empty;
                    ECardNumber = string.Empty;
                    CardType = string.Empty;
                    TxnsStatus = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    DebitCreditType = string.Empty;
                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }
            return _DataTable;
        }

        public DataTable ASP_SplitData1(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTimeConverter objDateTimeConverter = new DateTimeConverter();
            System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");



            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("CustAccountNo", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("RequestAmount", typeof(string));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("Amount2", typeof(decimal));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            _DataTable.Columns.Add("OPCode", typeof(string));
            _DataTable.Columns.Add("ErrorCode", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("NotesPresented1", typeof(string));
            _DataTable.Columns.Add("NotesPresented2", typeof(string));
            _DataTable.Columns.Add("NotesPresented3", typeof(string));
            _DataTable.Columns.Add("NotesPresented4", typeof(string));
            _DataTable.Columns.Add("Denomination1", typeof(string));
            _DataTable.Columns.Add("Denomination2", typeof(string));
            _DataTable.Columns.Add("Denomination3", typeof(string));
            _DataTable.Columns.Add("Denomination4", typeof(string));
            _DataTable.Columns.Add("Dispensed1", typeof(string));
            _DataTable.Columns.Add("Dispensed2", typeof(string));
            _DataTable.Columns.Add("Dispensed3", typeof(string));
            _DataTable.Columns.Add("Dispensed4", typeof(string));
            _DataTable.Columns.Add("Rejected1", typeof(string));
            _DataTable.Columns.Add("Rejected2", typeof(string));
            _DataTable.Columns.Add("Rejected3", typeof(string));
            _DataTable.Columns.Add("Rejected4", typeof(string));
            _DataTable.Columns.Add("Remaining1", typeof(string));
            _DataTable.Columns.Add("Remaining2", typeof(string));
            _DataTable.Columns.Add("Remaining3", typeof(string));
            _DataTable.Columns.Add("Remaining4", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("Status", typeof(int)); 
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;             

            DataSet ds = new DataSet();

            string LogType = fileImportRequest.ConfigData.Rows[0]["FileName"].ToString();
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = fileImportRequest.ConfigData.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());

            DtDetails DTdetails = new DtDetails();

            string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
            fileImportRequest.TotalCount = TotalCountArray.Length;


            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string PreviousReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string CustAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            decimal DepAmount = 0;
            decimal TxnsAmount = 0;
            decimal ReqAmount = 0;
            string Amount1 = "0";
            string Amount2 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;

            string CurrencyCode = "356";
            string CustBalance = "0";
            string RespLine = string.Empty;

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string line = string.Empty;
            string line1 = string.Empty;
            string ResponseCode = string.Empty;
            string EJResult = string.Empty;
            string ErrorCode = string.Empty;
            string Opcode = string.Empty;
            string ECardNumber = string.Empty;
            string Status = "0";

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            string tempCardNumber = string.Empty;
            string temp = string.Empty;
            string AuthCode = string.Empty;
            int ModeID = 0;
            string dummy = "XXXXXXXXXX";
            //int ChannelID;
            DateTime? TxnsDateTimeMain = null;

            DateTime? FileDate = null;
            try
            {
                FileDate = DateTime.ParseExact(fileImportRequest.FileName.Substring(fileImportRequest.FileName.IndexOf("_") + 1, 8).Trim(), "ddMMyyyy", CultureInfo.InvariantCulture);
            }
            catch
            {

            }


            try
            {
                TerminalID = fileImportRequest.FileName.Substring(0, fileImportRequest.FileName.IndexOf("_")).Trim();
            }
            catch
            {

            }

            bool card = false;
            bool Terminal = false;
            bool Acquirer = false;
            bool Rev1 = false;
            bool Rev2 = false;
            bool ATM = false;
            bool CDM = false;
            bool POS = false;
            bool ECOM = false;
            bool IMPS = false;
            bool UPI = false;
            bool MicroATM = false;
            bool MobileRecharge = false;
            bool BAL = false;
            bool MS = false;
            bool PC = false;
            bool CB = false;
            bool RCA1 = false;
            bool RCA2 = false;
            //bool MC = false;
            //bool VC = false;
            bool OC = false;
            bool D = false;
            bool C = false;
            int ATRRECEIVEDT = 0;

            string SplitType = ",";
            string[] TerminalCode = fileImportRequest.ConfigData.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BIN_No = fileImportRequest.ConfigData.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] AcquirerIDArray = fileImportRequest.ConfigData.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode1Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode2Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ReversalType = fileImportRequest.ConfigData.Rows[0]["ReversalType"].ToString();
            string[] ATMType = fileImportRequest.ConfigData.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CDMType = fileImportRequest.ConfigData.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] POSType = fileImportRequest.ConfigData.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ECOMType = fileImportRequest.ConfigData.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] IMPType = fileImportRequest.ConfigData.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] UPIType = fileImportRequest.ConfigData.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MicroATMType = fileImportRequest.ConfigData.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MobileRechargeType = fileImportRequest.ConfigData.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BalanceEnquiry = fileImportRequest.ConfigData.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MiniStatement = fileImportRequest.ConfigData.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] PinChange = fileImportRequest.ConfigData.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ChequeBookReq = fileImportRequest.ConfigData.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ResponseType = fileImportRequest.ConfigData.Rows[0]["ResponseType"].ToString();
            string[] ResponseCode1Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ResponseCode2Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] OfflineCode = fileImportRequest.ConfigData.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnPostDateTime = fileImportRequest.ConfigData.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] DebitCode = fileImportRequest.ConfigData.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CreditCode = fileImportRequest.ConfigData.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);



            string[] Notes = new string[4];
            string[] Denominations = new string[5];
            string[] Dispenseds = new string[5];
            string[] Rejecteds = new string[5];
            string[] Remainings = new string[5];
            string[] CASSTYPE = new string[5];

            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;

            string Denomination1 = string.Empty;
            string Denomination2 = string.Empty;
            string Denomination3 = string.Empty;
            string Denomination4 = string.Empty;

            string PRESENTED = string.Empty;

            bool CassetteFetch = false;

            int i = 0;

            string tempErrorCode = string.Empty;

            for (int j = 0; j <= fileImportRequest.TotalCount; j++)
            {
                try
                {
                    //StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID"); //DBA8
                    //EndIndex = Common.GetIndex(TotalCountArray, j + 1, "------------------------------------");

                    if (ATRRECEIVEDT > 1)
                    {
                        StartIndex = j - 1;
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "TRANSACTION START");
                        ATRRECEIVEDT = 0;
                    }
                    else
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j - 1, "TRANSACTION START");
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "TRANSACTION START");
                    }


                    if (StartIndex != -1 && EndIndex == -1)
                    {
                        EndIndex = TotalCountArray.Length - 1;
                    }

                    ReqAmount = 0;
                    //TerminalID = string.Empty;
                    AcquirerID = string.Empty;
                    ReferenceNumber = string.Empty;
                    AuthCode = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsDate = string.Empty;
                    TxnsTime = string.Empty;
                    TxnsAmount = 0;
                    Amount1 = "0";
                    Amount2 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;

                    CustBalance = "0";
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    Status = "0";

                    ResponseCode = string.Empty;
                    EJResult = string.Empty;
                    ErrorCode = string.Empty;
                    Opcode = string.Empty;
                    ECardNumber = string.Empty;
                    CardType = string.Empty;
                    TxnsStatus = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    DebitCreditType = string.Empty;


                    Denomination1 = string.Empty;
                    Denomination2 = string.Empty;
                    Denomination3 = string.Empty;
                    Denomination4 = string.Empty;
                    PRESENTED = string.Empty;

                    RespLine = string.Empty;
                    tempCardNumber = string.Empty;


                    Array.Clear(Notes, 0, Notes.Length);
                    Array.Clear(Dispenseds, 0, Dispenseds.Length);
                    Array.Clear(Denominations, 0, Denominations.Length);
                    Array.Clear(Rejecteds, 0, Rejecteds.Length);
                    Array.Clear(Remainings, 0, Remainings.Length);
                    Array.Clear(CASSTYPE, 0, CASSTYPE.Length);

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex + 1; k <= EndIndex - 1; k++)
                        {

                            try
                            {

                                LineNo++;

                                if (TotalCountArray.Length <= k)
                                {
                                    break;
                                }

                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = Common.RemoveAdditionalChars(line);
                                ReserveField5 = ReserveField5 + " \n " + EJResult.Trim();


                                if (EJResult.Contains("ATM ID"))
                                {
                                    TerminalID = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("REF NO") || EJResult.Contains("RRN NO.") || EJResult.Contains("REF NO   :"))
                                {
                                    ReferenceNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("DATE"))  // || TotalCountArray[k - 1].ToString().Contains("/")
                                {
                                    TxnsDate = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("TIME :"))
                                {
                                    TxnsTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("CARD NO") && EJResult.IndexOf(":") > 0)
                                {
                                    CardNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("A/C NO") || EJResult.Contains("ACCOUNT NO") || EJResult.Contains("ACCT NO"))
                                {
                                    CustAccountNo = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("CARD:"))
                                {
                                    CardNumber = EJResult.Substring(EJResult.IndexOf("CARD:") + 5).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("TRANSTYPE"))
                                {
                                    temp= EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsSubType = temp == "0" ? TxnsSubType : temp;
                                }
                                else if (EJResult.Contains("TOTAL :") && TxnsSubType == "CASHDEPOSIT")
                                {
                                    DepAmount = Convert.ToDecimal(EJResult.Substring(EJResult.IndexOf(":") + 1).Trim());
                                }
                                else if (EJResult.Contains("RESP CODE"))
                                {
                                    ResponseCode = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("TRANS AMOUNT") || (EJResult.Contains("WDL AMT")))
                                {
                                    TxnsAmount = Convert.ToDecimal(EJResult.Substring(EJResult.IndexOf(":") + 1).Replace("RS.", "").Trim());
                                }
                                else if (EJResult.Contains("AMOUNT ["))
                                {
                                    ReqAmount = Convert.ToDecimal(EJResult.Substring(EJResult.IndexOf("[") + 1).Trim().Replace("]", ""));
                                }
                                else if (EJResult.Contains("AMOUNT_ENTERED"))
                                {
                                    TxnsSubType = "WITHDRAWAL";
                                }
                                else if (EJResult.ToUpper().Contains("AMOUNT") && EJResult.Contains("ENTERED"))
                                {
                                    ReqAmount = Convert.ToDecimal(ExtractNumber(EJResult.Substring(EJResult.IndexOf("AMOUNT") + 6).Trim()));
                                }
                                else if (EJResult.ToUpper().Contains("AMOUNT=") && ReqAmount == 0)
                                {
                                    ReqAmount = Convert.ToDecimal(EJResult.Substring(EJResult.IndexOf("AMOUNT=") + 7).Trim());
                                }
                                else if (EJResult.Contains("BALANCE"))
                                {
                                    CustBalance = Convert.ToDecimal(Regex.Match(EJResult.Substring(EJResult.IndexOf(":") + 1).Trim(), @"\d+(?:\.\d+)").Value).ToString();
                                }
                                else if (EJResult.ToUpper().Contains("TXN SN NO="))
                                {
                                    AuthCode = EJResult.Substring(EJResult.IndexOf("TXN SN NO=") + "TXN SN NO=".Length).Trim();
                                    AuthCode = AuthCode.Replace("]", "");
                                }
                                else if (EJResult.ToUpper().Contains("TXN NO"))
                                {
                                    AuthCode = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("OPCODE"))
                                {
                                    Opcode = EJResult.Substring(EJResult.IndexOf("=") + 1).Trim();
                                }
                                else if (EJResult.Contains("TRANSTYPE"))
                                {
                                    TxnsSubType = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("PRINT RECEIPT - SUCCESS") && ReserveField4.Contains("APPROVED"))
                                {
                                    TxnsSubType = "MINISTATEMENT";
                                }
                                else if (EJResult.Contains("ATR RECEIVED T=0"))
                                {
                                    ATRRECEIVEDT++;
                                    if (ATRRECEIVEDT > 1)
                                    {
                                        break;
                                    }
                                }
                                else if (EJResult.Contains("STACKED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES STACKED";
                                }
                                else if (EJResult.Contains("CASH TAKEN"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " CASH TAKEN";
                                    TxnsStatus = "Sucessfull";
                                }
                                else if (EJResult.Contains("NOTES PRESENTED"))
                                {
                                    Notes = EJResult.Substring(EJResult.IndexOf("PRESENTED") + 10).Trim().Split(',');
                                    TxnsPerticulars = TxnsPerticulars + " NOTES PRESENTED";
                                }
                                else if (EJResult.Contains("PRESENTED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES PRESENTED";
                                    PRESENTED = EJResult.Substring(EJResult.IndexOf("PRESENTED :") + 11).Trim();
                                }
                                else if (EJResult.Contains("NOTES TAKEN") && TxnsSubType== "WITHDRAWAL")
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES TAKEN";
                                    TxnsStatus = "Sucessfull";
                                    ResponseCode = "00";
                                }
                                else if (EJResult.Contains("NOTES DEPOSITED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES DEPOSITED";
                                }
                                else if (EJResult.Contains("MINISTMT"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "MINI-STATEMENT";
                                }
                                else if (EJResult.Contains("DECLINED OFFLINE-AAC"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "DECLINED OFFLINE-AAC";
                                }
                                else if (EJResult.Contains("DISPENSER FAILURE"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "DISPENSER FAILURE";
                                }
                                else if (EJResult.Contains("SPECIAL PICKUPRS"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "SPECIAL PICKUPRS";
                                }
                                else if (EJResult.Contains("POWER"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + "POWER CYCLE";
                                }
                                else if (EJResult.Contains("CARD NOT EXIST"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " CARD NOT EXIST";
                                }
                                else if (EJResult.Contains("DENOMINATION"))
                                {
                                    Denominations = EJResult.Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("DENOMINATION"))
                                {
                                    Denominations = EJResult.Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("DENOM"))
                                {
                                    Denominations = EJResult.Replace(": ", "").Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("CASS.TYPE"))
                                {
                                    CASSTYPE = EJResult.Replace(": ", "").Split(' ');

                                    if (CASSTYPE.Length == 5 && Denominations.Length == 5)
                                    {
                                        for (int x = 1; x < CASSTYPE.Length; x++)
                                        {
                                            if (Convert.ToInt32(CASSTYPE[x]) == 0)
                                            {
                                                Notes[x - 1] = "0";
                                            }
                                            else if (Convert.ToInt32(CASSTYPE[x]) > 0)
                                            {
                                                if (PRESENTED.Length > 0 && PRESENTED.Contains(";"))
                                                {
                                                    string[] PR = PRESENTED.Split(";");
                                                    foreach (string Deno in PR)
                                                    {
                                                        if (Deno.Length > 0 && Deno.Substring(Deno.IndexOf(":") - 1, 1).Trim() == CASSTYPE[x].Trim())
                                                        {
                                                            Notes[x - 1] = Deno.Substring(EJResult.IndexOf(",") + 1, 1).Trim();
                                                        }
                                                        else
                                                        {
                                                            Notes[x - 1] = "0";
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    Notes[x - 1] = "0";
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (EJResult.Contains("DISPENSED"))
                                {
                                    Dispenseds = EJResult.Replace(": ", "").Split(' ');

                                    if (Dispenseds.Length != 5)
                                    {
                                        Dispenseds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REMAINING"))
                                {
                                    Remainings = EJResult.Replace(": ", "").Split(' ');

                                    if (Remainings.Length != 5)
                                    {
                                        Remainings = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REJECTED"))
                                {
                                    Rejecteds = EJResult.Replace(": ", "").Split(' ');

                                    if (Rejecteds.Length != 5)
                                    {
                                        Rejecteds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("+PURGE"))
                                {
                                    Rejecteds = EJResult.Replace(": ", "").Split(' ');

                                    if (Rejecteds.Length != 5)
                                    {
                                        Rejecteds = new string[5];
                                    }
                                }

                                else if (EJResult.Contains("USER"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("NO FUNDS AVAILABLE"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ERROR"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("UNABLE TO PROCESS"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("POWER-UP/RESET"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("LIMIT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ENTER LESSER AMOUNT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ENTER AMOUNT MULTIPLE OF"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("INCORRECT PIN"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("SECURITY KEY VOILATION"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("PIN RETRIES EXCEEDED"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("INVALID TRANSACTION"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("DO NOT HONOUR"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("NO FROM ACCOUNT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("(1*"))
                                {
                                    if (ErrorCode.IndexOf(EJResult) == -1)
                                    {
                                        ErrorCode = ErrorCode + " " + EJResult;
                                    }
                                }
                                else if ((EJResult.Contains("M-")) && (EJResult.Contains("*" + ReferenceNumber + "*")))
                                {
                                    if (ErrorCode.IndexOf(EJResult) == -1)
                                    {
                                        ErrorCode = ErrorCode + " " + EJResult;
                                    }
                                }
                                else if ((EJResult.Contains(",M-")))
                                {
                                    string Remark3 = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("HOST TX TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + "HOST TX TIMEOUT";
                                }
                                else if (EJResult.Contains("SWITCH RESP. TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + "SWITCH RESP. TIMEOUT";
                                }
                                else if (EJResult.Contains("DISPENSER FAILURE"))
                                {
                                    ErrorCode = ErrorCode + " " + "DISPENSER FAILURE";
                                }
                                else if (EJResult.Contains("DECLINED OFFLINE"))
                                {
                                    ErrorCode = ErrorCode + " " + "DECLINED OFFLINE";
                                }
                                else if (EJResult.Contains("COMMAND REJECT"))
                                {
                                    ErrorCode = ErrorCode + " " + "COMMAND REJECT";
                                }
                                else if (EJResult.Contains("ISSUER TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + "ISSUER TIMEOUT";
                                }
                                else if (EJResult.Contains("UNCERTAIN DISPENSE"))
                                {
                                    ErrorCode = ErrorCode + " " + "UNCERTAIN DISPENSE";
                                }
                                else if (EJResult.Contains("POWER CYCLE"))
                                {
                                    ErrorCode = ErrorCode + " " + "POWER CYCLE HAPPENED DURING WITHDRAWAL TRANSACTION (CASH TAKEN)";
                                }
                                else if (EJResult.Contains("ERROR"))
                                {
                                    ErrorCode = ErrorCode + " " + "DISPENSE ERROR";
                                }
                                else if (EJResult.Contains("INVALID ISSUERRS"))
                                {
                                    ErrorCode = ErrorCode + " " + "INVALID ISSUERRS";
                                }
                                else if (EJResult.Contains("UNABLE"))
                                {
                                    ErrorCode = ErrorCode + " " + "UNABLE TO PROCESS";
                                }
                                else if (EJResult.Contains("SUPERVISOR MODE ENTRY"))
                                {
                                    k = EndIndex;
                                }


                                j = EndIndex;
                            }
                            catch (Exception exx)
                            {
                                j = EndIndex;
                            }
                        }
                    }
                    #region StanderedFields

                    ReversalFlag = false;
                    TxnsStatus = string.Empty;
                    DebitCreditType = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    CardType = string.Empty;

                    TxnsDateTimeMain = null;

                    card = false;
                    Terminal = false;
                    Acquirer = false;
                    Rev1 = false;
                    Rev2 = false;
                    ATM = false;
                    CDM = false;
                    POS = false;
                    ECOM = false;
                    IMPS = false;
                    UPI = false;
                    MicroATM = false;
                    MobileRecharge = false;
                    BAL = false;
                    MS = false;
                    PC = false;
                    CB = false;
                    RCA1 = false;
                    RCA2 = false;
                    //MC = false;
                    //VC = false;
                    OC = false;
                    D = false;
                    C = false;

                    if (CardNumber != "")
                    {
                        CardType = Common.GetCardType(CardNumber);
                    }
                    
                        

                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        try
                        {
                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + " " + TxnsTime, TxnDateTime, CultureInfo.InvariantCulture, DateTimeStyles.None);
                        }
                        catch
                        {

                        }

                    }

                    if (TerminalID.Length > 0 && !CassetteFetch)
                    {
                        DataTable dataTable = Common.GetCassetteInfoByTerminalId(_connectionString, fileImportRequest.ClientCode, TerminalID);

                        if (dataTable != null && dataTable.Rows.Count > 0)
                        {
                            Cassette1 = Convert.ToString(dataTable.Rows[0]["Cassette1"]);
                            Cassette2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                            Cassette3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                            Cassette4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);

                        }

                        dataTable = null;
                        CassetteFetch = true;
                    }


                    if (FileDate == null)
                    {
                        FileDate = TxnsDateTimeMain;
                    }

                    if (CassetteFetch)
                    {
                        //if (Notes != null && Notes.Length == 4)
                        //{
                        //    Denomination1 = Cassette1.Length == 0 ? Notes[0] : Convert.ToString(Convert.ToDecimal(Cassette1) * Convert.ToDecimal(Notes[0]));
                        //    Denomination2 = Cassette2.Length == 0 ? Notes[1] : Convert.ToString(Convert.ToDecimal(Cassette2) * Convert.ToDecimal(Notes[1]));
                        //    Denomination3 = Cassette3.Length == 0 ? Notes[2] : Convert.ToString(Convert.ToDecimal(Cassette3) * Convert.ToDecimal(Notes[2]));
                        //    Denomination4 = Cassette4.Length == 0 ? Notes[3] : Convert.ToString(Convert.ToDecimal(Cassette4) * Convert.ToDecimal(Notes[3]));
                        //}
                        //else
                        //{
                        //    Denomination1 = Notes[0];
                        //    Denomination2 = Notes[1];
                        //    Denomination3 = Notes[2];
                        //    Denomination4 = Notes[3];
                        //}

                        Denomination1 = Cassette1.Length == 0 ? "0" : Cassette1;
                        Denomination2 = Cassette2.Length == 0 ? "0" : Cassette2;
                        Denomination3 = Cassette3.Length == 0 ? "0" : Cassette3;
                        Denomination4 = Cassette4.Length == 0 ? "0" : Cassette4;
                    }
                    else
                    {
                        Denomination1 = "0";
                        Denomination2 = "0";
                        Denomination3 = "0";
                        Denomination4 = "0";
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                                break;
                            }
                        }
                    }


                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                                break;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i] == CardNumber.Substring(0, 6))
                            {
                                card = true;
                                break;
                            }
                            else if (BIN_No[i].Substring(0, 4) == CardNumber.Substring(0, 4))
                            {
                                card = true;
                                break;
                            }
                        }
                    }



                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                                break;
                            }
                        }
                    }
                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                                break;
                            }
                        }
                        for (i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                                break;
                            }
                        }
                    }




                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                    break;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                    break;
                                }
                            }
                        }

                        //if (POSType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < POSType.Length; i++)
                        //    {
                        //        if (POSType[i].ToString() == TxnsSubType)
                        //        {
                        //            POS = true;
                        //        }
                        //    }
                        //}
                        //if (ECOMType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < ECOMType.Length; i++)
                        //    {
                        //        if (ECOMType[i].ToString() == TxnsSubType)
                        //        {
                        //            ECOM = true;
                        //        }
                        //    }
                        //}

                        //if (IMPType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < IMPType.Length; i++)
                        //    {
                        //        if (IMPType[i].ToString() == TxnsSubType)
                        //        {
                        //            IMPS = true;
                        //        }
                        //    }
                        //}

                        //if (UPIType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < UPIType.Length; i++)
                        //    {
                        //        if (UPIType[i].ToString() == TxnsSubType)
                        //        {
                        //            UPI = true;
                        //        }
                        //    }
                        //}

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType)
                                {
                                    MicroATM = true;
                                    break;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                    break;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType)
                                {
                                    ATM = true;
                                    break;
                                }
                            }
                        }

                        //if (POSType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < POSType.Length; i++)
                        //    {
                        //        if (POSType[i].ToString() == ChannelType)
                        //        {
                        //            POS = true;
                        //        }
                        //    }
                        //}
                        //if (ECOMType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < ECOMType.Length; i++)
                        //    {
                        //        if (ECOMType[i].ToString() == ChannelType)
                        //        {
                        //            ECOM = true;
                        //        }
                        //    }
                        //}

                        //if (IMPType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < IMPType.Length; i++)
                        //    {
                        //        if (IMPType[i].ToString() == ChannelType)
                        //        {
                        //            IMPS = true;
                        //        }
                        //    }
                        //}

                        //if (UPIType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < UPIType.Length; i++)
                        //    {
                        //        if (UPIType[i].ToString() == ChannelType)
                        //        {
                        //            UPI = true;
                        //        }
                        //    }
                        //}

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType)
                                {
                                    MicroATM = true;
                                    break;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                    break;
                                }
                            }
                        }
                    }


                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                                break;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                                break;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                                break;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                                break;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                                break;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                                break;
                            }
                        }

                        for (i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode)
                            {
                                RCA2 = true;
                                break;
                            }
                        }
                    }


                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() == "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                                break;
                            }
                        }
                    }



                    if (DebitCode[0].ToString() != "")
                    {
                        for (i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                                break;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                                break;
                            }
                        }
                    }


                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    if (AcquirerID == string.Empty || AcquirerID == "")
                    {
                        if (Terminal == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        else if (Terminal == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        else if (Terminal == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }
                    else
                    {
                        if (Acquirer == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        else if (Acquirer == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        else if (Acquirer == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }

                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    if (RCA1 == true || RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }
                    else
                    {
                        TxnsStatus = "Unsucessfull";
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    else if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                    }
                    else if (POS)
                    {
                        TxnsSubTypeMain = "Purchase";
                    }
                    else if (ECOM)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (IMPS)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (MicroATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    else if (MobileRecharge)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (UPI)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }
                    else if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }
                    else if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }
                    else if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }


                  
                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    if (TxnsSubType == "GREEN PIN")
                    {
                        TxnsType = "Non-Financial";
                        TxnsSubTypeMain = "Green Pin";
                    }

                    if (TxnsSubType.Length == 0 && TxnsSubTypeMain.Length == 0 && ReqAmount > 0)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }

                    #endregion InitilizedField

                    //if (ReferenceNumber.Length == 0)
                    //{
                    //    if (AuthCode.Length == 6)
                    //    {
                    //        ReferenceNumber = AuthCode.Substring(2);
                    //    }
                    //}

                    //#endregion StanderedFields

                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }

                    if (CardNumber != "")
                    {
                        CardNumber = CardNumber.Replace("*", "X");

                        tempCardNumber = CardNumber;

                        CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);

                        ReserveField5 = ReserveField5.Replace(tempCardNumber, CardNumber);
                    }

                    if (ReserveField5.Length >= 3900)
                    {
                        ReserveField5 = ReserveField5.Substring(0, 3900);
                    }

                    if (ErrorCode.Length >= 1590)
                    {
                        ErrorCode = ErrorCode.Substring(0, 1590);
                    }

                    if (TxnsSubType == "CASHDEPOSIT")
                    {
                        TxnsAmount = DepAmount;
                    }

                    if (ReqAmount > 0 || TxnsAmount >0)
                    {
                        TxnsType = "Financial";
                    }
                    else
                    {
                        TxnsType = "Non-Financial";
                    }

                    if (TxnsType == "Financial" && TxnsStatus == "Sucessfull")
                    {
                        Status = "1";
                        if (ReqAmount > 0 && TxnsAmount == 0)
                        {
                            TxnsAmount = ReqAmount;
                        }
                    }
                    else if (TxnsType == "Financial" && TxnsStatus == "Unsucessfull")
                    {
                        Status = "2";
                        if (ReqAmount > 0 && TxnsAmount == 0)
                        {
                            TxnsAmount = ReqAmount;
                        }
                    }
                    else if (TxnsStatus == "Unsucessfull" && TxnsType == "Non-Financial" && TxnsSubTypeMain== "Withdrawal")
                    {
                        TxnsType = "Financial";
                        //TxnsAmount = -1;
                        Status = "2";
                    }


                    CustBalance = CustBalance == "" ? "0" : CustBalance;
                    Amount1 = Amount1 == "" ? "0" : Amount1;
                    Amount2 = Amount2 == "" ? "0" : Amount2;

                    ReserveField5 = ReserveField5.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");

                    //if (ReferenceNumber.Length > 0)
                    //{
                    //    PreviousReferenceNumber = ReferenceNumber;
                    //}
                    //else if (ReferenceNumber.Length == 0 && PreviousReferenceNumber.Length > 0 && tempErrorCode.Contains("HOST TX TIMEOUT"))
                    //{
                    //    ReferenceNumber = Convert.ToString(Convert.ToInt32(PreviousReferenceNumber) );
                    //    PreviousReferenceNumber = ReferenceNumber;
                    //}
                    //else if (ReferenceNumber.Length == 0 && PreviousReferenceNumber.Length > 0 )
                    //{
                    //    ReferenceNumber = Convert.ToString(Convert.ToInt32(PreviousReferenceNumber) + 1);
                    //    PreviousReferenceNumber = ReferenceNumber;
                    //}

                    tempErrorCode = ErrorCode;

                    if (TxnsDateTimeMain != null && ReferenceNumber != "")
                    {
                        _DataTable.Rows.Add(
                                        ClientID
                                        , (int)TxnsChannelID.ATM
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , CardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , Convert.ToDecimal(CustBalance)
                                        , TxnsDateTimeMain
                                        , TxnsAmount
                                        , ReqAmount
                                        , Convert.ToDecimal(Amount1)
                                        , Convert.ToDecimal(Amount2)
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubTypeMain
                                        , TxnsEntryType
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , AuthCode
                                        , CurrencyCode
                                        , Opcode
                                        , ErrorCode
                                        , ReversalFlag
                                        , Notes[0]
                                        , Notes[1]
                                        , Notes[2]
                                        , Notes[3]
                                        , Denomination1
                                        , Denomination2
                                        , Denomination3
                                        , Denomination4
                                        , Dispenseds[1]
                                        , Dispenseds[2]
                                        , Dispenseds[3]
                                        , Dispenseds[4]
                                        , Rejecteds[1]
                                        , Rejecteds[2]
                                        , Rejecteds[3]
                                        , Rejecteds[4]
                                        , Remainings[1]
                                        , Remainings[2]
                                        , Remainings[3]
                                        , Remainings[4]
                                        , ReserveField1
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , Status 
                                        , ECardNumber.Trim()
                                        );

                    }

                    if (ATRRECEIVEDT <= 1)
                    {
                        ATRRECEIVEDT = 0;
                    }
                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                fileImportRequest.InsertCount = _DataTable.Rows.Count;
            }
            return _DataTable;
        }

        public DataTable ASP_SplitData2(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTimeConverter objDateTimeConverter = new DateTimeConverter();
            System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");



            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("CustAccountNo", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("RequestAmount", typeof(string));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("Amount2", typeof(decimal));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            _DataTable.Columns.Add("OPCode", typeof(string));
            _DataTable.Columns.Add("ErrorCode", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("NotesPresented1", typeof(string));
            _DataTable.Columns.Add("NotesPresented2", typeof(string));
            _DataTable.Columns.Add("NotesPresented3", typeof(string));
            _DataTable.Columns.Add("NotesPresented4", typeof(string));
            _DataTable.Columns.Add("Denomination1", typeof(string));
            _DataTable.Columns.Add("Denomination2", typeof(string));
            _DataTable.Columns.Add("Denomination3", typeof(string));
            _DataTable.Columns.Add("Denomination4", typeof(string));
            _DataTable.Columns.Add("Dispensed1", typeof(string));
            _DataTable.Columns.Add("Dispensed2", typeof(string));
            _DataTable.Columns.Add("Dispensed3", typeof(string));
            _DataTable.Columns.Add("Dispensed4", typeof(string));
            _DataTable.Columns.Add("Rejected1", typeof(string));
            _DataTable.Columns.Add("Rejected2", typeof(string));
            _DataTable.Columns.Add("Rejected3", typeof(string));
            _DataTable.Columns.Add("Rejected4", typeof(string));
            _DataTable.Columns.Add("Remaining1", typeof(string));
            _DataTable.Columns.Add("Remaining2", typeof(string));
            _DataTable.Columns.Add("Remaining3", typeof(string));
            _DataTable.Columns.Add("Remaining4", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("Status", typeof(int));
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;

            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;


            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string CustAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            decimal TxnsAmount = 0;
            decimal ReqAmount = 0;
            string Amount1 = "0";
            string Amount2 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;

            string CurrencyCode = "356";
            string CustBalance = "0";

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string line = string.Empty;
            string line1 = string.Empty;
            string ResponseCode = string.Empty;
            string EJResult = string.Empty;
            string ErrorCode = string.Empty;
            string Opcode = string.Empty;
            string ECardNumber = string.Empty;
            string Status = "0";

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            string tempCardNumber = string.Empty;
            int ModeID = 0;
            //int ChannelID;
            DateTime? TxnsDateTimeMain = null;

            DateTime? FileDate = null;
            try
            {
                FileDate = DateTime.ParseExact(FileName.Substring(FileName.IndexOf("_") + 1, 8).Trim(), "yyyyMMdd", CultureInfo.InvariantCulture);
            }
            catch
            {

            }

            bool card = false;
            bool Terminal = false;
            bool Acquirer = false;
            bool Rev1 = false;
            bool Rev2 = false;
            bool ATM = false;
            bool CDM = false;
            bool POS = false;
            bool ECOM = false;
            bool IMPS = false;
            bool UPI = false;
            bool MicroATM = false;
            bool MobileRecharge = false;
            bool BAL = false;
            bool MS = false;
            bool PC = false;
            bool CB = false;
            bool RCA1 = false;
            bool RCA2 = false;
            //bool MC = false;
            //bool VC = false;
            bool OC = false;
            bool D = false;
            bool C = false;

            string SplitType = ",";
            string[] TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] AcquirerIDArray = dt.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode1Array = dt.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode2Array = dt.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ReversalType = dt.Rows[0]["ReversalType"].ToString();
            string[] ATMType = dt.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CDMType = dt.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] POSType = dt.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ECOMType = dt.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] IMPType = dt.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] UPIType = dt.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MicroATMType = dt.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MobileRechargeType = dt.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BalanceEnquiry = dt.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MiniStatement = dt.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] PinChange = dt.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ChequeBookReq = dt.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ResponseType = dt.Rows[0]["ResponseType"].ToString();
            string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ResponseCode2Array = dt.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] OfflineCode = dt.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnDateTime = dt.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnPostDateTime = dt.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] DebitCode = dt.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CreditCode = dt.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);



            string[] Notes = new string[4];
            string[] Denominations = new string[5];
            string[] Dispenseds = new string[5];
            string[] Rejecteds = new string[5];
            string[] Remainings = new string[5];

            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;

            string Denomination1 = string.Empty;
            string Denomination2 = string.Empty;
            string Denomination3 = string.Empty;
            string Denomination4 = string.Empty;

            bool CassetteFetch = false;

            int i = 0;

            for (int j = 0; j <= TotalCount; j++)
            {
                try
                {
                    //StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID"); //DBA8
                    //EndIndex = Common.GetIndex(TotalCountArray, j + 1, "------------------------------------");

                    StartIndex = Common.GetIndex(TotalCountArray, j, "TRANSACTION START");
                    EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "TRANSACTION END");

                    ReqAmount = 0;
                    //TerminalID = string.Empty;
                    AcquirerID = string.Empty;
                    ReferenceNumber = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsDate = string.Empty;
                    TxnsTime = string.Empty;
                    TxnsAmount = 0;
                    Amount1 = "0";
                    Amount2 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;

                    CustBalance = "0";
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    Status = "0";

                    ResponseCode = string.Empty;
                    EJResult = string.Empty;
                    ErrorCode = string.Empty;
                    Opcode = string.Empty;
                    ECardNumber = string.Empty;
                    CardType = string.Empty;
                    TxnsStatus = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    DebitCreditType = string.Empty;


                    Denomination1 = string.Empty;
                    Denomination2 = string.Empty;
                    Denomination3 = string.Empty;
                    Denomination4 = string.Empty;

                    Array.Clear(Notes, 0, Notes.Length);
                    Array.Clear(Dispenseds, 0, Dispenseds.Length);
                    Array.Clear(Denominations, 0, Denominations.Length);
                    Array.Clear(Rejecteds, 0, Rejecteds.Length);
                    Array.Clear(Remainings, 0, Remainings.Length);

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex + 1; k <= EndIndex - 1; k++)
                        {

                            try
                            {

                                LineNo++;

                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = Common.RemoveAdditionalChars(line);
                                ReserveField5 = ReserveField5 + " \n " + EJResult.Trim();

                                if (EJResult.Contains("ATM ID") && TerminalID.Length == 0)
                                {
                                    TerminalID = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("CARD:") && CardNumber.Length == 0)
                                {
                                    CardNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("CARD NO :") && CardNumber.Length == 0)
                                {
                                    CardNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.ToUpper().Contains("AMOUNT") && EJResult.Contains("ENTERED"))
                                {
                                    ReqAmount = Convert.ToDecimal(Regex.Match(EJResult.Substring(EJResult.IndexOf("AMOUNT") + 6).Trim(), @"\d+").Value);
                                }
                                else if (EJResult.Contains("OPCODE"))
                                {
                                    Opcode = EJResult.Substring(EJResult.IndexOf("=") + 1).Trim();
                                }
                                else if (EJResult.Contains("DATE") && EJResult.Contains("TIME"))
                                {
                                    TxnsDate = EJResult.Substring(4, EJResult.IndexOf("TIME") - 4).Trim();
                                    TxnsTime = EJResult.Substring(EJResult.IndexOf("TIME") + 4).Trim();
                                }
                                else if (EJResult.Contains("DATE"))
                                {
                                    TxnsDate = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("TIME"))
                                {
                                    TxnsTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("REF NO"))
                                {
                                    ReferenceNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("A/C NO"))
                                {
                                    CustAccountNo = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("TRANSTYPE"))
                                {
                                    TxnsSubType = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("RESP CODE"))
                                {
                                    ResponseCode = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                else if (EJResult.Contains("WDL AMT"))
                                {
                                    TxnsAmount = Convert.ToDecimal(EJResult.Substring(EJResult.IndexOf(":") + 1).Trim());
                                }
                                else if (EJResult.Contains("BALANCE"))
                                {
                                    CustBalance = Convert.ToDecimal(Regex.Match(EJResult.Substring(EJResult.IndexOf(":") + 1).Trim(), @"\d+(?:\.\d+)").Value).ToString();

                                }
                                else if (EJResult.Contains("NOTES STACKED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES STACKED";
                                }
                                else if (EJResult.Contains("NOTES PRESENTED"))
                                {
                                    Notes = EJResult.Substring(EJResult.IndexOf("PRESENTED") + 10).Trim().Split(',');
                                    TxnsPerticulars = TxnsPerticulars + " NOTES PRESENTED";
                                }
                                else if (EJResult.Contains("NOTES TAKEN"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES TAKEN";
                                    TxnsStatus = "Sucessfull";
                                }
                                else if (EJResult.Contains("NOTES DEPOSITED"))
                                {
                                    TxnsPerticulars = TxnsPerticulars + " NOTES DEPOSITED";

                                    TxnsAmount = TotalCountArray[k + 6].Contains("TOTAL") ? Common.ExtractDecimal(TotalCountArray[k + 6]) : 0;
                                }
                                else if (EJResult.Contains("DENOMINATION"))
                                {
                                    Denominations = EJResult.Split(' ');
                                    if (Denominations.Length != 5)
                                    {
                                        Denominations = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("DISPENSED"))
                                {
                                    if (EJResult.Contains("DISPENSED NOTES :PRESENT"))
                                    {
                                        Notes = new string[4];
                                        Notes[0] = TotalCountArray[k + 1].Substring(TotalCountArray[k + 1].IndexOf("=") + 1).Trim();
                                        Notes[1] = TotalCountArray[k + 2].Substring(TotalCountArray[k + 2].IndexOf("=") + 1).Trim();
                                        Notes[2] = TotalCountArray[k + 3].Substring(TotalCountArray[k + 3].IndexOf("=") + 1).Trim();
                                        Notes[3] = TotalCountArray[k + 4].Substring(TotalCountArray[k + 4].IndexOf("=") + 1).Trim();
                                    }

                                    Dispenseds = EJResult.Split(' ');

                                    if (Dispenseds.Length != 5)
                                    {
                                        Dispenseds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REMAINING"))
                                {
                                    Remainings = EJResult.Split(' ');

                                    if (Remainings.Length != 5)
                                    {
                                        Remainings = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REJECTED"))
                                {
                                    Rejecteds = EJResult.Split(' ');

                                    if (Rejecteds.Length != 5)
                                    {
                                        Rejecteds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REJECT COUNT"))
                                {
                                    Rejecteds = EJResult.Replace("[", ",").Replace("]", "").Split(',');

                                    if (Rejecteds.Length != 5)
                                    {
                                        Rejecteds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("REMAIN COUNT"))
                                {
                                    Remainings = EJResult.Replace("[", ",").Replace("]", "").Split(',');

                                    if (Remainings.Length != 5)
                                    {
                                        Remainings = new string[5];
                                    }
                                }
                                //else if (EJResult.Contains("PICKUP COUNT"))
                                //{
                                //    Notes = EJResult.Replace("PICKUP COUNT [", "").Replace("]", "").Split(',');

                                //    if (Notes.Length != 4)
                                //    {
                                //        Notes = new string[4];
                                //    }
                                //}
                                else if (EJResult.Contains("DISPENSE COUNT"))
                                {
                                    Dispenseds = EJResult.Replace("[", ",").Replace("]", "").Split(',');

                                    if (Dispenseds.Length != 5)
                                    {
                                        Dispenseds = new string[5];
                                    }
                                }
                                else if (EJResult.Contains("NO FUNDS AVAILABLE"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ERROR"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("UNABLE TO PROCESS"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("TIMEOUT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("POWER-UP/RESET"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("LIMIT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ENTER LESSER AMOUNT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("ENTER AMOUNT MULTIPLE OF"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("INCORRECT PIN"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("SECURITY KEY VOILATION"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("PIN RETRIES EXCEEDED"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("INVALID TRANSACTION"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("DO NOT HONOUR"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("NO FROM ACCOUNT"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }
                                else if (EJResult.Contains("(1*"))
                                {
                                    ErrorCode = ErrorCode + " " + EJResult;
                                }

                                j = EndIndex;
                            }
                            catch
                            {
                                j = EndIndex;
                            }
                        }
                    }
                    #region StanderedFields

                    ReversalFlag = false;
                    TxnsStatus = string.Empty;
                    DebitCreditType = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    CardType = string.Empty;

                    TxnsDateTimeMain = null;

                    card = false;
                    Terminal = false;
                    Acquirer = false;
                    Rev1 = false;
                    Rev2 = false;
                    ATM = false;
                    CDM = false;
                    POS = false;
                    ECOM = false;
                    IMPS = false;
                    UPI = false;
                    MicroATM = false;
                    MobileRecharge = false;
                    BAL = false;
                    MS = false;
                    PC = false;
                    CB = false;
                    RCA1 = false;
                    RCA2 = false;
                    //MC = false;
                    //VC = false;
                    OC = false;
                    D = false;
                    C = false;

                    if (CardNumber != "")
                    {
                        CardType = Common.GetCardType(CardNumber);
                    }


                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        try
                        {
                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + " " + TxnsTime, TxnDateTime, CultureInfo.InvariantCulture, DateTimeStyles.None);
                        }
                        catch
                        {

                        }

                    }

                    if (TerminalID.Length > 0 && !CassetteFetch)
                    {
                        DataTable dataTable = Common.GetCassetteInfoByTerminalId(_connectionString, ClientCode, TerminalID);

                        if (dataTable != null && dataTable.Rows.Count > 0)
                        {
                            Cassette1 = Convert.ToString(dataTable.Rows[0]["Cassette1"]);
                            Cassette2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                            Cassette3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                            Cassette4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);

                        }

                        dataTable = null;
                        CassetteFetch = true;
                    }


                    if (FileDate == null)
                    {
                        FileDate = TxnsDateTimeMain;
                    }

                    if (CassetteFetch)
                    {
                        //if (Notes != null && Notes.Length == 4)
                        //{
                        //    Denomination1 = Cassette1.Length == 0 ? Notes[0] : Convert.ToString(Convert.ToDecimal(Cassette1) * Convert.ToDecimal(Notes[0]));
                        //    Denomination2 = Cassette2.Length == 0 ? Notes[1] : Convert.ToString(Convert.ToDecimal(Cassette2) * Convert.ToDecimal(Notes[1]));
                        //    Denomination3 = Cassette3.Length == 0 ? Notes[2] : Convert.ToString(Convert.ToDecimal(Cassette3) * Convert.ToDecimal(Notes[2]));
                        //    Denomination4 = Cassette4.Length == 0 ? Notes[3] : Convert.ToString(Convert.ToDecimal(Cassette4) * Convert.ToDecimal(Notes[3]));
                        //}
                        //else
                        //{
                        //    Denomination1 = Notes[0];
                        //    Denomination2 = Notes[1];
                        //    Denomination3 = Notes[2];
                        //    Denomination4 = Notes[3];
                        //}

                        Denomination1 = Cassette1.Length == 0 ? "0" : Cassette1;
                        Denomination2 = Cassette2.Length == 0 ? "0" : Cassette2;
                        Denomination3 = Cassette3.Length == 0 ? "0" : Cassette3;
                        Denomination4 = Cassette4.Length == 0 ? "0" : Cassette4;
                    }
                    else
                    {
                        Denomination1 = "0";
                        Denomination2 = "0";
                        Denomination3 = "0";
                        Denomination4 = "0";
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                                break;
                            }
                        }
                    }


                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                                break;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                            {
                                card = true;
                                break;
                            }
                        }
                    }



                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                                break;
                            }
                        }
                    }
                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                                break;
                            }
                        }
                        for (i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                                break;
                            }
                        }
                    }




                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                    break;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                    break;
                                }
                            }
                        }

                        //if (POSType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < POSType.Length; i++)
                        //    {
                        //        if (POSType[i].ToString() == TxnsSubType)
                        //        {
                        //            POS = true;
                        //        }
                        //    }
                        //}
                        //if (ECOMType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < ECOMType.Length; i++)
                        //    {
                        //        if (ECOMType[i].ToString() == TxnsSubType)
                        //        {
                        //            ECOM = true;
                        //        }
                        //    }
                        //}

                        //if (IMPType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < IMPType.Length; i++)
                        //    {
                        //        if (IMPType[i].ToString() == TxnsSubType)
                        //        {
                        //            IMPS = true;
                        //        }
                        //    }
                        //}

                        //if (UPIType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < UPIType.Length; i++)
                        //    {
                        //        if (UPIType[i].ToString() == TxnsSubType)
                        //        {
                        //            UPI = true;
                        //        }
                        //    }
                        //}

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType)
                                {
                                    MicroATM = true;
                                    break;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                    break;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType)
                                {
                                    ATM = true;
                                    break;
                                }
                            }
                        }

                        //if (POSType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < POSType.Length; i++)
                        //    {
                        //        if (POSType[i].ToString() == ChannelType)
                        //        {
                        //            POS = true;
                        //        }
                        //    }
                        //}
                        //if (ECOMType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < ECOMType.Length; i++)
                        //    {
                        //        if (ECOMType[i].ToString() == ChannelType)
                        //        {
                        //            ECOM = true;
                        //        }
                        //    }
                        //}

                        //if (IMPType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < IMPType.Length; i++)
                        //    {
                        //        if (IMPType[i].ToString() == ChannelType)
                        //        {
                        //            IMPS = true;
                        //        }
                        //    }
                        //}

                        //if (UPIType[0].ToString() != "")
                        //{
                        //    for (i = 0; i < UPIType.Length; i++)
                        //    {
                        //        if (UPIType[i].ToString() == ChannelType)
                        //        {
                        //            UPI = true;
                        //        }
                        //    }
                        //}

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType)
                                {
                                    MicroATM = true;
                                    break;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                    break;
                                }
                            }
                        }
                    }


                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                                break;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                                break;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                                break;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                                break;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                                break;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                                break;
                            }
                        }

                        for (i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode)
                            {
                                RCA2 = true;
                                break;
                            }
                        }
                    }


                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() == "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                                break;
                            }
                        }
                    }



                    if (DebitCode[0].ToString() != "")
                    {
                        for (i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                                break;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                                break;
                            }
                        }
                    }


                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    if (AcquirerID == string.Empty || AcquirerID == "")
                    {
                        if (Terminal == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        else if (Terminal == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        else if (Terminal == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }
                    else
                    {
                        if (Acquirer == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        else if (Acquirer == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        else if (Acquirer == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }

                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    if (RCA1 == true || RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }
                    else
                    {
                        TxnsStatus = "Unsucessfull";
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    else if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                    }
                    else if (POS)
                    {
                        TxnsSubTypeMain = "Purchase";
                    }
                    else if (ECOM)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (IMPS)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (MicroATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                    }
                    else if (MobileRecharge)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (UPI)
                    {
                        TxnsSubTypeMain = "Transfer";
                    }
                    else if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }
                    else if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }
                    else if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }
                    else if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }


                    if (BAL || MS || PC || CB)
                    {
                        TxnsType = "Non-Financial";
                    }
                    else
                    {
                        TxnsType = "Financial";
                    }
                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    #endregion InitilizedField


                    //#endregion StanderedFields

                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }

                    if (CardNumber != "")
                    {
                        string dummy = "XXXXXXXXXX";
                        tempCardNumber = CardNumber;

                        CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);

                        ReserveField5 = ReserveField5.Replace(tempCardNumber, CardNumber);
                    }

                    if (ReserveField5.Length >= 3900)
                    {
                        ReserveField5 = ReserveField5.Substring(0, 3900);
                    }

                    if (TxnsType == "Financial" && TxnsStatus == "Sucessfull")
                    {
                        Status = "1";
                    }
                    else if (TxnsType == "Financial" && TxnsStatus == "Unsucessfull")
                    {
                        Status = "2";

                        if (ReqAmount > 0 && TxnsAmount == 0)
                        {
                            TxnsAmount = ReqAmount;
                        }
                    }

                    CustBalance = CustBalance == "" ? "0" : CustBalance;
                    Amount1 = Amount1 == "" ? "0" : Amount1;
                    Amount2 = Amount2 == "" ? "0" : Amount2;

                    ReserveField5 = ReserveField5.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");

                    if (TxnsDateTimeMain != null && ReferenceNumber != "")
                    {
                        _DataTable.Rows.Add(
                                        ClientID
                                        , (int)TxnsChannelID.ATM
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , CardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , Convert.ToDecimal(CustBalance)
                                        , TxnsDateTimeMain
                                        , TxnsAmount
                                        , ReqAmount
                                        , Convert.ToDecimal(Amount1)
                                        , Convert.ToDecimal(Amount2)
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubTypeMain
                                        , TxnsEntryType
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , ReferenceNumber
                                        , CurrencyCode
                                        , Opcode
                                        , ErrorCode
                                        , ReversalFlag
                                        , Notes[0]
                                        , Notes[1]
                                        , Notes[2]
                                        , Notes[3]
                                        , Denomination1
                                        , Denomination2
                                        , Denomination3
                                        , Denomination4
                                        , Dispenseds[1]
                                        , Dispenseds[2]
                                        , Dispenseds[3]
                                        , Dispenseds[4]
                                        , Rejecteds[1]
                                        , Rejecteds[2]
                                        , Rejecteds[3]
                                        , Rejecteds[4]
                                        , Remainings[1]
                                        , Remainings[2]
                                        , Remainings[3]
                                        , Remainings[4]
                                        , ReserveField1
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , Status
                                        , ECardNumber.Trim()
                                        );

                    }


                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }
            return _DataTable;
        }

        public DataTable ASP_SplitDataCITIZEN(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTimeConverter objDateTimeConverter = new DateTimeConverter();
            System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");


            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("CustAccountNo", typeof(string));
            _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
            _DataTable.Columns.Add("ATMAccountNo", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("Amount2", typeof(decimal));
            _DataTable.Columns.Add("Amount3", typeof(decimal));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
            _DataTable.Columns.Add("ATMBalance", typeof(decimal));
            _DataTable.Columns.Add("BranchCode", typeof(string));
            _DataTable.Columns.Add("TransSEQNumber", typeof(string));
            _DataTable.Columns.Add("OPCode", typeof(string));
            _DataTable.Columns.Add("ResultCode", typeof(string));
            _DataTable.Columns.Add("ErrorCode", typeof(string));
            _DataTable.Columns.Add("TCode", typeof(string));
            _DataTable.Columns.Add("TCode1", typeof(string));
            _DataTable.Columns.Add("FunctionID", typeof(string));
            _DataTable.Columns.Add("Amount", typeof(decimal));
            _DataTable.Columns.Add("Denomination", typeof(string));
            _DataTable.Columns.Add("RequestCount", typeof(string));
            _DataTable.Columns.Add("DispenseCount", typeof(string));
            _DataTable.Columns.Add("RemainCount", typeof(string));
            _DataTable.Columns.Add("PickupCount", typeof(string));
            _DataTable.Columns.Add("RejectCount", typeof(string));
            _DataTable.Columns.Add("Cassette1", typeof(string));
            _DataTable.Columns.Add("Cassette2", typeof(string));
            _DataTable.Columns.Add("Cassette3", typeof(string));
            _DataTable.Columns.Add("Cassette4", typeof(string));
            //_DataTable.Columns.Add("InitAmount", typeof(decimal));
            //_DataTable.Columns.Add("DispAmount", typeof(decimal));
            //_DataTable.Columns.Add("StorAmount", typeof(decimal));
            //_DataTable.Columns.Add("RemAmount", typeof(decimal));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("NoOfDuplicate", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;









            DataSet ds = new DataSet();

            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            DateTime TimeStamp = System.DateTime.Now;
            DateTime TimeStamp1 = System.DateTime.Now;
            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            //DateTime? TxnsDateTime;
            //TxnsDateTime = null;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            //string TxnsAmount = "0";
            string TxnsAmount = string.Empty;
            decimal TxnsAmount1 = 0;
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string line = string.Empty;
            string line1 = string.Empty;
            string ResponseCode = string.Empty;
            string EJResult = string.Empty;
            string StrDateTime = string.Empty;
            string StrTime = string.Empty;
            string ErrorCode = string.Empty;
            string terminal = string.Empty;
            string TransSeqNo = string.Empty;
            string Opcode = string.Empty;
            string FunctionId = string.Empty;
            string Denomination = string.Empty;
            string ReqCount = string.Empty;
            string DispenseCount = string.Empty;
            string PickupCount = string.Empty;
            string RemainCount = string.Empty;
            string RejectCount = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string resultCode = string.Empty;
            string Remark3 = string.Empty;
            string ECardNumber = string.Empty;


            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            int ModeID = 0;
            int ChannelID;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            decimal Amount = 0;

            bool card = false;
            bool Terminal = false;
            bool Acquirer = false;
            bool Rev1 = false;
            bool Rev2 = false;
            bool ATM = false;
            bool CDM = false;
            bool POS = false;
            bool ECOM = false;
            bool IMPS = false;
            bool UPI = false;
            bool MicroATM = false;
            bool MobileRecharge = false;
            bool BAL = false;
            bool MS = false;
            bool PC = false;
            bool CB = false;
            bool RCA1 = false;
            bool RCA2 = false;
            bool MC = false;
            bool VC = false;
            bool OC = false;
            bool D = false;
            bool C = false;

            string SplitType = ",";
            string[] TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] AcquirerIDArray = dt.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode1Array = dt.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode2Array = dt.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ReversalType = dt.Rows[0]["ReversalType"].ToString();
            string[] ATMType = dt.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CDMType = dt.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] POSType = dt.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ECOMType = dt.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] IMPType = dt.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] UPIType = dt.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MicroATMType = dt.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MobileRechargeType = dt.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BalanceEnquiry = dt.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MiniStatement = dt.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] PinChange = dt.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ChequeBookReq = dt.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ResponseType = dt.Rows[0]["ResponseType"].ToString();
            string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ResponseCode2Array = dt.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] OfflineCode = dt.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnDateTime = dt.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnPostDateTime = dt.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] DebitCode = dt.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CreditCode = dt.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);

            string[] Arr_REFNO;
            string[] CARD_AUTH;
            string[] ACCNO;
            string[] arrResp_code;
            string[] arrAMOUNT;

            int i = 0;

            for (int j = 0; j <= TotalCount; j++)
            {
                try
                {
                    StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID"); //DBA8
                    EndIndex = Common.GetIndex(TotalCountArray, j + 1, "------------------------------------");

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex; k <= EndIndex; k++)
                        {

                            try
                            {

                                LineNo++;

                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = Common.RemoveAdditionalChars(line);


                                if (EJResult.Contains("REF NO"))
                                {
                                    Arr_REFNO = EJResult.Split(':');

                                    int V = Arr_REFNO.Length;


                                    if (V == 2)
                                    {
                                        ReferenceNumber = Arr_REFNO[1].Trim();
                                        AuthCode = Arr_REFNO[1].Trim();

                                        if (ReferenceNumber == "214317002904")
                                        {
                                        }
                                    }
                                }


                                if (EJResult.Contains("ATM ID"))
                                {
                                    TerminalID = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                if (EJResult.Contains("CARD NO"))
                                {
                                    CARD_AUTH = EJResult.Split(':');

                                    if (CARD_AUTH.Length == 2)
                                    {
                                        CardNumber = CARD_AUTH[1].Trim();
                                    }
                                }

                                if (EJResult.Contains("A/C NO"))
                                {

                                    ACCNO = EJResult.Split(':');
                                    CustAccountNo = ACCNO[1].Trim();

                                }

                                if (EJResult.Contains("TRANSTYPE"))
                                {
                                    arrResp_code = EJResult.Split(':');
                                    TxnsSubType = arrResp_code[1].Trim();

                                }
                                if (EJResult.Contains("RESP CODE"))
                                {
                                    arrResp_code = EJResult.Split(':');
                                    ResponseCode = arrResp_code[1].Trim();
                                }

                                if (EJResult.Contains("WDL AMT"))
                                {
                                    arrAMOUNT = EJResult.Split(':');
                                    //TxnsAmount = EJResult.Substring(10, 7).Trim();
                                    TxnsAmount = arrAMOUNT[1].Trim();
                                    if (TxnsAmount == "")
                                    {
                                        TxnsAmount1 = 0;
                                    }
                                    else
                                    {
                                        TxnsAmount = arrAMOUNT[1].Trim();
                                        TxnsAmount1 = Convert.ToDecimal(TxnsAmount);
                                    }
                                    // Amount = Convert.ToDouble(arrAMOUNT[1].Trim());
                                    //TxnsAmount = Convert.ToDouble(arrAMOUNT[1].Trim());
                                }

                                if (EJResult.Contains("DATE"))  // || TotalCountArray[k - 1].ToString().Contains("/")
                                {
                                    //StrDateTime = TotalCountArray[k - 1].ToString().Replace("BANK OF BARODADUGRI ROAD, LUDHIANALUDHIANA", "").ToString().Trim();
                                    //TxnsDateTime = StrDateTime;
                                    ////TxnsDateTime = DateTime.ParseExact(StrDateTime, "dd/MM/yy HH:mm", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);
                                    //TxnsValueDateTime = TxnsDateTime;
                                    //TxnsPostDateTime = TxnsDateTime;
                                    StrDateTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsDate = StrDateTime;
                                }

                                if (EJResult.Contains("TIME") && !(EJResult.Contains("Timeout")) && !(EJResult.Contains("TIMEOUT")) && !(EJResult.Contains("PRESENT TIMER EXPIRED"))) //|| TotalCountArray[k - 1].ToString().Contains("/")                                   
                                {
                                    //StrDateTime = TotalCountArray[k - 1].ToString().Replace("BANK OF BARODADUGRI ROAD, LUDHIANALUDHIANA", "").ToString().Trim();
                                    //TxnsDateTime = StrDateTime;
                                    ////TxnsDateTime = DateTime.ParseExact(StrDateTime, "dd/MM/yy HH:mm", CultureInfo.InvariantCulture);//Convert.ToDateTime(str_TrTimstamp);
                                    //TxnsValueDateTime = TxnsDateTime;
                                    //TxnsPostDateTime = TxnsDateTime;
                                    StrTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsTime = StrTime;
                                }

                                //if (EJResult.Contains("TX :"))
                                //{
                                //    TxnsSubType = "WITHDRAWAL";
                                //}

                                j = EndIndex;
                            }
                            catch
                            {
                                j = EndIndex;
                            }
                        }
                    }
                    #region StanderedFields

                    ReversalFlag = false;
                    TxnsStatus = string.Empty;
                    DebitCreditType = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    CardType = string.Empty;

                    TxnsDateTimeMain = null;
                    TxnsPostDateTimeMain = null;

                    card = false;
                    Terminal = false;
                    Acquirer = false;
                    Rev1 = false;
                    Rev2 = false;
                    ATM = false;
                    CDM = false;
                    POS = false;
                    ECOM = false;
                    IMPS = false;
                    UPI = false;
                    MicroATM = false;
                    MobileRecharge = false;
                    BAL = false;
                    MS = false;
                    PC = false;
                    CB = false;
                    RCA1 = false;
                    RCA2 = false;
                    MC = false;
                    VC = false;
                    OC = false;
                    D = false;
                    C = false;


                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        TxnsDateTimeMain = Convert.ToDateTime(TxnsDate + " " + TxnsTime);
                        //TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + TxnsTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);
                    }

                    if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                    {

                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);

                    }


                    if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                    {
                        for (i = 0; i < TxnPostDateTime.Length; i++)
                        {
                            if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                            {
                                TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                            }
                            else
                            {
                                TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), CultureInfo.InvariantCulture);
                            }
                        }
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                            }
                        }
                    }


                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                            {
                                card = true;
                            }
                        }
                    }



                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                    }
                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                        for (i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                            }
                        }
                    }




                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == TxnsSubType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == TxnsSubType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == TxnsSubType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == TxnsSubType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType)
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == ChannelType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == ChannelType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == ChannelType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == ChannelType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType)
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }


                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                            }
                        }

                        for (i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode)
                            {
                                RCA2 = true;
                            }
                        }
                    }


                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() == "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                            }
                        }
                    }



                    if (DebitCode[0].ToString() != "")
                    {
                        for (i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                            }
                        }
                    }


                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    if (AcquirerID == string.Empty || AcquirerID == "")
                    {
                        if (Terminal == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Terminal == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Terminal == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }
                    else
                    {
                        if (Acquirer == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Acquirer == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Acquirer == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }

                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (POS)
                    {
                        ChannelID = (int)TxnsChannelID.POS;
                        TxnsSubTypeMain = "Purchase";
                    }

                    if (ECOM)
                    {
                        ChannelID = (int)TxnsChannelID.E_COMMERCE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (IMPS)
                    {
                        ChannelID = (int)TxnsChannelID.IMPS;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (MicroATM)
                    {
                        ChannelID = (int)TxnsChannelID.MICRO_ATM;
                        TxnsSubTypeMain = "Withdrawal";
                    }

                    if (MobileRecharge)
                    {
                        ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (UPI)
                    {
                        ChannelID = (int)TxnsChannelID.UPI;
                        TxnsSubTypeMain = "Transfer";
                    }
                    if (RCA1 == true || RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }
                    else
                    {
                        TxnsStatus = "Unsucessfull";
                    }


                    if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }

                    if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }

                    if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }

                    if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }


                    if (BAL || MS || PC || CB)
                    {
                        TxnsType = "Non-Financial";
                    }
                    else
                    {
                        TxnsType = "Financial";
                    }
                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    #endregion InitilizedField


                    //#endregion StanderedFields

                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }

                    if (CardNumber != "")
                    {
                        string dummy = "XXXXXXXXXX";
                        CardNumber = CardNumber.Substring(0, 6) + dummy.Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);

                    }

                    if (TxnsDateTimeMain != null && ReferenceNumber != "")
                    {
                        _DataTable.Rows.Add(ClientID
                                        , (int)TxnsChannelID.ATM
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , CardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , InterchangeAccountNo
                                        , ATMAccountNo
                                        , TxnsDateTimeMain
                                        , TxnsAmount1
                                        , Convert.ToDecimal(Amount1)
                                        , Convert.ToDecimal(Amount2)
                                        , Convert.ToDecimal(Amount3)
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubTypeMain
                                        , TxnsEntryType
                                        , TxnsNumber
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , ReversalFlag
                                        , TxnsPostDateTimeMain
                                        , TxnsPostDateTimeMain
                                        , AuthCode
                                        , ProcessingCode
                                        , Convert.ToDecimal(FeeAmount)
                                        , CurrencyCode
                                        , Convert.ToDecimal(CustBalance)
                                        , Convert.ToDecimal(InterchangeBalance)
                                        , Convert.ToDecimal(ATMBalance)
                                        , BranchCode
                                        , TransSeqNo
                                        , Opcode
                                        , resultCode
                                        , ErrorCode
                                        , TCode
                                        , TCode1
                                        , FunctionId
                                        , Amount
                                        , Denomination
                                        , ReqCount
                                        , DispenseCount
                                        , RemainCount
                                        , PickupCount
                                        , RejectCount
                                        , Cassette1
                                        , Cassette2
                                        , Cassette3
                                        , Cassette4
                                        , ReserveField1
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , RevEntryLeg
                                        , 0
                                        , FileName
                                        , path
                                        , null
                                        , DateTime.Now
                                        , DateTime.Now
                                        , UserName
                                        , ""
                                        , ECardNumber.Trim()
                                        );

                    }
                    TxnsAmount1 = 0;
                    TerminalID = string.Empty;
                    AcquirerID = string.Empty;
                    ReferenceNumber = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    InterchangeAccountNo = string.Empty;
                    ATMAccountNo = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsDate = string.Empty;
                    TxnsTime = string.Empty;
                    TxnsAmount = string.Empty;
                    Amount1 = "0";
                    Amount2 = "0";
                    Amount3 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsNumber = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;
                    TxnsPostDateTime = string.Empty;
                    TxnsValueDateTime = string.Empty;
                    AuthCode = string.Empty;
                    ProcessingCode = string.Empty;
                    FeeAmount = "0";
                    CurrencyCode = string.Empty;
                    CustBalance = "0";
                    InterchangeBalance = "0";
                    ATMBalance = "0";
                    BranchCode = string.Empty;
                    Cassette1 = string.Empty;
                    Cassette2 = string.Empty;
                    Cassette3 = string.Empty;
                    Cassette4 = string.Empty;
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    ResponseCode = string.Empty;
                    EJResult = string.Empty;
                    StrDateTime = string.Empty;
                    StrTime = string.Empty;
                    ErrorCode = string.Empty;
                    terminal = string.Empty;
                    TransSeqNo = string.Empty;
                    Opcode = string.Empty;
                    FunctionId = string.Empty;
                    Denomination = string.Empty;
                    ReqCount = string.Empty;
                    DispenseCount = string.Empty;
                    PickupCount = string.Empty;
                    RemainCount = string.Empty;
                    RejectCount = string.Empty;
                    TCode = string.Empty;
                    TCode1 = string.Empty;
                    resultCode = string.Empty;
                    Remark3 = string.Empty;
                    ECardNumber = string.Empty;
                    CardType = string.Empty;
                    TxnsStatus = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    DebitCreditType = string.Empty;
                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }
            return _DataTable;
        }


        public DataTable ASP_SplitDataMachineCounter(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();


            DataTable _DataTableMCCounter = new DataTable();
            _DataTableMCCounter.Columns.Add("ClientID", typeof(int));
            _DataTableMCCounter.Columns.Add("TerminalID", typeof(string));
            _DataTableMCCounter.Columns.Add("CurrentEOD", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("MachineOp100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOpTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDisTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRemTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoadTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosingTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("RETRACTNOTESCOUNT", typeof(string));
            _DataTableMCCounter.Columns.Add("CassetteRemarks", typeof(string));
            _DataTableMCCounter.Columns.Add("Filename", typeof(string));
            _DataTableMCCounter.Columns.Add("FilePath", typeof(string));
            _DataTableMCCounter.Columns.Add("FileDate", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("CreatedON", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("Createdby", typeof(string));


            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;

            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            DateTime? FileDate = null;
            try
            {
                FileDate = DateTime.ParseExact(FileName.Substring(FileName.IndexOf("_") + 1, 8).Trim(), "yyyyMMdd", CultureInfo.InvariantCulture);
            }
            catch
            {

            }

            string TerminalId = Path.GetFileNameWithoutExtension(FileName.Split('_').First().Trim().ToString()).Replace("EJ", "");


            decimal MCOp100 = 0;
            decimal MCOp200 = 0;
            decimal MCOp500 = 0;
            decimal MCOp2000 = 0;
            decimal MCDis100 = 0;
            decimal MCDis200 = 0;
            decimal MCDis500 = 0;
            decimal MCDis2000 = 0;
            decimal MCRem100 = 0;
            decimal MCRem200 = 0;
            decimal MCRem500 = 0;
            decimal MCRem2000 = 0;
            decimal MCClosing100 = 0;
            decimal MCClosing200 = 0;
            decimal MCClosing500 = 0;
            decimal MCClosing2000 = 0;
            decimal RETRACTNOTESCOUNT = 0;

            string CassetteMaster1 = string.Empty;
            string CassetteMaster2 = string.Empty;
            string CassetteMaster3 = string.Empty;
            string CassetteMaster4 = string.Empty;

            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            string Rejected1 = string.Empty;
            string Rejected2 = string.Empty;
            string Rejected3 = string.Empty;
            string Rejected4 = string.Empty;
            string Remaining1 = string.Empty;
            string Remaining2 = string.Empty;
            string Remaining3 = string.Empty;
            string Remaining4 = string.Empty;
            string Dispense1 = string.Empty;
            string Dispense2 = string.Empty;
            string Dispense3 = string.Empty;
            string Dispense4 = string.Empty;

            string TotalDispense1 = string.Empty;
            string TotalDispense2 = string.Empty;
            string TotalDispense3 = string.Empty;
            string TotalDispense4 = string.Empty;

            int CASSETTE_Count = 0;
            int RejectCount = 0;
            int REMAINING_Count = 0;
            int DISPENSED_Count = 0;
            int TOTAL_Count = 0;

            DateTime? CounterDate = null;

            string line = string.Empty;
            string EJResult = string.Empty;

            if (TerminalId.Length > 0)
            {
                DataTable dataTable = Common.GetCassetteInfoByTerminalId(_connectionString, ClientCode, TerminalId);

                if (dataTable != null && dataTable.Rows.Count > 0)
                {
                    CassetteMaster1 = Convert.ToString(dataTable.Rows[0]["Cassette1"]);
                    CassetteMaster2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                    CassetteMaster3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                    CassetteMaster4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);

                }

                dataTable = null;
            }


            string[] TotalCountArray = File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;

            string[] CASSETTE = new string[3];

            if (TotalCountArray != null && TotalCountArray.Length > 0)
            {
                for (int j = 0; j <= TotalCount; j++)
                {
                    try
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j, "SUPERVISOR MODE ENTRY");
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "SUPERVISOR MODE EXIT");

                        if (StartIndex != -1 && EndIndex != -1)
                        {
                            for (int k = StartIndex + 1; k <= EndIndex - 1; k++)
                            {
                                try
                                {
                                    line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                    EJResult = Common.RemoveAdditionalChars(line);



                                    if (line.Contains(" CASSETTE") && CASSETTE_Count == 0)
                                    {
                                        CASSETTE_Count++;

                                        CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        Cassette1 = CASSETTE[1].Trim().ToString();
                                        Cassette2 = CASSETTE[2].Trim().ToString();
                                    }
                                    else if (line.Contains(" CASSETTE") && CASSETTE_Count == 1)
                                    {
                                        CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        Cassette3 = CASSETTE[1].Trim().ToString();
                                        Cassette4 = CASSETTE[2].Trim().ToString();
                                    }

                                    if (line.Contains("+REJECTED") && RejectCount == 0)
                                    {
                                        RejectCount++;

                                        CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        Rejected1 = CASSETTE[1].Trim().ToString();
                                        Rejected2 = CASSETTE[2].Trim().ToString();
                                    }
                                    else if (line.Contains("+REJECTED") && RejectCount == 1)
                                    {
                                        CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        Rejected3 = CASSETTE[1].Trim().ToString();
                                        Rejected4 = CASSETTE[2].Trim().ToString();

                                        RETRACTNOTESCOUNT = Convert.ToDecimal(Rejected1) + Convert.ToDecimal(Rejected2) + Convert.ToDecimal(Rejected3) + Convert.ToDecimal(Rejected4);
                                    }

                                    if (line.Contains("=REMAINING") && REMAINING_Count == 0)
                                    {
                                        REMAINING_Count++;

                                        CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        Remaining1 = CASSETTE[1].Trim().ToString();
                                        Remaining2 = CASSETTE[2].Trim().ToString();
                                    }
                                    else if (line.Contains("=REMAINING") && REMAINING_Count == 1)
                                    {
                                        CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        Remaining3 = CASSETTE[1].Trim().ToString();
                                        Remaining4 = CASSETTE[2].Trim().ToString();
                                    }
                                    if (line.Contains("+DISPENSED") && DISPENSED_Count == 0)
                                    {
                                        DISPENSED_Count++;

                                        CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        Dispense1 = CASSETTE[1].Trim().ToString();
                                        Dispense2 = CASSETTE[2].Trim().ToString();
                                    }
                                    else if (line.Contains("+DISPENSED") && DISPENSED_Count == 1)
                                    {
                                        CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        Dispense3 = CASSETTE[1].Trim().ToString();
                                        Dispense4 = CASSETTE[2].Trim().ToString();
                                    }

                                    if (line.Contains("=TOTAL") && TOTAL_Count == 0)
                                    {
                                        TOTAL_Count++;

                                        CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        TotalDispense1 = CASSETTE[1].Trim().ToString();
                                        TotalDispense2 = CASSETTE[2].Trim().ToString();

                                    }
                                    else if (line.Contains("=TOTAL") && TOTAL_Count == 1)
                                    {
                                        CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        TotalDispense3 = CASSETTE[1].Trim().ToString();
                                        TotalDispense4 = CASSETTE[2].Trim().ToString();
                                    }

                                    if (EJResult.Contains("DATE-TIME"))
                                    {
                                        string[] date1 = EJResult.Split('=').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        CounterDate = DateTime.ParseExact(date1[1].Substring(0, 14).Trim().ToString(), "MM/dd/yy HH:mm", CultureInfo.InvariantCulture);

                                    }

                                    j = EndIndex;

                                }
                                catch
                                {
                                    j = EndIndex;
                                }
                            }


                            try
                            {
                                if (Dispense1.Length > 0 || Dispense2.Length > 0 || Dispense3.Length > 0 || Dispense4.Length > 0)
                                {

                                    if (CassetteMaster1.Length > 0 && Convert.ToInt32(CassetteMaster1) > 0)
                                    {
                                        MCDis100 += CassetteMaster1 == "100" ? Convert.ToDecimal(Dispense1) : 0;
                                        MCDis200 += CassetteMaster1 == "200" ? Convert.ToDecimal(Dispense1) : 0;
                                        MCDis500 += CassetteMaster1 == "500" ? Convert.ToDecimal(Dispense1) : 0;
                                        MCDis2000 += CassetteMaster1 == "2000" ? Convert.ToDecimal(Dispense1) : 0;

                                        MCOp100 += CassetteMaster1 == "100" ? Convert.ToDecimal(TotalDispense1) : 0;
                                        MCOp200 += CassetteMaster1 == "200" ? Convert.ToDecimal(TotalDispense1) : 0;
                                        MCOp500 += CassetteMaster1 == "500" ? Convert.ToDecimal(TotalDispense1) : 0;
                                        MCOp2000 += CassetteMaster1 == "2000" ? Convert.ToDecimal(TotalDispense1) : 0;

                                        MCClosing100 += CassetteMaster1 == "100" ? Convert.ToDecimal(TotalDispense1) : 0;
                                        MCClosing200 += CassetteMaster1 == "200" ? Convert.ToDecimal(TotalDispense1) : 0;
                                        MCClosing500 += CassetteMaster1 == "500" ? Convert.ToDecimal(TotalDispense1) : 0;
                                        MCClosing2000 += CassetteMaster1 == "2000" ? Convert.ToDecimal(TotalDispense1) : 0;
                                    }

                                    if (CassetteMaster2.Length > 0 && Convert.ToInt32(CassetteMaster2) > 0)
                                    {
                                        MCDis100 += CassetteMaster2 == "100" ? Convert.ToDecimal(Dispense2) : 0;
                                        MCDis200 += CassetteMaster2 == "200" ? Convert.ToDecimal(Dispense2) : 0;
                                        MCDis500 += CassetteMaster2 == "500" ? Convert.ToDecimal(Dispense2) : 0;
                                        MCDis2000 += CassetteMaster2 == "2000" ? Convert.ToDecimal(Dispense2) : 0;

                                        MCOp100 += CassetteMaster2 == "100" ? Convert.ToDecimal(TotalDispense2) : 0;
                                        MCOp200 += CassetteMaster2 == "200" ? Convert.ToDecimal(TotalDispense2) : 0;
                                        MCOp500 += CassetteMaster2 == "500" ? Convert.ToDecimal(TotalDispense2) : 0;
                                        MCOp2000 += CassetteMaster2 == "2000" ? Convert.ToDecimal(TotalDispense2) : 0;

                                        MCClosing100 += CassetteMaster2 == "100" ? Convert.ToDecimal(TotalDispense2) : 0;
                                        MCClosing200 += CassetteMaster2 == "200" ? Convert.ToDecimal(TotalDispense2) : 0;
                                        MCClosing500 += CassetteMaster2 == "500" ? Convert.ToDecimal(TotalDispense2) : 0;
                                        MCClosing2000 += CassetteMaster2 == "2000" ? Convert.ToDecimal(TotalDispense2) : 0;
                                    }

                                    if (CassetteMaster3.Length > 0 && Convert.ToInt32(CassetteMaster3) > 0)
                                    {
                                        MCDis100 += CassetteMaster3 == "100" ? Convert.ToDecimal(Dispense3) : 0;
                                        MCDis200 += CassetteMaster3 == "200" ? Convert.ToDecimal(Dispense3) : 0;
                                        MCDis500 += CassetteMaster3 == "500" ? Convert.ToDecimal(Dispense3) : 0;
                                        MCDis2000 += CassetteMaster3 == "2000" ? Convert.ToDecimal(Dispense3) : 0;

                                        MCOp100 += CassetteMaster3 == "100" ? Convert.ToDecimal(TotalDispense3) : 0;
                                        MCOp200 += CassetteMaster3 == "200" ? Convert.ToDecimal(TotalDispense3) : 0;
                                        MCOp500 += CassetteMaster3 == "500" ? Convert.ToDecimal(TotalDispense3) : 0;
                                        MCOp2000 += CassetteMaster3 == "2000" ? Convert.ToDecimal(TotalDispense3) : 0;

                                        MCClosing100 += CassetteMaster3 == "100" ? Convert.ToDecimal(TotalDispense3) : 0;
                                        MCClosing200 += CassetteMaster3 == "200" ? Convert.ToDecimal(TotalDispense3) : 0;
                                        MCClosing500 += CassetteMaster3 == "500" ? Convert.ToDecimal(TotalDispense3) : 0;
                                        MCClosing2000 += CassetteMaster3 == "2000" ? Convert.ToDecimal(TotalDispense3) : 0;
                                    }

                                    if (CassetteMaster4.Length > 0 && Convert.ToInt32(CassetteMaster4) > 0)
                                    {
                                        MCDis100 += CassetteMaster4 == "100" ? Convert.ToDecimal(Dispense4) : 0;
                                        MCDis200 += CassetteMaster4 == "200" ? Convert.ToDecimal(Dispense4) : 0;
                                        MCDis500 += CassetteMaster4 == "500" ? Convert.ToDecimal(Dispense4) : 0;
                                        MCDis2000 += CassetteMaster4 == "2000" ? Convert.ToDecimal(Dispense4) : 0;

                                        MCOp100 += CassetteMaster4 == "100" ? Convert.ToDecimal(TotalDispense4) : 0;
                                        MCOp200 += CassetteMaster4 == "200" ? Convert.ToDecimal(TotalDispense4) : 0;
                                        MCOp500 += CassetteMaster4 == "500" ? Convert.ToDecimal(TotalDispense4) : 0;
                                        MCOp2000 += CassetteMaster4 == "2000" ? Convert.ToDecimal(TotalDispense4) : 0;

                                        MCClosing100 += CassetteMaster4 == "100" ? Convert.ToDecimal(TotalDispense4) : 0;
                                        MCClosing200 += CassetteMaster4 == "200" ? Convert.ToDecimal(TotalDispense4) : 0;
                                        MCClosing500 += CassetteMaster4 == "500" ? Convert.ToDecimal(TotalDispense4) : 0;
                                        MCClosing2000 += CassetteMaster4 == "2000" ? Convert.ToDecimal(TotalDispense4) : 0;
                                    }

                                    _DataTableMCCounter.Rows.Add(
                                        ClientID, TerminalId, CounterDate,
                                        MCOp100, MCOp200, MCOp500, MCOp2000,
                                        (MCOp100 * 100) + (MCOp200 * 200) + (MCOp500 * 500) + (MCOp2000 * 2000),

                                        MCDis100, MCDis200, MCDis500, MCDis2000,
                                        (MCDis100 * 100) + (MCDis200 * 200) + (MCDis500 * 500) + (MCDis2000 * 2000),

                                        Convert.ToString(MCOp100 - MCDis100),
                                        Convert.ToString(MCOp200 - MCDis200),
                                        Convert.ToString(MCOp500 - MCDis500),
                                        Convert.ToString(MCOp2000 - MCDis2000),
                                        ((MCOp100 - MCDis100) * 100) + ((MCOp200 - MCDis200) * 200) + ((MCOp500 - MCDis500) * 500) + ((MCOp2000 - MCDis2000) * 2000),

                                        MCClosing100 - MCRem100, MCClosing200 - MCRem200,
                                        MCClosing500 - MCRem500, MCClosing2000 - MCRem2000,
                                        ((MCClosing100 - MCRem100) * 100) + ((MCClosing200 - MCRem200) * 200) + ((MCClosing500 - MCRem500) * 500) + ((MCClosing2000 - MCRem2000) * 2000),

                                        MCClosing100, MCClosing200, MCClosing500, MCClosing2000,
                                        (MCClosing100 * 100) + (MCClosing200 * 200) + (MCClosing500 * 500) + (MCClosing2000 * 2000),

                                        RETRACTNOTESCOUNT, string.Empty, FileName, path, FileDate, System.DateTime.Now, UserName);
                                }
                            }
                            catch (Exception ex)
                            {
                                DBLog.InsertLogs("Adding machine counter in data table => " + ex.Message, ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                                //  DBLog.InsertLogs("Adding machine counter in data table => " + ex.Message, TerminalId, "SplitterCITIZEN.cs", "ASP_SplitDataMachineCounter", LineNo, FileName, UserName, 'E', _connectionString);
                            }
                        }

                        MCOp100 = 0;
                        MCOp200 = 0;
                        MCOp500 = 0;
                        MCOp2000 = 0;
                        MCDis100 = 0;
                        MCDis200 = 0;
                        MCDis500 = 0;
                        MCDis2000 = 0;
                        MCRem100 = 0;
                        MCRem200 = 0;
                        MCRem500 = 0;
                        MCRem2000 = 0;
                        MCClosing100 = 0;
                        MCClosing200 = 0;
                        MCClosing500 = 0;
                        MCClosing2000 = 0;
                        RETRACTNOTESCOUNT = 0;

                        Cassette1 = string.Empty;
                        Cassette2 = string.Empty;
                        Cassette3 = string.Empty;
                        Cassette4 = string.Empty;
                        Rejected1 = string.Empty;
                        Rejected2 = string.Empty;
                        Rejected3 = string.Empty;
                        Rejected4 = string.Empty;
                        Remaining1 = string.Empty;
                        Remaining2 = string.Empty;
                        Remaining3 = string.Empty;
                        Remaining4 = string.Empty;
                        Dispense1 = string.Empty;
                        Dispense2 = string.Empty;
                        Dispense3 = string.Empty;
                        Dispense4 = string.Empty;

                        TotalDispense1 = string.Empty;
                        TotalDispense2 = string.Empty;
                        TotalDispense3 = string.Empty;
                        TotalDispense4 = string.Empty;

                        CASSETTE_Count = 0;
                        RejectCount = 0;
                        REMAINING_Count = 0;
                        DISPENSED_Count = 0;
                        TOTAL_Count = 0;
                    }
                    catch (Exception ex)
                    {
                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }
                }



            }

            return _DataTableMCCounter;
        }

        public DataTable ASP_SplitDataMachineCounter2(string path, string FileName, DataTable dt, out int InsertCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTableMCCounter = new DataTable();
            _DataTableMCCounter.Columns.Add("ClientID", typeof(int));
            _DataTableMCCounter.Columns.Add("TerminalID", typeof(string));
            _DataTableMCCounter.Columns.Add("CurrentEOD", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("MachineOp100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOp2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineOpTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDis2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineDisTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRem2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineRemTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoad2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineLoadTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing100", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing200", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing500", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosing2000", typeof(string));
            _DataTableMCCounter.Columns.Add("MachineClosingTotal", typeof(string));
            _DataTableMCCounter.Columns.Add("RETRACTNOTESCOUNT", typeof(string));
            _DataTableMCCounter.Columns.Add("CassetteRemarks", typeof(string));
            _DataTableMCCounter.Columns.Add("Filename", typeof(string));
            _DataTableMCCounter.Columns.Add("FilePath", typeof(string));
            _DataTableMCCounter.Columns.Add("FileDate", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("CreatedON", typeof(DateTime));
            _DataTableMCCounter.Columns.Add("Createdby", typeof(string));


            InsertCount = 0;

            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;

            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            DateTime? FileDate = null;
            try
            {
                FileDate = DateTime.ParseExact(FileName.Substring(FileName.IndexOf("_") + 1, 8).Trim(), "yyyyMMdd", CultureInfo.InvariantCulture);
            }
            catch
            {

            }

            string TerminalId = string.Empty;


            //decimal MCOp100 = 0;
            //decimal MCOp200 = 0;
            //decimal MCOp500 = 0;
            //decimal MCOp2000 = 0;
            decimal MCDis100 = 0;
            decimal MCDis200 = 0;
            decimal MCDis500 = 0;
            decimal MCDis2000 = 0;
            decimal MCRem100 = 0;
            decimal MCRem200 = 0;
            decimal MCRem500 = 0;
            decimal MCRem2000 = 0;
            decimal MCClosing100 = 0;
            decimal MCClosing200 = 0;
            decimal MCClosing500 = 0;
            decimal MCClosing2000 = 0;
            decimal RETRACTNOTESCOUNT = 0;

            string CassetteMaster1 = string.Empty;
            string CassetteMaster2 = string.Empty;
            string CassetteMaster3 = string.Empty;
            string CassetteMaster4 = string.Empty;

            string[] Type1 = new string[1];
            string[] Type2 = new string[1];
            string[] Type3 = new string[1];
            string[] Type4 = new string[1];


            //string Rejected1 = string.Empty;
            //string Rejected2 = string.Empty;
            //string Rejected3 = string.Empty;
            //string Rejected4 = string.Empty;
            //string Remaining1 = string.Empty;
            //string Remaining2 = string.Empty;
            //string Remaining3 = string.Empty;
            //string Remaining4 = string.Empty;
            //string Dispense1 = string.Empty;
            //string Dispense2 = string.Empty;
            //string Dispense3 = string.Empty;
            //string Dispense4 = string.Empty;

            //string TotalDispense1 = string.Empty;
            //string TotalDispense2 = string.Empty;
            //string TotalDispense3 = string.Empty;
            //string TotalDispense4 = string.Empty; 

            DateTime? CounterDate = null;

            string line = string.Empty;
            string EJResult = string.Empty;

            string[] TotalCountArray = File.ReadAllLines(path);


            string[] CASSETTE = new string[3];

            if (TotalCountArray != null && TotalCountArray.Length > 0)
            {
                for (int j = 0; j <= TotalCountArray.Length; j++)
                {
                    StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID");
                    EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "BALANCE");

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex; k <= EndIndex - 1; k++)
                        {
                            try
                            {
                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = Common.RemoveAdditionalChars(line);

                                if (EJResult.Contains("ATM ID"))
                                {
                                    TerminalId = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    if (TerminalId.Length > 0)
                                    {
                                        break;
                                    }
                                }
                                j = EndIndex;
                            }
                            catch
                            {
                                j = EndIndex;
                            }
                        }
                    }

                    if (TerminalId.Length > 0)
                    {
                        break;
                    }
                }
            }

            if (TerminalId.Length > 0)
            {
                DataTable dataTable = Common.GetCassetteInfoByTerminalId(_connectionString, ClientID.ToString(), TerminalId);

                if (dataTable != null && dataTable.Rows.Count > 0)
                {
                    CassetteMaster1 = Convert.ToString(dataTable.Rows[0]["Cassette1"]);
                    CassetteMaster2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                    CassetteMaster3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                    CassetteMaster4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);

                }
                else
                {
                    CassetteMaster1 = "100";
                    CassetteMaster1 = "200";
                    CassetteMaster1 = "500";
                    CassetteMaster1 = "2000";
                }
                dataTable = null;
            }

            if (TotalCountArray != null && TotalCountArray.Length > 0 && TerminalId.Length > 0)
            {
                for (int j = 0; j <= TotalCountArray.Length; j++)
                {
                    try
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j, "SUPERVISOR MODE ENTRY");
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "SUPERVISOR MODE EXIT");

                        if (StartIndex != -1 && EndIndex != -1)
                        {
                            for (int k = StartIndex + 1; k <= EndIndex - 1; k++)
                            {
                                try
                                {
                                    line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                    EJResult = Common.RemoveAdditionalChars(line);

                                    if (EJResult.Contains("CASH DISPENSED"))
                                    {
                                        string[] Type1Type2 = TotalCountArray[k + 1].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        string[] Type3Type4 = TotalCountArray[k + 2].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();

                                        if (CassetteMaster1.Length > 0 && Convert.ToInt32(CassetteMaster1) > 0)
                                        {
                                            MCDis100 += CassetteMaster1 == "100" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCDis200 += CassetteMaster1 == "200" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCDis500 += CassetteMaster1 == "500" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCDis2000 += CassetteMaster1 == "2000" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                        }

                                        if (CassetteMaster2.Length > 0 && Convert.ToInt32(CassetteMaster2) > 0)
                                        {
                                            MCDis100 += CassetteMaster2 == "100" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCDis200 += CassetteMaster2 == "200" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCDis500 += CassetteMaster2 == "500" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCDis2000 += CassetteMaster2 == "2000" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                        }

                                        if (CassetteMaster3.Length > 0 && Convert.ToInt32(CassetteMaster3) > 0)
                                        {
                                            MCDis100 += CassetteMaster3 == "100" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCDis200 += CassetteMaster3 == "200" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCDis500 += CassetteMaster3 == "500" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCDis2000 += CassetteMaster3 == "2000" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                        }


                                        if (CassetteMaster4.Length > 0 && Convert.ToInt32(CassetteMaster4) > 0)
                                        {
                                            MCDis100 += CassetteMaster4 == "100" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCDis200 += CassetteMaster4 == "200" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCDis500 += CassetteMaster4 == "500" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCDis2000 += CassetteMaster4 == "2000" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                        }

                                    }
                                    else if (EJResult.Contains("CASH REMAINING"))
                                    {
                                        string[] Type1Type2 = TotalCountArray[k + 1].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        string[] Type3Type4 = TotalCountArray[k + 2].Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();

                                        if (CassetteMaster1.Length > 0 && Convert.ToInt32(CassetteMaster1) > 0)
                                        {
                                            MCRem100 += CassetteMaster1 == "100" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCRem200 += CassetteMaster1 == "200" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCRem500 += CassetteMaster1 == "500" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                            MCRem2000 += CassetteMaster1 == "2000" ? Convert.ToDecimal(Type1Type2[3].Trim()) : 0;
                                        }

                                        if (CassetteMaster2.Length > 0 && Convert.ToInt32(CassetteMaster2) > 0)
                                        {
                                            MCRem100 += CassetteMaster2 == "100" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCRem200 += CassetteMaster2 == "200" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCRem500 += CassetteMaster2 == "500" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                            MCRem2000 += CassetteMaster2 == "2000" ? Convert.ToDecimal(Type1Type2[7].Trim()) : 0;
                                        }

                                        if (CassetteMaster3.Length > 0 && Convert.ToInt32(CassetteMaster3) > 0)
                                        {
                                            MCRem100 += CassetteMaster3 == "100" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCRem200 += CassetteMaster3 == "200" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCRem500 += CassetteMaster3 == "500" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                            MCRem2000 += CassetteMaster3 == "2000" ? Convert.ToDecimal(Type3Type4[3].Trim()) : 0;
                                        }


                                        if (CassetteMaster4.Length > 0 && Convert.ToInt32(CassetteMaster4) > 0)
                                        {
                                            MCRem100 += CassetteMaster4 == "100" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCRem200 += CassetteMaster4 == "200" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCRem500 += CassetteMaster4 == "500" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                            MCRem2000 += CassetteMaster4 == "2000" ? Convert.ToDecimal(Type3Type4[7].Trim()) : 0;
                                        }

                                    }
                                    else if (EJResult.Contains("CASH ADDED"))
                                    {
                                        string[] Type1Type2 = Common.RemoveAdditionalChars(TotalCountArray[k + 1]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                        string[] Type3Type4 = Common.RemoveAdditionalChars(TotalCountArray[k + 2]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();

                                        if (Convert.ToInt32(Type1Type2[3]) > 0 || Convert.ToInt32(Type1Type2[7]) > 0 || Convert.ToInt32(Type3Type4[3]) > 0 || Convert.ToInt32(Type3Type4[7]) > 0)
                                        {
                                            if (CassetteMaster1.Length > 0 && Convert.ToInt32(CassetteMaster1) > 0)
                                            {
                                                Type1 = Regex.Split(Type1Type2[3].Trim(), @"\D+");
                                                if (Type1.Length > 0)
                                                {
                                                    MCClosing100 += CassetteMaster1 == "100" ? Convert.ToDecimal(Type1[0]) : 0;
                                                    MCClosing200 += CassetteMaster1 == "200" ? Convert.ToDecimal(Type1[0]) : 0;
                                                    MCClosing500 += CassetteMaster1 == "500" ? Convert.ToDecimal(Type1[0]) : 0;
                                                    MCClosing2000 += CassetteMaster1 == "2000" ? Convert.ToDecimal(Type1[0]) : 0;
                                                }
                                            }

                                            if (CassetteMaster2.Length > 0 && Convert.ToInt32(CassetteMaster2) > 0)
                                            {
                                                Type2 = Regex.Split(Type1Type2[7].Trim(), @"\D+");
                                                if (Type2.Length > 0)
                                                {
                                                    MCClosing100 += CassetteMaster2 == "100" ? Convert.ToDecimal(Type2[0]) : 0;
                                                    MCClosing200 += CassetteMaster2 == "200" ? Convert.ToDecimal(Type2[0]) : 0;
                                                    MCClosing500 += CassetteMaster2 == "500" ? Convert.ToDecimal(Type2[0]) : 0;
                                                    MCClosing2000 += CassetteMaster2 == "2000" ? Convert.ToDecimal(Type2[0]) : 0;
                                                }
                                            }

                                            if (CassetteMaster3.Length > 0 && Convert.ToInt32(CassetteMaster3) > 0)
                                            {
                                                Type3 = Regex.Split(Type3Type4[3].Trim(), @"\D+");
                                                if (Type3.Length > 0)
                                                {
                                                    MCClosing100 += CassetteMaster3 == "100" ? Convert.ToDecimal(Type3[0]) : 0;
                                                    MCClosing200 += CassetteMaster3 == "200" ? Convert.ToDecimal(Type3[0]) : 0;
                                                    MCClosing500 += CassetteMaster3 == "500" ? Convert.ToDecimal(Type3[0]) : 0;
                                                    MCClosing2000 += CassetteMaster3 == "2000" ? Convert.ToDecimal(Type3[0]) : 0;
                                                }
                                            }


                                            if (CassetteMaster4.Length > 0 && Convert.ToInt32(CassetteMaster4) > 0)
                                            {
                                                Type4 = Regex.Split(Type3Type4[7].Trim(), @"\D+");
                                                if (Type4.Length > 0)
                                                {
                                                    MCClosing100 += CassetteMaster4 == "100" ? Convert.ToDecimal(Type4[0]) : 0;
                                                    MCClosing200 += CassetteMaster4 == "200" ? Convert.ToDecimal(Type4[0]) : 0;
                                                    MCClosing500 += CassetteMaster4 == "500" ? Convert.ToDecimal(Type4[0]) : 0;
                                                    MCClosing2000 += CassetteMaster4 == "2000" ? Convert.ToDecimal(Type4[0]) : 0;
                                                }
                                            }
                                            try
                                            {
                                                CounterDate = DateTime.ParseExact(TotalCountArray[k + 5].Substring(3, 19).Trim(), new string[] { "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyY HH:mm" }, CultureInfo.InvariantCulture);
                                            }
                                            catch
                                            {
                                            }
                                        }
                                    }
                                    //if (line.Contains(" CASSETTE") && CASSETTE_Count == 0)
                                    //{
                                    //    CASSETTE_Count++;

                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Cassette1 = CASSETTE[1].Trim().ToString();
                                    //    Cassette2 = CASSETTE[2].Trim().ToString();
                                    //}
                                    //else if (line.Contains(" CASSETTE") && CASSETTE_Count == 1)
                                    //{
                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Cassette3 = CASSETTE[1].Trim().ToString();
                                    //    Cassette4 = CASSETTE[2].Trim().ToString();
                                    //}

                                    //if (line.Contains("+REJECTED") && RejectCount == 0)
                                    //{
                                    //    RejectCount++;

                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Rejected1 = CASSETTE[1].Trim().ToString();
                                    //    Rejected2 = CASSETTE[2].Trim().ToString();
                                    //}
                                    //else if (line.Contains("+REJECTED") && RejectCount == 1)
                                    //{
                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Rejected3 = CASSETTE[1].Trim().ToString();
                                    //    Rejected4 = CASSETTE[2].Trim().ToString();

                                    //    RETRACTNOTESCOUNT = Convert.ToDecimal(Rejected1) + Convert.ToDecimal(Rejected2) + Convert.ToDecimal(Rejected3) + Convert.ToDecimal(Rejected4);
                                    //}

                                    //if (line.Contains("=REMAINING") && REMAINING_Count == 0)
                                    //{
                                    //    REMAINING_Count++;

                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Remaining1 = CASSETTE[1].Trim().ToString();
                                    //    Remaining2 = CASSETTE[2].Trim().ToString();
                                    //}
                                    //else if (line.Contains("=REMAINING") && REMAINING_Count == 1)
                                    //{
                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Remaining3 = CASSETTE[1].Trim().ToString();
                                    //    Remaining4 = CASSETTE[2].Trim().ToString();
                                    //}
                                    //if (line.Contains("+DISPENSED") && DISPENSED_Count == 0)
                                    //{
                                    //    DISPENSED_Count++;

                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Dispense1 = CASSETTE[1].Trim().ToString();
                                    //    Dispense2 = CASSETTE[2].Trim().ToString();
                                    //}
                                    //else if (line.Contains("+DISPENSED") && DISPENSED_Count == 1)
                                    //{
                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    Dispense3 = CASSETTE[1].Trim().ToString();
                                    //    Dispense4 = CASSETTE[2].Trim().ToString();
                                    //}

                                    //if (line.Contains("=TOTAL") && TOTAL_Count == 0)
                                    //{
                                    //    TOTAL_Count++;

                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    TotalDispense1 = CASSETTE[1].Trim().ToString();
                                    //    TotalDispense2 = CASSETTE[2].Trim().ToString();

                                    //}
                                    //else if (line.Contains("=TOTAL") && TOTAL_Count == 1)
                                    //{
                                    //    CASSETTE = Common.RemoveAdditionalChars(TotalCountArray[k]).Split(' ').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    TotalDispense3 = CASSETTE[1].Trim().ToString();
                                    //    TotalDispense4 = CASSETTE[2].Trim().ToString();
                                    //}

                                    //if (EJResult.Contains("DATE-TIME"))
                                    //{
                                    //    string[] date1 = EJResult.Split('=').Where(x => !string.IsNullOrEmpty(x)).ToArray();
                                    //    CounterDate = DateTime.ParseExact(date1[1].Substring(0, 14).Trim().ToString(), "MM/dd/yy HH:mm", CultureInfo.InvariantCulture);

                                    //}

                                    j = EndIndex;

                                }
                                catch
                                {
                                    j = EndIndex;
                                }
                            }


                            try
                            {

                                _DataTableMCCounter.Rows.Add(
                                    ClientID, TerminalId, CounterDate,
                                    (MCRem100 + MCDis100), (MCRem200 + MCDis200), (MCRem500 + MCDis500), (MCRem2000 + MCDis2000),
                                    ((MCRem100 + MCDis100) * 100) + ((MCRem200 + MCDis200) * 200) + ((MCRem500 + MCDis500) * 500) + ((MCRem2000 + MCDis2000) * 2000),

                                    MCDis100, MCDis200, MCDis500, MCDis2000,
                                    (MCDis100 * 100) + (MCDis200 * 200) + (MCDis500 * 500) + (MCDis2000 * 2000),

                                    MCRem100, MCRem200, MCRem500, MCRem2000,
                                    (MCRem100 * 100) + (MCRem200 * 200) + (MCRem500 * 500) + (MCRem2000 * 2000),

                                    MCClosing100 - MCRem100, MCClosing200 - MCRem200, MCClosing500 - MCRem500, MCClosing2000 - MCRem2000,
                                    ((MCClosing100 - MCRem100) * 100) + ((MCClosing200 - MCRem200) * 200) + ((MCClosing500 - MCRem500) * 500) + ((MCClosing2000 - MCRem2000) * 2000),

                                    MCClosing100, MCClosing200, MCClosing500, MCClosing2000,
                                    (MCClosing100 * 100) + (MCClosing200 * 200) + (MCClosing500 * 500) + (MCClosing2000 * 2000),

                                    RETRACTNOTESCOUNT, string.Empty, FileName, path, FileDate, System.DateTime.Now, UserName);

                            }
                            catch (Exception ex)
                            {
                                DBLog.InsertLogs("Adding machine counter in data table => " + ex.Message, ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

                                // DBLog.InsertLogs(, TerminalId, "SplitterCITIZEN.cs", "ASP_SplitDataMachineCounter", LineNo, FileName, UserName, 'E', _connectionString);
                            }
                        }

                        //MCOp100 = 0;
                        //MCOp200 = 0;
                        //MCOp500 = 0;
                        //MCOp2000 = 0;
                        MCDis100 = 0;
                        MCDis200 = 0;
                        MCDis500 = 0;
                        MCDis2000 = 0;
                        MCRem100 = 0;
                        MCRem200 = 0;
                        MCRem500 = 0;
                        MCRem2000 = 0;
                        MCClosing100 = 0;
                        MCClosing200 = 0;
                        MCClosing500 = 0;
                        MCClosing2000 = 0;
                        RETRACTNOTESCOUNT = 0;

                        Array.Clear(Type1, 0, Type1.Length);
                        Array.Clear(Type2, 0, Type2.Length);
                        Array.Clear(Type3, 0, Type3.Length);
                        Array.Clear(Type4, 0, Type4.Length);

                        //Rejected1 = string.Empty;
                        //Rejected2 = string.Empty;
                        //Rejected3 = string.Empty;
                        //Rejected4 = string.Empty;
                        //Remaining1 = string.Empty;
                        //Remaining2 = string.Empty;
                        //Remaining3 = string.Empty;
                        //Remaining4 = string.Empty;
                        //Dispense1 = string.Empty;
                        //Dispense2 = string.Empty;
                        //Dispense3 = string.Empty;
                        //Dispense4 = string.Empty;

                        //TotalDispense1 = string.Empty;
                        //TotalDispense2 = string.Empty;
                        //TotalDispense3 = string.Empty;
                        //TotalDispense4 = string.Empty;


                    }
                    catch (Exception ex)
                    {
                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }
                }
            }

            if (_DataTableMCCounter.Rows.Count > 0)
            {
                InsertCount = _DataTableMCCounter.Rows.Count;
            }

            return _DataTableMCCounter;
        }

        public DataTable ASP_SplitDataSwitchCounter(string path, string FileName, DataTable dt, out int InsertCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTableSWCounter = new DataTable();
            _DataTableSWCounter.Columns.Add("ClientID", typeof(int));
            _DataTableSWCounter.Columns.Add("TerminalID", typeof(string));
            _DataTableSWCounter.Columns.Add("CurrentEOD", typeof(DateTime));
            _DataTableSWCounter.Columns.Add("SWOp100", typeof(string));
            _DataTableSWCounter.Columns.Add("SWOp200", typeof(string));
            _DataTableSWCounter.Columns.Add("SWOp500", typeof(string));
            _DataTableSWCounter.Columns.Add("SWOp2000", typeof(string));
            _DataTableSWCounter.Columns.Add("SWOpTotal", typeof(string));
            _DataTableSWCounter.Columns.Add("SWDis100", typeof(string));
            _DataTableSWCounter.Columns.Add("SWDis200", typeof(string));
            _DataTableSWCounter.Columns.Add("SWDis500", typeof(string));
            _DataTableSWCounter.Columns.Add("SWDis2000", typeof(string));
            _DataTableSWCounter.Columns.Add("SWDisTotal", typeof(string));
            _DataTableSWCounter.Columns.Add("SWRem100", typeof(string));
            _DataTableSWCounter.Columns.Add("SWRem200", typeof(string));
            _DataTableSWCounter.Columns.Add("SWRem500", typeof(string));
            _DataTableSWCounter.Columns.Add("SWRem2000", typeof(string));
            _DataTableSWCounter.Columns.Add("SWRemTotal", typeof(string));
            _DataTableSWCounter.Columns.Add("SWLoad100", typeof(string));
            _DataTableSWCounter.Columns.Add("SWLoad200", typeof(string));
            _DataTableSWCounter.Columns.Add("SWLoad500", typeof(string));
            _DataTableSWCounter.Columns.Add("SWLoad2000", typeof(string));
            _DataTableSWCounter.Columns.Add("SWLoadTotal", typeof(string));
            _DataTableSWCounter.Columns.Add("SWClosing100", typeof(string));
            _DataTableSWCounter.Columns.Add("SWClosing200", typeof(string));
            _DataTableSWCounter.Columns.Add("SWClosing500", typeof(string));
            _DataTableSWCounter.Columns.Add("SWClosing2000", typeof(string));
            _DataTableSWCounter.Columns.Add("SWClosingTotal", typeof(string));
            _DataTableSWCounter.Columns.Add("Filename", typeof(string));
            _DataTableSWCounter.Columns.Add("FilePath", typeof(string));
            _DataTableSWCounter.Columns.Add("FileDate", typeof(DateTime));
            _DataTableSWCounter.Columns.Add("CreatedON", typeof(DateTime));
            _DataTableSWCounter.Columns.Add("Createdby", typeof(string));

            InsertCount = 0;

            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;


            string SWOp100 = "0";
            string SWOp200 = "0";
            string SWOp500 = "0";
            string SWOp2000 = "0";
            string SWOpTotal = "0";
            string SWDis100 = "0";
            string SWDis200 = "0";
            string SWDis500 = "0";
            string SWDis2000 = "0";
            string SWDisTotal = "0";
            string SWRem100 = "0";
            string SWRem200 = "0";
            string SWRem500 = "0";
            string SWRem2000 = "0";
            string SWRemTotal = "0";
            string SWLoad100 = "0";
            string SWLoad200 = "0";
            string SWLoad500 = "0";
            string SWLoad2000 = "0";
            string SWLoadTotal = "0";
            string SWClosing100 = "0";
            string SWClosing200 = "0";
            string SWClosing500 = "0";
            string SWClosing2000 = "0";
            string SWClosingTotal = "0";
            string LastSWDis100 = "0";
            string LastSWDis200 = "0";
            string LastSWDis500 = "0";
            string LastSWDis2000 = "0";


            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            DateTime? FileDate = null;
            try
            {
                FileDate = DateTime.ParseExact(FileName.Substring(FileName.IndexOf("_") + 1, 8).Trim(), "yyyyMMdd", CultureInfo.InvariantCulture);
            }
            catch (Exception ex)
            {

            }

            string TerminalId = string.Empty;

            DateTime? CounterDate = null;

            string line = string.Empty;
            string EJResult = string.Empty;

            string[] TotalCountArray = File.ReadAllLines(path);

            //if (TotalCountArray != null && TotalCountArray.Length > 0)
            //{
            //    for (int j = 0; j <= TotalCountArray.Length; j++)
            //    {
            //        StartIndex = Common.GetIndex(TotalCountArray, j, "ATM ID");
            //        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "BALANCE");

            //        if (StartIndex != -1 && EndIndex != -1)
            //        {
            //            for (int k = StartIndex; k <= EndIndex - 1; k++)
            //            {
            //                try
            //                {
            //                    line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
            //                    EJResult = Common.RemoveAdditionalChars(line);

            //                    if (EJResult.Contains("ATM ID"))
            //                    {
            //                        TerminalId = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
            //                        if (TerminalId.Length > 0)
            //                        {
            //                            break;
            //                        }
            //                    }
            //                    j = EndIndex;
            //                }
            //                catch
            //                {
            //                    j = EndIndex;
            //                }
            //            }
            //        }

            //        if (TerminalId.Length > 0)
            //        {
            //            break;
            //        }
            //    }
            //}

            string CassetteMaster1 = string.Empty;
            string CassetteMaster2 = string.Empty;
            string CassetteMaster3 = string.Empty;
            string CassetteMaster4 = string.Empty;

            if (TerminalId.Length > 0)
            {
                DataTable dataTable = Common.GetCassetteInfoByTerminalId(_connectionString, ClientID.ToString(), TerminalId);

                if (dataTable != null && dataTable.Rows.Count > 0)
                {
                    CassetteMaster1 = Convert.ToString(dataTable.Rows[0]["Cassette1"]);
                    CassetteMaster2 = Convert.ToString(dataTable.Rows[0]["Cassette2"]);
                    CassetteMaster3 = Convert.ToString(dataTable.Rows[0]["Cassette3"]);
                    CassetteMaster4 = Convert.ToString(dataTable.Rows[0]["Cassette4"]);

                }

                dataTable = null;
            }

            if (TotalCountArray != null && TotalCountArray.Length > 0 && TerminalId.Length > 0)
            {
                for (int j = 0; j <= TotalCountArray.Length; j++)
                {
                    try
                    {
                        StartIndex = Common.GetIndex(TotalCountArray, j, "C1 STR");
                        EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "C4 OUT");

                        if (StartIndex != -1 && EndIndex != -1)
                        {
                            for (int k = StartIndex + 1; k <= EndIndex - 1; k++)
                            {
                                try
                                {
                                    line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                    EJResult = Common.RemoveAdditionalChars(line);

                                    #region Switch Opening
                                    if (EJResult.Contains("C1 STR") && string.IsNullOrEmpty(SWOp100))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 100);
                                                SWOp100 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWOp100 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C2 STR") && string.IsNullOrEmpty(SWOp200))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", ""); ;
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 200);
                                                SWOp200 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWOp200 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C3 STR") && string.IsNullOrEmpty(SWOp500))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 500);
                                                SWOp500 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWOp500 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C4 STR") && string.IsNullOrEmpty(SWOp2000))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 2000);
                                                SWOp2000 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWOp2000 = "0";
                                        }
                                    }
                                    #endregion

                                    #region Switch Loading
                                    if (EJResult.Contains("C1 INC") && (string.IsNullOrEmpty(SWLoad100) || SWLoad100.Equals("0")))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C1", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 100);
                                                SWLoad100 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWLoad100 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C2 INC") && (string.IsNullOrEmpty(SWLoad200) || SWLoad200.Equals("0")))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C2", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 200);
                                                SWLoad200 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWLoad200 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C3 INC") && (string.IsNullOrEmpty(SWLoad500) || SWLoad500.Equals("0")))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C3", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 500);
                                                SWLoad500 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWLoad500 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C4 INC") && (string.IsNullOrEmpty(SWLoad2000) || SWLoad2000.Equals("0")))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C4", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 2000);
                                                SWLoad2000 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWLoad2000 = "0";
                                        }
                                    }

                                    #endregion

                                    #region Switch Dispense &  Switch Remaining

                                    if (EJResult.Contains("C1 OUT") && string.IsNullOrEmpty(SWDis100))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C1", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 100);
                                                SWDis100 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWDis100 = "0";
                                        }

                                        amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 100);
                                                SWRem100 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWRem100 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C2 OUT") && string.IsNullOrEmpty(SWDis200))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C2", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 200);
                                                SWDis200 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWDis200 = "0";
                                        }

                                        amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", ""); ;
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 200);
                                                SWRem200 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWRem200 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C3 OUT") && string.IsNullOrEmpty(SWDis500))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C3", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 500);
                                                SWDis500 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWDis500 = "0";
                                        }


                                        amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 500);
                                                SWRem500 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWRem500 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C4 OUT") && string.IsNullOrEmpty(SWDis2000))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[2].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "").Replace("C4", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 2000);
                                                SWDis2000 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWDis2000 = "0";
                                        }

                                        amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 2000);
                                                SWRem2000 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWRem2000 = "0";
                                        }
                                    }

                                    //if (EJResult.Contains("DIS "))
                                    //{
                                    //    string[] result_DTTime = EJResult.Split(' ');
                                    //    SWDis100 = result_DTTime[1].TrimStart('0');
                                    //    SWDis100 = String.IsNullOrEmpty(SWDis100) ? "0" : SWDis100;
                                    //    SWDis200 = result_DTTime[2].TrimStart('0');
                                    //    SWDis200 = String.IsNullOrEmpty(SWDis200) ? "0" : SWDis200;
                                    //    SWDis500 = result_DTTime[3].TrimStart('0');
                                    //    SWDis500 = String.IsNullOrEmpty(SWDis500) ? "0" : SWDis500;
                                    //    SWDis2000 = result_DTTime[4].TrimStart('0');
                                    //    SWDis2000 = String.IsNullOrEmpty(SWDis2000) ? "0" : SWDis2000;
                                    //}

                                    #endregion



                                    #region Switch Closing
                                    if (EJResult.Contains("C1 END"))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 100);
                                                SWClosing100 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWClosing100 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C2 END"))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 200);
                                                SWClosing200 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWClosing200 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C3 END"))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 500);
                                                SWClosing500 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWClosing500 = "0";
                                        }
                                    }
                                    if (EJResult.Contains("C4 END"))
                                    {
                                        string[] result_DTTime = EJResult.Split(' ');
                                        string amt = result_DTTime[5].ToString().Trim().Replace("RS.", "");
                                        amt = amt.Replace(".00", "");
                                        amt = amt.Replace("(", "");
                                        amt = Regex.Replace(amt.Replace(")", "").Trim(), "[A-Za-z]", "").Replace(".00", "");
                                        if (!string.IsNullOrEmpty(amt.ToString().Trim()))
                                        {
                                            try
                                            {
                                                amt = Convert.ToString(Convert.ToInt64(amt) / 2000);
                                                SWClosing2000 = Convert.ToString(amt);
                                            }
                                            catch
                                            {

                                            }
                                        }
                                        else
                                        {
                                            SWClosing2000 = "0";
                                        }
                                    }


                                    #endregion

                                    j = EndIndex;

                                }
                                catch
                                {
                                    j = EndIndex;
                                }
                            }
                        }

                        #region Storing switch counter in datatable
                        SWRem100 = string.IsNullOrEmpty(SWRem100) ? "0" : SWRem100;
                        SWRem200 = string.IsNullOrEmpty(SWRem200) ? "0" : SWRem200;
                        SWRem500 = string.IsNullOrEmpty(SWRem500) ? "0" : SWRem500;
                        SWRem2000 = string.IsNullOrEmpty(SWRem2000) ? "0" : SWRem2000;
                        SWRemTotal = string.IsNullOrEmpty(SWRemTotal) ? "0" : SWRemTotal;
                        SWLoad100 = string.IsNullOrEmpty(SWLoad100) ? "0" : SWLoad100;
                        SWLoad200 = string.IsNullOrEmpty(SWLoad200) ? "0" : SWLoad200;
                        SWLoad500 = string.IsNullOrEmpty(SWLoad500) ? "0" : SWLoad500;
                        SWLoad2000 = string.IsNullOrEmpty(SWLoad2000) ? "0" : SWLoad2000;
                        SWLoadTotal = string.IsNullOrEmpty(SWLoadTotal) ? "0" : SWLoadTotal;

                        if (Convert.ToDecimal(SWRem100) > 0 || Convert.ToDecimal(SWRem200) > 0 || Convert.ToDecimal(SWRem500) > 0 || Convert.ToDecimal(SWRem2000) > 0 ||
                            Convert.ToDecimal(SWLoad100) > 0 || Convert.ToDecimal(SWLoad200) > 0 || Convert.ToDecimal(SWLoad500) > 0 || Convert.ToDecimal(SWLoad2000) > 0)
                        {
                            SWOp100 = string.IsNullOrEmpty(SWOp100) ? "0" : SWOp100;
                            SWOp200 = string.IsNullOrEmpty(SWOp200) ? "0" : SWOp200;
                            SWOp500 = string.IsNullOrEmpty(SWOp500) ? "0" : SWOp500;
                            SWOp2000 = string.IsNullOrEmpty(SWOp2000) ? "0" : SWOp2000;
                            SWOpTotal = string.IsNullOrEmpty(SWOpTotal) ? "0" : SWOpTotal;
                            SWDis100 = string.IsNullOrEmpty(SWDis100) ? "0" : SWDis100;
                            SWDis200 = string.IsNullOrEmpty(SWDis200) ? "0" : SWDis200;
                            SWDis500 = string.IsNullOrEmpty(SWDis500) ? "0" : SWDis500;
                            SWDis2000 = string.IsNullOrEmpty(SWDis2000) ? "0" : SWDis2000;
                            SWDisTotal = string.IsNullOrEmpty(SWDisTotal) ? "0" : SWDisTotal;
                            SWClosing100 = string.IsNullOrEmpty(SWClosing100) ? "0" : SWClosing100;
                            SWClosing200 = string.IsNullOrEmpty(SWClosing200) ? "0" : SWClosing200;
                            SWClosing500 = string.IsNullOrEmpty(SWClosing500) ? "0" : SWClosing500;
                            SWClosing2000 = string.IsNullOrEmpty(SWClosing2000) ? "0" : SWClosing2000;
                            SWClosingTotal = string.IsNullOrEmpty(SWClosingTotal) ? "0" : SWClosingTotal;

                            _DataTableSWCounter.Rows.Add(
                                //TerminalId, TxnsDateTime,
                                TerminalId, CounterDate,
                                //-- Opening
                                Convert.ToDecimal(SWOp100), Convert.ToDecimal(SWOp200), Convert.ToDecimal(SWOp500), Convert.ToDecimal(SWOp2000),
                                ((Convert.ToDecimal(SWOp100)) * 100) + ((Convert.ToDecimal(SWOp200)) * 200) + ((Convert.ToDecimal(SWOp500)) * 500) + ((Convert.ToDecimal(SWOp2000)) * 2000),
                                //-- Dispense
                                Convert.ToDecimal(SWDis100), Convert.ToDecimal(SWDis200), Convert.ToDecimal(SWDis500), Convert.ToDecimal(SWDis2000),
                                ((Convert.ToDecimal(SWDis100)) * 100) + ((Convert.ToDecimal(SWDis200)) * 200) + ((Convert.ToDecimal(SWDis500)) * 500) + ((Convert.ToDecimal(SWDis2000)) * 2000),
                                //-- Remianing
                                SWRem100, SWRem200, SWRem500, SWRem2000,
                                (Convert.ToDecimal(SWRem100) * 100) + (Convert.ToDecimal(SWRem200) * 200) + (Convert.ToDecimal(SWRem500) * 500) + (Convert.ToDecimal(SWRem2000) * 2000),
                                //-- Loading
                                SWLoad100, SWLoad200, SWLoad500, SWLoad2000,
                                (Convert.ToDecimal(SWLoad100) * 100) + (Convert.ToDecimal(SWLoad200) * 200) + (Convert.ToDecimal(SWLoad500) * 500) + (Convert.ToDecimal(SWLoad2000) * 2000),
                                //-- Closing
                                Convert.ToDecimal(SWClosing100), Convert.ToDecimal(SWClosing200), Convert.ToDecimal(SWClosing500), Convert.ToDecimal(SWClosing2000),
                                ((Convert.ToDecimal(SWClosing100)) * 100) + ((Convert.ToDecimal(SWClosing200)) * 200) +
                                ((Convert.ToDecimal(SWClosing500)) * 500) + ((Convert.ToDecimal(SWClosing2000)) * 2000),

                                System.DateTime.Now, UserName, FileName);
                        }
                        #endregion

                        SWOp100 = "0";
                        SWOp200 = "0";
                        SWOp500 = "0";
                        SWOp2000 = "0";
                        SWOpTotal = "0";
                        SWDis100 = "0";
                        SWDis200 = "0";
                        SWDis500 = "0";
                        SWDis2000 = "0";
                        SWDisTotal = "0";
                        SWRem100 = "0";
                        SWRem200 = "0";
                        SWRem500 = "0";
                        SWRem2000 = "0";
                        SWRemTotal = "0";
                        SWLoad100 = "0";
                        SWLoad200 = "0";
                        SWLoad500 = "0";
                        SWLoad2000 = "0";
                        SWLoadTotal = "0";
                        SWClosing100 = "0";
                        SWClosing200 = "0";
                        SWClosing500 = "0";
                        SWClosing2000 = "0";
                        SWClosingTotal = "0";
                        LastSWDis100 = "0";
                        LastSWDis200 = "0";
                        LastSWDis500 = "0";
                        LastSWDis2000 = "0";
                    }
                    catch (Exception ex)
                    {
                        //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "SplitterCITIZEN.cs", "SplitData", LineNo, FileName, UserName, 'E');
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }
                }
            }

            if (_DataTableSWCounter.Rows.Count > 0)
            {
                InsertCount = _DataTableSWCounter.Rows.Count;
            }

            return _DataTableSWCounter;

        }


        string ExtractNumber(string original)
        {
            return new string(original.Where(c => Char.IsDigit(c) || c == '.').ToArray());
        }

    }
}
