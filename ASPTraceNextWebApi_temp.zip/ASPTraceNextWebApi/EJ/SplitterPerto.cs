﻿using ImportData;
using System;
using System.Data;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Xml;
using Utility;

namespace EJ
{
    public class SplitterPerto
    {
        private readonly string _connectionString;
        BulkImports bulkimports;
        public SplitterPerto(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        public DataTable ASP_SplitData(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTimeConverter objDateTimeConverter = new DateTimeConverter();
            System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("CustAccountNo", typeof(string));
            _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
            _DataTable.Columns.Add("ATMAccountNo", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("Amount2", typeof(decimal));
            _DataTable.Columns.Add("Amount3", typeof(decimal));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
            _DataTable.Columns.Add("ATMBalance", typeof(decimal));
            _DataTable.Columns.Add("BranchCode", typeof(string));
            _DataTable.Columns.Add("TransSEQNumber", typeof(string));
            _DataTable.Columns.Add("OPCode", typeof(string));
            _DataTable.Columns.Add("ResultCode", typeof(string));
            _DataTable.Columns.Add("ErrorCode", typeof(string));
            _DataTable.Columns.Add("TCode", typeof(string));
            _DataTable.Columns.Add("TCode1", typeof(string));
            _DataTable.Columns.Add("FunctionID", typeof(string));
            _DataTable.Columns.Add("Amount", typeof(decimal));
            _DataTable.Columns.Add("Denomination", typeof(string));
            _DataTable.Columns.Add("RequestCount", typeof(string));
            _DataTable.Columns.Add("DispenseCount", typeof(string));
            _DataTable.Columns.Add("RemainCount", typeof(string));
            _DataTable.Columns.Add("PickupCount", typeof(string));
            _DataTable.Columns.Add("RejectCount", typeof(string));
            _DataTable.Columns.Add("Cassette1", typeof(string));
            _DataTable.Columns.Add("Cassette2", typeof(string));
            _DataTable.Columns.Add("Cassette3", typeof(string));
            _DataTable.Columns.Add("Cassette4", typeof(string));
            //_DataTable.Columns.Add("InitAmount", typeof(decimal));
            //_DataTable.Columns.Add("DispAmount", typeof(decimal));
            //_DataTable.Columns.Add("StorAmount", typeof(decimal));
            //_DataTable.Columns.Add("RemAmount", typeof(decimal));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("NoOfDuplicate", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int StartIndex = 0;
            int EndIndex = 0;  

            DataSet ds = new DataSet();

            string LogType = fileImportRequest.ConfigData.Rows[0]["FileName"].ToString();
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = fileImportRequest.ConfigData.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
            string result = string.Empty;

            string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
            fileImportRequest.TotalCount = TotalCountArray.Length;


            // string result1 = ConvertStringArrayToString(TotalCountArray);
            // result = result1.Replace("ATM ID", "|ATM ID").Replace("REF NO", "|REF NO").Replace("DATE", "|DATE").Replace("TIME", "|TIME").Replace("CARD NO", "|CARD NO").Replace("A/C NO", "|A/C NO").Replace("TRANSTYPE", "|TRANSTYPE").Replace("RESP CODE", "|RESP CODE").Replace("WDL AMT", "|WDL AMT").Replace("DISPENSED", "|DISPENSED").Replace("BALANCE", "|BALANCE").Replace("------------------------------------", "|------------------------------------").Replace("|BALANCEENQUIRY", "BALANCEENQUIRY").Replace("a", "|").Replace("AMT", "|AMT").Replace("CRD", "|CRD").Replace("RESP CD", "|RESP CD").Replace("FR A/C#", "|FR A/C#").Trim();//.Replace("500  X", "|500  X").Replace("100  X", "|100  X").Trim();
            //TotalCountArray = result.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
            int totallength = TotalCountArray.Length;

            DateTime TimeStamp = System.DateTime.Now;
            DateTime TimeStamp1 = System.DateTime.Now;
            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            //DateTime? TxnsDateTime;
            //TxnsDateTime = null;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            //string TxnsAmount = "0";
            decimal TxnsAmount = 0;
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            //DateTime? TxnsPostDateTime;
            //TxnsPostDateTime = null;
            string TxnsValueDateTime = string.Empty;
            //DateTime? TxnsValueDateTime;
            //TxnsValueDateTime = null;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string Cassette1 = string.Empty;
            string Cassette2 = string.Empty;
            string Cassette3 = string.Empty;
            string Cassette4 = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string line = string.Empty;
            string line1 = string.Empty;
            string ResponseCode = string.Empty;
            string EJResult = string.Empty;
            string StrDateTime = string.Empty;
            string StrTime = string.Empty;
            string ErrorCode = string.Empty;
            string terminal = string.Empty;
            string TransSeqNo = string.Empty;
            string Opcode = string.Empty;
            string FunctionId = string.Empty;
            string Denomination = string.Empty;
            string ReqCount = string.Empty;
            string DispenseCount = string.Empty;
            string PickupCount = string.Empty;
            string RemainCount = string.Empty;
            string RejectCount = string.Empty;
            string TCode = string.Empty;
            string TCode1 = string.Empty;
            string resultCode = string.Empty;
            string Remark3 = string.Empty;
            string Date = string.Empty;
            string Time = string.Empty;
            string ECardNumber = string.Empty;

            decimal Amount = 0;
            int LineNo1 = 0;
            bool flag = false;
            terminal = fileImportRequest.FileName.Substring(0, 8);
            //int LineNo = 0;
            int ErrorLine = 0;

            
            int ModeID = 0;
            int ChannelID = 0;
            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain  = null;


            string SplitType = ",";

            string[] TerminalCode = fileImportRequest.ConfigData.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BIN_No = fileImportRequest.ConfigData.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] AcquirerIDArray = fileImportRequest.ConfigData.Rows[0]["AcquirerID"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode1Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ReversalCode2Array = fileImportRequest.ConfigData.Rows[0]["ReversalCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ReversalType = fileImportRequest.ConfigData.Rows[0]["ReversalType"].ToString();
            string[] ATMType = fileImportRequest.ConfigData.Rows[0]["ATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CDMType = fileImportRequest.ConfigData.Rows[0]["CDMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] POSType = fileImportRequest.ConfigData.Rows[0]["POSType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ECOMType = fileImportRequest.ConfigData.Rows[0]["ECOMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] IMPType = fileImportRequest.ConfigData.Rows[0]["IMPType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] UPIType = fileImportRequest.ConfigData.Rows[0]["UPIType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MicroATMType = fileImportRequest.ConfigData.Rows[0]["MicroATMType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MobileRechargeType = fileImportRequest.ConfigData.Rows[0]["MobileRechargeType"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] BalanceEnquiry = fileImportRequest.ConfigData.Rows[0]["BalanceEnquiry"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] MiniStatement = fileImportRequest.ConfigData.Rows[0]["MiniStatement"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] PinChange = fileImportRequest.ConfigData.Rows[0]["PinChange"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ChequeBookReq = fileImportRequest.ConfigData.Rows[0]["ChequeBookReq"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string ResponseType = fileImportRequest.ConfigData.Rows[0]["ResponseType"].ToString();
            string[] ResponseCode1Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode1"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] ResponseCode2Array = fileImportRequest.ConfigData.Rows[0]["ResponseCode2"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] OfflineCode = fileImportRequest.ConfigData.Rows[0]["OfflineCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] TxnPostDateTime = fileImportRequest.ConfigData.Rows[0]["TxnPostDateTime"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] DebitCode = fileImportRequest.ConfigData.Rows[0]["DebitCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
            string[] CreditCode = fileImportRequest.ConfigData.Rows[0]["CreditCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);


            bool card = false;
            bool Terminal = false;
            bool Acquirer = false;
            bool Rev1 = false;
            bool Rev2 = false;
            bool ATM = false;
            bool CDM = false;
            bool POS = false;
            bool ECOM = false;
            bool IMPS = false;
            bool UPI = false;
            bool MicroATM = false;
            bool MobileRecharge = false;
            bool BAL = false;
            bool MS = false;
            bool PC = false;
            bool CB = false;
            bool RCA1 = false;
            bool RCA2 = false;
            bool MC = false;
            bool VC = false;
            bool OC = false;
            bool D = false;
            bool C = false;


            int FromRange = 0;
            int ToRange = 0;
            int i = 0;

            string amountstr = string.Empty;
            string Range = string.Empty;

            for (int j = 0; j <= totallength; j++)
            {

                try
                {
                    LineNo = j;
                    StartIndex = Common.GetIndex(TotalCountArray, j, "Transaction start");
                    EndIndex = Common.GetIndex(TotalCountArray, StartIndex + 1, "-------------------------~"); // ------------------------------
                    //TotalCount++;


                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {
                                LineNo++;
                                line = Regex.Replace(TotalCountArray[k].ToString(), "[^ -~]+", string.Empty);
                                EJResult = Common.RemoveAdditionalChars(line);
                                //TotalCount++;
                                //result = Common.RemoveAdditionalChars(TotalCountArray[k].ToString());
                                //string[] EJRequest = result.Split(new string[] { ":" }, StringSplitOptions.None);

                                if (EJResult.Contains("ATM ID") || EJResult.Contains("ATMID"))
                                {
                                    TerminalID = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    //string[] SplitRRn = result.Split(':');
                                    //TerminalID = (SplitRRn[1].Length > 0) ? SplitRRn[1].ToString().Trim() : "";
                                }
                                if (EJResult.Contains("RRN"))
                                {
                                    //string[] SplitRRn = result.Split(':');
                                    //ReferenceNumber = (SplitRRn[1].Length > 0) ? SplitRRn[1].ToString().Trim() : "";

                                    ReferenceNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }
                                if (EJResult.Contains("DATE"))  // || TotalCountArray[k - 1].ToString().Contains("/")
                                {

                                    StrDateTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsDate = StrDateTime;

                                    //string[] SplitRRn = result.Split(' ');

                                    //Date = (SplitRRn[1].Length > 0) ? SplitRRn[1].ToString() : "";


                                    ////TimeStamp = DateTime.ParseExact(Date, "dd:MM:yy", CultureInfo.InvariantCulture);
                                    //TxnsDate = Date.ToString();





                                }
                                if (EJResult.Contains("TIME")) //|| TotalCountArray[k - 1].ToString().Contains("/")
                                {
                                    /*Time = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    StrDateTime = Date + " " + Time;
                                    TxnsTime = StrTime;*/
                                    //string[] SplitRRn = result.Split(' ');
                                    //TxnsTime = (SplitRRn[2].Length > 0) ? SplitRRn[2].ToString() : "";
                                    StrTime = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    TxnsTime = StrTime;
                                    //string Timeout = result;
                                    //TxnsTime = Timeout.Substring(6, 8).Trim();

                                    //TxnsTime = Date + " " + Time;
                                }
                                if (EJResult.Contains("CARD NO"))
                                {
                                    CardNumber = string.Empty;
                                    CardNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    //CardNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();

                                    //string[] Splitcrd = result.Split(':');
                                    //CardNumber = (Splitcrd[1].Length > 0) ? Splitcrd[1].ToString().Trim() : "";
                                }

                                if (EJResult.Contains("ACCT NO") || EJResult.Contains("ACCOUNT NO"))
                                {
                                    // CustAccountNo = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();// Str_Accs[1].ToString().Trim(); 
                                    //string[] Splitcrd = result.Split(':');
                                    CustAccountNo = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    //CustAccountNo = (EJRequest[1].Length > 0) ? EJRequest[1].ToString() : "";
                                }
                                if (EJResult.Contains("CASH WITHDRAWAL"))
                                {
                                    //string[] splitTXN_type = EJResult.Split(':');
                                    TxnsSubType = "Withdrawal";
                                    //TxnsSubType = (EJRequest[1].Length > 0) ? EJRequest[1].ToString() : "";
                                }
                                if (EJResult.Contains("BALANCE INQUIRY"))
                                {
                                    //string[] splitTXN_type = EJResult.Split(':');
                                    TxnsSubType = "BALANCE ENQUIRY";
                                    //TxnsSubType = (EJRequest[1].Length > 0) ? EJRequest[1].ToString() : "";
                                }
                                if (EJResult.Contains("INVALID PIN"))
                                {
                                    //string[] splitTXN_type = EJResult.Split(':');
                                    TxnsSubType = "Pin Change";
                                    //TxnsSubType = (EJRequest[1].Length > 0) ? EJRequest[1].ToString() : "";
                                }
                                if (EJResult.Contains("MINI STATEMENT"))
                                {
                                    //string[] splitTXN_type = EJResult.Split(':');
                                    TxnsSubType = "Mini Statement";
                                    //TxnsSubType = (EJRequest[1].Length > 0) ? EJRequest[1].ToString() : "";
                                }
                                if (EJResult.Contains("ACCOUNT FUNDS INSUFFICIENT"))
                                {
                                    //string[] splitTXN_type = EJResult.Split(':');
                                    TxnsSubType = "Insufficient Balance";
                                    //TxnsSubType = (EJRequest[1].Length > 0) ? EJRequest[1].ToString() : "";
                                }
                                if (EJResult.Contains("TXN NO"))
                                {
                                    TxnsNumber = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                    //string[] SplitRRn = result.Split(':');
                                    //TxnsNumber = (SplitRRn[1].Length > 0) ? SplitRRn[1].ToString().Trim() : "";
                                }

                                if (EJResult.Contains("RESP CODE") || EJResult.Contains("RESPONSE CODE"))
                                {
                                    ResponseCode = EJResult.Substring(EJResult.IndexOf(":") + 1).Trim();
                                }

                                //if (EJResult.Contains("RESP CODE") || EJResult.Contains("RESPONSE CODE"))
                                //{
                                //    string[] SplitRRn = result.Split(':');
                                //    ResponseCode = (SplitRRn[1].Length > 0) ? SplitRRn[1].ToString().Trim() : "";
                                //    /* string error = TotalCountArray[k + 1].ToString();
                                //     if (!error.Contains("TRANS AMOUNT") && TxnsSubType == "CASH WITHDRAWAL")
                                //     {
                                //         ErrorCode = error;
                                //     }*/
                                //}
                                //if (EJResult.Contains("DENOMINATION"))
                                //{
                                //    Denomination = EJResult.Substring(EJResult.IndexOf(" ")).Trim();
                                //}

                                //if (EJResult.Contains("REQUEST COUNT"))
                                //{
                                //    ReqCount = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                //}

                                //if (EJResult.Contains("DISPENSE COUNT"))
                                //{
                                //    DispenseCount = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                //}

                                //if (EJResult.Contains("REMAIN COUNT"))
                                //{
                                //    RemainCount = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                //}

                                //if (EJResult.Contains("PICKUP COUNT"))
                                //{
                                //    PickupCount = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                //}

                                //if (EJResult.Contains("REJECT COUNT"))
                                //{
                                //    RejectCount = EJResult.Substring(EJResult.IndexOf("[")).Trim();
                                //}
                                //if (EJResult.Contains("DISPENSED"))
                                //{
                                //    string[] Dis = EJResult.Split(' ');
                                //    DispenseCount = Dis[1] + "," + Dis[2] + "," + Dis[3] + "," + Dis[4];
                                //    //DispenseCount = EJResult.Substring(EJResult.IndexOf(" ")).Trim();
                                //}

                                //if (EJResult.Contains("REMAINING"))
                                //{
                                //    string[] Rem = EJResult.Split(' ');
                                //    RemainCount = Rem[1] + "," + Rem[2] + "," + Rem[3] + "," + Rem[4];
                                //}


                                //if (EJResult.Contains("REJECTED"))
                                //{
                                //    string[] Rem = EJResult.Split(' ');
                                //    RejectCount = Rem[1] + "," + Rem[2] + "," + Rem[3] + "," + Rem[4];
                                //}

                                //if (EJResult.Contains("NOTES PRESENTED"))
                                //{
                                //    string[] Note = EJResult.Split(' ');
                                //    string[] Notes = Note[4].Split(',');

                                //    Cassette1 = Notes[0];
                                //    Cassette2 = Notes[1];
                                //    Cassette3 = Notes[2];
                                //    Cassette4 = Notes[3];
                                //}

                                if (EJResult.Contains("REQUESTED AMT"))
                                {
                                    amountstr = EJResult.Substring(EJResult.IndexOf("=") + 1).Trim();
                                    TxnsAmount = Convert.ToDecimal(amountstr);

                                    //string[] resp = result.Split('=');
                                    //string Rupees = (resp[1].Length > 0) ? resp[1].ToString().Trim() : "";
                                    //TxnsAmount = Convert.ToDecimal(Rupees);
                                }

                                //else if (result.Contains("BALANCE") && !result.Contains("BALANCEENQUIRY"))
                                //{

                                //    string[] resp = result.Split(':');
                                //    ATMBalance = (resp[1].Length > 0) ? resp[1].ToString() : "";


                                //}

                                j = EndIndex;
                            }
                            catch  
                            {
                                j = EndIndex;
                            }
                        }
                    }


                    #region StanderedFields
                    SplitType = ",";
                    ModeID = 0;
                    ChannelID = 0;
                    ReversalFlag = false;
                    TxnsStatus = string.Empty;
                    DebitCreditType = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    CardType = string.Empty; 
                    TxnsDateTimeMain = null; 
                    TxnsPostDateTimeMain = null;

                   
                    card = false;
                    Terminal = false;
                    Acquirer = false;
                    Rev1 = false;
                    Rev2 = false;
                    ATM = false;
                    CDM = false;
                    POS = false;
                    ECOM = false;
                    IMPS = false;
                    UPI = false;
                    MicroATM = false;
                    MobileRecharge = false;
                    BAL = false;
                    MS = false;
                    PC = false;
                    CB = false;
                    RCA1 = false;
                    RCA2 = false;
                    MC = false;
                    VC = false;
                    OC = false;
                    D = false;
                    C = false;

                    #region ValidateField

                    if (TxnsDate != "" && TxnsTime != "")
                    {
                        //string temp = TxnsDate + " " + TxnsTime;
                        //TxnsDateTimeMain = Convert.ToDateTime(temp);
                        
                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + " " + TxnsTime, "dd:MM:yy HH:mm:ss", CultureInfo.InvariantCulture);
                        //TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + TxnsTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);
                    }

                    if (TxnDateTime[0].ToString() != "" && TxnsDateTime != "")
                    {

                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime[0].ToString(), CultureInfo.InvariantCulture);

                    }


                    if (TxnPostDateTime[0].ToString() != "" && TxnsPostDateTime != "")
                    {
                        for (i = 0; i < TxnPostDateTime.Length; i++)
                        {
                            if (TxnsPostDateTime.Contains("/") || TxnsPostDateTime.Contains(".") || TxnsPostDateTime.Contains("-"))
                            {
                                TxnsPostDateTimeMain = objDateTimeConverter.ConvertToDateTime(TxnPostDateTime[i].ToString(), TxnsPostDateTime);
                            }
                            else
                            {
                                TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnsPostDateTime[i].ToString(), CultureInfo.InvariantCulture);
                            }
                        }
                    }

                    if (TerminalCode[0].ToString() != "" && TerminalID != "")
                    {
                        for (i = 0; i < TerminalCode.Length; i++)
                        {
                            if (TerminalID.StartsWith(TerminalCode[i].ToString()))
                            {
                                Terminal = true;
                            }
                        }
                    }


                    if (AcquirerIDArray[0].ToString() != "" && AcquirerID != "")
                    {
                        for (i = 0; i < AcquirerIDArray.Length; i++)
                        {
                            if (AcquirerIDArray[i].ToString() == AcquirerID)
                            {
                                Acquirer = true;
                            }
                        }
                    }

                    if (BIN_No[0].ToString() != "" && CardNumber != "")
                    {
                        for (i = 0; i < BIN_No.Length; i++)
                        {
                            if (BIN_No[i].ToString() == CardNumber.Substring(0, 6))
                            {
                                card = true;
                            }
                        }
                    }



                    if (ReversalType == "1" && ReversalCode1Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                    }
                    if (ReversalType == "2" && ReversalCode1Array[0].ToString() != "" && ReversalCode2Array[0].ToString() != "" && ReversalCode1 != "")
                    {
                        for (i = 0; i < ReversalCode1Array.Length; i++)
                        {
                            if (ReversalCode1Array[i].ToString() == ReversalCode1)
                            {
                                Rev1 = true;
                            }
                        }
                        for (i = 0; i < ReversalCode2Array.Length; i++)
                        {
                            if (ReversalCode2Array[i].ToString() == ReversalCode2)
                            {
                                Rev2 = true;
                            }
                        }
                    }




                    if (ChannelType == "" && TxnsSubType != "")
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == TxnsSubType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == TxnsSubType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == TxnsSubType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == TxnsSubType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == TxnsSubType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == TxnsSubType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == TxnsSubType)
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == TxnsSubType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }
                    else
                    {

                        if (CDMType[0].ToString() != "")
                        {
                            for (i = 0; i < CDMType.Length; i++)
                            {
                                if (CDMType[i].ToString() == ChannelType)
                                {
                                    CDM = true;
                                }
                            }
                        }

                        if (ATMType[0].ToString() != "")
                        {
                            for (i = 0; i < ATMType.Length; i++)
                            {
                                if (ATMType[i].ToString() == ChannelType)
                                {
                                    ATM = true;
                                }
                            }
                        }

                        if (POSType[0].ToString() != "")
                        {
                            for (i = 0; i < POSType.Length; i++)
                            {
                                if (POSType[i].ToString() == ChannelType)
                                {
                                    POS = true;
                                }
                            }
                        }
                        if (ECOMType[0].ToString() != "")
                        {
                            for (i = 0; i < ECOMType.Length; i++)
                            {
                                if (ECOMType[i].ToString() == ChannelType)
                                {
                                    ECOM = true;
                                }
                            }
                        }

                        if (IMPType[0].ToString() != "")
                        {
                            for (i = 0; i < IMPType.Length; i++)
                            {
                                if (IMPType[i].ToString() == ChannelType)
                                {
                                    IMPS = true;
                                }
                            }
                        }

                        if (UPIType[0].ToString() != "")
                        {
                            for (i = 0; i < UPIType.Length; i++)
                            {
                                if (UPIType[i].ToString() == ChannelType)
                                {
                                    UPI = true;
                                }
                            }
                        }

                        if (MicroATMType[0].ToString() != "")
                        {
                            for (i = 0; i < MicroATMType.Length; i++)
                            {
                                if (MicroATMType[i].ToString() == ChannelType)
                                {
                                    MicroATM = true;
                                }
                            }
                        }

                        if (MobileRechargeType[0].ToString() != "")
                        {
                            for (i = 0; i < MobileRechargeType.Length; i++)
                            {
                                if (MobileRechargeType[i].ToString() == ChannelType)
                                {
                                    MobileRecharge = true;
                                }
                            }
                        }
                    }


                    if (BalanceEnquiry[0].ToString() != "")
                    {
                        for (i = 0; i < BalanceEnquiry.Length; i++)
                        {
                            if (BalanceEnquiry[i].ToString() == TxnsSubType)
                            {
                                BAL = true;
                            }
                        }
                    }

                    if (MiniStatement[0].ToString() != "")
                    {
                        for (i = 0; i < MiniStatement.Length; i++)
                        {
                            if (MiniStatement[i].ToString() == TxnsSubType)
                            {
                                MS = true;
                            }
                        }
                    }

                    if (PinChange[0].ToString() != "")
                    {
                        for (i = 0; i < PinChange.Length; i++)
                        {
                            if (PinChange[i].ToString() == TxnsSubType)
                            {
                                PC = true;
                            }
                        }
                    }

                    if (ChequeBookReq[0].ToString() != "")
                    {
                        for (i = 0; i < ChequeBookReq.Length; i++)
                        {
                            if (ChequeBookReq[i].ToString() == TxnsSubType)
                            {
                                CB = true;
                            }
                        }
                    }

                    if (ResponseType == "1" && ResponseCode1Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                            }
                        }
                    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() != "" && ResponseCode2Array[0].ToString() != "" && ResponseCode != "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode)
                            {
                                RCA1 = true;
                            }
                        }

                        for (i = 0; i < ResponseCode2Array.Length; i++)
                        {
                            if (ResponseCode2Array[i].ToString() == ResponseCode)
                            {
                                RCA2 = true;
                            }
                        }
                    }

                    //if (ResponseCode1Array[0].ToString() == "")
                    //    {
                    //    RCA1 = true;
                    //    }
                    if (ResponseType == "2" && ResponseCode1Array[0].ToString() == "")
                    {
                        for (i = 0; i < ResponseCode1Array.Length; i++)
                        {
                            if (ResponseCode1Array[i].ToString() == ResponseCode1)
                            {
                                RCA1 = true;
                            }
                        }
                    } 
                     

                    if (DebitCode[0].ToString() != "")
                    {
                        for (i = 0; i < DebitCode.Length; i++)
                        {
                            if (DebitCode[i].ToString() == DrCrType)
                            {
                                D = true;
                            }
                        }
                    }

                    if (CreditCode[0].ToString() != "")
                    {
                        for (i = 0; i < CreditCode.Length; i++)
                        {
                            if (CreditCode[i].ToString() == DrCrType)
                            {
                                C = true;
                            }
                        }
                    }


                    /*
                    if (VISACode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < VISACode.Length; i++)
                            {
                            if (VISACode[i].ToString() == CardNumber.Substring(0,1))
                                {
                                CardType = "VISA";
                                }
                            }
                        }

                    if (MasterCode[0].ToString() != "" && CardNumber != "")
                        {
                        for (i = 0; i < MasterCode.Length; i++)
                            {
                            if (MasterCode[i].ToString() == CardNumber.Substring(0, 2))
                                {
                                CardType = "MASTER";
                                }
                            }
                        }

                        */

                    #endregion ValidateField

                    #region InitilizedField

                    if (AcquirerID == string.Empty || AcquirerID == "")
                    {
                        if (Terminal == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Terminal == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Terminal == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }
                    }
                    else
                    {
                        if (Acquirer == true && card == true)
                        {
                            ModeID = (int)TxnsMode.ONUS;
                        }
                        if (Acquirer == true && card == false)
                        {
                            ModeID = (int)TxnsMode.ACQUIRER;
                        }
                        if (Acquirer == false && card == true)
                        {
                            ModeID = (int)TxnsMode.ISSUER;
                        }

                    }

                    if (Rev1 == true || Rev1 == true && Rev2 == true)
                    {
                        ReversalFlag = true;
                    }
                    else
                    {
                        ReversalFlag = false;
                    }

                    if (ATM)
                    {
                        TxnsSubTypeMain = "Withdrawal";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (CDM)
                    {
                        TxnsSubTypeMain = "Deposit";
                        ChannelID = (int)TxnsChannelID.ATM;
                    }

                    if (POS)
                    {
                        ChannelID = (int)TxnsChannelID.POS;
                        TxnsSubTypeMain = "Purchase";
                    }

                    if (ECOM)
                    {
                        ChannelID = (int)TxnsChannelID.E_COMMERCE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (IMPS)
                    {
                        ChannelID = (int)TxnsChannelID.IMPS;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (MicroATM)
                    {
                        ChannelID = (int)TxnsChannelID.MICRO_ATM;
                        TxnsSubTypeMain = "Withdrawal";
                    }

                    if (MobileRecharge)
                    {
                        ChannelID = (int)TxnsChannelID.MOBILE_RECHARGE;
                        TxnsSubTypeMain = "Transfer";
                    }

                    if (UPI)
                    {
                        ChannelID = (int)TxnsChannelID.UPI;
                        TxnsSubTypeMain = "Transfer";
                    }
                    if (RCA1 == true || RCA2 == true)
                    {
                        ResponseCode = "00";
                        TxnsStatus = "Sucessfull";
                    }
                    else
                    { 
                        TxnsStatus = "Unsucessfull";
                    }


                    //if (RCA1 == true  || RCA1 == true && RCA2 == false)
                    //    {
                    //    ResponseCode = "00";
                    //    TxnsStatus = "Sucessfull";
                    //    }
                    //else
                    //    {
                    //    ResponseCode = ResponseCode1;
                    //    TxnsStatus = "Unsucessfull";
                    //    }

                    if (BAL)
                    {
                        TxnsSubTypeMain = "Balance enquiry";
                    }

                    if (MS)
                    {
                        TxnsSubTypeMain = "Mini statement";
                    }

                    if (PC)
                    {
                        TxnsSubTypeMain = "Pin change";
                    }

                    if (CB)
                    {
                        TxnsSubTypeMain = "Cheque book request";
                    }


                    if (BAL || MS || PC || CB)
                    {
                        TxnsType = "Non-Financial";
                    }
                    else
                    {
                        TxnsType = "Financial";
                    }
                    if (OC)
                    {
                        TxnsEntryType = "Manual";
                    }
                    else
                    {
                        TxnsEntryType = "Auto";
                    }
                    if (D)
                    {
                        DebitCreditType = "D";
                    }

                    if (C)
                    {
                        DebitCreditType = "C";
                    }

                    #endregion InitilizedField


                    #endregion StanderedFields

                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }

                    if (CardNumber != "")
                    { 
                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);

                    }

                    if (TxnsDateTimeMain != null && ReferenceNumber != "")
                    {
                        _DataTable.Rows.Add(ClientID
                                        , (int)TxnsChannelID.ATM
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , CardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , InterchangeAccountNo
                                        , ATMAccountNo
                                        , TxnsDateTimeMain
                                        , Convert.ToDecimal(TxnsAmount)
                                        , Convert.ToDecimal(Amount1)
                                        , Convert.ToDecimal(Amount2)
                                        , Convert.ToDecimal(Amount3)
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubTypeMain
                                        , TxnsEntryType
                                        , TxnsNumber
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , ReversalFlag
                                        , TxnsPostDateTimeMain
                                        , TxnsPostDateTimeMain
                                        , AuthCode
                                        , ProcessingCode
                                        , Convert.ToDecimal(FeeAmount)
                                        , CurrencyCode
                                        , Convert.ToDecimal(CustBalance)
                                        , Convert.ToDecimal(InterchangeBalance)
                                        , Convert.ToDecimal(ATMBalance)
                                        , BranchCode
                                        , TransSeqNo
                                        , Opcode
                                        , resultCode
                                        , ErrorCode
                                        , TCode
                                        , TCode1
                                        , FunctionId
                                        , Amount
                                        , Denomination
                                        , ReqCount
                                        , DispenseCount
                                        , RemainCount
                                        , PickupCount
                                        , RejectCount
                                        , Cassette1
                                        , Cassette2
                                        , Cassette3
                                        , Cassette4
                                        , ReserveField1
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , RevEntryLeg
                                        , 0
                                        , fileImportRequest.FileName
                                        , fileImportRequest.Path
                                        , null
                                        , DateTime.Now
                                        , DateTime.Now
                                        , fileImportRequest.UserName
                                        , ""
                                        , ECardNumber
                                        );


                    }

                    TerminalID = string.Empty;
                    AcquirerID = string.Empty;
                    ReferenceNumber = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    InterchangeAccountNo = string.Empty;
                    ATMAccountNo = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsDate = string.Empty;
                    TxnsTime = string.Empty;
                    TxnsAmount = 0;
                    Amount1 = "0";
                    Amount2 = "0";
                    Amount3 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsNumber = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;
                    TxnsPostDateTime = string.Empty;
                    TxnsValueDateTime = string.Empty;
                    AuthCode = string.Empty;
                    ProcessingCode = string.Empty;
                    FeeAmount = "0";
                    CurrencyCode = string.Empty;
                    CustBalance = "0";
                    InterchangeBalance = "0";
                    ATMBalance = "0";
                    BranchCode = string.Empty;
                    Cassette1 = string.Empty;
                    Cassette2 = string.Empty;
                    Cassette3 = string.Empty;
                    Cassette4 = string.Empty;
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    ResponseCode = string.Empty;
                    EJResult = string.Empty;
                    StrDateTime = string.Empty;
                    StrTime = string.Empty;
                    ErrorCode = string.Empty;
                    terminal = string.Empty;
                    TransSeqNo = string.Empty;
                    Opcode = string.Empty;
                    FunctionId = string.Empty;
                    Denomination = string.Empty;
                    ReqCount = string.Empty;
                    DispenseCount = string.Empty;
                    PickupCount = string.Empty;
                    RemainCount = string.Empty;
                    RejectCount = string.Empty;
                    TCode = string.Empty;
                    TCode1 = string.Empty;
                    resultCode = string.Empty;
                    Remark3 = string.Empty;
                    ECardNumber = string.Empty;
                    CardType = string.Empty;

                    TxnsStatus = string.Empty;
                    TxnsType = string.Empty;
                    TxnsSubTypeMain = string.Empty;
                    TxnsEntryType = string.Empty;
                    DebitCreditType = string.Empty;


                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }


            }
            if (_DataTable.Rows.Count > 0)
            {
                fileImportRequest.InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;
        }

    }
}
