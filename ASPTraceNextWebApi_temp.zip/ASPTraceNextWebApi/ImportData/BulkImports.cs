﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Utility;
using Newtonsoft.Json;
using System.Globalization;
using System.Net.Sockets;
using System.Net;
namespace ImportData
{
    public  class BulkImports
    {
        private readonly string _MekKey1;
        private readonly string _MekKey2;
        private readonly string _connectionString;
        public BulkImports(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            _MekKey1 = MekKey1;
            _MekKey2 = MekKey2;
        }

        public DataTable GetDynamicFieldDetailsById(string ClientID, string FormatID)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandText = "uspGetDynamicFieldDetailsByFormatId";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.BigInt).Value = ClientID;
                        cmd.Parameters.AddWithValue("@FormatID", SqlDbType.BigInt).Value = FormatID;

                        connExcel.Open();
                        da.SelectCommand = cmd;
                        da.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }


        public DataTable GetFileTypeFormatById(string ClientID, string FormatID)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandText = "UspGetFileTypeByFormatId_Core";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.BigInt).Value = ClientID;
                        cmd.Parameters.AddWithValue("@FormatID", SqlDbType.BigInt).Value = FormatID;

                        connExcel.Open();
                        da.SelectCommand = cmd;
                        da.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }

        //get batch Details
        public List<BatchDetails> GetStartBatchPosition(string FileName, int ClientID, int ChannelID, int ModeID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("GetBatchDetails", connExcel))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 1000000;
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@ClienID", ClientID);
                        cmd.Parameters.AddWithValue("@ChannelID", ChannelID);
                        cmd.Parameters.AddWithValue("@ModeID", ModeID);

                        connExcel.Open();
                        object result = cmd.ExecuteScalar();

                        // Convert the result (JSON string) to a List of BatchDetails
                        if (result != null)
                        {
                            string jsonString = Convert.ToString(result);
                            List<BatchDetails> allBatches = JsonConvert.DeserializeObject<List<BatchDetails>>(jsonString);
                            return allBatches;
                        }
                        else
                        {
                            return new List<BatchDetails>();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return new List<BatchDetails>();
            }
        }

        //Batch Processing
        public int GetBatchSize(string ConfigID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 10000;
                        cmd.CommandText = "spGetBatchSize";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);

                        connExcel.Open();

                        object result = cmd.ExecuteScalar();
                        return result != null ? Convert.ToInt32(result) : 100000;
                    }
                }
            }
            catch (Exception ex)
            {
                return 10000;
            }
        }

        //Get Table name For UPI Switch
        public static string GetDynamicTableName(string connectionString, int ClientID, int ChannelId, int ModeID, int logtype)
        {
            string tableName = string.Empty;

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand("GetTableName", connExcel))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Adding parameters to the command
                    cmd.Parameters.AddWithValue("@ClientID", ClientID);
                    cmd.Parameters.AddWithValue("@ChannelID", ChannelId);
                    cmd.Parameters.AddWithValue("@ModeID", ModeID);
                    cmd.Parameters.AddWithValue("@logType", logtype);

                    // Open the connection
                    connExcel.Open();

                    // Execute the command and get the result as a string
                    object result = cmd.ExecuteScalar();

                    // Check if result is not null and assign to tableName
                    if (result != null)
                    {
                        tableName = result.ToString();
                    }
                }
            }

            return tableName;
        }

        //Get DateTime Format
        public DtDetails GetdetailsFromDataTable(DataTable d, string FileName)
        {

            DtDetails details = new DtDetails();
            string dateFile = string.Empty;
            string FileDateFormat = d.Rows[0]["FileDateFormat"].ToString();
            // details.ConfigID = Convert.ToString(d.Rows[0]["ConfigID"]);

            if (Convert.ToString(d.Rows[0]["ConfigID"]) == null)
            {
                details.ConfigID = "0";
            }
            else
            {
                details.ConfigID = Convert.ToString(d.Rows[0]["ConfigID"]);
            }

            if (FileDateFormat.Length > 0)
            {
                dateFile = new string(FileName.Where(c => Char.IsDigit(c)).ToArray());

                if (details.ConfigID == "112")
                {
                    string[] parts = FileName.Split('_');
                     dateFile = parts[1];
                    if (dateFile.Length >= FileDateFormat.Length)
                    {
                        dateFile = dateFile.Substring(0, FileDateFormat.Length);
                    }
                   // dateFile =dateWithTime.Substring(0, 8);
                }
                else if(details.ConfigID == "207" || details.ConfigID == "210")
                {
                    dateFile = dateFile.Substring(dateFile.Length - FileDateFormat.Length); 
                }
                else
                {
                    if (dateFile.Length >= FileDateFormat.Length)
                    {
                        dateFile = dateFile.Substring(0, FileDateFormat.Length);
                    }
                }
                try
                {
                    details.FileDateTime = DateTime.ParseExact(dateFile, FileDateFormat, CultureInfo.InvariantCulture);
                }
                catch (Exception ex)
                {
                    details.FileDateTime = DateTime.Now;
                }

            }
            else
            {
                details.FileDateTime = DateTime.Now;
            }
            return details;
        }
        //GL 
        public string BulkInsertCBSTable(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertCBSData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@CBS", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID); 
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        //GL UP
        public string BulkInsertCBSTableUPI(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertCBSDataUPI";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@CBS", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }


        //Switch
        public string BulkInsertSWITCHTableUPI(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertSWITCHDataUPI";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@SWITCH", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);

                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                //InsertLogs(ex.Message.ToString(), "56", "DynamicImportLogsRepository.cs", "BulkInsertSWITCHTableUPI", 0, FileName, UserName, 'E', _connectionString);
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertSWITCHTable(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertSWITCHData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@SWITCH", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        //Network

        #region UPI 
        //UPI
        public string BulkInsertIssuerDataUPITable(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertUPIIssuerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID); 
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertAcquirerDataUPITable(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertUPIAcquirerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertSettlementDataUPI(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertUPISettlementData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertNPCIAdjustmentUPI(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertNPCIAdjustmentUPI";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        #endregion UPI

        #region IMPS
        //IMPS

        public string BulkInsertIssuerDataIMPS(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertIMPSIssuerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID); 
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertAcquirerDataIMPS(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertIMPSAcquirerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertNPCIAdjustmentIMPS(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertNPCIAdjustmentIMPS";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertSettlementDataIMPS(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertIMPSSettlementData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }
        #endregion IMPS

        #region POS
        //POS
        public string BulkInsertIssuerDataPOS(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertPOSIssuerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        #endregion POS

        #region ATM

        //ATM
        public string BulkInsertAcquirerDataATM(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertATMAcquirerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }


        public string BulkInsertIssuerDataATM(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertATMIssuerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertNPCIAdjustmentATM(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertNPCIAdjustmentATM";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertSettlementDataATM(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertATMSettlementData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID ", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        #endregion ATM

        #region AEPS

        //AEPS
        public string BulkInsertAcquirerDataAEPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspDynamicBulkInsertAEPSAcquirerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileDate", FileDate);
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@FilePath", FilePath);
                        cmd.Parameters.AddWithValue("@CreatedBy", UserName);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertIssuerDataAEPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspDynamicBulkInsertAEPSIssuerData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileDate", FileDate);
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@FilePath", FilePath);
                        cmd.Parameters.AddWithValue("@CreatedBy", UserName);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertSettlementDataAEPS(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertAEPSSettlementData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileDate", FileDate);
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@FilePath", FilePath);
                        cmd.Parameters.AddWithValue("@CreatedBy", UserName);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        #endregion AEPS


        public string BulkInsertGLAdjustmentALL(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "spBulkInsertGLDataAdjustment";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@GLAdjustment", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);   
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID); 
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }
        public string BulkInsertIMPSUPITimeOutData(DataTable __DataTable, string ConfigID, DateTime? FileDate, string FilePath, string FileName, string UserName)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertNPCIIMPSUPITimeOutData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileDate", FileDate);
                        cmd.Parameters.AddWithValue("@FileName", FileName);
                        cmd.Parameters.AddWithValue("@FilePath", FilePath);
                        cmd.Parameters.AddWithValue("@CreatedBy", UserName);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public DataTable VerifyIMPSUPITimeOutData(DataTable __DataTable, string ClientID, string ChannelId, out string Message)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            Message = string.Empty;
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspCheckNPCIIMPSUPITimeOutData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ClientID", ClientID);
                        cmd.Parameters.AddWithValue("@ChannelId", ChannelId);
                        using (System.Data.SqlClient.SqlDataAdapter sda = new System.Data.SqlClient.SqlDataAdapter(cmd))
                        {
                            sda.Fill(dt);
                        }
                        Message = "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return null;
            }

            return dt;
        }

        public string NPCIBillingSummarryDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 10000000;
                        cmd.CommandText = "spBulkInsertNPCIBillingSummarry";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NPCIBilling_USER", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string InterchangeSummarryDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 10000000;
                        cmd.CommandText = "spBulkInsertInterchangeSummarry";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Interchange_USER", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string NetSettlementDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 10000000;
                        cmd.CommandText = "spBulkInsertNetSettlementSummarry";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NetSettlement_USER", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string DSRSummarryDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 100000000;
                        cmd.CommandText = "spBulkInsertDSRSummarry";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@DSRSummary_USER", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }
        public string PresentmentDataTable(DataTable __DataTable)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 10000000;
                        cmd.CommandText = "spBulkInsertPresentmentData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@tblPresentmentData", __DataTable);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertUPIDebitReversal(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertNPCIUPIDebitReversal";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertRefundlogs(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertPosRefundlog";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }

        public string BulkInsertlateReversalATM(DataTable __DataTable, string ConfigID, string FileImportID)
        {
            try
            {
                using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(_connectionString))
                {
                    using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                    {
                        cmd.Connection = connExcel;
                        cmd.CommandTimeout = 1000000;
                        cmd.CommandText = "uspBulkInsertATMLateReversalData";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@NETWORK", __DataTable);
                        cmd.Parameters.AddWithValue("@ConfigID", ConfigID);
                        cmd.Parameters.AddWithValue("@FileImportID", FileImportID);
                        connExcel.Open();
                        cmd.ExecuteNonQuery();
                        connExcel.Close();
                        return "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                return "An error occurred during the bulk insert process;\n" + ex.Message;
            }
        }


        //Get Local IP Address
        public string GetLocalIPAddress()
        {
            string localIP = string.Empty;

            try
            {
                var host = Dns.GetHostEntry(Dns.GetHostName());

                foreach (var ip in host.AddressList)
                {
                    // Check for IPv4 address and exclude loopback address
                    if (ip.AddressFamily == AddressFamily.InterNetwork)
                    {
                        localIP = ip.ToString();
                        break;
                    }
                }

                if (string.IsNullOrEmpty(localIP))
                {
                    throw new Exception("No IPv4 address found for the machine.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            return localIP;
        }
    }
}
