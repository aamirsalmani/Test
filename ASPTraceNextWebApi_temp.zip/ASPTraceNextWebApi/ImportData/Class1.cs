﻿using Utility;

namespace ImportData
{
    public class FileImportRequest
    {
        public string Path { get; set; }
        public string FileName { get; set; }
        public System.Data.DataTable ConfigData { get; set; }

        public DateTime? FileDateTime { get; set; }
        public string UserName { get; set; }
        public string ClientCode { get; set; }
        public string FileImportID { get; set; }

        // Output values
        public int InsertCount { get; set; }
        public int TotalCount { get; set; }
        public string ErrorMessage { get; set; }
        public string FinalBatchDetails { get; set; }
        public int SkippedRows { get; set; }
        public List<BatchDetails> FailedBatches { get; set; }
    }
}
