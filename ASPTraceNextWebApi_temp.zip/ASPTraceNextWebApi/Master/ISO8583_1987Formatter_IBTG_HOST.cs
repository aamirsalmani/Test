﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Master
{
    public enum ResponseCodesEnum : int
    {
        UnableToProcess = -1,                // 05 - Unable to process 
        TransactionApproved = 0,             // 00 - Transaction approved
        ReferToCardIssuer = 1,               // 02 - Refer to card issuer 
        DoNotHonour = 2,                     // 04 - Do not honour 
        Timeout = 3,                         // 08 - Timeout 
        DuplicateTransaction = 4,            // 09 - Duplicate Transaction
        UnableToReverse = 5,                 // 10 - Unable to reverse 
        LowDispenserOut = 6,                 // 11 - Low dispenser out 
        InvalidTransaction = 7,              // 12 - Invalid transaction 
        InvalidAmount = 8,                   // 13 - Invalid amount 
        InvalidCardNumber = 9,               // 14 - Invalid card number 
        NoFromAccount = 10,                  // 20 - No From account 
        MessageFormatError = 11,             // 30 - Message format error
        TransactionNotAllowed = 12,          // 39 - Transaction not allowed
        NoFundsAvailable = 13,               // 51 - No funds available
        ExpiredCard = 14,                    // 54 - Expired card
        IncorrectPIN = 15,                   // 55 - Incorrect PIN; re-enter
        TransactionNotPermittedOnCard = 16,  // 57 - Transaction not permitted on card
        ExceedsAmountLimit = 17,             // 61 - Exceeds amount limit
        RestrictedCard = 18,                 // 62 - Restricted card
        ExceedFrequencyLimit = 19,           // 65 - Exceed Frequency Limit
        PinRetriesExceeded = 20,             // 75 - Pin Retries Exceeded
        InvalidAccount = 21,                 // 76 - Invalid account
        SystemError = 22,                    // 96 - System Error
        UnableToDispense = 23,               // 21 - Unable to Dispense
        PartialDispense = 24,                // 32 - Partial Dispense
        LateResponse = 25,                   // 68 - Late Response
        IssuerDown = 26,                     // 91 - Issuer Down
        HostAccepted = 27,                   // 00 - Host Accepted
        HostRejected = 28,                   // != 00 - Host Rejected
        HotListed = 29,                      // 43 - Hot listed
        NoRoutingGateway = 31,               //No Routing Gateway
        InvalidCheckingAccount = 32,           //Invalid Checking Account,
        InvalidSavingAccount = 33,             //Invalid Saving Account
        NoActionTacken = 33,             //Invalid Saving Account
        PickUp = 34,
        SuspectFraud = 35,
        StolenCard = 43,
        SecurityKeyViolation = 63,
    }
    public class ISO8583_1987Formatter_IBTG_HOST : ISO8583Formatter
    {
        private static ISO8583_CommandCollection commandCollection;

        public override ISO8583_CommandCollection CommandCollection
        {
            get
            {
                return commandCollection;
            }
            set
            {
                //base.CommandCollection = value;
            }
        }

        static ISO8583_1987Formatter_IBTG_HOST()
        {
            SetUpCommands();
        }
        private static void SetUpCommands()
        {


            ///////////////*******************Added By Abhishek.V 

            commandCollection = new ISO8583_CommandCollection();
            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.AuthorizationRequestMessage, "0200", new int[] { 3, 4, 11, 12, 17, 24, 28, 32, 34, 37, 41, 42, 49, 102, 123 }, new int[] { 120, 124 }));

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.AuthorizationResponseMessage, "0210", new int[] { 3, 4, 11, 12, 17, 32, 34, 37, 41, 42, 49, 123 }, new int[] { 38, 39, 48, 124, 125 })
            {
                IsResponseCommand = true,
                ResponseCodes = new ISO8583_ResponseCodeCollection()
                {
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.TransactionApproved, "000"),            // 00 - Transaction approved
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ReferToCardIssuer, "101"),              // 02 - Refer to card issuer 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.DoNotHonour, "105"),                    // 04 - Do not honour 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.UnableToProcess, "191"),                // 05 - Unable to process 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.Timeout, "108"),                        // 08 - Timeout 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.UnableToReverse, "110"),                // 10 - Unable to reverse 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.LowDispenserOut, "111"),                // 11 - Low dispenser out 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidTransaction, "112"),             // 12 - Invalid transaction 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidAmount, "113"),                  // 13 - Invalid amount 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidCardNumber, "114"),              // 14 - Invalid card number 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoFromAccount, "120"),                  // 20 - No From account 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.MessageFormatError,"130"),              // 30 - Message format error
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.TransactionNotAllowed, "139"),          // 39 - Transaction not allowed
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoFundsAvailable, "116"),               // 51 - No funds available
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ExpiredCard, "154"),                    // 54 - Expired card
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.IncorrectPIN, "155"),                   // 55 - Incorrect PIN; re-enter
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.TransactionNotPermittedOnCard, "157"),  // 57 - Transaction not permitted on card
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ExceedsAmountLimit, "161"),             // 61 - Exceeds amount limit
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.RestrictedCard, "162"),                 // 62 - Restricted card
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ExceedFrequencyLimit, "165"),           // 65 - Exceed Frequency Limit
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.PinRetriesExceeded,"175"),              // 75 - PinRetriesExceeded
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidAccount, "176"),                 // 76 - Invalid account
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.IssuerDown, "191"),                     // 91 - Issuer Down
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SystemError, "196"),                    // 96 - System Error
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.HotListed, "141"),                      // 43 - HotListed
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.DuplicateTransaction,"194"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidCheckingAccount , "152"),        //InvalidCheckingAccount
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidSavingAccount , "153"),          //InvalidSavingAccount
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoRoutingGateway , "192"),              //No Routing Gateway
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.PickUp , "104"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SuspectFraud , "134"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.StolenCard , "143"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SecurityKeyViolation , "163"),
                }
            });

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.DMSAuthorizationRequestMessage, "1200", new int[] { 3, 4, 11, 12, 17, 24, 28, 32, 34, 37, 41, 42, 49, 102, 123 }, new int[] { 124 }));

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.DMSAuthorizationResponseMessage, "1210", new int[] { 3, 4, 11, 12, 17, 32, 34, 37, 41, 42, 49, 123 }, new int[] { 38, 39, 48, 102, 103, 124, 125 }) { });

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.AccountingAuthorizationRequestMessage, "1220", new int[] { 3, 4, 11, 12, 17, 24, 32, 34, 37, 41, 42, 49, 102, 123 }, new int[] { 124 }));

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.AccountingAuthorizationResponseMessage, "1230", new int[] { 3, 4, 11, 12, 17, 32, 34, 37, 41, 42, 49, 123 }, new int[] { 38, 39, 48, 102, 103, 124, 125 })
            {
                IsResponseCommand = true,
                ResponseCodes = new ISO8583_ResponseCodeCollection()
                {
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.TransactionApproved, "000"),            // 00 - Transaction approved
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ReferToCardIssuer, "101"),              // 02 - Refer to card issuer 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.DoNotHonour, "105"),                    // 04 - Do not honour 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.UnableToProcess, "191"),                // 05 - Unable to process 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.Timeout, "108"),                        // 08 - Timeout 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.UnableToReverse, "110"),                // 10 - Unable to reverse 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.LowDispenserOut, "111"),                // 11 - Low dispenser out 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidTransaction, "112"),             // 12 - Invalid transaction 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidAmount, "113"),                  // 13 - Invalid amount 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidCardNumber, "114"),              // 14 - Invalid card number 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoFromAccount, "120"),                  // 20 - No From account 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.MessageFormatError,"130"),              // 30 - Message format error
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.TransactionNotAllowed, "139"),          // 39 - Transaction not allowed
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoFundsAvailable, "116"),               // 51 - No funds available
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ExpiredCard, "154"),                    // 54 - Expired card
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.IncorrectPIN, "155"),                   // 55 - Incorrect PIN; re-enter
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.TransactionNotPermittedOnCard, "157"),  // 57 - Transaction not permitted on card
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ExceedsAmountLimit, "161"),             // 61 - Exceeds amount limit
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.RestrictedCard, "162"),                 // 62 - Restricted card
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ExceedFrequencyLimit, "165"),           // 65 - Exceed Frequency Limit
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.PinRetriesExceeded,"175"),              // 75 - PinRetriesExceeded
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidAccount, "176"),                 // 76 - Invalid account
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.IssuerDown, "191"),                     // 91 - Issuer Down
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SystemError, "196"),                    // 96 - System Error
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.HotListed, "141"),                      // 43 - HotListed
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.DuplicateTransaction,"194"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidCheckingAccount , "152"),        //InvalidCheckingAccount
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidSavingAccount , "153"),          //InvalidSavingAccount
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoRoutingGateway , "192"),              //No Routing Gateway
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.PickUp , "104"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SuspectFraud , "134"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.StolenCard , "143"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SecurityKeyViolation , "163"),
                }
            });

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.AccountingReversalAdviceRequestMessage, "1240", new int[] { 3, 4, 11, 12, 17, 24, 32, 34, 37, 41, 42, 49, 102, 123 }, new int[] { 56, 103, 124 }));

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.AccountingReversalAdviceResponseMessage, "1250", new int[] { 3, 4, 11, 12, 17, 32, 34, 37, 41, 42, 49, 123 }, new int[] { 38, 39, 48, 102, 103, 124, 125 })
            {
                IsResponseCommand = true,
                ResponseCodes = new ISO8583_ResponseCodeCollection()
                {
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.TransactionApproved, "000"),            // 00 - Transaction approved
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ReferToCardIssuer, "101"),              // 02 - Refer to card issuer 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.DoNotHonour, "105"),                    // 04 - Do not honour 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.UnableToProcess, "191"),                // 05 - Unable to process 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.Timeout, "108"),                        // 08 - Timeout 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.UnableToReverse, "110"),                // 10 - Unable to reverse 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.LowDispenserOut, "111"),                // 11 - Low dispenser out 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidTransaction, "112"),             // 12 - Invalid transaction 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidAmount, "113"),                  // 13 - Invalid amount 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidCardNumber, "114"),              // 14 - Invalid card number 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoFromAccount, "120"),                  // 20 - No From account 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.MessageFormatError,"130"),              // 30 - Message format error
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.TransactionNotAllowed, "139"),          // 39 - Transaction not allowed
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoFundsAvailable, "116"),               // 51 - No funds available
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ExpiredCard, "154"),                    // 54 - Expired card
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.IncorrectPIN, "155"),                   // 55 - Incorrect PIN; re-enter
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.TransactionNotPermittedOnCard, "157"),  // 57 - Transaction not permitted on card
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ExceedsAmountLimit, "161"),             // 61 - Exceeds amount limit
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.RestrictedCard, "162"),                 // 62 - Restricted card
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ExceedFrequencyLimit, "165"),           // 65 - Exceed Frequency Limit
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.PinRetriesExceeded,"175"),              // 75 - PinRetriesExceeded
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidAccount, "176"),                 // 76 - Invalid account
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.IssuerDown, "191"),                     // 91 - Issuer Down
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SystemError, "196"),                    // 96 - System Error
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.HotListed, "141"),                      // 43 - HotListed
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.DuplicateTransaction,"194"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidCheckingAccount , "152"),        //InvalidCheckingAccount
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.InvalidSavingAccount , "153"),          //InvalidSavingAccount
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoRoutingGateway , "192"),              //No Routing Gateway
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.PickUp , "104"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SuspectFraud , "134"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.StolenCard , "143"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SecurityKeyViolation , "163"),
                }
            });

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.ReversalAdviceRequestMessage, "1420", new int[] { 3, 4, 11, 12, 17, 24, 28, 32, 34, 37, 41, 42, 49, 102, 123 }, new int[] { 56, 124 })
            {
                IsResponseCommand = true,
                ResponseCodes = new ISO8583_ResponseCodeCollection()
                {
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.IssuerDown, "191"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoActionTacken, "121"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.ReferToCardIssuer, "101"),              // 02 - Refer to card issuer 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.DoNotHonour, "105"),                    // 04 - Do not honour 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.UnableToProcess, "191"),                // 05 - Unable to process 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.Timeout, "108"),                        // 08 - Timeout 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.UnableToReverse, "110"),                // 10 - Unable to reverse 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.LowDispenserOut, "111"),                // 11 - Low dispenser out 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.DuplicateTransaction, "194"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.LateResponse, "168"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.NoRoutingGateway , "192"),              //No Routing Gateway
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.PickUp , "104"),
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SuspectFraud , "134"),
                }
            });

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.ReversalAdviceResponseMessage, "1430", new int[] { 3, 4, 11, 12, 17, 32, 34, 37, 41, 42, 49, 123 }, new int[] { 38, 39, 54, 90, 102, 124, 125 })
            {
                IsResponseCommand = true,
                ResponseCodes = new ISO8583_ResponseCodeCollection()
                {
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.TransactionApproved, "000"),                 // 00 - Transaction approved
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.UnableToProcess, "191"),                      // 05 - Unable to Process 
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.Timeout, "108"),                              // 08 - Timeout
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.UnableToDispense, "121"),                     // 21 - Unable to Dispense
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.PartialDispense, "132"),                      // 32 - Partial Dispense
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.LateResponse, "168"),                         // 68 - Late Response
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.IssuerDown, "191"),                           // 91 - Issuer Down
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.SystemError, "196"),                          // 96 - System Error
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.DuplicateTransaction, "109"),
                }
            });

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.NetworkManagementRequestsMessages, "1804", new int[] { 11, 12, 70, 123 }, new int[] { }));

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.NetworkManagementResponseMessages, "1814", new int[] { 11, 12, 70, 123 }, new int[] { 39 })
            {
                IsResponseCommand = true,
                ResponseCodes = new ISO8583_ResponseCodeCollection()
                {
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.HostAccepted, "000"),                     // 00 - Host Accepted
                    new ISO8583_ResponseCode((int)ResponseCodesEnum.HostRejected, "101"),                     // != 00 - Host Rejected
                }
            });

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.MST1AuthorizationRequestMessage, "1644", new int[] { 24, 48, 71 }, new int[] { 50, 93, 94, 100 })
            { });

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.MST2AuthorizationResponseMessage, "1240", new int[] { 2, 3, 4, 5, 6, 9, 10, 12, 22, 24, 26, 31, 33, 38, 42, 43, 48, 49, 50, 51, 63, 71, 93, 94, 100 }, new int[] { 23, 55 })
            { });

            commandCollection.Add(new ISO8583_Command(CommandTypeEnum.MST3Firstchargeback, "1442", new int[] { 2, 3, 4, 5, 9, 12, 22, 24, 25, 26, 30, 31, 33, 38, 40, 41, 42, 43, 48, 49, 50, 63, 71, 72, 93, 94, 95, 100 }, new int[] { })
            { });


        }
        static string HEADER = "";
        public ISO8583_1987Formatter_IBTG_HOST()
        {
            base.Version = ISO8583VersionEnum.ISO8583_1993;
            base.HeaderValue = HEADER;
            base.HasMsgLengthPrefixIN4Byte = true;
            base.HasMsgLengthPrefixIN2Byte = false;
            base.MsgLengthSize = 4;
            SetUpFields();
        }
        private void SetUpFields()
        {
            base.Version = ISO8583VersionEnum.ISO8583_1993;
            base.Header = new ISO8583Field() { FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 0, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Header" };
            base.MessageTypeIdentifier = new ISO8583Field() { FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 4, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "MessageTypeIdentifier" };
            base.PrimaryBitMap = new ISO8583Field() { FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Primary Bitmap" };
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 001, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "ans 8 Bit map (b 128 if secondary is present and b 192 if tertiary is present)" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 002, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 18, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "ans ..19 Primary Account Number (PAN)" });
            //base.DataElements.Add(new ISO8583Field() { FieldIndex = 002, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 16, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "ans ..19 Primary Account Number (PAN)" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 003, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 6, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 6 Processing code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 004, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 12, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 12 Amount, transaction" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 005, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 12, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 12 Amount, Reconciliation " });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 006, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 12, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 12 Amount, Cardholder Billing" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 007, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 10, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 10 Transmission date & time" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 009, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Conversation Rate, Reconciliation " });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 010, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Conversation Rate, Cardholder Billing " });
            //base.DataElements.Add(new ISO8583Field() { FieldIndex = 011, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 12, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 6 Systems trace audit number"});
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 012, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 12, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 5 Time, local transaction (hhmmss)" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 013, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 4, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 4 Date, local transaction (MMDD)" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 014, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 4, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 4 Date, settlement" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 015, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 4, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 4 Date, settlement" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 016, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 4, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 4 Date, Conversion Date" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 017, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 4 Date, capture" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 018, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 4, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 4 Merchant type" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 019, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 3, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Transaction currency code" });            //end amit
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 022, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 12, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "PAN Entry Mode" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 023, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 3, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Card Sequence Number" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 024, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 3, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Function Code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 025, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 4, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "POS Condition Code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 026, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 4, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Card Acceptor Business Code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 028, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 16, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "This will be use in Issuer Transaction Charges" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 029, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 16, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "This will be use in CashBack on POS Transactions" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 030, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 24, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Acquirer Reference Data" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 031, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 25, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "Acquirer Reference Data" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 032, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 99, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "n ..11 Acquiring institution identification code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 033, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Forwarding Inst ID" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 034, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 32, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "Extended Primary Account Number" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 035, FieldType = ISO8583FieldTypeEnum.ISO8583_Z, Size = 40, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "z ..37 Track 2 data" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 037, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 12, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "an 12 Retrieval reference number" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 038, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 6, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "an 6 Authorization identification response" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 039, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 3, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 3 Response code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 040, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 3, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Service code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 041, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "ans 16 Card acceptor terminal identification" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 042, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 15, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "ans 15 Card acceptor identification code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 043, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 99, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "ans 40 Card acceptor name/location (1-23 address 24-36 city 37-38 state 39-40 country)" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 044, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 29, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "an ..25 Additional response data" });
            ////base.DataElements.Add(new ISO8583Field() { FieldIndex = 046, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 9, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "an ..25 Additional response data" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 046, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "Additional data - ISO" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 048, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "an ..25 Additional response data" });
            //base.DataElements.Add(new ISO8583Field() { FieldIndex = 048, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "an ..25 Additional response data" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 049, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 3, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "a 3 Currency code, transaction" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 050, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 3, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "a 3 Settlement Currency Code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 051, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 3, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "a 3 Settlement Currency Code,Cardholder Billing" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 052, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 16, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "b 64 Personal identification number data" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 054, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "an .7 Advice/reason code (private reserved)" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 055, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "Integrated Circuit Card" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 056, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 99, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "a 99 ReversalField" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 059, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "a 999 Transport Data" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 060, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ...999 Reserved private" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 061, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ...999 Reserved private" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 062, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ...999 Reserved private" });
            //base.DataElements.Add(new ISO8583Field() { FieldIndex = 063, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 15, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "Transaction Life Cycle" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 063, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 99, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "Integrated Circuit Card" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 070, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 3, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 3 Network Management Information Code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 071, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "Message Number" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 072, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "Message Number" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 090, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 42, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n 42 Original data elements" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 093, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "n Transaction destination Institution identification code" });
            //base.DataElements.Add(new ISO8583Field() { FieldIndex = 094, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 6, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n Transaction originator  Institution identification code" });            
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 094, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "n Transaction originator  Institution identification code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 095, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 42, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "an 42 Replacement amounts" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 099, FieldType = ISO8583FieldTypeEnum.ISO8583_AN, Size = 99, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "an 42 Replacement amounts" });
            //base.DataElements.Add(new ISO8583Field() { FieldIndex = 100, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 6, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED, FieldDescription = "n ..11 Receiving institution identification code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 100, FieldType = ISO8583FieldTypeEnum.ISO8583_N, Size = 8, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "n ..11 Receiving institution identification code" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 102, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 99, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "ans ..28 Account identification 1" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 103, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 99, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLVAR, FieldDescription = "ans ..28 Account identification 2" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 108, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ..999 This will use in mini statement and pin change" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 111, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ..999 This will use in mini statement and pin change" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 114, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ..999 This will use in mini statement and pin change" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 116, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ..999 This will use in mini statement and pin change" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 120, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ..999 This will use in mini statement and pin change" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 123, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ..999 Service Delivery Channel" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 124, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ..999 Terminal Type For Finacle user" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 125, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ..999 This will use in mini statement/Reserved field" });
            base.DataElements.Add(new ISO8583Field() { FieldIndex = 127, FieldType = ISO8583FieldTypeEnum.ISO8583_ANS, Size = 999, FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR, FieldDescription = "ans ..999 This will use in mini statement/Reserved field" });
        }

        public override bool InitCommand(ISO8583Message sourceMessage, CommandData cmdData)
        {
            try
            {
                if (sourceMessage == null || cmdData == null) return false;
                bool isValidMsg = false;
                cmdData.CommandType = CommandTypeEnum.Unknown;
                cmdData.NCommandType = "0000";
                ISO8583_Command cmd = CommandCollection[sourceMessage.MTI];
                if (cmd == null) return false;
                cmdData.CommandType = cmd.CommandType;
                cmdData.NCommandType = cmd.CommandCode;
                isValidMsg = CheckFields(sourceMessage, cmd.MFields, cmd.OFields);
                //  if (!isValidMsg) return false;
                if (sourceMessage.Fields.Contains(002)) cmdData.CardNumber = Utils.ByteArrayToASCII(sourceMessage.Fields[2].Value);
                if (sourceMessage.Fields.Contains(003)) cmdData.Processingcode = Utils.ByteArrayToASCII(sourceMessage.Fields[3].Value);
                if (sourceMessage.Fields.Contains(004)) cmdData.TransactionAmount = Utils.GetAmountToDouble(Utils.ByteArrayToASCII(sourceMessage.Fields[4].Value));
                if (sourceMessage.Fields.Contains(005)) cmdData.ReconciliationAmount = Utils.GetAmountToDouble(Utils.ByteArrayToASCII(sourceMessage.Fields[5].Value));
                if (sourceMessage.Fields.Contains(006)) cmdData.CardholderBilling = Utils.GetAmountToDouble(Utils.ByteArrayToASCII(sourceMessage.Fields[6].Value));
                if (sourceMessage.Fields.Contains(007)) cmdData.TransmissionDateTime = Utils.ByteArrayToASCII(sourceMessage.Fields[7].Value);
                if (sourceMessage.Fields.Contains(009)) cmdData.ConversationRateReconciliation = Utils.ByteArrayToASCII(sourceMessage.Fields[9].Value);
                if (sourceMessage.Fields.Contains(010)) cmdData.ConversationRateCardholderBilling = Utils.ByteArrayToASCII(sourceMessage.Fields[10].Value);
                if (sourceMessage.Fields.Contains(011)) cmdData.SystemsTraceAuditNumber = Utils.ByteArrayToASCII(sourceMessage.Fields[11].Value);
                ////if (sourceMessage.Fields.Contains(012)) cmdData.LocalTransactionDateTime = DateTime.ParseExact(Utils.ByteArrayToASCII(sourceMessage.Fields[12].Value), "HHmmss", CultureInfo.InvariantCulture);
                if (sourceMessage.Fields.Contains(012)) cmdData.LocalTransactionDateTime = DateTime.ParseExact(Utils.ByteArrayToASCII(sourceMessage.Fields[12].Value), "yyMMddHHmmss", CultureInfo.InvariantCulture);
                if (sourceMessage.Fields.Contains(013)) cmdData.LocalTransactionDate = DateTime.ParseExact(Utils.ByteArrayToASCII(sourceMessage.Fields[13].Value), "MMdd", CultureInfo.InvariantCulture);
                if (sourceMessage.Fields.Contains(014)) cmdData.ExpiredDate = DateTime.ParseExact(Utils.ByteArrayToASCII(sourceMessage.Fields[14].Value), "yyMM", CultureInfo.InvariantCulture);
                if (sourceMessage.Fields.Contains(015)) cmdData.SettlementDate = (Utils.ByteArrayToASCII(sourceMessage.Fields[15].Value));
                ////if (sourceMessage.Fields.Contains(017)) cmdData.CaptureDate = DateTime.ParseExact(Utils.ByteArrayToASCII(sourceMessage.Fields[17].Value), "yyyyMMdd", CultureInfo.InvariantCulture).ToString();
                if (sourceMessage.Fields.Contains(017)) cmdData.CaptureDate = (Utils.ByteArrayToASCII(sourceMessage.Fields[17].Value));
                if (sourceMessage.Fields.Contains(018)) cmdData.MerchantCategory = (Utils.ByteArrayToASCII(sourceMessage.Fields[18].Value).ToString());
                if (sourceMessage.Fields.Contains(019)) cmdData.AcquiringInstitutionCountryCode = (Utils.ByteArrayToASCII(sourceMessage.Fields[19].Value).ToString());
                if (sourceMessage.Fields.Contains(022)) cmdData.PanEntryMode = Utils.ByteArrayToASCII(sourceMessage.Fields[22].Value);
                if (sourceMessage.Fields.Contains(023)) cmdData.CardSequenceNumber = Utils.ByteArrayToASCII(sourceMessage.Fields[23].Value);
                if (sourceMessage.Fields.Contains(024)) cmdData.FunctionCode = (Utils.ByteArrayToASCII(sourceMessage.Fields[24].Value).ToString());
                if (sourceMessage.Fields.Contains(026)) cmdData.CardAcceptorBusinessCode = Utils.ByteArrayToASCII(sourceMessage.Fields[26].Value);
                if (sourceMessage.Fields.Contains(028)) cmdData.TransactionCharges = (Utils.ByteArrayToASCII(sourceMessage.Fields[28].Value).ToString());
                if (sourceMessage.Fields.Contains(029)) cmdData.CashBackAmount = (Utils.ByteArrayToASCII(sourceMessage.Fields[29].Value).ToString());
                if (sourceMessage.Fields.Contains(030)) cmdData.AmountsOriginal = Utils.ByteArrayToASCII(sourceMessage.Fields[31].Value);
                if (sourceMessage.Fields.Contains(031)) cmdData.AcquirerReferenceData = Utils.ByteArrayToASCII(sourceMessage.Fields[31].Value);
                if (sourceMessage.Fields.Contains(032)) cmdData.AcquirerInstitutionCode = Utils.ByteArrayToASCII(sourceMessage.Fields[32].Value);
                if (sourceMessage.Fields.Contains(033)) cmdData.ReceivingInstitutionCode = Utils.ByteArrayToASCII(sourceMessage.Fields[33].Value);
                if (sourceMessage.Fields.Contains(034)) cmdData.CardNumber = Utils.ByteArrayToASCII(sourceMessage.Fields[34].Value);
                if (sourceMessage.Fields.Contains(035)) cmdData.Track2Data = Utils.ByteArrayToASCII(sourceMessage.Fields[35].Value);
                if (sourceMessage.Fields.Contains(037)) cmdData.ReferenceNumber = Utils.ByteArrayToASCII(sourceMessage.Fields[37].Value);
                if (sourceMessage.Fields.Contains(038)) cmdData.AuthorizationNumber = Utils.ByteArrayToASCII(sourceMessage.Fields[38].Value);
                if (sourceMessage.Fields.Contains(039))
                {
                    cmdData.NResponseCode = Utils.ByteArrayToASCII(sourceMessage.Fields[39].Value);
                }
                if (sourceMessage.Fields.Contains(040)) cmdData.ServiceCode = Utils.ByteArrayToASCII(sourceMessage.Fields[40].Value);
                if (sourceMessage.Fields.Contains(041)) cmdData.TerminalID = Utils.ByteArrayToASCII(sourceMessage.Fields[41].Value);
                if (sourceMessage.Fields.Contains(042)) cmdData.TerminalLocation = Utils.ByteArrayToASCII(sourceMessage.Fields[42].Value);
                if (sourceMessage.Fields.Contains(043)) cmdData.CardAccepterName = Utils.ByteArrayToASCII(sourceMessage.Fields[43].Value);
                //if (sourceMessage.Fields.Contains(046)) cmdData.AdditionalIssuerData = Utils.ByteArrayToASCII(sourceMessage.Fields[46].Value);
                if (sourceMessage.Fields.Contains(046)) cmdData.TransactionCharges = Utils.ByteArrayToASCII(sourceMessage.Fields[46].Value);
                if (sourceMessage.Fields.Contains(048)) cmdData.AdditionalDataPrivate = Utils.ByteArrayToASCII(sourceMessage.Fields[48].Value);
                if (sourceMessage.Fields.Contains(049)) cmdData.TransactionCurrencyCode = Utils.ByteArrayToASCII(sourceMessage.Fields[49].Value);
                if (sourceMessage.Fields.Contains(050)) cmdData.SettlementCurrencyCode = Utils.ByteArrayToASCII(sourceMessage.Fields[50].Value).ToString();
                if (sourceMessage.Fields.Contains(051)) cmdData.SettlementCurrencyCodeCardholderBilling = Utils.ByteArrayToASCII(sourceMessage.Fields[51].Value).ToString();
                if (sourceMessage.Fields.Contains(054)) cmdData.AdditionalAmounts = Utils.ByteArrayToASCII(sourceMessage.Fields[54].Value);
                if (sourceMessage.Fields.Contains(055)) cmdData.ChipData = Utils.ByteArrayToASCII(sourceMessage.Fields[55].Value);
                if (sourceMessage.Fields.Contains(056)) cmdData.ReversalField56 = Utils.ByteArrayToASCII(sourceMessage.Fields[56].Value);
                if (sourceMessage.Fields.Contains(059)) cmdData.TransportData = Utils.ByteArrayToASCII(sourceMessage.Fields[59].Value);
                if (sourceMessage.Fields.Contains(060)) cmdData.PoSData = Utils.ByteArrayToASCII(sourceMessage.Fields[60].Value);
                if (sourceMessage.Fields.Contains(061)) cmdData.PoSData = Utils.ByteArrayToASCII(sourceMessage.Fields[61].Value);
                if (sourceMessage.Fields.Contains(062)) cmdData.ChequeDetails = Utils.ByteArrayToASCII(sourceMessage.Fields[62].Value);
                if (sourceMessage.Fields.Contains(063)) cmdData.AdditionalIssuerData = Utils.ByteArrayToASCII(sourceMessage.Fields[63].Value);
                if (sourceMessage.Fields.Contains(070)) cmdData.NNetworkManagementInformationCode = Utils.ByteArrayToASCII(sourceMessage.Fields[70].Value);
                if (sourceMessage.Fields.Contains(071)) cmdData.MessageNumber = Utils.ByteArrayToASCII(sourceMessage.Fields[71].Value);
                if (sourceMessage.Fields.Contains(072)) cmdData.DE72DataRecord = Utils.ByteArrayToASCII(sourceMessage.Fields[71].Value);
                if (sourceMessage.Fields.Contains(090)) cmdData.OriginalDataElements = Utils.ByteArrayToASCII(sourceMessage.Fields[090].Value);
                if (sourceMessage.Fields.Contains(093)) cmdData.DestinationInstIDCode = Utils.ByteArrayToASCII(sourceMessage.Fields[093].Value);
                if (sourceMessage.Fields.Contains(094)) cmdData.OriginatorInstIDCode = Utils.ByteArrayToASCII(sourceMessage.Fields[094].Value);
                if (sourceMessage.Fields.Contains(095)) cmdData.PartialReversal = Utils.ByteArrayToASCII(sourceMessage.Fields[095].Value);
                if (sourceMessage.Fields.Contains(099)) cmdData.SettlementInstitution = Utils.ByteArrayToASCII(sourceMessage.Fields[99].Value);
                if (sourceMessage.Fields.Contains(100)) cmdData.ReceivingInstitutionBin = Utils.ByteArrayToASCII(sourceMessage.Fields[100].Value);
                if (sourceMessage.Fields.Contains(102)) cmdData.FromAccountNumber = Utils.ByteArrayToASCII(sourceMessage.Fields[102].Value);
                if (sourceMessage.Fields.Contains(103)) cmdData.ToAccountNumber = Utils.ByteArrayToASCII(sourceMessage.Fields[103].Value);
                if (sourceMessage.Fields.Contains(108)) cmdData.Field108 = Utils.ByteArrayToASCII(sourceMessage.Fields[108].Value);
                if (sourceMessage.Fields.Contains(111)) cmdData.ExtendedData = Utils.ByteArrayToASCII(sourceMessage.Fields[111].Value);
                if (sourceMessage.Fields.Contains(114)) cmdData.Field114 = Utils.ByteArrayToASCII(sourceMessage.Fields[114].Value);
                if (sourceMessage.Fields.Contains(116)) cmdData.TransactionCharges = Utils.ByteArrayToASCII(sourceMessage.Fields[116].Value);
                if (sourceMessage.Fields.Contains(120)) cmdData.ExtendedData = Utils.ByteArrayToASCII(sourceMessage.Fields[120].Value);
                if (sourceMessage.Fields.Contains(123)) cmdData.DeliveryChannelControllerId = Utils.ByteArrayToASCII(sourceMessage.Fields[123].Value);
                if (sourceMessage.Fields.Contains(124)) cmdData.TerminalType = Utils.ByteArrayToASCII(sourceMessage.Fields[124].Value);
                if (sourceMessage.Fields.Contains(125)) cmdData.ReservedField1 = Utils.ByteArrayToASCII(sourceMessage.Fields[125].Value);
                if (sourceMessage.Fields.Contains(126)) cmdData.ReservedField2 = Utils.ByteArrayToASCII(sourceMessage.Fields[126].Value);
                if (sourceMessage.Fields.Contains(127)) cmdData.ExtendedData = Utils.ByteArrayToASCII(sourceMessage.Fields[127].Value);
                if (cmdData.CardNumber == null || cmdData.CardNumber == string.Empty)
                {
                    string CardNo = string.Empty;
                    if (cmdData.Track2Data != null)
                    {
                        string[] track2Data = cmdData.Track2Data.Replace(";", "").Replace("?", "").Split('=');
                        if (track2Data != null && track2Data.Length > 0)
                            CardNo = track2Data[0];
                    }
                    cmdData.CardNumber = CardNo;
                }
                //call reconver cmddata
                return true;
            }
            catch (Exception ex)
            {
                if (sourceMessage != null)
                {
                    sourceMessage.ErrorLog = ex.Message;
                    sourceMessage.IsValidMessage = false;
                }
                return false;
            }
        }

        public override bool InitMessage(ISO8583Message sourceMessage, CommandData cmdData)
        {
            try
            {
                if (sourceMessage == null || cmdData == null) return false;

                ISO8583_Command cmd = CommandCollection[cmdData.CommandType];
                if (cmd == null) return false;
                if (cmd.CommandType != CommandTypeEnum.Unknown)
                {
                    cmdData.NCommandType = cmd.CommandCode;
                    sourceMessage.Header = HEADER;
                    sourceMessage.MTI = cmd.CommandCode;
                    ////SetRequiredFields(sourceMessage, cmd.MFields, cmd.OFields);

                    //if (cmdData.PartialReversal.Length > 12 || (!string.IsNullOrEmpty(cmdData.ToAccountNumber)))
                    ////if (cmdData.PartialReversal.Length > 12)
                    //if (!string.IsNullOrEmpty(cmdData.ExtendedData))
                    //{
                    //    GetRequiredFieldHost(sourceMessage, cmdData, cmd);
                    //}
                    //else
                    //{
                    SetRequiredFields(sourceMessage, cmd.MFields, cmd.OFields);
                    //}
                }
                else
                {
                    cmdData.NCommandType = "0000";
                    sourceMessage.Fields.Clear();
                    sourceMessage.IsValidMessage = false;
                    sourceMessage.ErrorLog = "Unknown Request";
                    return false;
                }

                if (cmdData.CardNumber == null || cmdData.CardNumber == string.Empty)
                {
                    string CardNo = string.Empty;
                    if (cmdData.Track2Data != null)
                    {
                        string[] track2Data = cmdData.Track2Data.Replace(";", "").Replace("?", "").Split('=');
                        if (track2Data != null && track2Data.Length > 0)
                            CardNo = track2Data[0];
                    }
                    cmdData.CardNumber = CardNo;
                }

                if (sourceMessage.Fields.Contains(002)) sourceMessage.Fields[002].Value = Utils.ASCIIToByteArray(cmdData.CardNumber);
                if (sourceMessage.Fields.Contains(003)) sourceMessage.Fields[003].Value = Utils.ASCIIToByteArray(cmdData.Processingcode);
                if (sourceMessage.Fields.Contains(004)) sourceMessage.Fields[004].Value = Utils.ASCIIToByteArray(Utils.GetDoubleToAmount(cmdData.TransactionAmount));
                if (sourceMessage.Fields.Contains(005)) sourceMessage.Fields[005].Value = Utils.ASCIIToByteArray(Utils.GetDoubleToAmount(cmdData.ReconciliationAmount));
                if (sourceMessage.Fields.Contains(006)) sourceMessage.Fields[006].Value = Utils.ASCIIToByteArray(Utils.GetDoubleToAmount(cmdData.CardholderBilling));
                if (sourceMessage.Fields.Contains(007)) sourceMessage.Fields[007].Value = Utils.ASCIIToByteArray(cmdData.TransmissionDateTime);
                if (sourceMessage.Fields.Contains(009)) sourceMessage.Fields[009].Value = Utils.ASCIIToByteArray(cmdData.ConversationRateReconciliation.ToString());
                if (sourceMessage.Fields.Contains(010)) sourceMessage.Fields[010].Value = Utils.ASCIIToByteArray(cmdData.ConversationRateCardholderBilling.ToString());
                if (sourceMessage.Fields.Contains(011)) sourceMessage.Fields[011].Value = Utils.ASCIIToByteArray(cmdData.SystemsTraceAuditNumber.ToString().PadLeft(6, '0'));
                ////if (sourceMessage.Fields.Contains(012)) sourceMessage.Fields[012].Value = Utils.ASCIIToByteArray(cmdData.LocalTransactionDateTime.ToString("HHmmss", CultureInfo.InvariantCulture));
                if (sourceMessage.Fields.Contains(012)) sourceMessage.Fields[012].Value = Utils.ASCIIToByteArray(cmdData.LocalTransactionDateTime.ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture));
                if (sourceMessage.Fields.Contains(013)) sourceMessage.Fields[013].Value = Utils.ASCIIToByteArray(cmdData.LocalTransactionDate.ToString("MMdd", CultureInfo.InvariantCulture));
                if (sourceMessage.Fields.Contains(014)) sourceMessage.Fields[014].Value = Utils.ASCIIToByteArray(cmdData.ExpiredDate.ToString("yyMM", CultureInfo.InvariantCulture));
                if (sourceMessage.Fields.Contains(015)) sourceMessage.Fields[015].Value = Utils.ASCIIToByteArray(cmdData.ExpiredDate.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
                if (sourceMessage.Fields.Contains(017)) sourceMessage.Fields[017].Value = Utils.ASCIIToByteArray(cmdData.CaptureDate);
                if (sourceMessage.Fields.Contains(018)) sourceMessage.Fields[018].Value = Utils.ASCIIToByteArray(cmdData.MerchantCategory);
                if (sourceMessage.Fields.Contains(019)) sourceMessage.Fields[019].Value = Utils.ASCIIToByteArray(cmdData.AcquiringInstitutionCountryCode);
                if (sourceMessage.Fields.Contains(022)) sourceMessage.Fields[022].Value = Utils.ASCIIToByteArray(cmdData.PanEntryMode.ToString());
                if (sourceMessage.Fields.Contains(023)) sourceMessage.Fields[023].Value = Utils.ASCIIToByteArray(cmdData.CardSequenceNumber.ToString());
                if (sourceMessage.Fields.Contains(024)) sourceMessage.Fields[024].Value = Utils.ASCIIToByteArray(cmdData.FunctionCode.ToString());
                if (sourceMessage.Fields.Contains(025)) sourceMessage.Fields[025].Value = Utils.ASCIIToByteArray(cmdData.PoSConditionCode.ToString());
                if (sourceMessage.Fields.Contains(026)) sourceMessage.Fields[026].Value = Utils.ASCIIToByteArray(cmdData.CardAcceptorBusinessCode.ToString());
                if (sourceMessage.Fields.Contains(028)) sourceMessage.Fields[028].Value = Utils.ASCIIToByteArray(cmdData.TransactionCharges.ToString());
                if (sourceMessage.Fields.Contains(029)) sourceMessage.Fields[029].Value = Utils.ASCIIToByteArray(cmdData.CashBackAmount.ToString());
                if (sourceMessage.Fields.Contains(030)) sourceMessage.Fields[029].Value = Utils.ASCIIToByteArray(cmdData.AmountsOriginal.ToString());
                if (sourceMessage.Fields.Contains(031)) sourceMessage.Fields[031].Value = Utils.ASCIIToByteArray(cmdData.AcquirerReferenceData.ToString());
                if (sourceMessage.Fields.Contains(032)) sourceMessage.Fields[032].Value = Utils.ASCIIToByteArray(cmdData.AcquirerInstitutionCode.ToString());
                if (sourceMessage.Fields.Contains(033)) sourceMessage.Fields[033].Value = Utils.ASCIIToByteArray(cmdData.ReceivingInstitutionCode.ToString());
                if (sourceMessage.Fields.Contains(034)) sourceMessage.Fields[034].Value = Utils.ASCIIToByteArray(cmdData.CardNumber.ToString());
                if (sourceMessage.Fields.Contains(035)) sourceMessage.Fields[035].Value = Utils.ASCIIToByteArray(cmdData.Track2Data.ToString());
                if (sourceMessage.Fields.Contains(037)) sourceMessage.Fields[037].Value = Utils.ASCIIToByteArray(cmdData.ReferenceNumber.ToString());
                if (sourceMessage.Fields.Contains(038)) sourceMessage.Fields[038].Value = Utils.ASCIIToByteArray(cmdData.AuthorizationNumber.ToString());
                if (sourceMessage.Fields.Contains(039))
                {
                    sourceMessage.Fields[039].Value = Utils.ASCIIToByteArray(cmdData.NResponseCode);
                }
                if (sourceMessage.Fields.Contains(040)) sourceMessage.Fields[040].Value = Utils.ASCIIToByteArray(cmdData.ServiceCode);
                if (sourceMessage.Fields.Contains(041)) sourceMessage.Fields[041].Value = Utils.ASCIIToByteArray(cmdData.TerminalID);
                if (sourceMessage.Fields.Contains(042)) sourceMessage.Fields[042].Value = Utils.ASCIIToByteArray(cmdData.TerminalLocation);
                if (sourceMessage.Fields.Contains(043)) sourceMessage.Fields[043].Value = Utils.ASCIIToByteArray(cmdData.CardAccepterName);
                if (sourceMessage.Fields.Contains(046)) sourceMessage.Fields[046].Value = Utils.ASCIIToByteArray(cmdData.TransactionCharges);
                if (sourceMessage.Fields.Contains(048)) sourceMessage.Fields[048].Value = Utils.ASCIIToByteArray(cmdData.AdditionalDataPrivate);
                if (sourceMessage.Fields.Contains(049)) sourceMessage.Fields[049].Value = Utils.ASCIIToByteArray(cmdData.TransactionCurrencyCode.ToString());
                if (sourceMessage.Fields.Contains(050)) sourceMessage.Fields[050].Value = Utils.ASCIIToByteArray(cmdData.SettlementCurrencyCode.ToString());
                if (sourceMessage.Fields.Contains(051)) sourceMessage.Fields[051].Value = Utils.ASCIIToByteArray(cmdData.SettlementCurrencyCodeCardholderBilling.ToString());
                if (sourceMessage.Fields.Contains(054)) sourceMessage.Fields[054].Value = Utils.ASCIIToByteArray(cmdData.AdditionalAmounts);
                if (sourceMessage.Fields.Contains(055)) sourceMessage.Fields[055].Value = Utils.ASCIIToByteArray(Utils.HEX2ASCII(cmdData.ChipData));
                //if (sourceMessage.Fields.Contains(055)) sourceMessage.Fields[055].Value = Utils.ASCIIToByteArray(cmdData.IntegratedCircuitCard);
                if (sourceMessage.Fields.Contains(056)) sourceMessage.Fields[056].Value = Utils.ASCIIToByteArray(cmdData.ReversalField56);
                if (sourceMessage.Fields.Contains(059)) sourceMessage.Fields[059].Value = Utils.ASCIIToByteArray(cmdData.TransportData);
                if (sourceMessage.Fields.Contains(060)) sourceMessage.Fields[060].Value = Utils.ASCIIToByteArray(cmdData.PoSData);
                if (sourceMessage.Fields.Contains(061)) sourceMessage.Fields[061].Value = Utils.ASCIIToByteArray(cmdData.PoSData);
                if (sourceMessage.Fields.Contains(062)) sourceMessage.Fields[062].Value = Utils.ASCIIToByteArray(cmdData.ChequeDetails);
                if (sourceMessage.Fields.Contains(063)) sourceMessage.Fields[063].Value = Utils.ASCIIToByteArray(cmdData.TransactionLifeCycle);
                if (sourceMessage.Fields.Contains(070)) sourceMessage.Fields[070].Value = Utils.ASCIIToByteArray(cmdData.NNetworkManagementInformationCode);
                if (sourceMessage.Fields.Contains(071)) sourceMessage.Fields[071].Value = Utils.ASCIIToByteArray(cmdData.MessageNumber);
                if (sourceMessage.Fields.Contains(072)) sourceMessage.Fields[072].Value = Utils.ASCIIToByteArray(cmdData.DE72DataRecord);
                if (sourceMessage.Fields.Contains(090)) sourceMessage.Fields[090].Value = Utils.ASCIIToByteArray(cmdData.OriginalDataElements);
                if (sourceMessage.Fields.Contains(093)) sourceMessage.Fields[093].Value = Utils.ASCIIToByteArray(cmdData.DestinationInstIDCode);
                if (sourceMessage.Fields.Contains(094)) sourceMessage.Fields[094].Value = Utils.ASCIIToByteArray(cmdData.OriginatorInstIDCode);
                if (sourceMessage.Fields.Contains(095)) sourceMessage.Fields[095].Value = Utils.ASCIIToByteArray(cmdData.PartialReversal);
                if (sourceMessage.Fields.Contains(099)) sourceMessage.Fields[099].Value = Utils.ASCIIToByteArray(cmdData.SettlementInstitution);
                if (sourceMessage.Fields.Contains(100)) sourceMessage.Fields[100].Value = Utils.ASCIIToByteArray(cmdData.ReceivingInstitutionBin.ToString());
                if (sourceMessage.Fields.Contains(102)) sourceMessage.Fields[102].Value = Utils.ASCIIToByteArray(cmdData.FromAccountNumber);
                if (sourceMessage.Fields.Contains(103)) sourceMessage.Fields[103].Value = Utils.ASCIIToByteArray(cmdData.ToAccountNumber);
                if (sourceMessage.Fields.Contains(108)) sourceMessage.Fields[108].Value = Utils.ASCIIToByteArray(cmdData.Field108);
                if (sourceMessage.Fields.Contains(116)) sourceMessage.Fields[116].Value = Utils.ASCIIToByteArray(cmdData.TransactionCharges);
                if (sourceMessage.Fields.Contains(120)) sourceMessage.Fields[120].Value = Utils.ASCIIToByteArray(cmdData.ExtendedData);
                if (sourceMessage.Fields.Contains(123)) sourceMessage.Fields[123].Value = Utils.ASCIIToByteArray(cmdData.DeliveryChannelControllerId);
                if (sourceMessage.Fields.Contains(124)) sourceMessage.Fields[124].Value = Utils.ASCIIToByteArray(cmdData.TerminalType);
                ////if (sourceMessage.Fields.Contains(125)) sourceMessage.Fields[125].Value = Utils.ASCIIToByteArray(cmdData.ReservedField1);
                if (sourceMessage.Fields.Contains(125)) sourceMessage.Fields[125].Value = Utils.ASCIIToByteArray(cmdData.ReservedField1);
                if (sourceMessage.Fields.Contains(126)) sourceMessage.Fields[126].Value = Utils.ASCIIToByteArray(cmdData.ReservedField2);
                if (sourceMessage.Fields.Contains(127)) sourceMessage.Fields[127].Value = Utils.ASCIIToByteArray(cmdData.ReservedField3);


                sourceMessage.IsValidMessage = true;
                sourceMessage.ErrorLog = string.Empty;

                return true;
            }
            catch (Exception ex)
            {
                if (sourceMessage != null)
                {
                    sourceMessage.ErrorLog = ex.Message;
                    sourceMessage.IsValidMessage = false;
                }
                return false;
            }
        }

        public static int[] IssuerPartialReversal = new int[] { 95 };
        public static int[] VASTransactions = new int[] { 120 };
        private void GetRequiredFieldHost(ISO8583Message sourceMessage, CommandData cmdData, ISO8583_Command cmd)
        {
            try
            {
                #region Live
                //if (cmd.CommandType == CommandTypeEnum.AuthorizationRequestMessage && (!string.IsNullOrEmpty(cmdData.ToAccountNumber)))
                //{
                //    SetRequiredFields(sourceMessage, cmd.MFields, FundTransfer);
                //}
                ////if (cmd.CommandType == CommandTypeEnum.ReversalAdviceRequestMessage)
                ////{
                ////    SetRequiredFields(sourceMessage, cmd.MFields, IssuerPartialReversal);
                ////}

                if (cmd.CommandType == CommandTypeEnum.AuthorizationRequestMessage)
                {
                    SetRequiredFields(sourceMessage, cmd.MFields, VASTransactions);
                }
                #endregion
            }
            catch (Exception ex)
            { }
        }
    }

}
