﻿using ImportData;
using System.Data;
using System.Data.OleDb;
using System.Reflection;
using Utility;

using Microsoft.VisualBasic;
using System;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.IO;
using System.Xml.Linq;
using Utility; 

namespace Master
{
    public class Master_Splitter
    { 
        private readonly string _connectionString;
        BulkImports bulkimports;
        public Master_Splitter(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        string TransactionReqDate = string.Empty;
        string TransactionDate = string.Empty;
        string CardNumber = string.Empty;
        string ReferenceNumber = string.Empty;
        string ReversalFlag = string.Empty;
        string TransactionID = string.Empty;
        string TerminalID = string.Empty;
        string TransactionType = string.Empty;
        string ProcessingCode = string.Empty;
        string ResponseCode = string.Empty;
        string TAmount = string.Empty;
        string ActualAmount = string.Empty;


        internal void variable<T>()
        {
            TransactionReqDate = string.Empty;
            TransactionDate = string.Empty;
            CardNumber = string.Empty;
            ReferenceNumber = string.Empty;
            ReversalFlag = string.Empty;
            TransactionID = string.Empty;
            TerminalID = string.Empty;
            TransactionType = string.Empty;
            ProcessingCode = string.Empty;
            ResponseCode = string.Empty;
            TAmount = string.Empty;
            ActualAmount = string.Empty;
        }
        public DataTable SplitData(string masterFilePath, string UserName, string BankCode, string FileName, string ConnectionString, out int InsertCount, out int TotalCount)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("CARDNO", typeof(string));
            _DataTable.Columns.Add("PROCESSINGCODE", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONAMT", typeof(double));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
            _DataTable.Columns.Add("APPROVALCODE", typeof(string));
            _DataTable.Columns.Add("REFERENCE", typeof(string));
            _DataTable.Columns.Add("TERMINAL", typeof(string));
            _DataTable.Columns.Add("NAME", typeof(string));
            _DataTable.Columns.Add("CURRENCY", typeof(string));
            _DataTable.Columns.Add("RATE", typeof(string));
            _DataTable.Columns.Add("SETTLEDATE", typeof(DateTime));
            _DataTable.Columns.Add("TYPE", typeof(string));
            _DataTable.Columns.Add("LOADDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRACE", typeof(string));
            _DataTable.Columns.Add("MEMCOMM", typeof(string));
            _DataTable.Columns.Add("Filename", typeof(string));
            _DataTable.Columns.Add("Responsecode", typeof(string));
            _DataTable.Columns.Add("Reservefileld2", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("CREATEDBY", typeof(string));
            _DataTable.Columns.Add("MODIFIEDBY", typeof(string));


            try
            {


                string CARDNO = string.Empty;
                string REFERENCE = string.Empty;
                string PROCESSINGCODE = string.Empty;
                string APPROVALCODE = string.Empty;
                DateTime TRANSACTIONDATE;
                DateTime SETTLEDATE;
                DateTime LOADDATE;
                double AMOUNT;
                string TERMINAL = string.Empty;
                string NAME = string.Empty;
                string RATE = string.Empty;
                string CURRENCY = string.Empty;
                string TYPE = string.Empty;
                //string LOADDATE = string.Empty;
                string TRACE = string.Empty;
                string ProcessCode = string.Empty;
                string MEMCOMM = string.Empty;
                string Reservefileld1 = string.Empty;
                string Reservefileld2 = string.Empty;

                // DataTable csvData = new DataTable();

                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                "Data Source=" + masterFilePath + ";Extended Properties=Excel 8.0;";
                string extension = System.IO.Path.GetExtension(masterFilePath);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + masterFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + masterFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        break;
                }
                objConn = new OleDbConnection(connString);
                objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                
                int j = 0;  

                OleDbCommand cmd = new OleDbCommand("SELECT * FROM [" + Convert.ToString(dtexcelsheetname.Rows[0]["TABLE_NAME"]).Replace("'", "") + "]", objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dtfillsheet1 = new DataTable();
                da.Fill(dtfillsheet1);

                //dtfillsheet1.Rows.RemoveAt(0);
                //dtfillsheet1.Rows.RemoveAt(dtfillsheet1.Rows.Count -1);
                objConn.Close();

                TotalCount = dtfillsheet1.Rows.Count;
                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {
                    try
                    {

                        CARDNO = dtfillsheet1.Rows[i][0].ToString();
                        PROCESSINGCODE = dtfillsheet1.Rows[i][1].ToString();
                        AMOUNT = Convert.ToDouble(dtfillsheet1.Rows[i][2].ToString());
                        TRANSACTIONDATE = Convert.ToDateTime(dtfillsheet1.Rows[i][3].ToString());

                        //   TRANSACTIONDATE = DateTime.ParseExact(dtfillsheet1.Rows[i][3].ToString(), new[] {"dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss", "dd/MM/yyyy HH:mm:ss tt", "dd/MM/yyyy hh:mm:ss tt", "d/MM/yyyy HH:mm:ss tt", "d/MM/yyyy hh:mm:ss tt" }, null, DateTimeStyles.AdjustToUniversal);

                        APPROVALCODE = dtfillsheet1.Rows[i][4].ToString();
                        REFERENCE = dtfillsheet1.Rows[i][5].ToString().Trim();
                        TERMINAL = dtfillsheet1.Rows[i][6].ToString();
                        NAME = dtfillsheet1.Rows[i][7].ToString();  //TYP
                        CURRENCY = dtfillsheet1.Rows[i][8].ToString();
                        RATE = dtfillsheet1.Rows[i][9].ToString();
                        SETTLEDATE = Convert.ToDateTime(dtfillsheet1.Rows[i][10].ToString());
                        //SETTLEDATE = DateTime.ParseExact(dtfillsheet1.Rows[i][10].ToString(), new[] { "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss", "dd/MM/yyyy HH:mm:ss tt", "dd/MM/yyyy hh:mm:ss tt", "d/MM/yyyy HH:mm:ss tt", "d/MM/yyyy hh:mm:ss tt" }, null, DateTimeStyles.AdjustToUniversal);
                        TYPE = dtfillsheet1.Rows[i][11].ToString(); //
                        LOADDATE = Convert.ToDateTime(dtfillsheet1.Rows[i][12].ToString());

                        //LOADDATE = DateTime.ParseExact(dtfillsheet1.Rows[i][12].ToString(), new[] { "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss", "dd/MM/yyyy HH:mm:ss tt", "dd/MM/yyyy hh:mm:ss tt", "d/MM/yyyy HH:mm:ss tt", "d/MM/yyyy hh:mm:ss tt" }, null, DateTimeStyles.AdjustToUniversal);
                        TRACE = dtfillsheet1.Rows[i][13].ToString(); //..AGENTTYPE1
                        MEMCOMM = dtfillsheet1.Rows[i][14].ToString(); //CurrencyCode
                        string Responsecode = "00";

                        _DataTable.Rows.Add(CARDNO, PROCESSINGCODE, AMOUNT, TRANSACTIONDATE, APPROVALCODE,
                            REFERENCE, TERMINAL, NAME, CURRENCY, RATE, SETTLEDATE, TYPE,
                            LOADDATE, TRACE, MEMCOMM, FileName, Responsecode, Reservefileld1, System.DateTime.Now, System.DateTime.Now); //TransStatus, TransDescription);
                        InsertCount++;

                    }
                    catch (Exception EX)
                    {
                        //_DataTable.Rows.Clear();
                        DBLog.InsertLogs(EX.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

                        // DBLog.InsertLogs(EX.Message.ToString(), BankCode, "Master_Splitter", "SplitData", LineNo, FileName, UserName, 'E', _connectionString);
                        // variable();
                    }

                }
                if (_DataTable.Rows.Count == 0)
                {
                    // InsertCount--;
                    DBLog.InsertLogs("Transaction not found", BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    //DBLog.InsertLogs("Transaction not found", BankCode, "Master_Splitter", "SplitData", LineNo, FileName, UserName, 'E', _connectionString);
                    // variable();
                }
                TotalCount++;
            }
            catch (Exception EX)
            {
                //_DataTable.Rows.Clear();
                DBLog.InsertLogs(EX.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                //  variable();
            }
            return _DataTable;
        }


        public DataTable SpliterAcquirerExcel(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DataTable _DataTable = new DataTable();

            DateTime CreatedDt = DateTime.Now;
            string CreatedDate = CreatedDt.Day.ToString() + "-" + CreatedDt.ToString("MMM") + "-" + CreatedDt.ToString("yy") + CreatedDt.ToString(" hh.mm.ss tt");

            int LineNo = 0;

            InsertCount = 0;
            TotalCount = 0;

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSMODE", typeof(string));
            _DataTable.Columns.Add("PROCESSORID", typeof(string));
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(DateTime));
            _DataTable.Columns.Add("PROCESSINGCODE", typeof(string));
            _DataTable.Columns.Add("TRACENO", typeof(string));
            _DataTable.Columns.Add("POSENTRY", typeof(double));
            _DataTable.Columns.Add("REFNO", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("CURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("AMOUNT", typeof(string));
            _DataTable.Columns.Add("DR_CR", typeof(string));
            _DataTable.Columns.Add("ACTUALAMOUNT", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));

            try
            {
                string[] LogFile = new string[1024];
                int _TotalRows = 0;


                string CARDNO = string.Empty;
                string REFERENCE = string.Empty;
                string PROCESSINGCODE = string.Empty;
                string APPROVALCODE = string.Empty;
                string TRANSACTIONDATE;
                DateTime SETTLEDATE;
                DateTime LOADDATE;
                double AMOUNT;
                string TERMINAL = string.Empty;
                string NAME = string.Empty;
                string RATE = string.Empty;
                string CURRENCY = string.Empty;
                string TYPE = string.Empty;
                //string LOADDATE = string.Empty;
                string TRACE = string.Empty;
                string ProcessCode = string.Empty;
                string MEMCOMM = string.Empty;
                string Responsecode = string.Empty;
                string Reservefileld1 = string.Empty;

                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
                int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());
                int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());

                string month = string.Empty;
                string date = string.Empty;
                string Year = string.Empty;
                string hour = string.Empty;
                string min = string.Empty;
                string sec = string.Empty;
                string TimestampCreator = string.Empty;
                DateTime TimeStamp;
                double stramnt = 0;

               
                LogFile = null;
                LogFile = new string[1024];
                _TotalRows = 0;
                LogFile = File.ReadAllLines(path, System.Text.Encoding.Default);

                string CardScheme = "Master";
                string IssuingNetwork = "Master";
                string ECardNumber = string.Empty;


                

                
                
                
                

                OleDbConnection objConn = null;
                DataTable dtexcelsheetname = null;
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                string extension = System.IO.Path.GetExtension(path);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                        connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        break;
                }
                objConn = new OleDbConnection(connString);
                objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count]; 

                OleDbCommand cmd = new OleDbCommand("SELECT * FROM [" + Convert.ToString(dtexcelsheetname.Rows[0]["TABLE_NAME"]).Replace("'", "") + "]", objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dtfillsheet1 = new DataTable();
                da.Fill(dtfillsheet1);

                //dtfillsheet1.Rows.RemoveAt(0);
                //dtfillsheet1.Rows.RemoveAt(dtfillsheet1.Rows.Count -1);
                objConn.Close();

                TotalCount = dtfillsheet1.Rows.Count;
                 
                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {
                    try
                    { 
                        CARDNO = dtfillsheet1.Rows[i][0].ToString();
                        PROCESSINGCODE = dtfillsheet1.Rows[i][1].ToString();
                        AMOUNT = Convert.ToDouble(dtfillsheet1.Rows[i][2].ToString());
                        TRANSACTIONDATE = dtfillsheet1.Rows[i][3].ToString(); 

                        APPROVALCODE = dtfillsheet1.Rows[i][4].ToString();
                        REFERENCE = dtfillsheet1.Rows[i][5].ToString().Trim();
                        TERMINAL = dtfillsheet1.Rows[i][6].ToString();
                        NAME = dtfillsheet1.Rows[i][7].ToString();  //TYP
                        CURRENCY = dtfillsheet1.Rows[i][8].ToString();
                        RATE = dtfillsheet1.Rows[i][9].ToString();
                        //SETTLEDATE = Convert.ToDateTime(dtfillsheet1.Rows[i][10].ToString());
                        //SETTLEDATE = DateTime.ParseExact(dtfillsheet1.Rows[i][10].ToString(), new[] { "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss", "dd/MM/yyyy HH:mm:ss tt", "dd/MM/yyyy hh:mm:ss tt", "d/MM/yyyy HH:mm:ss tt", "d/MM/yyyy hh:mm:ss tt" }, null, DateTimeStyles.AdjustToUniversal);
                        TYPE = dtfillsheet1.Rows[i][11].ToString(); //
                        //LOADDATE = Convert.ToDateTime(dtfillsheet1.Rows[i][12].ToString());

                        //LOADDATE = DateTime.ParseExact(dtfillsheet1.Rows[i][12].ToString(), new[] { "dd-MM-yyyy HH:mm:ss", "dd-MM-yyyy hh:mm:ss", "dd/MM/yyyy HH:mm:ss tt", "dd/MM/yyyy hh:mm:ss tt", "d/MM/yyyy HH:mm:ss tt", "d/MM/yyyy hh:mm:ss tt" }, null, DateTimeStyles.AdjustToUniversal);
                        TRACE = dtfillsheet1.Rows[i][13].ToString(); //..AGENTTYPE1
                        MEMCOMM = dtfillsheet1.Rows[i][14].ToString(); //CurrencyCode

                        Responsecode = "00";

                        if (CARDNO != "")
                        {
                            ECardNumber = AesEncryption.EncryptString(CARDNO);
                        }

                        CardScheme = "MASTER";
                        IssuingNetwork = "MASTER";

                        _DataTable.Rows.Add(ClientID, ChannelID, ModeID, CARDNO, TYPE, "", APPROVALCODE, DateTime.ParseExact(TRANSACTIONDATE, "M/d/yyyy h:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture), PROCESSINGCODE, TRACE, "0", REFERENCE, TERMINAL, Responsecode, CURRENCY,  AMOUNT,  "DR", AMOUNT,
                         FileName, path , System.DateTime.Now, System.DateTime.Now, System.DateTime.Now, UserName, UserName, ECardNumber, IssuingNetwork, CardScheme); //TransStatus, TransDescription);
                  

                        InsertCount++;
 
                        LineNo++;

                    }
                    catch
                    {
                        
                    }

                }

                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                    TotalCount = LineNo;
                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                //objLogWriter.FunErrorLog(ex.Message.ToString(), BankCode, "ProcessvisaacqFileSpliter", "ProcessvisaacqFileSpliter", LineNo, FileName, UserName, 'E');
            }

            return _DataTable;
        }


        public DataTable SpliterAcquirer(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DataTable _DataTable = new DataTable();

            DateTime CreatedDt = DateTime.Now;
            string CreatedDate = CreatedDt.Day.ToString() + "-" + CreatedDt.ToString("MMM") + "-" + CreatedDt.ToString("yy") + CreatedDt.ToString(" hh.mm.ss tt");

            int LineNo = 0;

            InsertCount = 0;
            TotalCount = 0;

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSMODE", typeof(string));
            _DataTable.Columns.Add("PROCESSORID", typeof(string));
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(DateTime)); 
            _DataTable.Columns.Add("PROCESSINGCODE", typeof(string));
            _DataTable.Columns.Add("TRACENO", typeof(string));
            _DataTable.Columns.Add("POSENTRY", typeof(double));
            _DataTable.Columns.Add("REFNO", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("CURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("AMOUNT", typeof(string));
            _DataTable.Columns.Add("DR_CR", typeof(string));
            _DataTable.Columns.Add("ACTUALAMOUNT", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));

            try
            {
                string[] LogFile = new string[1024];
                int _TotalRows = 0,   i = 0; 

                
                string _TotalRecordsRow = string.Empty;
                string _TRANSTYPE = string.Empty;
                string _TRANSMODE = string.Empty;
                string _PROCESSORID = string.Empty;
                string _TR_TIMESTAMP = string.Empty;
                string _ACCNO = string.Empty;
                string _PROCESSINGCODE = string.Empty;
                string _TRACENO = string.Empty;
                string _POSENTRY = string.Empty;
                string _REFNO = string.Empty;
                string _TERMINALID = string.Empty;
                string _RESPONSECODE = string.Empty;
                string _CURRENCYCODE = string.Empty;
                string _AMOUNT = string.Empty;
                string _DR_CR = string.Empty;
                string _ActualAmmt = string.Empty;
                double mainamount;
                double amount = 0;
                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
                int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());
                int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());

                string month = string.Empty;
                string date = string.Empty;
                string Year = string.Empty;
                string hour = string.Empty;
                string min = string.Empty;
                string sec = string.Empty;
                string TimestampCreator= string.Empty;
                DateTime TimeStamp;
                double stramnt = 0;

                i = 0;
                LogFile = null;
                LogFile = new string[1024];
                _TotalRows = 0;
                LogFile = File.ReadAllLines(path, System.Text.Encoding.Default);

                string CardScheme = "Master";
                string IssuingNetwork = "Master";
                string ECardNumber = string.Empty;


                

                
                
                
                

                _TotalRows = LogFile.Length;
                while (i < _TotalRows - 1)
                {
                    try
                    {
                        _TotalRecordsRow = LogFile[i].Substring(0, 249).ToString();

                        if (_TotalRecordsRow.Contains("FREC"))
                        {
                            _TotalRecordsRow = LogFile[i] + LogFile[i + 1] + LogFile[i + 2] + LogFile[i + 3];
                            _TRANSTYPE = _TotalRecordsRow.Substring(0, 4);
                            _TRANSMODE = _TotalRecordsRow.Substring(13, 1);
                            _PROCESSORID = _TotalRecordsRow.Substring(14, 4);
                            _TR_TIMESTAMP = _TotalRecordsRow.Substring(18, 12);

                            month = _TR_TIMESTAMP.Substring(0, 2).ToString();
                            date = _TR_TIMESTAMP.Substring(2, 2).ToString();
                            Year = _TR_TIMESTAMP.Substring(4, 2);
                            hour = _TR_TIMESTAMP.Substring(6, 2);
                            min = _TR_TIMESTAMP.Substring(8, 2);
                            sec = _TR_TIMESTAMP.Substring(10, 2);
                            TimestampCreator = date + "-" + month + "-" + Year + " " + hour + ":" + min + ":" + sec;

                            //TimeStamp = Convert.ToDateTime(DateTime.ParseExact(TimestampCreator, "dd-MM-yy HH:mm:ss", CultureInfo.InvariantCulture));
                            TimeStamp = DateTime.ParseExact(TimestampCreator, "dd-MM-yy HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                            //DateTime TimeStamp = DateTime.ParseExact(TimestampCreator, "dd-MM-yy HH:mm:ss");
                            _ACCNO = _TotalRecordsRow.Substring(32, 19);
                            _PROCESSINGCODE = _TotalRecordsRow.Substring(51, 6);
                            _TRACENO = _TotalRecordsRow.Substring(57, 6);
                            _POSENTRY = _TotalRecordsRow.Substring(67, 3);
                            _REFNO = _TotalRecordsRow.Substring(70, 12);
                            _TERMINALID = _TotalRecordsRow.Substring(92, 10);
                            _RESPONSECODE = _TotalRecordsRow.Substring(102, 2);
                            _CURRENCYCODE = _TotalRecordsRow.Substring(124, 3);
                            mainamount = double.Parse(_TotalRecordsRow.Substring(129, 9));
                            _AMOUNT = Convert.ToString(mainamount);

                            _DR_CR = _TotalRecordsRow.Substring(153, 1);

                            stramnt = mainamount % 100;

                            if (stramnt == 20.0)
                            {
                                amount = Convert.ToDouble(_AMOUNT.Trim()) - 20;
                            }
                            else if (stramnt == 50.0)
                            {
                                amount = Convert.ToDouble(_AMOUNT.Trim()) - 150;
                            }
                            else
                            {
                                amount = Convert.ToDouble(_AMOUNT.Trim());
                            }

                            if (_ACCNO != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(_ACCNO);
                            }

                            if (_ACCNO != "")
                            {
                                _ACCNO = _ACCNO.Substring(0, 6) + "XXXXXXXXXXXXXXX".Substring(1, _ACCNO.Length - 10) + _ACCNO.Substring(_ACCNO.Length - 4, 4);
                            }

                            _DataTable.Rows.Add(ClientID, ChannelID, ModeID, _ACCNO.Trim(), _TRANSTYPE.Trim(), _TRANSMODE.Trim(), _PROCESSORID.Trim(), TimeStamp, _PROCESSINGCODE.Trim(), _TRACENO.Trim(), _POSENTRY.Trim(), _REFNO.Trim(), _TERMINALID.Trim(), _RESPONSECODE.Trim(), _CURRENCYCODE.Trim(), _AMOUNT.ToString(), _DR_CR.Trim(), amount, FileName, path, null, CreatedDt, null, UserName, null, ECardNumber, IssuingNetwork, CardScheme);



                        }
                        i = i + 1;
                        LineNo++;

                    }
                    catch
                    {
                        i = i + 1;
                        // LineNo;
                        //ErrorLine++;
                        //_frmErrorLog.FunErrorLog(ex.Message.ToString(), "AutoRecon", "VisaMasterUploadForm", "GetDataVisaAcquirerCSVFile", (i), VisaFilePath, UserName.ToString(), 'T');

                    }

                }

                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                    TotalCount = LineNo;
                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                //objLogWriter.FunErrorLog(ex.Message.ToString(), BankCode, "ProcessvisaacqFileSpliter", "ProcessvisaacqFileSpliter", LineNo, FileName, UserName, 'E');
            }

            return _DataTable;
        }

        public DataTable SplitterT464(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            LogWriter log = new LogWriter();
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("MessageTypeIndicator", typeof(string));
            _DataTable.Columns.Add("SwitchSerialNumber", typeof(string));
            _DataTable.Columns.Add("ProcessorAcquirerORIssuer", typeof(string));
            _DataTable.Columns.Add("ProcessorID", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("PANLength", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("TraceNumber", typeof(string));
            _DataTable.Columns.Add("MerchantType", typeof(string));
            _DataTable.Columns.Add("POSEntry", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("AcquirerInstitutionID", typeof(string));
            _DataTable.Columns.Add("TerminalID", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("ProductCode", typeof(string));
            _DataTable.Columns.Add("AdviceReasonCode", typeof(string));
            _DataTable.Columns.Add("ISISAgreementCode", typeof(string));
            _DataTable.Columns.Add("AuthorizationID", typeof(string));
            _DataTable.Columns.Add("CurrencyCodeTxns", typeof(string));
            _DataTable.Columns.Add("ImpliedDecimalTxns", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("CompletedAmtTxnsLocalDRCRIndicator", typeof(string));
            _DataTable.Columns.Add("CashBackAmtLocal", typeof(decimal));
            _DataTable.Columns.Add("CashBackAmtLocalDRCRIndicator", typeof(string));
            _DataTable.Columns.Add("AccessFeeLocal", typeof(decimal));
            _DataTable.Columns.Add("AccessFeeLocalDRCRIndicator", typeof(string));
            _DataTable.Columns.Add("CurrencyCodeSettlement", typeof(string));
            _DataTable.Columns.Add("ImpliedDecimalSettlement", typeof(string));
            _DataTable.Columns.Add("ConversionRateSettlement", typeof(decimal));
            _DataTable.Columns.Add("CompletedAmtSettlement", typeof(decimal));
            _DataTable.Columns.Add("CompletedAmtStlmntDRCRIndicator", typeof(string));
            _DataTable.Columns.Add("InterchangeFee", typeof(decimal));
            _DataTable.Columns.Add("InterchangeFeeDRCRIndicator", typeof(string));
            _DataTable.Columns.Add("ReservedforFutureUse1", typeof(string));
            _DataTable.Columns.Add("ReservedforFutureUse2", typeof(string));
            _DataTable.Columns.Add("ReservedforFutureUse3", typeof(string));
            _DataTable.Columns.Add("ReservedforFutureUse4", typeof(string));
            _DataTable.Columns.Add("PositiveIDIndicator", typeof(string));
            _DataTable.Columns.Add("FutureServiceFiller", typeof(string));
            _DataTable.Columns.Add("CrossBorderIndicator", typeof(string));
            _DataTable.Columns.Add("CrossBorderCurrencyIndicator", typeof(string));
            _DataTable.Columns.Add("VISAIntlServiceAssessmentFeeIndicator", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));



            DateTime CreatedDt = DateTime.Now;
            string CreatedDate = CreatedDt.Day.ToString() + "-" + CreatedDt.ToString("MMM") + "-" + CreatedDt.ToString("yy") + CreatedDt.ToString(" hh.mm.ss tt");


            TotalCount = 0;
            InsertCount = 0;
            //frmErrorLog _frmErrorLog = new frmErrorLog();
            int LineNo = 0;
            int ErrorLine = 0;
            try
            {

                

                
                
                
                

                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

                string[] LogFile = new string[1024];
                int _TotalRows = 0, _Rownumber = 0;
                int i = 0;
                string _TotalRecordsRow = string.Empty;

                int _RecordID = 0;
                string MessageTypeIndicator = string.Empty;
                string SwitchSerialNumber = string.Empty;
                string ProcessorAcquirerORIssuer = string.Empty;
                string ProcessorID = string.Empty;
                DateTime TxnsDateTime = new DateTime();
                string PANLength = string.Empty;
                string CardNumber = string.Empty;
                string ProcessingCode = string.Empty;
                string TraceNumber = string.Empty;
                string MerchantType = string.Empty;
                string POSEntry = string.Empty;
                string ReferenceNumber = string.Empty;
                string AcquirerInstitutionID = string.Empty;
                string TerminalID = string.Empty;
                string ResponseCode = string.Empty;
                string ProductCode = string.Empty;
                string AdviceReasonCode = string.Empty;
                string ISISAgreementCode = string.Empty;
                string AuthorizationID = string.Empty;
                string CurrencyCodeTxns = string.Empty;
                string ImpliedDecimalTxns = string.Empty;
                decimal TxnsAmount = 0;
                string CompletedAmtTxnsLocalDRCRIndicator = string.Empty;
                decimal CashBackAmtLocal = 0;
                string CashBackAmtLocalDRCRIndicator = string.Empty;
                decimal AccessFeeLocal = 0;
                string AccessFeeLocalDRCRIndicator = string.Empty;
                string CurrencyCodeSettlement = string.Empty;
                string ImpliedDecimalSettlement = string.Empty;
                decimal ConversionRateSettlement = 0;
                decimal CompletedAmtSettlement = 0;
                string CompletedAmtStlmntDRCRIndicator = string.Empty;
                decimal InterchangeFee = 0;
                string InterchangeFeeDRCRIndicator = string.Empty;
                string ReservedforFutureUse1 = string.Empty;
                string ReservedforFutureUse2 = string.Empty;
                string ReservedforFutureUse3 = string.Empty;
                string ReservedforFutureUse4 = string.Empty;
                string PositiveIDIndicator = string.Empty;
                string FutureServiceFiller = string.Empty;
                string CrossBorderIndicator = string.Empty;
                string CrossBorderCurrencyIndicator = string.Empty;
                string VISAIntlServiceAssessmentFeeIndicator = string.Empty;
                string ECardNumber = string.Empty;
                string CardScheme = string.Empty;
                string IssuingNetwork = string.Empty;
                string CardType = string.Empty;
                string FilePath = string.Empty;
                DateTime FileDate = new DateTime();
                DateTime CreatedOn = new DateTime();
                DateTime ModifiedOn = new DateTime();
                string CreatedBy = string.Empty;
                string ModifiedBy = string.Empty;
                string StrTxnsDateTime = string.Empty;
                string StrTxnsAmount = string.Empty;
                string StrCashBackAmtLocal = string.Empty;
                string StrAccessFeeLocal = string.Empty;
                string StrConversionRateSettlement = string.Empty;
                string StrCompletedAmtSettlement = string.Empty;
                string StrInterchangeFee = string.Empty;
                int ModeID = 0;
                int ChannelID = 0;


                i = 0;
                LogFile = null;
                LogFile = new string[1024];
                _TotalRows = 0;
                LogFile = File.ReadAllLines(path, System.Text.Encoding.Default);

                _TotalRows = LogFile.Length;
                TotalCount = LogFile.Length;
                while (i < _TotalRows)
                {
                    try
                    {
                        _TotalRecordsRow = LogFile[i].ToString();



                        if (_TotalRecordsRow.StartsWith("FREC") || _TotalRecordsRow.StartsWith("EREC") || _TotalRecordsRow.StartsWith("NREC"))
                        {
                            MessageTypeIndicator = _TotalRecordsRow.Substring(0, 4).Trim();
                            SwitchSerialNumber = _TotalRecordsRow.Substring(4, 9).Trim();
                            ProcessorAcquirerORIssuer = _TotalRecordsRow.Substring(13, 1).Trim();
                            if (ProcessorAcquirerORIssuer == "A")
                            {
                                ModeID = 2;
                            }
                            else
                            {
                                ModeID = 3;
                            }
                            ProcessorID = _TotalRecordsRow.Substring(14, 4).Trim();
                            StrTxnsDateTime = _TotalRecordsRow.Substring(18, 6).Trim();
                            StrTxnsDateTime = StrTxnsDateTime + _TotalRecordsRow.Substring(24, 6).Trim();
                            TxnsDateTime = DateTime.ParseExact(StrTxnsDateTime, "MMddyyHHmmss", null);
                            PANLength = _TotalRecordsRow.Substring(30, 2).Trim();
                            CardNumber = _TotalRecordsRow.Substring(32, 19).Trim();
                            ProcessingCode = _TotalRecordsRow.Substring(51, 6).Trim();
                            TraceNumber = _TotalRecordsRow.Substring(57, 6).Trim();
                            MerchantType = _TotalRecordsRow.Substring(63, 4).Trim();
                            if (MerchantType == "6011")
                            {
                                ChannelID = 1;
                            }
                            else
                            {
                                ChannelID = 2;
                            }
                            POSEntry = _TotalRecordsRow.Substring(67, 3).Trim();
                            ReferenceNumber = _TotalRecordsRow.Substring(70, 12).Trim();
                            AcquirerInstitutionID = _TotalRecordsRow.Substring(82, 10).Trim();
                            TerminalID = _TotalRecordsRow.Substring(92, 10).Trim();
                            ResponseCode = _TotalRecordsRow.Substring(102, 2).Trim();
                            ProductCode = _TotalRecordsRow.Substring(104, 3).Trim();
                            AdviceReasonCode = _TotalRecordsRow.Substring(107, 7).Trim();
                            ISISAgreementCode = _TotalRecordsRow.Substring(114, 4).Trim();
                            AuthorizationID = _TotalRecordsRow.Substring(118, 6).Trim();
                            CurrencyCodeTxns = _TotalRecordsRow.Substring(124, 3).Trim();
                            ImpliedDecimalTxns = _TotalRecordsRow.Substring(127, 1).Trim();
                            StrTxnsAmount = _TotalRecordsRow.Substring(128, 12).Trim();
                            TxnsAmount = Convert.ToInt16(StrTxnsAmount) / 100;
                            CompletedAmtTxnsLocalDRCRIndicator = _TotalRecordsRow.Substring(140, 1).Trim();
                            StrCashBackAmtLocal = _TotalRecordsRow.Substring(141, 12).Trim();
                            CashBackAmtLocal = Convert.ToInt16(StrCashBackAmtLocal) / 100; ;
                            CashBackAmtLocalDRCRIndicator = _TotalRecordsRow.Substring(153, 1).Trim();
                            StrAccessFeeLocal = _TotalRecordsRow.Substring(154, 8).Trim();
                            AccessFeeLocal = Convert.ToInt16(AccessFeeLocal) / 100;
                            AccessFeeLocalDRCRIndicator = _TotalRecordsRow.Substring(162, 1).Trim();
                            CurrencyCodeSettlement = _TotalRecordsRow.Substring(163, 3).Trim();
                            ImpliedDecimalSettlement = _TotalRecordsRow.Substring(166, 1).Trim();
                            StrConversionRateSettlement = _TotalRecordsRow.Substring(167, 8).Trim();
                            ConversionRateSettlement = Convert.ToInt16(ConversionRateSettlement) / 100;
                            StrCompletedAmtSettlement = _TotalRecordsRow.Substring(175, 12).Trim();
                            CompletedAmtSettlement = Convert.ToInt16(StrCompletedAmtSettlement) / 100;
                            CompletedAmtStlmntDRCRIndicator = _TotalRecordsRow.Substring(187, 1).Trim();
                            StrInterchangeFee = _TotalRecordsRow.Substring(188, 10).Trim();
                            InterchangeFee = Convert.ToInt16(StrInterchangeFee) / 100;
                            InterchangeFeeDRCRIndicator = _TotalRecordsRow.Substring(198, 1).Trim();
                            ReservedforFutureUse1 = _TotalRecordsRow.Substring(199, 3).Trim();
                            ReservedforFutureUse2 = _TotalRecordsRow.Substring(202, 1).Trim();
                            ReservedforFutureUse3 = _TotalRecordsRow.Substring(203, 10).Trim();
                            ReservedforFutureUse4 = _TotalRecordsRow.Substring(213, 1).Trim();
                            PositiveIDIndicator = _TotalRecordsRow.Substring(214, 1).Trim();
                            FutureServiceFiller = _TotalRecordsRow.Substring(215, 1).Trim();
                            CrossBorderIndicator = _TotalRecordsRow.Substring(216, 1).Trim();
                            CrossBorderCurrencyIndicator = _TotalRecordsRow.Substring(217, 1).Trim();
                            VISAIntlServiceAssessmentFeeIndicator = _TotalRecordsRow.Substring(218, 1).Trim();

                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);
                            }

                            if (CardNumber != "")
                            { 
                                CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                            }

                            CardScheme = "MASTER";
                            IssuingNetwork = "MASTER";
                            CardType = "Debit";

                            _DataTable.Rows.Add(ClientID, ChannelID, ModeID, MessageTypeIndicator, SwitchSerialNumber, ProcessorAcquirerORIssuer, ProcessorID, TxnsDateTime, PANLength, CardNumber, ProcessingCode, TraceNumber, MerchantType, POSEntry, ReferenceNumber, AcquirerInstitutionID, TerminalID, ResponseCode, ProductCode, AdviceReasonCode, ISISAgreementCode, AuthorizationID, CurrencyCodeTxns, ImpliedDecimalTxns, TxnsAmount, CompletedAmtTxnsLocalDRCRIndicator, CashBackAmtLocal, CashBackAmtLocalDRCRIndicator, AccessFeeLocal, AccessFeeLocalDRCRIndicator, CurrencyCodeSettlement, ImpliedDecimalSettlement, ConversionRateSettlement, CompletedAmtSettlement, CompletedAmtStlmntDRCRIndicator, InterchangeFee, InterchangeFeeDRCRIndicator, ReservedforFutureUse1, ReservedforFutureUse2, ReservedforFutureUse3, ReservedforFutureUse4, PositiveIDIndicator, FutureServiceFiller, CrossBorderIndicator, CrossBorderCurrencyIndicator, VISAIntlServiceAssessmentFeeIndicator, ECardNumber, CardScheme, IssuingNetwork, CardType, FileName, path, System.DateTime.Now, System.DateTime.Now, null, UserName, null);


                        }

                        i++;
                    }
                    catch (Exception ex)
                    {
                        i++;
                        ErrorLine++;
                    }

                }

                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            return _DataTable;

        }



    }
}
