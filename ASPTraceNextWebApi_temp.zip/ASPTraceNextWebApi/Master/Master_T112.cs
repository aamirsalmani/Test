﻿using System;  
using System.Data;
using System.IO;
using System.Linq;
using Utility;

namespace Master
{
    public class Master_T112
    { 
        private readonly string _connectionString;
        public Master_T112(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
        }

        public DataTable SplitDataT112(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            DataTable dt1 = new DataTable();


            InsertCount = 0;
            TotalCount = 0;
            int Srnoindex = -1;
            try
            {
                byte[] ebcdicData = File.ReadAllBytes(path);
                string HexData = Utils.ByteArrayToHex(ebcdicData);
                string AsciiData = Utils.ByteArrayToASCII(ebcdicData);
                AsciiData = AsciiData.Replace("@@", string.Empty);
                string[] Processmsg = Process_MultiRequest.MultiRequest(AsciiData);
                string[] HexProcess = new string[10000];
                for (int i = 0; i < Processmsg.Length; i++)
                {
                    HexProcess[i] = "0000" + Utils.ByteArrayToHex(Utils.ASCIIToByteArray(Processmsg[i].ToString()));
                }



                HexProcess = HexProcess.Where(x => !string.IsNullOrEmpty(x)).ToArray();

                for (int i = 0; i < HexProcess.Length; i++)
                {
                    Srnoindex = i + 1;

                    InitialiseDataProcessor(HexProcess[i], Srnoindex, ref dt1);
                }

            }
            catch (Exception ex)
            {

            }

            Srnoindex = -1;

            if (dt1.Rows.Count > 0)
            {
                InsertCount = dt1.Rows.Count;
                TotalCount = dt1.Rows.Count;
            }

            return dt1;

        }

        ISO8583MessageParser mParser = null;
        public ISO8583MessageParser MParser
        {
            get
            {
                if (mParser == null)
                {
                    //if (FldType.SelectedIndex == 0)
                    //    mParser = new ISO8583MessageParser(new ISO8583_1987Formatter_IBTG_BANCS());
                    //else
                    mParser = new ISO8583MessageParser(new ISO8583_1987Formatter_IBTG_HOST());
                }
                return mParser;
            }
            set { mParser = value; }
        }

        private void InitialiseDataProcessor(string RawMessage, int Srnoindex, ref DataTable dt)
        {
            try
            {


                //ConfigurationManager.RefreshSection("appSettings");
                if (RawMessage.Length > 9)
                {
                    ProcessData(Utils.HexToByteArray(RawMessage), Srnoindex, ref dt);
                }
            }
            catch (Exception ex)
            { //WriteLogEntry(this, ex);
            }
        }

        private void ProcessData(byte[] rawMsg, int Srnoindex, ref DataTable dt)
        {
            //ConfigurationManager.RefreshSection("appSettings");

            try
            {
                string s = Utils.ByteArrayToHex(rawMsg);
                byte[] raw = Utils.ASCIIToByteArray(s);
                ISO8583Message isoMsg = MParser.Unpack(rawMsg, Srnoindex, ref dt);
            }
            catch (Exception ex)
            {

                //WriteLogEntry("Error Occured in the ProcessData Module :- " + ex.ToString() + ex.StackTrace.ToString() + ex.Source.ToString()); 

            }
        }

    }
}
