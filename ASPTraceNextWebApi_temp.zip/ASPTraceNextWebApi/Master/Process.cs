﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;


namespace Master
{
    public enum ISO8583VersionEnum
    {
        ISO8583_1987,
        ISO8583_1993,
        ISO8583_2003,
    }
    public enum ProcessingCodes : int
    {
        BE = 31,
        WDL = 01,
        RequestTrans = 90,
        HostMiniStat = 38,
    }
    public enum RequestTransaction : int
    {
        Unknown = -1,
        MiniStatement = 07,
        PinChange = 08,
    }
    public enum ModeOfTransaction
    {
        Unknown,
        Issuer,
        Acquirer,
    }
    public enum NetworkMsgType
    {
        Login = 0,
        LogOFF = 1,
        Ecco = 2,
    }
    public enum ISO8583FieldLengthTypeEnum : int
    {
        ISO8583_FIXED = 0,      /* Fixed              */
        ISO8583_LVAR = 1,      /* Variable - 0..9   */
        ISO8583_LLVAR = 2,      /* Variable - 0..99   */
        ISO8583_LLLVAR = 3,     /* Variable - 0..999  */
        ISO8583_LLLLVAR = 4,    /* Variable - 0..9999 */
    }
    public enum ISO8583FieldTypeEnum : int
    {
        ISO8583_N = 0,          /* Numeric values only */
        ISO8583_A = 1,          /* Alpha, including blanks */
        ISO8583_S = 2,          /* Special characters only */
        ISO8583_AN = 3,         /* Alphanumeric */
        ISO8583_AS = 4,         /* Alpha & special characters only */
        ISO8583_NS = 5,         /* Numeric and special characters only */
        ISO8583_ANS = 6,        /* Alphabetic, numeric and special characters */
        ISO8583_B = 7,          /* Binary data*/
        ISO8583_Z = 8,          /* Tracks 2 and 3 code set as defined in ISO/IEC 7813 and ISO/IEC 4909 respectively */
        ISO8583_XN = 9,         /* */
        ISO8583_ANSB = 10,      /* */
        ISO8583_ANP = 11,       /* */
        ISO8583_BMP = 12,       /* */
    }

    public enum ISO8583FieldEncryptionDecryptionEnum : int
    {
        ISO8583_Encryption = 0,
        ISO8583_Decryption = 1,
    }

    public enum CommandTypeEnum : int
    {

        Unknown = 0,
        AuthorizationRequestMessage = 1,
        AuthorizationResponseMessage = 2,
        ReversalAdviceRequestMessage = 3,
        ReversalAdviceResponseMessage = 4,
        NetworkManagementRequestsMessages = 5,
        NetworkManagementResponseMessages = 6,
        AccountingAuthorizationRequestMessage = 7,
        AccountingAuthorizationResponseMessage = 8,
        AccountingReversalAdviceRequestMessage = 9,
        AccountingReversalAdviceResponseMessage = 10,
        ReversalAdviceRequestRepeatMessage = 11,
        DMSAuthorizationRequestMessage = 12,
        DMSAuthorizationResponseMessage = 13,
        MST1AuthorizationRequestMessage = 14,
        MST2AuthorizationResponseMessage = 15,
        MST3Firstchargeback = 16,


    }

    public static class Process_MultiRequest
    {

        public static string[] MultiRequest_Chetan(string Message)
        {
            ArrayList TagValueWithAscii1 = new ArrayList();
            ArrayList TagValueWithAscii = new ArrayList();

            //string[] TagValueWithAscii1 = new string[100];
            //string[] TagValueWithAscii = new string[100];
            List<int> TagIndex = GetTagPosition(Message, "1240");  //1240
            List<int> TagIndex1 = GetTagPosition(Message, "1644"); //1644
            TagIndex.AddRange(TagIndex1);
            TagIndex.Sort();

            string[] RequestProcessData = new string[TagIndex.Count];

            string[] RequestProcessFinalData = new string[100];
            int L = 0;
            for (int i = 0; i < TagIndex.Count; i++)
            {
                //TagValueWithAscii1[i] = Message.Substring(TagIndex[i] - 2, 5);
                TagValueWithAscii1.Add(Message.Substring(TagIndex[i] - 2, 5));

            }
            for (int intCounter = 0; intCounter < TagValueWithAscii1.Count; intCounter++)
            {
                object row = TagValueWithAscii1[intCounter];

                Regex regex = new Regex(@"^[a-zA-Z]+$^-?\d+$");
                Match match = regex.Match(row.ToString().Substring(0, 1));
                if (match.Success)
                {

                }
                else
                {
                    TagValueWithAscii.Add(Convert.ToString(row));
                }

            }
            string[] TagValueWithAsciiArry = (string[])TagValueWithAscii.ToArray(typeof(string));
            RequestProcessData = Message.Split(TagValueWithAsciiArry, StringSplitOptions.None);


            for (int j = 1; j < RequestProcessData.Length; j++)
            {
                if (!RequestProcessData[j].Contains(Convert.ToString(TagValueWithAscii[0])))
                {
                    RequestProcessData[j] = TagValueWithAscii[j - 1] + RequestProcessData[j];
                }
            }
            return RequestProcessData;



        }

        public class SocketClientDataReceivedEventArgs : SocketClientEventArgs
        {
            public byte[] Message
            {
                get;
                private set;
            }
            public SocketClientDataReceivedEventArgs(string id, byte[] msg)
                : base(id)
            {
                this.Message = msg;
            }
        }

        public class SocketClientEventArgs : EventArgs
        {
            public string ID
            {
                get;
                private set;
            }
            public SocketClientEventArgs(string id)
            {
                this.ID = id;
            }
        }

        public static string[] MultiRequest(string Message)
        {
            string[] TagValueWithAscii1 = new string[1000];
            string[] TagValueWithAscii = new string[1000];
            List<int> TagIndex = GetTagPosition(Message, "1644");
            List<int> TagIndex1 = GetTagPosition(Message, "1240");
            List<int> TagIndex2 = GetTagPosition(Message, "1442");
            TagIndex.AddRange(TagIndex1);
            TagIndex.AddRange(TagIndex2);
            TagIndex.Sort();
            string[] RequestProcessData = new string[1000];
            string[] RequestProcessFinalData = new string[1000];
            int L = 0;
            try
            {
                for (int i = 0; i < TagIndex.Count; i++)
                {
                    TagValueWithAscii1[i] = Message.Substring(TagIndex[i] - 2, 5);
                }
            }
            catch { }
            try
            {
                for (int i = 0; i < TagIndex.Count; i++)
                {
                    if (Regex.IsMatch(TagValueWithAscii1[i].Substring(0, 1), @"^[a-zA-Z]+$") || Regex.IsMatch(TagValueWithAscii1[i].Substring(0, 1), @"^-?\d+$"))
                    { }
                    else
                    {
                        TagValueWithAscii[L] = TagValueWithAscii1[i];
                        L++;
                    }
                }
            }
            catch { }
            RequestProcessData = Message.Split(TagValueWithAscii, StringSplitOptions.None);



            try
            {
                for (int j = 1; j < RequestProcessData.Length; j++)
                {
                    if (!RequestProcessData[j].Contains(TagValueWithAscii[0]))
                    {
                        RequestProcessData[j] = TagValueWithAscii[j - 1] + RequestProcessData[j];
                    }
                }
            }
            catch { }
            return RequestProcessData;
        }
        public static List<int> GetTagPosition(string Message, string TagValue)
        {
            List<int> ret = new List<int>();
            int len = TagValue.Length;
            int start = -len;
            while (true)
            {
                start = Message.IndexOf(TagValue, start + len);
                if (start == -1)
                {
                    break;
                }
                else
                {
                    ret.Add(start);
                }
            }
            return ret;
        }
    }

    public class ISO8583FieldCollection : KeyedCollection<int, ISO8583Field>
    {
        public ISO8583FieldCollection() { }
        protected override int GetKeyForItem(ISO8583Field item)
        {
            return item.FieldIndex;
        }
    }

    public class CommandData : ICloneable
    {
        public int indexno { get; set; }
        public ISO8583Message SourceMessage { get; set; }
        public ISO8583Formatter Formatter { get; set; }
        public CommandTypeEnum CommandType { get; set; }
        public ModeOfTransaction TransactionMode { get; set; }
        public string NCommandType { get; set; }
        public string CardNumber { get; set; }
        public string Processingcode { get; set; }
        public double TransactionAmount { get; set; }
        // public string TransactionAmount { get; set; }
        public double SettlementAmount { get; set; }
        public string TransmissionDateTime { get; set; }
        public string SystemsTraceAuditNumber { get; set; }
        public DateTime LocalTransactionDateTime { get; set; }
        public DateTime LocalTransactionDate { get; set; }
        public DateTime ExpiredDate { get; set; }
        public string SettlementDate { get; set; }
        public string CaptureDate { get; set; }
        public string ConversionDate { get; set; }
        public string MerchantCategory { get; set; }
        public string PanEntryMode { get; set; }
        public string AcquirerInstitutionCode { get; set; }
        public string Track2Data { get; set; }

        public string ChipData { get; set; }
        public string ReferenceNumber { get; set; }
        public string AuthorizationNumber { get; set; }
        public long ResponseCode { get; set; }
        public string NResponseCode { get; set; }
        public string TerminalID { get; set; }
        public string TerminalLocation { get; set; }
        public string CardAccepterName { get; set; }
        public string AdditionalAmounts { get; set; }
        public string TransactionCurrencyCode { get; set; }
        public string SettlementCurrencyCode { get; set; }
        public string PersonalIdentificationNumber { get; set; }
        public string AdditionalAmount { get; set; }
        public string TerminalData { get; set; }
        public string ReceivingInstitutionCode { get; set; }
        public string AdditionalIssuerData { get; set; }
        public long NetworkManagementInformationCode { get; set; }
        public string NNetworkManagementInformationCode { get; set; }
        public string OriginalDataElements { get; set; }
        public string ReceivingInstitutionBin { get; set; }
        public double ReplaceAmount1 { get; set; }
        public double ReplaceAmount2 { get; set; }
        public string FromAccountNumber { get; set; }
        public string ToAccountNumber { get; set; }
        public string SettlementInstitution { get; set; }
        public string BankBranchAccountTypeSchemetype { get; set; }
        public string TransactionCharges { get; set; }
        public Guid CycleID { get; set; }
        public int CycleSNo { get; set; }
        public int Mode { get; set; }

        public string FunctionCode { get; set; }
        public string ExtendedPrimaryAccountNumber { get; set; }
        public string AdditionalDataPrivate { get; set; }
        public string ReversalField56 { get; set; }
        public string ChequeDetails { get; set; }
        public string AccountIdentification1 { get; set; }
        public string DeliveryChannelControllerId { get; set; }
        public string TerminalType { get; set; }
        public string UserDefined { get; set; }
        public string TransactionRequest { get; set; }
        public string ReservedField1 { get; set; }
        public string ReservedField2 { get; set; }
        public string ReservedField3 { get; set; }
        public string PinOFFSet { get; set; }
        public string ExtendedData { get; set; }
        public string PoSData { get; set; }


        public string POSConditionCode { get; set; }
        public string PinData { get; set; }
        public string ServiceCode { get; set; }
        public string AcquiringInstitutionCountryCode { get; set; }
        public string MiniStateMent { get; set; }


        //by amit

        public string PoSConditionCode { get; set; }
        public bool RepeatReversal { get; set; }
        public string PartialReversal { get; set; }

        public string RequestKey { get; set; }
        public string ResponseKey { get; set; }

        public string CashBackAmount { get; set; }

        public string TransportData { get; set; }
        public string DestinationInstIDCode { get; set; }
        public string OriginatorInstIDCode { get; set; }
        public string Field108 { get; set; }
        public string Field111 { get; set; }
        public string Field114 { get; set; }
        public string Field116 { get; set; }
        public bool ResponseFlag { get; set; }

        public string SettlementCurrencyCodeCardholderBilling { get; set; }

        public string CardSequenceNumber { get; set; }
        public string CardAcceptorBusinessCode { get; set; }
        public string AcquirerReferenceData { get; set; }

        public string IntegratedCircuitCard { get; set; }
        public string TransactionLifeCycle { get; set; }
        public string MessageNumber { get; set; }

        public string DE72DataRecord { get; set; }
        public string TransactionDestinationInstitutionID { get; set; }
        public string TransactionOriginatorInstitutionID { get; set; }
        public double ReconciliationAmount { get; set; }
        public double CardholderBilling { get; set; }
        public string ConversationRateReconciliation { get; set; }
        public string ConversationRateCardholderBilling { get; set; }

        public string AmountsOriginal { get; set; }


        public CommandData(ISO8583Formatter pFormatter)
            : this(null, pFormatter)
        {
        }
        public CommandData(ISO8583Message pISO8583Message, ISO8583Formatter pFormatter)
        {
            InitProperties();
            this.SourceMessage = pISO8583Message;
            this.Formatter = pFormatter;
            this.Formatter.InitCommand(pISO8583Message, this);
        }

        private void InitProperties()
        {
            CommandType = CommandTypeEnum.Unknown;
            TransactionMode = ModeOfTransaction.Unknown;
            NCommandType = "0000";
            CardNumber = string.Empty;
            Processingcode = string.Empty;
            TransactionAmount = 0.0;
            ////TransactionAmount = string.Empty;
            SettlementAmount = 0.0;
            TransmissionDateTime = string.Empty;
            //amit
            LocalTransactionDate = DateTime.Now;
            ExpiredDate = DateTime.Now;
            SystemsTraceAuditNumber = string.Empty;
            LocalTransactionDateTime = DateTime.Now;
            SettlementDate = string.Empty;
            CaptureDate = string.Empty;
            ConversionDate = string.Empty;
            MerchantCategory = string.Empty;
            PanEntryMode = string.Empty;
            AcquirerInstitutionCode = string.Empty;
            Track2Data = string.Empty;
            ReferenceNumber = string.Empty;
            //AuthorizationCode = string.Empty;
            AuthorizationNumber = string.Empty;
            ResponseCode = -1;
            NResponseCode = "-1";
            TerminalID = string.Empty;
            TerminalLocation = string.Empty;
            CardAccepterName = string.Empty;
            AdditionalAmounts = string.Empty;
            TransactionCurrencyCode = string.Empty;
            PersonalIdentificationNumber = string.Empty;
            AdditionalAmount = string.Empty;
            TerminalData = string.Empty;
            ReceivingInstitutionCode = string.Empty;
            AdditionalIssuerData = string.Empty;
            NetworkManagementInformationCode = 0;
            NNetworkManagementInformationCode = "000";
            OriginalDataElements = string.Empty;
            PartialReversal = string.Empty;
            ReceivingInstitutionBin = string.Empty;
            ReplaceAmount1 = 0.0;
            ReplaceAmount2 = 0.0;
            FromAccountNumber = string.Empty;
            ToAccountNumber = string.Empty;
            SettlementInstitution = string.Empty;
            BankBranchAccountTypeSchemetype = string.Empty;
            CycleID = Guid.Empty;
            CycleSNo = 0;
            Mode = 0;
            SettlementCurrencyCode = string.Empty;
            FunctionCode = string.Empty;
            ExtendedPrimaryAccountNumber = string.Empty;
            AdditionalDataPrivate = string.Empty;
            ReversalField56 = string.Empty;
            ChequeDetails = string.Empty;
            AccountIdentification1 = string.Empty;
            DeliveryChannelControllerId = string.Empty;
            TerminalType = string.Empty;
            ReservedField1 = string.Empty;
            ReservedField2 = string.Empty;
            ReservedField3 = string.Empty;
            PinOFFSet = string.Empty;
            ExtendedData = string.Empty;
            PoSData = string.Empty;
            PoSConditionCode = string.Empty;

            // POSConditionCode = string.Empty;
            PinData = string.Empty;
            ServiceCode = string.Empty;
            AcquiringInstitutionCountryCode = string.Empty;
            MiniStateMent = string.Empty;
            RepeatReversal = false;
            RequestKey = string.Empty;
            ResponseKey = string.Empty;
            TransportData = string.Empty;
            DestinationInstIDCode = string.Empty;
            OriginatorInstIDCode = string.Empty;
            Field108 = string.Empty;
            Field111 = string.Empty;
            Field114 = string.Empty;
            Field116 = string.Empty;
            ResponseFlag = false;
        }

        public ISO8583Message GetISO8583Message()
        {
            ISO8583Message result = new ISO8583Message();
            this.Formatter.InitMessage(result, this);
            return result;
        }

        public string Key()
        {
            return Key(CommandType);
        }
        public string Key(CommandTypeEnum pCommandType)
        {
            return string.Format("{0}{1}{2}{3}{4}", Processingcode.Substring(0, 2), CardNumber, LocalTransactionDateTime.ToString("yyyyMMddHHmmss"), ReferenceNumber, TerminalID.Trim());
        }

        #region ICloneable Members

        public object Clone()
        {
            try
            {
                return new CommandData(this.Formatter)
                {
                    SourceMessage = this.GetISO8583Message(),
                    CommandType = this.CommandType,
                    NCommandType = this.NCommandType,
                    CardNumber = this.CardNumber,
                    Processingcode = this.Processingcode,
                    TransactionAmount = this.TransactionAmount,
                    SettlementAmount = this.SettlementAmount,
                    TransmissionDateTime = this.TransmissionDateTime,
                    LocalTransactionDate = this.LocalTransactionDate,
                    ExpiredDate = this.ExpiredDate,
                    SystemsTraceAuditNumber = this.SystemsTraceAuditNumber,
                    LocalTransactionDateTime = this.LocalTransactionDateTime,
                    SettlementDate = this.SettlementDate,
                    ConversionDate = this.ConversionDate,
                    CaptureDate = this.CaptureDate,
                    MerchantCategory = this.MerchantCategory,
                    PanEntryMode = this.PanEntryMode,
                    AcquirerInstitutionCode = this.AcquirerInstitutionCode,
                    Track2Data = this.Track2Data,
                    ReferenceNumber = this.ReferenceNumber,
                    //AuthorizationCode = string.Empty;
                    AuthorizationNumber = this.AuthorizationNumber,
                    ResponseCode = this.ResponseCode,
                    NResponseCode = this.NResponseCode,
                    TerminalID = this.TerminalID,
                    TerminalLocation = this.TerminalLocation,
                    CardAccepterName = this.CardAccepterName,
                    AdditionalAmounts = this.AdditionalAmounts,
                    TransactionCurrencyCode = this.TransactionCurrencyCode,
                    PersonalIdentificationNumber = this.PersonalIdentificationNumber,
                    AdditionalAmount = this.AdditionalAmount,
                    TerminalData = this.TerminalData,
                    ReceivingInstitutionCode = this.ReceivingInstitutionCode,
                    AdditionalIssuerData = this.AdditionalIssuerData,
                    NetworkManagementInformationCode = this.NetworkManagementInformationCode,
                    NNetworkManagementInformationCode = this.NNetworkManagementInformationCode,
                    OriginalDataElements = this.OriginalDataElements,
                    ReceivingInstitutionBin = this.ReceivingInstitutionBin,
                    ReplaceAmount1 = this.ReplaceAmount1,
                    ReplaceAmount2 = this.ReplaceAmount2,
                    FromAccountNumber = this.FromAccountNumber,
                    ToAccountNumber = this.ToAccountNumber,
                    SettlementInstitution = this.SettlementInstitution,
                    BankBranchAccountTypeSchemetype = this.BankBranchAccountTypeSchemetype,
                    CycleID = this.CycleID,
                    CycleSNo = this.CycleSNo,
                    Mode = this.Mode,
                    SettlementCurrencyCode = this.SettlementCurrencyCode,
                    FunctionCode = this.FunctionCode,
                    ExtendedPrimaryAccountNumber = this.ExtendedPrimaryAccountNumber,
                    AdditionalDataPrivate = this.AdditionalDataPrivate,
                    ReversalField56 = this.ReversalField56,
                    ChequeDetails = this.ChequeDetails,
                    AccountIdentification1 = this.AccountIdentification1,
                    DeliveryChannelControllerId = this.DeliveryChannelControllerId,
                    TerminalType = this.TerminalType,
                    ReservedField1 = this.ReservedField1,
                    ReservedField2 = this.ReservedField2,
                    ReservedField3 = this.ReservedField3,
                    PinOFFSet = this.PinOFFSet,
                    ExtendedData = this.ExtendedData,
                    PoSData = this.PoSData,
                    PoSConditionCode = this.PoSConditionCode,
                    AcquiringInstitutionCountryCode = this.AcquiringInstitutionCountryCode,
                    POSConditionCode = this.POSConditionCode,
                    PinData = this.PinData,
                    ServiceCode = this.ServiceCode,
                    MiniStateMent = this.MiniStateMent,
                    RepeatReversal = this.RepeatReversal,
                    TransportData = this.TransportData,
                    DestinationInstIDCode = this.DestinationInstIDCode,
                    OriginatorInstIDCode = this.OriginatorInstIDCode,
                    Field108 = this.Field108,
                    Field111 = this.Field111,
                    Field114 = this.Field114,
                    Field116 = this.Field116,
                    ResponseFlag = this.ResponseFlag,
                };
            }
            catch //(Exception ex)
            {
                return null;
            }
        }

        #endregion
    }

    public class ISO8583Field
    {
        public ISO8583FieldCollection subFields;
        public ISO8583Field()
        {
            FieldIndex = -1;
            FieldDescription = string.Empty;
            FieldType = ISO8583FieldTypeEnum.ISO8583_N;
            Size = 0;
            FieldLengthType = ISO8583FieldLengthTypeEnum.ISO8583_FIXED;
        }
        public int FieldIndex { get; set; }
        public string FieldDescription { get; set; }
        public ISO8583FieldTypeEnum FieldType { get; set; }
        public int Size { get; set; }
        public ISO8583FieldLengthTypeEnum FieldLengthType { get; set; }
        public ISO8583FieldCollection SubFields
        {
            get
            {
                if (this.subFields == null)
                    subFields = new ISO8583FieldCollection();
                return subFields;
            }
            set
            {
                subFields = value;
            }
        }
        public bool HasSubFields { get { return (this.subFields != null && this.subFields.Count > 0); } }

        public ISO8583FieldEncryptionDecryptionEnum ISO8583FieldEncryptionDecryption { get; set; }
    }

    public class ISO8583_CommandCollection : KeyedCollection<CommandTypeEnum, ISO8583_Command>
    {
        public ISO8583_CommandCollection() { }
        protected override CommandTypeEnum GetKeyForItem(ISO8583_Command item)
        {
            return item.CommandType;
        }
        public ISO8583_Command this[string MTI]
        {
            get
            {
                ISO8583_Command result = null;
                foreach (ISO8583_Command cmd in base.Items)
                    if (cmd.CommandCode == MTI)
                    {
                        result = cmd;
                        break;
                    }
                return result;
            }
        }
    }

    public class ISO8583_ResponseCode
    {
        public ISO8583_ResponseCode() { }
        public ISO8583_ResponseCode(int code, string value)
        {
            this.Code = code;
            this.Value = value;
        }
        public long Code { get; set; }
        public String Value { get; set; }
    }

    public class ISO8583_ResponseCodeCollection : KeyedCollection<long, ISO8583_ResponseCode>
    {
        protected override long GetKeyForItem(ISO8583_ResponseCode item)
        {
            return item.Code;
        }
        public ISO8583_ResponseCode this[string value]
        {
            get
            {
                ISO8583_ResponseCode result = null;
                foreach (ISO8583_ResponseCode respCode in base.Items)
                    if (respCode.Value == value)
                    {
                        result = respCode;
                        break;
                    }
                return result;
            }
        }
    }

    public class ISO8583_Command
    {
        public ISO8583_Command() { }
        public ISO8583_Command(CommandTypeEnum commandType, string commandCode, int[] mFields, int[] oFields)
        {
            this.CommandType = commandType;
            this.CommandCode = commandCode;
            this.MFields = mFields;
            this.OFields = oFields;
            this.IsResponseCommand = false;
        }
        public CommandTypeEnum CommandType { get; set; }
        public string CommandCode { get; set; }
        public int[] MFields { get; set; }
        public int[] OFields { get; set; }
        public bool IsResponseCommand { get; set; }

        private ISO8583_ResponseCodeCollection responseCodes = null;

        public ISO8583_ResponseCodeCollection ResponseCodes
        {
            get
            {
                if (responseCodes == null)
                    responseCodes = new ISO8583_ResponseCodeCollection();
                return responseCodes;
            }
            set { responseCodes = value; }
        }
    }

    public class FieldCollection : KeyedCollection<int, Field>
    {
        protected override int GetKeyForItem(Field item)
        {
            return item.FieldIndex;
        }
    }

    public class ISO8583Message
    {

        FieldCollection fields = null;
        public ISO8583Message()
        {
            HasHeader = true;
            Header = string.Empty;
            MTI = string.Empty;

            IsValidMessage = false;
            ErrorLog = string.Empty;
        }
        public bool HasHeader { get; set; }
        public string Header { get; set; }
        public string MTI { get; set; }
        public bool IsValidMessage { get; set; }
        public string ErrorLog { get; set; }
        public FieldCollection Fields
        {
            get
            {
                if (fields == null)
                    fields = new FieldCollection();
                return fields;
            }
            set
            {
                fields = value;
            }
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Header : {0} {1}", this.Header, Environment.NewLine);
            sb.AppendFormat("MTI : {0} {1}", this.MTI, Environment.NewLine);
            foreach (Field f in this.Fields)
            {
                sb.AppendFormat("{0}{1}", f.ToString(), Environment.NewLine);
            }
            return sb.ToString();
        }

    }

    public class Field
    {
        public int FieldIndex { get; set; }
        public byte[] Value { get; set; }
        public override string ToString()
        {
            string result = "";
            int resultLength = 0;
            if (Value != null)
                resultLength = Value.Length;
            int CharsToRead = Size > resultLength ? resultLength : Size;
            char paddingChar = (FieldType == ISO8583FieldTypeEnum.ISO8583_N) ? '0' : ' ';
            string fieldData = Utils.ByteArrayToASCII(Value);
            int index = 0;
            switch (FieldLengthType)
            {
                case ISO8583FieldLengthTypeEnum.ISO8583_FIXED:
                    //CharsToRead = field.Size;
                    fieldData = fieldData.Substring(index, CharsToRead);
                    if (FieldType == ISO8583FieldTypeEnum.ISO8583_N)
                        fieldData = fieldData.PadLeft(Size, paddingChar);
                    else
                        fieldData = fieldData.PadRight(Size, paddingChar);
                    result = string.Format("   Field [{0}] : <{1}> ", FieldIndex, fieldData);
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LVAR:
                    CharsToRead = ((Size - 1) > resultLength) ? resultLength : (Size - 1);
                    fieldData = fieldData.Substring(index, CharsToRead);
                    result = string.Format("   Field [{0}] : <{1}> ", FieldIndex, fieldData.Length);
                    result = result + Environment.NewLine + string.Format("   Field [{0}] : <{1}> ", FieldIndex, fieldData);
                    //fieldData = String.Format("{0:0}", fieldData.Length) + fieldData;
                    //index = index + Size;
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LLVAR:
                    CharsToRead = ((Size - 2) > resultLength) ? resultLength : (Size - 2);
                    fieldData = fieldData.Substring(index, CharsToRead);
                    result = string.Format("   Field [{0}] : <{1}> ", FieldIndex, fieldData.Length);
                    result = result + Environment.NewLine + string.Format("   Field [{0}] : <{1}> ", FieldIndex, fieldData);
                    //fieldData = String.Format("{0:00}", fieldData.Length) + fieldData;
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR:
                    CharsToRead = ((Size - 3) > resultLength) ? resultLength : (Size - 3);
                    fieldData = fieldData.Substring(index, CharsToRead);
                    result = string.Format("   Field [{0}] : <{1}> ", FieldIndex, fieldData.Length);
                    result = result + Environment.NewLine + string.Format("   Field [{0}] : <{1}> ", FieldIndex, fieldData);
                    //fieldData = String.Format("{0:000}", fieldData.Length) + fieldData;
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LLLLVAR:
                    CharsToRead = ((Size - 4) > resultLength) ? resultLength : (Size - 4);
                    fieldData = fieldData.Substring(index, CharsToRead);
                    result = string.Format("   Field [{0}] : <{1}> ", FieldIndex, fieldData.Length);
                    result = result + Environment.NewLine + string.Format("   Field [{0}] : <{1}> ", FieldIndex, fieldData);
                    //fieldData = String.Format("{0:0000}", fieldData.Length) + fieldData;
                    break;
            }

            return result;
        }
        private FieldCollection subFields;

        public FieldCollection SubFields
        {
            get
            {
                if (subFields == null)
                    subFields = new FieldCollection();
                return subFields;
            }
            set { subFields = value; }
        }
        public bool HasSubFields
        {
            get
            {
                return (subFields != null && subFields.Count > 0);
            }
        }

        public ISO8583FieldTypeEnum FieldType { get; set; }
        public int Size { get; set; }
        public ISO8583FieldLengthTypeEnum FieldLengthType { get; set; }

        public ISO8583FieldEncryptionDecryptionEnum ISO8583FieldEncryptionDecryption { get; set; }
    }

    public class ISO8583Formatter
    {
        private ISO8583VersionEnum version;
        private ISO8583Field header;
        private ISO8583Field messageTypeIdentifier;
        private ISO8583Field primaryBitMap;
        private ISO8583FieldCollection dataElements;

        public bool HasMsgLengthPrefixIN4Byte { get; set; }

        public bool HasMsgLengthPrefixIN2Byte { get; set; }

        public int MsgLengthSize { get; set; }

        public ISO8583VersionEnum Version
        {
            get { return version; }
            set { version = value; }
        }

        public ISO8583Field Header
        {
            get { return header; }
            set { header = value; }
        }

        public ISO8583Field MessageTypeIdentifier
        {
            get { return messageTypeIdentifier; }
            set { messageTypeIdentifier = value; }
        }

        public ISO8583Field PrimaryBitMap
        {
            get { return primaryBitMap; }
            set { primaryBitMap = value; }
        }

        public ISO8583FieldCollection DataElements
        {
            get
            {
                if (dataElements == null)
                    dataElements = new ISO8583FieldCollection();
                return dataElements;
            }
            set { dataElements = value; }
        }

        public string HeaderValue { get; set; }

        public virtual ISO8583_CommandCollection CommandCollection { get; set; }

        public virtual bool InitCommand(ISO8583Message sourceMessage, CommandData result) { return false; }
        public virtual bool InitMessage(ISO8583Message sourceMessage, CommandData result) { return false; }

        public bool CheckFields(ISO8583Message sourceMessage, int[] aryIdxM, int[] aryIdxO)
        {
            StringBuilder sb = new StringBuilder(sourceMessage.ErrorLog);
            bool result = false;
            foreach (int idx in aryIdxM)
                if (!sourceMessage.Fields.Contains(idx))
                {
                    sb.AppendLine(string.Format("Field [{0}] is not found", idx));
                    result = true;
                }
            sourceMessage.ErrorLog = sb.ToString();
            sourceMessage.IsValidMessage = !result;
            return !result;
        }

        public void SetRequiredFields(ISO8583Message sourceMessage, int[] aryIdxM, int[] aryIdxO)
        {
            sourceMessage.Fields.Clear();
            for (int idx = 1; idx <= 128; idx++)
            {
                if (aryIdxM.Contains(idx) || aryIdxO.Contains(idx))
                {
                    Field f = new Field()
                    {
                        FieldIndex = idx,
                        FieldType = this.DataElements[idx].FieldType,
                        FieldLengthType = this.DataElements[idx].FieldLengthType,
                        Size = this.DataElements[idx].Size
                    };
                    sourceMessage.Fields.Add(f);
                }
            }
        }
        public string GetCommandType(CommandData cmdData)
        {
            string obj = "";
            try
            {
                ISO8583_Command cmd = CommandCollection[cmdData.CommandType];
                if (cmd != null)
                    obj = cmd.CommandCode;
            }
            catch
            { }
            return obj;
        }
        public string GetResponseValue(CommandData cmdData)
        {
            string obj = "05";
            try
            {
                ISO8583_Command cmd = CommandCollection[cmdData.CommandType];
                if (cmd != null)
                    obj = cmd.ResponseCodes[cmdData.ResponseCode].Value;
            }
            catch //(Exception ex)
            { }
            return obj;
        }
        public string GetResponseValue(long ResponseCode, ISO8583_Command resCmd)
        {
            string obj = "05";
            try
            {
                obj = resCmd.ResponseCodes[ResponseCode].Value;
            }
            catch //(Exception ex)
            { }
            return obj;
        }
        public long GetResponseCode(string ResponseValue, ISO8583_Command resCmd)
        {
            long obj = -1; //ResponseCodesEnum.UnableToProcess 
            try
            {
                obj = resCmd.ResponseCodes[ResponseValue].Code;
            }
            catch //(Exception ex)
            { }
            return obj;
        }
        public virtual string GetBitMap(string MTI)
        {
            if (CommandCollection != null)
            {
                ISO8583_Command cmd = CommandCollection[MTI];
                if (cmd != null)
                {

                    StringBuilder sb = new StringBuilder();
                    bool SecondaryBitmapAvailable = false;
                    for (int idx = 2; idx <= 128; idx++)
                        if (cmd.MFields.Contains(idx) || cmd.OFields.Contains(idx))
                        {
                            sb.Append("1");
                            if (idx > 64)
                                SecondaryBitmapAvailable = true;
                        }
                        else
                            sb.Append("0");
                    string Bitmap = (SecondaryBitmapAvailable ? "1" + sb.ToString() : "0" + sb.ToString().Substring(0, 63));
                    //change
                    return Bitmap;
                }
            }
            return string.Empty;
        }

        public string GetSelectedBitMap(string MTI, int[] OFields)
        {
            if (CommandCollection != null)
            {
                ISO8583_Command cmd = CommandCollection[MTI];
                if (cmd != null)
                {
                    StringBuilder sb = new StringBuilder();
                    bool SecondaryBitmapAvailable = false;
                    for (int idx = 2; idx <= 128; idx++)
                        if (cmd.MFields.Contains(idx) || OFields.Contains(idx))
                        {
                            sb.Append("1");
                            if (idx > 64)
                                SecondaryBitmapAvailable = true;
                        }
                        else
                            sb.Append("0");
                    string Bitmap = (SecondaryBitmapAvailable ? "1" + sb.ToString() : "0" + sb.ToString().Substring(0, 63));
                    return Bitmap;
                }
            }

            return string.Empty;
        }
    }

    public class ISO8583FieldParser
    {
        public static byte[] Unpack(ISO8583Field field, ref int index, byte[] sourceMessage)
        {
            byte[] result = null;
            int CharsToRead = 0;
            int StartIndex = 0;
            switch (field.FieldLengthType)
            {
                case ISO8583FieldLengthTypeEnum.ISO8583_FIXED:
                    StartIndex = 0;
                    CharsToRead = field.Size;
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LVAR:
                    StartIndex = 1;
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LLVAR:
                    StartIndex = 2;
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR:
                    StartIndex = 3;
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LLLLVAR:
                    StartIndex = 4;
                    break;
            }

            if (StartIndex > 0)
            {
                byte[] bytes1 = Utils.GetSubBytes(sourceMessage, index, index + StartIndex - 1);
                CharsToRead = Convert.ToInt32(Utils.ByteArrayToASCII(bytes1));// -StartIndex;
            }
            CharsToRead = (field.Size > CharsToRead) ? CharsToRead : field.Size;
            result = Utils.GetSubBytes(sourceMessage, index + StartIndex, index + StartIndex + CharsToRead - 1);
            string Hex = Utils.ByteArrayToHex(result);
            index = index + StartIndex + CharsToRead;
            return result;
        }
        public static byte[] Pack(ISO8583Field field, ref int index, byte[] sourceMessage)
        {
            byte[] result = null;
            if (!field.HasSubFields)
                result = sourceMessage;
            else
            {
                int subIndex = 0;
                System.IO.MemoryStream s = new System.IO.MemoryStream();
                foreach (ISO8583Field subField in field.SubFields)
                {
                    byte[] subResult = Pack(subField, ref subIndex, sourceMessage);
                    s.Write(subResult, 0, subResult.Length);
                }
                result = s.ToArray();
            }
            int resultLength = 0;
            if (result != null)
                resultLength = result.Length;
            int CharsToRead = field.Size > resultLength ? resultLength : field.Size;
            char paddingChar = (field.FieldType == ISO8583FieldTypeEnum.ISO8583_N) ? '0' : ' ';
            string fieldData = Utils.ByteArrayToASCII(result);

            switch (field.FieldLengthType)
            {
                case ISO8583FieldLengthTypeEnum.ISO8583_FIXED:
                    //CharsToRead = field.Size;
                    fieldData = fieldData.Substring(index, CharsToRead);
                    if (field.FieldType == ISO8583FieldTypeEnum.ISO8583_N)
                        fieldData = fieldData.PadLeft(field.Size, paddingChar);
                    else
                        fieldData = fieldData.PadRight(field.Size, paddingChar);
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LVAR:
                    CharsToRead = ((field.Size - 1) > resultLength) ? resultLength : (field.Size - 1);
                    fieldData = fieldData.Substring(index, CharsToRead);
                    fieldData = String.Format("{0:0}", fieldData.Length) + fieldData;
                    //index = index + field.Size;
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LLVAR:
                    CharsToRead = ((field.Size - 2) > resultLength) ? resultLength : (field.Size - 2);
                    fieldData = fieldData.Substring(index, CharsToRead);
                    fieldData = String.Format("{0:00}", fieldData.Length) + fieldData;
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LLLVAR:
                    CharsToRead = ((field.Size - 3) > resultLength) ? resultLength : (field.Size - 3);
                    fieldData = fieldData.Substring(index, CharsToRead);
                    fieldData = String.Format("{0:000}", fieldData.Length) + fieldData;
                    break;
                case ISO8583FieldLengthTypeEnum.ISO8583_LLLLVAR:
                    CharsToRead = ((field.Size - 4) > resultLength) ? resultLength : (field.Size - 4);
                    fieldData = fieldData.Substring(index, CharsToRead);
                    fieldData = String.Format("{0:0000}", fieldData.Length) + fieldData;
                    break;
            }
            index = index + fieldData.Length;
            result = Utils.ASCIIToByteArray(fieldData);
            return result;
        }
    }
    public class ISO8583MessageParser
    {
        //public iLogger Logger { get; set; }
        //protected void WriteEntry(string msg)
        //{
        //    if (this.Logger != null)
        //        this.Logger.WriteEntry(this, msg);
        //}

        private ISO8583Formatter formatter;
        public ISO8583Formatter Formatter
        {
            get { return formatter; }
            set { formatter = value; }
        }

        public ISO8583MessageParser(ISO8583Formatter pFormatter)
        {
            this.Formatter = pFormatter;
        }

        public ISO8583Message Unpack(byte[] sourceMessage, int Srnoindex, ref DataTable dt)
        {
            string HexData = Utils.ByteArrayToHex(sourceMessage);
            string Header = HexData.Substring(0, 8);
            string BITPMAP = HexData.Substring(16, 32);
            string Binary = Utils.HEX2Binary(BITPMAP);
            //string ASCII = Utils.HEX2ASCII(HexData.Substring(48));
            //HexData = HexData.Replace("324040333730313634", string.Empty);
            string[] TagDetails = new string[10000];
            string Tag = string.Empty;
            string ASCIIData = string.Empty;
            try
            {
                int getValus = 8;
                int indexof = 0;
                string Data = string.Empty;
                for (int a = 0; a < HexData.Length;)
                {

                    if ((a + getValus) > HexData.Length)
                    {
                        break;
                    }
                    
                    Tag = HexData.Substring(a, getValus);
                    // string HeaderValue = HexData.Substring(8, 8);
                    int lengthOfHeader = Convert.ToInt32(Tag, 16);
                    Data = HexData.Substring(a, 8 + Convert.ToInt32(Tag, 16) * 2);

                    string lengthdata = Data.Substring(Data.Length - 2);
                    if (lengthdata == "00")
                    {

                    }
                    if (Data.Contains("4040"))
                    {
                        Data = HexData.Substring(a, 12 + Convert.ToInt32(Tag, 16) * 2);
                        // Data = Data.Replace("4040", string.Empty);
                        ASCIIData = Utils.HEX2ASCII(Data);

                        // TagDetails[indexof] += Data;
                        TagDetails[indexof] += HexData;
                        a = a + Data.Length;
                        indexof++;

                    }
                    else
                    {
                        //TagDetails[indexof] += Data;
                        TagDetails[indexof] += HexData;
                        a = a + Data.Length;
                        indexof++;
                    }
                }
                //catch( Exception ex)
                //{

                //}

                // }
            }
            catch (Exception ex)
            {
            }

            for (int indexvalue = 0; indexvalue <= TagDetails.Length; indexvalue++)
            {
                ISO8583Message result = new ISO8583Message();

                if (TagDetails[indexvalue] == null)
                {
                    break;
                }

                sourceMessage = Utils.HexToByteArray(TagDetails[indexvalue].ToString());
                HexData = TagDetails[indexvalue].ToString();
                int index = 0;
                if (this.Formatter.HasMsgLengthPrefixIN4Byte)
                {
                    index = this.Formatter.MsgLengthSize;
                }
                else if (this.Formatter.HasMsgLengthPrefixIN2Byte)
                    index = this.Formatter.MsgLengthSize;

                if (index < 0) index = 0;

                result.Header = Utils.ByteArrayToASCII(ISO8583FieldParser.Unpack(this.Formatter.Header, ref index, sourceMessage));

                ////*************************Modified As FlexCube Response Message Length is not comming****************************
                if (this.Formatter.HeaderValue.Length != result.Header.Length)
                {
                    if (this.Formatter.HasMsgLengthPrefixIN4Byte)
                        index = this.Formatter.MsgLengthSize;
                    else
                        index = 0;
                    if (index < 0) index = 0;

                    result.Header = "";
                    result.HasHeader = false;
                }
                result.MTI = Utils.ByteArrayToASCII(ISO8583FieldParser.Unpack(this.Formatter.MessageTypeIdentifier, ref index, sourceMessage));
                if (result.MTI == "1740")
                {

                }
                string strprimaryBitMap = HexData.Substring(16, 16);
                string strSecondaryBITMAP = string.Empty;
                strprimaryBitMap = Utils.HEX2Binary(strprimaryBitMap);
                if (strprimaryBitMap.Substring(0, 1) == "1")
                {
                    strSecondaryBITMAP = HexData.Substring(32, 16);
                    strSecondaryBITMAP = Utils.HEX2Binary(strSecondaryBITMAP);
                    index = 24;
                }

                string strBitMap = strprimaryBitMap + strSecondaryBITMAP;
                // for exception handling               
                sourceMessage = Utils.ASCIIToByteArray(Utils.HEX2ASCII(HexData));
                for (int i = 1; i < strBitMap.Length; i++)
                {
                    if (strBitMap.Substring(i, 1) == "1")
                    {
                        if (i == 54)
                        {

                        }
                        try
                        {
                            int idx = i + 1;
                            Field f = new Field()
                            {
                                FieldIndex = idx,
                                Value = ISO8583FieldParser.Unpack(this.Formatter.DataElements[idx], ref index, sourceMessage),
                                FieldType = this.Formatter.DataElements[idx].FieldType,
                                FieldLengthType = this.Formatter.DataElements[idx].FieldLengthType,
                                Size = this.Formatter.DataElements[idx].Size,
                                ISO8583FieldEncryptionDecryption = this.Formatter.DataElements[idx].ISO8583FieldEncryptionDecryption,
                            };
                            if (this.Formatter.DataElements[idx].HasSubFields)
                            {
                                int subIndex = 0;
                                foreach (ISO8583Field subfield in this.Formatter.DataElements[idx].SubFields)
                                    f.SubFields.Add(new Field()
                                    {
                                        FieldIndex = subfield.FieldIndex,
                                        Value = ISO8583FieldParser.Unpack(subfield, ref subIndex, f.Value),
                                        FieldType = subfield.FieldType,
                                        FieldLengthType = subfield.FieldLengthType,
                                        Size = subfield.Size

                                    });
                            }
                            result.Fields.Add(f);
                        }
                        catch (Exception ex)
                        {
                            //Loger.WriteErrorLog(null, ex);
                        }
                    }
                }

                //SwitchLogger.PosTraceLog(this, "ISO8583 Message : -" + result.ToString());
                CommandData cmdData = new CommandData(result, MParser.Formatter);
                SwitchConsumerRequestReqMsg sCmdData = new SwitchConsumerRequestReqMsg();
                sCmdData.indexno = Srnoindex;
                MessageConvertor(ref cmdData, ref sCmdData);

                ParseMastercardData(sCmdData, ref dt);
            }
            return null;
        }
        public byte[] Pack(ISO8583Message sourceMessage)
        {
            byte[] result = new byte[] { };
            result = result.Concat(Utils.ASCIIToByteArray(this.Formatter.HeaderValue)).ToArray();
            result = result.Concat(Utils.ASCIIToByteArray(sourceMessage.MTI)).ToArray();
            string strBitMap = string.Empty;

            StringBuilder sb = new StringBuilder();
            bool SecondaryBitmapAvailable = false;
            for (int idx = 2; idx <= 128; idx++)
                if (sourceMessage.Fields.Contains(idx))
                {
                    sb.Append("1");
                    if (idx > 64)
                        SecondaryBitmapAvailable = true;
                }
                else
                    sb.Append("0");

            strBitMap = (SecondaryBitmapAvailable ? "1" + sb.ToString() : "0" + sb.ToString().Substring(0, 63));

            // Loger.WriteTransLog(null, "Sending BitMaps : " + strBitMap);

            switch (this.Formatter.Version)
            {
                case ISO8583VersionEnum.ISO8583_1987:
                    result = result.Concat(Utils.ASCIIToByteArray(Utils.Binary2HEX(strBitMap).ToUpper())).ToArray();
                    break;
                case ISO8583VersionEnum.ISO8583_1993:
                    result = result.Concat(Utils.ASCIIToByteArray(Utils.Binary2ASCII(strBitMap))).ToArray();
                    break;
                case ISO8583VersionEnum.ISO8583_2003:
                    //sb.Append(Utils.Binary2ASCII(strBitMap).ToUpper());
                    ////result = result.Concat(Utils.ASCIIToByteArray(Utils.Binary2HEX(strBitMap))).ToArray();
                    result = result.Concat(Utils.ASCIIToByteArray(Utils.Binary2ASCII(strBitMap))).ToArray();
                    break;
            }
            foreach (ISO8583Field f in this.Formatter.DataElements)
            {
                if (f.FieldIndex == 1) continue;
                if (sourceMessage.Fields.Contains(f.FieldIndex))
                {
                    int idx = 0;
                    result = result.Concat(ISO8583FieldParser.Pack(f, ref idx, sourceMessage.Fields[f.FieldIndex].Value)).ToArray();
                }
            }
            string sMsgLength = string.Empty;
            int msgLength = 0;

            if (this.Formatter.HasMsgLengthPrefixIN2Byte)
            {
                //int msgLength = sb.ToString().Length;
                msgLength = result.Length;
                sMsgLength = msgLength.ToString();
                sMsgLength = sMsgLength.PadLeft(this.Formatter.MsgLengthSize, '0');
                string binValue = Convert.ToString(msgLength, 2).PadLeft(16, '0');
                byte[] fresult = result = Utils.ASCIIToByteArray(Utils.Binary2ASCII(binValue)).Concat(result).ToArray();
                return fresult;
            }
            else if (this.Formatter.HasMsgLengthPrefixIN4Byte)
            {
                msgLength = result.Length;
                sMsgLength = msgLength.ToString();
                sMsgLength = sMsgLength.PadLeft(this.Formatter.MsgLengthSize, '0');
                byte[] fresult = result = Utils.ASCIIToByteArray(sMsgLength).Concat(result).ToArray();
                return fresult;
            }

            return result;
        }

       
        ISO8583MessageParser mParser = null;
        public int Srnoindex { get; set; }
        public ISO8583MessageParser MParser
        {
            get
            {
                if (mParser == null)
                {
                    //if (FldType.SelectedIndex == 0)
                    //    mParser = new ISO8583MessageParser(new ISO8583_1987Formatter_IBTG_BANCS());
                    //else
                    mParser = new ISO8583MessageParser(new ISO8583_1987Formatter_IBTG_HOST());
                }
                return mParser;
            }
            set { mParser = value; }
        }



        public void MessageConvertor(ref CommandData cmdData, ref SwitchConsumerRequestReqMsg sCmdData)
        {
            try
            {

                sCmdData.FileHeader = cmdData.NCommandType;
                sCmdData.DE2CardNumber = cmdData.CardNumber;
                sCmdData.DE3ProcessingCode = cmdData.Processingcode;
                sCmdData.DE4TransactionAmount = Convert.ToString(cmdData.TransactionAmount);
                sCmdData.DE5ReconciliationAmount = Convert.ToString(cmdData.ReconciliationAmount);
                sCmdData.DE6CardholderBilling = Convert.ToString(cmdData.CardholderBilling);
                sCmdData.DE9ConversationRateReconciliation = cmdData.ConversationRateReconciliation;
                sCmdData.DE10ConversationRateCardholderBilling = cmdData.ConversationRateCardholderBilling;
                sCmdData.DE12LocalTransactionDateTime = cmdData.LocalTransactionDateTime.ToString("yyyyMMddHHmmss");
                sCmdData.DE14ExpiredDate = Convert.ToString(cmdData.ExpiredDate);
                sCmdData.DE22PanEntryMode = cmdData.PanEntryMode;
                sCmdData.DE23CardSequenceNumber = cmdData.CardSequenceNumber;
                sCmdData.DE24FunctionCode = cmdData.FunctionCode;
                sCmdData.DE25PoSConditionCode = cmdData.PoSConditionCode;
                sCmdData.DE26CardAcceptorBusinessCode = cmdData.CardAcceptorBusinessCode;
                sCmdData.DE30AmountsOriginal = cmdData.AmountsOriginal;
                sCmdData.DE31AcquirerReferenceData = cmdData.AcquirerReferenceData;
                sCmdData.DE32AcquirerInstitutionCode = cmdData.AcquirerInstitutionCode;
                sCmdData.DE33ReceivingInstitutionCode = cmdData.ReceivingInstitutionCode;
                sCmdData.DE37ReferenceNumber = cmdData.ReferenceNumber;
                sCmdData.DE38AuthorizationNumber = cmdData.AuthorizationNumber;
                sCmdData.DE40ServiceCode = cmdData.ServiceCode;
                sCmdData.DE41TerminalID = cmdData.TerminalID;
                sCmdData.DE42TerminalLocation = cmdData.TerminalLocation;
                sCmdData.DE43CardAccepterName = cmdData.CardAccepterName;
                sCmdData.DE48AdditionalData = cmdData.AdditionalDataPrivate;
                sCmdData.DE49TransactionCurrencyCode = cmdData.TransactionCurrencyCode;
                sCmdData.DE50CurrencyCodeReconciliation = cmdData.SettlementCurrencyCode;
                sCmdData.DE51SettlementCurrencyCodeCardholderBilling = cmdData.SettlementCurrencyCodeCardholderBilling;
                sCmdData.DE54AdditionalAmounts = cmdData.AdditionalAmounts;
                sCmdData.DE55ChipData = cmdData.ChipData;
                sCmdData.DE63AdditionalIssuerData = cmdData.AdditionalIssuerData;
                sCmdData.DE71MessageNumber = cmdData.MessageNumber;
                sCmdData.DE72DataRecord = cmdData.DE72DataRecord;
                sCmdData.DE93TransactionDestinationInstitutionIDCode = cmdData.DestinationInstIDCode;
                sCmdData.DE94TransactionOriginatorInstitutionIDCode = cmdData.OriginatorInstIDCode;
                sCmdData.DE95PartialReversal = cmdData.PartialReversal;
                sCmdData.DE100ReceivingInstitutionIDCode = cmdData.ReceivingInstitutionBin;
            }
            catch (Exception ex)
            {
                // Loger.WriteErrorLog(this, ex);
            }
        }

        private void ParseMastercardData(SwitchConsumerRequestReqMsg cmdData, ref DataTable dt)
        {

            if (cmdData.FileHeader.ToString() == "1442")
            {


                /*_TerminalId = _DataTable.Rows[j]["TERMINALID"].ToString(),
                                                                            _ReferenceNo = _DataTable.Rows[j]["REFNO"].ToString(),
                                                                            _TxnDate = _DataTable.Rows[j]["TR_TIMESTAMP"].ToString(),
                                                                            _CardNo = _DataTable.Rows[j]["CARDNO"].ToString(),
                                                                            _TxnAmount = _DataTable.Rows[j]["ACTUALAMOUNT"].ToString(),
                                                                            _ActualTxnsAmount = _DataTable.Rows[j]["ACTUALAMOUNT"].ToString(),
                                                                            _AccountNumber = "",
                                                                            _ContactNumber = "",
                                                                            _Remark = _DataTable.Rows[j]["TRANSACTIONID"].ToString(),
                                                                            _CreatedBy = Session["UserID"].ToString(),
                                                                            _ClaimType = "Full",
                                                                            _ComplaintID = _DataTable.Rows[j]["COMPLAINTID"].ToString(),
                                                                            _ClaimDate = _DataTable.Rows[j]["CLAIMDATE"].ToString(),
                                                                            _TxnsSubType = _DataTable.Rows[j]["TRANSTYPE"].ToString()*/

                string _referenceNumber = cmdData.DE38AuthorizationNumber.ToString();
                Random generator = new Random();
                String strComplaintID = generator.Next(100000, 999999).ToString("D6");
                string COMPLAINTID = strComplaintID + _referenceNumber.Substring(_referenceNumber.Length - 4).ToString();

                if (dt.Columns.Count == 0)
                {
                    dt.Columns.Add("FileHeader", typeof(System.String));
                    dt.Columns.Add("TERMINALID", typeof(System.String));
                    dt.Columns.Add("REFNO", typeof(System.String));
                    dt.Columns.Add("TR_TIMESTAMP", typeof(System.String));
                    dt.Columns.Add("CARDNO", typeof(System.String));
                    dt.Columns.Add("TXNAMOUNT", typeof(System.String));
                    dt.Columns.Add("ACTUALAMOUNT", typeof(System.String));
                    dt.Columns.Add("TRANSACTIONID", typeof(System.String));
                    dt.Columns.Add("COMPLAINTID", typeof(System.String));
                    dt.Columns.Add("CLAIMDATE", typeof(System.String));
                    dt.Columns.Add("TRANSTYPE", typeof(System.String));
                    dt.Columns.Add("MsgReasonCode", typeof(System.String));

                }

                dt.Rows.Add(cmdData.FileHeader.ToString(),
                    cmdData.DE41TerminalID.ToString().Trim(),
                    cmdData.DE38AuthorizationNumber.ToString().Trim(),
                    cmdData.DE12LocalTransactionDateTime.ToString().Trim(),
                    cmdData.DE2CardNumber.ToString().Trim(),
                    cmdData.DE4TransactionAmount.ToString().Trim(),
                    cmdData.DE5ReconciliationAmount.ToString().Trim(),
                    cmdData.DE31AcquirerReferenceData.ToString().Trim(),
                    COMPLAINTID,
                    DateTime.Now.ToString("yyyyMMddHHmmss"),
                    "Withdraw",
                    cmdData.DE25PoSConditionCode.ToString().Trim()
                    );


                //JSONString = new StringBuilder();
                // JSONString.Append("{ \"refnum\":" + "\"" + cmdData.DE38AuthorizationNumber.ToString() + "\",\"cardnumber\":" + "\"" + cmdData.DE2CardNumber.ToString() + "\" }");



                cmdData.Mastercarddata = string.Empty;
                //cmdData.Mastercarddata = cmdData.FileHeader + "|" + cmdData.DE24FunctionCode + "|" + cmdData.DE48AdditionalData + "|" + cmdData.DE50CurrencyCodeReconciliation + "|" + cmdData.DE71MessageNumber + "|" + cmdData.DE93TransactionDestinationInstitutionIDCode + "|" + cmdData.DE94TransactionOriginatorInstitutionIDCode + "|" + cmdData.DE100ReceivingInstitutionIDCode;
                cmdData.Mastercarddata = cmdData.FileHeader + "|" + cmdData.DE2CardNumber + "|" + cmdData.DE3ProcessingCode + "|" + cmdData.DE4TransactionAmount + "|" + cmdData.DE5ReconciliationAmount + "|" + cmdData.DE6CardholderBilling + "|" + /*DE7*/'A' + "|" + /*DE8BILLING_AMT*/'A' + "|" + cmdData.DE9ConversationRateReconciliation + "|" + cmdData.DE10ConversationRateCardholderBilling + "|" + /*DE11*/'A' + "|" + cmdData.DE12LocalTransactionDateTime + "|" + /*DE13 */'A' + "|" + cmdData.DE14ExpiredDate + "|" +/* DE15*/'A' + "|" + /*DE16*/'A' + "|" +/*DE17*/'A' + "|" + /*DE18*/'A' + "|" + /*DE19*/'A' + "|" + /*DE20*/'A' + "|" + /*DE21*/'A' + "|" + cmdData.DE22PanEntryMode + "|" + cmdData.DE23CardSequenceNumber + "|" + cmdData.DE24FunctionCode + "|" + cmdData.DE25PoSConditionCode + "|" + cmdData.DE26CardAcceptorBusinessCode + "|" + /*DE27*/'A' + "|"
                + /*DE28*/'A' + "|" + /*DE29*/'A' + "|" + cmdData.DE30AmountsOriginal + "|" + cmdData.DE31AcquirerReferenceData + "|" + cmdData.DE32AcquirerInstitutionCode + "|" + /*DE33ACQ_INST_ID*/'A' + "|" + /*DE34FWDINST_ID*/'A' + "|" + /*DE35*/'A' + "|" + /*DE36*/'A' + "|" + cmdData.DE37ReferenceNumber + "|" +
                "|" + cmdData.DE38AuthorizationNumber + "|" + /*DE39*/'A' + "|" + cmdData.DE40ServiceCode + "|" + cmdData.DE41TerminalID + "|" + cmdData.DE42TerminalLocation + "|" + cmdData.DE43CardAccepterName + "|" + /*DE44*/'A' + "|" + /*DE45*/'A' + "|" + /*DE46*/'A' + "|" + /*DE47*/'A' + "|" + cmdData.DE48AdditionalData + "|" + /*DE49TRAN_CURR*/'A' + "|" + cmdData.DE50CurrencyCodeReconciliation + "|" + cmdData.DE51SettlementCurrencyCodeCardholderBilling + "|" + /*DE52*/'A' + "|" + /*DE53*/'A' + "|" + cmdData.DE54AdditionalAmounts + "|" + cmdData.DE55ChipData + "|" + /*DE56*/'A' + "|" + /*DE57*/'A' + "|" + /*DE58*/'A' +
                    "|" + /*DE59*/'A' + "|" + /*DE60*/'A' + "|" + /*DE61*/'A' + "|" + /*ADDN_DATA62*/'A' + "|" + cmdData.DE63AdditionalIssuerData + "|" + /*DE64*/'A' + "|" + /*DE65*/ 'A' + "|" +/*DE66*/ 'A' + "|" + /*DE67*/'A' + "|" + /*DE68*/ 'A' + "|" + /*DE69*/ 'A' + "|" + /*DE70*/ 'A' + "|" + cmdData.DE71MessageNumber + "|" + cmdData.DE72DataRecord + "|" + /*DE73ACTION_DATE*/ 'A' + "|" + /*DE74*/ 'A' + "|" + /*DE75*/ 'A' + "|" + /*DE76*/ 'A' + "|" + /*DE77*/ 'A' + "|" + /*DE78*/ 'A' + "|" +
                    /*DE79*/ 'A' + "|" + /*DE80*/'A' + "|" + /*DE81*/ 'A' + "|" + /*DE82*/ 'A' + "|" + /*DE83*/ 'A' + "|" + /*DE84*/'A' + "|" + /*DE85*/ 'A' + "|" + /*DE86*/'A' + "|" + /*DE87*/ 'A' + "|" + /*DE88*/ 'A' + "|" +/*DE89*/ 'A' + "|" + /*DE90*/'A' + "|" + /*DE91*/ 'A' + "|" +/*DE92*/'A' + "|" + cmdData.DE93TransactionDestinationInstitutionIDCode + "|" + cmdData.DE94TransactionOriginatorInstitutionIDCode + "|" + cmdData.DE95PartialReversal + "|" + /*DE96*/'A' + "|" + /*DE97*/ 'A' + "|" + /*DE98*/ 'A' + "|"
                    + /*DE99*/ 'A' + "|" + cmdData.DE100ReceivingInstitutionIDCode + "|" + /*DE101*/ 'A' + "|" + /*DE102*/ 'A' + "|" + /*DE103*/ 'A' + "|" + /*DE104*/ 'A' + "|" + /*DE105*/ 'A' + "|" + /*DE106*/ 'A' + "|" + /*DE107*/ 'A' + "|" + /*DE108*/ 'A' + "|" + /*DE109*/ 'A' + "|" + /*DE110*/ 'A' + "|" + /*DE111ASS_AMOUNT*/ 'A' + "|" + /*DE112*/ 'A' + "|" + /*DE113*/ 'A' + "|" + /*DE114*/ 'A' + "|" + /*DE115*/ 'A' + "|" + /*DE116*/ 'A' + "|" + /*DE117*/ 'A' + "|" + /*DE118*/'A' + "|" + /*DE119*/ 'A' + "|" + /*DE120*/ 'A' + "|"
                    + /*DE121*/ 'A' + "|" + /*DE122*/ 'A' + "|" + /*ADDN_DATA3*/ 'A' + "|" + /*ADDN_DATA4*/ 'A' + "|" + /*ADDN_DATA5*/ 'A' + "|" + /*DE126*/  'A' + "|" + /*NET_DATE*/  'A' + "|" + /*DE128*/  'A' + "|";
                //SwitchLogger.TerminalTraceLog(this, "MastercardData Message Recieved : -|" +"Sr.No "+ cmdData.indexno + "|"+ cmdData.Mastercarddata);
                if (cmdData.indexno == 2)
                {

                    // SwitchLogger.TerminalTraceLog(this, "Sr.No:| FileHeader  | DE2CardNumber |DE3ProcessingCode |DE4TransactionAmount |DE5ReconciliationAmount |DE6CardholderBilling |DE7 |DE8BILLING_AMT|DE9ConversationRateReconciliation|DE10ConversationRateCardholderBilling |DE11|DE12LocalTransactionDateTime|DE13|DE14ExpiredDate | DE15|DE16|DE17|DE18|DE19|DE20|DE21|DE22PanEntryMode|DE23CardSequenceNumber |DE24FunctionCode|DE25MSG_RSNCODE|DE26CardAcceptorBusinessCode |DE27|DE28|DE29|DE30AmountsOriginal|DE31AcquirerReferenceData |DE32AcquirerInstitutionCode|DE33ACQ_INST_ID|DE34FWDINST_ID|DE35|DE36|DE37ReferenceNumber | |DE38REFERENCE_NUMB|DE39|DE40SERV_CODE|DE41TerminalID |DE42TerminalLocation |DE43CardAccepterName |DE44|DE45|DE46|DE47|DE48AdditionalData |DE49TRAN_CURR|DE50CurrencyCodeReconciliation |DE51SettlementCurrencyCodeCardholderBilling |DE52|DE53|DE54AdditionalAmounts|DE55ChipData|DE56|DE57|DE58|DE59|DE60|DE61|ADDN_DATA62|DE63AdditionalIssuerData |DE64|DE65|DE66|DE67|DE68|DE69|DE70|DE71MessageNumber|DE72DATA_RECORD|DE73ACTION_DATE|DE74|DE75|DE76|DE77|DE78|DE79|DE80|DE81|DE82|DE83|DE84|DE85|DE86|DE87|DE88|DE89|DE90|DE91|DE92|DE93TransactionDestinationInstitutionIDCode |DE94TransactionOriginatorInstitutionIDCode |DE95ISS_REFDATA|DE96|DE97|DE98|DE99|DE100ReceivingInstitutionIDCode |DE101|DE102|DE103|DE104|DE105|DE106|DE107|DE108|DE109|DE110|DE111ASS_AMOUNT|DE112|DE113|DE114|DE115|DE116|DE117|DE118|DE119|DE120|DE121|DE122|DE123ADDN_DATA3|DE124ADDN_DATA4|DE125ADDN_DATA5|DE126|DE127NET_DATE|DE128|");
                }
            }


            //SwitchLogger.TerminalTraceLog(this, " Message Sr.No: -" + "|" + cmdData.indexno + "|"+ cmdData.Mastercarddata);
        }

    }

}
