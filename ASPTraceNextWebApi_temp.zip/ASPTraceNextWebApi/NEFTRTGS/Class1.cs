﻿namespace NEFTRTGS
{
    public class Class1
    {

    }
}
