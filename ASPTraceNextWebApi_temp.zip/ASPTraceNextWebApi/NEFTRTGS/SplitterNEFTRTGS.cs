﻿using ImportData;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using Utility;

namespace NEFTRTGS
{
   public class SplitterNEFTRTGS
    { 
        private readonly string _connectionString;
        BulkImports bulkimports;
        public SplitterNEFTRTGS(string connectionString , string MekKey1 , string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        public DataTable SplitData(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("IDBIReferenceNo", typeof(string));
            _DataTable.Columns.Add("ReturnRefNo", typeof(string));
            _DataTable.Columns.Add("UTRNo", typeof(string));
            _DataTable.Columns.Add("BankCode", typeof(string));//P
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("SenderIFSC", typeof(string));
            _DataTable.Columns.Add("SenderCustName", typeof(string));
            _DataTable.Columns.Add("SenderAccountNo", typeof(string));//No
            _DataTable.Columns.Add("SenderAccType", typeof(string));//P
            _DataTable.Columns.Add("SenderRecvInfo", typeof(string));//P
            _DataTable.Columns.Add("OriginatorOfRemittance", typeof(string));//P
            _DataTable.Columns.Add("BeneficiaryAccType", typeof(string));//P
            _DataTable.Columns.Add("BeneficiaryIFSC", typeof(string));
            _DataTable.Columns.Add("BenefCustName", typeof(string));
            _DataTable.Columns.Add("BenefAccountNo", typeof(string));//No
            _DataTable.Columns.Add("TransType", typeof(string));//P
            _DataTable.Columns.Add("TransSubType", typeof(string));//P
            _DataTable.Columns.Add("Return_IDBI_UTRNO", typeof(string));//P
            _DataTable.Columns.Add("Return_Bank_UTRNO", typeof(string));//P
            _DataTable.Columns.Add("ReasonCode", typeof(string));//P
            _DataTable.Columns.Add("ReasonDescription", typeof(string));//P
            _DataTable.Columns.Add("Status", typeof(string));
            _DataTable.Columns.Add("FILE_NAME", typeof(string));
            _DataTable.Columns.Add("Tr_TimeStamp", typeof(DateTime));//P
            _DataTable.Columns.Add("DELETED_BY_CORP_ID", typeof(string));
            _DataTable.Columns.Add("DELETED_TIME", typeof(DateTime));//P
            _DataTable.Columns.Add("VERIFIED_BY_CORP_ID", typeof(string));
            _DataTable.Columns.Add("VERIFIED_TIME", typeof(DateTime));//P
            _DataTable.Columns.Add("DELETED_BY_USER_ID", typeof(string));
            _DataTable.Columns.Add("VERIFIED_BY_USER_ID", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            
            

            
            
            
            

            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            //ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());
            int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());
            InsertCount = 0;
            TotalCount = 0;
            ChannelID = 0;
            ModeID = 0;
            string[] TotalCountArray = File.ReadAllLines(path);
            string strFileName = Path.GetFileNameWithoutExtension(path);
            string FD = strFileName.Substring(strFileName.Length - 14);
            FD = FD.Replace("Report", "").ToString();
            DateTime FileDate = DateTime.ParseExact(FD, "yyyyMMdd", CultureInfo.InvariantCulture);
            // String FileDate = DateTime.ParseExact(FD, "yyyyMMdd", null).ToString("yyyyMMdd");



            DataTable dtexcelsheetname = null;
            try
            {
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                OleDbConnection objConn = new OleDbConnection(connString);
                string extension = Path.GetExtension(path);
                switch (extension.ToLower())
                {

                    case ".xls": //Excel 97-03
                        // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1\'";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                        break;
                }

                try
                {
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }
                catch
                {
                    switch (extension.ToLower())
                    {
                        case ".xls": //Excel 97-03
                            connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                    }
                    objConn = new OleDbConnection(connString);
                    objConn.Open();
                }

                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                String[] excelSheets = new String[dtexcelsheetname.Rows.Count];
                int j = 0;
                foreach (DataRow row in dtexcelsheetname.Rows)
                {
                    excelSheets[j] = row["TABLE_NAME"].ToString();

                    string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";

                    OleDbCommand cmd = new OleDbCommand(Getdatafromsheet1, objConn);
                    OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                    DataTable dtSheet = new DataTable();
                    da.Fill(dtSheet);
                    objConn.Close();


                    #region code
                    if (dtSheet.Rows.Count > 1)
                    {
                        {
                            if (FileName.Contains("B25"))
                            {
                                for (int i = 0; i < dtSheet.Rows.Count; i++)
                                {
                                    int Incr = 1;

                                    string IDBIReferenceNo = string.Empty;
                                    string ReturnRefNo = string.Empty;
                                    string UTRNo = string.Empty;
                                    string BankCode = string.Empty;
                                    string TxnsAmount = "0";
                                    string TxnsDateTime = string.Empty;
                                    string SenderIFSC = string.Empty;
                                    string SenderCustName = string.Empty;
                                    string SenderAccountNo = string.Empty;
                                    string SenderAccType = string.Empty;
                                    string SenderRecvInfo = string.Empty;
                                    string OriginatorOfRemittance = string.Empty;
                                    string BeneficiaryAccType = string.Empty;
                                    string BeneficiaryIFSC = string.Empty;
                                    string BenefCustName = string.Empty;
                                    string BenefAccountNo = string.Empty;
                                    string TransType = string.Empty;
                                    string TransSubType = string.Empty;
                                    string Return_IDBI_UTRNO = string.Empty;
                                    string Return_Bank_UTRNO = string.Empty;
                                    string ReasonCode = string.Empty;
                                    string ReasonDescription = string.Empty;
                                    string Status = string.Empty;
                                    string FILENAME = string.Empty;
                                    string Tr_TimeStamp = string.Empty;
                                    string DELETED_BY_CORP_ID = string.Empty;
                                    string DELETED_TIME = string.Empty;
                                    string VERIFIED_BY_CORP_ID = string.Empty;
                                    string VERIFIED_TIME = string.Empty;
                                    string DELETED_BY_USER_ID = string.Empty;
                                    string VERIFIED_BY_USER_ID = string.Empty;
                                    string Remarks = string.Empty;
                                    string ReserveField1 = string.Empty;
                                    string ReserveField2 = string.Empty;


                                    try
                                    {

                                        if (Getdatafromsheet1.Contains("INWARD"))
                                        {

                                            IDBIReferenceNo = dtSheet.Rows[i][0].ToString().Trim();
                                            UTRNo = dtSheet.Rows[i][1].ToString().Trim();
                                            BankCode = dtSheet.Rows[i][2].ToString().Trim();
                                            TxnsAmount = dtSheet.Rows[i][3].ToString().Trim();
                                            TxnsDateTime = dtSheet.Rows[i][4].ToString().Trim();
                                            TxnsDateTime = DateTime.ParseExact(TxnsDateTime, "yyyyMMdd", null).ToString("yyyy-MM-dd");
                                            SenderIFSC = dtSheet.Rows[i][5].ToString().Trim();
                                            SenderCustName = dtSheet.Rows[i][6].ToString().Trim();
                                            SenderAccountNo = dtSheet.Rows[i][7].ToString().Trim();
                                            SenderAccType = dtSheet.Rows[i][8].ToString().Trim();
                                            SenderRecvInfo = dtSheet.Rows[i][9].ToString().Trim();
                                            OriginatorOfRemittance = dtSheet.Rows[i][10].ToString().Trim();
                                            BeneficiaryAccType = dtSheet.Rows[i][11].ToString().Trim();
                                            BeneficiaryIFSC = dtSheet.Rows[i][12].ToString().Trim();
                                            BenefCustName = dtSheet.Rows[i][13].ToString().Trim();
                                            BenefAccountNo = dtSheet.Rows[i][14].ToString().Trim();
                                            TransType = dtSheet.Rows[i][15].ToString().Trim();
                                            if (TransType == "NEFT")
                                            {
                                                ChannelID = (int)TxnsChannelID.NEFT;
                                            }
                                            if (TransType == "RTGS")
                                            {
                                                ChannelID = (int)TxnsChannelID.RTGS;
                                            }

                                            TransSubType = dtSheet.Rows[i][16].ToString().Trim();


                                            ModeID = (int)TxnsMode.INWARD;

                                            Return_IDBI_UTRNO = dtSheet.Rows[i][17].ToString().Trim();
                                            Return_Bank_UTRNO = dtSheet.Rows[i][18].ToString().Trim();
                                            ReasonCode = dtSheet.Rows[i][19].ToString().Trim();
                                            ReasonDescription = dtSheet.Rows[i][20].ToString().Trim();
                                            Status = dtSheet.Rows[i][21].ToString().Trim();
                                            FILENAME = dtSheet.Rows[i][22].ToString().Trim();
                                            Tr_TimeStamp = dtSheet.Rows[i][23].ToString().Trim();
                                            Tr_TimeStamp = Tr_TimeStamp.Substring(0, 19).ToString();
                                            Tr_TimeStamp = DateTime.ParseExact(Tr_TimeStamp, "yyyy-MM-dd HH:mm:ss", null).ToString("yyyy-MM-dd HH:mm:ss");




                                            _DataTable.Rows.Add(ClientID, ChannelID, ModeID, IDBIReferenceNo, ReturnRefNo, UTRNo, BankCode, TxnsAmount, TxnsDateTime, SenderIFSC,
                                                 SenderCustName, SenderAccountNo, SenderAccType, SenderRecvInfo, OriginatorOfRemittance, BeneficiaryAccType, BeneficiaryIFSC,
                                               BenefCustName, BenefAccountNo, TransType, TransSubType, Return_IDBI_UTRNO, Return_Bank_UTRNO, ReasonCode, ReasonDescription, Status, FILENAME, Tr_TimeStamp,
                                               DELETED_BY_CORP_ID, DELETED_TIME.Length == 0 ? null : DELETED_TIME, VERIFIED_BY_CORP_ID, VERIFIED_TIME.Length == 0 ? null : VERIFIED_TIME, DELETED_BY_USER_ID, VERIFIED_BY_USER_ID, Remarks, ReserveField1, ReserveField2,

                                               FileDate, path, FileName, System.DateTime.Now, System.DateTime.Now,
                                              UserName, "");


                                        }

                                        else
                                        {

                                            IDBIReferenceNo = dtSheet.Rows[i][2].ToString().Trim();
                                            ReturnRefNo = dtSheet.Rows[i][1].ToString().Trim();//RETURN REF NO
                                            UTRNo = dtSheet.Rows[i][0].ToString().Trim();
                                            BankCode = dtSheet.Rows[i][3].ToString().Trim();
                                            TxnsAmount = dtSheet.Rows[i][5].ToString().Trim();
                                            TxnsDateTime = dtSheet.Rows[i][6].ToString().Trim();
                                            TxnsDateTime = DateTime.ParseExact(TxnsDateTime, "yyyyMMdd", null).ToString("yyyy-MM-dd");
                                            SenderIFSC = dtSheet.Rows[i][8].ToString().Trim();
                                            SenderCustName = dtSheet.Rows[i][9].ToString().Trim();
                                            SenderAccountNo = dtSheet.Rows[i][10].ToString().Trim();
                                            SenderAccType = dtSheet.Rows[i][11].ToString().Trim();
                                            OriginatorOfRemittance = dtSheet.Rows[i][15].ToString().Trim();
                                            BeneficiaryAccType = dtSheet.Rows[i][19].ToString().Trim();
                                            BeneficiaryIFSC = dtSheet.Rows[i][16].ToString().Trim();
                                            BenefCustName = dtSheet.Rows[i][17].ToString().Trim();
                                            BenefAccountNo = dtSheet.Rows[i][18].ToString().Trim();
                                            TransType = dtSheet.Rows[i][4].ToString().Trim();
                                            if (TransType == "NEFT")
                                            {
                                                ChannelID = (int)TxnsChannelID.NEFT;
                                            }
                                            if (TransType == "RTGS")
                                            {
                                                ChannelID = (int)TxnsChannelID.RTGS;
                                            }

                                            ModeID = (int)TxnsMode.OUTWARD;
                                            SenderRecvInfo = dtSheet.Rows[i][21].ToString().Trim();
                                            ReasonCode = dtSheet.Rows[i][22].ToString().Trim();
                                            ReasonDescription = dtSheet.Rows[i][23].ToString().Trim();
                                            Status = dtSheet.Rows[i][7].ToString().Trim();
                                            FILENAME = dtSheet.Rows[i][24].ToString().Trim();
                                            Tr_TimeStamp = dtSheet.Rows[i][25].ToString().Trim();
                                            Tr_TimeStamp = Tr_TimeStamp.Substring(0, 19).ToString();
                                            Tr_TimeStamp = DateTime.ParseExact(Tr_TimeStamp, "yyyy-MM-dd HH:mm:ss", null).ToString("yyyy-MM-dd HH:mm:ss");

                                            DELETED_BY_CORP_ID = dtSheet.Rows[i][26].ToString().Trim();
                                            DELETED_TIME = dtSheet.Rows[i][27].ToString().Trim();
                                            if (DELETED_TIME == "")
                                            {
                                                DELETED_TIME = DELETED_TIME = null;
                                            }
                                            else
                                            {
                                                DELETED_TIME = DELETED_TIME.Substring(0, 19).ToString();
                                                DELETED_TIME = DateTime.ParseExact(DELETED_TIME, "yyyy-MM-dd HH:mm:ss", null).ToString("yyyy-MM-dd HH:mm:ss");
                                            }

                                            VERIFIED_BY_CORP_ID = dtSheet.Rows[i][28].ToString().Trim();
                                            VERIFIED_TIME = dtSheet.Rows[i][29].ToString().Trim();
                                            if (VERIFIED_TIME == "")
                                            {
                                                VERIFIED_TIME = VERIFIED_TIME = null;
                                            }
                                            else
                                            {
                                                VERIFIED_TIME = VERIFIED_TIME.Substring(0, 19).ToString();
                                                VERIFIED_TIME = DateTime.ParseExact(VERIFIED_TIME, "yyyy-MM-dd HH:mm:ss", null).ToString("yyyy-MM-dd HH:mm:ss");
                                            }

                                            DELETED_BY_USER_ID = dtSheet.Rows[i][30].ToString().Trim();
                                            VERIFIED_BY_USER_ID = dtSheet.Rows[i][31].ToString().Trim();


                                            _DataTable.Rows.Add(ClientID, ChannelID, ModeID, IDBIReferenceNo, ReturnRefNo, UTRNo, BankCode, TxnsAmount, TxnsDateTime, SenderIFSC,
                                                SenderCustName, SenderAccountNo, SenderAccType, SenderRecvInfo, OriginatorOfRemittance, BeneficiaryAccType, BeneficiaryIFSC,
                                              BenefCustName, BenefAccountNo, TransType, TransSubType, Return_IDBI_UTRNO, Return_Bank_UTRNO, ReasonCode, ReasonDescription, Status, FILENAME, Tr_TimeStamp,
                                              DELETED_BY_CORP_ID, DELETED_TIME, VERIFIED_BY_CORP_ID, VERIFIED_TIME, DELETED_BY_USER_ID, VERIFIED_BY_USER_ID, Remarks, ReserveField1, ReserveField2,
                                              FileDate, path, FileName, System.DateTime.Now, System.DateTime.Now,
                                             UserName, "");
                                        }
                                    }

                                    catch (Exception ex)
                                    {
                                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                                    }
                                    LineNo++;
                                    InsertCount++;
                                    j++;
                                }
                            }


                            #endregion code

                            j = 1;
                        }

                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;
        }
    }
}
