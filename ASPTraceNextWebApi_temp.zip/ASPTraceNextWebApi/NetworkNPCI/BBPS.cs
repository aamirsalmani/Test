﻿using System;
using System.Collections.Generic;
using System.Text;
using Utility;

namespace NetworkNPCI
{
    class BBPS
    {
         
        private readonly string _connectionString;
        public BBPS(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
        }

    }
}
