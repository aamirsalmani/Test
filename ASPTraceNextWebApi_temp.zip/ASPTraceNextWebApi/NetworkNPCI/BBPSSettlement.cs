﻿using ImportData;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Text;
using Utility;

namespace NetworkNPCI
{
    public class BBPSSettlement: BBPSSettlementsplitter
    {
       
        private readonly string _connectionString;

        public BBPSSettlement(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;

        }

        public DataTable BBPSSettlementSplitter(string FilePath, string FileName, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();
            try
            {
                _DataTable.Columns.Add("ClientID", typeof(string));
                _DataTable.Columns.Add("Date", typeof(DateTime));
                _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
                _DataTable.Columns.Add("Cycle", typeof(string));
                _DataTable.Columns.Add("Customer", typeof(string));
                _DataTable.Columns.Add("BillCategory", typeof(string));
                _DataTable.Columns.Add("Description", typeof(string));
                _DataTable.Columns.Add("NoOfTxns", typeof(int));
                _DataTable.Columns.Add("DebitAmt", typeof(decimal));
                _DataTable.Columns.Add("CreditAmt", typeof(decimal));


                _DataTable = BBPSSettlementsplit(FilePath, _DataTable, UserName, ClientCode, FileName, _connectionString, out InsertCount, out TotalCount);
            }
            catch (Exception EX)
            {
                LogWriter _log = new LogWriter();
                _log.FunErrorLog(EX.Message.ToString(), ClientCode, currentMethod?.DeclaringType?.Name, currentMethod?.Name, 0, FileName, UserName, 'E');
              //  DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

            }
            return _DataTable;
        }

    }
}


