﻿using System;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using Utility;

namespace NetworkNPCI
{
    public class BBPSSettlementsplitter
    {
        LogWriter _log = new LogWriter();

        protected DataTable BBPSSettlementsplit(string FilePath, DataTable _DataTable, string UserName, string BankCode, string FileName, string ConnectionString, out int InsertCount, out int TotalCount)
        {

            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            string Description = string.Empty;
            string Typemode = string.Empty;
            string AccountNumber = string.Empty;

            string Cycle = string.Empty;
            string FileDate = string.Empty;
            DateTime Date = new DateTime();
            string Customer = string.Empty;


            try
            {
                string[] ArrayGLLines;
                int i = 0;
                ArrayGLLines = File.ReadAllLines(FilePath, Encoding.Default);
                int totalrecords = ArrayGLLines.Length;
                while (totalrecords > i)
                {

                    LineNo++;
                    TotalCount++;
                    string LBRCODE = string.Empty;
                    string PRDACCTID = string.Empty;
                    string ACTUALDAT = string.Empty;
                    string SYSTRACENUM = string.Empty;
                    string ACCOUNTNUM = string.Empty;
                    string CARDNUM = string.Empty;
                    string BRBATCH = string.Empty;
                    string BRSETNUM = string.Empty;
                    string BRENTRYDA = string.Empty;
                    string TOBRCODE = string.Empty;
                    string TOBRBATCH = string.Empty;
                    string TOBRSETNUM = string.Empty;
                    string TOBRENTRY = string.Empty;
                    string TRANSTYPE = string.Empty;
                    string ENTRYTYPE = string.Empty;
                    string TRANSTIME = string.Empty;
                    string DRCR = string.Empty;
                    string AMOUNT = string.Empty;
                    string MAINACCTNUM = string.Empty;
                    string PROCESS_CODE = string.Empty;
                    string SYS_TRACENUM = string.Empty;
                    string TERMINAL_ID = string.Empty;
                    string FRM_ACNO = string.Empty;
                    string AUTH_ID = string.Empty;
                    string RRN = string.Empty;
                    string REFERENCENO = string.Empty;
                    string ACQ_INSTITUCODE = string.Empty;
                    string TERMINAL_LOC = string.Empty;
                    string CARD_NUMBER = string.Empty;
                    string LEDGER_BAL = string.Empty;
                    string NET_BAL = string.Empty;
                    DateTime TxnsDateTime;
                    string TRANSDATE = string.Empty;
                    string RESPONSE_CODE = string.Empty;
                    string REVERSAL_CASE = string.Empty;
                    string LOROMODE = string.Empty;
                    string STAN_N = string.Empty;
                    string RR_NO = string.Empty;
                    string STATION_ID = string.Empty;
                    string TXN_TI = string.Empty;
                    string TXN_TI1 = string.Empty;
                    string _DateTime = string.Empty;
                    string TRAN_C = string.Empty;
                    string BANCS_JOU = string.Empty;
                    string CUSTOMER_NO = string.Empty;
                    string CARD_NO = string.Empty;
                    string TRAN_AMOUNT = string.Empty;
                    string sline = string.Empty;
                    string Atm_Pos = string.Empty;
                    string CORR_JOUR = string.Empty;
                    string PSRLNO = string.Empty;
                    string TXNTYPE = string.Empty;
                    double DebitAmt = 0;
                    double CreditAmt = 0;
                    string BAL = string.Empty;
                    string BatchSeq = string.Empty;
                    string BillCategory = string.Empty;
                    string temp_sline = string.Empty;
                    string NoOfTxns = string.Empty;

                    try
                    {

                        sline = ArrayGLLines[i];


                        string[] SplitArr = sline.Split(',');

                        int len = SplitArr.Count();

                        if (sline.Contains("Settlement Cycle"))
                        {
                            string[] split = SplitArr[3].ToString().Split(':');
                            Cycle = split[1].ToString().Substring(3, 1) + "C";
                        }


                        if (sline.Contains("IST"))
                        {
                            string[] split0 = SplitArr[3].ToString().Split(' ');
                            if (split0[2].ToString() == "IST")
                            {
                                FileDate = (split0[0]).ToString() + " " + (split0[1]);
                                Date = DateTime.ParseExact(FileDate.ToString(), "dd/MM/yyyy HH:mm:ss", new CultureInfo("en-US"));

                            }
                        }

                        TxnsDateTime = Date.AddDays(-1);

                        if (SplitArr[2].Length > 0 && SplitArr[2] != "Total" || SplitArr[2] != "Goods & Services Tax" && SplitArr.Contains("."))
                        {
                            try
                            {
                                string[] split1 = SplitArr[2].ToString().Split('.');
                                Customer = split1[1].ToString();
                            }
                            catch
                            {

                            }
                        }

                        if (sline.Contains("Bill Payment"))
                        {


                            if (SplitArr[5].ToString() != "")
                            {
                                int startindex = i;
                                for (int j = startindex + 1; j < ArrayGLLines.Length; j++)
                                {
                                    try
                                    {
                                        temp_sline = ArrayGLLines[j];

                                        string[] SplitArr1 = temp_sline.Split(',', '\"');
                                        if (SplitArr1[5] != "" || SplitArr1[6].ToString() == "" || SplitArr1[6].ToString() == null)
                                        { break; }

                                        if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr1[7]); }

                                        if (SplitArr1.Count() > 13)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                        }
                                        else if (SplitArr1.Count() > 10)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                        }
                                        else
                                        {

                                            if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                            if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                        }
                                        _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[5].ToString(), SplitArr1[6].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                                    }
                                    catch { }

                                    i++;
                                }
                            }

                        }


                        if (sline.Contains("Bill Fetch"))
                        {
                            if (SplitArr[5].ToString() != "")
                            {
                                int startindex = i;
                                for (int j = startindex + 1; j < ArrayGLLines.Length; j++)
                                {
                                    try
                                    {
                                        temp_sline = ArrayGLLines[j];
                                        string[] SplitArr1 = temp_sline.Split(',', '\"');
                                        if (SplitArr1[5] != "" || SplitArr1[6].ToString() == "" || SplitArr1[6].ToString() == null)
                                        { break; }

                                        if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr1[7]); }

                                        if (SplitArr1.Count() > 13)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                        }
                                        else if (SplitArr1.Count() > 10)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                        }
                                        else
                                        {

                                            if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                            if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                        }
                                        _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[5].ToString(), SplitArr1[6].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                                    }
                                    catch { }
                                    i++;
                                }
                            }
                        }


                        if (sline.Contains("Refund Amount"))
                        {
                            if (SplitArr[5].ToString() != "")
                            {
                                int startindex = i;
                                for (int j = startindex + 1; j < ArrayGLLines.Length; j++)
                                {
                                    try
                                    {
                                        temp_sline = ArrayGLLines[j];
                                        string[] SplitArr1 = temp_sline.Split(',', '\"');
                                        if (SplitArr1[5] != "" || SplitArr1[6].ToString() == "" || SplitArr1[6].ToString() == null)
                                        { break; }

                                        if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr1[7]); }

                                        if (SplitArr1.Count() > 13)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                        }
                                        else if (SplitArr1.Count() > 10)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                        }
                                        else
                                        {
                                            if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                            if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                        }
                                        _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[5].ToString(), SplitArr1[6].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                                    }
                                    catch { }
                                    i++;
                                }
                            }
                        }


                        if (sline.Contains("Force Payment Amount"))
                        {
                            if (SplitArr[5].ToString() != "")
                            {
                                int startindex = i;
                                for (int j = startindex + 1; j < ArrayGLLines.Length; j++)
                                {
                                    try
                                    {
                                        temp_sline = ArrayGLLines[j];
                                        string[] SplitArr1 = temp_sline.Split(',', '\"');
                                        if (SplitArr1[5] != "" || SplitArr1[6].ToString() == "" || SplitArr1[6].ToString() == null)
                                        { break; }

                                        if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr1[7]); }

                                        if (SplitArr1.Count() > 13)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                        }
                                        else if (SplitArr1.Count() > 10)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                        }
                                        else
                                        {
                                            if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                            if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                        }
                                        _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[5].ToString(), SplitArr1[6].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                                    }
                                    catch { }
                                    i++;
                                }
                            }
                        }


                        if (sline.Contains("Good Faith Payment Amount"))
                        {
                            if (SplitArr[5].ToString() != "")
                            {
                                int startindex = i;
                                for (int j = startindex + 1; j < ArrayGLLines.Length; j++)
                                {
                                    try
                                    {
                                        temp_sline = ArrayGLLines[j];
                                        string[] SplitArr1 = temp_sline.Split(',', '\"');
                                        if (SplitArr1[5] != "" || SplitArr1[6].ToString() == "" || SplitArr1[6].ToString() == null)
                                        { break; }

                                        if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr1[7]); }

                                        if (SplitArr1.Count() > 13)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                        }
                                        else if (SplitArr1.Count() > 10)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                        }
                                        else
                                        {
                                            if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                            if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                        }
                                        _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[5].ToString(), SplitArr1[6].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                                    }
                                    catch { }
                                    i++;
                                }
                            }
                        }


                        if (sline.Contains("Credit Adjustment Amount"))
                        {
                            if (SplitArr[5].ToString() != "")
                            {
                                int startindex = i;
                                for (int j = startindex + 1; j < ArrayGLLines.Length; j++)
                                {
                                    try
                                    {
                                        temp_sline = ArrayGLLines[j];
                                        string[] SplitArr1 = temp_sline.Split(',', '\"');
                                        if (SplitArr1[5] != "" || SplitArr1[6].ToString() == "" || SplitArr1[6].ToString() == null)
                                        { break; }

                                        if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr1[7]); }

                                        if (SplitArr1.Count() > 13)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                        }
                                        else if (SplitArr1.Count() > 10)
                                        {
                                            if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                            if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                        }
                                        else
                                        {

                                            if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                            if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                        }
                                        _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[5].ToString(), SplitArr1[6].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                                    }
                                    catch { }
                                    i++;
                                }
                            }
                        }

                        if (sline.Contains(",Total,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[2].ToString() == ("Total"))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {

                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[5].ToString(), SplitArr[2].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }
                        if (sline.Contains(",Goods & Services Tax,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[2].ToString() == ("Goods & Services Tax"))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {
                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[5].ToString(), SplitArr[2].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }


                        if (sline.Contains(",BBPCU Service Charges,"))
                        {
                            string[] SplitArr0 = sline.Split(',', '\"');
                            string stype = SplitArr0[1].ToString();
                            if (SplitArr[1].ToString() != "")
                            {
                                stype = "";
                                int startindex = i;
                                for (int j = startindex + 1; j < ArrayGLLines.Length; j++)
                                {

                                    try
                                    {
                                        temp_sline = ArrayGLLines[j];
                                        string temp_sline1 = ArrayGLLines[j - 1];
                                        string[] SplitArr1 = temp_sline.Split(',', '\"');
                                        string[] SplitArr2 = temp_sline1.Split(',', '\"');
                                        if (SplitArr1[5] != "" || SplitArr1[6].ToString() == "" || SplitArr1[6].ToString() == null)
                                        { break; }
                                        else
                                        {
                                            if (SplitArr1[6] == "Goods & Services Tax")
                                            {
                                                Description = SplitArr1[6] + "_" + SplitArr2[6].ToString();
                                            }
                                            else
                                            {
                                                Description = SplitArr1[6];
                                            }
                                            if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr1[7]); }

                                            if (SplitArr1.Count() > 13)
                                            {
                                                if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                                if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                            }
                                            else if (SplitArr1.Count() > 10)
                                            {
                                                if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                                if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                            }
                                            else
                                            {
                                                if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                                if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                            }
                                            stype = SplitArr1[6].ToString();
                                            _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[1].ToString(), Description, NoOfTxns, DebitAmt, CreditAmt);
                                        }
                                    }
                                    catch { }
                                    i++;
                                }
                            }
                        }


                        if (sline.Contains(",Service Charges -Subtotal,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[1].ToString() == ("Service Charges -Subtotal"))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {
                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[5].ToString(), SplitArr[1].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }
                        if (sline.Contains(",Service Charges-Goods & Services Tax,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[1].ToString() == ("Service Charges-Goods & Services Tax"))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {
                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[5].ToString(), SplitArr[1].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }



                        if (sline.Contains(",BBPCU Switching Fee,"))
                        {
                            string[] SplitArr0 = sline.Split(',', '\"');
                            string stype = SplitArr0[1].ToString();
                            if (SplitArr[1].ToString() != "")
                            {
                                stype = "";
                                int startindex = i;
                                for (int j = startindex + 1; j < ArrayGLLines.Length; j++)
                                {

                                    try
                                    {
                                        temp_sline = ArrayGLLines[j];
                                        string temp_sline1 = ArrayGLLines[j - 1];
                                        string[] SplitArr1 = temp_sline.Split(',', '\"');
                                        string[] SplitArr2 = temp_sline1.Split(',', '\"');
                                        if (SplitArr1[5] != "" || SplitArr1[6].ToString() == "" || SplitArr1[6].ToString() == null)
                                        { break; }
                                        else
                                        {
                                            if (SplitArr1[6] == "Goods & Services Tax")
                                            {
                                                Description = SplitArr1[6] + "_" + SplitArr2[6].ToString();
                                            }
                                            else
                                            {
                                                Description = SplitArr1[6];
                                            }
                                            if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr1[7]); }
                                            if (SplitArr1.Count() > 13)
                                            {
                                                if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }

                                                if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                            }
                                            else if (SplitArr1.Count() > 10)
                                            {
                                                if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                                if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                            }
                                            else
                                            {
                                                if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                                if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                            }
                                            _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, Customer, SplitArr[1].ToString(), Description, NoOfTxns, DebitAmt, CreditAmt);
                                        }
                                    }
                                    catch { }
                                    i++;
                                }
                            }
                        }


                        if (sline.Contains(",Switching Fees Subtotal,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[1].ToString() == ("Switching Fees Subtotal"))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {
                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, "", SplitArr[5].ToString(), SplitArr[1].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }


                        if (sline.Contains(",Switching Fees -Goods & Services Tax,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[1].ToString() == ("Switching Fees -Goods & Services Tax"))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {

                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, "", SplitArr[5].ToString(), SplitArr[1].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }




                        if (sline.Contains(",NBBL Fees - Total,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[1].ToString() == ("NBBL Fees - Total"))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {

                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, "", SplitArr[5].ToString(), SplitArr[1].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }


                        if (sline.Contains(",NBBL Fees - Total Goods & Services Tax,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[1].ToString() == ("NBBL Fees - Total Goods & Services Tax"))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {

                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, "", SplitArr[5].ToString(), SplitArr[1].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }


                        if (sline.Contains(",GRAND TOTAL ,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[1].ToString() == ("GRAND TOTAL "))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {

                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, "", SplitArr[5].ToString(), SplitArr[1].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }

                        if (sline.Contains(",GRAND TOTAL for GOODS & SERVICES TAX PAID,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[1].ToString() == ("GRAND TOTAL for GOODS & SERVICES TAX PAID"))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {

                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, "", SplitArr[5].ToString(), SplitArr[1].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }

                        if (sline.Contains(",GRAND TOTAL for GOODS & SERVICES TAX PYBL,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[1].ToString() == ("GRAND TOTAL for GOODS & SERVICES TAX PYBL"))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {

                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, "", SplitArr[5].ToString(), SplitArr[1].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }


                        if (sline.Contains(",NET TOTAL INCLUDING TAX ,"))
                        {
                            string[] SplitArr1 = sline.Split(',', '\"');
                            if (SplitArr1[1].ToString() == ("NET TOTAL INCLUDING TAX "))
                            {
                                if (SplitArr1[7] == null || SplitArr1[7] == "") { NoOfTxns = "0"; } else { NoOfTxns = (SplitArr[7]); }
                                if (SplitArr1.Count() > 13)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[13] + SplitArr1[14]); }
                                }
                                else if (SplitArr1.Count() > 10)
                                {
                                    if (SplitArr1 == null) { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[9] + SplitArr1[10]); }
                                    if (SplitArr1 == null) { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[12]); }
                                }
                                else
                                {

                                    if (SplitArr1[8] == null || SplitArr1[8] == "") { DebitAmt = 0; } else { DebitAmt = Convert.ToDouble(SplitArr1[8]); }
                                    if (SplitArr1[9] == null || SplitArr1[9] == "") { CreditAmt = 0; } else { CreditAmt = Convert.ToDouble(SplitArr1[9]); }
                                }
                                _DataTable.Rows.Add(BankCode, Date, TxnsDateTime, Cycle, "", SplitArr[5].ToString(), SplitArr[1].ToString(), NoOfTxns, DebitAmt, CreditAmt);
                            }
                        }



                        InsertCount++;

                    }
                    catch (Exception ex)
                    {

                        _log.FunErrorLog(ex.Message.ToString(), BankCode, "BBPSSettlement", "BBPSSettlementSplitter", 0, FileName, UserName, 'E');
                    }
                    i++;
                }
            }
            catch (Exception ex)
            {
                _log.FunErrorLog(ex.Message.ToString(), BankCode, "BBPSSettlement", "BBPSSettlementSplitter", 0, FileName, UserName, 'E');
            }
            return _DataTable;
        }
    }
}