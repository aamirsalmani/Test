﻿using ImportData;
using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Text;
using Utility;

namespace NetworkNPCI
{
   public class BBPSSplittter
    {
        
   
        private readonly string _connectionString;
        BulkImports bulkimports;
        public BBPSSplittter(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        public DataTable BBPSNetwork(string FilePath, string FileName, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            DataSet dataSet = new DataSet();

            try
            {
                dataSet.ReadXml(FilePath, XmlReadMode.InferSchema);
                dataSet.Tables[1].Columns.Add("ClientID");
                dataSet.Tables[1].Columns.Add("ChannelID");
                dataSet.Tables[1].Columns.Add("ModeID");
                dataSet.Tables[1].Columns.Add("FileName");
                dataSet.Tables[1].Columns.Add("FilePath");
                dataSet.Tables[1].Columns.Add("CreatedOn");
                dataSet.Tables[1].Columns.Add("CreatedBy");

                foreach (DataRow row in dataSet.Tables[1].Rows)
                {
                    row["ClientID"] = ClientCode;
                    row["ChannelID"] = (int)TxnsChannelID.BBPS;
                    row["ModeID"] = (int)TxnsMode.ACQUIRER;
                    row["FileName"] = FileName;
                    row["FilePath"] = FilePath;
                    row["CreatedOn"] = DateTime.Now;
                    row["CreatedBy"] = UserName;

                }
            }
            catch (Exception EX)
            {
                DBLog.InsertLogs(EX.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, 0, FileName, UserName, 'E', _connectionString);
            }
            return dataSet.Tables[1];
        }

    }
}
