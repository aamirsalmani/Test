﻿namespace NetworkNPCI
{
    public class Class1
    {

    }
}
