﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Text;
using System.Xml;
using Excel = Microsoft.Office.Interop.Excel;
using System.Linq;
using Utility;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Text.Json;
using ImportData;
using System.Reflection;

namespace NetworkNPCI
{
    public class NPCIAEPS
    {

        private readonly string _connectionString;
        BulkImports bulkimports;
        public NPCIAEPS(string connectionString)
        {
            _connectionString = connectionString;
            bulkimports = new BulkImports(_connectionString, " ", " ");
        }
   
        //Siddhant
        public string Splitter_NPCI_Acquirer_AEPS_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int ErrorCount = 0;
            int LineNumber = 0;
            //DynamicAEPSAcquirerTableType

            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails dtdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);  

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNO", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            //  _DataTable.Columns.Add("TRANSDATE", typeof(DateTime));
            //   _DataTable.Columns.Add("TRANSTIME", typeof(DateTime));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(string));//
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(string));//
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(decimal));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(decimal));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(decimal));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(decimal));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("URN", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));


            string RevEntryLeg = "1";
            int Incr = 1;
            string Participant_ID = string.Empty;
            string TxnsDateTime = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty; ;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string Member_Number = string.Empty;
            string Approval_Number = string.Empty;
            string System_Trace_Audit_Number = string.Empty;
            string Transaction_Date = string.Empty;
            string Transaction_Time = string.Empty;
            string Merchant_Category_Code = string.Empty;
            string Card_Acceptor_Settlement_Date = string.Empty;
            string Card_Acceptor_ID = string.Empty;
            string Card_Acceptor_Terminal_ID = string.Empty;
            string Card_Acceptor_Terminal_Location = string.Empty;
            string Acquirer_ID = string.Empty;
            string Acquirer_Settlement_Date = string.Empty; ;
            string Transaction_Currency_code = string.Empty;
            string Transaction_Amount = "0";
            string Actual_Transaction_Amount = "0";
            string Transaction_Acitivity_fee = "0";
            string Acquirer_settlement_Currency_Code = string.Empty;
            string Acquirer_settlement_Amount = "0";
            string Acquirer_Settlement_Fee = "0";
            string Acquirer_settlement_processing_fee = "0";
            string Transaction_Acquirer_Conversion_Rate = "0";
            string ForceMatch = string.Empty;
            string Cycle = string.Empty;
            string URN = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;


            DateTime? TxnsDateTimeMain = null;


            ushort PARICIPATEID_StartPosition = 0;
            ushort PARICIPATEID_Length = 0;
            ushort TRANSACTIONTYPE_StartPosition = 0;
            ushort TRANSACTIONTYPE_Length = 0;
            ushort FromAccountType_StartPosition = 0;
            ushort FromAccountType_Length = 0;
            ushort ToAccountType_StartPosition = 0;
            ushort ToAccountType_Length = 0;
            ushort ReferenceNumber_StartPosition = 0;
            ushort ReferenceNumber_Length = 0;
            ushort ResponseCode_StartPosition = 0;
            ushort ResponseCode_Length = 0;
            ushort PAN_Number_StartPosition = 0;
            ushort PAN_Number_Length = 0;
            ushort MEMNUMBER_StartPosition = 0;
            ushort MEMNUMBER_Length = 0;
            ushort APPROVNO_StartPosition = 0;
            ushort APPROVNO_Length = 0;
            ushort STAUDITNO_StartPosition = 0;
            ushort STAUDITNO_Length = 0;
            ushort TRANSTIME_StartPosition = 0;
            ushort TRANSTIME_Length = 0;
            ushort TRANSDATE_StartPosition = 0;
            ushort TRANSDATE_Length = 0;
            ushort TxnsDateTime_StartPosition = 0;
            ushort TxnsDateTime_Length = 0;
            ushort MERCHENTCATCODE_StartPosition = 0;
            ushort MERCHENTCATCODE_Length = 0;
            ushort CARDACCEPTSETDATE_StartPosition = 0;
            ushort CARDACCEPTSETDATE_Length = 0;
            ushort CARDACCID_StartPosition = 0;
            ushort CARDACCID_Length = 0;
            ushort CARDACCEPTERID_StartPosition = 0;  //Terminal ID
            ushort CARDACCEPTERID_Length = 0;
            ushort CARDACCEPTERTERLOCATION_StartPosition = 0;
            ushort CARDACCEPTERTERLOCATION_Length = 0;
            ushort AcquirerID_StartPosition = 0;
            ushort AcquirerID_Length = 0;
            ushort ACCSETDATE_StartPosition = 0;
            ushort ACCSETDATE_Length = 0;
            ushort TRANSCURRENCYCODE_StartPosition = 0;
            ushort TRANSCURRENCYCODE_Length = 0;
            ushort TxnsAmount_StartPosition = 0;
            ushort TxnsAmount_Length = 0;
            ushort ACCTUALTRANAMOUNT_StartPosition = 0;
            ushort ACCTUALTRANAMOUNT_Length = 0;
            ushort TRANSACCVITYFEE_StartPosition = 0;
            ushort TRANSACCVITYFEE_Length = 0;
            ushort ACCURSETCURCODE_StartPosition = 0;
            ushort ACCURSETCURCODE_Length = 0;
            ushort ACQUIERSETAMOUNT_StartPosition = 0;
            ushort ACQUIERSETAMOUNT_Length = 0;
            ushort ACQUIERSETFEE_StartPosition = 0;
            ushort ACQUIERSETFEE_Length = 0;
            ushort ACQUIERSETPROFEE_StartPosition = 0;
            ushort ACQUIERSETPROFEE_Length = 0;
            ushort TRANSACQUIERCONVERRATE_StartPosition = 0;
            ushort TRANSACQUIERCONVERRATE_Length = 0;
            ushort FORCEMATCH_StartPosition = 0;
            ushort FORCEMATCH_Length = 0;
            ushort Cycle_StartPosition = 0;
            ushort Cycle_Length = 0;
            ushort URN_StartPosition = 0;
            ushort URN_Length = 0;
            ushort ReserveField1_StartPosition = 0;
            ushort ReserveField1_Length = 0;
            ushort ReserveField2_StartPosition = 0;
            ushort ReserveField2_Length = 0;
            ushort ReserveField3_StartPosition = 0;
            ushort ReserveField3_Length = 0;
            ushort ReserveField4_StartPosition = 0;
            ushort ReserveField4_Length = 0;
            ushort ReserveField5_StartPosition = 0;
            ushort ReserveField5_Length = 0;


            bool ErrorOccurred = false;
            string[] TxnDateTime = null;
            string Status = "0";

            string[] CycleList = { "1C", "2C", "3C", "4C" };

            try
            {
               

                //  int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();
                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
                fileImportRequest.TotalCount = TotalCountArray.Length;
                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }
                TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                string[] FDA = fileImportRequest.FileName.Split('_', '.');

                if (fileImportRequest.ConfigData.Rows[0]["ChannelID"].ToString() == "13")
                {
                    Cycle = FDA.Length > 2 ? FDA[2].ToString() : string.Empty;
                }
                else
                {
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;
                }

                Cycle = CycleList.Contains(Cycle) ? Cycle : string.Empty;//13


                DataSet ds = new DataSet();

                ds.ReadXml(new XmlTextReader(new System.IO.StringReader(xmlFile)));


                PARICIPATEID_StartPosition = Convert.ToUInt16(ds.Tables["PARTICIPENTID"].Rows[0]["StartPosition"]);
                PARICIPATEID_Length = Convert.ToUInt16(ds.Tables["PARTICIPENTID"].Rows[0]["Length"]);

                TRANSACTIONTYPE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSTYPE"].Rows[0]["StartPosition"]);
                TRANSACTIONTYPE_Length = Convert.ToUInt16(ds.Tables["TRANSTYPE"].Rows[0]["Length"]);


                FromAccountType_StartPosition = Convert.ToUInt16(ds.Tables["FROMACCTYPE"].Rows[0]["StartPosition"]);
                FromAccountType_Length = Convert.ToUInt16(ds.Tables["FROMACCTYPE"].Rows[0]["Length"]);

                ToAccountType_StartPosition = Convert.ToUInt16(ds.Tables["TOACCTYPE"].Rows[0]["StartPosition"]);
                ToAccountType_Length = Convert.ToUInt16(ds.Tables["TOACCTYPE"].Rows[0]["Length"]);

                ReferenceNumber_StartPosition = Convert.ToUInt16(ds.Tables["TRANSSERIALNO"].Rows[0]["StartPosition"]);
                ReferenceNumber_Length = Convert.ToUInt16(ds.Tables["TRANSSERIALNO"].Rows[0]["Length"]);

                ResponseCode_StartPosition = Convert.ToUInt16(ds.Tables["RESPONSECODE"].Rows[0]["StartPosition"]);
                ResponseCode_Length = Convert.ToUInt16(ds.Tables["RESPONSECODE"].Rows[0]["Length"]);

                PAN_Number_StartPosition = Convert.ToUInt16(ds.Tables["PANNO"].Rows[0]["StartPosition"]);
                PAN_Number_Length = Convert.ToUInt16(ds.Tables["PANNO"].Rows[0]["Length"]);

                MEMNUMBER_StartPosition = Convert.ToUInt16(ds.Tables["MEMNUMBER"].Rows[0]["StartPosition"]);
                MEMNUMBER_Length = Convert.ToUInt16(ds.Tables["MEMNUMBER"].Rows[0]["Length"]);

                APPROVNO_StartPosition = Convert.ToUInt16(ds.Tables["APPROVALNO"].Rows[0]["StartPosition"]);
                APPROVNO_Length = Convert.ToUInt16(ds.Tables["APPROVALNO"].Rows[0]["Length"]);

                STAUDITNO_StartPosition = Convert.ToUInt16(ds.Tables["SYSTRACAUDITNO"].Rows[0]["StartPosition"]);
                STAUDITNO_Length = Convert.ToUInt16(ds.Tables["SYSTRACAUDITNO"].Rows[0]["Length"]);

                TRANSTIME_StartPosition = Convert.ToUInt16(ds.Tables["TRANSTIME"].Rows[0]["StartPosition"]);
                TRANSTIME_Length = Convert.ToUInt16(ds.Tables["TRANSTIME"].Rows[0]["Length"]);

                TRANSDATE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSDATE"].Rows[0]["StartPosition"]);
                TRANSDATE_Length = Convert.ToUInt16(ds.Tables["TRANSTIME"].Rows[0]["Length"]);

                TxnsDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"]);
                TxnsDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["Length"]);

                MERCHENTCATCODE_StartPosition = Convert.ToUInt16(ds.Tables["MERCHANTCATCODE"].Rows[0]["StartPosition"]);
                MERCHENTCATCODE_Length = Convert.ToUInt16(ds.Tables["MERCHANTCATCODE"].Rows[0]["Length"]);

                CARDACCEPTSETDATE_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTERSETDATE"].Rows[0]["StartPosition"]);
                CARDACCEPTSETDATE_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTERSETDATE"].Rows[0]["Length"]);

                CARDACCID_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCID"].Rows[0]["StartPosition"]);
                CARDACCID_Length = Convert.ToUInt16(ds.Tables["CARDACCID"].Rows[0]["Length"]);

                CARDACCEPTERID_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTERID"].Rows[0]["StartPosition"]);
                CARDACCEPTERID_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTERID"].Rows[0]["Length"]);

                CARDACCEPTERTERLOCATION_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTERTERLOC"].Rows[0]["StartPosition"]);
                CARDACCEPTERTERLOCATION_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTERTERLOC"].Rows[0]["Length"]);

                AcquirerID_StartPosition = Convert.ToUInt16(ds.Tables["ACCIQUIERID"].Rows[0]["StartPosition"]);
                AcquirerID_Length = Convert.ToUInt16(ds.Tables["ACCIQUIERID"].Rows[0]["Length"]);

                ACCSETDATE_StartPosition = Convert.ToUInt16(ds.Tables["ACCSETDATE"].Rows[0]["StartPosition"]);
                ACCSETDATE_Length = Convert.ToUInt16(ds.Tables["ACCSETDATE"].Rows[0]["Length"]);

                TRANSCURRENCYCODE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSCURCODE"].Rows[0]["StartPosition"]);
                TRANSCURRENCYCODE_Length = Convert.ToUInt16(ds.Tables["TRANSCURCODE"].Rows[0]["Length"]);

                TxnsAmount_StartPosition = Convert.ToUInt16(ds.Tables["TRANSAMOUNT"].Rows[0]["StartPosition"]);
                TxnsAmount_Length = Convert.ToUInt16(ds.Tables["TRANSAMOUNT"].Rows[0]["Length"]);

                ACCTUALTRANAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["ACCTUALTRANSAMOUNT"].Rows[0]["StartPosition"]);
                ACCTUALTRANAMOUNT_Length = Convert.ToUInt16(ds.Tables["ACCTUALTRANSAMOUNT"].Rows[0]["Length"]);

                TRANSACCVITYFEE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACTIVITYFEE"].Rows[0]["StartPosition"]);
                TRANSACCVITYFEE_Length = Convert.ToUInt16(ds.Tables["TRANSACTIVITYFEE"].Rows[0]["Length"]);

                ACCURSETCURCODE_StartPosition = Convert.ToUInt16(ds.Tables["ACCURSETCURCODE"].Rows[0]["StartPosition"]);
                ACCURSETCURCODE_Length = Convert.ToUInt16(ds.Tables["ACCURSETCURCODE"].Rows[0]["Length"]);

                ACQUIERSETAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["ACQUIERSETAMOUNT"].Rows[0]["StartPosition"]);
                ACQUIERSETAMOUNT_Length = Convert.ToUInt16(ds.Tables["ACQUIERSETAMOUNT"].Rows[0]["Length"]);

                ACQUIERSETFEE_StartPosition = Convert.ToUInt16(ds.Tables["ACQUIERSETFEE"].Rows[0]["StartPosition"]);
                ACQUIERSETFEE_Length = Convert.ToUInt16(ds.Tables["ACQUIERSETFEE"].Rows[0]["Length"]);

                ACQUIERSETPROFEE_StartPosition = Convert.ToUInt16(ds.Tables["ACQUIERSETPROFEE"].Rows[0]["StartPosition"]);
                ACQUIERSETPROFEE_Length = Convert.ToUInt16(ds.Tables["ACQUIERSETPROFEE"].Rows[0]["Length"]);

                TRANSACQUIERCONVERRATE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACQUIERCONVERRATE"].Rows[0]["StartPosition"]);
                TRANSACQUIERCONVERRATE_Length = Convert.ToUInt16(ds.Tables["TRANSACQUIERCONVERRATE"].Rows[0]["Length"]);

                FORCEMATCH_StartPosition = Convert.ToUInt16(ds.Tables["FORCEMATCH"].Rows[0]["StartPosition"]);
                FORCEMATCH_Length = Convert.ToUInt16(ds.Tables["FORCEMATCH"].Rows[0]["Length"]);

                Cycle_StartPosition = Convert.ToUInt16(ds.Tables["Cycle"].Rows[0]["StartPosition"]);
                Cycle_Length = Convert.ToUInt16(ds.Tables["Cycle"].Rows[0]["Length"]);

                URN_StartPosition = Convert.ToUInt16(ds.Tables["URN"].Rows[0]["StartPosition"]);
                URN_Length = Convert.ToUInt16(ds.Tables["URN"].Rows[0]["Length"]);

                ReserveField1_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField1"].Rows[0]["StartPosition"]);
                ReserveField1_Length = Convert.ToUInt16(ds.Tables["ReserveField1"].Rows[0]["Length"]);

                ReserveField2_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField2"].Rows[0]["StartPosition"]);
                ReserveField2_Length = Convert.ToUInt16(ds.Tables["ReserveField2"].Rows[0]["Length"]);

                ReserveField3_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField3"].Rows[0]["StartPosition"]);
                ReserveField3_Length = Convert.ToUInt16(ds.Tables["ReserveField3"].Rows[0]["Length"]);

                ReserveField4_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField4"].Rows[0]["StartPosition"]);
                ReserveField4_Length = Convert.ToUInt16(ds.Tables["ReserveField4"].Rows[0]["Length"]);

                ReserveField5_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField5"].Rows[0]["StartPosition"]);
                ReserveField5_Length = Convert.ToUInt16(ds.Tables["ReserveField5"].Rows[0]["Length"]);


                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTime = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                batchSize = bulkimports.GetBatchSize(dtdetails.ConfigID);

                string line1 = string.Empty;
                foreach (var batchDetail in fileImportRequest.FailedBatches)
                {
                    if (batchDetail.BatchNo != 0)
                    {
                        BatchNo = batchDetail.BatchNo - 1;
                    }


                    bool NewEntry = false;

                    if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                    {
                        //set the flag if it is new Entry
                        NewEntry = false;
                    }
                    else
                    {
                        if (batchDetail.BatchStatus == "None")
                        {
                            break;
                        }
                        else
                        {
                            //set the flag if it is old and  Partial Entry
                            NewEntry = true;
                        }
                    }

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        LineNo++;
                        LineNumber++;
                        if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                        {
                            continue;
                        }

                        try
                        {
                            line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                            Incr = 1;
                            Participant_ID = string.Empty;
                            TxnsDateTime = string.Empty;
                            Transaction_Type = string.Empty;
                            From_Account_Type = string.Empty;
                            To_Account_Type = string.Empty;
                            Transaction_Serial_Number = string.Empty;
                            Response_Code = string.Empty;
                            PAN_Number = string.Empty;
                            Member_Number = string.Empty;
                            Approval_Number = string.Empty;
                            System_Trace_Audit_Number = string.Empty;
                            Transaction_Date = string.Empty;
                            Transaction_Time = string.Empty;
                            Merchant_Category_Code = string.Empty;
                            Card_Acceptor_Settlement_Date = string.Empty;
                            Card_Acceptor_ID = string.Empty;
                            Card_Acceptor_Terminal_ID = string.Empty;
                            Card_Acceptor_Terminal_Location = string.Empty;
                            Acquirer_ID = string.Empty;
                            Acquirer_Settlement_Date = string.Empty;
                            Transaction_Currency_code = string.Empty;
                            Transaction_Amount = "0";
                            Actual_Transaction_Amount = "0";
                            Transaction_Acitivity_fee = "0";
                            Acquirer_settlement_Currency_Code = string.Empty;
                            Acquirer_settlement_Amount = "0";
                            Acquirer_Settlement_Fee = "0";
                            Acquirer_settlement_processing_fee = "0";
                            Transaction_Acquirer_Conversion_Rate = "0";
                            ForceMatch = string.Empty;

                            URN = string.Empty;
                            ReserveField1 = string.Empty;
                            ReserveField2 = string.Empty;
                            ReserveField3 = string.Empty;
                            ReserveField4 = string.Empty;
                            ReserveField5 = string.Empty;



                            Participant_ID = PARICIPATEID_StartPosition > 0 && PARICIPATEID_Length > 0 ? line1.Substring(PARICIPATEID_StartPosition - Incr, PARICIPATEID_Length).Trim() : string.Empty;
                            TxnsDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length) : string.Empty;
                            Transaction_Type = TRANSACTIONTYPE_StartPosition > 0 && TRANSACTIONTYPE_Length > 0 ? line1.Substring(TRANSACTIONTYPE_StartPosition - Incr, TRANSACTIONTYPE_Length).Trim() : string.Empty;
                            From_Account_Type = FromAccountType_StartPosition > 0 && FromAccountType_Length > 0 ? line1.Substring(FromAccountType_StartPosition - Incr, FromAccountType_Length).Trim() : string.Empty;
                            To_Account_Type = ToAccountType_StartPosition > 0 && ToAccountType_Length > 0 ? line1.Substring(ToAccountType_StartPosition - Incr, ToAccountType_Length).Trim() : string.Empty;
                            Transaction_Serial_Number = ReferenceNumber_StartPosition > 0 && ReferenceNumber_Length > 0 ? line1.Substring(ReferenceNumber_StartPosition - Incr, ReferenceNumber_Length).Trim() : string.Empty;
                            Response_Code = ResponseCode_StartPosition > 0 && ResponseCode_Length > 0 ? line1.Substring(ResponseCode_StartPosition - Incr, ResponseCode_Length).Trim() : string.Empty;
                            PAN_Number = PAN_Number_StartPosition > 0 && PAN_Number_Length > 0 ? line1.Substring(PAN_Number_StartPosition - Incr, PAN_Number_Length).Trim() : string.Empty;
                            Member_Number = MEMNUMBER_StartPosition > 0 && MEMNUMBER_Length > 0 ? line1.Substring(MEMNUMBER_StartPosition - Incr, MEMNUMBER_Length).Trim() : string.Empty;
                            Approval_Number = APPROVNO_StartPosition > 0 && APPROVNO_Length > 0 ? line1.Substring(APPROVNO_StartPosition - Incr, APPROVNO_Length).Trim() : string.Empty;
                            System_Trace_Audit_Number = STAUDITNO_StartPosition > 0 && STAUDITNO_Length > 0 ? line1.Substring(STAUDITNO_StartPosition - Incr, STAUDITNO_Length).Trim() : string.Empty;
                            Transaction_Date = TRANSDATE_StartPosition > 0 && TRANSDATE_Length > 0 ? line1.Substring(TRANSDATE_StartPosition - Incr, TRANSDATE_Length).Trim() : string.Empty;
                            Transaction_Time = TRANSTIME_StartPosition > 0 && TRANSTIME_Length > 0 ? line1.Substring(TRANSTIME_StartPosition - Incr, TRANSTIME_Length).Trim() : string.Empty;
                            Merchant_Category_Code = MERCHENTCATCODE_StartPosition > 0 && MERCHENTCATCODE_Length > 0 ? line1.Substring(MERCHENTCATCODE_StartPosition - Incr, MERCHENTCATCODE_Length).Trim() : string.Empty;
                            Card_Acceptor_Settlement_Date = CARDACCEPTSETDATE_StartPosition > 0 && CARDACCEPTSETDATE_Length > 0 ? line1.Substring(CARDACCEPTSETDATE_StartPosition - Incr, CARDACCEPTSETDATE_Length).Trim() : string.Empty;
                            Card_Acceptor_ID = CARDACCID_StartPosition > 0 && CARDACCID_Length > 0 ? line1.Substring(CARDACCID_StartPosition - Incr, CARDACCID_Length).Trim() : string.Empty;
                            Card_Acceptor_Terminal_ID = CARDACCEPTERID_StartPosition > 0 && CARDACCEPTERID_Length > 0 ? line1.Substring(CARDACCEPTERID_StartPosition - Incr, CARDACCEPTERID_Length).Trim() : string.Empty;
                            Card_Acceptor_Terminal_Location = CARDACCEPTERTERLOCATION_StartPosition > 0 && CARDACCEPTERTERLOCATION_Length > 0 ? line1.Substring(CARDACCEPTERTERLOCATION_StartPosition - Incr, CARDACCEPTERTERLOCATION_Length).Trim() : string.Empty;
                            Acquirer_ID = AcquirerID_StartPosition > 0 && AcquirerID_Length > 0 ? line1.Substring(AcquirerID_StartPosition - Incr, AcquirerID_Length).Trim() : string.Empty;
                            Acquirer_Settlement_Date = ACCSETDATE_StartPosition > 0 && ACCSETDATE_Length > 0 ? line1.Substring(ACCSETDATE_StartPosition - Incr, ACCSETDATE_Length).Trim() : string.Empty;
                            Transaction_Currency_code = TRANSCURRENCYCODE_StartPosition > 0 && TRANSCURRENCYCODE_Length > 0 ? line1.Substring(TRANSCURRENCYCODE_StartPosition - Incr, TRANSCURRENCYCODE_Length).Trim() : string.Empty;
                            Transaction_Amount = TxnsAmount_StartPosition > 0 && TxnsAmount_Length > 0 ? line1.Substring(TxnsAmount_StartPosition - Incr, TxnsAmount_Length).Trim() : string.Empty;
                            Actual_Transaction_Amount = ACCTUALTRANAMOUNT_StartPosition > 0 && ACCTUALTRANAMOUNT_Length > 0 ? line1.Substring(ACCTUALTRANAMOUNT_StartPosition - Incr, ACCTUALTRANAMOUNT_Length).Trim() : string.Empty;
                            Transaction_Acitivity_fee = TRANSACCVITYFEE_StartPosition > 0 && TRANSACCVITYFEE_Length > 0 ? line1.Substring(TRANSACCVITYFEE_StartPosition - Incr, TRANSACCVITYFEE_Length).Trim() : string.Empty;
                            Acquirer_settlement_Currency_Code = ACCURSETCURCODE_StartPosition > 0 && ACCURSETCURCODE_Length > 0 ? line1.Substring(ACCURSETCURCODE_StartPosition - Incr, ACCURSETCURCODE_Length).Trim() : string.Empty;
                            Acquirer_settlement_Amount = ACQUIERSETAMOUNT_StartPosition > 0 && ACQUIERSETAMOUNT_Length > 0 ? line1.Substring(ACQUIERSETAMOUNT_StartPosition - Incr, ACQUIERSETAMOUNT_Length).Trim() : string.Empty;
                            Acquirer_Settlement_Fee = ACQUIERSETFEE_StartPosition > 0 && ACQUIERSETFEE_Length > 0 ? line1.Substring(ACQUIERSETFEE_StartPosition - Incr, ACQUIERSETFEE_Length).Trim() : string.Empty;
                            Acquirer_settlement_processing_fee = ACQUIERSETPROFEE_StartPosition > 0 && ACQUIERSETPROFEE_Length > 0 ? line1.Substring(ACQUIERSETPROFEE_StartPosition - Incr, ACQUIERSETPROFEE_Length).Trim() : string.Empty;
                            Transaction_Acquirer_Conversion_Rate = TRANSACQUIERCONVERRATE_StartPosition > 0 && TRANSACQUIERCONVERRATE_Length > 0 ? line1.Substring(TRANSACQUIERCONVERRATE_StartPosition - Incr, TRANSACQUIERCONVERRATE_Length).Trim() : string.Empty;
                            ForceMatch = FORCEMATCH_StartPosition > 0 && FORCEMATCH_Length > 0 ? line1.Substring(FORCEMATCH_StartPosition - Incr, FORCEMATCH_Length).Trim() : string.Empty;

                            URN = URN_StartPosition > 0 && URN_Length > 0 ? line1.Substring(URN_StartPosition - Incr, URN_Length) : string.Empty;
                            ReserveField1 = ReserveField1_StartPosition > 0 && ReserveField1_Length > 0 ? line1.Substring(ReserveField1_StartPosition - Incr, ReserveField1_Length) : string.Empty;
                            ReserveField2 = ReserveField2_StartPosition > 0 && ReserveField2_Length > 0 ? line1.Substring(ReserveField2_StartPosition - Incr, ReserveField2_Length) : string.Empty;
                            ReserveField3 = ReserveField3_StartPosition > 0 && ReserveField3_Length > 0 ? line1.Substring(ReserveField3_StartPosition - Incr, ReserveField3_Length) : string.Empty;
                            ReserveField4 = ReserveField4_StartPosition > 0 && ReserveField4_Length > 0 ? line1.Substring(ReserveField4_StartPosition - Incr, ReserveField4_Length) : string.Empty;
                            ReserveField5 = ReserveField4_StartPosition > 0 && ReserveField5_Length > 0 ? line1.Substring(ReserveField5_StartPosition - Incr, ReserveField5_Length) : string.Empty;

                            TxnsDateTimeMain = null;



                            Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                            Actual_Transaction_Amount = Common.IsNumeric(Actual_Transaction_Amount) ? Actual_Transaction_Amount : "0";
                            Transaction_Acitivity_fee = Common.IsNumeric(Transaction_Acitivity_fee) ? Transaction_Acitivity_fee : "0";
                            Acquirer_settlement_Amount = Common.IsNumeric(Acquirer_settlement_Amount) ? Acquirer_settlement_Amount : "0";
                            Acquirer_Settlement_Fee = Common.IsNumeric(Acquirer_Settlement_Fee) ? Acquirer_Settlement_Fee : "0";
                            Acquirer_settlement_processing_fee = Common.IsNumeric(Acquirer_settlement_processing_fee) ? Acquirer_settlement_processing_fee : "0";
                            System_Trace_Audit_Number = Common.IsNumeric(System_Trace_Audit_Number) ? System_Trace_Audit_Number : "0";
                            Merchant_Category_Code = Common.IsNumeric(Merchant_Category_Code) ? Merchant_Category_Code : "0";
                            Transaction_Acquirer_Conversion_Rate = Common.IsNumeric(Transaction_Acquirer_Conversion_Rate) ? Transaction_Acquirer_Conversion_Rate : "0";


                            if (TxnsDateTime != "" && TxnDateTime.Length > 0)
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime, CultureInfo.InvariantCulture);
                            }

                            if (Transaction_Date != "" && Transaction_Time != "")
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(Transaction_Date + " " + Transaction_Time, TxnDateTime, CultureInfo.InvariantCulture);
                            }

                            if (TxnsDateTimeMain != null)
                            {
                                _DataTable.Rows.Add(
                                    Participant_ID
                                    , TxnsDateTimeMain
                                    , Transaction_Type
                                    , From_Account_Type
                                    , To_Account_Type
                                    , Transaction_Serial_Number
                                    , Response_Code
                                    , PAN_Number
                                    , Member_Number
                                    , Approval_Number
                                    , System_Trace_Audit_Number
                                    , Merchant_Category_Code
                                    , Card_Acceptor_Settlement_Date
                                    , Card_Acceptor_ID
                                    , Card_Acceptor_Terminal_ID
                                    , Card_Acceptor_Terminal_Location
                                    , Acquirer_ID
                                    , Acquirer_Settlement_Date
                                    , Transaction_Currency_code
                                    , Transaction_Amount
                                    , Actual_Transaction_Amount
                                    , Transaction_Acitivity_fee
                                    , Acquirer_settlement_Currency_Code
                                    , Acquirer_settlement_Amount
                                    , Acquirer_Settlement_Fee
                                    , Acquirer_settlement_processing_fee
                                    , Transaction_Acquirer_Conversion_Rate
                                    , ForceMatch
                                    , Cycle
                                    , URN
                                    , ReserveField1
                                    , ReserveField2
                                    , ReserveField3
                                    , ReserveField4
                                    , ReserveField5
                                    );

                                if (_DataTable.Rows.Count >= batchSize)
                                {
                                    BatchNo++;
                                    MSG = bulkimports.BulkInsertAcquirerDataAEPS(_DataTable, dtdetails.ConfigID, dtdetails.FileDateTime, fileImportRequest.Path, fileImportRequest.FileName, fileImportRequest.UserName);
                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                    BatchDetails batchDetails = new BatchDetails
                                    {
                                        BatchNo = BatchNo,
                                        BatchSize = batchSize,
                                        TxnUploadCount = _DataTable.Rows.Count,
                                        TxnsCount = fileImportRequest.InsertCount,
                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                        FailedCount = ErrorCount,
                                        BatchStartTime = batchStartTime,
                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                    };

                                    batchDetailsList.Add(batchDetails);
                                    _DataTable.Clear();
                                    ErrorCount = 0;
                                    StartTime = DateTime.Now;

                                    if (NewEntry)
                                    {
                                        break;
                                    }
                                }

                            }
                            //uspDynamicBulkInsertAEPSAcquirerData

                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                        }
                    }

                    LineNo = 0;
                }
            }

            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkimports.BulkInsertAcquirerDataAEPS(_DataTable, dtdetails.ConfigID, dtdetails.FileDateTime, fileImportRequest.Path, fileImportRequest.FileName, fileImportRequest.UserName);

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

               // _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string Splitter_NPCI_Issuer_AEPS_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int ErrorCount = 0;
            //DynamicAEPSAcquirerTableType
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0; 

            DtDetails dtdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();


            // _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(decimal));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(decimal));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(decimal));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(decimal));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(decimal));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(decimal));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(decimal));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(decimal));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(decimal));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));


            string RevEntryLeg = "1";
            int Incr = 1;

            string PARICIPATEID = string.Empty;
            string TxnsDateTime = string.Empty;
            string TRANSACTIONTYPE = string.Empty;
            string FROMACCOUNTTYPE = string.Empty;
            string TOACCOUNTTYPE = string.Empty;
            string TRANSSERIALNO = string.Empty;
            string RESPONSECODE = string.Empty;
            string PANNUMBER = string.Empty;
            string MEMNUMBER = string.Empty;
            string APPROVNO = string.Empty;
            string STAUDITNO = string.Empty;
            string MERCHENTCATCODE = string.Empty;
            string CARDACCEPTSETDATE = string.Empty;
            string CARDACCEPTORID = string.Empty;
            string CARDACCEPTTERMINALID = string.Empty;
            string CARDACCEPTERTERLOCATION = string.Empty;
            string ACQUIRERID = string.Empty;
            string NETWORKID = string.Empty;
            string ACCOUNTNO1 = string.Empty;
            string ACCOUNTBRANCHID = string.Empty;
            string ACCOUNTNO2 = string.Empty;
            string ACCOUNT2BRANCHID = string.Empty;
            string TRANSCURRENCYCODE = string.Empty;
            string TRANSAMOUNT = string.Empty;
            string ACCTUALTRANAMOUNT = string.Empty;
            string TRANSACCVITYFEE = string.Empty;
            string ISSUERSETCURRENCYCODE = string.Empty;
            string ISSURESETAMOUNT = string.Empty;
            string ISSUERSETFEE = string.Empty;
            string ISSURESETPROCFEE = string.Empty;
            string CARDHOLDERBILLCURNCCODE = string.Empty;
            string CARDHOLDERBILLAMOUNT = string.Empty;
            string CARDHOLDERBILACTFEE = string.Empty;
            string CARDHOLDERBILPROFEE = string.Empty;
            string CARDHOLDERBILSRVICEFEE = string.Empty;
            string TRAN_ISSUERCONVERSRATE = string.Empty;
            string TRANS_CARDHOLDERCONVERRATE = string.Empty;
            string FORCEMATCH = string.Empty;
            string Cycle = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;

            string Transaction_Date = string.Empty;
            string Transaction_Time = string.Empty;

            DateTime? TxnsDateTimeMain = null;

            ushort PARTICIPENTID_StartPosition = 0;
            ushort TxnsDateTime_StartPosition = 0;
            ushort TRANSTYPE_StartPosition = 0;
            ushort FROMACCTYPE_StartPosition = 0;
            ushort TOACCTYPE_StartPosition = 0;
            ushort TRANSSERIALNO_StartPosition = 0;
            ushort RESPONSECODE_StartPosition = 0;
            ushort PANNO_StartPosition = 0;
            ushort MEMNUMBER_StartPosition = 0;
            ushort APPROVALNO_StartPosition = 0;
            ushort SYSTRACAUDITNO_StartPosition = 0;
            ushort MERCHANTCATCODE_StartPosition = 0;
            ushort CARDACCEPTERSETDATE_StartPosition = 0;//
            ushort CARDACCID_StartPosition = 0;
            ushort CARDACCEPTERID_StartPosition = 0;
            ushort CARDACCEPTERTERLOC_StartPosition = 0;
            ushort ACCIQUIERID_StartPosition = 0;
            // ushort ACCSETDATE_StartPosition = 0;//
            ushort TRANSCURCODE_StartPosition = 0;
            ushort TRANSAMOUNT_StartPosition = 0;
            ushort ACCTUALTRANSAMOUNT_StartPosition = 0;
            ushort TRANSACTIVITYFEE_StartPosition = 0;
            ushort ISSCURSETCURCODE_StartPosition = 0;
            ushort ISSUERSETAMOUNT_StartPosition = 0;
            ushort ISSUERSETFEE_StartPosition = 0;
            ushort ISSUERSETPROFEE_StartPosition = 0;
            ushort TRANSISSUERCONVERRATE_StartPosition = 0;
            ushort NETWORKID_StartPosition = 0;
            ushort ACCOUNTNO1_StartPosition = 0;
            ushort ACCOUNTBRANCHID_StartPosition = 0;
            ushort ACCOUNTNO2_StartPosition = 0;
            ushort ACCOUNT2BRANCHID_StartPosition = 0;
            ushort CARDHOLDERBILLCURNCCODE_StartPosition = 0;//
            ushort CARDHOLDERBILLAMOUNT_StartPosition = 0;
            ushort CARDHOLDERBILACTFEE_StartPosition = 0;
            ushort CARDHOLDERBILPROFEE_StartPosition = 0;
            ushort CARDHOLDERBILSRVICEFEE_StartPosition = 0;
            ushort TRANS_CARDHOLDERCONVERRATE_StartPosition = 0;
            ushort FORCEMATCH_StartPosition = 0;
            ushort Cycle_StartPosition = 0;
            ushort ReserveField1_StartPosition = 0;
            ushort ReserveField2_StartPosition = 0;
            ushort ReserveField3_StartPosition = 0;
            ushort ReserveField4_StartPosition = 0;
            ushort ReserveField5_StartPosition = 0;
            ushort TRANSTIME_StartPosition = 0;
            ushort TRANSDATE_StartPosition = 0;

            ushort TRANSTIME_Length = 0;
            ushort TRANSDATE_Length = 0;
            ushort PARTICIPENTID_Length = 0;
            ushort TxnsDateTime_Length = 0;
            ushort TRANSTYPE_Length = 0;
            ushort FROMACCTYPE_Length = 0;
            ushort TOACCTYPE_Length = 0;
            ushort TRANSSERIALNO_Length = 0;
            ushort RESPONSECODE_Length = 0;
            ushort PANNO_Length = 0;
            ushort MEMNUMBER_Length = 0;
            ushort APPROVALNO_Length = 0;
            ushort SYSTRACAUDITNO_Length = 0;
            ushort MERCHANTCATCODE_Length = 0;
            ushort CARDACCEPTERSETDATE_Length = 0;//
            ushort CARDACCID_Length = 0;
            ushort CARDACCEPTERID_Length = 0;
            ushort CARDACCEPTERTERLOC_Length = 0;
            ushort ACCIQUIERID_Length = 0;
            //  ushort ACCSETDATE_Length = 0;//
            ushort TRANSCURCODE_Length = 0;
            ushort TRANSAMOUNT_Length = 0;
            ushort ACCTUALTRANSAMOUNT_Length = 0;
            ushort TRANSACTIVITYFEE_Length = 0;
            ushort ISSCURSETCURCODE_Length = 0;
            ushort ISSUERSETAMOUNT_Length = 0;
            ushort ISSUERSETFEE_Length = 0;
            ushort ISSUERSETPROFEE_Length = 0;
            ushort TRANSISSUERCONVERRATE_Length = 0;
            ushort NETWORKID_Length = 0;
            ushort ACCOUNTNO1_Length = 0;
            ushort ACCOUNTBRANCHID_Length = 0;
            ushort ACCOUNTNO2_Length = 0;
            ushort ACCOUNT2BRANCHID_Length = 0;
            ushort CARDHOLDERBILLCURNCCODE_Length = 0;//
            ushort CARDHOLDERBILLAMOUNT_Length = 0;
            ushort CARDHOLDERBILACTFEE_Length = 0;
            ushort CARDHOLDERBILPROFEE_Length = 0;
            ushort CARDHOLDERBILSRVICEFEE_Length = 0;
            ushort TRANS_CARDHOLDERCONVERRATE_Length = 0;
            ushort FORCEMATCH_Length = 0;
            ushort Cycle_Length = 0;
            ushort ReserveField1_Length = 0;
            ushort ReserveField2_Length = 0;
            ushort ReserveField3_Length = 0;
            ushort ReserveField4_Length = 0;
            ushort ReserveField5_Length = 0;


            bool ErrorOccurred = false;
            string[] TxnDateTime = null;
            string Status = "0";

            string[] CycleList = { "1C", "2C", "3C", "4C" };

            try
            {
                
                //  int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();
                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
                fileImportRequest.TotalCount = TotalCountArray.Length;
                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }
                TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                string[] FDA = fileImportRequest.FileName.Split('_', '.');

                if (fileImportRequest.ConfigData.Rows[0]["ChannelID"].ToString() == "13")
                {
                    Cycle = FDA.Length > 2 ? FDA[2].ToString() : string.Empty;
                }
                else
                {
                    Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;
                }

                Cycle = CycleList.Contains(Cycle) ? Cycle : string.Empty;

                DataSet ds = new DataSet();

                ds.ReadXml(new XmlTextReader(new System.IO.StringReader(xmlFile)));




                PARTICIPENTID_StartPosition = Convert.ToUInt16(ds.Tables["PARICIPATEID"].Rows[0]["StartPosition"]);
                PARTICIPENTID_Length = Convert.ToUInt16(ds.Tables["PARICIPATEID"].Rows[0]["Length"]);

                TRANSTYPE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACTIONTYPE"].Rows[0]["StartPosition"]);
                TRANSTYPE_Length = Convert.ToUInt16(ds.Tables["TRANSACTIONTYPE"].Rows[0]["Length"]);



                TRANSTIME_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACTIONTIME"].Rows[0]["StartPosition"]);
                TRANSTIME_Length = Convert.ToUInt16(ds.Tables["TRANSACTIONTIME"].Rows[0]["Length"]);

                TRANSDATE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACTIONDATE"].Rows[0]["StartPosition"]);
                TRANSDATE_Length = Convert.ToUInt16(ds.Tables["TRANSACTIONDATE"].Rows[0]["Length"]);

                FROMACCTYPE_StartPosition = Convert.ToUInt16(ds.Tables["FROMACCOUNTTYPE"].Rows[0]["StartPosition"]);
                FROMACCTYPE_Length = Convert.ToUInt16(ds.Tables["FROMACCOUNTTYPE"].Rows[0]["Length"]);

                TOACCTYPE_StartPosition = Convert.ToUInt16(ds.Tables["TOACCOUNTTYPE"].Rows[0]["StartPosition"]);
                TOACCTYPE_Length = Convert.ToUInt16(ds.Tables["TOACCOUNTTYPE"].Rows[0]["Length"]);

                TRANSSERIALNO_StartPosition = Convert.ToUInt16(ds.Tables["TRANSSERIALNO"].Rows[0]["StartPosition"]);
                TRANSSERIALNO_Length = Convert.ToUInt16(ds.Tables["TRANSSERIALNO"].Rows[0]["Length"]);

                RESPONSECODE_StartPosition = Convert.ToUInt16(ds.Tables["RESPONSECODE"].Rows[0]["StartPosition"]);
                RESPONSECODE_Length = Convert.ToUInt16(ds.Tables["RESPONSECODE"].Rows[0]["Length"]);

                PANNO_StartPosition = Convert.ToUInt16(ds.Tables["PANNUMBER"].Rows[0]["StartPosition"]);
                PANNO_Length = Convert.ToUInt16(ds.Tables["PANNUMBER"].Rows[0]["Length"]);

                MEMNUMBER_StartPosition = Convert.ToUInt16(ds.Tables["MEMNUMBER"].Rows[0]["StartPosition"]);
                MEMNUMBER_Length = Convert.ToUInt16(ds.Tables["MEMNUMBER"].Rows[0]["Length"]);

                APPROVALNO_StartPosition = Convert.ToUInt16(ds.Tables["APPROVNO"].Rows[0]["StartPosition"]);
                APPROVALNO_Length = Convert.ToUInt16(ds.Tables["APPROVNO"].Rows[0]["Length"]);

                SYSTRACAUDITNO_StartPosition = Convert.ToUInt16(ds.Tables["STAUDITNO"].Rows[0]["StartPosition"]);
                SYSTRACAUDITNO_Length = Convert.ToUInt16(ds.Tables["STAUDITNO"].Rows[0]["Length"]);

                MERCHANTCATCODE_StartPosition = Convert.ToUInt16(ds.Tables["MERCHENTCATCODE"].Rows[0]["StartPosition"]);
                MERCHANTCATCODE_Length = Convert.ToUInt16(ds.Tables["MERCHENTCATCODE"].Rows[0]["Length"]);

                CARDACCEPTERSETDATE_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTSETDATE"].Rows[0]["StartPosition"]);
                CARDACCEPTERSETDATE_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTSETDATE"].Rows[0]["Length"]);

                CARDACCID_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTORID"].Rows[0]["StartPosition"]);
                CARDACCID_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTORID"].Rows[0]["Length"]);


                CARDACCEPTERID_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTTERMINALID"].Rows[0]["StartPosition"]);
                CARDACCEPTERID_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTTERMINALID"].Rows[0]["Length"]);

                CARDACCEPTERTERLOC_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTERTERLOCATION"].Rows[0]["StartPosition"]);
                CARDACCEPTERTERLOC_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTERTERLOCATION"].Rows[0]["Length"]);

                ACCIQUIERID_StartPosition = Convert.ToUInt16(ds.Tables["ACQUIRERID"].Rows[0]["StartPosition"]);
                ACCIQUIERID_Length = Convert.ToUInt16(ds.Tables["ACQUIRERID"].Rows[0]["Length"]);

                TRANSCURCODE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSCURRENCYCODE"].Rows[0]["StartPosition"]);
                TRANSCURCODE_Length = Convert.ToUInt16(ds.Tables["TRANSCURRENCYCODE"].Rows[0]["Length"]);

                TRANSAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["TRANSAMOUNT"].Rows[0]["StartPosition"]);
                TRANSAMOUNT_Length = Convert.ToUInt16(ds.Tables["TRANSAMOUNT"].Rows[0]["Length"]);

                ACCTUALTRANSAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["ACCTUALTRANAMOUNT"].Rows[0]["StartPosition"]);
                ACCTUALTRANSAMOUNT_Length = Convert.ToUInt16(ds.Tables["ACCTUALTRANAMOUNT"].Rows[0]["Length"]);

                TRANSACTIVITYFEE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACCVITYFEE"].Rows[0]["StartPosition"]);
                TRANSACTIVITYFEE_Length = Convert.ToUInt16(ds.Tables["TRANSACCVITYFEE"].Rows[0]["Length"]);

                ISSCURSETCURCODE_StartPosition = Convert.ToUInt16(ds.Tables["ISSUERSETCURRENCYCODE"].Rows[0]["StartPosition"]);
                ISSCURSETCURCODE_Length = Convert.ToUInt16(ds.Tables["ISSUERSETCURRENCYCODE"].Rows[0]["Length"]);

                ISSUERSETAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["ISSURESETAMOUNT"].Rows[0]["StartPosition"]);
                ISSUERSETAMOUNT_Length = Convert.ToUInt16(ds.Tables["ISSURESETAMOUNT"].Rows[0]["Length"]);

                ISSUERSETFEE_StartPosition = Convert.ToUInt16(ds.Tables["ISSUERSETFEE"].Rows[0]["StartPosition"]);
                ISSUERSETFEE_Length = Convert.ToUInt16(ds.Tables["ISSUERSETFEE"].Rows[0]["Length"]);

                ISSUERSETPROFEE_StartPosition = Convert.ToUInt16(ds.Tables["ISSURESETPROCFEE"].Rows[0]["StartPosition"]);
                ISSUERSETPROFEE_Length = Convert.ToUInt16(ds.Tables["ISSURESETPROCFEE"].Rows[0]["Length"]);

                TRANSISSUERCONVERRATE_StartPosition = Convert.ToUInt16(ds.Tables["TRAN_ISSUERCONVERSRATE"].Rows[0]["StartPosition"]);
                TRANSISSUERCONVERRATE_Length = Convert.ToUInt16(ds.Tables["TRAN_ISSUERCONVERSRATE"].Rows[0]["Length"]);

                NETWORKID_StartPosition = Convert.ToUInt16(ds.Tables["NETWORKID"].Rows[0]["StartPosition"]);
                NETWORKID_Length = Convert.ToUInt16(ds.Tables["NETWORKID"].Rows[0]["Length"]);

                ACCOUNTNO1_StartPosition = Convert.ToUInt16(ds.Tables["ACCOUNTNO1"].Rows[0]["StartPosition"]);
                ACCOUNTNO1_Length = Convert.ToUInt16(ds.Tables["ACCOUNTNO1"].Rows[0]["Length"]);

                ACCOUNTBRANCHID_StartPosition = Convert.ToUInt16(ds.Tables["ACCOUNTBRANCHID"].Rows[0]["StartPosition"]);
                ACCOUNTBRANCHID_Length = Convert.ToUInt16(ds.Tables["ACCOUNTBRANCHID"].Rows[0]["Length"]);

                ACCOUNTNO2_StartPosition = Convert.ToUInt16(ds.Tables["ACCOUNTNO2"].Rows[0]["StartPosition"]);
                ACCOUNTNO2_Length = Convert.ToUInt16(ds.Tables["ACCOUNTNO2"].Rows[0]["Length"]);

                ACCOUNT2BRANCHID_StartPosition = Convert.ToUInt16(ds.Tables["ACCOUNT2BRANCHID"].Rows[0]["StartPosition"]);
                ACCOUNT2BRANCHID_Length = Convert.ToUInt16(ds.Tables["ACCOUNT2BRANCHID"].Rows[0]["Length"]);

                CARDHOLDERBILLCURNCCODE_StartPosition = Convert.ToUInt16(ds.Tables["CARDHOLDERBILLCURNCCODE"].Rows[0]["StartPosition"]);
                CARDHOLDERBILLCURNCCODE_Length = Convert.ToUInt16(ds.Tables["CARDHOLDERBILLCURNCCODE"].Rows[0]["Length"]);

                CARDHOLDERBILLAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["CARDHOLDERBILLAMOUNT"].Rows[0]["StartPosition"]);
                CARDHOLDERBILLAMOUNT_Length = Convert.ToUInt16(ds.Tables["CARDHOLDERBILLAMOUNT"].Rows[0]["Length"]);

                CARDHOLDERBILACTFEE_StartPosition = Convert.ToUInt16(ds.Tables["CARDHOLDERBILACTFEE"].Rows[0]["StartPosition"]);
                CARDHOLDERBILACTFEE_Length = Convert.ToUInt16(ds.Tables["CARDHOLDERBILACTFEE"].Rows[0]["Length"]);

                CARDHOLDERBILPROFEE_StartPosition = Convert.ToUInt16(ds.Tables["CARDHOLDERBILPROFEE"].Rows[0]["StartPosition"]);
                CARDHOLDERBILPROFEE_Length = Convert.ToUInt16(ds.Tables["CARDHOLDERBILPROFEE"].Rows[0]["Length"]);

                CARDHOLDERBILSRVICEFEE_StartPosition = Convert.ToUInt16(ds.Tables["CARDHOLDERBILSRVICEFEE"].Rows[0]["StartPosition"]);
                CARDHOLDERBILSRVICEFEE_Length = Convert.ToUInt16(ds.Tables["CARDHOLDERBILSRVICEFEE"].Rows[0]["Length"]);

                TRANS_CARDHOLDERCONVERRATE_StartPosition = Convert.ToUInt16(ds.Tables["TRANS_CARDHOLDERCONVERRATE"].Rows[0]["StartPosition"]);
                TRANS_CARDHOLDERCONVERRATE_Length = Convert.ToUInt16(ds.Tables["TRANS_CARDHOLDERCONVERRATE"].Rows[0]["Length"]);

                FORCEMATCH_StartPosition = Convert.ToUInt16(ds.Tables["FORCEMATCH"].Rows[0]["StartPosition"]);
                FORCEMATCH_Length = Convert.ToUInt16(ds.Tables["FORCEMATCH"].Rows[0]["Length"]);

                Cycle_StartPosition = Convert.ToUInt16(ds.Tables["Cycle"].Rows[0]["StartPosition"]);
                Cycle_Length = Convert.ToUInt16(ds.Tables["Cycle"].Rows[0]["Length"]);

                ReserveField1_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField1"].Rows[0]["StartPosition"]);
                ReserveField1_Length = Convert.ToUInt16(ds.Tables["ReserveField1"].Rows[0]["Length"]);

                ReserveField2_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField2"].Rows[0]["StartPosition"]);
                ReserveField2_Length = Convert.ToUInt16(ds.Tables["ReserveField2"].Rows[0]["Length"]);

                ReserveField3_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField3"].Rows[0]["StartPosition"]);
                ReserveField3_Length = Convert.ToUInt16(ds.Tables["ReserveField3"].Rows[0]["Length"]);

                ReserveField4_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField4"].Rows[0]["StartPosition"]);
                ReserveField4_Length = Convert.ToUInt16(ds.Tables["ReserveField4"].Rows[0]["Length"]);

                ReserveField5_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField5"].Rows[0]["StartPosition"]);
                ReserveField5_Length = Convert.ToUInt16(ds.Tables["ReserveField5"].Rows[0]["Length"]);


                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTime = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string line1 = string.Empty;
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(dtdetails.ConfigID);

                foreach (var batchDetail in fileImportRequest.FailedBatches)
                {
                    if (batchDetail.BatchNo != 0)
                    {
                        BatchNo = batchDetail.BatchNo - 1;
                    }


                    bool NewEntry = false;

                    if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                    {
                        //set the flag if it is new Entry
                        NewEntry = false;
                    }
                    else
                    {
                        if (batchDetail.BatchStatus == "None")
                        {
                            break;
                        }
                        else
                        {
                            //set the flag if it is old and  Partial Entry
                            NewEntry = true;
                        }
                    }

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        LineNo++;
                        if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                        {
                            continue;
                        }

                        try
                        {
                            line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                            Incr = 1;
                            PARICIPATEID = string.Empty;
                            TxnsDateTime = string.Empty;
                            TRANSACTIONTYPE = string.Empty;
                            FROMACCOUNTTYPE = string.Empty;
                            TOACCOUNTTYPE = string.Empty;
                            TRANSSERIALNO = string.Empty;
                            RESPONSECODE = string.Empty;
                            PANNUMBER = string.Empty;
                            MEMNUMBER = string.Empty;
                            APPROVNO = string.Empty;
                            STAUDITNO = string.Empty;
                            MERCHENTCATCODE = string.Empty;
                            CARDACCEPTSETDATE = string.Empty;
                            CARDACCEPTORID = string.Empty;
                            CARDACCEPTTERMINALID = string.Empty;
                            CARDACCEPTERTERLOCATION = string.Empty;
                            ACQUIRERID = string.Empty;
                            NETWORKID = string.Empty;
                            ACCOUNTNO1 = string.Empty;
                            ACCOUNTBRANCHID = string.Empty;
                            ACCOUNTNO2 = string.Empty;
                            ACCOUNT2BRANCHID = string.Empty;
                            TRANSCURRENCYCODE = string.Empty;
                            TRANSAMOUNT = "0";
                            ACCTUALTRANAMOUNT = "0";
                            TRANSACCVITYFEE = "0";
                            ISSUERSETCURRENCYCODE = string.Empty;
                            ISSURESETAMOUNT = "0";
                            ISSUERSETFEE = "0";
                            ISSURESETPROCFEE = "0";
                            CARDHOLDERBILLCURNCCODE = string.Empty;
                            CARDHOLDERBILLAMOUNT = "0";
                            CARDHOLDERBILACTFEE = "0";
                            CARDHOLDERBILPROFEE = "0";
                            CARDHOLDERBILSRVICEFEE = "0";
                            TRAN_ISSUERCONVERSRATE = "0";
                            TRANS_CARDHOLDERCONVERRATE = "0";
                            FORCEMATCH = string.Empty;

                            ReserveField1 = string.Empty;
                            ReserveField2 = string.Empty;
                            ReserveField3 = string.Empty;
                            ReserveField4 = string.Empty;
                            ReserveField5 = string.Empty;


                            PARICIPATEID = PARTICIPENTID_StartPosition > 0 && PARTICIPENTID_Length > 0 ? line1.Substring(PARTICIPENTID_StartPosition - Incr, PARTICIPENTID_Length).Trim() : string.Empty;
                            TxnsDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length) : string.Empty;
                            TRANSACTIONTYPE = TRANSTYPE_StartPosition > 0 && TRANSTYPE_Length > 0 ? line1.Substring(TRANSTYPE_StartPosition - Incr, TRANSTYPE_Length).Trim() : string.Empty;
                            FROMACCOUNTTYPE = FROMACCTYPE_StartPosition > 0 && FROMACCTYPE_Length > 0 ? line1.Substring(FROMACCTYPE_StartPosition - Incr, FROMACCTYPE_Length).Trim() : string.Empty;
                            TOACCOUNTTYPE = TOACCTYPE_StartPosition > 0 && TOACCTYPE_Length > 0 ? line1.Substring(TOACCTYPE_StartPosition - Incr, TOACCTYPE_Length).Trim() : string.Empty;
                            TRANSSERIALNO = TRANSSERIALNO_StartPosition > 0 && TRANSSERIALNO_Length > 0 ? line1.Substring(TRANSSERIALNO_StartPosition - Incr, TRANSSERIALNO_Length).Trim() : string.Empty;
                            RESPONSECODE = RESPONSECODE_StartPosition > 0 && RESPONSECODE_Length > 0 ? line1.Substring(RESPONSECODE_StartPosition - Incr, RESPONSECODE_Length).Trim() : string.Empty;
                            PANNUMBER = PANNO_StartPosition > 0 && PANNO_Length > 0 ? line1.Substring(PANNO_StartPosition - Incr, PANNO_Length).Trim() : string.Empty;
                            MEMNUMBER = MEMNUMBER_StartPosition > 0 && MEMNUMBER_Length > 0 ? line1.Substring(MEMNUMBER_StartPosition - Incr, MEMNUMBER_Length).Trim() : string.Empty;
                            APPROVNO = APPROVALNO_StartPosition > 0 && APPROVALNO_Length > 0 ? line1.Substring(APPROVALNO_StartPosition - Incr, APPROVALNO_Length).Trim() : string.Empty;
                            STAUDITNO = SYSTRACAUDITNO_StartPosition > 0 && SYSTRACAUDITNO_Length > 0 ? line1.Substring(SYSTRACAUDITNO_StartPosition - Incr, SYSTRACAUDITNO_Length).Trim() : string.Empty;
                            MERCHENTCATCODE = MERCHANTCATCODE_StartPosition > 0 && MERCHANTCATCODE_Length > 0 ? line1.Substring(MERCHANTCATCODE_StartPosition - Incr, MERCHANTCATCODE_Length).Trim() : string.Empty;
                            CARDACCEPTSETDATE = CARDACCEPTERSETDATE_StartPosition > 0 && CARDACCEPTERSETDATE_Length > 0 ? line1.Substring(CARDACCEPTERSETDATE_StartPosition - Incr, CARDACCEPTERSETDATE_Length).Trim() : string.Empty;
                            CARDACCEPTORID = CARDACCID_StartPosition > 0 && CARDACCID_Length > 0 ? line1.Substring(CARDACCID_StartPosition - Incr, CARDACCID_Length).Trim() : string.Empty;
                            CARDACCEPTTERMINALID = CARDACCEPTERID_StartPosition > 0 && CARDACCEPTERID_Length > 0 ? line1.Substring(CARDACCEPTERID_StartPosition - Incr, CARDACCEPTERID_Length).Trim() : string.Empty;
                            CARDACCEPTERTERLOCATION = CARDACCEPTERTERLOC_StartPosition > 0 && CARDACCEPTERTERLOC_Length > 0 ? line1.Substring(CARDACCEPTERTERLOC_StartPosition - Incr, CARDACCEPTERTERLOC_Length).Trim() : string.Empty;
                            ACQUIRERID = ACCIQUIERID_StartPosition > 0 && ACCIQUIERID_Length > 0 ? line1.Substring(ACCIQUIERID_StartPosition - Incr, ACCIQUIERID_Length).Trim() : string.Empty;
                            NETWORKID = NETWORKID_StartPosition > 0 && NETWORKID_Length > 0 ? line1.Substring(NETWORKID_StartPosition - Incr, NETWORKID_Length).Trim() : string.Empty;
                            ACCOUNTNO1 = ACCOUNTNO1_StartPosition > 0 && ACCOUNTNO1_Length > 0 ? line1.Substring(ACCOUNTNO1_StartPosition - Incr, ACCOUNTNO1_Length).Trim() : string.Empty;
                            ACCOUNTBRANCHID = ACCOUNTBRANCHID_StartPosition > 0 && ACCOUNTBRANCHID_Length > 0 ? line1.Substring(ACCOUNTBRANCHID_StartPosition - Incr, ACCOUNTBRANCHID_Length) : string.Empty;
                            ACCOUNTNO2 = ACCOUNTNO2_StartPosition > 0 && ACCOUNTNO2_Length > 0 ? line1.Substring(ACCOUNTNO2_StartPosition - Incr, ACCOUNTNO2_Length) : string.Empty;
                            ACCOUNT2BRANCHID = ACCOUNT2BRANCHID_StartPosition > 0 && ACCOUNT2BRANCHID_Length > 0 ? line1.Substring(ACCOUNT2BRANCHID_StartPosition - Incr, ACCOUNT2BRANCHID_Length) : string.Empty;
                            TRANSCURRENCYCODE = TRANSCURCODE_StartPosition > 0 && TRANSCURCODE_Length > 0 ? line1.Substring(TRANSCURCODE_StartPosition - Incr, TRANSCURCODE_Length).Trim() : string.Empty;
                            TRANSAMOUNT = TRANSAMOUNT_StartPosition > 0 && TRANSAMOUNT_Length > 0 ? line1.Substring(TRANSAMOUNT_StartPosition - Incr, TRANSAMOUNT_Length).Trim() : string.Empty;
                            ACCTUALTRANAMOUNT = ACCTUALTRANSAMOUNT_StartPosition > 0 && ACCTUALTRANSAMOUNT_Length > 0 ? line1.Substring(ACCTUALTRANSAMOUNT_StartPosition - Incr, ACCTUALTRANSAMOUNT_Length).Trim() : string.Empty;

                            TRANSACCVITYFEE = TRANSACTIVITYFEE_StartPosition > 0 && TRANSACTIVITYFEE_Length > 0 ? line1.Substring(TRANSACTIVITYFEE_StartPosition - Incr, TRANSACTIVITYFEE_Length).Trim() : string.Empty;
                            ISSUERSETCURRENCYCODE = ISSCURSETCURCODE_StartPosition > 0 && ISSCURSETCURCODE_Length > 0 ? line1.Substring(ISSCURSETCURCODE_StartPosition - Incr, ISSCURSETCURCODE_Length).Trim() : string.Empty;
                            ISSURESETAMOUNT = ISSUERSETAMOUNT_StartPosition > 0 && ISSUERSETAMOUNT_Length > 0 ? line1.Substring(ISSUERSETAMOUNT_StartPosition - Incr, ISSUERSETAMOUNT_Length).Trim() : string.Empty;
                            ISSUERSETFEE = ISSUERSETFEE_StartPosition > 0 && ISSUERSETFEE_Length > 0 ? line1.Substring(ISSUERSETFEE_StartPosition - Incr, ISSUERSETFEE_Length).Trim() : string.Empty;
                            ISSURESETPROCFEE = ISSUERSETPROFEE_StartPosition > 0 && ISSUERSETPROFEE_Length > 0 ? line1.Substring(ISSUERSETPROFEE_StartPosition - Incr, ISSUERSETPROFEE_Length).Trim() : string.Empty;
                            CARDHOLDERBILLCURNCCODE = CARDHOLDERBILLCURNCCODE_StartPosition > 0 && CARDHOLDERBILLCURNCCODE_Length > 0 ? line1.Substring(CARDHOLDERBILLCURNCCODE_StartPosition - Incr, CARDHOLDERBILLCURNCCODE_Length) : string.Empty;
                            CARDHOLDERBILLAMOUNT = CARDHOLDERBILLAMOUNT_StartPosition > 0 && CARDHOLDERBILLAMOUNT_Length > 0 ? line1.Substring(CARDHOLDERBILLAMOUNT_StartPosition - Incr, CARDHOLDERBILLAMOUNT_Length) : string.Empty;
                            CARDHOLDERBILACTFEE = CARDHOLDERBILACTFEE_StartPosition > 0 && CARDHOLDERBILACTFEE_Length > 0 ? line1.Substring(CARDHOLDERBILACTFEE_StartPosition - Incr, CARDHOLDERBILACTFEE_Length) : string.Empty;
                            CARDHOLDERBILPROFEE = CARDHOLDERBILPROFEE_StartPosition > 0 && CARDHOLDERBILPROFEE_Length > 0 ? line1.Substring(CARDHOLDERBILPROFEE_StartPosition - Incr, CARDHOLDERBILPROFEE_Length) : string.Empty;
                            CARDHOLDERBILSRVICEFEE = CARDHOLDERBILSRVICEFEE_StartPosition > 0 && CARDHOLDERBILSRVICEFEE_Length > 0 ? line1.Substring(CARDHOLDERBILSRVICEFEE_StartPosition - Incr, CARDHOLDERBILSRVICEFEE_Length) : string.Empty;
                            TRAN_ISSUERCONVERSRATE = TRANSISSUERCONVERRATE_StartPosition > 0 && TRANSISSUERCONVERRATE_Length > 0 ? line1.Substring(TRANSISSUERCONVERRATE_StartPosition - Incr, TRANSISSUERCONVERRATE_Length).Trim() : string.Empty;
                            TRANS_CARDHOLDERCONVERRATE = TRANS_CARDHOLDERCONVERRATE_StartPosition > 0 && TRANS_CARDHOLDERCONVERRATE_Length > 0 ? line1.Substring(TRANS_CARDHOLDERCONVERRATE_StartPosition - Incr, TRANS_CARDHOLDERCONVERRATE_Length) : string.Empty;
                            FORCEMATCH = FORCEMATCH_StartPosition > 0 && FORCEMATCH_Length > 0 ? line1.Substring(FORCEMATCH_StartPosition - Incr, FORCEMATCH_Length) : string.Empty;

                            ReserveField1 = ReserveField1_StartPosition > 0 && ReserveField1_Length > 0 ? line1.Substring(ReserveField1_StartPosition - Incr, ReserveField1_Length) : string.Empty;
                            ReserveField2 = ReserveField2_StartPosition > 0 && ReserveField2_Length > 0 ? line1.Substring(ReserveField2_StartPosition - Incr, ReserveField2_Length) : string.Empty;
                            ReserveField3 = ReserveField3_StartPosition > 0 && ReserveField3_Length > 0 ? line1.Substring(ReserveField3_StartPosition - Incr, ReserveField3_Length) : string.Empty;
                            ReserveField4 = ReserveField4_StartPosition > 0 && ReserveField4_Length > 0 ? line1.Substring(ReserveField4_StartPosition - Incr, ReserveField4_Length) : string.Empty;
                            ReserveField5 = ReserveField4_StartPosition > 0 && ReserveField5_Length > 0 ? line1.Substring(ReserveField5_StartPosition - Incr, ReserveField5_Length) : string.Empty;
                            Transaction_Date = TRANSDATE_StartPosition > 0 && TRANSDATE_Length > 0 ? line1.Substring(TRANSDATE_StartPosition - Incr, TRANSDATE_Length).Trim() : string.Empty;
                            Transaction_Time = TRANSTIME_StartPosition > 0 && TRANSTIME_Length > 0 ? line1.Substring(TRANSTIME_StartPosition - Incr, TRANSTIME_Length).Trim() : string.Empty;

                            TxnsDateTimeMain = null;



                            TRANSAMOUNT = Common.IsNumeric(TRANSAMOUNT) ? TRANSAMOUNT : "0";
                            ACCTUALTRANAMOUNT = Common.IsNumeric(ACCTUALTRANAMOUNT) ? ACCTUALTRANAMOUNT : "0";
                            TRANSACCVITYFEE = Common.IsNumeric(TRANSACCVITYFEE) ? TRANSACCVITYFEE : "0";
                            ISSURESETAMOUNT = Common.IsNumeric(ISSURESETAMOUNT) ? ISSURESETAMOUNT : "0";
                            ISSUERSETFEE = Common.IsNumeric(ISSUERSETFEE) ? ISSUERSETFEE : "0";
                            ISSURESETPROCFEE = Common.IsNumeric(ISSURESETPROCFEE) ? ISSURESETPROCFEE : "0";
                            CARDHOLDERBILLAMOUNT = Common.IsNumeric(CARDHOLDERBILLAMOUNT) ? CARDHOLDERBILLAMOUNT : "0";
                            CARDHOLDERBILACTFEE = Common.IsNumeric(CARDHOLDERBILACTFEE) ? CARDHOLDERBILACTFEE : "0";
                            CARDHOLDERBILPROFEE = Common.IsNumeric(CARDHOLDERBILPROFEE) ? CARDHOLDERBILPROFEE : "0";
                            CARDHOLDERBILSRVICEFEE = Common.IsNumeric(CARDHOLDERBILSRVICEFEE) ? CARDHOLDERBILSRVICEFEE : "0";
                            TRANS_CARDHOLDERCONVERRATE = Common.IsNumeric(TRANS_CARDHOLDERCONVERRATE) ? TRANS_CARDHOLDERCONVERRATE : "0";



                            if (TxnsDateTime != "" && TxnDateTime.Length > 0)
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime, CultureInfo.InvariantCulture);
                            }

                            if (Transaction_Date != "" && Transaction_Time != "")
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(Transaction_Date + " " + Transaction_Time, TxnDateTime, CultureInfo.InvariantCulture);
                            }
                            if (TxnsDateTimeMain != null)
                            {
                                _DataTable.Rows.Add(
                                 PARICIPATEID,
                                 TxnsDateTimeMain,
                                 TRANSACTIONTYPE,
                                 FROMACCOUNTTYPE,
                                 TOACCOUNTTYPE,
                                 TRANSSERIALNO,
                                 RESPONSECODE,
                                 PANNUMBER,
                                 MEMNUMBER,
                                 APPROVNO,
                                 STAUDITNO,
                                 MERCHENTCATCODE,
                                 CARDACCEPTSETDATE,
                                 CARDACCEPTORID,
                                 CARDACCEPTTERMINALID,
                                 CARDACCEPTERTERLOCATION,
                                 ACQUIRERID,
                                 NETWORKID,
                                 ACCOUNTNO1,
                                 ACCOUNTBRANCHID,
                                 ACCOUNTNO2,
                                 ACCOUNT2BRANCHID,
                                 TRANSCURRENCYCODE,
                                 TRANSAMOUNT,
                                 ACCTUALTRANAMOUNT,
                                 TRANSACCVITYFEE,
                                 ISSUERSETCURRENCYCODE,
                                 ISSURESETAMOUNT,
                                 ISSUERSETFEE,
                                 ISSURESETPROCFEE,
                                 CARDHOLDERBILLCURNCCODE,
                                 CARDHOLDERBILLAMOUNT,
                                 CARDHOLDERBILACTFEE,
                                 CARDHOLDERBILPROFEE,
                                 CARDHOLDERBILSRVICEFEE,
                                 TRAN_ISSUERCONVERSRATE,
                                 TRANS_CARDHOLDERCONVERRATE,
                                 FORCEMATCH,
                                 Cycle,
                                 ReserveField1,
                                 ReserveField2,
                                 ReserveField3,
                                 ReserveField4,
                                 ReserveField5);


                                if (_DataTable.Rows.Count >= batchSize)
                                {
                                    BatchNo++;

                                    MSG = bulkimports.BulkInsertIssuerDataAEPS(_DataTable, dtdetails.ConfigID, dtdetails.FileDateTime, fileImportRequest.Path, fileImportRequest.FileName, fileImportRequest.UserName);
                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                //    _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);

                                    BatchDetails batchDetails = new BatchDetails
                                    {
                                        BatchNo = BatchNo,
                                        BatchSize = batchSize,
                                        TxnUploadCount = _DataTable.Rows.Count,
                                        TxnsCount = fileImportRequest.InsertCount,
                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                        FailedCount = ErrorCount,
                                        BatchStartTime = batchStartTime,
                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                    };

                                    batchDetailsList.Add(batchDetails);
                                    _DataTable.Clear();
                                    StartTime = DateTime.Now;
                                    ErrorCount = 0;
                                    if (NewEntry)
                                    {
                                        break;
                                    }
                                }

                            }
                            //uspDynamicBulkInsertAEPSAcquirerData

                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                        }
                    }

                    LineNo = 0;
                }
            }

            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkimports.BulkInsertIssuerDataAEPS(_DataTable, dtdetails.ConfigID, dtdetails.FileDateTime, fileImportRequest.Path, fileImportRequest.FileName, fileImportRequest.UserName);
               // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

               // _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";


            return MSG;

        }

        public string Splitter_NPCI_Settlement_AEPS_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNumber = 0;
            int LineNo = 0, ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0; 

            DtDetails dtdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("NoTxns", typeof(int));
            _DataTable.Columns.Add("Debit", typeof(decimal));
            _DataTable.Columns.Add("Credit", typeof(decimal));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));

            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
            string FileDateFormat = fileImportRequest.ConfigData.Rows[0]["FileDateFormat"].ToString();

            DateTime? TxnsDateTimeMain = null;
            DateTime? FileDateTime = null;

            string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

            string[] FDA = fileImportRequest.FileName.Split('_', '.');

            string Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

            DataSet ds = new DataSet();

            try
            {

                conString = string.Format(conString, fileImportRequest.Path);

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                ushort Description_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Description"]);
                ushort NoTxns_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NoTxns"]);
                ushort Debit_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Debit"]);
                ushort Credit_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Credit"]);
                ushort Remarks_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remarks"]);
                ushort Date_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Date"]);

                DataTable dtexcelsheetname = new DataTable();
                DataTable dtSheet = new DataTable();

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }


                DateTime StartTime = DateTime.Now;
                string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {

                    
                    int j = 0;
                    //Get Batch Size
                    batchSize = bulkimports.GetBatchSize(dtdetails.ConfigID);

                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }


                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }

                        foreach (DataRow row in dtexcelsheetname.Rows)
                        { 
                            string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = Getdatafromsheet1;
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            int Incr = 1;
                            string Description = string.Empty;
                            string NoTxnsValue = "0";
                            string DebitValue = "0";
                            string CreditValue = "0";
                            string Remarks = string.Empty;
                            string TxnsDate = string.Empty;

                            if (dtSheet.Rows.Count > 1)
                            {
                                fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                for (int k = 0; k < dtSheet.Rows.Count; k++)
                                {
                                    LineNo++;
                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    Incr = 1;
                                    Description = string.Empty;
                                    NoTxnsValue = "0";
                                    DebitValue = "0";
                                    CreditValue = "0";
                                    Remarks = string.Empty;
                                    TxnsDate = string.Empty;
                                    TxnsDateTimeMain = null;

                                    try
                                    {

                                        Description = Description_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Description_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        NoTxnsValue = NoTxns_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][NoTxns_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        DebitValue = Debit_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Debit_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        CreditValue = Credit_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Credit_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Remarks = Remarks_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Remarks_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsDate = Date_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Date_CoulmnIndex - Incr]).Trim() : string.Empty;


                                        if (TxnsDate.Length > 0)
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDate, TxnDateTime, CultureInfo.InvariantCulture);
                                        }
                                        else
                                        {
                                            if (FileDateFormat.Length > 0)
                                            {
                                                string dateFile = ExtractNumber(fileImportRequest.FileName).Substring(0, FileDateFormat.Length);
                                                try
                                                {
                                                    FileDateTime = DateTime.ParseExact(dateFile, FileDateFormat, CultureInfo.InvariantCulture);
                                                }
                                                catch (Exception ex)
                                                {
                                                    FileDateTime = DateTime.Now;
                                                }
                                            }
                                            else
                                            {
                                                FileDateTime = DateTime.Now;
                                            }

                                            TxnsDateTimeMain = FileDateTime;
                                        }

                                        NoTxnsValue = Common.IsNumeric(NoTxnsValue) ? NoTxnsValue : "0";
                                        DebitValue = Common.IsNumeric(DebitValue) ? DebitValue : "0";
                                        CreditValue = Common.IsNumeric(CreditValue) ? CreditValue : "0";

                                        if (Description != "" && (Convert.ToDecimal(DebitValue) > 0 || Convert.ToDecimal(CreditValue) > 0) && TxnsDateTimeMain != null)
                                        {

                                            _DataTable.Rows.Add
                                                (
                                                TxnsDateTimeMain
                                                , Cycle
                                                , Convert.ToInt16(NoTxnsValue)
                                                , Convert.ToDecimal(DebitValue)
                                                , Convert.ToDecimal(CreditValue)
                                                , Description
                                                , Remarks
                                                );

                                            if (_DataTable.Rows.Count >= batchSize)
                                            {
                                                BatchNo++;

                                                MSG = bulkimports.BulkInsertSettlementDataAEPS(_DataTable, dtdetails.ConfigID, dtdetails.FileDateTime, fileImportRequest.Path, fileImportRequest.FileName, fileImportRequest.UserName);
                                                fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                               // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);

                                                BatchDetails batchDetails = new BatchDetails
                                                {
                                                    BatchNo = BatchNo,
                                                    BatchSize = batchSize,
                                                    TxnUploadCount = _DataTable.Rows.Count,
                                                    TxnsCount = fileImportRequest.InsertCount,
                                                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                    FailedCount = ErrorCount,
                                                    BatchStartTime = batchStartTime,
                                                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                };

                                                batchDetailsList.Add(batchDetails);
                                                _DataTable.Clear();
                                                StartTime = DateTime.Now;
                                                ErrorCount = 0;
                                                if (NewEntry)
                                                {
                                                    break;
                                                }
                                            }

                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorCount++;
                                        DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    }

                                    LineNumber++;
                                }
                            }

                            j++;
                        }

                        LineNo = 0;
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    BatchNo = BatchNo + 1;

                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                    MSG = bulkimports.BulkInsertSettlementDataAEPS(_DataTable, dtdetails.ConfigID, dtdetails.FileDateTime, fileImportRequest.Path, fileImportRequest.FileName, fileImportRequest.UserName);
                   // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                    BatchDetails batchDetails = new BatchDetails
                    {
                        BatchNo = BatchNo,
                        BatchSize = batchSize,
                        TxnUploadCount = _DataTable.Rows.Count,
                        TxnsCount = fileImportRequest.InsertCount,
                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                        FailedCount = ErrorCount,
                        BatchStartTime = batchStartTime,
                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    };

                    batchDetailsList.Add(batchDetails);

                   // _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

                }
              
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        string ExtractNumber(string original)
        {
            return new string(original.Where(c => Char.IsDigit(c)).ToArray());
        }

    }

}
