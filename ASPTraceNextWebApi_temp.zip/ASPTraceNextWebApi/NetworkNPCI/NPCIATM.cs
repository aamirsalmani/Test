﻿using System;  
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions; 
using System.Xml;
using Utility;
using ASPTrace.Models;
using System.Text.Json;
using ImportData;
using System.Reflection;
using DocumentFormat.OpenXml.Math;

namespace NetworkNPCI
{
    public class NPCIATM
    {

       
        private readonly string _connectionString;
        BulkImports bulkImports;
        public NPCIATM(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkImports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }
        public string Splitter_NPCI_Issuer_ATM_Text_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int LineNumber = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int ErrorCount = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkImports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FromAccountType", typeof(string));
            _DataTable.Columns.Add("ToAccountType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(DateTime));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            string RevEntryLeg = "1";


            int Incr = 1;
            string PARTICIPENTID = string.Empty;
            string TRANSTYPE = string.Empty;
            string FROMACCTYPE = string.Empty;
            string TOACCTYPE = string.Empty;
            string ReferenceNumber = string.Empty;
            string RESPONSECODE = string.Empty;
            string CardNumber = string.Empty;
            string MEMNUMBER = string.Empty;
            string APPROVALNO = string.Empty;
            string SYSTRACAUDITNO = string.Empty;
            string TxnsDateTime = string.Empty;
            string TRANSDATE = string.Empty;
            string TRANSTIME = string.Empty;
            string MERCHANTCATCODE = string.Empty;
            string CARDACCEPTERSETDATE = string.Empty;

            string CARDACCID = string.Empty;
            string TerminalId = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string ACCIQUIERID = string.Empty;

            string NETWORKID = string.Empty;
            string ACCOUNTNO1 = string.Empty;
            string ACCOUNTBRANCHID = string.Empty;
            string ACCOUNTNO2 = string.Empty;
            string ACCOUNT2BRANCHID = string.Empty;
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = "0";
            string ACCTUALTRANAMOUNT = "0";
            string TRANSACCVITYFEE = "0";
            string ISSUERSETCURRENCYCODE = string.Empty;
            string ISSURESETAMOUNT = "0";
            string ISSUERSETFEE = "0";
            string ISSURESETPROCFEE = "0";
            string CARDHOLDERBILLCURNCCODE = string.Empty;
            string CARDHOLDERBILLAMOUNT = "0";
            string CARDHOLDERBILACTFEE = "0";
            string CARDHOLDERBILPROFEE = "0";
            string CARDHOLDERBILSRVICEFEE = "0";
            string TRAN_ISSUERCONVERSRATE = "0";
            string TRANS_CARDHOLDERCONVERRATE = "0";


            string ECardNumber = string.Empty;
            string line1 = string.Empty;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            string CardType = string.Empty;

            DateTime? TxnsDateTimeMain = null;

            DateTime? CARDACCEPTERSETDATEMain = null;

            string[] TxnDateTimeFormat = null;

            string Cycle = string.Empty;

            ushort PARICIPATEID_StartPosition = 0;
            ushort PARICIPATEID_Length = 0;
            ushort TRANSACTIONTYPE_StartPosition = 0;
            ushort TRANSACTIONTYPE_Length = 0;
            ushort FromAccountType_StartPosition = 0;
            ushort FromAccountType_Length = 0;
            ushort ToAccountType_StartPosition = 0;
            ushort ToAccountType_Length = 0;
            ushort ReferenceNumber_StartPosition = 0;
            ushort ReferenceNumber_Length = 0;
            ushort ResponseCode_StartPosition = 0;
            ushort ResponseCode_Length = 0;
            ushort CardNumber_StartPosition = 0;
            ushort CardNumber_Length = 0;
            ushort MEMNUMBER_StartPosition = 0;
            ushort MEMNUMBER_Length = 0;
            ushort APPROVNO_StartPosition = 0;
            ushort APPROVNO_Length = 0;
            ushort STAUDITNO_StartPosition = 0;
            ushort STAUDITNO_Length = 0;
            ushort TxnsDateTime_StartPosition = 0;
            ushort TxnsDateTime_Length = 0;
            ushort TRANSTIME_StartPosition = 0;
            ushort TRANSTIME_Length = 0;
            ushort TRANSDATE_StartPosition = 0;
            ushort TRANSDATE_Length = 0;
            ushort MERCHENTCATCODE_StartPosition = 0;
            ushort MERCHENTCATCODE_Length = 0;
            ushort CARDACCEPTSETDATE_StartPosition = 0;
            ushort CARDACCEPTSETDATE_Length = 0;
            ushort CARDACCID_StartPosition = 0;
            ushort CARDACCID_Length = 0;
            ushort TerminalId_StartPosition = 0;
            ushort TerminalId_Length = 0;
            ushort CARDACCEPTERTERLOCATION_StartPosition = 0;
            ushort CARDACCEPTERTERLOCATION_Length = 0;
            ushort AcquirerID_StartPosition = 0;
            ushort AcquirerID_Length = 0;
            ushort NETWORKID_StartPosition = 0;
            ushort NETWORKID_Length = 0;
            ushort ACCOUNTNO1_StartPosition = 0;
            ushort ACCOUNTNO1_Length = 0;
            ushort ACCOUNTBRANCHID_StartPosition = 0;
            ushort ACCOUNTBRANCHID_Length = 0;
            ushort ACCOUNTNO2_StartPosition = 0;
            ushort ACCOUNTNO2_Length = 0;
            ushort ACCOUNT2BRANCHID_StartPosition = 0;
            ushort ACCOUNT2BRANCHID_Length = 0;
            ushort TRANSCURRENCYCODE_StartPosition = 0;
            ushort TRANSCURRENCYCODE_Length = 0;
            ushort TxnsAmount_StartPosition = 0;
            ushort TxnsAmount_Length = 0;
            ushort ACCTUALTRANAMOUNT_StartPosition = 0;
            ushort ACCTUALTRANAMOUNT_Length = 0;
            ushort TRANSACCVITYFEE_StartPosition = 0;
            ushort TRANSACCVITYFEE_Length = 0;
            ushort ISSUERSETCURRENCYCODE_StartPosition = 0;
            ushort ISSUERSETCURRENCYCODE_Length = 0;
            ushort ISSURESETAMOUNT_StartPosition = 0;
            ushort ISSURESETAMOUNT_Length = 0;
            ushort ISSUERSETFEE_StartPosition = 0;
            ushort ISSUERSETFEE_Length = 0;
            ushort ISSURESETPROCFEE_StartPosition = 0;
            ushort ISSURESETPROCFEE_Length = 0;
            ushort CARDHOLDERBILLCURNCCODE_StartPosition = 0;
            ushort CARDHOLDERBILLCURNCCODE_Length = 0;
            ushort CARDHOLDERBILLAMOUNT_StartPosition = 0;
            ushort CARDHOLDERBILLAMOUNT_Length = 0;
            ushort CARDHOLDERBILACTFEE_StartPosition = 0;
            ushort CARDHOLDERBILACTFEE_Length = 0;
            ushort CARDHOLDERBILPROFEE_StartPosition = 0;
            ushort CARDHOLDERBILPROFEE_Length = 0;
            ushort CARDHOLDERBILSRVICEFEE_StartPosition = 0;
            ushort CARDHOLDERBILSRVICEFEE_Length = 0;
            ushort TRAN_ISSUERCONVERSRATE_StartPosition = 0;
            ushort TRAN_ISSUERCONVERSRATE_Length = 0;
            ushort TRANS_CARDHOLDERCONVERRATE_StartPosition = 0;
            ushort TRANS_CARDHOLDERCONVERRATE_Length = 0;

            bool ErrorOccurred = false;

            try
            {  

                int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
                fileImportRequest.TotalCount = TotalCountArray.Length;

                TxnDateTimeFormat =  fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
                                 
                string[] FDA = fileImportRequest.FileName.Split('_');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                DataSet ds = new DataSet();

                ds.ReadXml(new XmlTextReader(new System.IO.StringReader(xmlFile)));

                PARICIPATEID_StartPosition = Convert.ToUInt16(ds.Tables["PARICIPATEID"].Rows[0]["StartPosition"]);
                PARICIPATEID_Length = Convert.ToUInt16(ds.Tables["PARICIPATEID"].Rows[0]["Length"]);

                TRANSACTIONTYPE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACTIONTYPE"].Rows[0]["StartPosition"]);
                TRANSACTIONTYPE_Length = Convert.ToUInt16(ds.Tables["TRANSACTIONTYPE"].Rows[0]["Length"]);

                FromAccountType_StartPosition = Convert.ToUInt16(ds.Tables["FromAccountType"].Rows[0]["StartPosition"]);
                FromAccountType_Length = Convert.ToUInt16(ds.Tables["FromAccountType"].Rows[0]["Length"]);

                ToAccountType_StartPosition = Convert.ToUInt16(ds.Tables["ToAccountType"].Rows[0]["StartPosition"]);
                ToAccountType_Length = Convert.ToUInt16(ds.Tables["ToAccountType"].Rows[0]["Length"]);

                ReferenceNumber_StartPosition = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"]);
                ReferenceNumber_Length = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["Length"]);

                ResponseCode_StartPosition = Convert.ToUInt16(ds.Tables["ResponseCode"].Rows[0]["StartPosition"]);
                ResponseCode_Length = Convert.ToUInt16(ds.Tables["ResponseCode"].Rows[0]["Length"]);

                CardNumber_StartPosition = Convert.ToUInt16(ds.Tables["CardNumber"].Rows[0]["StartPosition"]);
                CardNumber_Length = Convert.ToUInt16(ds.Tables["CardNumber"].Rows[0]["Length"]);

                MEMNUMBER_StartPosition = Convert.ToUInt16(ds.Tables["MEMNUMBER"].Rows[0]["StartPosition"]);
                MEMNUMBER_Length = Convert.ToUInt16(ds.Tables["MEMNUMBER"].Rows[0]["Length"]);

                APPROVNO_StartPosition = Convert.ToUInt16(ds.Tables["APPROVNO"].Rows[0]["StartPosition"]);
                APPROVNO_Length = Convert.ToUInt16(ds.Tables["APPROVNO"].Rows[0]["Length"]);

                STAUDITNO_StartPosition = Convert.ToUInt16(ds.Tables["STAUDITNO"].Rows[0]["StartPosition"]);
                STAUDITNO_Length = Convert.ToUInt16(ds.Tables["STAUDITNO"].Rows[0]["Length"]);

                TxnsDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"]);
                TxnsDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["Length"]);

                TRANSTIME_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACTIONTIME"].Rows[0]["StartPosition"]);
                TRANSTIME_Length = Convert.ToUInt16(ds.Tables["TRANSACTIONTIME"].Rows[0]["Length"]);

                TRANSDATE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACTIONDATE"].Rows[0]["StartPosition"]);
                TRANSDATE_Length = Convert.ToUInt16(ds.Tables["TRANSACTIONDATE"].Rows[0]["Length"]);

                MERCHENTCATCODE_StartPosition = Convert.ToUInt16(ds.Tables["MERCHENTCATCODE"].Rows[0]["StartPosition"]);
                MERCHENTCATCODE_Length = Convert.ToUInt16(ds.Tables["MERCHENTCATCODE"].Rows[0]["Length"]);

                CARDACCEPTSETDATE_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTSETDATE"].Rows[0]["StartPosition"]);
                CARDACCEPTSETDATE_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTSETDATE"].Rows[0]["Length"]);

                CARDACCID_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCID"].Rows[0]["StartPosition"]);
                CARDACCID_Length = Convert.ToUInt16(ds.Tables["CARDACCID"].Rows[0]["Length"]);

                TerminalId_StartPosition = Convert.ToUInt16(ds.Tables["TerminalId"].Rows[0]["StartPosition"]);
                TerminalId_Length = Convert.ToUInt16(ds.Tables["TerminalId"].Rows[0]["Length"]);

                CARDACCEPTERTERLOCATION_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTERTERLOCATION"].Rows[0]["StartPosition"]);
                CARDACCEPTERTERLOCATION_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTERTERLOCATION"].Rows[0]["Length"]);

                AcquirerID_StartPosition = Convert.ToUInt16(ds.Tables["AcquirerID"].Rows[0]["StartPosition"]);
                AcquirerID_Length = Convert.ToUInt16(ds.Tables["AcquirerID"].Rows[0]["Length"]);

                NETWORKID_StartPosition = Convert.ToUInt16(ds.Tables["NETWORKID"].Rows[0]["StartPosition"]);
                NETWORKID_Length = Convert.ToUInt16(ds.Tables["NETWORKID"].Rows[0]["Length"]);

                ACCOUNTNO1_StartPosition = Convert.ToUInt16(ds.Tables["ACCOUNTNO1"].Rows[0]["StartPosition"]);
                ACCOUNTNO1_Length = Convert.ToUInt16(ds.Tables["ACCOUNTNO1"].Rows[0]["Length"]);

                ACCOUNTBRANCHID_StartPosition = Convert.ToUInt16(ds.Tables["ACCOUNTBRANCHID"].Rows[0]["StartPosition"]);
                ACCOUNTBRANCHID_Length = Convert.ToUInt16(ds.Tables["ACCOUNTBRANCHID"].Rows[0]["Length"]);

                ACCOUNTNO2_StartPosition = Convert.ToUInt16(ds.Tables["ACCOUNTNO2"].Rows[0]["StartPosition"]);
                ACCOUNTNO2_Length = Convert.ToUInt16(ds.Tables["ACCOUNTNO2"].Rows[0]["Length"]);

                ACCOUNT2BRANCHID_StartPosition = Convert.ToUInt16(ds.Tables["ACCOUNT2BRANCHID"].Rows[0]["StartPosition"]);
                ACCOUNT2BRANCHID_Length = Convert.ToUInt16(ds.Tables["ACCOUNT2BRANCHID"].Rows[0]["Length"]);

                TRANSCURRENCYCODE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSCURRENCYCODE"].Rows[0]["StartPosition"]);
                TRANSCURRENCYCODE_Length = Convert.ToUInt16(ds.Tables["TRANSCURRENCYCODE"].Rows[0]["Length"]);

                TxnsAmount_StartPosition = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["StartPosition"]);
                TxnsAmount_Length = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["Length"]);

                ACCTUALTRANAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["ACCTUALTRANAMOUNT"].Rows[0]["StartPosition"]);
                ACCTUALTRANAMOUNT_Length = Convert.ToUInt16(ds.Tables["ACCTUALTRANAMOUNT"].Rows[0]["Length"]);

                TRANSACCVITYFEE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACCVITYFEE"].Rows[0]["StartPosition"]);
                TRANSACCVITYFEE_Length = Convert.ToUInt16(ds.Tables["TRANSACCVITYFEE"].Rows[0]["Length"]);

                ISSUERSETCURRENCYCODE_StartPosition = Convert.ToUInt16(ds.Tables["ISSUERSETCURRENCYCODE"].Rows[0]["StartPosition"]);
                ISSUERSETCURRENCYCODE_Length = Convert.ToUInt16(ds.Tables["ISSUERSETCURRENCYCODE"].Rows[0]["Length"]);

                ISSURESETAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["ISSURESETAMOUNT"].Rows[0]["StartPosition"]);
                ISSURESETAMOUNT_Length = Convert.ToUInt16(ds.Tables["ISSURESETAMOUNT"].Rows[0]["Length"]);

                ISSUERSETFEE_StartPosition = Convert.ToUInt16(ds.Tables["ISSUERSETFEE"].Rows[0]["StartPosition"]);
                ISSUERSETFEE_Length = Convert.ToUInt16(ds.Tables["ISSUERSETFEE"].Rows[0]["Length"]);

                ISSURESETPROCFEE_StartPosition = Convert.ToUInt16(ds.Tables["ISSURESETPROCFEE"].Rows[0]["StartPosition"]);
                ISSURESETPROCFEE_Length = Convert.ToUInt16(ds.Tables["ISSURESETPROCFEE"].Rows[0]["Length"]);

                CARDHOLDERBILLCURNCCODE_StartPosition = Convert.ToUInt16(ds.Tables["CARDHOLDERBILLCURNCCODE"].Rows[0]["StartPosition"]);
                CARDHOLDERBILLCURNCCODE_Length = Convert.ToUInt16(ds.Tables["CARDHOLDERBILLCURNCCODE"].Rows[0]["Length"]);

                CARDHOLDERBILLAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["CARDHOLDERBILLAMOUNT"].Rows[0]["StartPosition"]);
                CARDHOLDERBILLAMOUNT_Length = Convert.ToUInt16(ds.Tables["CARDHOLDERBILLAMOUNT"].Rows[0]["Length"]);

                CARDHOLDERBILACTFEE_StartPosition = Convert.ToUInt16(ds.Tables["CARDHOLDERBILACTFEE"].Rows[0]["StartPosition"]);
                CARDHOLDERBILACTFEE_Length = Convert.ToUInt16(ds.Tables["CARDHOLDERBILACTFEE"].Rows[0]["Length"]);

                CARDHOLDERBILPROFEE_StartPosition = Convert.ToUInt16(ds.Tables["CARDHOLDERBILPROFEE"].Rows[0]["StartPosition"]);
                CARDHOLDERBILPROFEE_Length = Convert.ToUInt16(ds.Tables["CARDHOLDERBILPROFEE"].Rows[0]["Length"]);

                CARDHOLDERBILSRVICEFEE_StartPosition = Convert.ToUInt16(ds.Tables["CARDHOLDERBILSRVICEFEE"].Rows[0]["StartPosition"]);
                CARDHOLDERBILSRVICEFEE_Length = Convert.ToUInt16(ds.Tables["CARDHOLDERBILSRVICEFEE"].Rows[0]["Length"]);

                TRAN_ISSUERCONVERSRATE_StartPosition = Convert.ToUInt16(ds.Tables["TRAN_ISSUERCONVERSRATE"].Rows[0]["StartPosition"]);
                TRAN_ISSUERCONVERSRATE_Length = Convert.ToUInt16(ds.Tables["TRAN_ISSUERCONVERSRATE"].Rows[0]["Length"]);

                TRANS_CARDHOLDERCONVERRATE_StartPosition = Convert.ToUInt16(ds.Tables["TRANS_CARDHOLDERCONVERRATE"].Rows[0]["StartPosition"]);
                TRANS_CARDHOLDERCONVERRATE_Length = Convert.ToUInt16(ds.Tables["TRANS_CARDHOLDERCONVERRATE"].Rows[0]["Length"]);

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                //Get Batch Size
                batchSize = bulkImports.GetBatchSize(DTdetails.ConfigID);

                foreach (var batchDetail in fileImportRequest.FailedBatches)
                {
                    if (batchDetail.BatchNo != 0)
                    {
                        BatchNo = batchDetail.BatchNo - 1;
                    }


                    bool NewEntry = false;

                    if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                    {
                        //set the flag if it is new Entry
                        NewEntry = false;
                    }
                    else
                    {
                        if (batchDetail.BatchStatus == "None")
                        {
                            break;
                        }
                        else
                        {
                            //set the flag if it is old and  Partial Entry
                            NewEntry = true;
                        }
                    }

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        LineNo++;
                        LineNumber++;
                        if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                        {
                            continue;
                        }
                        try
                        {
                            line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                            //string[] dtSheet.Rows[k] = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                            Incr = 1;
                            PARTICIPENTID = string.Empty;
                            TRANSTYPE = string.Empty;
                            FROMACCTYPE = string.Empty;
                            TOACCTYPE = string.Empty;
                            ReferenceNumber = string.Empty;
                            RESPONSECODE = string.Empty;
                            CardNumber = string.Empty;
                            MEMNUMBER = string.Empty;
                            APPROVALNO = string.Empty;
                            SYSTRACAUDITNO = string.Empty;
                            TxnsDateTime = string.Empty;
                            TRANSTIME = string.Empty;
                            MERCHANTCATCODE = string.Empty;
                            CARDACCEPTERSETDATE = string.Empty;

                            CARDACCID = string.Empty;
                            TerminalId = string.Empty;
                            CARDACCEPTERTERLOC = string.Empty;
                            ACCIQUIERID = string.Empty;
                            Transaction_Amount = "0";
                            ACCTUALTRANAMOUNT = "0";
                            TRANSACCVITYFEE = "0";
                            ISSUERSETCURRENCYCODE = string.Empty;
                            ISSURESETAMOUNT = "0";
                            ISSUERSETFEE = "0";
                            ISSURESETPROCFEE = "0";
                            CARDHOLDERBILLCURNCCODE = string.Empty;
                            CARDHOLDERBILLAMOUNT = "0";
                            CARDHOLDERBILACTFEE = "0";
                            CARDHOLDERBILPROFEE = "0";
                            CARDHOLDERBILSRVICEFEE = "0";
                            TRAN_ISSUERCONVERSRATE = "0";
                            TRANS_CARDHOLDERCONVERRATE = "0";
                            ECardNumber = string.Empty;
                            CardScheme = string.Empty;

                            PARTICIPENTID = PARICIPATEID_StartPosition > 0 && PARICIPATEID_Length > 0 ? line1.Substring(PARICIPATEID_StartPosition - Incr, PARICIPATEID_Length).Trim() : string.Empty;

                            TRANSTYPE = TRANSACTIONTYPE_StartPosition > 0 && TRANSACTIONTYPE_Length > 0 ? line1.Substring(TRANSACTIONTYPE_StartPosition - Incr, TRANSACTIONTYPE_Length).Trim() : string.Empty;
                            FROMACCTYPE = FromAccountType_StartPosition > 0 && FromAccountType_Length > 0 ? line1.Substring(FromAccountType_StartPosition - Incr, FromAccountType_Length).Trim() : string.Empty;
                            TOACCTYPE = ToAccountType_StartPosition > 0 && ToAccountType_Length > 0 ? line1.Substring(ToAccountType_StartPosition - Incr, ToAccountType_Length).Trim() : string.Empty;
                            ReferenceNumber = ReferenceNumber_StartPosition > 0 && ReferenceNumber_Length > 0 ? line1.Substring(ReferenceNumber_StartPosition - Incr, ReferenceNumber_Length).Trim() : string.Empty;
                            RESPONSECODE = ResponseCode_StartPosition > 0 && ResponseCode_Length > 0 ? line1.Substring(ResponseCode_StartPosition - Incr, ResponseCode_Length).Trim() : string.Empty;
                            CardNumber = CardNumber_StartPosition > 0 && CardNumber_Length > 0 ? line1.Substring(CardNumber_StartPosition - Incr, CardNumber_Length).Trim() : string.Empty;
                            MEMNUMBER = MEMNUMBER_StartPosition > 0 && MEMNUMBER_Length > 0 ? line1.Substring(MEMNUMBER_StartPosition - Incr, MEMNUMBER_Length).Trim() : string.Empty;
                            APPROVALNO = APPROVNO_StartPosition > 0 && APPROVNO_Length > 0 ? line1.Substring(APPROVNO_StartPosition - Incr, APPROVNO_Length).Trim() : string.Empty;
                            SYSTRACAUDITNO = STAUDITNO_StartPosition > 0 && STAUDITNO_Length > 0 ? line1.Substring(STAUDITNO_StartPosition - Incr, STAUDITNO_Length).Trim() : string.Empty;
                            TxnsDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length).Trim() : string.Empty;
                            MERCHANTCATCODE = MERCHENTCATCODE_StartPosition > 0 && MERCHENTCATCODE_Length > 0 ? line1.Substring(MERCHENTCATCODE_StartPosition - Incr, MERCHENTCATCODE_Length).Trim() : string.Empty;
                            CARDACCID = CARDACCID_StartPosition > 0 && CARDACCID_Length > 0 ? line1.Substring(CARDACCID_StartPosition - Incr, CARDACCID_Length).Trim() : string.Empty;

                            TerminalId = TerminalId_StartPosition > 0 && TerminalId_Length > 0 ? line1.Substring(TerminalId_StartPosition - Incr, TerminalId_Length).Trim() : string.Empty;
                            CARDACCEPTERTERLOC = CARDACCEPTERTERLOCATION_StartPosition > 0 && CARDACCEPTERTERLOCATION_Length > 0 ? line1.Substring(CARDACCEPTERTERLOCATION_StartPosition - Incr, CARDACCEPTERTERLOCATION_Length).Trim() : string.Empty;
                            ACCIQUIERID = AcquirerID_StartPosition > 0 && AcquirerID_Length > 0 ? line1.Substring(AcquirerID_StartPosition - Incr, AcquirerID_Length).Trim() : string.Empty;

                            NETWORKID = NETWORKID_StartPosition > 0 && NETWORKID_Length > 0 ? line1.Substring(NETWORKID_StartPosition - Incr, NETWORKID_Length).Trim() : string.Empty;
                            ACCOUNTNO1 = ACCOUNTNO1_StartPosition > 0 && ACCOUNTNO1_Length > 0 ? line1.Substring(ACCOUNTNO1_StartPosition - Incr, ACCOUNTNO1_Length).Trim() : string.Empty;
                            ACCOUNTBRANCHID = ACCOUNTBRANCHID_StartPosition > 0 && ACCOUNTBRANCHID_Length > 0 ? line1.Substring(ACCOUNTBRANCHID_StartPosition - Incr, ACCOUNTBRANCHID_Length).Trim() : string.Empty;
                            ACCOUNTNO2 = ACCOUNTNO2_StartPosition > 0 && ACCOUNTNO2_Length > 0 ? line1.Substring(ACCOUNTNO2_StartPosition - Incr, ACCOUNTNO2_Length).Trim() : string.Empty;
                            ACCOUNT2BRANCHID = ACCOUNT2BRANCHID_StartPosition > 0 && ACCOUNT2BRANCHID_Length > 0 ? line1.Substring(ACCOUNT2BRANCHID_StartPosition - Incr, ACCOUNT2BRANCHID_Length).Trim() : string.Empty;
                            Transaction_Currency_Code = TRANSCURRENCYCODE_StartPosition > 0 && TRANSCURRENCYCODE_Length > 0 ? line1.Substring(TRANSCURRENCYCODE_StartPosition - Incr, TRANSCURRENCYCODE_Length).Trim() : string.Empty;
                            Transaction_Amount = TxnsAmount_StartPosition > 0 && TxnsAmount_Length > 0 ? line1.Substring(TxnsAmount_StartPosition - Incr, TxnsAmount_Length).Trim() : string.Empty;
                            ACCTUALTRANAMOUNT = ACCTUALTRANAMOUNT_StartPosition > 0 && ACCTUALTRANAMOUNT_Length > 0 ? line1.Substring(ACCTUALTRANAMOUNT_StartPosition - Incr, ACCTUALTRANAMOUNT_Length).Trim() : string.Empty;


                            TRANSACCVITYFEE = TRANSACCVITYFEE_StartPosition > 0 && TRANSACCVITYFEE_Length > 0 ? line1.Substring(TRANSACCVITYFEE_StartPosition - Incr, TRANSACCVITYFEE_Length).Trim() : string.Empty;
                            ISSUERSETCURRENCYCODE = ISSUERSETCURRENCYCODE_StartPosition > 0 && ISSUERSETCURRENCYCODE_Length > 0 ? line1.Substring(ISSUERSETCURRENCYCODE_StartPosition - Incr, ISSUERSETCURRENCYCODE_Length).Trim() : string.Empty;
                            ISSURESETAMOUNT = ISSURESETAMOUNT_StartPosition > 0 && ISSURESETAMOUNT_Length > 0 ? line1.Substring(ISSURESETAMOUNT_StartPosition - Incr, ISSURESETAMOUNT_Length).Trim() : string.Empty;
                            ISSUERSETFEE = ISSUERSETFEE_StartPosition > 0 && ISSUERSETFEE_Length > 0 ? line1.Substring(ISSUERSETFEE_StartPosition - Incr, ISSUERSETFEE_Length).Trim() : string.Empty;
                            ISSURESETPROCFEE = ISSURESETPROCFEE_StartPosition > 0 && ISSURESETPROCFEE_Length > 0 ? line1.Substring(ISSURESETPROCFEE_StartPosition - Incr, ISSURESETPROCFEE_Length).Trim() : string.Empty;
                            CARDHOLDERBILLCURNCCODE = CARDHOLDERBILLCURNCCODE_StartPosition > 0 && CARDHOLDERBILLCURNCCODE_Length > 0 ? line1.Substring(CARDHOLDERBILLCURNCCODE_StartPosition - Incr, CARDHOLDERBILLCURNCCODE_Length).Trim() : string.Empty;
                            CARDHOLDERBILLAMOUNT = CARDHOLDERBILLAMOUNT_StartPosition > 0 && CARDHOLDERBILLAMOUNT_Length > 0 ? line1.Substring(CARDHOLDERBILLAMOUNT_StartPosition - Incr, CARDHOLDERBILLAMOUNT_Length).Trim() : string.Empty;
                            CARDHOLDERBILACTFEE = CARDHOLDERBILACTFEE_StartPosition > 0 && CARDHOLDERBILACTFEE_Length > 0 ? line1.Substring(CARDHOLDERBILACTFEE_StartPosition - Incr, CARDHOLDERBILACTFEE_Length).Trim() : string.Empty;
                            CARDHOLDERBILPROFEE = CARDHOLDERBILPROFEE_StartPosition > 0 && CARDHOLDERBILPROFEE_Length > 0 ? line1.Substring(CARDHOLDERBILPROFEE_StartPosition - Incr, CARDHOLDERBILPROFEE_Length).Trim() : string.Empty;

                            CARDHOLDERBILSRVICEFEE = CARDHOLDERBILSRVICEFEE_StartPosition > 0 && CARDHOLDERBILSRVICEFEE_Length > 0 ? line1.Substring(CARDHOLDERBILSRVICEFEE_StartPosition - Incr, CARDHOLDERBILSRVICEFEE_Length).Trim() : string.Empty;
                            TRAN_ISSUERCONVERSRATE = TRAN_ISSUERCONVERSRATE_StartPosition > 0 && TRAN_ISSUERCONVERSRATE_Length > 0 ? line1.Substring(TRAN_ISSUERCONVERSRATE_StartPosition - Incr, TRAN_ISSUERCONVERSRATE_Length).Trim() : string.Empty;
                            TRANS_CARDHOLDERCONVERRATE = TRANS_CARDHOLDERCONVERRATE_StartPosition > 0 && TRANS_CARDHOLDERCONVERRATE_Length > 0 ? line1.Substring(TRANS_CARDHOLDERCONVERRATE_StartPosition - Incr, TRANS_CARDHOLDERCONVERRATE_Length).Trim() : string.Empty;

                            TRANSTIME = TRANSTIME_StartPosition > 0 && TRANSTIME_Length > 0 ? line1.Substring(TRANSTIME_StartPosition - Incr, TRANSTIME_Length).Trim() : string.Empty;
                            TRANSDATE = TRANSDATE_StartPosition > 0 && TRANSDATE_Length > 0 ? line1.Substring(TRANSDATE_StartPosition - Incr, TRANSDATE_Length).Trim() : string.Empty;

                            CardType = string.Empty;
                            TxnsDateTimeMain = null;
                            CARDACCEPTERSETDATEMain = null;

                            #region ValidateField

                            Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                            ACCTUALTRANAMOUNT = Common.IsNumeric(ACCTUALTRANAMOUNT) ? ACCTUALTRANAMOUNT : "0";
                            TRANSACCVITYFEE = Common.IsNumeric(TRANSACCVITYFEE) ? TRANSACCVITYFEE : "0";
                            ISSURESETAMOUNT = Common.IsNumeric(ISSURESETAMOUNT) ? ISSURESETAMOUNT : "0";
                            ISSUERSETFEE = Common.IsNumeric(ISSUERSETFEE) ? ISSUERSETFEE : "0";
                            ISSURESETPROCFEE = Common.IsNumeric(ISSURESETPROCFEE) ? ISSURESETPROCFEE : "0";
                            CARDHOLDERBILLAMOUNT = Common.IsNumeric(CARDHOLDERBILLAMOUNT) ? CARDHOLDERBILLAMOUNT : "0";
                            CARDHOLDERBILACTFEE = Common.IsNumeric(CARDHOLDERBILACTFEE) ? CARDHOLDERBILACTFEE : "0";
                            CARDHOLDERBILPROFEE = Common.IsNumeric(CARDHOLDERBILPROFEE) ? CARDHOLDERBILPROFEE : "0";
                            CARDHOLDERBILSRVICEFEE = Common.IsNumeric(CARDHOLDERBILSRVICEFEE) ? CARDHOLDERBILSRVICEFEE : "0";
                            TRAN_ISSUERCONVERSRATE = Common.IsNumeric(TRAN_ISSUERCONVERSRATE) ? TRAN_ISSUERCONVERSRATE : "0";
                            TRANS_CARDHOLDERCONVERRATE = Common.IsNumeric(TRANS_CARDHOLDERCONVERRATE) ? TRANS_CARDHOLDERCONVERRATE : "0";

                            if (TxnsDateTime != "")
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                            }

                            if (TRANSDATE != "" && TRANSTIME != "")
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TRANSDATE + " " + TRANSTIME, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                            }

                            if (CARDACCEPTERSETDATE != "")
                            {
                                CARDACCEPTERSETDATEMain = DateTime.ParseExact(CARDACCEPTERSETDATE, "yyMMdd", CultureInfo.InvariantCulture);
                            } 

                            #endregion ValidateField 

                            if (CardNumber != "")
                            {
                                CardScheme = Common.GetCardType(CardNumber);
                                ECardNumber = AesEncryption.EncryptString(CardNumber);
                            }

                            if (CardNumber != "")
                            {
                                CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                            }

                            if (TxnsDateTimeMain != null)
                            {

                                _DataTable.Rows.Add(
                                            PARTICIPENTID
                                            , TRANSTYPE
                                            , FROMACCTYPE
                                            , TOACCTYPE
                                            , ReferenceNumber
                                            , RESPONSECODE
                                            , CardNumber.Trim()
                                            , CardType
                                            , MEMNUMBER
                                            , APPROVALNO
                                            , SYSTRACAUDITNO
                                            , TxnsDateTimeMain
                                            , TRANSTIME
                                            , MERCHANTCATCODE
                                            , CARDACCEPTERSETDATEMain
                                            , CARDACCID
                                            , TerminalId
                                            , CARDACCEPTERTERLOC
                                            , ACCIQUIERID
                                            , NETWORKID
                                            , ACCOUNTNO1
                                            , ACCOUNTBRANCHID
                                            , ACCOUNTNO2
                                            , ACCOUNT2BRANCHID
                                            , Transaction_Currency_Code
                                            , Transaction_Amount
                                            , ACCTUALTRANAMOUNT
                                            , TRANSACCVITYFEE.Trim()
                                            , ISSUERSETCURRENCYCODE.Trim()
                                            , ISSURESETAMOUNT.Trim()
                                            , ISSUERSETFEE.Trim()
                                            , ISSURESETPROCFEE.Trim()
                                            , CARDHOLDERBILLCURNCCODE.Trim()
                                            , CARDHOLDERBILLAMOUNT.Trim()
                                            , CARDHOLDERBILACTFEE.Trim()
                                            , CARDHOLDERBILPROFEE.Trim()
                                            , CARDHOLDERBILSRVICEFEE.Trim()
                                            , TRAN_ISSUERCONVERSRATE.Trim()
                                            , TRANS_CARDHOLDERCONVERRATE.Trim()
                                            , RevEntryLeg
                                            , Cycle
                                            , ECardNumber.Trim()
                                            , CardScheme
                                            , IssuingNetwork
                                            );

                                if (_DataTable.Rows.Count >= batchSize)
                                {
                                    BatchNo++;

                                    MSG = bulkImports.BulkInsertIssuerDataATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                    BatchDetails batchDetails = new BatchDetails
                                    {
                                        BatchNo = BatchNo,
                                        BatchSize = batchSize,
                                        TxnUploadCount = _DataTable.Rows.Count,
                                        TxnsCount = fileImportRequest.InsertCount,
                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                        FailedCount = ErrorCount,
                                        BatchStartTime = batchStartTime,
                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                    };

                                    batchDetailsList.Add(batchDetails);
                                    _DataTable.Clear();
                                    StartTime = DateTime.Now;
                                    ErrorCount = 0;
                                    if (NewEntry)
                                    {
                                        break;
                                    }
                                }

                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                        }

                    }

                    LineNo = 0;
                }
            }

            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkImports.BulkInsertIssuerDataATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = fileImportRequest.TotalCount,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);
            }
            else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
            {
                MSG = "Successful";
            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string Splitter_NPCI_Acquirer_ATM_Text_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int LineNumber = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int ErrorCount = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkImports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataSet ds = new DataSet();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FromAccountType", typeof(string));
            _DataTable.Columns.Add("ToAccountType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(DateTime));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            string RevEntryLeg = "1";

            int Incr = 1;
            string PARTICIPENTID = string.Empty;
            string TRANSTYPE = string.Empty;
            string FROMACCTYPE = string.Empty;
            string TOACCTYPE = string.Empty;
            string ReferenceNumber = string.Empty;
            string RESPONSECODE = string.Empty;
            string CardNumber = string.Empty;
            string MEMNUMBER = string.Empty;
            string APPROVALNO = string.Empty;
            string SYSTRACAUDITNO = string.Empty;
            string TxnsDateTime = string.Empty;
            string TRANSTIME = string.Empty;
            string TRANSDATE = string.Empty;
            string MERCHANTCATCODE = string.Empty;
            string CARDACCEPTERSETDATE = string.Empty;

            string CARDACCID = string.Empty;
            string TerminalId = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string ACCIQUIERID = string.Empty;

            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = "0";
            string ACCTUALTRANAMOUNT = "0";
            string TRANSACCVITYFEE = "0";
            string ACCURSETCURCODE = string.Empty;
            string ACQUIERSETAMOUNT = "0";
            string ACQUIERSETFEE = "0";
            string ACQUIERSETPROFEE = "0";
            string TRANSACQUIERCONVERRATE = "0";


            string ECardNumber = string.Empty;
            string line1 = string.Empty;
            string Cycle = string.Empty;
            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            string CardType = string.Empty;

            DateTime? TxnsDateTimeMain = null;
            DateTime? CARDACCEPTERSETDATEMain = null;


            ushort PARICIPATEID_StartPosition = 0;
            ushort PARICIPATEID_Length = 0;
            ushort TRANSACTIONTYPE_StartPosition = 0;
            ushort TRANSACTIONTYPE_Length = 0;
            ushort FromAccountType_StartPosition = 0;
            ushort FromAccountType_Length = 0;
            ushort ToAccountType_StartPosition = 0;
            ushort ToAccountType_Length = 0;
            ushort ReferenceNumber_StartPosition = 0;
            ushort ReferenceNumber_Length = 0;
            ushort ResponseCode_StartPosition = 0;
            ushort ResponseCode_Length = 0;
            ushort CardNumber_StartPosition = 0;
            ushort CardNumber_Length = 0;
            ushort MEMNUMBER_StartPosition = 0;
            ushort MEMNUMBER_Length = 0;
            ushort APPROVNO_StartPosition = 0;
            ushort APPROVNO_Length = 0;
            ushort SYSTRACAUDITNO_StartPosition = 0;
            ushort SYSTRACAUDITNO_Length = 0;
            ushort TxnsDateTime_StartPosition = 0;
            ushort TxnsDateTime_Length = 0;
            ushort TRANSTIME_StartPosition = 0;
            ushort TRANSTIME_Length = 0;
            ushort TRANSDATE_StartPosition = 0;
            ushort TRANSDATE_Length = 0;
            ushort MERCHENTCATCODE_StartPosition = 0;
            ushort MERCHENTCATCODE_Length = 0;
            ushort CARDACCEPTERSETDATE_StartPosition = 0;
            ushort CARDACCEPTERSETDATE_Length = 0;
            ushort CARDACCID_StartPosition = 0;
            ushort CARDACCID_Length = 0;
            ushort TerminalId_StartPosition = 0;
            ushort TerminalId_Length = 0;
            ushort CARDACCEPTERTERLOCATION_StartPosition = 0;
            ushort CARDACCEPTERTERLOCATION_Length = 0;
            ushort AcquirerID_StartPosition = 0;
            ushort AcquirerID_Length = 0;
            ushort TRANSCURRENCYCODE_StartPosition = 0;
            ushort TRANSCURRENCYCODE_Length = 0;
            ushort TxnsAmount_StartPosition = 0;
            ushort TxnsAmount_Length = 0;
            ushort ACCTUALTRANAMOUNT_StartPosition = 0;
            ushort ACCTUALTRANAMOUNT_Length = 0;
            ushort TRANSACCVITYFEE_StartPosition = 0;
            ushort TRANSACCVITYFEE_Length = 0;
            ushort ACCURSETCURCODE_StartPosition = 0;
            ushort ACCURSETCURCODE_Length = 0;
            ushort ACQUIERSETAMOUNT_StartPosition = 0;
            ushort ACQUIERSETAMOUNT_Length = 0;
            ushort ACQUIERSETFEE_StartPosition = 0;
            ushort ACQUIERSETFEE_Length = 0;
            ushort ACQUIERSETPROFEE_StartPosition = 0;
            ushort ACQUIERSETPROFEE_Length = 0;
            ushort TRANSACQUIERCONVERRATE_StartPosition = 0;
            ushort TRANSACQUIERCONVERRATE_Length = 0;

            string[] TxnDateTimeFormat = null;
            bool ErrorOccurred = false;

            try
            {

                int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                
                string[] FDA = fileImportRequest.FileName.Split('_');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;


                ds.ReadXml(new XmlTextReader(new System.IO.StringReader(xmlFile)));

                PARICIPATEID_StartPosition = Convert.ToUInt16(ds.Tables["PARTICIPENTID"].Rows[0]["StartPosition"]);
                PARICIPATEID_Length = Convert.ToUInt16(ds.Tables["PARTICIPENTID"].Rows[0]["Length"]);

                TRANSACTIONTYPE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACTIONTYPE"].Rows[0]["StartPosition"]);
                TRANSACTIONTYPE_Length = Convert.ToUInt16(ds.Tables["TRANSACTIONTYPE"].Rows[0]["Length"]);

                FromAccountType_StartPosition = Convert.ToUInt16(ds.Tables["FromAccountType"].Rows[0]["StartPosition"]);
                FromAccountType_Length = Convert.ToUInt16(ds.Tables["FromAccountType"].Rows[0]["Length"]);

                ToAccountType_StartPosition = Convert.ToUInt16(ds.Tables["ToAccountType"].Rows[0]["StartPosition"]);
                ToAccountType_Length = Convert.ToUInt16(ds.Tables["ToAccountType"].Rows[0]["Length"]);

                ReferenceNumber_StartPosition = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"]);
                ReferenceNumber_Length = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["Length"]);

                ResponseCode_StartPosition = Convert.ToUInt16(ds.Tables["ResponseCode"].Rows[0]["StartPosition"]);
                ResponseCode_Length = Convert.ToUInt16(ds.Tables["ResponseCode"].Rows[0]["Length"]);

                CardNumber_StartPosition = Convert.ToUInt16(ds.Tables["CardNumber"].Rows[0]["StartPosition"]);
                CardNumber_Length = Convert.ToUInt16(ds.Tables["CardNumber"].Rows[0]["Length"]);

                MEMNUMBER_StartPosition = Convert.ToUInt16(ds.Tables["MEMNUMBER"].Rows[0]["StartPosition"]);
                MEMNUMBER_Length = Convert.ToUInt16(ds.Tables["MEMNUMBER"].Rows[0]["Length"]);

                APPROVNO_StartPosition = Convert.ToUInt16(ds.Tables["APPROVALNO"].Rows[0]["StartPosition"]);
                APPROVNO_Length = Convert.ToUInt16(ds.Tables["APPROVALNO"].Rows[0]["Length"]);

                SYSTRACAUDITNO_StartPosition = Convert.ToUInt16(ds.Tables["SYSTRACAUDITNO"].Rows[0]["StartPosition"]);
                SYSTRACAUDITNO_Length = Convert.ToUInt16(ds.Tables["SYSTRACAUDITNO"].Rows[0]["Length"]);

                TxnsDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"]);
                TxnsDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["Length"]);

                TRANSTIME_StartPosition = Convert.ToUInt16(ds.Tables["TRANSTIME"].Rows[0]["StartPosition"]);
                TRANSTIME_Length = Convert.ToUInt16(ds.Tables["TRANSTIME"].Rows[0]["Length"]);

                TRANSDATE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSDATE"].Rows[0]["StartPosition"]);
                TRANSDATE_Length = Convert.ToUInt16(ds.Tables["TRANSDATE"].Rows[0]["Length"]);

                MERCHENTCATCODE_StartPosition = Convert.ToUInt16(ds.Tables["MERCHANTCATCODE"].Rows[0]["StartPosition"]);
                MERCHENTCATCODE_Length = Convert.ToUInt16(ds.Tables["MERCHANTCATCODE"].Rows[0]["Length"]);

                CARDACCEPTERSETDATE_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTERSETDATE"].Rows[0]["StartPosition"]);
                CARDACCEPTERSETDATE_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTERSETDATE"].Rows[0]["Length"]);

                CARDACCID_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCID"].Rows[0]["StartPosition"]);
                CARDACCID_Length = Convert.ToUInt16(ds.Tables["CARDACCID"].Rows[0]["Length"]);

                TerminalId_StartPosition = Convert.ToUInt16(ds.Tables["TerminalId"].Rows[0]["StartPosition"]);
                TerminalId_Length = Convert.ToUInt16(ds.Tables["TerminalId"].Rows[0]["Length"]);

                CARDACCEPTERTERLOCATION_StartPosition = Convert.ToUInt16(ds.Tables["CARDACCEPTERTERLOC"].Rows[0]["StartPosition"]);
                CARDACCEPTERTERLOCATION_Length = Convert.ToUInt16(ds.Tables["CARDACCEPTERTERLOC"].Rows[0]["Length"]);

                AcquirerID_StartPosition = Convert.ToUInt16(ds.Tables["ACCIQUIERID"].Rows[0]["StartPosition"]);
                AcquirerID_Length = Convert.ToUInt16(ds.Tables["ACCIQUIERID"].Rows[0]["Length"]);

                TRANSCURRENCYCODE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSCURCODE"].Rows[0]["StartPosition"]);
                TRANSCURRENCYCODE_Length = Convert.ToUInt16(ds.Tables["TRANSCURCODE"].Rows[0]["Length"]);

                TxnsAmount_StartPosition = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["StartPosition"]);
                TxnsAmount_Length = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["Length"]);

                ACCTUALTRANAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["ACCTUALTRANSAMOUNT"].Rows[0]["StartPosition"]);
                ACCTUALTRANAMOUNT_Length = Convert.ToUInt16(ds.Tables["ACCTUALTRANSAMOUNT"].Rows[0]["Length"]);

                TRANSACCVITYFEE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACTIVITYFEE"].Rows[0]["StartPosition"]);
                TRANSACCVITYFEE_Length = Convert.ToUInt16(ds.Tables["TRANSACTIVITYFEE"].Rows[0]["Length"]);

                ACCURSETCURCODE_StartPosition = Convert.ToUInt16(ds.Tables["ACCURSETCURCODE"].Rows[0]["StartPosition"]);
                ACCURSETCURCODE_Length = Convert.ToUInt16(ds.Tables["ACCURSETCURCODE"].Rows[0]["Length"]);

                ACQUIERSETAMOUNT_StartPosition = Convert.ToUInt16(ds.Tables["ACQUIERSETAMOUNT"].Rows[0]["StartPosition"]);
                ACQUIERSETAMOUNT_Length = Convert.ToUInt16(ds.Tables["ACQUIERSETAMOUNT"].Rows[0]["Length"]);

                ACQUIERSETFEE_StartPosition = Convert.ToUInt16(ds.Tables["ACQUIERSETFEE"].Rows[0]["StartPosition"]);
                ACQUIERSETFEE_Length = Convert.ToUInt16(ds.Tables["ACQUIERSETFEE"].Rows[0]["Length"]);

                ACQUIERSETPROFEE_StartPosition = Convert.ToUInt16(ds.Tables["ACQUIERSETPROFEE"].Rows[0]["StartPosition"]);
                ACQUIERSETPROFEE_Length = Convert.ToUInt16(ds.Tables["ACQUIERSETPROFEE"].Rows[0]["Length"]);

                TRANSACQUIERCONVERRATE_StartPosition = Convert.ToUInt16(ds.Tables["TRANSACQUIERCONVERRATE"].Rows[0]["StartPosition"]);
                TRANSACQUIERCONVERRATE_Length = Convert.ToUInt16(ds.Tables["TRANSACQUIERCONVERRATE"].Rows[0]["Length"]);

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
                fileImportRequest.TotalCount = TotalCountArray.Length;

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                //Get Batch Size
                batchSize = bulkImports.GetBatchSize(DTdetails.ConfigID);

                foreach (var batchDetail in fileImportRequest.FailedBatches)
                {
                    if (batchDetail.BatchNo != 0)
                    {
                        BatchNo = batchDetail.BatchNo - 1;
                    }


                    bool NewEntry = false;

                    if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                    {
                        //set the flag if it is new Entry
                        NewEntry = false;
                    }
                    else
                    {
                        if (batchDetail.BatchStatus == "None")
                        {
                            break;
                        }
                        else
                        {
                            //set the flag if it is old and  Partial Entry
                            NewEntry = true;
                        }
                    }

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        LineNo++;
                        LineNumber++;
                        if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                        {
                            continue;
                        }

                        try
                        {
                            line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                            //string[] dtSheet.Rows[k] = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                            Incr = 1;
                            PARTICIPENTID = string.Empty;
                            TRANSTYPE = string.Empty;
                            FROMACCTYPE = string.Empty;
                            TOACCTYPE = string.Empty;
                            ReferenceNumber = string.Empty;
                            RESPONSECODE = string.Empty;
                            CardNumber = string.Empty;
                            MEMNUMBER = string.Empty;
                            APPROVALNO = string.Empty;
                            SYSTRACAUDITNO = string.Empty;
                            TxnsDateTime = string.Empty;
                            TRANSTIME = string.Empty;
                            TRANSDATE = string.Empty;
                            MERCHANTCATCODE = string.Empty;
                            CARDACCEPTERSETDATE = string.Empty;

                            CARDACCID = string.Empty;
                            TerminalId = string.Empty;
                            CARDACCEPTERTERLOC = string.Empty;
                            ACCIQUIERID = string.Empty;
                            Transaction_Amount = "0";
                            ACCTUALTRANAMOUNT = "0";
                            TRANSACCVITYFEE = "0";
                            ACCURSETCURCODE = string.Empty;
                            ACQUIERSETAMOUNT = "0";
                            ACQUIERSETFEE = "0";
                            ACQUIERSETPROFEE = "0";
                            TRANSACQUIERCONVERRATE = "0";
                            ECardNumber = string.Empty;
                            CardScheme = string.Empty;

                            PARTICIPENTID = PARICIPATEID_StartPosition > 0 && PARICIPATEID_Length > 0 ? line1.Substring(PARICIPATEID_StartPosition - Incr, PARICIPATEID_Length).Trim() : string.Empty;

                            TRANSTYPE = TRANSACTIONTYPE_StartPosition > 0 && TRANSACTIONTYPE_Length > 0 ? line1.Substring(TRANSACTIONTYPE_StartPosition - Incr, TRANSACTIONTYPE_Length).Trim() : string.Empty;
                            FROMACCTYPE = FromAccountType_StartPosition > 0 && FromAccountType_Length > 0 ? line1.Substring(FromAccountType_StartPosition - Incr, FromAccountType_Length).Trim() : string.Empty;
                            TOACCTYPE = ToAccountType_StartPosition > 0 && ToAccountType_Length > 0 ? line1.Substring(ToAccountType_StartPosition - Incr, ToAccountType_Length).Trim() : string.Empty;
                            ReferenceNumber = ReferenceNumber_StartPosition > 0 && ReferenceNumber_Length > 0 ? line1.Substring(ReferenceNumber_StartPosition - Incr, ReferenceNumber_Length).Trim() : string.Empty;
                            RESPONSECODE = ResponseCode_StartPosition > 0 && ResponseCode_Length > 0 ? line1.Substring(ResponseCode_StartPosition - Incr, ResponseCode_Length).Trim() : string.Empty;
                            CardNumber = CardNumber_StartPosition > 0 && CardNumber_Length > 0 ? line1.Substring(CardNumber_StartPosition - Incr, CardNumber_Length).Trim() : string.Empty;
                            MEMNUMBER = MEMNUMBER_StartPosition > 0 && MEMNUMBER_Length > 0 ? line1.Substring(MEMNUMBER_StartPosition - Incr, MEMNUMBER_Length).Trim() : string.Empty;
                            APPROVALNO = APPROVNO_StartPosition > 0 && APPROVNO_Length > 0 ? line1.Substring(APPROVNO_StartPosition - Incr, APPROVNO_Length).Trim() : string.Empty;
                            SYSTRACAUDITNO = SYSTRACAUDITNO_StartPosition > 0 && SYSTRACAUDITNO_Length > 0 ? line1.Substring(SYSTRACAUDITNO_StartPosition - Incr, SYSTRACAUDITNO_Length).Trim() : string.Empty;
                            TxnsDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length).Trim() : string.Empty;
                            MERCHANTCATCODE = MERCHENTCATCODE_StartPosition > 0 && MERCHENTCATCODE_Length > 0 ? line1.Substring(MERCHENTCATCODE_StartPosition - Incr, MERCHENTCATCODE_Length).Trim() : string.Empty;
                            CARDACCID = CARDACCID_StartPosition > 0 && CARDACCID_Length > 0 ? line1.Substring(CARDACCID_StartPosition - Incr, CARDACCID_Length).Trim() : string.Empty;

                            TerminalId = TerminalId_StartPosition > 0 && TerminalId_Length > 0 ? line1.Substring(TerminalId_StartPosition - Incr, TerminalId_Length).Trim() : string.Empty;
                            CARDACCEPTERTERLOC = CARDACCEPTERTERLOCATION_StartPosition > 0 && CARDACCEPTERTERLOCATION_Length > 0 ? line1.Substring(CARDACCEPTERTERLOCATION_StartPosition - Incr, CARDACCEPTERTERLOCATION_Length).Trim() : string.Empty;
                            ACCIQUIERID = AcquirerID_StartPosition > 0 && AcquirerID_Length > 0 ? line1.Substring(AcquirerID_StartPosition - Incr, AcquirerID_Length).Trim() : string.Empty;

                            Transaction_Currency_Code = TRANSCURRENCYCODE_StartPosition > 0 && TRANSCURRENCYCODE_Length > 0 ? line1.Substring(TRANSCURRENCYCODE_StartPosition - Incr, TRANSCURRENCYCODE_Length).Trim() : string.Empty;
                            Transaction_Amount = TxnsAmount_StartPosition > 0 && TxnsAmount_Length > 0 ? line1.Substring(TxnsAmount_StartPosition - Incr, TxnsAmount_Length).Trim() : string.Empty;
                            ACCTUALTRANAMOUNT = ACCTUALTRANAMOUNT_StartPosition > 0 && ACCTUALTRANAMOUNT_Length > 0 ? line1.Substring(ACCTUALTRANAMOUNT_StartPosition - Incr, ACCTUALTRANAMOUNT_Length).Trim() : string.Empty;


                            TRANSACCVITYFEE = TRANSACCVITYFEE_StartPosition > 0 && TRANSACCVITYFEE_Length > 0 ? line1.Substring(TRANSACCVITYFEE_StartPosition - Incr, TRANSACCVITYFEE_Length).Trim() : string.Empty;
                            ACCURSETCURCODE = ACCURSETCURCODE_StartPosition > 0 && ACCURSETCURCODE_Length > 0 ? line1.Substring(ACCURSETCURCODE_StartPosition - Incr, ACCURSETCURCODE_Length).Trim() : string.Empty;
                            ACQUIERSETAMOUNT = ACQUIERSETAMOUNT_StartPosition > 0 && ACQUIERSETAMOUNT_Length > 0 ? line1.Substring(ACQUIERSETAMOUNT_StartPosition - Incr, ACQUIERSETAMOUNT_Length).Trim() : string.Empty;
                            ACQUIERSETFEE = ACQUIERSETFEE_StartPosition > 0 && ACQUIERSETFEE_Length > 0 ? line1.Substring(ACQUIERSETFEE_StartPosition - Incr, ACQUIERSETFEE_Length).Trim() : string.Empty;
                            ACQUIERSETPROFEE = ACQUIERSETPROFEE_StartPosition > 0 && ACQUIERSETPROFEE_Length > 0 ? line1.Substring(ACQUIERSETPROFEE_StartPosition - Incr, ACQUIERSETPROFEE_Length).Trim() : string.Empty;
                            TRANSACQUIERCONVERRATE = TRANSACQUIERCONVERRATE_StartPosition > 0 && TRANSACQUIERCONVERRATE_Length > 0 ? line1.Substring(TRANSACQUIERCONVERRATE_StartPosition - Incr, TRANSACQUIERCONVERRATE_Length).Trim() : string.Empty;

                            TRANSTIME = TRANSTIME_StartPosition > 0 && TRANSTIME_Length > 0 ? line1.Substring(TRANSTIME_StartPosition - Incr, TRANSTIME_Length).Trim() : string.Empty;
                            TRANSDATE = TRANSDATE_StartPosition > 0 && TRANSDATE_Length > 0 ? line1.Substring(TRANSDATE_StartPosition - Incr, TRANSDATE_Length).Trim() : string.Empty;

                            CardType = string.Empty;
                            TxnsDateTimeMain = null;
                            CARDACCEPTERSETDATEMain = null;

                          

                            Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                            ACCTUALTRANAMOUNT = Common.IsNumeric(ACCTUALTRANAMOUNT) ? ACCTUALTRANAMOUNT : "0";
                            TRANSACCVITYFEE = Common.IsNumeric(TRANSACCVITYFEE) ? TRANSACCVITYFEE : "0";
                            ACQUIERSETAMOUNT = Common.IsNumeric(ACQUIERSETAMOUNT) ? ACQUIERSETAMOUNT : "0";
                            ACQUIERSETFEE = Common.IsNumeric(ACQUIERSETFEE) ? ACQUIERSETFEE : "0";
                            ACQUIERSETPROFEE = Common.IsNumeric(ACQUIERSETPROFEE) ? ACQUIERSETPROFEE : "0";
                            TRANSACQUIERCONVERRATE = Common.IsNumeric(TRANSACQUIERCONVERRATE) ? TRANSACQUIERCONVERRATE : "0";

                            if (TxnsDateTime != "")
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                            }

                            if (TRANSDATE != "" && TRANSTIME != "")
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TRANSDATE + " " + TRANSTIME, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                            }

                            if (CARDACCEPTERSETDATE != "")
                            {
                                CARDACCEPTERSETDATEMain = DateTime.ParseExact(CARDACCEPTERSETDATE, "yyMMdd", CultureInfo.InvariantCulture);
                            } 

                            if (CardNumber != "")
                            {
                                CardScheme = Common.GetCardType(CardNumber);

                                ECardNumber = AesEncryption.EncryptString(CardNumber);
                            }

                            if (CardNumber != "")
                            {
                                CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                            }

                            if (TxnsDateTimeMain != null)
                            {
                                _DataTable.Rows.Add(
                                            PARTICIPENTID
                                            , TRANSTYPE
                                            , FROMACCTYPE
                                            , TOACCTYPE
                                            , ReferenceNumber
                                            , RESPONSECODE
                                            , CardNumber.Trim()
                                            , CardType
                                            , MEMNUMBER
                                            , APPROVALNO
                                            , SYSTRACAUDITNO
                                            , TxnsDateTimeMain
                                            , TRANSTIME
                                            , MERCHANTCATCODE
                                            , CARDACCEPTERSETDATEMain
                                            , CARDACCID
                                            , TerminalId
                                            , CARDACCEPTERTERLOC
                                            , ACCIQUIERID
                                            , Transaction_Currency_Code
                                            , Transaction_Amount
                                            , ACCTUALTRANAMOUNT
                                            , TRANSACCVITYFEE.Trim()
                                            , ACCURSETCURCODE.Trim()
                                            , ACQUIERSETAMOUNT.Trim()
                                            , ACQUIERSETFEE.Trim()
                                            , ACQUIERSETPROFEE.Trim()
                                            , TRANSACQUIERCONVERRATE.Trim()
                                            , RevEntryLeg
                                            , Cycle
                                            , ECardNumber.Trim()
                                            , CardScheme
                                            , IssuingNetwork
                                            );

                                if (_DataTable.Rows.Count >= batchSize)
                                {
                                    BatchNo++;

                                    MSG = bulkImports.BulkInsertAcquirerDataATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                    // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                                    BatchDetails batchDetails = new BatchDetails
                                    {
                                        BatchNo = BatchNo,
                                        BatchSize = batchSize,
                                        TxnUploadCount = _DataTable.Rows.Count,
                                        TxnsCount = fileImportRequest.InsertCount,
                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                        FailedCount = ErrorCount,
                                        BatchStartTime = batchStartTime,
                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                    };

                                    batchDetailsList.Add(batchDetails);
                                    _DataTable.Clear();
                                    StartTime = DateTime.Now;
                                    ErrorCount = 0;
                                    if (NewEntry)
                                    {
                                        break;
                                    }
                                }

                            }

                        }
                        catch (Exception ex)
                        {
                            //objLogWriter.FunErrorLog(ex.Message.ToString(), fileImportRequest.ClientCode, "NPCIATM.cs", "SplitData", LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E');
                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                            ErrorCount++;
                        }

                    }

                    LineNo = 0;
                }


            }

            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkImports.BulkInsertAcquirerDataATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                //  _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                //_logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
            {
                MSG = "Successful";
            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string Splitter_NPCI_Acquirer_ATM_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int LineNumber = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int ErrorCount = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkImports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataSet ds = new DataSet();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FromAccountType", typeof(string));
            _DataTable.Columns.Add("ToAccountType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(DateTime));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            string RevEntryLeg = "1";

            int Incr = 1;
            string PARTICIPENTID = string.Empty;
            string TRANSTYPE = string.Empty;
            string FROMACCTYPE = string.Empty;
            string TOACCTYPE = string.Empty;
            string ReferenceNumber = string.Empty;
            string RESPONSECODE = string.Empty;
            string CardNumber = string.Empty;
            string MEMNUMBER = string.Empty;
            string APPROVALNO = string.Empty;
            string SYSTRACAUDITNO = string.Empty;
            string TxnsDateTime = string.Empty;
            string TRANSTIME = string.Empty;
            string TRANSDATE = string.Empty;
            string MERCHANTCATCODE = string.Empty;
            string CARDACCEPTERSETDATE = string.Empty;

            string CARDACCID = string.Empty;
            string TerminalId = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string ACCIQUIERID = string.Empty;

            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = "0";
            string ACCTUALTRANAMOUNT = "0";
            string TRANSACCVITYFEE = "0";
            string ACCURSETCURCODE = string.Empty;
            string ACQUIERSETAMOUNT = "0";
            string ACQUIERSETFEE = "0";
            string ACQUIERSETPROFEE = "0";
            string TRANSACQUIERCONVERRATE = "0";


            string ECardNumber = string.Empty;
            string line1 = string.Empty;
            string Cycle = string.Empty;
            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            string CardType = string.Empty;

            DateTime? TxnsDateTimeMain = null;
            DateTime? CARDACCEPTERSETDATEMain = null;

            ushort PARICIPATEID_CoulmnIndex = 0;
            ushort TRANSACTIONTYPE_CoulmnIndex = 0;
            ushort FromAccountType_CoulmnIndex = 0;
            ushort ToAccountType_CoulmnIndex = 0;
            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort ResponseCode_CoulmnIndex = 0;
            ushort CardNumber_CoulmnIndex = 0;
            ushort MEMNUMBER_CoulmnIndex = 0;
            ushort APPROVNO_CoulmnIndex = 0;
            ushort STAUDITNO_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;
            ushort TRANSDATE_CoulmnIndex = 0;
            ushort MERCHENTCATCODE_CoulmnIndex = 0;
            ushort CARDACCEPTSETDATE_CoulmnIndex = 0;
            ushort CARDACCID_CoulmnIndex = 0;
            ushort TerminalId_CoulmnIndex = 0;
            ushort CARDACCEPTERTERLOCATION_CoulmnIndex = 0;
            ushort AcquirerID_CoulmnIndex = 0;
            //ushort NETWORKID_CoulmnIndex = 0;
            //ushort ACCOUNTNO1_CoulmnIndex = 0;
            //ushort ACCOUNTBRANCHID_CoulmnIndex = 0;
            //ushort ACCOUNTNO2_CoulmnIndex = 0;
            //ushort ACCOUNT2BRANCHID_CoulmnIndex = 0;
            ushort TRANSCURRENCYCODE_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort ACCTUALTRANAMOUNT_CoulmnIndex = 0;
            ushort TRANSACCVITYFEE_CoulmnIndex = 0;
            ushort ACCURSETCURCODE_CoulmnIndex = 0;
            ushort ACQUIERSETAMOUNT_CoulmnIndex = 0;
            ushort ACQUIERSETFEE_CoulmnIndex = 0;  
            ushort TRANSACQUIERCONVERRATE_CoulmnIndex = 0;
            ushort ACQUIERSETPROFEE_CoulmnIndex = 0;


            string[] SplitArr = null;
            string[] TxnDateTimeFormat = null;
            bool ErrorOccurred = false;
            int largestIndex = 0, CoulmnIndex = 0;

            try
            {

                int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();


                string[] FDA = fileImportRequest.FileName.Split('_');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;


                ds.ReadXml(new XmlTextReader(new System.IO.StringReader(xmlFile)));

                AcquirerID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCIQUIERID"]);
                PARICIPATEID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PARTICIPENTID"]);
                TRANSACTIONTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONTYPE"]); ;
                FromAccountType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccountType"]);
                ToAccountType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccountType"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                ResponseCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode"]);
                CardNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CardNumber"]);
                MEMNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MEMNUMBER"]);
                APPROVNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["APPROVALNO"]);
                STAUDITNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SYSTRACAUDITNO"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTIME"]);
                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSDATE"]);
                MERCHENTCATCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MERCHANTCATCODE"]);
                CARDACCEPTSETDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERSETDATE"]);
                CARDACCID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCID"]);
                TerminalId_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TerminalId"]);
                CARDACCEPTERTERLOCATION_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERTERLOC"]);
                
                //NETWORKID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NETWORKID"]);
                //ACCOUNTNO1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTNO1"]);
                //ACCOUNTBRANCHID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTBRANCHID"]);
                //ACCOUNTNO2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTNO2"]);
                //ACCOUNT2BRANCHID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNT2BRANCHID"]);
                TRANSCURRENCYCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSCURCODE"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                ACCTUALTRANAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANSAMOUNT"]);
                TRANSACCVITYFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIVITYFEE"]);
                ACCURSETCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCURSETCURCODE"]);
                ACQUIERSETAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETAMOUNT"]);
                ACQUIERSETFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETFEE"]);
                ACQUIERSETPROFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETPROFEE"]); 
                TRANSACQUIERCONVERRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACQUIERCONVERRATE"]);

                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);                 
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;
                //Get Batch Size
                batchSize = bulkImports.GetBatchSize(DTdetails.ConfigID);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            SplitArr = new string[0];

                            SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            if (TxnsDateTime_CoulmnIndex > 0)
                            {
                                tempTxnDateTime = TxnsDateTime_CoulmnIndex > 0 ? SplitArr[TxnsDateTime_CoulmnIndex - Incr].Trim() : string.Empty;
                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                }
                            }
                            else if (TRANSDATE_CoulmnIndex > 0 && TRANSTIME_CoulmnIndex > 0)
                            {
                                TRANSDATE = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                TRANSTIME = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;
                                tempTxnDateTime = TRANSDATE + " " + TRANSTIME;
                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;

                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }


                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                if (LineNo < dateStartIndex)
                                {
                                    LineNumber++;
                                    LineNo++;
                                    continue;
                                }                               

                                try
                                {
                                    LineNo++; 

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    line1 = Regex.Replace(line, "[^ -~]+", string.Empty);
                                    SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                    if (SplitArr.Length < largestIndex) continue;

                                    LineNumber++;

                                    Incr = 1;
                                    PARTICIPENTID = string.Empty;
                                    TRANSTYPE = string.Empty;
                                    FROMACCTYPE = string.Empty;
                                    TOACCTYPE = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    RESPONSECODE = string.Empty;
                                    CardNumber = string.Empty;
                                    MEMNUMBER = string.Empty;
                                    APPROVALNO = string.Empty;
                                    SYSTRACAUDITNO = string.Empty;
                                    TxnsDateTime = string.Empty;
                                    TRANSTIME = string.Empty;
                                    TRANSDATE = string.Empty;
                                    MERCHANTCATCODE = string.Empty;
                                    CARDACCEPTERSETDATE = string.Empty;

                                    CARDACCID = string.Empty;
                                    TerminalId = string.Empty;
                                    CARDACCEPTERTERLOC = string.Empty;
                                    ACCIQUIERID = string.Empty;
                                    Transaction_Amount = "0";
                                    ACCTUALTRANAMOUNT = "0";
                                    TRANSACCVITYFEE = "0";
                                    ACCURSETCURCODE = string.Empty;
                                    ACQUIERSETAMOUNT = "0";
                                    ACQUIERSETFEE = "0";
                                    ACQUIERSETPROFEE = "0";
                                    TRANSACQUIERCONVERRATE = "0";
                                    ECardNumber = string.Empty;
                                    CardScheme = string.Empty;

                                    PARTICIPENTID = PARICIPATEID_CoulmnIndex > 0 ? SplitArr[PARICIPATEID_CoulmnIndex - Incr].Trim() : string.Empty;

                                    TRANSTYPE = TRANSACTIONTYPE_CoulmnIndex > 0 ? SplitArr[TRANSACTIONTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    FROMACCTYPE = FromAccountType_CoulmnIndex > 0 ? SplitArr[FromAccountType_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TOACCTYPE = ToAccountType_CoulmnIndex > 0 ? SplitArr[ToAccountType_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? SplitArr[ReferenceNumber_CoulmnIndex - Incr].Trim() : string.Empty;
                                    RESPONSECODE = ResponseCode_CoulmnIndex > 0 ? SplitArr[ResponseCode_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CardNumber = CardNumber_CoulmnIndex > 0 ? SplitArr[CardNumber_CoulmnIndex - Incr].Trim() : string.Empty;
                                    MEMNUMBER = MEMNUMBER_CoulmnIndex > 0 ? SplitArr[MEMNUMBER_CoulmnIndex - Incr].Trim() : string.Empty;
                                    APPROVALNO = APPROVNO_CoulmnIndex > 0 ? SplitArr[APPROVNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    SYSTRACAUDITNO = STAUDITNO_CoulmnIndex > 0 ? SplitArr[STAUDITNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? SplitArr[TxnsDateTime_CoulmnIndex - Incr].Trim() : string.Empty;
                                    MERCHANTCATCODE = MERCHENTCATCODE_CoulmnIndex > 0 ? SplitArr[MERCHENTCATCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDACCID = CARDACCID_CoulmnIndex > 0 ? SplitArr[CARDACCID_CoulmnIndex - Incr].Trim() : string.Empty;

                                    TerminalId = TerminalId_CoulmnIndex > 0 ? SplitArr[TerminalId_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDACCEPTERTERLOC = CARDACCEPTERTERLOCATION_CoulmnIndex > 0 ? SplitArr[CARDACCEPTERTERLOCATION_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCIQUIERID = AcquirerID_CoulmnIndex > 0 ? SplitArr[AcquirerID_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Transaction_Currency_Code = TRANSCURRENCYCODE_CoulmnIndex > 0 ? SplitArr[TRANSCURRENCYCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Amount = TxnsAmount_CoulmnIndex > 0 ? SplitArr[TxnsAmount_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCTUALTRANAMOUNT = ACCTUALTRANAMOUNT_CoulmnIndex > 0 ? SplitArr[ACCTUALTRANAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;


                                    TRANSACCVITYFEE = TRANSACCVITYFEE_CoulmnIndex > 0 ? SplitArr[TRANSACCVITYFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCURSETCURCODE = ACCURSETCURCODE_CoulmnIndex > 0 ? SplitArr[ACCURSETCURCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACQUIERSETAMOUNT = ACQUIERSETAMOUNT_CoulmnIndex > 0 ? SplitArr[ACQUIERSETAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACQUIERSETFEE = ACQUIERSETPROFEE_CoulmnIndex > 0 ? SplitArr[ACQUIERSETPROFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACQUIERSETPROFEE = ACQUIERSETPROFEE_CoulmnIndex > 0 ? SplitArr[ACQUIERSETPROFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TRANSACQUIERCONVERRATE = TRANSACQUIERCONVERRATE_CoulmnIndex > 0 ? SplitArr[TRANSACQUIERCONVERRATE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    TRANSTIME = TRANSTIME_CoulmnIndex > 0 ? SplitArr[TRANSTIME_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TRANSDATE = TRANSDATE_CoulmnIndex > 0 ? SplitArr[TRANSDATE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    CardType = string.Empty;
                                    TxnsDateTimeMain = null;
                                    CARDACCEPTERSETDATEMain = null;

                                    Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                                    ACCTUALTRANAMOUNT = Common.IsNumeric(ACCTUALTRANAMOUNT) ? ACCTUALTRANAMOUNT : "0";
                                    TRANSACCVITYFEE = Common.IsNumeric(TRANSACCVITYFEE) ? TRANSACCVITYFEE : "0";
                                    ACQUIERSETAMOUNT = Common.IsNumeric(ACQUIERSETAMOUNT) ? ACQUIERSETAMOUNT : "0";
                                    ACQUIERSETFEE = Common.IsNumeric(ACQUIERSETFEE) ? ACQUIERSETFEE : "0";
                                    ACQUIERSETPROFEE = Common.IsNumeric(ACQUIERSETPROFEE) ? ACQUIERSETPROFEE : "0";
                                    TRANSACQUIERCONVERRATE = Common.IsNumeric(TRANSACQUIERCONVERRATE) ? TRANSACQUIERCONVERRATE : "0";

                                    TxnsDateTime = TxnsDateTime.Replace("'", "");

                                    if (TxnsDateTime != "")
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TRANSDATE != "" && TRANSTIME != "")
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TRANSDATE + " " + TRANSTIME, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (CARDACCEPTERSETDATE != "")
                                    {
                                        CARDACCEPTERSETDATEMain = DateTime.ParseExact(CARDACCEPTERSETDATE, "yyMMdd", CultureInfo.InvariantCulture);
                                    }

                                    if (CardNumber != "")
                                    {
                                        CardScheme = Common.GetCardType(CardNumber);

                                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                                    }

                                    if (CardNumber != "")
                                    {
                                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                                    }

                                    if (TxnsDateTimeMain != null)
                                    {
                                        _DataTable.Rows.Add(
                                                    PARTICIPENTID
                                                    , TRANSTYPE
                                                    , FROMACCTYPE
                                                    , TOACCTYPE
                                                    , ReferenceNumber
                                                    , RESPONSECODE
                                                    , CardNumber.Trim()
                                                    , CardType
                                                    , MEMNUMBER
                                                    , APPROVALNO
                                                    , SYSTRACAUDITNO
                                                    , TxnsDateTimeMain
                                                    , TRANSTIME
                                                    , MERCHANTCATCODE
                                                    , CARDACCEPTERSETDATEMain
                                                    , CARDACCID
                                                    , TerminalId
                                                    , CARDACCEPTERTERLOC
                                                    , ACCIQUIERID
                                                    , Transaction_Currency_Code
                                                    , Transaction_Amount
                                                    , ACCTUALTRANAMOUNT
                                                    , TRANSACCVITYFEE.Trim()
                                                    , ACCURSETCURCODE.Trim()
                                                    , ACQUIERSETAMOUNT.Trim()
                                                    , ACQUIERSETFEE.Trim()
                                                    , ACQUIERSETPROFEE.Trim()
                                                    , TRANSACQUIERCONVERRATE.Trim()
                                                    , RevEntryLeg
                                                    , Cycle
                                                    , ECardNumber.Trim()
                                                    , CardScheme
                                                    , IssuingNetwork
                                                    );

                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;

                                            MSG = bulkImports.BulkInsertAcquirerDataATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                            // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);
                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }

                                    }

                                }
                                catch (Exception ex)
                                {
                                    //objLogWriter.FunErrorLog(ex.Message.ToString(), fileImportRequest.ClientCode, "NPCIATM.cs", "SplitData", LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E');
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    ErrorCount++;
                                }

                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkImports.BulkInsertAcquirerDataATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        if (tempTxnDateTime.Length > 0)
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        }
                        else
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + " File is Empty OR DateTime Format not matched;  ";
                        }
                        MSG = fileImportRequest.ErrorMessage;
                    }

                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }
            }          

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = _DataTable.Rows.Count,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }
        public string Splitter_NPCI_Settlement_ATM_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            string TempRemark = string.Empty;
            int LineNo = 0, ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int SheetLineNumber = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkImports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("NoTxns", typeof(int));
            _DataTable.Columns.Add("Debit", typeof(decimal));
            _DataTable.Columns.Add("Credit", typeof(decimal));
            _DataTable.Columns.Add("Bank", typeof(string));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));

            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

            string[] TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
            string FileDateFormat = fileImportRequest.ConfigData.Rows[0]["FileDateFormat"].ToString();

            DateTime? TxnsDateTimeMain = null;

            string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

            string[] FDA = Path.GetFileNameWithoutExtension(fileImportRequest.FileName).Split('_');
            string Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

            DataSet ds = new DataSet();
            DataTable allSheets = new DataTable();
            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            try
            {

                conString = string.Format(conString, fileImportRequest.Path);

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                ushort Description_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Description"]);
                ushort NoTxns_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NoTxns"]);
                ushort Debit_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Debit"]);
                ushort Credit_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Credit"]);
                ushort Remarks_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remarks"]);
                ushort Date_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Date"]);

                DataTable dtexcelsheetname = new DataTable();
                DataTable dtSheet = new DataTable();

                if (conString.Contains("HTML Import"))
                {
                    using (OleDbConnection connExcel = new OleDbConnection(conString))
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            connExcel.Open();
                            //Get the name of First Sheet. 
                            dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            connExcel.Close();
                        }
                    }
                }
                else
                {

                    using (OleDbConnection connExcel = new OleDbConnection(conString))
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            connExcel.Open();
                            //Get the name of First Sheet. 
                            allSheets = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            connExcel.Close();
                        }
                    }

                    // Filter only visible sheets that end with '$' and do not include hidden/system ranges
                    var validSheetRows = allSheets
                        .AsEnumerable()
                        .Where(row =>
                        {
                            string sheetName = row["TABLE_NAME"].ToString();
                            return sheetName.EndsWith("$") &&
                                   !sheetName.Contains("xlnm") && // Exclude _xlnm# named ranges
                                   !sheetName.StartsWith("_");    // Exclude hidden/internal
                        });

                    if (validSheetRows.Any())
                    {
                        dtexcelsheetname = validSheetRows.CopyToDataTable();
                    }
                    else
                    {
                        throw new Exception("No valid worksheet found in Excel file.");
                    }

                }


                batchSize = bulkImports.GetBatchSize(DTdetails.ConfigID);

                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {


                    int j = 0;


                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }


                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            dtSheet = new DataTable();

                            string Getdatafromsheet1 = "SELECT * FROM [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]";

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = Getdatafromsheet1;
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            int Incr = 1;
                            string Description = string.Empty;
                            string NoTxnsValue = "0";
                            string DebitValue = "0";
                            string CreditValue = "0";
                            string Remarks = string.Empty;
                            string TxnsDate = string.Empty;
                            string BankName = ClientID.ToString();
                            int start, end;

                            if (dtSheet.Rows.Count > 1)
                            {
                                // Find first data row based on whether the "Join Date" cell can be parsed as a date

                                fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                for (int k = 0; k < dtSheet.Rows.Count; k++)
                                {
                                    LineNo++;
                                    SheetLineNumber++;
                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    Incr = 1;
                                    Description = string.Empty;
                                    NoTxnsValue = "0";
                                    DebitValue = "0";
                                    CreditValue = "0";
                                    Remarks = string.Empty;
                                    TxnsDate = string.Empty;
                                    TxnsDateTimeMain = null;

                                    try
                                    {

                                        Description = Description_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Description_CoulmnIndex - Incr]).Trim() : string.Empty;

                                        if (Description.Contains("Daily Settlement Statement for"))
                                        {
                                            TempRemark = Description;

                                            start = TempRemark.IndexOf("for ") + 4;
                                            end = TempRemark.IndexOf("as on");

                                            if (end > start)
                                            {
                                                BankName = TempRemark.Substring(start, end - start).Trim();
                                                BankName = BankName.Substring(0, BankName.Length > 100 ? 100 : BankName.Length);
                                            }
                                        }

                                        NoTxnsValue = NoTxns_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][NoTxns_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        DebitValue = Debit_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Debit_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        CreditValue = Credit_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Credit_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Remarks = Remarks_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Remarks_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsDate = Date_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Date_CoulmnIndex - Incr]).Trim() : string.Empty;

                                        if (TxnsDate.Length > 0)
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDate, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                        }
                                        else
                                        {
                                            TxnsDateTimeMain = fileImportRequest.FileDateTime;
                                        }

                                        NoTxnsValue = Common.IsNumeric(NoTxnsValue) ? NoTxnsValue : "0";
                                        DebitValue = Common.IsNumeric(DebitValue) ? DebitValue : "0";
                                        CreditValue = Common.IsNumeric(CreditValue) ? CreditValue : "0";

                                        Decimal Debit = Decimal.Parse(DebitValue, System.Globalization.NumberStyles.Float);
                                        Decimal Credit = Decimal.Parse(CreditValue, System.Globalization.NumberStyles.Float);


                                        if (Description != "" && (Debit > 0 || Credit > 0) && TxnsDateTimeMain != null)
                                        {

                                            _DataTable.Rows.Add(
                                                TxnsDateTimeMain
                                                , Cycle
                                                , Convert.ToDecimal(NoTxnsValue)
                                                , Debit
                                                , Credit
                                                , BankName
                                                , Description
                                                , Remarks
                                                );

                                            if (_DataTable.Rows.Count >= batchSize)
                                            {
                                                BatchNo++;
                                                MSG = bulkImports.BulkInsertSettlementDataATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                BatchDetails batchDetails = new BatchDetails
                                                {
                                                    BatchNo = BatchNo,
                                                    BatchSize = batchSize,
                                                    TxnUploadCount = _DataTable.Rows.Count,
                                                    TxnsCount = fileImportRequest.InsertCount,
                                                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                    FailedCount = ErrorCount,
                                                    BatchStartTime = batchStartTime,
                                                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                };

                                                batchDetailsList.Add(batchDetails);
                                                _DataTable.Clear();
                                                ErrorCount = 0;
                                                StartTime = DateTime.Now;

                                                if (NewEntry)
                                                {
                                                    break;
                                                }
                                            }

                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorCount++;
                                        DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    }

                                    //fileImportRequest.InsertCount++;
                                }

                            }

                            j++;
                        }

                        LineNo = 0;
                    }
                }

            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }
            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkImports.BulkInsertSettlementDataATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                //_logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
            {
                MSG = "Successful";
            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string Splitter_NPCI_ATM_Adjustment_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            int SheetLineNumber = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkImports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            System.Data.DataTable _DataTable = new System.Data.DataTable();

            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TerminalID", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("TxnType", typeof(string));
            _DataTable.Columns.Add("TxnUID", typeof(string));
            _DataTable.Columns.Add("UID", typeof(string));
            _DataTable.Columns.Add("AdjustmentDate", typeof(DateTime));
            _DataTable.Columns.Add("AdjustmentType", typeof(string));
            _DataTable.Columns.Add("AcquirerBank", typeof(string));
            _DataTable.Columns.Add("IssuerBank", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("ChargebackDate", typeof(DateTime));
            _DataTable.Columns.Add("ChargebackRemarks", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("AdjustmentAmount", typeof(decimal));
            _DataTable.Columns.Add("ACQFee", typeof(decimal));
            _DataTable.Columns.Add("ISSFee", typeof(decimal));
            _DataTable.Columns.Add("ISSFeeSW", typeof(decimal));
            _DataTable.Columns.Add("NPCIFee", typeof(decimal));
            _DataTable.Columns.Add("AcqFeeTax", typeof(decimal));
            _DataTable.Columns.Add("IssFeetax", typeof(decimal));
            _DataTable.Columns.Add("NPCITax", typeof(decimal));
            _DataTable.Columns.Add("AdjRef", typeof(string));
            _DataTable.Columns.Add("BankAdjRef", typeof(string));
            _DataTable.Columns.Add("AdjProof", typeof(string));
            _DataTable.Columns.Add("reasondesc", typeof(string));
            _DataTable.Columns.Add("PinCode", typeof(string));
            _DataTable.Columns.Add("TerminalLocation", typeof(string));
            _DataTable.Columns.Add("MultiDisputeGroup", typeof(string));
            _DataTable.Columns.Add("FCQM", typeof(string));
            _DataTable.Columns.Add("ADJSettlementdate", typeof(DateTime));
            _DataTable.Columns.Add("CustomerPenalty", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("TATExpiryDate", typeof(DateTime));
            _DataTable.Columns.Add("ACQSTLAmount", typeof(string));
            _DataTable.Columns.Add("AcqCC", typeof(string));
            _DataTable.Columns.Add("PanEntryMode", typeof(string));
            _DataTable.Columns.Add("ServiceCode", typeof(string));
            _DataTable.Columns.Add("CardDataInputCapability", typeof(string));
            _DataTable.Columns.Add("MCCCode", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));
            _DataTable.Columns.Add("ComplaintNumber", typeof(string));
            _DataTable.Columns.Add("ComplaintClosedReason", typeof(string));
            _DataTable.Columns.Add("Remark", typeof(string));

            int Incr = 1;

            DateTime? TxnsDateTimeMain = null;
            string ReferenceNumber = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TerminalID = string.Empty;
            string CardNumber = string.Empty;
            string Txnuid = string.Empty;
            string Uid = string.Empty;
            string TxnType = string.Empty;
            string AdjDate = string.Empty;
            string AdjType = string.Empty;
            string AcquirerBank = string.Empty;
            string IssuerBank = string.Empty;
            string AdjustmentAmount = string.Empty;
            string ResponseCode = string.Empty;

            string CardNo = string.Empty;
            string ChargebackDate = string.Empty;
            string ChargebackRemarks = string.Empty;
            string TxnAmount = "0";
            string AdjAmount = "0";
            string ACQFee = "0";
            string ISSFee = "0";
            string ISSFeeSW = "0";

            string NPCIFee = "0";
            string AcqFeeTax = "0";
            string IssFeetax = "0";
            string NPCITax = "0";

            string AdjRef = string.Empty;
            string BankAdjRef = string.Empty;
            string AdjProof = string.Empty;
            string reasondesc = string.Empty;
            string PinCode = string.Empty;
            string TermLoc = string.Empty;
            string MultDisGroup = string.Empty;
            string FCQM = string.Empty;
            string ADJSettlementdate = string.Empty;

            string CustomerPenalty = string.Empty;
            string Cycle = string.Empty;
            string TATExpiryDate = string.Empty;
            string ACQSTLAmount = string.Empty;
            string AcqCC = string.Empty;
            string PanEntryMode = string.Empty;
            string ServiceCode = string.Empty;
            string CardDataInputCapability = string.Empty;
            string MCCCode = string.Empty;

            string ECardNumber = string.Empty;
            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";
            string ComplaintNumber = string.Empty;
            string ComplaintClosedReason = string.Empty;
            string Remark = string.Empty;

            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TerminalID_CoulmnIndex = 0;
            ushort CardNumber_CoulmnIndex = 0;
            ushort TxnType_CoulmnIndex = 0;
            ushort TxnUID_CoulmnIndex = 0;
            ushort UID_CoulmnIndex = 0;
            ushort AdjustmentDate_CoulmnIndex = 0;
            ushort AdjustmentType_CoulmnIndex = 0;

            ushort AcquirerBank_CoulmnIndex = 0;
            ushort IssuerBank_CoulmnIndex = 0;
            ushort ResponseCode_CoulmnIndex = 0;
            ushort ChargebackDate_CoulmnIndex = 0;
            ushort ChargebackRemarks_CoulmnIndex = 0;


            ushort TxnAmount_CoulmnIndex = 0;
            ushort AdjustmentAmount_CoulmnIndex = 0;
            ushort ACQFee_CoulmnIndex = 0;
            ushort ISSFee_CoulmnIndex = 0;
            ushort ISSFeeSW_CoulmnIndex = 0;
            ushort NPCIFee_CoulmnIndex = 0;
            ushort AcqFeeTax_CoulmnIndex = 0;
            ushort IssFeetax_CoulmnIndex = 0;
            ushort NPCITax_CoulmnIndex = 0;


            ushort AdjRef_CoulmnIndex = 0;
            ushort BankAdjRef_CoulmnIndex = 0;
            ushort AdjProof_CoulmnIndex = 0;
            ushort reasondesc_CoulmnIndex = 0;
            ushort PinCode_CoulmnIndex = 0;
            ushort TerminalLocation_CoulmnIndex = 0;
            ushort MultiDisputeGroup_CoulmnIndex = 0;
            ushort FCQM_CoulmnIndex = 0;
            ushort AdjSettlementdate_CoulmnIndex = 0;


            ushort CustomerPenalty_CoulmnIndex = 0;
            ushort Cycle_CoulmnIndex = 0;
            ushort TATExpiryDate_CoulmnIndex = 0;
            ushort ACQSTLAmount_CoulmnIndex = 0;
            ushort AcqCC_CoulmnIndex = 0;
            ushort PanEntryMode_CoulmnIndex = 0;
            ushort ServiceCode_CoulmnIndex = 0;
            ushort CardDataInputCapability_CoulmnIndex = 0;
            ushort MCCCode_CoulmnIndex = 0;
            ushort ComplaintNumber_CoulmnIndex = 0;
            ushort ComplaintClosedReason_CoulmnIndex = 0;
            ushort Remark_CoulmnIndex = 0;

            string[] TxnDateTimeFormat = null;
            string Status = "0";
            bool ErrorOccurred = false;
            DateTime? AdjustmentDate = null;
            DateTime? ChBkdate = null;
            DateTime? AdjSetDate = null;
            DateTime? TATExpDate = null;

            try
            {
                DataSet ds = new DataSet();

                string RevEntryLeg = string.Empty;
                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);


                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TerminalID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TerminalID"]);
                CardNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CardNumber"]);
                TxnType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsType"]);
                TxnUID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnUID"]);
                UID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UID"]);
                AdjustmentDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjustmentDate"]);
                AdjustmentType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjustmentType"]);

                AcquirerBank_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AcquirerBank"]);
                IssuerBank_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["IssuerBank"]);
                ResponseCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode"]);
                ChargebackDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChargebackDate"]);
                ChargebackRemarks_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChargebackRemarks"]);

                TxnAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                AdjustmentAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjustmentAmount"]);
                ACQFee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQFee"]);
                ISSFee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSFee"]);
                ISSFeeSW_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSFeeSW"]);
                NPCIFee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NPCIFee"]);
                AcqFeeTax_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AcqFeeTax"]);
                IssFeetax_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["IssFeetax"]);
                NPCITax_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NPCITax"]);

                AdjRef_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjRef"]);
                BankAdjRef_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BankAdjRef"]);
                AdjProof_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjProof"]);
                reasondesc_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["reasondesc"]);
                PinCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PinCode"]);
                TerminalLocation_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TerminalLocation"]);
                MultiDisputeGroup_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MultiDisputeGroup"]);
                FCQM_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FCQM"]);
                AdjSettlementdate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjSettlementdate"]);

                CustomerPenalty_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CustomerPenalty"]);
                Cycle_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Cycle"]);
                TATExpiryDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TATExpiryDate"]);
                ACQSTLAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQSTLAmount"]);
                AcqCC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AcqCC"]);
                PanEntryMode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PanEntryMode"]);
                ServiceCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ServiceCode"]);
                CardDataInputCapability_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CardDataInputCapability"]);
                MCCCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MCCCode"]);
                ComplaintNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ComplaintNumber"]);
                ComplaintClosedReason_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ComplaintClosedReason"]);
                Remark_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remark"]);

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }
                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            DataTable allSheets = new DataTable();
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {
                try
                {
                    batchSize = bulkImports.GetBatchSize(DTdetails.ConfigID);

                    System.Data.DataTable dtexcelsheetname = new System.Data.DataTable();
                    System.Data.DataTable dtSheet = new System.Data.DataTable();
                    //Read the connection string for the Excel file.
                    string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                    conString = string.Format(conString, fileImportRequest.Path);

                    if (conString.Contains("HTML Import"))
                    {
                        using (OleDbConnection connExcel = new OleDbConnection(conString))
                        {
                            using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                            {
                                connExcel.Open();
                                //Get the name of First Sheet. 
                                dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                                connExcel.Close();
                            }
                        }
                    }
                    else
                    {

                        using (OleDbConnection connExcel = new OleDbConnection(conString))
                        {
                            using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                            {
                                connExcel.Open();
                                //Get the name of First Sheet. 
                                allSheets = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                                connExcel.Close();
                            }
                        }

                        // Filter only visible sheets that end with '$' and do not include hidden/system ranges
                        var validSheetRows = allSheets
                            .AsEnumerable()
                            .Where(row =>
                            {
                                string sheetName = row["TABLE_NAME"].ToString();
                                return sheetName.EndsWith("$") &&
                                       !sheetName.Contains("xlnm") && // Exclude _xlnm# named ranges
                                       !sheetName.StartsWith("_");    // Exclude hidden/internal
                            });

                        if (validSheetRows.Any())
                        {
                            dtexcelsheetname = validSheetRows.CopyToDataTable();
                        }
                        else
                        {
                            throw new Exception("No valid worksheet found in Excel file.");
                        }

                    }

                    if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                    {

                        int j = 0;

                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }
                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }
                            foreach (DataRow row in dtexcelsheetname.Rows)
                            {
                                dtSheet = new DataTable();

                                using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                                {
                                    using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                    {
                                        using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                        {
                                            //Read Data from First Sheet.
                                            cmdExcelSheet.Connection = connExcelSheet;
                                            connExcelSheet.Open();
                                            cmdExcelSheet.CommandText = "SELECT * From [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                            odaExcelSheet.SelectCommand = cmdExcelSheet;
                                            odaExcelSheet.Fill(dtSheet);
                                            connExcelSheet.Close();
                                        }
                                    }
                                }

                                Incr = 1;

                                if (dtSheet.Rows.Count > 0)
                                {
                                    // Find first data row based on whether the "Join Date" cell can be parsed as a date
                                    int dateStartIndex = -1;

                                    for (int i = 0; i < dtSheet.Rows.Count; i++)
                                    {
                                        try
                                        {
                                            if (TxnsDateTime_CoulmnIndex > 0)
                                            {
                                                string value = dtSheet.Rows[i][TxnsDateTime_CoulmnIndex - Incr]?.ToString()?.Trim();

                                                bool isValid = DateTime.TryParseExact(value, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                                if (isValid)
                                                {
                                                    dateStartIndex = i;
                                                    break;
                                                }
                                            }
                                            else if (TxnsDate_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                                            {
                                                string[] dateParts = dtSheet.Rows[i][TxnsDate_CoulmnIndex - Incr]?.ToString()?.Trim().Split('-');
                                                string[] timeParts = dtSheet.Rows[i][TxnsTime_CoulmnIndex - Incr]?.ToString()?.Trim().Split(':');

                                                TxnsDate = $"{dateParts[0]}{dateParts[1]}{dateParts[2]}";
                                                TxnsTime = $"{timeParts[0]}{timeParts[1]}{timeParts[2]}";

                                                string value = TxnsDate + " " + TxnsTime;

                                                bool isValid = DateTime.TryParseExact(value, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                                if (isValid)
                                                {
                                                    dateStartIndex = i;
                                                    break;
                                                }
                                            }
                                        }
                                        catch
                                        {
                                            SheetDateError++;
                                        }

                                        if (i > 25)
                                            break;
                                    }

                                    if (dateStartIndex > -1)
                                    {
                                        fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                                        {
                                            LineNo++;
                                            SheetLineNumber++;
                                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                            {
                                                continue;
                                            }
                                            try
                                            {
                                                ReferenceNumber = string.Empty;
                                                TxnsDateTime = string.Empty;
                                                TxnsDate = string.Empty;
                                                TxnsTime = string.Empty;
                                                TerminalID = string.Empty;
                                                CardNumber = string.Empty;
                                                TxnType = string.Empty;
                                                Txnuid = string.Empty;
                                                Uid = string.Empty;
                                                AdjDate = string.Empty;
                                                AdjType = string.Empty;
                                                AcquirerBank = string.Empty;
                                                IssuerBank = string.Empty;
                                                ResponseCode = string.Empty;
                                                ChargebackDate = string.Empty;
                                                ChargebackRemarks = string.Empty;

                                                TxnAmount = "0";
                                                AdjustmentAmount = "0";
                                                ACQFee = "0";
                                                ISSFee = "0";
                                                ISSFeeSW = "0";
                                                NPCIFee = "0";
                                                AcqFeeTax = "0";
                                                IssFeetax = "0";
                                                NPCITax = "0";


                                                AdjRef = string.Empty;
                                                BankAdjRef = string.Empty;
                                                AdjProof = string.Empty;
                                                reasondesc = string.Empty;
                                                PinCode = string.Empty;
                                                TermLoc = string.Empty;
                                                MultDisGroup = string.Empty;
                                                FCQM = string.Empty;
                                                ADJSettlementdate = string.Empty;

                                                CustomerPenalty = string.Empty;
                                                Cycle = string.Empty;
                                                TATExpiryDate = string.Empty;
                                                ACQSTLAmount = string.Empty;
                                                AcqCC = string.Empty;
                                                PanEntryMode = string.Empty;
                                                ServiceCode = string.Empty;
                                                CardDataInputCapability = string.Empty;
                                                MCCCode = string.Empty;
                                                CardScheme = string.Empty;
                                                ECardNumber = string.Empty;
                                                ComplaintNumber = string.Empty;
                                                ComplaintClosedReason = string.Empty;
                                                Remark = string.Empty;

                                                ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TerminalID = TerminalID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TerminalID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                CardNumber = CardNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CardNumber_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnType = TxnType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                Txnuid = TxnUID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnUID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                Uid = UID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][UID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AdjDate = AdjustmentDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjustmentDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AdjType = AdjustmentType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjustmentType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ResponseCode = ResponseCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AcquirerBank = AcquirerBank_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AcquirerBank_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                IssuerBank = IssuerBank_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][IssuerBank_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ResponseCode = ResponseCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ChargebackDate = ChargebackDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ChargebackDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ChargebackRemarks = ChargebackRemarks_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ChargebackRemarks_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnAmount = TxnAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnAmount_CoulmnIndex - Incr]) : string.Empty;
                                                AdjustmentAmount = AdjustmentAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjustmentAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ACQFee = ACQFee_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQFee_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ISSFee = ISSFee_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISSFee_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ISSFeeSW = ISSFeeSW_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISSFeeSW_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                NPCIFee = NPCIFee_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][NPCIFee_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AcqFeeTax = AcqFeeTax_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AcqFeeTax_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                NPCITax = NPCITax_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][NPCITax_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                AdjRef = AdjRef_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjRef_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                BankAdjRef = BankAdjRef_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BankAdjRef_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AdjProof = AdjProof_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjProof_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                reasondesc = reasondesc_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][reasondesc_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                PinCode = PinCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PinCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TermLoc = TerminalLocation_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TerminalLocation_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                MultDisGroup = MultiDisputeGroup_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][MultiDisputeGroup_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                FCQM = FCQM_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FCQM_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ADJSettlementdate = AdjSettlementdate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjSettlementdate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                CustomerPenalty = CustomerPenalty_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CustomerPenalty_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                Cycle = Cycle_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Cycle_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TATExpiryDate = TATExpiryDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TATExpiryDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ACQSTLAmount = ACQSTLAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQSTLAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AcqCC = AcqCC_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AcqCC_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                PanEntryMode = PanEntryMode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PanEntryMode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ServiceCode = ServiceCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ServiceCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                CardDataInputCapability = CardDataInputCapability_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CardDataInputCapability_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                MCCCode = MCCCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][MCCCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ComplaintNumber = ComplaintNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ComplaintNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ComplaintClosedReason = ComplaintClosedReason_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ComplaintClosedReason_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                Remark = Remark_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Remark_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsDateTimeMain = null;

                                                #region ValidateField

                                                if (TxnsDate.Length == 10 && TxnsTime.Length == 8)
                                                {
                                                    string[] dateParts = TxnsDate.Split('-');
                                                    string[] timeParts = TxnsTime.Split(':');

                                                    TxnsDate = $"{dateParts[0]}{dateParts[1]}{dateParts[2]}";
                                                    TxnsTime = $"{timeParts[0]}{timeParts[1]}{timeParts[2]}";
                                                }

                                                if (TxnsDate != "" && TxnsTime != "")
                                                {
                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + " " + TxnsTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (TxnDateTimeFormat[0].ToString() != "" && TxnsDateTime != "")
                                                {
                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                ChBkdate = ChargebackDate == "--" ? null : DateTime.TryParse(ChargebackDate, out DateTime parsedDate) ? (DateTime?)parsedDate : null;
                                                AdjustmentDate = AdjDate == "" ? null : DateTime.TryParse(AdjDate, out DateTime AdjustmentDate_parsedDate) ? (DateTime?)AdjustmentDate_parsedDate : null;
                                                AdjSetDate = ADJSettlementdate == "" ? null : DateTime.TryParse(ADJSettlementdate, out DateTime AdjSetDate_parsedDate) ? (DateTime?)AdjSetDate_parsedDate : null;
                                                TATExpDate = TATExpiryDate == "" ? null : DateTime.TryParse(TATExpiryDate, out DateTime TATExpDate_parsedDate) ? (DateTime?)TATExpDate_parsedDate : null;

                                                #endregion ValidateField

                                                Txnuid = Txnuid.Replace("'", "");
                                                Uid = Uid.Replace("'", "");
                                                ResponseCode = ResponseCode.Replace("'", "");
                                                ReferenceNumber = ReferenceNumber.Replace("'", "");
                                                CardNumber = CardNumber.Replace("'", "");
                                                TermLoc = TermLoc.Replace("'", "");


                                                if (CardNumber != "")
                                                {
                                                    CardScheme = Common.GetCardType(CardNumber);

                                                    ECardNumber = AesEncryption.EncryptString(CardNumber);
                                                }

                                                if (CardNumber != "" && CardNumber.Length == 16)
                                                {
                                                    CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();
                                                } 

                                                TxnAmount = Common.IsNumeric(TxnAmount) ? TxnAmount : "0";
                                                AdjustmentAmount = Common.IsNumeric(AdjustmentAmount) ? AdjustmentAmount : "0";
                                                ACQFee = Common.IsNumeric(ACQFee) ? ACQFee : "0";
                                                ISSFee = Common.IsNumeric(ISSFee) ? ISSFee : "0";
                                                ISSFeeSW = Common.IsNumeric(ISSFeeSW) ? ISSFeeSW : "0";
                                                NPCIFee = Common.IsNumeric(NPCIFee) ? NPCIFee : "0";
                                                AcqFeeTax = Common.IsNumeric(AcqFeeTax) ? AcqFeeTax : "0";
                                                IssFeetax = Common.IsNumeric(IssFeetax) ? IssFeetax : "0";
                                                NPCITax = Common.IsNumeric(NPCITax) ? NPCITax : "0";

                                                if (TxnsDateTimeMain != null)
                                                {
                                                    _DataTable.Rows.Add(
                                                          ReferenceNumber
                                                        , TxnsDateTimeMain
                                                        , TerminalID
                                                        , CardNumber.Trim()
                                                        , TxnType
                                                        , Txnuid
                                                        , Uid
                                                        , AdjustmentDate
                                                        , AdjType
                                                        , AcquirerBank
                                                        , IssuerBank
                                                        , ResponseCode
                                                        , ChBkdate
                                                        , ChargebackRemarks
                                                        , Convert.ToDecimal(TxnAmount)
                                                        , Convert.ToDecimal(AdjustmentAmount)
                                                        , Convert.ToDecimal(ACQFee)
                                                        , Convert.ToDecimal(ISSFee)
                                                        , Convert.ToDecimal(ISSFeeSW)
                                                        , Convert.ToDecimal(NPCIFee)
                                                        , Convert.ToDecimal(AcqFeeTax)
                                                        , Convert.ToDecimal(IssFeetax)
                                                        , Convert.ToDecimal(NPCITax)
                                                        , AdjRef
                                                        , BankAdjRef
                                                        , AdjProof
                                                        , reasondesc
                                                        , PinCode
                                                        , TermLoc
                                                        , MultDisGroup
                                                        , FCQM
                                                        , AdjSetDate
                                                        , CustomerPenalty
                                                        , Cycle
                                                        , TATExpDate
                                                        , ACQSTLAmount
                                                        , AcqCC
                                                        , PanEntryMode
                                                        , ServiceCode
                                                        , CardDataInputCapability
                                                        , MCCCode
                                                        , ECardNumber.Trim()
                                                        , CardScheme
                                                        , IssuingNetwork
                                                        , ComplaintNumber
                                                        , ComplaintClosedReason
                                                        , Remark
                                                        );


                                                    if (_DataTable.Rows.Count >= batchSize)
                                                    {
                                                        BatchNo++;
                                                        MSG = bulkImports.BulkInsertNPCIAdjustmentATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                        fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                        BatchDetails batchDetails = new BatchDetails
                                                        {
                                                            BatchNo = BatchNo,
                                                            BatchSize = batchSize,
                                                            TxnUploadCount = _DataTable.Rows.Count,
                                                            TxnsCount = fileImportRequest.InsertCount,
                                                            BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                            FailedCount = ErrorCount,
                                                            BatchStartTime = batchStartTime,
                                                            BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                        };

                                                        batchDetailsList.Add(batchDetails);
                                                        _DataTable.Clear();
                                                        ErrorCount = 0;
                                                        StartTime = DateTime.Now;

                                                        if (NewEntry)
                                                        {
                                                            break;
                                                        }
                                                    }
                                                }

                                            }
                                            catch (Exception ex)
                                            {
                                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                                ErrorCount++;
                                            }
                                            j++;
                                        }
                                    }
                                    else
                                    {
                                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched";
                                        break;
                                    }
                                }
                            }

                            LineNo = 0;
                        }
                    }
                }
                catch (Exception ex)
                {
                    fileImportRequest.ErrorMessage = ex.Message;
                    // objLogWriter.FunErrorLog(ex.Message.ToString(), fileImportRequest.ClientCode, "SplitterWithSeperator.cs", "SplitData", LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }

            }


            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkImports.BulkInsertNPCIAdjustmentATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                //  _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            else if(_DataTable.Rows.Count==0 && ErrorCount==0 && fileImportRequest.TotalCount == 0)
                {
                MSG = "Successful";
            }
                fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string Splitter_NPCI_Issuer_ATM_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0, LineNumber = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int ErrorCount = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;


            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;
            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkImports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FromAccountType", typeof(string));
            _DataTable.Columns.Add("ToAccountType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(DateTime));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            string RevEntryLeg = "1";


            int Incr = 1;
            string PARTICIPENTID = string.Empty;
            string TRANSTYPE = string.Empty;
            string FROMACCTYPE = string.Empty;
            string TOACCTYPE = string.Empty;
            string ReferenceNumber = string.Empty;
            string RESPONSECODE = string.Empty;
            string CardNumber = string.Empty;
            string MEMNUMBER = string.Empty;
            string APPROVALNO = string.Empty;
            string SYSTRACAUDITNO = string.Empty;
            string TxnsDateTime = string.Empty;
            string TRANSDATE = string.Empty;
            string TRANSTIME = string.Empty;
            string MERCHANTCATCODE = string.Empty;
            string CARDACCEPTERSETDATE = string.Empty;

            string CARDACCID = string.Empty;
            string TerminalId = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string ACCIQUIERID = string.Empty;

            string NETWORKID = string.Empty;
            string ACCOUNTNO1 = string.Empty;
            string ACCOUNTBRANCHID = string.Empty;
            string ACCOUNTNO2 = string.Empty;
            string ACCOUNT2BRANCHID = string.Empty;
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = "0";
            string ACCTUALTRANAMOUNT = "0";
            string TRANSACCVITYFEE = "0";
            string ISSUERSETCURRENCYCODE = string.Empty;
            string ISSURESETAMOUNT = "0";
            string ISSUERSETFEE = "0";
            string ISSURESETPROCFEE = "0";
            string CARDHOLDERBILLCURNCCODE = string.Empty;
            string CARDHOLDERBILLAMOUNT = "0";
            string CARDHOLDERBILACTFEE = "0";
            string CARDHOLDERBILPROFEE = "0";
            string CARDHOLDERBILSRVICEFEE = "0";
            string TRAN_ISSUERCONVERSRATE = "0";
            string TRANS_CARDHOLDERCONVERRATE = "0";


            string ECardNumber = string.Empty;
            string line1 = string.Empty;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            string CardType = string.Empty;

            DateTime? TxnsDateTimeMain = null;

            DateTime? CARDACCEPTERSETDATEMain = null;

            string[] TxnDateTimeFormat = null;

            string Cycle = string.Empty;

            ushort PARICIPATEID_CoulmnIndex = 0;
            ushort TRANSACTIONTYPE_CoulmnIndex = 0;
            ushort FromAccountType_CoulmnIndex = 0;
            ushort ToAccountType_CoulmnIndex = 0;
            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort ResponseCode_CoulmnIndex = 0;
            ushort CardNumber_CoulmnIndex = 0;
            ushort MEMNUMBER_CoulmnIndex = 0;
            ushort APPROVNO_CoulmnIndex = 0;
            ushort STAUDITNO_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;
            ushort TRANSDATE_CoulmnIndex = 0;
            ushort MERCHENTCATCODE_CoulmnIndex = 0;
            ushort CARDACCEPTSETDATE_CoulmnIndex = 0;
            ushort CARDACCID_CoulmnIndex = 0;
            ushort TerminalId_CoulmnIndex = 0;
            ushort CARDACCEPTERTERLOCATION_CoulmnIndex = 0;
            ushort AcquirerID_CoulmnIndex = 0;
            ushort NETWORKID_CoulmnIndex = 0;
            ushort ACCOUNTNO1_CoulmnIndex = 0;
            ushort ACCOUNTBRANCHID_CoulmnIndex = 0;
            ushort ACCOUNTNO2_CoulmnIndex = 0;
            ushort ACCOUNT2BRANCHID_CoulmnIndex = 0;
            ushort TRANSCURRENCYCODE_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort ACCTUALTRANAMOUNT_CoulmnIndex = 0;
            ushort TRANSACCVITYFEE_CoulmnIndex = 0;
            ushort ISSUERSETCURRENCYCODE_CoulmnIndex = 0;
            ushort ISSURESETAMOUNT_CoulmnIndex = 0;
            ushort ISSUERSETFEE_CoulmnIndex = 0;
            ushort ISSURESETPROCFEE_CoulmnIndex = 0;
            ushort CARDHOLDERBILLCURNCCODE_CoulmnIndex = 0;
            ushort CARDHOLDERBILLAMOUNT_CoulmnIndex = 0;
            ushort CARDHOLDERBILACTFEE_CoulmnIndex = 0;
            ushort CARDHOLDERBILPROFEE_CoulmnIndex = 0;
            ushort CARDHOLDERBILSRVICEFEE_CoulmnIndex = 0;
            ushort TRAN_ISSUERCONVERSRATE_CoulmnIndex = 0;
            ushort TRANS_CARDHOLDERCONVERRATE_CoulmnIndex = 0;

            bool ErrorOccurred = false;
            int largestIndex = 0, CoulmnIndex = 0, TxnAmountIsDecimal = 0;
            string[] SplitArr = null;

            try
            {
                int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                string[] FDA = fileImportRequest.FileName.Split('_');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                DataSet ds = new DataSet();

                ds.ReadXml(new XmlTextReader(new System.IO.StringReader(xmlFile)));

                PARICIPATEID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PARICIPATEID"]);
                TRANSACTIONTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONTYPE"]); ;
                FromAccountType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccountType"]);
                ToAccountType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccountType"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                ResponseCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode"]);
                CardNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CardNumber"]);
                MEMNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MEMNUMBER"]);
                APPROVNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["APPROVNO"]);
                STAUDITNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["STAUDITNO"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONTIME"]);
                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONDATE"]);
                MERCHENTCATCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MERCHENTCATCODE"]);
                CARDACCEPTSETDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTSETDATE"]);
                CARDACCID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCID"]);
                TerminalId_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TerminalId"]);
                CARDACCEPTERTERLOCATION_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERTERLOCATION"]);
                AcquirerID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AcquirerID"]);
                NETWORKID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NETWORKID"]);
                ACCOUNTNO1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTNO1"]);
                ACCOUNTBRANCHID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTBRANCHID"]);
                ACCOUNTNO2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTNO2"]);
                ACCOUNT2BRANCHID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNT2BRANCHID"]);
                TRANSCURRENCYCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSCURRENCYCODE"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                ACCTUALTRANAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANAMOUNT"]);
                TRANSACCVITYFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACCVITYFEE"]);
                ISSUERSETCURRENCYCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSUERSETCURRENCYCODE"]);
                ISSURESETAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSURESETAMOUNT"]);
                ISSUERSETFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSUERSETFEE"]);
                ISSURESETPROCFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSURESETPROCFEE"]);
                CARDHOLDERBILLCURNCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILLCURNCCODE"]);
                CARDHOLDERBILLAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILLAMOUNT"]);
                CARDHOLDERBILACTFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILACTFEE"]);
                CARDHOLDERBILPROFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILPROFEE"]);
                CARDHOLDERBILSRVICEFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILSRVICEFEE"]);
                TRAN_ISSUERCONVERSRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRAN_ISSUERCONVERSRATE"]);
                TRANS_CARDHOLDERCONVERRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANS_CARDHOLDERCONVERRATE"]);

                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }


            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    //Get Batch Size
                    batchSize = bulkImports.GetBatchSize(DTdetails.ConfigID);

                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            SplitArr = new string[0];

                            SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            if (TxnsDateTime_CoulmnIndex > 0)
                            {
                                tempTxnDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                            else if (TRANSDATE_CoulmnIndex > 0 && TRANSTIME_CoulmnIndex > 0)
                            {
                                TRANSDATE = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                TRANSTIME = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;
                                tempTxnDateTime = TRANSDATE + " " + TRANSTIME;
                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                        
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }


                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                if (LineNo < dateStartIndex)
                                {
                                    LineNumber++;
                                    LineNo++;
                                    continue;
                                }

                                LineNo++;

                                try
                                {
                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                    SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                    if (SplitArr.Length < largestIndex) continue;

                                    LineNumber++;

                                    PARTICIPENTID = string.Empty;
                                    TRANSTYPE = string.Empty;
                                    FROMACCTYPE = string.Empty;
                                    TOACCTYPE = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    RESPONSECODE = string.Empty;
                                    CardNumber = string.Empty;
                                    MEMNUMBER = string.Empty;
                                    APPROVALNO = string.Empty;
                                    SYSTRACAUDITNO = string.Empty;
                                    TxnsDateTime = string.Empty;
                                    TRANSTIME = string.Empty;
                                    MERCHANTCATCODE = string.Empty;
                                    CARDACCEPTERSETDATE = string.Empty;

                                    CARDACCID = string.Empty;
                                    TerminalId = string.Empty;
                                    CARDACCEPTERTERLOC = string.Empty;
                                    ACCIQUIERID = string.Empty;
                                    Transaction_Amount = "0";
                                    ACCTUALTRANAMOUNT = "0";
                                    TRANSACCVITYFEE = "0";
                                    ISSUERSETCURRENCYCODE = string.Empty;
                                    ISSURESETAMOUNT = "0";
                                    ISSUERSETFEE = "0";
                                    ISSURESETPROCFEE = "0";
                                    CARDHOLDERBILLCURNCCODE = string.Empty;
                                    CARDHOLDERBILLAMOUNT = "0";
                                    CARDHOLDERBILACTFEE = "0";
                                    CARDHOLDERBILPROFEE = "0";
                                    CARDHOLDERBILSRVICEFEE = "0";
                                    TRAN_ISSUERCONVERSRATE = "0";
                                    TRANS_CARDHOLDERCONVERRATE = "0";
                                    ECardNumber = string.Empty;
                                    CardScheme = string.Empty;

                                    PARTICIPENTID = PARICIPATEID_CoulmnIndex > 0 ? SplitArr[PARICIPATEID_CoulmnIndex - Incr].Trim() : string.Empty;

                                    TRANSTYPE = TRANSACTIONTYPE_CoulmnIndex > 0 ? SplitArr[TRANSACTIONTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    FROMACCTYPE = FromAccountType_CoulmnIndex > 0 ? SplitArr[FromAccountType_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TOACCTYPE = ToAccountType_CoulmnIndex > 0 ? SplitArr[ToAccountType_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? SplitArr[ReferenceNumber_CoulmnIndex - Incr].Trim() : string.Empty;
                                    RESPONSECODE = ResponseCode_CoulmnIndex > 0 ? SplitArr[ResponseCode_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CardNumber = CardNumber_CoulmnIndex > 0 ? SplitArr[CardNumber_CoulmnIndex - Incr].Trim() : string.Empty;
                                    MEMNUMBER = MEMNUMBER_CoulmnIndex > 0 ? SplitArr[MEMNUMBER_CoulmnIndex - Incr].Trim() : string.Empty;
                                    APPROVALNO = APPROVNO_CoulmnIndex > 0 ? SplitArr[APPROVNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    SYSTRACAUDITNO = STAUDITNO_CoulmnIndex > 0 ? SplitArr[STAUDITNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? SplitArr[TxnsDateTime_CoulmnIndex - Incr].Trim() : string.Empty;
                                    MERCHANTCATCODE = MERCHENTCATCODE_CoulmnIndex > 0 ? SplitArr[MERCHENTCATCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDACCID = CARDACCID_CoulmnIndex > 0 ? SplitArr[CARDACCID_CoulmnIndex - Incr].Trim() : string.Empty;

                                    TerminalId = TerminalId_CoulmnIndex > 0 ? SplitArr[TerminalId_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDACCEPTERTERLOC = CARDACCEPTERTERLOCATION_CoulmnIndex > 0 ? SplitArr[CARDACCEPTERTERLOCATION_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCIQUIERID = AcquirerID_CoulmnIndex > 0 ? SplitArr[AcquirerID_CoulmnIndex - Incr].Trim() : string.Empty;

                                    NETWORKID = NETWORKID_CoulmnIndex > 0 ? SplitArr[NETWORKID_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCOUNTNO1 = ACCOUNTNO1_CoulmnIndex > 0 ? SplitArr[ACCOUNTNO1_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCOUNTBRANCHID = ACCOUNTBRANCHID_CoulmnIndex > 0 ? SplitArr[ACCOUNTBRANCHID_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCOUNTNO2 = ACCOUNTNO2_CoulmnIndex > 0 ? SplitArr[ACCOUNTNO2_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCOUNT2BRANCHID = ACCOUNT2BRANCHID_CoulmnIndex > 0 ? SplitArr[ACCOUNT2BRANCHID_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Currency_Code = TRANSCURRENCYCODE_CoulmnIndex > 0 ? SplitArr[TRANSCURRENCYCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Amount = TxnsAmount_CoulmnIndex > 0 ? SplitArr[TxnsAmount_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCTUALTRANAMOUNT = ACCTUALTRANAMOUNT_CoulmnIndex > 0 ? SplitArr[ACCTUALTRANAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;


                                    TRANSACCVITYFEE = TRANSACCVITYFEE_CoulmnIndex > 0 ? SplitArr[TRANSACCVITYFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ISSUERSETCURRENCYCODE = ISSUERSETCURRENCYCODE_CoulmnIndex > 0 ? SplitArr[ISSUERSETCURRENCYCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ISSURESETAMOUNT = ISSURESETAMOUNT_CoulmnIndex > 0 ? SplitArr[ISSURESETAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ISSUERSETFEE = ISSUERSETFEE_CoulmnIndex > 0 ? SplitArr[ISSUERSETFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ISSURESETPROCFEE = ISSURESETPROCFEE_CoulmnIndex > 0 ? SplitArr[ISSURESETPROCFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDHOLDERBILLCURNCCODE = CARDHOLDERBILLCURNCCODE_CoulmnIndex > 0 ? SplitArr[CARDHOLDERBILLCURNCCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDHOLDERBILLAMOUNT = CARDHOLDERBILLAMOUNT_CoulmnIndex > 0 ? SplitArr[CARDHOLDERBILLAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDHOLDERBILACTFEE = CARDHOLDERBILACTFEE_CoulmnIndex > 0 ? SplitArr[CARDHOLDERBILACTFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDHOLDERBILPROFEE = CARDHOLDERBILPROFEE_CoulmnIndex > 0 ? SplitArr[CARDHOLDERBILPROFEE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    CARDHOLDERBILSRVICEFEE = CARDHOLDERBILSRVICEFEE_CoulmnIndex > 0 ? SplitArr[CARDHOLDERBILSRVICEFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TRAN_ISSUERCONVERSRATE = TRAN_ISSUERCONVERSRATE_CoulmnIndex > 0 ? SplitArr[TRAN_ISSUERCONVERSRATE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TRANS_CARDHOLDERCONVERRATE = TRANS_CARDHOLDERCONVERRATE_CoulmnIndex > 0 ? SplitArr[TRANS_CARDHOLDERCONVERRATE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    TRANSTIME = TRANSTIME_CoulmnIndex > 0 ? SplitArr[TRANSTIME_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TRANSDATE = TRANSDATE_CoulmnIndex > 0 ? SplitArr[TRANSDATE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    CardType = string.Empty;
                                    TxnsDateTimeMain = null;
                                    CARDACCEPTERSETDATEMain = null;

                                    #region ValidateField

                                    Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                                    ACCTUALTRANAMOUNT = Common.IsNumeric(ACCTUALTRANAMOUNT) ? ACCTUALTRANAMOUNT : "0";
                                    TRANSACCVITYFEE = Common.IsNumeric(TRANSACCVITYFEE) ? TRANSACCVITYFEE : "0";
                                    ISSURESETAMOUNT = Common.IsNumeric(ISSURESETAMOUNT) ? ISSURESETAMOUNT : "0";
                                    ISSUERSETFEE = Common.IsNumeric(ISSUERSETFEE) ? ISSUERSETFEE : "0";
                                    ISSURESETPROCFEE = Common.IsNumeric(ISSURESETPROCFEE) ? ISSURESETPROCFEE : "0";
                                    CARDHOLDERBILLAMOUNT = Common.IsNumeric(CARDHOLDERBILLAMOUNT) ? CARDHOLDERBILLAMOUNT : "0";
                                    CARDHOLDERBILACTFEE = Common.IsNumeric(CARDHOLDERBILACTFEE) ? CARDHOLDERBILACTFEE : "0";
                                    CARDHOLDERBILPROFEE = Common.IsNumeric(CARDHOLDERBILPROFEE) ? CARDHOLDERBILPROFEE : "0";
                                    CARDHOLDERBILSRVICEFEE = Common.IsNumeric(CARDHOLDERBILSRVICEFEE) ? CARDHOLDERBILSRVICEFEE : "0";
                                    TRAN_ISSUERCONVERSRATE = Common.IsNumeric(TRAN_ISSUERCONVERSRATE) ? TRAN_ISSUERCONVERSRATE : "0";
                                    TRANS_CARDHOLDERCONVERRATE = Common.IsNumeric(TRANS_CARDHOLDERCONVERRATE) ? TRANS_CARDHOLDERCONVERRATE : "0";

                                    if (TxnsDateTime != "")
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TRANSDATE != "" && TRANSTIME != "")
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TRANSDATE + " " + TRANSTIME, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (CARDACCEPTERSETDATE != "")
                                    {
                                        CARDACCEPTERSETDATEMain = DateTime.ParseExact(CARDACCEPTERSETDATE, "yyMMdd", CultureInfo.InvariantCulture);
                                    }

                                    

                                    #endregion ValidateField 

                                    if (CardNumber != "")
                                    {
                                        CardScheme = Common.GetCardType(CardNumber);

                                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                                    }

                                    if (CardNumber != "")
                                    {
                                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                                    }

                                    if (TxnsDateTimeMain != null)
                                    {

                                        _DataTable.Rows.Add(
                                                    PARTICIPENTID
                                                    , TRANSTYPE
                                                    , FROMACCTYPE
                                                    , TOACCTYPE
                                                    , ReferenceNumber
                                                    , RESPONSECODE
                                                    , CardNumber.Trim()
                                                    , CardType
                                                    , MEMNUMBER
                                                    , APPROVALNO
                                                    , SYSTRACAUDITNO
                                                    , TxnsDateTimeMain
                                                    , TRANSTIME
                                                    , MERCHANTCATCODE
                                                    , CARDACCEPTERSETDATEMain
                                                    , CARDACCID
                                                    , TerminalId
                                                    , CARDACCEPTERTERLOC
                                                    , ACCIQUIERID
                                                    , NETWORKID
                                                    , ACCOUNTNO1
                                                    , ACCOUNTBRANCHID
                                                    , ACCOUNTNO2
                                                    , ACCOUNT2BRANCHID
                                                    , Transaction_Currency_Code
                                                    , Transaction_Amount
                                                    , ACCTUALTRANAMOUNT
                                                    , TRANSACCVITYFEE.Trim()
                                                    , ISSUERSETCURRENCYCODE.Trim()
                                                    , ISSURESETAMOUNT.Trim()
                                                    , ISSUERSETFEE.Trim()
                                                    , ISSURESETPROCFEE.Trim()
                                                    , CARDHOLDERBILLCURNCCODE.Trim()
                                                    , CARDHOLDERBILLAMOUNT.Trim()
                                                    , CARDHOLDERBILACTFEE.Trim()
                                                    , CARDHOLDERBILPROFEE.Trim()
                                                    , CARDHOLDERBILSRVICEFEE.Trim()
                                                    , TRAN_ISSUERCONVERSRATE.Trim()
                                                    , TRANS_CARDHOLDERCONVERRATE.Trim()
                                                    , RevEntryLeg
                                                    , Cycle
                                                    , ECardNumber.Trim()
                                                    , CardScheme
                                                    , IssuingNetwork
                                                    );


                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;
                                            MSG = bulkImports.BulkInsertIssuerDataATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);
                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }
                                    }

                                }
                                catch (Exception ex)
                                {
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    //_logger.LogInformation("Error At Inserting data into Datatable : {ex} ", ex);
                                    ErrorCount++;
                                }

                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkImports.BulkInsertIssuerDataATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (fileImportRequest.ErrorMessage.Length == 0 && _DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        if (tempTxnDateTime.Length > 0)
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        }
                        else
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + " File is Empty OR DateTime Format not matched;  ";
                        }
                        MSG = fileImportRequest.ErrorMessage;
                    }                   
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string Splitter_ATM_Late_Reversal_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;

            bool ErrorOccurred = false;
            int SheetLineNo = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkImports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable(); 
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("StanNo", typeof(string));
            _DataTable.Columns.Add("ACQ", typeof(string));
            _DataTable.Columns.Add("ISS", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TerminalID", typeof(string));
            _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("ReceivedAmount", typeof(decimal));
            _DataTable.Columns.Add("LateReversalStatus", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            string TransType = string.Empty;
            string Resp_Code = string.Empty;
            string CardNo = string.Empty;
            string E_CardNumber = string.Empty;
            string RRN = string.Empty;
            string StanNo = string.Empty;
            string ACQ = string.Empty;
            string ISS = string.Empty;
            DateTime Trasn_DateTime;
            string TerminalID = string.Empty;
            DateTime? SettleDate;
            string Amount = "0";
            string ReceivedAmt = "0";
            string Status = string.Empty;
            string StrTrasn_DateTime = string.Empty;
            string StrSettleDate = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;

            DateTime? TxnsDateTimeMain = null;
            string[] TxnDateTimeFormat = null;
            string line1 = string.Empty;
            string Cycle = string.Empty;
            string TxnsDateTimeDiff = string.Empty;
            int Incr = 1;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";
            string ECardNumber = string.Empty;
            string SplitType = ",";



            ushort TransType_CoulmnIndex = 0;
            ushort Resp_Code_CoulmnIndex = 0;
            ushort CardNo_CoulmnIndex = 0; 
            ushort RRN_CoulmnIndex = 0;
            ushort StanNo_CoulmnIndex = 0;
            ushort ACQ_CoulmnIndex = 0;
            ushort ISS_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TerminalID_CoulmnIndex = 0;
            ushort SettleDate_CoulmnIndex = 0;
            ushort Amount_CoulmnIndex = 0;
            ushort ReceivedAmt_CoulmnIndex = 0;
            ushort Status_CoulmnIndex = 0;
            ushort StrTrasn_DateTime_CoulmnIndex = 0;
            ushort StrSettleDate_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;

            int ErrorCount = 0, LineNo = 0;

            string conString = string.Empty;
            DataTable dtexcelsheetname = new DataTable();
            DataTable dtSheet = new DataTable();

            try
            {
              
                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string strFileName = Path.GetFileNameWithoutExtension(fileImportRequest.Path);
                string FD = strFileName.Substring(strFileName.Length - 9);

                string[] FDA = FD.Split('_', '.');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                TransType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsType"]);
                Resp_Code_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode"]);
                CardNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CardNumber"]); 
                RRN_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                StanNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["StanNo"]);
                ACQ_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQ"]);
                ISS_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISS"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TerminalID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TerminalId"]);
                StrSettleDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SettlementDate"]);
                Amount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                ReceivedAmt_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReceivedAmount"]);
                Status_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["LateReversalStatus"]); 
                TxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);

                //Read the connection string for the Excel file.
                conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                conString = string.Format(conString, fileImportRequest.Path);
 
                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        // Get all sheet names
                        DataTable allSheets = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                        // Filter valid worksheet names (excluding hidden/system ones)
                        dtexcelsheetname = allSheets
                            .AsEnumerable()
                            .Where(row => row["TABLE_NAME"].ToString().EndsWith("$") && !row["TABLE_NAME"].ToString().Contains("_xlnm#"))
                            .CopyToDataTable();

                        connExcel.Close();
                    }
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTimeFormat Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;

                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {
                    int j = 0;
                    batchSize = bulkImports.GetBatchSize(DTdetails.ConfigID);  

                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }
                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = "SELECT * From [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                            Incr = 1;

                            if (dtSheet.Rows.Count > 1)
                            {
                                int dateStartIndex = -1;

                                for (int i = 0; i < dtSheet.Rows.Count; i++)
                                {
                                    try
                                    {
                                        if (TxnsDateTime_CoulmnIndex > 0)
                                        {
                                            tempTxnDateTime = dtSheet.Rows[i][TxnsDateTime_CoulmnIndex - Incr]?.ToString()?.Trim();

                                            bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                            if (isValid)
                                            {
                                                dateStartIndex = i;
                                                break;
                                            }
                                        }
                                        else if (TxnsDate_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                                        {
                                            tempTxnDateTime = dtSheet.Rows[i][TxnsDate_CoulmnIndex - Incr]?.ToString()?.Trim() + " " + dtSheet.Rows[i][TxnsTime_CoulmnIndex - Incr]?.ToString()?.Trim();

                                            bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                            if (isValid)
                                            {
                                                dateStartIndex = i;
                                                break;
                                            }
                                        }
                                    }
                                    catch
                                    {
                                        SheetDateError++;
                                    }

                                    if (i > 25)
                                        break;
                                    
                                }

                                if (dateStartIndex > 0)
                                {
                                    for (int k = 0; k < dtSheet.Rows.Count; k++)
                                    {
                                        LineNo++;
                                        SheetLineNo++;
                                        if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                        {
                                            continue;
                                        }
                                        try
                                        {
                                            TransType = string.Empty;
                                            Resp_Code = string.Empty;
                                            CardNo = string.Empty;
                                            RRN = string.Empty;
                                            StanNo = string.Empty;
                                            ACQ = string.Empty;
                                            ISS = string.Empty;
                                            TerminalID = string.Empty;
                                            Amount = "0";
                                            ReceivedAmt = "0";
                                            Status = string.Empty;

                                            TxnsDateTimeMain = null;



                                            TransType = TransType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TransType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Resp_Code = Resp_Code_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Resp_Code_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CardNo = CardNo_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CardNo_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            RRN = RRN_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][RRN_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            StanNo = StanNo_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][StanNo_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACQ = ACQ_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQ_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ISS = ISS_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISS_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            StrTrasn_DateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TerminalID = TerminalID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TerminalID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Amount = Amount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Amount_CoulmnIndex - Incr]).Trim() : "0";
                                            ReceivedAmt = ReceivedAmt_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReceivedAmt_CoulmnIndex - Incr]).Trim() : "0";
                                            Status = Status_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Status_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            StrSettleDate = StrSettleDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][StrSettleDate_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            TransType = TransType.Replace("'", "");
                                            Resp_Code = Resp_Code.Replace("'", "");
                                            CardNo = CardNo.Replace("'", "");
                                            RRN = RRN.Replace("'", "");
                                            StanNo = StanNo.Replace("`", "");
                                            ACQ = ACQ.Replace("'", "");
                                            ISS = ISS.Replace("'", "");
                                            TerminalID = TerminalID.Replace("'", "");
                                            Amount = Amount.Replace("'", "");
                                            ReceivedAmt = ReceivedAmt.Replace("'", "");
                                            Status = Status.Replace("'", "");

                                            TransType = TransType.Replace("`", "");
                                            Resp_Code = Resp_Code.Replace("`", "");
                                            CardNo = CardNo.Replace("`", "");
                                            RRN = RRN.Replace("`", "");
                                            StanNo = StanNo.Replace("`", "");
                                            ACQ = ACQ.Replace("`", "");
                                            ISS = ISS.Replace("`", "");
                                            TerminalID = TerminalID.Replace("`", "");
                                            Amount = Amount.Replace("`", "");
                                            ReceivedAmt = ReceivedAmt.Replace("`", "");
                                            Status = Status.Replace("`", "");

                                            TxnsDateTimeMain = null;


                                            if (TxnsDate.Length > 0 && TxnsTime.Length > 0)
                                            {
                                                TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;
                                            }
                                            else if (StrTrasn_DateTime.Length > 0)
                                            {
                                                TxnsDateTimeDiff = StrTrasn_DateTime;
                                            }

                                            try
                                            {
                                                if (TxnsDate.Contains("-") && TxnsTime.Contains(":"))
                                                {
                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, System.Globalization.CultureInfo.InvariantCulture);
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                TxnsDateTimeMain = null;
                                            }

                                            if (StrSettleDate.Length > 0)
                                            {
                                                try
                                                {
                                                    SettleDate = DateTime.ParseExact(StrSettleDate, new[] { "dd-MM-yyyy", "dd/MM/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None);
                                                }
                                                catch (Exception ex)
                                                {
                                                    SettleDate = null;
                                                }
                                            }
                                            else
                                            {
                                                SettleDate = null;
                                            }

                                            if (CardNo != "" && CardNo.Length == 16)
                                            {
                                                CardNo = CardNo.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNo.Length - 10) + CardNo.Substring(CardNo.Length - 4, 4).Trim();
                                            }

                                            if (CardNo != "")
                                            {
                                                ECardNumber = AesEncryption.EncryptString(CardNo);
                                            }

                                            if (TxnsDateTimeMain != null)
                                            {
                                                _DataTable.Rows.Add(
                                                    TransType,
                                                    Resp_Code,
                                                    CardNo,
                                                    RRN,
                                                    StanNo,
                                                    ACQ,
                                                    ISS,
                                                    TxnsDateTimeMain,
                                                    TerminalID,
                                                    SettleDate,
                                                    Amount,
                                                    ReceivedAmt,
                                                    Status,
                                                    ECardNumber
                                                     );

                                                if (_DataTable.Rows.Count >= batchSize)
                                                {
                                                    BatchNo++;
                                                    MSG = bulkImports.BulkInsertlateReversalATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                    BatchDetails batchDetailsPartial = new BatchDetails
                                                    {
                                                        BatchNo = BatchNo,
                                                        BatchSize = batchSize,
                                                        TxnUploadCount = _DataTable.Rows.Count,
                                                        TxnsCount = fileImportRequest.InsertCount,
                                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                        FailedCount = ErrorCount,
                                                        BatchStartTime = batchStartTime,
                                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                    };

                                                    batchDetailsList.Add(batchDetailsPartial);

                                                    _DataTable.Clear();
                                                    ErrorCount = 0;
                                                    StartTime = DateTime.Now;

                                                    if (NewEntry)
                                                    {
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            ErrorCount++;
                                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                        }
                                    }
                                }
                                else
                                {
                                    if (j == 0 || _DataTable.Rows.Count == 0)
                                    {
                                        BatchNo++; 

                                        if (tempTxnDateTime.Length > 0)
                                        {
                                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                                        }
                                        else
                                        {
                                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + " File is Empty OR DateTime Format not matched;  ";
                                        }
                                        MSG = fileImportRequest.ErrorMessage;
                                    }
                                    break;
                                }
                            }
                        }

                        LineNo = 0;
                    }
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkImports.BulkInsertlateReversalATM(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = _DataTable.Rows.Count,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }


        string ExtractNumber(string original)
        {
            return new string(original.Where(c => Char.IsDigit(c)).ToArray());
        }

    }


}
