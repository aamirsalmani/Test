﻿
using DocumentFormat.OpenXml.Spreadsheet;
using ImportData;
using System; 
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml;
using Utility;

namespace NetworkNPCI
{
    public class NPCIIMPS
    {
        private readonly string _connectionString;
        BulkImports bulkimports;
        public NPCIIMPS(string connectionString)
        {
            _connectionString = connectionString;
            bulkimports = new BulkImports(_connectionString, "", "");
        }

        public string Splitter_IMPS_Adjustment_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            int LineNo = 0;
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            bool ErrorOccurred = false;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("TxnUID", typeof(string));
            _DataTable.Columns.Add("UID", typeof(string));
            _DataTable.Columns.Add("AdjDate", typeof(DateTime));
            _DataTable.Columns.Add("AdjType", typeof(string));
            _DataTable.Columns.Add("Remitter", typeof(string));
            _DataTable.Columns.Add("Beneficiery", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("TxnDateTime", typeof(DateTime));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TerminalID", typeof(string));
            _DataTable.Columns.Add("Ben_Mobile_No", typeof(string));
            _DataTable.Columns.Add("Rem_Mobile_No", typeof(string));
            _DataTable.Columns.Add("ChargebackDate", typeof(DateTime));
            _DataTable.Columns.Add("Chbref", typeof(string));
            _DataTable.Columns.Add("TxnAmount", typeof(decimal));
            _DataTable.Columns.Add("AdjAmount", typeof(decimal));
            _DataTable.Columns.Add("Rem_Fee", typeof(decimal));
            _DataTable.Columns.Add("Ben_Fee", typeof(decimal));
            _DataTable.Columns.Add("BenFeeSW", typeof(decimal));
            _DataTable.Columns.Add("AdjFee", typeof(decimal));
            _DataTable.Columns.Add("NPCIFee", typeof(decimal));
            _DataTable.Columns.Add("RemFeeGST", typeof(decimal));
            _DataTable.Columns.Add("BenFeeGST", typeof(decimal));
            _DataTable.Columns.Add("NPCIGST", typeof(decimal));
            _DataTable.Columns.Add("AdjRef", typeof(string));
            _DataTable.Columns.Add("BankAdjRef", typeof(string));
            _DataTable.Columns.Add("AdjProof", typeof(string));
            _DataTable.Columns.Add("Cust_Comp", typeof(string));
            _DataTable.Columns.Add("Adj_Raise_Time", typeof(string));
            _DataTable.Columns.Add("SHDT72", typeof(string));
            _DataTable.Columns.Add("SHDT73", typeof(string));
            _DataTable.Columns.Add("SHDT74", typeof(string));
            _DataTable.Columns.Add("SHDT75", typeof(string));
            _DataTable.Columns.Add("SHDT76", typeof(string));
            _DataTable.Columns.Add("SHDT77", typeof(string));
            _DataTable.Columns.Add("status", typeof(string));



            string TxnUID = string.Empty;
            string UID = string.Empty;
            DateTime? AdjDate = null;
            string AdjType = string.Empty;
            string Remitter = string.Empty;
            string Beneficiery = string.Empty;
            string ResponseCode = string.Empty;
            string TxnDateTime = string.Empty;
            string ReferenceNumber = string.Empty;
            string TerminalID = string.Empty;
            string Ben_Mobile_No = string.Empty;
            string Rem_Mobile_No = string.Empty;
            DateTime? ChargebackDate = null;
            string Chbref = string.Empty;
            string TxnAmount = string.Empty;
            string AdjAmount = string.Empty;
            string Rem_Fee = string.Empty;
            string Ben_Fee = string.Empty;
            string BenFeeSW = string.Empty;
            string AdjFee = string.Empty;
            string NPCIFee = string.Empty;
            string RemFeeGST = string.Empty;
            string BenFeeGST = string.Empty;
            string NPCIGST = string.Empty;
            string AdjRef = string.Empty;
            string BankAdjRef = string.Empty;
            string AdjProof = string.Empty;
            string Cust_Comp = string.Empty;
            string Adj_Raise_Time = string.Empty;
            string SHDT72 = string.Empty;
            string SHDT73 = string.Empty;
            string SHDT74 = string.Empty;
            string SHDT75 = string.Empty;
            string SHDT76 = string.Empty;
            string SHDT77 = string.Empty;
            string status = string.Empty;
            string TransDate = string.Empty;
            string TransTime = string.Empty;

            ushort TxnUID_CoulmnIndex = 0;
            ushort UID_CoulmnIndex = 0;
            ushort AdjDate_CoulmnIndex = 0;
            ushort AdjType_CoulmnIndex = 0;
            ushort Remitter_CoulmnIndex = 0;
            ushort Beneficiery_CoulmnIndex = 0;
            ushort ResponseCode_CoulmnIndex = 0;
            ushort TxnDateTime_CoulmnIndex = 0;
            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort TerminalID_CoulmnIndex = 0;
            ushort Ben_Mobile_No_CoulmnIndex = 0;
            ushort Rem_Mobile_No_CoulmnIndex = 0;
            ushort ChargebackDate_CoulmnIndex = 0;
            ushort Chbref_CoulmnIndex = 0;
            ushort TxnAmount_CoulmnIndex = 0;
            ushort AdjAmount_CoulmnIndex = 0;
            ushort Rem_Fee_CoulmnIndex = 0;
            ushort Ben_Fee_CoulmnIndex = 0;
            ushort BenFeeSW_CoulmnIndex = 0;
            ushort AdjFee_CoulmnIndex = 0;
            ushort NPCIFee_CoulmnIndex = 0;
            ushort RemFeeGST_CoulmnIndex = 0;
            ushort BenFeeGST_CoulmnIndex = 0;
            ushort NPCIGST_CoulmnIndex = 0;
            ushort AdjRef_CoulmnIndex = 0;
            ushort BankAdjRef_CoulmnIndex = 0;
            ushort AdjProof_CoulmnIndex = 0;
            ushort Cust_Comp_CoulmnIndex = 0;
            ushort Adj_Raise_Time_CoulmnIndex = 0;
            ushort SHDT72_CoulmnIndex = 0;
            ushort SHDT73_CoulmnIndex = 0;
            ushort SHDT74_CoulmnIndex = 0;
            ushort SHDT75_CoulmnIndex = 0;
            ushort SHDT76_CoulmnIndex = 0;
            ushort SHDT77_CoulmnIndex = 0;
            ushort status_CoulmnIndex = 0;
            ushort TransDate_CoulmnIndex = 0;
            ushort TransTime_CoulmnIndex = 0;


            DateTime? TxnsDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;
            string tempAdjDate = string.Empty;
            string ChargebackDate1 = string.Empty;

            int Incr = 1;

            string[] TxnsDateTime = null;
            string Cycle = string.Empty;

            int ErrorCount = 0;

            string conString = string.Empty;
            DataTable dtexcelsheetname = new DataTable();
            DataTable dtSheet = new DataTable();

            try
            {
                DataSet ds = new DataSet();

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string[] FDA = Path.GetFileNameWithoutExtension(fileImportRequest.FileName).Split('_');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                TxnsDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);


                TxnUID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnUID"]);
                UID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UID"]);
                AdjDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjDate"]);
                AdjType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjType"]);
                Remitter_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remitter"]);
                Beneficiery_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Beneficiery"]);
                ResponseCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode"]);
                TxnDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnDateTime"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                TerminalID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TerminalID"]);
                Ben_Mobile_No_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Ben_Mobile_No"]);
                Rem_Mobile_No_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Rem_Mobile_No"]);
                ChargebackDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChargebackDate"]);
                Chbref_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Chbref"]);
                TxnAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnAmount"]);
                AdjAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjAmount"]);
                Rem_Fee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Rem_Fee"]);
                Ben_Fee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Ben_Fee"]);
                BenFeeSW_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BenFeeSW"]);
                AdjFee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjFee"]);
                NPCIFee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NPCIFee"]);
                RemFeeGST_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RemFeeGST"]);
                BenFeeGST_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BenFeeGST"]);
                NPCIGST_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NPCIGST"]);
                AdjRef_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjRef"]);
                BankAdjRef_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BankAdjRef"]);
                AdjProof_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjProof"]);
                Cust_Comp_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Cust_Comp"]);
                Adj_Raise_Time_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Adj_Raise_Time"]);
                SHDT72_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT72"]);
                SHDT73_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT73"]);
                SHDT74_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT74"]);
                SHDT75_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT75"]);
                SHDT76_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT76"]);
                SHDT77_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT77"]);
                status_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["status"]);
                TransTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TransDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);


                //Read the connection string for the Excel file.
                conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                conString = string.Format(conString, fileImportRequest.Path);

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }


            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");


            if (!ErrorOccurred)
            {
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {
                    int SheetLineNumber = 0;

                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }

                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = "SELECT * From [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }



                            Incr = 1;

                            if (dtSheet.Rows.Count > 0)
                            {
                                fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                for (int k = 0; k < dtSheet.Rows.Count; k++)
                                {
                                    LineNo++;
                                    SheetLineNumber++;
                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }
                                    try
                                    {

                                        TxnUID = string.Empty;
                                        UID = string.Empty;
                                        AdjDate = null;
                                        AdjType = string.Empty;
                                        Remitter = string.Empty;
                                        Beneficiery = string.Empty;
                                        ResponseCode = string.Empty;
                                        TxnDateTime = string.Empty;
                                        ReferenceNumber = string.Empty;
                                        TerminalID = string.Empty;
                                        Ben_Mobile_No = string.Empty;
                                        Rem_Mobile_No = string.Empty;
                                        ChargebackDate = null;
                                        Chbref = string.Empty;
                                        TxnAmount = string.Empty;
                                        AdjAmount = string.Empty;
                                        Rem_Fee = string.Empty;
                                        Ben_Fee = string.Empty;
                                        BenFeeSW = string.Empty;
                                        AdjFee = string.Empty;
                                        NPCIFee = string.Empty;
                                        RemFeeGST = string.Empty;
                                        BenFeeGST = string.Empty;
                                        NPCIGST = string.Empty;
                                        AdjRef = string.Empty;
                                        BankAdjRef = string.Empty;
                                        AdjProof = string.Empty;
                                        Cust_Comp = string.Empty;
                                        Adj_Raise_Time = string.Empty;
                                        SHDT72 = string.Empty;
                                        SHDT73 = string.Empty;
                                        SHDT74 = string.Empty;
                                        SHDT75 = string.Empty;
                                        SHDT76 = string.Empty;
                                        SHDT77 = string.Empty;
                                        status = string.Empty;
                                        TransTime = string.Empty;
                                        TransDate = string.Empty;
                                        tempAdjDate = string.Empty;
                                        ChargebackDate1 = string.Empty;

                                        TxnsDateTimeMain = null;

                                        TxnUID = TxnUID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnUID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        UID = UID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][UID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        tempAdjDate = AdjDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjDate_CoulmnIndex - Incr]).Trim() : string.Empty;

                                        AdjType = AdjType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Remitter = Remitter_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Remitter_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Beneficiery = Beneficiery_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Beneficiery_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        ResponseCode = ResponseCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnDateTime = TxnDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TerminalID = TerminalID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TerminalID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Ben_Mobile_No = Ben_Mobile_No_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Ben_Mobile_No_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Rem_Mobile_No = Rem_Mobile_No_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Rem_Mobile_No_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        ChargebackDate1 = ChargebackDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ChargebackDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Chbref = Chbref_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Chbref_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnAmount = TxnAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        AdjAmount = AdjAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Rem_Fee = Rem_Fee_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Rem_Fee_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Ben_Fee = Ben_Fee_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Ben_Fee_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        BenFeeSW = BenFeeSW_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BenFeeSW_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        AdjFee = AdjFee_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjFee_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        NPCIFee = NPCIFee_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][NPCIFee_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        RemFeeGST = RemFeeGST_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][RemFeeGST_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        BenFeeGST = BenFeeGST_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BenFeeGST_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        NPCIGST = NPCIGST_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][NPCIGST_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        AdjRef = AdjRef_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjRef_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        BankAdjRef = BankAdjRef_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BankAdjRef_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        AdjProof = AdjProof_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AdjProof_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Cust_Comp = Cust_Comp_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Cust_Comp_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Adj_Raise_Time = Adj_Raise_Time_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Adj_Raise_Time_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        SHDT72 = SHDT72_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SHDT72_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        SHDT73 = SHDT73_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SHDT73_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        SHDT74 = SHDT74_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SHDT74_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        SHDT75 = SHDT75_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SHDT75_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        SHDT76 = SHDT76_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SHDT76_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        SHDT77 = SHDT77_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SHDT77_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        status = status_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][status_CoulmnIndex - Incr]).Trim() : string.Empty;

                                        TransDate = TransDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TransDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TransTime = TransTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TransTime_CoulmnIndex - Incr]).Trim() : string.Empty;

                                        TxnAmount = Common.IsNumeric(TxnAmount) ? TxnAmount : "0";
                                        AdjAmount = Common.IsNumeric(AdjAmount) ? AdjAmount : "0";
                                        Rem_Fee = Common.IsNumeric(Rem_Fee) ? Rem_Fee : "0";
                                        Ben_Fee = Common.IsNumeric(Ben_Fee) ? Ben_Fee : "0";
                                        BenFeeSW = Common.IsNumeric(BenFeeSW) ? BenFeeSW : "0";
                                        AdjFee = Common.IsNumeric(AdjFee) ? AdjFee : "0";
                                        NPCIFee = Common.IsNumeric(NPCIFee) ? NPCIFee : "0";
                                        RemFeeGST = Common.IsNumeric(RemFeeGST) ? RemFeeGST : "0";
                                        BenFeeGST = Common.IsNumeric(BenFeeGST) ? BenFeeGST : "0";
                                        NPCIGST = Common.IsNumeric(NPCIGST) ? NPCIGST : "0";

                                        TxnUID = TxnUID.Replace("'", "");
                                        TxnUID = TxnUID.Replace("=", "");
                                        TxnUID = TxnUID.Replace("\"\"", "");
                                        TxnUID = TxnUID.Replace("\"", "");

                                        UID = UID.Replace("'", "");
                                        UID = UID.Replace("=", "");
                                        UID = UID.Replace("\"\"", "");
                                        UID = UID.Replace("\"", "");

                                        ResponseCode = ResponseCode.Replace("'", "");
                                        ResponseCode = ResponseCode.Replace("=", "");
                                        ResponseCode = ResponseCode.Replace("\"\"", "");
                                        ResponseCode = ResponseCode.Replace("\"", "");

                                        ReferenceNumber = ReferenceNumber.Replace("'", "");
                                        ReferenceNumber = ReferenceNumber.Replace("=", "");
                                        ReferenceNumber = ReferenceNumber.Replace("\"\"", "");
                                        ReferenceNumber = ReferenceNumber.Replace("\"", "");

                                        Ben_Mobile_No = Ben_Mobile_No.Replace("'", "");
                                        Ben_Mobile_No = Ben_Mobile_No.Replace("\"", "");

                                        Rem_Mobile_No = Rem_Mobile_No.Replace("'", "");
                                        Rem_Mobile_No = Rem_Mobile_No.Replace("\"", "");

                                        BankAdjRef = BankAdjRef.Replace("'", "");
                                        BankAdjRef = BankAdjRef.Replace("\"", "");

                                        if (TxnsDateTime.Length > 0 && TransDate.Length > 0 && TransTime.Length > 0)
                                        {
                                            if (TransDate.Length > 10)
                                            {
                                                string[] TD = TransDate.Split(" ");
                                                if (TD.Length > 1)
                                                {
                                                    TransDate = TD[0];
                                                }
                                            }

                                            if (TransTime.Length > 8)
                                            {
                                                string[] TM = TransTime.Split(" ");
                                                if (TM.Length > 1)
                                                {
                                                    TransTime = TM[1];
                                                }
                                                if (TM.Length > 2)
                                                {
                                                    TransTime = TransTime + " " + TM[2];
                                                }
                                            }

                                            TxnsDateTimeDiff = TransDate + " " + TransTime;

                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnsDateTime, CultureInfo.InvariantCulture);
                                        }
                                        else if (TxnsDateTime.Length > 0 && TxnDateTime.Length > 0)
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnDateTime, TxnsDateTime, CultureInfo.InvariantCulture);
                                        }

                                        if (tempAdjDate.Length > 0 && tempAdjDate.Length > 15)
                                        {
                                            try
                                            {
                                                AdjDate = DateTime.ParseExact(tempAdjDate, new[] { "d-MM-yyyy HH:mm:ss", "d-MMM-yyyy HH:mm:ss", "d-MM-yy HH:mm:ss", "d-MMM-yy HH:mm:ss", "d/MM/yyyy HH:mm:ss", "d/MMM/yyyy HH:mm:ss", "d/MM/yy HH:mm:ss", "d/MMM/yy HH:mm:ss", }, null);
                                            }
                                            catch
                                            { }
                                        }
                                        else if (tempAdjDate.Length > 0)
                                        {
                                            try
                                            {
                                                AdjDate = DateTime.ParseExact(tempAdjDate, new[] { "d-MM-yyyy", "d-MMM-yyyy", "d-MM-yy", "d-MMM-yy", "d/MM/yyyy", "d/MMM/yyyy", "d/MM/yy", "d/MMM/yy" }, null);
                                            }
                                            catch
                                            { }
                                        }

                                        if (ChargebackDate1.Contains("-") || ChargebackDate1.Length == 1)
                                        {
                                            ChargebackDate = null;
                                        }
                                        else
                                        {
                                            try
                                            {
                                                if (tempAdjDate.Length > 0 && tempAdjDate.Length <= 15 && tempAdjDate.Length > 4)
                                                {
                                                    ChargebackDate = DateTime.ParseExact(ChargebackDate1, new[] { "d-MM-yyyy", "d-MMM-yyyy", "d-MM-yy", "d-MMM-yy", "d/MM/yyyy", "d/MMM/yyyy", "d/MM/yy", "d/MMM/yy" }, null);
                                                }
                                            }
                                            catch
                                            { }
                                        }

                                        if (TxnsDateTimeMain != null)
                                        {
                                            _DataTable.Rows.Add(
                                                TxnUID,
                                                UID,
                                                AdjDate,
                                                AdjType,
                                                Remitter,
                                                Beneficiery,
                                                ResponseCode,
                                                TxnsDateTimeMain,
                                                ReferenceNumber,
                                                TerminalID,
                                                Ben_Mobile_No,
                                                Rem_Mobile_No,
                                                ChargebackDate,
                                                Chbref,
                                                TxnAmount,
                                                AdjAmount,
                                                Rem_Fee,
                                                Ben_Fee,
                                                BenFeeSW,
                                                AdjFee,
                                                NPCIFee,
                                                RemFeeGST,
                                                BenFeeGST,
                                                NPCIGST,
                                                AdjRef,
                                                BankAdjRef,
                                                AdjProof,
                                                Cust_Comp,
                                                Adj_Raise_Time,
                                                SHDT72,
                                                SHDT73,
                                                SHDT74,
                                                SHDT75,
                                                SHDT76,
                                                SHDT77,
                                                status
                                                );

                                            if (_DataTable.Rows.Count >= batchSize)
                                            {
                                                BatchNo++;
                                                MSG = bulkimports.BulkInsertNPCIAdjustmentIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                BatchDetails batchDetails = new BatchDetails
                                                {
                                                    BatchNo = BatchNo,
                                                    BatchSize = batchSize,
                                                    TxnUploadCount = _DataTable.Rows.Count,
                                                    TxnsCount = fileImportRequest.InsertCount,
                                                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                    FailedCount = ErrorCount,
                                                    BatchStartTime = batchStartTime,
                                                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                };

                                                batchDetailsList.Add(batchDetails);
                                                _DataTable.Clear();
                                                ErrorCount = 0;
                                                StartTime = DateTime.Now;

                                                if (NewEntry)
                                                {
                                                    break;
                                                }
                                            }

                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorCount++;
                                        DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    }
                                }
                            }
                            else
                            {
                                fileImportRequest.ErrorMessage = "File contains no records";
                            }
                        }
                        LineNo = 0;
                    }
                }
            }

            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkimports.BulkInsertNPCIAdjustmentIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                //_logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
            {
                MSG = "Successful";
            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }

        public string Splitter_IMPS_Adjustment_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DataTable _DataTable = new DataTable();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            string MSG = "";
            fileImportRequest.ErrorMessage = string.Empty;

            fileImportRequest.FinalBatchDetails = "None";

            return MSG;
        }

        public string Splitter_IMPS_Issuer_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            bool ErrorOccurred = false;
            int LineNumber = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;
            DtDetails DTdetails = new DtDetails();
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(bool));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));
            //New Added
            _DataTable.Columns.Add("ORIGINALCHANNEL", typeof(string));
            _DataTable.Columns.Add("BeneIFSCCODE", typeof(string));
            _DataTable.Columns.Add("BeneAccountNumber", typeof(string));
            _DataTable.Columns.Add("REMIFSCCODE", typeof(string));
            _DataTable.Columns.Add("REMACCOUNTNUMBER", typeof(string));

            int Incr = 1;
            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string MEMNUMBER = string.Empty;
            string Approval_Number = string.Empty;
            string STAUDITNO = "0";
            string TransDate = string.Empty;
            string Transaction_Time = string.Empty;
            string Merchant_Category_Code = string.Empty;
            string CARDACCEPTSETDATE = string.Empty;
            string Card_Acceptor_ID = string.Empty;
            string CARDACCEPTTERMINALID = string.Empty;
            string CARDACCEPTERTERLOCATION = string.Empty;
            string Acquirer_ID = string.Empty;
            string NETWORKID = string.Empty;
            string Ben_Account_Number = string.Empty;
            string Bene_IFSC_CODE = string.Empty;
            string REM_ACCOUNT_NUMBER = string.Empty;
            string REM_IFSC_CODE = string.Empty;
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = "0";
            string ACCTUALTRANAMOUNT = "0";
            string TRANSACCVITYFEE = "0";
            string ISSUERSETCURRENCYCODE = string.Empty;
            string ISSURESETAMOUNT = "0";
            string ISSUERSETFEE = "0";
            string ISSURESETPROCFEE = "0";
            string CARDHOLDERBILLCURNCCODE = string.Empty;
            string CARDHOLDERBILLAMOUNT = "0";
            string CARDHOLDERBILACTFEE = "0";
            string CARDHOLDERBILPROFEE = "0";
            string CARDHOLDERBILSRVICEFEE = "0";
            string TRAN_ISSUERCONVERSRATE = "0";
            string TRANS_CARDHOLDERCONVERRATE = "0";

            //New Added
            string ORIGINALCHANNEL = string.Empty;
            string BeneIFSCCODE = string.Empty;
            string BeneAccountNumber = string.Empty;
            string REMIFSCCODE = string.Empty;
            string REMACCOUNTNUMBER = string.Empty;



            ushort PARTICIPENTID_CoulmnIndex = 0;
            ushort TRANSTYPE_CoulmnIndex = 0;
            ushort FROMACCOUNTTYPE_CoulmnIndex = 0;
            ushort TOACCOUNTTYPE_CoulmnIndex = 0;
            ushort TRANSSERIALNO_CoulmnIndex = 0;
            ushort RESPONSECODE_CoulmnIndex = 0;
            ushort PAN_Number_CoulmnIndex = 0;
            ushort MEMNUMBER_CoulmnIndex = 0;
            ushort APPROVALNO_CoulmnIndex = 0;
            ushort STAUDITNO_CoulmnIndex = 0;
            ushort TRANSDATE_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;
            ushort MERCHENTCATCODE_CoulmnIndex = 0;
            ushort CARDACCEPTERSETDATE_CoulmnIndex = 0;
            ushort CARDACCEPTERID_CoulmnIndex = 0;
            ushort CARDACCEPTTERMINALID_CoulmnIndex = 0;
            ushort CARDACCEPTERTERLOCATION_CoulmnIndex = 0;
            ushort ACQUIRERID_CoulmnIndex = 0;
            ushort NETWORKID_CoulmnIndex = 0;
            ushort ACCOUNTNO1_CoulmnIndex = 0;
            ushort ACCOUNTBRANCHID_CoulmnIndex = 0;
            ushort ACCOUNTNO2_CoulmnIndex = 0;
            ushort ACCOUNT2BRANCHID_CoulmnIndex = 0;


            ushort TRANSCURCODE_CoulmnIndex = 0;
            ushort TRANSAMOUNT_CoulmnIndex = 0;
            ushort ACCTUALTRANSAMOUNT_CoulmnIndex = 0;
            ushort TRANSACCVITYFEE_CoulmnIndex = 0;
            ushort ISSUERSETCURRENCYCODE_CoulmnIndex = 0;
            ushort ISSURESETAMOUNT_CoulmnIndex = 0;
            ushort ISSUERSETFEE_CoulmnIndex = 0;
            ushort ISSURESETPROCFEE_CoulmnIndex = 0;


            ushort CARDHOLDERBILLCURNCCODE_CoulmnIndex = 0;
            ushort CARDHOLDERBILLAMOUNT_CoulmnIndex = 0;
            ushort CARDHOLDERBILACTFEE_CoulmnIndex = 0;
            ushort CARDHOLDERBILPROFEE_CoulmnIndex = 0;
            ushort CARDHOLDERBILSRVICEFEE_CoulmnIndex = 0;
            ushort TRAN_ISSUERCONVERSRATE_CoulmnIndex = 0;
            ushort TRANS_CARDHOLDERCONVERRATE_CoulmnIndex = 0;


            //New Added
            ushort ORIGINALCHANNEL_CoulmnIndex = 0;
            ushort BeneIFSCCODE_CoulmnIndex = 0;
            ushort BeneAccountNumber_CoulmnIndex = 0;
            ushort REMIFSCCODE_CoulmnIndex = 0;
            ushort REMACCOUNTNUMBER_CoulmnIndex = 0;



            string timestamp = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            bool FORCEMATCH = false;

            string[] SplitArr = null;
            string[] TxnDateTimeFormat = null;
            string line1 = string.Empty;
            string Cycle = string.Empty;

            int ErrorCount = 0, LineNo = 0;
            int largestIndex = 0, CoulmnIndex = 0;

            int TxnAmountIsDecimal = 0;
            double temp = 0;

            try
            {
                DataSet ds = new DataSet();

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string[] FDA = fileImportRequest.FileName.Split('_', '.');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty; 

                PARTICIPENTID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PARICIPATEID"]);
                TRANSTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONTYPE"]);
                FROMACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FROMACCOUNTTYPE"]);
                TOACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TOACCOUNTTYPE"]);
                TRANSSERIALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSSERIALNO"]);
                RESPONSECODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RESPONSECODE"]);
                PAN_Number_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PANNUMBER"]);
                MEMNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MEMNUMBER"]);
                APPROVALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["APPROVNO"]);
                STAUDITNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["STAUDITNO"]);
                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONDATE"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONTIME"]);
                MERCHENTCATCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MERCHENTCATCODE"]);
                CARDACCEPTERSETDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTSETDATE"]);
                CARDACCEPTERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTORID"]);
                CARDACCEPTTERMINALID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTTERMINALID"]);
                CARDACCEPTERTERLOCATION_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERTERLOCATION"]);
                ACQUIRERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIRERID"]);
                NETWORKID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NETWORKID"]);
                ACCOUNTNO1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTNO1"]);
                ACCOUNTBRANCHID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTBRANCHID"]);
                ACCOUNTNO2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTNO2"]);
                ACCOUNT2BRANCHID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNT2BRANCHID"]);

                TRANSCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSCURRENCYCODE"]);
                TRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSAMOUNT"]);
                ACCTUALTRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANAMOUNT"]);
                TRANSACCVITYFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACCVITYFEE"]);
                ISSUERSETCURRENCYCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSUERSETCURRENCYCODE"]);
                ISSURESETAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSURESETAMOUNT"]);
                ISSUERSETFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSUERSETFEE"]);
                ISSURESETPROCFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSURESETPROCFEE"]);

                CARDHOLDERBILLCURNCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILLCURNCCODE"]);
                CARDHOLDERBILLAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILLAMOUNT"]);
                CARDHOLDERBILACTFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILACTFEE"]);
                CARDHOLDERBILPROFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILPROFEE"]);
                CARDHOLDERBILSRVICEFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILSRVICEFEE"]);
                TRAN_ISSUERCONVERSRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRAN_ISSUERCONVERSRATE"]);
                TRANS_CARDHOLDERCONVERRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANS_CARDHOLDERCONVERRATE"]);



                //New Added 
                ORIGINALCHANNEL_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ORIGINALCHANNEL"]);
                BeneIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneIFSCCODE"]);
                BeneAccountNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneAccountNumber"]);
                REMIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["REMIFSCCODE"]);
                REMACCOUNTNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["REMACCOUNTNUMBER"]);

                TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                TxnAmountIsDecimal = Convert.ToInt32(fileImportRequest.ConfigData.Rows[0]["TxnAmountIsDecimal"]);

                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;

                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            SplitArr = new string[0];

                            SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            if (TRANSDATE_CoulmnIndex > 0 && TRANSTIME_CoulmnIndex > 0)
                            {
                                TransDate = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;
                                tempTxnDateTime = TransDate + " " + Transaction_Time;
                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }
                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                if (LineNo < dateStartIndex)
                                {
                                    LineNumber++;
                                    LineNo++;
                                    continue;
                                }

                                LineNo++;

                                if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                {
                                    continue;
                                }

                                try
                                {
                                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                    SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                    if (SplitArr.Length < largestIndex) continue;

                                    LineNumber++;

                                    Participant_ID = string.Empty;
                                    Transaction_Type = string.Empty;
                                    From_Account_Type = string.Empty; ;
                                    To_Account_Type = string.Empty;
                                    Transaction_Serial_Number = string.Empty;
                                    Response_Code = string.Empty;
                                    PAN_Number = string.Empty;
                                    MEMNUMBER = string.Empty;
                                    Approval_Number = string.Empty;


                                    //DateTime  Transaction_Date ;//= string.Empty;
                                    Transaction_Time = "0";
                                    Merchant_Category_Code = "0";
                                    Acquirer_ID = string.Empty;
                                    Transaction_Amount = "0";
                                    ACCTUALTRANAMOUNT = "0";
                                    TRANSACCVITYFEE = "0";
                                    ISSUERSETCURRENCYCODE = string.Empty;
                                    ISSURESETAMOUNT = "0";
                                    ISSUERSETFEE = "0";
                                    ISSURESETPROCFEE = "0";
                                    CARDHOLDERBILLCURNCCODE = string.Empty;
                                    CARDHOLDERBILLAMOUNT = "0";
                                    CARDHOLDERBILACTFEE = "0";
                                    CARDHOLDERBILPROFEE = "0";
                                    CARDHOLDERBILSRVICEFEE = "0";
                                    TRAN_ISSUERCONVERSRATE = "0";
                                    TRANS_CARDHOLDERCONVERRATE = "0";
                                    CARDACCEPTSETDATE = "0";
                                    STAUDITNO = "0";
                                    timestamp = string.Empty;
                                    temp = 0;


                                    //New Added
                                    ORIGINALCHANNEL = string.Empty;
                                    BeneIFSCCODE = string.Empty;
                                    BeneAccountNumber = string.Empty;
                                    REMIFSCCODE = string.Empty;
                                    REMACCOUNTNUMBER = string.Empty;

                                    TxnsDateTimeMain = null;

                                    Participant_ID = PARTICIPENTID_CoulmnIndex > 0 ? SplitArr[PARTICIPENTID_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Type = TRANSTYPE_CoulmnIndex > 0 ? SplitArr[TRANSTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    From_Account_Type = FROMACCOUNTTYPE_CoulmnIndex > 0 ? SplitArr[FROMACCOUNTTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    To_Account_Type = TOACCOUNTTYPE_CoulmnIndex > 0 ? SplitArr[TOACCOUNTTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Serial_Number = TRANSSERIALNO_CoulmnIndex > 0 ? SplitArr[TRANSSERIALNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Response_Code = RESPONSECODE_CoulmnIndex > 0 ? SplitArr[RESPONSECODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    PAN_Number = PAN_Number_CoulmnIndex > 0 ? SplitArr[PAN_Number_CoulmnIndex - Incr].Trim() : string.Empty;

                                    MEMNUMBER = MEMNUMBER_CoulmnIndex > 0 ? SplitArr[MEMNUMBER_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Approval_Number = APPROVALNO_CoulmnIndex > 0 ? SplitArr[APPROVALNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    STAUDITNO = STAUDITNO_CoulmnIndex > 0 ? SplitArr[STAUDITNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Merchant_Category_Code = MERCHENTCATCODE_CoulmnIndex > 0 ? SplitArr[MERCHENTCATCODE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    CARDACCEPTSETDATE = CARDACCEPTERSETDATE_CoulmnIndex > 0 ? SplitArr[CARDACCEPTERSETDATE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Card_Acceptor_ID = CARDACCEPTERID_CoulmnIndex > 0 ? SplitArr[CARDACCEPTERID_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDACCEPTTERMINALID = CARDACCEPTTERMINALID_CoulmnIndex > 0 ? SplitArr[CARDACCEPTTERMINALID_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDACCEPTERTERLOCATION = CARDACCEPTERTERLOCATION_CoulmnIndex > 0 ? SplitArr[CARDACCEPTERTERLOCATION_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Acquirer_ID = ACQUIRERID_CoulmnIndex > 0 ? SplitArr[ACQUIRERID_CoulmnIndex - Incr].Trim() : string.Empty;
                                    NETWORKID = NETWORKID_CoulmnIndex > 0 ? SplitArr[NETWORKID_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Transaction_Currency_Code = TRANSCURCODE_CoulmnIndex > 0 ? SplitArr[TRANSCURCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Amount = TRANSAMOUNT_CoulmnIndex > 0 ? SplitArr[TRANSAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCTUALTRANAMOUNT = ACCTUALTRANSAMOUNT_CoulmnIndex > 0 ? SplitArr[ACCTUALTRANSAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TRANSACCVITYFEE = TRANSACCVITYFEE_CoulmnIndex > 0 ? SplitArr[TRANSACCVITYFEE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    ISSUERSETCURRENCYCODE = ISSUERSETCURRENCYCODE_CoulmnIndex > 0 ? SplitArr[ISSUERSETCURRENCYCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ISSURESETAMOUNT = ISSURESETAMOUNT_CoulmnIndex > 0 ? SplitArr[ISSURESETAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ISSUERSETFEE = ISSUERSETFEE_CoulmnIndex > 0 ? SplitArr[ISSUERSETFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ISSURESETPROCFEE = ISSURESETPROCFEE_CoulmnIndex > 0 ? SplitArr[ISSURESETPROCFEE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    CARDHOLDERBILLCURNCCODE = CARDHOLDERBILLCURNCCODE_CoulmnIndex > 0 ? SplitArr[CARDHOLDERBILLCURNCCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDHOLDERBILLAMOUNT = CARDHOLDERBILLAMOUNT_CoulmnIndex > 0 ? SplitArr[CARDHOLDERBILLAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDHOLDERBILACTFEE = CARDHOLDERBILACTFEE_CoulmnIndex > 0 ? SplitArr[CARDHOLDERBILACTFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDHOLDERBILPROFEE = CARDHOLDERBILPROFEE_CoulmnIndex > 0 ? SplitArr[CARDHOLDERBILPROFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    CARDHOLDERBILSRVICEFEE = CARDHOLDERBILSRVICEFEE_CoulmnIndex > 0 ? SplitArr[CARDHOLDERBILSRVICEFEE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    TRAN_ISSUERCONVERSRATE = TRAN_ISSUERCONVERSRATE_CoulmnIndex > 0 ? SplitArr[TRAN_ISSUERCONVERSRATE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TRANS_CARDHOLDERCONVERRATE = TRANS_CARDHOLDERCONVERRATE_CoulmnIndex > 0 ? SplitArr[TRANS_CARDHOLDERCONVERRATE_CoulmnIndex - Incr].Trim() : string.Empty;


                                    //New Added
                                    ORIGINALCHANNEL = ORIGINALCHANNEL_CoulmnIndex > 0 ? SplitArr[ORIGINALCHANNEL_CoulmnIndex - Incr].Trim() : string.Empty;
                                    BeneIFSCCODE = BeneIFSCCODE_CoulmnIndex > 0 ? SplitArr[BeneIFSCCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    BeneAccountNumber = BeneAccountNumber_CoulmnIndex > 0 ? SplitArr[BeneAccountNumber_CoulmnIndex - Incr].Trim() : string.Empty;
                                    REMIFSCCODE = REMIFSCCODE_CoulmnIndex > 0 ? SplitArr[REMIFSCCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    REMACCOUNTNUMBER = REMACCOUNTNUMBER_CoulmnIndex > 0 ? SplitArr[REMACCOUNTNUMBER_CoulmnIndex - Incr].Trim() : string.Empty;


                                    Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                                    ACCTUALTRANAMOUNT = Common.IsNumeric(ACCTUALTRANAMOUNT) ? ACCTUALTRANAMOUNT : "0";
                                    TRANSACCVITYFEE = Common.IsNumeric(TRANSACCVITYFEE) ? TRANSACCVITYFEE : "0";
                                    ISSURESETAMOUNT = Common.IsNumeric(ISSURESETAMOUNT) ? ISSURESETAMOUNT : "0";
                                    ISSUERSETFEE = Common.IsNumeric(ISSUERSETFEE) ? ISSUERSETFEE : "0";
                                    ISSURESETPROCFEE = Common.IsNumeric(ISSURESETPROCFEE) ? ISSURESETPROCFEE : "0";
                                    CARDHOLDERBILLAMOUNT = Common.IsNumeric(CARDHOLDERBILLAMOUNT) ? CARDHOLDERBILLAMOUNT : "0";
                                    CARDHOLDERBILACTFEE = Common.IsNumeric(CARDHOLDERBILACTFEE) ? CARDHOLDERBILACTFEE : "0";
                                    CARDHOLDERBILPROFEE = Common.IsNumeric(CARDHOLDERBILPROFEE) ? CARDHOLDERBILPROFEE : "0";
                                    CARDHOLDERBILSRVICEFEE = Common.IsNumeric(CARDHOLDERBILSRVICEFEE) ? CARDHOLDERBILSRVICEFEE : "0";
                                    TRAN_ISSUERCONVERSRATE = Common.IsNumeric(TRAN_ISSUERCONVERSRATE) ? TRAN_ISSUERCONVERSRATE : "0";
                                    TRANS_CARDHOLDERCONVERRATE = Common.IsNumeric(TRANS_CARDHOLDERCONVERRATE) ? TRANS_CARDHOLDERCONVERRATE : "0";
                                    CARDACCEPTSETDATE = Common.IsNumeric(CARDACCEPTSETDATE) ? CARDACCEPTSETDATE : "0";
                                    STAUDITNO = Common.IsNumeric(STAUDITNO) ? STAUDITNO : "0";
                                    Merchant_Category_Code = Common.IsNumeric(Merchant_Category_Code) ? Merchant_Category_Code : "0";

                                    TransDate = TRANSDATE_CoulmnIndex > 0 ? SplitArr[TRANSDATE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? SplitArr[TRANSTIME_CoulmnIndex - Incr].Trim() : string.Empty;

                                    if (TransDate.Length > 0 && Transaction_Time.Length > 0)
                                    {
                                        timestamp = TransDate + " " + Transaction_Time;
                                    }

                                    if (TxnAmountIsDecimal > 0)
                                    {
                                        temp = Convert.ToDouble(Transaction_Amount);

                                        if (temp > 0)
                                        {
                                            Transaction_Amount = (temp / (Math.Pow((double)10, (double)TxnAmountIsDecimal))).ToString();
                                        }
                                    }

                                    if (BeneAccountNumber.Any(char.IsLetter))
                                    {
                                        string TempToAccount = Regex.Replace(BeneAccountNumber, "[^0-9]", "");
                                        BeneAccountNumber = TempToAccount.TrimStart('0');
                                    }
                                    else
                                    {
                                        BeneAccountNumber = BeneAccountNumber.TrimStart('0');
                                    }

                                    TxnsDateTimeMain = DateTime.ParseExact(timestamp, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None);

                                    FORCEMATCH = false;

                                    if (TxnsDateTimeMain != null)
                                    {

                                        _DataTable.Rows.Add(Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code, PAN_Number, MEMNUMBER,
                                                           Approval_Number, STAUDITNO, TxnsDateTimeMain, Merchant_Category_Code, CARDACCEPTSETDATE, Card_Acceptor_ID, CARDACCEPTTERMINALID, CARDACCEPTERTERLOCATION,
                                                           Acquirer_ID, NETWORKID, Ben_Account_Number, Bene_IFSC_CODE, REM_ACCOUNT_NUMBER, REM_IFSC_CODE, Transaction_Currency_Code, Transaction_Amount, ACCTUALTRANAMOUNT,
                                                           TRANSACCVITYFEE, ISSUERSETCURRENCYCODE, ISSURESETAMOUNT, ISSUERSETFEE, ISSURESETPROCFEE, CARDHOLDERBILLCURNCCODE, CARDHOLDERBILLAMOUNT, CARDHOLDERBILACTFEE, CARDHOLDERBILPROFEE,
                                                           CARDHOLDERBILSRVICEFEE, TRAN_ISSUERCONVERSRATE, TRANS_CARDHOLDERCONVERRATE, FORCEMATCH, TransDate.Trim(), Transaction_Time.Trim(), Cycle, CardScheme, IssuingNetwork, ORIGINALCHANNEL, BeneIFSCCODE, BeneAccountNumber,
                                                           REMIFSCCODE, REMACCOUNTNUMBER);


                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;
                                            MSG = bulkimports.BulkInsertIssuerDataIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);

                                            _DataTable.Clear();
                                            ErrorCount = 0;
                                            StartTime = DateTime.Now;

                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }
                                    }

                                }
                                catch (Exception ex)
                                {
                                    ErrorCount++;
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                }
                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertIssuerDataIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (fileImportRequest.ErrorMessage.Length == 0 && _DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        if (tempTxnDateTime.Length > 0)
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        }
                        else
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + " File is Empty OR DateTime Format not matched;  ";
                        }
                        MSG = fileImportRequest.ErrorMessage;
                    }
                    
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                } 
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage; 
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG; ;
        }

        public string Splitter_IMPS_Acquirer_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            bool ErrorOccurred = false;
            int LineNo = 0;
            int LineNumber = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNO", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSDATE", typeof(string));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));
            //New Added
            _DataTable.Columns.Add("ORIGINALCHANNEL", typeof(string));
            _DataTable.Columns.Add("BeneIFSCCODE", typeof(string));
            _DataTable.Columns.Add("BeneAccountNumber", typeof(string));
            _DataTable.Columns.Add("REMIFSCCODE", typeof(string));
            _DataTable.Columns.Add("REMACCOUNTNUMBER", typeof(string));

            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string MEMNUMBER = string.Empty;
            string Approval_Number = string.Empty;
            string SYSTRACAUDITNO = "0";

            string TransDate = string.Empty;
            string Transaction_Time = string.Empty;
            string Merchant_Category_Code = string.Empty;

            string CARDACCEPTSETDATE = string.Empty;


            string CARDACCID = string.Empty;//REM_IFSC_CODE
            string Card_Acceptor_ID = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string Acquirer_ID = string.Empty;
            string ACCSETDATE = "0";
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = string.Empty;
            string ACCTUALTRANSAMOUNT = string.Empty;
            string TRANSACTIVITYFEE = string.Empty;//Ben_Account_Number


            string ACCURSETCURCODE = string.Empty;//Bene_IFSC_CODE
            string ACQUIERSETAMOUNT = "0";
            string ACQUIERSETFEE = "0";
            string ACQUIERSETPROFEE = string.Empty;//REM_ACCOUNT_NUMBER

            //New Added
            string ORIGINALCHANNEL = string.Empty;
            string BeneIFSCCODE = string.Empty;
            string BeneAccountNumber = string.Empty;
            string REMIFSCCODE = string.Empty;
            string REMACCOUNTNUMBER = string.Empty;

            string TRANSACQUIERCONVERRATE = "0";
            bool FORCEMATCH = false;

            ushort PARTICIPENTID_CoulmnIndex = 0;
            ushort TRANSTYPE_CoulmnIndex = 0;
            ushort FROMACCOUNTTYPE_CoulmnIndex = 0;
            ushort TOACCOUNTTYPE_CoulmnIndex = 0;
            ushort TRANSSERIALNO_CoulmnIndex = 0;
            ushort RESPONSECODE_CoulmnIndex = 0;
            ushort PAN_Number_CoulmnIndex = 0;
            ushort MEMNUMBER_CoulmnIndex = 0;
            ushort APPROVALNO_CoulmnIndex = 0;
            ushort SYSTRACAUDITNO_CoulmnIndex = 0;
            ushort TRANSDATE_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;
            ushort MERCHENTCATCODE_CoulmnIndex = 0;
            ushort CARDACCEPTERSETDATE_CoulmnIndex = 0;
            ushort CARDACCEPTERID_CoulmnIndex = 0;
            ushort CARDACCEPTERTERLOCATION_CoulmnIndex = 0;
            ushort ACQUIRERID_CoulmnIndex = 0;


            ushort TRANSCURCODE_CoulmnIndex = 0;
            ushort TRANSAMOUNT_CoulmnIndex = 0;
            ushort ACCTUALTRANSAMOUNT_CoulmnIndex = 0;
            ushort TRANSACCVITYFEE_CoulmnIndex = 0;
            ushort ACCURSETCURCODE_CoulmnIndex = 0;
            ushort ACQUIERSETAMOUNT_CoulmnIndex = 0;
            ushort ACQUIERSETFEE_CoulmnIndex = 0;
            ushort ACQUIERSETPROFEE_CoulmnIndex = 0;
            ushort TTRANSACQUIERCONVERRATE_CoulmnIndex = 0;

            //New Added
            ushort ORIGINALCHANNEL_CoulmnIndex = 0;
            ushort BeneIFSCCODE_CoulmnIndex = 0;
            ushort BeneAccountNumber_CoulmnIndex = 0;
            ushort REMIFSCCODE_CoulmnIndex = 0;
            ushort REMACCOUNTNUMBER_CoulmnIndex = 0;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";
            string timestamp = string.Empty;
            DateTime? TxnsDateTimeMain = null;

            int Incr = 1;
            int TxnAmountIsDecimal = 0;

            string[] SplitArr = null;
            string[] TxnDateTimeFormat = null;
            string Cycle = string.Empty;
            string line1 = string.Empty;
            int ErrorCount = 0;
            int largestIndex = 0, CoulmnIndex = 0;

            double temp = 0;

            try
            {
                DataSet ds = new DataSet();

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string[] FDA = fileImportRequest.FileName.Split('_', '.');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;


                PARTICIPENTID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PARTICIPENTID"]);
                TRANSTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTYPE"]);
                FROMACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FROMACCTYPE"]);
                TOACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TOACCTYPE"]);
                TRANSSERIALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSSERIALNO"]);
                RESPONSECODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RESPONSECODE"]);
                PAN_Number_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PANNO"]);
                MEMNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MEMNUMBER"]);
                APPROVALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["APPROVALNO"]);
                SYSTRACAUDITNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SYSTRACAUDITNO"]);
                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSDATE"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTIME"]);
                MERCHENTCATCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MERCHANTCATCODE"]);
                CARDACCEPTERSETDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERSETDATE"]);
                CARDACCEPTERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERID"]);
                CARDACCEPTERTERLOCATION_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERTERLOC"]);
                ACQUIRERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCIQUIERID"]);

                TRANSCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSCURCODE"]);
                TRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSAMOUNT"]);
                ACCTUALTRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANSAMOUNT"]);
                TRANSACCVITYFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIVITYFEE"]);
                ACCURSETCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCURSETCURCODE"]);
                ACQUIERSETAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETAMOUNT"]);
                ACQUIERSETFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETFEE"]);
                ACQUIERSETPROFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETPROFEE"]);

                TTRANSACQUIERCONVERRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACQUIERCONVERRATE"]);

                //New Added 
                ORIGINALCHANNEL_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ORIGINALCHANNEL"]);
                BeneIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneIFSCCODE"]);
                BeneAccountNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneAccountNumber"]);
                REMIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["REMIFSCCODE"]);
                REMACCOUNTNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["REMACCOUNTNUMBER"]);

                TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                TxnAmountIsDecimal = Convert.ToInt32(fileImportRequest.ConfigData.Rows[0]["TxnAmountIsDecimal"]);

                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            string tempTxnDateTime = string.Empty;
            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            SplitArr = new string[0];

                            SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            if (TRANSDATE_CoulmnIndex > 0 && TRANSTIME_CoulmnIndex > 0)
                            {
                                TransDate = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;
                                tempTxnDateTime = TransDate + " " + Transaction_Time;
                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }

                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }
                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                try
                                {
                                    if (LineNo < dateStartIndex)
                                    {
                                        LineNumber++;
                                        LineNo++;
                                        continue;
                                    }

                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                    SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                    if (SplitArr.Length < largestIndex) continue;

                                    LineNumber++;

                                    Participant_ID = string.Empty;
                                    Transaction_Type = string.Empty;
                                    From_Account_Type = string.Empty; ;
                                    To_Account_Type = string.Empty;
                                    Transaction_Serial_Number = string.Empty;
                                    Response_Code = string.Empty;
                                    PAN_Number = string.Empty;
                                    MEMNUMBER = string.Empty;
                                    Approval_Number = string.Empty;
                                    //DateTime  Transaction_Date ;//= string.Empty;
                                    Transaction_Time = "0";
                                    Merchant_Category_Code = "0";
                                    Acquirer_ID = string.Empty;
                                    Transaction_Amount = "0";
                                    ACCTUALTRANSAMOUNT = "0";
                                    TRANSACTIVITYFEE = "0";

                                    ACCURSETCURCODE = string.Empty;
                                    ACQUIERSETAMOUNT = "0";
                                    ACQUIERSETFEE = "0";
                                    ACQUIERSETPROFEE = "0";

                                    TRANSACQUIERCONVERRATE = "0";
                                    CARDACCEPTSETDATE = "0";
                                    ACCSETDATE = "0";

                                    timestamp = string.Empty;
                                    TxnsDateTimeMain = null;

                                    //New Added
                                    ORIGINALCHANNEL = string.Empty;
                                    BeneIFSCCODE = string.Empty;
                                    BeneAccountNumber = string.Empty;
                                    REMIFSCCODE = string.Empty;
                                    REMACCOUNTNUMBER = string.Empty;

                                    temp = 0;

                                    Participant_ID = PARTICIPENTID_CoulmnIndex > 0 ? SplitArr[PARTICIPENTID_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Type = TRANSTYPE_CoulmnIndex > 0 ? SplitArr[TRANSTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    From_Account_Type = FROMACCOUNTTYPE_CoulmnIndex > 0 ? SplitArr[FROMACCOUNTTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    To_Account_Type = TOACCOUNTTYPE_CoulmnIndex > 0 ? SplitArr[TOACCOUNTTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Serial_Number = TRANSSERIALNO_CoulmnIndex > 0 ? SplitArr[TRANSSERIALNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Response_Code = RESPONSECODE_CoulmnIndex > 0 ? SplitArr[RESPONSECODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    PAN_Number = PAN_Number_CoulmnIndex > 0 ? SplitArr[PAN_Number_CoulmnIndex - Incr].Trim() : string.Empty;

                                    MEMNUMBER = MEMNUMBER_CoulmnIndex > 0 ? SplitArr[MEMNUMBER_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Approval_Number = APPROVALNO_CoulmnIndex > 0 ? SplitArr[APPROVALNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Merchant_Category_Code = MERCHENTCATCODE_CoulmnIndex > 0 ? SplitArr[MERCHENTCATCODE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    CARDACCEPTSETDATE = CARDACCEPTERSETDATE_CoulmnIndex > 0 ? SplitArr[CARDACCEPTERSETDATE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Card_Acceptor_ID = CARDACCEPTERID_CoulmnIndex > 0 ? SplitArr[CARDACCEPTERID_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Acquirer_ID = ACQUIRERID_CoulmnIndex > 0 ? SplitArr[ACQUIRERID_CoulmnIndex - Incr].Trim() : string.Empty;
                                    SYSTRACAUDITNO = SYSTRACAUDITNO_CoulmnIndex > 0 ? SplitArr[SYSTRACAUDITNO_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Transaction_Currency_Code = TRANSCURCODE_CoulmnIndex > 0 ? SplitArr[TRANSCURCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Amount = TRANSAMOUNT_CoulmnIndex > 0 ? SplitArr[TRANSAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACCTUALTRANSAMOUNT = ACCTUALTRANSAMOUNT_CoulmnIndex > 0 ? SplitArr[ACCTUALTRANSAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    TRANSACTIVITYFEE = TRANSACCVITYFEE_CoulmnIndex > 0 ? SplitArr[TRANSACCVITYFEE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    ACCURSETCURCODE = ACCURSETCURCODE_CoulmnIndex > 0 ? SplitArr[ACCURSETCURCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACQUIERSETAMOUNT = ACQUIERSETAMOUNT_CoulmnIndex > 0 ? SplitArr[ACQUIERSETAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACQUIERSETFEE = ACQUIERSETFEE_CoulmnIndex > 0 ? SplitArr[ACQUIERSETFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    ACQUIERSETPROFEE = ACQUIERSETPROFEE_CoulmnIndex > 0 ? SplitArr[ACQUIERSETPROFEE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    TRANSACQUIERCONVERRATE = TTRANSACQUIERCONVERRATE_CoulmnIndex > 0 ? SplitArr[TTRANSACQUIERCONVERRATE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                                    ACCTUALTRANSAMOUNT = Common.IsNumeric(ACCTUALTRANSAMOUNT) ? ACCTUALTRANSAMOUNT : "0";
                                    TRANSACTIVITYFEE = Common.IsNumeric(TRANSACTIVITYFEE) ? TRANSACTIVITYFEE : "0";
                                    ACQUIERSETAMOUNT = Common.IsNumeric(ACQUIERSETAMOUNT) ? ACQUIERSETAMOUNT : "0";
                                    ACQUIERSETFEE = Common.IsNumeric(ACQUIERSETFEE) ? ACQUIERSETFEE : "0";
                                    ACQUIERSETPROFEE = Common.IsNumeric(ACQUIERSETPROFEE) ? ACQUIERSETPROFEE : "0";
                                    SYSTRACAUDITNO = Common.IsNumeric(SYSTRACAUDITNO) ? SYSTRACAUDITNO : "0";


                                    TRANSACQUIERCONVERRATE = Common.IsNumeric(TRANSACQUIERCONVERRATE) ? TRANSACQUIERCONVERRATE : "0";
                                    CARDACCEPTSETDATE = Common.IsNumeric(CARDACCEPTSETDATE) ? CARDACCEPTSETDATE : "0";
                                    Merchant_Category_Code = Common.IsNumeric(Merchant_Category_Code) ? Merchant_Category_Code : "0";

                                    //New Added
                                    ORIGINALCHANNEL = ORIGINALCHANNEL_CoulmnIndex > 0 ? SplitArr[ORIGINALCHANNEL_CoulmnIndex - Incr].Trim() : string.Empty;
                                    BeneIFSCCODE = BeneIFSCCODE_CoulmnIndex > 0 ? SplitArr[BeneIFSCCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    BeneAccountNumber = BeneAccountNumber_CoulmnIndex > 0 ? SplitArr[BeneAccountNumber_CoulmnIndex - Incr].Trim() : string.Empty;
                                    REMIFSCCODE = REMIFSCCODE_CoulmnIndex > 0 ? SplitArr[REMIFSCCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    REMACCOUNTNUMBER = REMACCOUNTNUMBER_CoulmnIndex > 0 ? SplitArr[REMACCOUNTNUMBER_CoulmnIndex - Incr].Trim() : string.Empty;


                                    TransDate = TRANSDATE_CoulmnIndex > 0 ? SplitArr[TRANSDATE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? SplitArr[TRANSTIME_CoulmnIndex - Incr].Trim() : string.Empty;


                                    if (TxnAmountIsDecimal > 0)
                                    {
                                        temp = Convert.ToDouble(Transaction_Amount);

                                        if (temp > 0)
                                        {
                                            Transaction_Amount = (temp / (Math.Pow((double)10, (double)TxnAmountIsDecimal))).ToString();
                                        }
                                    }

                                    if (TransDate.Length > 0 && Transaction_Time.Length > 0)
                                    {
                                        timestamp = TransDate + " " + Transaction_Time;
                                    }

                                    TxnsDateTimeMain = DateTime.ParseExact(timestamp, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None);

                                    FORCEMATCH = false;

                                    if (TxnsDateTimeMain != null)
                                    {
                                        _DataTable.Rows.Add(Participant_ID.Trim(), Transaction_Type.Trim(), From_Account_Type.Trim(), To_Account_Type.Trim(), Transaction_Serial_Number.Trim(), Response_Code.Trim(), PAN_Number.Trim(), MEMNUMBER.Trim(),
                                                           Approval_Number.Trim(), SYSTRACAUDITNO.Trim(), TxnsDateTimeMain, TransDate.Trim(), Transaction_Time.Trim(), Merchant_Category_Code.Trim(), CARDACCEPTSETDATE.Trim(), CARDACCID.Trim(), Card_Acceptor_ID.Trim(), CARDACCEPTERTERLOC.Trim(),
                                                              Acquirer_ID, ACCSETDATE, Transaction_Currency_Code, Transaction_Amount, ACCTUALTRANSAMOUNT, TRANSACTIVITYFEE, ACCURSETCURCODE, ACQUIERSETAMOUNT, ACQUIERSETFEE, ACQUIERSETPROFEE, TRANSACQUIERCONVERRATE,
                                                              FORCEMATCH, Cycle.Trim(), CardScheme, IssuingNetwork, ORIGINALCHANNEL, BeneIFSCCODE, BeneAccountNumber, REMIFSCCODE, REMACCOUNTNUMBER);

                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;

                                            MSG = bulkimports.BulkInsertAcquirerDataIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);
                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    ErrorCount++;
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                }
                            }
                            LineNo = 0;

                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo = BatchNo + 1;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertAcquirerDataIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        if (tempTxnDateTime.Length > 0)
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        }
                        else
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + " File is Empty OR DateTime Format not matched;  ";
                        }
                        MSG = fileImportRequest.ErrorMessage;
                    }
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }

            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = 1,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string Splitter_IMPS_Issuer_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            bool ErrorOccurred = false;
            int SheetLineNo = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(bool));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            int Incr = 1;
            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string MEMNUMBER = string.Empty;
            string Approval_Number = string.Empty;
            string STAUDITNO = "0";
            string TransDate = string.Empty;
            string Transaction_Time = string.Empty;
            string Merchant_Category_Code = string.Empty;
            string CARDACCEPTSETDATE = string.Empty;
            string Card_Acceptor_ID = string.Empty;
            string CARDACCEPTTERMINALID = string.Empty;
            string CARDACCEPTERTERLOCATION = string.Empty;
            string Acquirer_ID = string.Empty;
            string NETWORKID = string.Empty;
            string Ben_Account_Number = string.Empty;
            string Bene_IFSC_CODE = string.Empty;
            string REM_ACCOUNT_NUMBER = string.Empty;
            string REM_IFSC_CODE = string.Empty;
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = "0";
            string ACCTUALTRANAMOUNT = "0";
            string TRANSACCVITYFEE = "0";
            string ISSUERSETCURRENCYCODE = string.Empty;
            string ISSURESETAMOUNT = "0";
            string ISSUERSETFEE = "0";
            string ISSURESETPROCFEE = "0";
            string CARDHOLDERBILLCURNCCODE = string.Empty;
            string CARDHOLDERBILLAMOUNT = "0";
            string CARDHOLDERBILACTFEE = "0";
            string CARDHOLDERBILPROFEE = "0";
            string CARDHOLDERBILSRVICEFEE = "0";
            string TRAN_ISSUERCONVERSRATE = "0";
            string TRANS_CARDHOLDERCONVERRATE = "0";

            ushort PARTICIPENTID_CoulmnIndex = 0;
            ushort TRANSTYPE_CoulmnIndex = 0;
            ushort FROMACCOUNTTYPE_CoulmnIndex = 0;
            ushort TOACCOUNTTYPE_CoulmnIndex = 0;
            ushort TRANSSERIALNO_CoulmnIndex = 0;
            ushort RESPONSECODE_CoulmnIndex = 0;
            ushort PAN_Number_CoulmnIndex = 0;
            ushort MEMNUMBER_CoulmnIndex = 0;
            ushort APPROVALNO_CoulmnIndex = 0;
            ushort STAUDITNO_CoulmnIndex = 0;
            ushort TRANSDATE_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;
            ushort MERCHENTCATCODE_CoulmnIndex = 0;
            ushort CARDACCEPTERSETDATE_CoulmnIndex = 0;
            ushort CARDACCEPTERID_CoulmnIndex = 0;
            ushort CARDACCEPTTERMINALID_CoulmnIndex = 0;
            ushort CARDACCEPTERTERLOCATION_CoulmnIndex = 0;
            ushort ACQUIRERID_CoulmnIndex = 0;
            ushort NETWORKID_CoulmnIndex = 0;
            ushort ACCOUNTNO1_CoulmnIndex = 0;
            ushort ACCOUNTBRANCHID_CoulmnIndex = 0;
            ushort ACCOUNTNO2_CoulmnIndex = 0;
            ushort ACCOUNT2BRANCHID_CoulmnIndex = 0;


            ushort TRANSCURCODE_CoulmnIndex = 0;
            ushort TRANSAMOUNT_CoulmnIndex = 0;
            ushort ACCTUALTRANSAMOUNT_CoulmnIndex = 0;
            ushort TRANSACCVITYFEE_CoulmnIndex = 0;
            ushort ISSUERSETCURRENCYCODE_CoulmnIndex = 0;
            ushort ISSURESETAMOUNT_CoulmnIndex = 0;
            ushort ISSUERSETFEE_CoulmnIndex = 0;
            ushort ISSURESETPROCFEE_CoulmnIndex = 0;


            ushort CARDHOLDERBILLCURNCCODE_CoulmnIndex = 0;
            ushort CARDHOLDERBILLAMOUNT_CoulmnIndex = 0;
            ushort CARDHOLDERBILACTFEE_CoulmnIndex = 0;
            ushort CARDHOLDERBILPROFEE_CoulmnIndex = 0;
            ushort CARDHOLDERBILSRVICEFEE_CoulmnIndex = 0;
            ushort TRAN_ISSUERCONVERSRATE_CoulmnIndex = 0;
            ushort TRANS_CARDHOLDERCONVERRATE_CoulmnIndex = 0;

            string timestamp = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            bool FORCEMATCH = false;

            string[] TxnDateTimeFormat = null;
            string line1 = string.Empty;
            string Cycle = string.Empty;

            int ErrorCount = 0, LineNo = 0;
            string conString = string.Empty;
            DataTable dtexcelsheetname = new DataTable();
            DataTable dtSheet = new DataTable();

            try
            {
                DataSet ds = new DataSet();

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string[] FDA = fileImportRequest.FileName.Split('_');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                PARTICIPENTID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PARICIPATEID"]);
                TRANSTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONTYPE"]);
                FROMACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FROMACCOUNTTYPE"]);
                TOACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TOACCOUNTTYPE"]);
                TRANSSERIALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSSERIALNO"]);
                RESPONSECODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RESPONSECODE"]);
                PAN_Number_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PANNUMBER"]);
                MEMNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MEMNUMBER"]);
                APPROVALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["APPROVNO"]);
                STAUDITNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["STAUDITNO"]);
                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONDATE"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONTIME"]);
                MERCHENTCATCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MERCHENTCATCODE"]);
                CARDACCEPTERSETDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTSETDATE"]);
                CARDACCEPTERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTORID"]);
                CARDACCEPTTERMINALID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTTERMINALID"]);
                CARDACCEPTERTERLOCATION_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERTERLOCATION"]);
                ACQUIRERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIRERID"]);
                NETWORKID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NETWORKID"]);
                ACCOUNTNO1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTNO1"]);
                ACCOUNTBRANCHID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTBRANCHID"]);
                ACCOUNTNO2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTNO2"]);
                ACCOUNT2BRANCHID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNT2BRANCHID"]);

                TRANSCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSCURRENCYCODE"]);
                TRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSAMOUNT"]);
                ACCTUALTRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANAMOUNT"]);
                TRANSACCVITYFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACCVITYFEE"]);
                ISSUERSETCURRENCYCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSUERSETCURRENCYCODE"]);
                ISSURESETAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSURESETAMOUNT"]);
                ISSUERSETFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSUERSETFEE"]);
                ISSURESETPROCFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSURESETPROCFEE"]);

                CARDHOLDERBILLCURNCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILLCURNCCODE"]);
                CARDHOLDERBILLAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILLAMOUNT"]);
                CARDHOLDERBILACTFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILACTFEE"]);
                CARDHOLDERBILPROFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILPROFEE"]);
                CARDHOLDERBILSRVICEFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILSRVICEFEE"]);
                TRAN_ISSUERCONVERSRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRAN_ISSUERCONVERSRATE"]);
                TRANS_CARDHOLDERCONVERRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANS_CARDHOLDERCONVERRATE"]);

                //Read the connection string for the Excel file.
                conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                conString = string.Format(conString, fileImportRequest.Path);

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {
                // _logger.LogInformation("Ready for read");
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {
                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }

                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            dtSheet = new DataTable();

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = "SELECT * From [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            Incr = 1;

                            if (dtSheet.Rows.Count > 1)
                            {
                                fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;
                                // Find first data row based on whether the "Join Date" cell can be parsed as a date
                                int dateStartIndex = -1;

                                for (int i = 0; i < dtSheet.Rows.Count; i++)
                                {
                                    try
                                    {
                                        if (TRANSDATE_CoulmnIndex > 0 && TRANSTIME_CoulmnIndex > 0)
                                        {
                                            string value = dtSheet.Rows[i][TRANSDATE_CoulmnIndex - Incr]?.ToString()?.Trim() + " " + dtSheet.Rows[i][TRANSTIME_CoulmnIndex - Incr]?.ToString()?.Trim();

                                            bool isValid = DateTime.TryParseExact(value, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                            if (isValid)
                                            {
                                                dateStartIndex = i;
                                                break;
                                            }
                                        }
                                    }
                                    catch
                                    {
                                        SheetDateError++;
                                    }

                                    if (i > 25)
                                        break;
                                }

                                // Remove rows before first data row
                                if (dateStartIndex > -1)
                                {
                                    for (int k = 0; k < dtSheet.Rows.Count; k++)
                                    {
                                        LineNo++;
                                        SheetLineNo++;
                                        if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                        {
                                            continue;
                                        }

                                        try
                                        {

                                            Participant_ID = string.Empty;
                                            Transaction_Type = string.Empty;
                                            From_Account_Type = string.Empty; ;
                                            To_Account_Type = string.Empty;
                                            Transaction_Serial_Number = string.Empty;
                                            Response_Code = string.Empty;
                                            PAN_Number = string.Empty;
                                            MEMNUMBER = string.Empty;
                                            Approval_Number = string.Empty;


                                            //DateTime  Transaction_Date ;//= string.Empty;
                                            Transaction_Time = "0";
                                            Merchant_Category_Code = "0";
                                            Acquirer_ID = string.Empty;
                                            Transaction_Amount = "0";
                                            ACCTUALTRANAMOUNT = "0";
                                            TRANSACCVITYFEE = "0";
                                            ISSUERSETCURRENCYCODE = string.Empty;
                                            ISSURESETAMOUNT = "0";
                                            ISSUERSETFEE = "0";
                                            ISSURESETPROCFEE = "0";
                                            CARDHOLDERBILLCURNCCODE = string.Empty;
                                            CARDHOLDERBILLAMOUNT = "0";
                                            CARDHOLDERBILACTFEE = "0";
                                            CARDHOLDERBILPROFEE = "0";
                                            CARDHOLDERBILSRVICEFEE = "0";
                                            TRAN_ISSUERCONVERSRATE = "0";
                                            TRANS_CARDHOLDERCONVERRATE = "0";
                                            CARDACCEPTSETDATE = "0";
                                            STAUDITNO = "0";
                                            timestamp = string.Empty;

                                            TxnsDateTimeMain = null;

                                            Participant_ID = PARTICIPENTID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PARTICIPENTID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Type = TRANSTYPE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSTYPE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            From_Account_Type = FROMACCOUNTTYPE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FROMACCOUNTTYPE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            To_Account_Type = TOACCOUNTTYPE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TOACCOUNTTYPE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Serial_Number = TRANSSERIALNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSSERIALNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Response_Code = RESPONSECODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][RESPONSECODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            PAN_Number = PAN_Number_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PAN_Number_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            MEMNUMBER = MEMNUMBER_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][MEMNUMBER_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Approval_Number = APPROVALNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][APPROVALNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            STAUDITNO = STAUDITNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][STAUDITNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Merchant_Category_Code = MERCHENTCATCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][MERCHENTCATCODE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            CARDACCEPTSETDATE = CARDACCEPTERSETDATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERSETDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Card_Acceptor_ID = CARDACCEPTERID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDACCEPTTERMINALID = CARDACCEPTTERMINALID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTTERMINALID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDACCEPTERTERLOCATION = CARDACCEPTERTERLOCATION_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERTERLOCATION_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            Acquirer_ID = ACQUIRERID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQUIRERID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            NETWORKID = NETWORKID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][NETWORKID_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            Transaction_Currency_Code = TRANSCURCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSCURCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Amount = TRANSAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACCTUALTRANAMOUNT = ACCTUALTRANSAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACCTUALTRANSAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TRANSACCVITYFEE = TRANSACCVITYFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSACCVITYFEE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            ISSUERSETCURRENCYCODE = ISSUERSETCURRENCYCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISSUERSETCURRENCYCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ISSURESETAMOUNT = ISSURESETAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISSURESETAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ISSUERSETFEE = ISSUERSETFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISSUERSETFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ISSURESETPROCFEE = ISSURESETPROCFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISSURESETPROCFEE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            CARDHOLDERBILLCURNCCODE = CARDHOLDERBILLCURNCCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDHOLDERBILLCURNCCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDHOLDERBILLAMOUNT = CARDHOLDERBILLAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDHOLDERBILLAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDHOLDERBILACTFEE = CARDHOLDERBILACTFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDHOLDERBILACTFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDHOLDERBILPROFEE = CARDHOLDERBILPROFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDHOLDERBILPROFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDHOLDERBILSRVICEFEE = CARDHOLDERBILSRVICEFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDHOLDERBILSRVICEFEE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            TRAN_ISSUERCONVERSRATE = TRAN_ISSUERCONVERSRATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRAN_ISSUERCONVERSRATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TRANS_CARDHOLDERCONVERRATE = TRANS_CARDHOLDERCONVERRATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANS_CARDHOLDERCONVERRATE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                                            ACCTUALTRANAMOUNT = Common.IsNumeric(ACCTUALTRANAMOUNT) ? ACCTUALTRANAMOUNT : "0";
                                            TRANSACCVITYFEE = Common.IsNumeric(TRANSACCVITYFEE) ? TRANSACCVITYFEE : "0";
                                            ISSURESETAMOUNT = Common.IsNumeric(ISSURESETAMOUNT) ? ISSURESETAMOUNT : "0";
                                            ISSUERSETFEE = Common.IsNumeric(ISSUERSETFEE) ? ISSUERSETFEE : "0";
                                            ISSURESETPROCFEE = Common.IsNumeric(ISSURESETPROCFEE) ? ISSURESETPROCFEE : "0";
                                            CARDHOLDERBILLAMOUNT = Common.IsNumeric(CARDHOLDERBILLAMOUNT) ? CARDHOLDERBILLAMOUNT : "0";
                                            CARDHOLDERBILACTFEE = Common.IsNumeric(CARDHOLDERBILACTFEE) ? CARDHOLDERBILACTFEE : "0";
                                            CARDHOLDERBILPROFEE = Common.IsNumeric(CARDHOLDERBILPROFEE) ? CARDHOLDERBILPROFEE : "0";
                                            CARDHOLDERBILSRVICEFEE = Common.IsNumeric(CARDHOLDERBILSRVICEFEE) ? CARDHOLDERBILSRVICEFEE : "0";
                                            TRAN_ISSUERCONVERSRATE = Common.IsNumeric(TRAN_ISSUERCONVERSRATE) ? TRAN_ISSUERCONVERSRATE : "0";
                                            TRANS_CARDHOLDERCONVERRATE = Common.IsNumeric(TRANS_CARDHOLDERCONVERRATE) ? TRANS_CARDHOLDERCONVERRATE : "0";
                                            CARDACCEPTSETDATE = Common.IsNumeric(CARDACCEPTSETDATE) ? CARDACCEPTSETDATE : "0";
                                            STAUDITNO = Common.IsNumeric(STAUDITNO) ? STAUDITNO : "0";
                                            Merchant_Category_Code = Common.IsNumeric(Merchant_Category_Code) ? Merchant_Category_Code : "0";

                                            TransDate = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            if (TransDate.Length > 0 && Transaction_Time.Length > 0)
                                            {
                                                timestamp = TransDate + " " + Transaction_Time;
                                            }

                                            TxnsDateTimeMain = DateTime.ParseExact(timestamp, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None);

                                            FORCEMATCH = false;

                                            if (TxnsDateTimeMain != null)
                                            {

                                                _DataTable.Rows.Add(Participant_ID, Transaction_Type, From_Account_Type, To_Account_Type, Transaction_Serial_Number, Response_Code, PAN_Number, MEMNUMBER,
                                                                   Approval_Number, STAUDITNO, TxnsDateTimeMain, Transaction_Time, Merchant_Category_Code, CARDACCEPTSETDATE, Card_Acceptor_ID, CARDACCEPTTERMINALID, CARDACCEPTERTERLOCATION,
                                                                   Acquirer_ID, NETWORKID, Ben_Account_Number, Bene_IFSC_CODE, REM_ACCOUNT_NUMBER, REM_IFSC_CODE, Transaction_Currency_Code, Transaction_Amount, ACCTUALTRANAMOUNT,
                                                                   TRANSACCVITYFEE, ISSUERSETCURRENCYCODE, ISSURESETAMOUNT, ISSUERSETFEE, ISSURESETPROCFEE, CARDHOLDERBILLCURNCCODE, CARDHOLDERBILLAMOUNT, CARDHOLDERBILACTFEE, CARDHOLDERBILPROFEE,
                                                                   CARDHOLDERBILSRVICEFEE, TRAN_ISSUERCONVERSRATE, TRANS_CARDHOLDERCONVERRATE, FORCEMATCH, Cycle, CardScheme, IssuingNetwork);


                                                if (_DataTable.Rows.Count >= batchSize)
                                                {
                                                    BatchNo++;
                                                    MSG = bulkimports.BulkInsertIssuerDataIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                    BatchDetails batchDetailsPartial = new BatchDetails
                                                    {
                                                        BatchNo = BatchNo,
                                                        BatchSize = batchSize,
                                                        TxnUploadCount = _DataTable.Rows.Count,
                                                        TxnsCount = fileImportRequest.InsertCount,
                                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                        FailedCount = ErrorCount,
                                                        BatchStartTime = batchStartTime,
                                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                    };

                                                    batchDetailsList.Add(batchDetailsPartial);
                                                    _DataTable.Clear();
                                                    ErrorCount = 0;
                                                    StartTime = DateTime.Now;

                                                    if (NewEntry)
                                                    {
                                                        break;
                                                    }
                                                }

                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            ErrorCount++;
                                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                        }
                                    }

                                    if (_DataTable.Rows.Count > 0)
                                    {
                                        BatchNo++;

                                        fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                        MSG = bulkimports.BulkInsertIssuerDataIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                    }
                                    else if (fileImportRequest.ErrorMessage.Length == 0 && _DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                                    {
                                        BatchNo++;
                                        MSG = "Successful";
                                    }
                                }
                                else
                                {
                                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched";
                                    break;
                                }
                            }
                        }

                        LineNo = 0;

                    }
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }

        public string Splitter_IMPS_Acquirer_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            bool ErrorOccurred = false;
            int SheetLineNo = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNO", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSDATE", typeof(string));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));
            //New Added
            _DataTable.Columns.Add("ORIGINALCHANNEL", typeof(string));
            _DataTable.Columns.Add("BeneIFSCCODE", typeof(string));
            _DataTable.Columns.Add("BeneAccountNumber", typeof(string));
            _DataTable.Columns.Add("REMIFSCCODE", typeof(string));
            _DataTable.Columns.Add("REMACCOUNTNUMBER", typeof(string));

            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string MEMNUMBER = string.Empty;
            string Approval_Number = string.Empty;
            string SYSTRACAUDITNO = "0";

            string TransDate = string.Empty;
            string Transaction_Time = string.Empty;
            string Merchant_Category_Code = string.Empty;

            string CARDACCEPTSETDATE = string.Empty;


            string CARDACCID = string.Empty;//REM_IFSC_CODE
            string Card_Acceptor_ID = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string Acquirer_ID = string.Empty;
            string ACCSETDATE = "0";
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = string.Empty;
            string ACCTUALTRANSAMOUNT = string.Empty;
            string TRANSACTIVITYFEE = string.Empty;//Ben_Account_Number


            string ACCURSETCURCODE = string.Empty;//Bene_IFSC_CODE
            string ACQUIERSETAMOUNT = "0";
            string ACQUIERSETFEE = "0";
            string ACQUIERSETPROFEE = string.Empty;//REM_ACCOUNT_NUMBER


            //New Added
            string ORIGINALCHANNEL = string.Empty;
            string BeneIFSCCODE = string.Empty;
            string BeneAccountNumber = string.Empty;
            string REMIFSCCODE = string.Empty;
            string REMACCOUNTNUMBER = string.Empty;


            string TRANSACQUIERCONVERRATE = "0";
            bool FORCEMATCH = false;

            ushort PARTICIPENTID_CoulmnIndex = 0;
            ushort TRANSTYPE_CoulmnIndex = 0;
            ushort FROMACCOUNTTYPE_CoulmnIndex = 0;
            ushort TOACCOUNTTYPE_CoulmnIndex = 0;
            ushort TRANSSERIALNO_CoulmnIndex = 0;
            ushort RESPONSECODE_CoulmnIndex = 0;
            ushort PAN_Number_CoulmnIndex = 0;
            ushort MEMNUMBER_CoulmnIndex = 0;
            ushort APPROVALNO_CoulmnIndex = 0;
            ushort SYSTRACAUDITNO_CoulmnIndex = 0;
            ushort TRANSDATE_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;
            ushort MERCHENTCATCODE_CoulmnIndex = 0;
            ushort CARDACCEPTERSETDATE_CoulmnIndex = 0;
            ushort CARDACCEPTERID_CoulmnIndex = 0;
            ushort CARDACCEPTERTERLOCATION_CoulmnIndex = 0;
            ushort ACQUIRERID_CoulmnIndex = 0;


            ushort TRANSCURCODE_CoulmnIndex = 0;
            ushort TRANSAMOUNT_CoulmnIndex = 0;
            ushort ACCTUALTRANSAMOUNT_CoulmnIndex = 0;
            ushort TRANSACCVITYFEE_CoulmnIndex = 0;
            ushort ACCURSETCURCODE_CoulmnIndex = 0;
            ushort ACQUIERSETAMOUNT_CoulmnIndex = 0;
            ushort ACQUIERSETFEE_CoulmnIndex = 0;
            ushort ACQUIERSETPROFEE_CoulmnIndex = 0;
            ushort TTRANSACQUIERCONVERRATE_CoulmnIndex = 0;

            //New Added
            ushort ORIGINALCHANNEL_CoulmnIndex = 0;
            ushort BeneIFSCCODE_CoulmnIndex = 0;
            ushort BeneAccountNumber_CoulmnIndex = 0;
            ushort REMIFSCCODE_CoulmnIndex = 0;
            ushort REMACCOUNTNUMBER_CoulmnIndex = 0;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";
            string timestamp = string.Empty;
            DateTime? TxnsDateTimeMain = null;

            int Incr = 1;

            string[] TxnDateTimeFormat = null;
            string Cycle = string.Empty;

            int ErrorCount = 0, LineNo = 0;

            string conString = string.Empty;
            DataTable dtexcelsheetname = new DataTable();
            DataTable dtSheet = new DataTable();

            try
            {
                DataSet ds = new DataSet();

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string[] FDA = fileImportRequest.FileName.Split('_');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                PARTICIPENTID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PARTICIPENTID"]);
                TRANSTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTYPE"]);
                FROMACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FROMACCTYPE"]);
                TOACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TOACCTYPE"]);
                TRANSSERIALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSSERIALNO"]);
                RESPONSECODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RESPONSECODE"]);
                PAN_Number_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PANNO"]);
                MEMNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MEMNUMBER"]);
                APPROVALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["APPROVALNO"]);
                SYSTRACAUDITNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SYSTRACAUDITNO"]);
                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSDATE"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTIME"]);
                MERCHENTCATCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MERCHANTCATCODE"]);
                CARDACCEPTERSETDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERSETDATE"]);
                CARDACCEPTERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERID"]);
                CARDACCEPTERTERLOCATION_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERTERLOC"]);
                ACQUIRERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCIQUIERID"]);

                TRANSCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSCURCODE"]);
                TRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSAMOUNT"]);
                ACCTUALTRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANSAMOUNT"]);
                TRANSACCVITYFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIVITYFEE"]);
                ACCURSETCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCURSETCURCODE"]);
                ACQUIERSETAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETAMOUNT"]);
                ACQUIERSETFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETFEE"]);
                ACQUIERSETPROFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETPROFEE"]);

                TTRANSACQUIERCONVERRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACQUIERCONVERRATE"]);

                //New Added 
                ORIGINALCHANNEL_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ORIGINALCHANNEL"]);
                BeneIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneIFSCCODE"]);
                BeneAccountNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneAccountNumber"]);
                REMIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["REMIFSCCODE"]);
                REMACCOUNTNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["REMACCOUNTNUMBER"]);

                //Read the connection string for the Excel file.
                conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                conString = string.Format(conString, fileImportRequest.Path);

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {
                // _logger.LogInformation("Ready for read");
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {

                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }


                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            dtSheet = new DataTable();

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = "SELECT * From [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            Incr = 1;

                            if (dtSheet.Rows.Count > 1)
                            {
                                fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;
                                // Find first data row based on whether the "Join Date" cell can be parsed as a date
                                int dateStartIndex = -1;

                                for (int i = 0; i < dtSheet.Rows.Count; i++)
                                {
                                    try
                                    {
                                        if (TRANSDATE_CoulmnIndex > 0 && TRANSTIME_CoulmnIndex > 0)
                                        {
                                            string value = dtSheet.Rows[i][TRANSDATE_CoulmnIndex - Incr]?.ToString()?.Trim() + " " + dtSheet.Rows[i][TRANSTIME_CoulmnIndex - Incr]?.ToString()?.Trim();

                                            bool isValid = DateTime.TryParseExact(value, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                            if (isValid)
                                            {
                                                dateStartIndex = i;
                                                break;
                                            }
                                        }
                                    }
                                    catch
                                    {
                                        SheetDateError++;
                                    }

                                    if (i > 25)
                                        break;
                                }

                                // Remove rows before first data row
                                if (dateStartIndex > -1)
                                {
                                    for (int k = 0; k < dtSheet.Rows.Count; k++)
                                    {
                                        LineNo++;
                                        SheetLineNo++;

                                        if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                        {
                                            continue;
                                        }

                                        try
                                        {

                                            Participant_ID = string.Empty;
                                            Transaction_Type = string.Empty;
                                            From_Account_Type = string.Empty; ;
                                            To_Account_Type = string.Empty;
                                            Transaction_Serial_Number = string.Empty;
                                            Response_Code = string.Empty;
                                            PAN_Number = string.Empty;
                                            MEMNUMBER = string.Empty;
                                            Approval_Number = string.Empty;
                                            //DateTime  Transaction_Date ;//= string.Empty;
                                            Transaction_Time = "0";
                                            Merchant_Category_Code = "0";
                                            Acquirer_ID = string.Empty;
                                            Transaction_Amount = "0";
                                            ACCTUALTRANSAMOUNT = "0";
                                            TRANSACTIVITYFEE = "0";

                                            ACCURSETCURCODE = string.Empty;
                                            ACQUIERSETAMOUNT = "0";
                                            ACQUIERSETFEE = "0";
                                            ACQUIERSETPROFEE = "0";

                                            TRANSACQUIERCONVERRATE = "0";
                                            CARDACCEPTSETDATE = "0";
                                            ACCSETDATE = "0";

                                            //New Added
                                            ORIGINALCHANNEL = string.Empty;
                                            BeneIFSCCODE = string.Empty;
                                            BeneAccountNumber = string.Empty;
                                            REMIFSCCODE = string.Empty;
                                            REMACCOUNTNUMBER = string.Empty;

                                            timestamp = string.Empty;
                                            TxnsDateTimeMain = null;

                                            Participant_ID = PARTICIPENTID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PARTICIPENTID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Type = TRANSTYPE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSTYPE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            From_Account_Type = FROMACCOUNTTYPE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FROMACCOUNTTYPE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            To_Account_Type = TOACCOUNTTYPE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TOACCOUNTTYPE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Serial_Number = TRANSSERIALNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSSERIALNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Response_Code = RESPONSECODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][RESPONSECODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            PAN_Number = PAN_Number_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PAN_Number_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            MEMNUMBER = MEMNUMBER_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][MEMNUMBER_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Approval_Number = APPROVALNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][APPROVALNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Merchant_Category_Code = MERCHENTCATCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][MERCHENTCATCODE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            CARDACCEPTSETDATE = CARDACCEPTERSETDATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERSETDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Card_Acceptor_ID = CARDACCEPTERID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERID_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            Acquirer_ID = ACQUIRERID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQUIRERID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            SYSTRACAUDITNO = SYSTRACAUDITNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SYSTRACAUDITNO_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            Transaction_Currency_Code = TRANSCURCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSCURCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Amount = TRANSAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACCTUALTRANSAMOUNT = ACCTUALTRANSAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACCTUALTRANSAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TRANSACTIVITYFEE = TRANSACCVITYFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSACCVITYFEE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            ACCURSETCURCODE = ACCURSETCURCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACCURSETCURCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACQUIERSETAMOUNT = ACQUIERSETAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQUIERSETAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACQUIERSETFEE = ACQUIERSETFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQUIERSETFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACQUIERSETPROFEE = ACQUIERSETPROFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQUIERSETPROFEE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            TRANSACQUIERCONVERRATE = TTRANSACQUIERCONVERRATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TTRANSACQUIERCONVERRATE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            //New Added
                                            ORIGINALCHANNEL = ORIGINALCHANNEL_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ORIGINALCHANNEL_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            BeneIFSCCODE = BeneIFSCCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BeneIFSCCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            BeneAccountNumber = BeneAccountNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BeneAccountNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            REMIFSCCODE = REMIFSCCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][REMIFSCCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            REMACCOUNTNUMBER = REMACCOUNTNUMBER_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][REMACCOUNTNUMBER_CoulmnIndex - Incr]).Trim() : string.Empty;


                                            Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                                            ACCTUALTRANSAMOUNT = Common.IsNumeric(ACCTUALTRANSAMOUNT) ? ACCTUALTRANSAMOUNT : "0";
                                            TRANSACTIVITYFEE = Common.IsNumeric(TRANSACTIVITYFEE) ? TRANSACTIVITYFEE : "0";
                                            ACQUIERSETAMOUNT = Common.IsNumeric(ACQUIERSETAMOUNT) ? ACQUIERSETAMOUNT : "0";
                                            ACQUIERSETFEE = Common.IsNumeric(ACQUIERSETFEE) ? ACQUIERSETFEE : "0";
                                            ACQUIERSETPROFEE = Common.IsNumeric(ACQUIERSETPROFEE) ? ACQUIERSETPROFEE : "0";
                                            SYSTRACAUDITNO = Common.IsNumeric(SYSTRACAUDITNO) ? SYSTRACAUDITNO : "0";


                                            TRANSACQUIERCONVERRATE = Common.IsNumeric(TRANSACQUIERCONVERRATE) ? TRANSACQUIERCONVERRATE : "0";
                                            CARDACCEPTSETDATE = Common.IsNumeric(CARDACCEPTSETDATE) ? CARDACCEPTSETDATE : "0";
                                            Merchant_Category_Code = Common.IsNumeric(Merchant_Category_Code) ? Merchant_Category_Code : "0";

                                            TransDate = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            if (TransDate.Length > 0 && Transaction_Time.Length > 0)
                                            {
                                                timestamp = TransDate + " " + Transaction_Time;
                                            }

                                            TxnsDateTimeMain = DateTime.ParseExact(timestamp, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None);

                                            FORCEMATCH = false;
                                            if (TxnsDateTimeMain != null)
                                            {

                                                _DataTable.Rows.Add(Participant_ID.Trim(), Transaction_Type.Trim(), From_Account_Type.Trim(), To_Account_Type.Trim(), Transaction_Serial_Number.Trim(), Response_Code.Trim(), PAN_Number.Trim(), MEMNUMBER.Trim(),
                                                                   Approval_Number.Trim(), SYSTRACAUDITNO.Trim(), TxnsDateTimeMain, TransDate.Trim(), Transaction_Time.Trim(), Merchant_Category_Code.Trim(), CARDACCEPTSETDATE.Trim(), CARDACCID.Trim(), Card_Acceptor_ID.Trim(), CARDACCEPTERTERLOC.Trim(),
                                                                      Acquirer_ID, ACCSETDATE, Transaction_Currency_Code, Transaction_Amount, ACCTUALTRANSAMOUNT, TRANSACTIVITYFEE, ACCURSETCURCODE, ACQUIERSETAMOUNT, ACQUIERSETFEE, ACQUIERSETPROFEE, TRANSACQUIERCONVERRATE,
                                                                      FORCEMATCH, Cycle.Trim(), CardScheme, IssuingNetwork, ORIGINALCHANNEL, BeneIFSCCODE, BeneAccountNumber, REMIFSCCODE, REMACCOUNTNUMBER);

                                                if (_DataTable.Rows.Count >= batchSize)
                                                {
                                                    BatchNo++;
                                                    MSG = bulkimports.BulkInsertAcquirerDataIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                    BatchDetails batchDetails = new BatchDetails
                                                    {
                                                        BatchNo = BatchNo,
                                                        BatchSize = batchSize,
                                                        TxnUploadCount = _DataTable.Rows.Count,
                                                        TxnsCount = fileImportRequest.InsertCount,
                                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                        FailedCount = ErrorCount,
                                                        BatchStartTime = batchStartTime,
                                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                    };

                                                    batchDetailsList.Add(batchDetails);
                                                    _DataTable.Clear();
                                                    ErrorCount = 0;
                                                    StartTime = DateTime.Now;

                                                    if (NewEntry)
                                                    {
                                                        break;
                                                    }
                                                }
                                            }

                                        }
                                        catch (Exception ex)
                                        {
                                            ErrorCount++;
                                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                        }
                                    }
                                }
                                else
                                {
                                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched";
                                    break;
                                }
                            }
                        }

                        LineNo = 0;
                    }
                }
            }

            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkimports.BulkInsertAcquirerDataIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                //  _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
            {
                MSG = "Successful";
            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }

        public string Splitter_NPCI_Settlement_IMPS_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            string TempRemark = string.Empty;
            int LineNo = 0, ErrorCount = 0;
            int SheetLineNumber = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("NoTxns", typeof(int));
            _DataTable.Columns.Add("Debit", typeof(decimal));
            _DataTable.Columns.Add("Credit", typeof(decimal));
            _DataTable.Columns.Add("Bank", typeof(string));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));

            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
            string FileDateFormat = fileImportRequest.ConfigData.Rows[0]["FileDateFormat"].ToString();

            DateTime? TxnsDateTimeMain = null;
            DateTime? FileDateTime = null;

            string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

            string[] FDA = Path.GetFileNameWithoutExtension(fileImportRequest.FileName).Split('_');
            string Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

            DataSet ds = new DataSet();

            try
            {

                conString = string.Format(conString, fileImportRequest.Path);

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                ushort Description_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Description"]);
                ushort NoTxns_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NoTxns"]);
                ushort Debit_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Debit"]);
                ushort Credit_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Credit"]);
                ushort Remarks_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remarks"]);
                ushort Date_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Date"]);

                DataTable dtexcelsheetname = new DataTable();
                DataTable dtSheet = new DataTable();

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }

                DateTime StartTime = DateTime.Now;
                string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);


                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {


                    int j = 0;

                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }
                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = Getdatafromsheet1;
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            int Incr = 1;
                            string Description = string.Empty;
                            string NoTxnsValue = "0";
                            string DebitValue = "0";
                            string CreditValue = "0";
                            string Remarks = string.Empty;
                            string TxnsDate = string.Empty;
                            string BankName = ClientID.ToString();
                            int start, end; 

                            if (dtSheet.Rows.Count > 1)
                            {
                                fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                for (int k = 0; k < dtSheet.Rows.Count; k++)
                                {
                                    Incr = 1;
                                    SheetLineNumber++;
                                    LineNo++;
                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    Description = string.Empty;
                                    NoTxnsValue = "0";
                                    DebitValue = "0";
                                    CreditValue = "0";
                                    Remarks = string.Empty;
                                    TxnsDate = string.Empty;
                                    TxnsDateTimeMain = null;

                                    try
                                    {

                                        Description = Description_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Description_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        if (Description.Contains("Daily Settlement Statement for"))
                                        {
                                            TempRemark = Description;

                                            start = TempRemark.IndexOf("for ") + 4;
                                            end = TempRemark.IndexOf("as on");

                                            if (end > start)
                                            {
                                                BankName = TempRemark.Substring(start, end - start).Trim();
                                                BankName = BankName.Substring(0, BankName.Length > 100 ? 100 : BankName.Length);
                                            }
                                        }
                                        NoTxnsValue = NoTxns_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][NoTxns_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        DebitValue = Debit_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Debit_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        CreditValue = Credit_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Credit_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Remarks = Remarks_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Remarks_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsDate = Date_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Date_CoulmnIndex - Incr]).Trim() : string.Empty;


                                        if (TxnsDate.Length > 0)
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDate, TxnDateTime, CultureInfo.InvariantCulture);
                                        }
                                        else
                                        {
                                            TxnsDateTimeMain = fileImportRequest.FileDateTime;
                                        }

                                        NoTxnsValue = Common.IsNumeric(NoTxnsValue) ? NoTxnsValue : "0";
                                        DebitValue = Common.IsNumeric(DebitValue) ? DebitValue : "0";
                                        CreditValue = Common.IsNumeric(CreditValue) ? CreditValue : "0";

                                        if (fileImportRequest.ClientCode == "56" && Description.Contains("ESB"))
                                        {
                                            TempRemark = "ESB";
                                        }
                                        else if (fileImportRequest.ClientCode == "56" && TempRemark != "ESB")
                                        {
                                            TempRemark = "ESF";
                                        }


                                        if (Remarks.Length == 0)
                                        {
                                            Remarks = TempRemark;
                                        }

                                        if (Description != "" && (Convert.ToDecimal(DebitValue) > 0 || Convert.ToDecimal(CreditValue) > 0) && TxnsDateTimeMain != null)
                                        {
                                            _DataTable.Rows.Add(
                                                TxnsDateTimeMain
                                                , Cycle
                                                , Convert.ToDecimal(NoTxnsValue)
                                                , Convert.ToDecimal(DebitValue)
                                                , Convert.ToDecimal(CreditValue)
                                                , BankName
                                                , Description
                                                , Remarks);

                                            if (_DataTable.Rows.Count >= batchSize)
                                            {
                                                BatchNo++;
                                                MSG = bulkimports.BulkInsertSettlementDataIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                BatchDetails batchDetails = new BatchDetails
                                                {
                                                    BatchNo = BatchNo,
                                                    BatchSize = batchSize,
                                                    TxnUploadCount = _DataTable.Rows.Count,
                                                    TxnsCount = fileImportRequest.InsertCount,
                                                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                    FailedCount = ErrorCount,
                                                    BatchStartTime = batchStartTime,
                                                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                };

                                                batchDetailsList.Add(batchDetails);
                                                _DataTable.Clear();
                                                ErrorCount = 0;
                                                StartTime = DateTime.Now;

                                                if (NewEntry)
                                                {
                                                    break;
                                                }
                                            }
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorCount++;
                                        DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    }
                                }
                            }

                            j++;
                        }

                        LineNo = 0;
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    BatchNo = BatchNo + 1;

                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                    MSG = bulkimports.BulkInsertSettlementDataIMPS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                    BatchDetails batchDetails = new BatchDetails
                    {
                        BatchNo = BatchNo,
                        BatchSize = batchSize,
                        TxnUploadCount = _DataTable.Rows.Count,
                        TxnsCount = fileImportRequest.InsertCount,
                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                        FailedCount = ErrorCount,
                        BatchStartTime = batchStartTime,
                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    };

                    batchDetailsList.Add(batchDetails);

                    //  _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

                }
                else if (_DataTable.Rows.Count == 0 && ErrorCount == 0)
                {
                    MSG = "Successful";
                }

            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        string ExtractNumber(string original)
        {
            return new string(original.Where(c => Char.IsDigit(c)).ToArray());
        }
    }
}
