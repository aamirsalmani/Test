﻿using ImportData;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Reflection;
using System.Text;
using Utility;

namespace NetworkNPCI
{
    public class NPCINETC
    {
        private readonly string _connectionString;
        BulkImports bulkimports;
        public NPCINETC(string connectionString)
        {
            _connectionString = connectionString;
            bulkimports = new BulkImports(_connectionString, " ", " ");
        }

        public DataTable SplitterNETCACQUIRER(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0, ErrorCount = 0;

            DataSet ds = new DataSet();

            DataTable _DataTableFastNWRAW = new DataTable();

            _DataTableFastNWRAW.Columns.Add("ClientID", typeof(int));
            _DataTableFastNWRAW.Columns.Add("ChannelID", typeof(int));
            _DataTableFastNWRAW.Columns.Add("ModeID", typeof(int));
            _DataTableFastNWRAW.Columns.Add("TerminalId", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TRANS_MerchantType", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ReferenceNumber", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TransactionSequenceNumber", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TransactionID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("MessageID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("Note", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ReferenceID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ReferenceURL", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TransactionDateandTime", typeof(DateTime));
            _DataTableFastNWRAW.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTableFastNWRAW.Columns.Add("TxnsType", typeof(string));
            _DataTableFastNWRAW.Columns.Add("OriginalTransactionID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TagID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("AVC", typeof(string));
            _DataTableFastNWRAW.Columns.Add("WIM", typeof(string));
            _DataTableFastNWRAW.Columns.Add("MerchantId", typeof(string));
            _DataTableFastNWRAW.Columns.Add("MerchantType", typeof(string));
            _DataTableFastNWRAW.Columns.Add("SubMerchantType", typeof(string));
            _DataTableFastNWRAW.Columns.Add("LanID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("LaneDirection", typeof(string));
            _DataTableFastNWRAW.Columns.Add("LaneReaderID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ParkingFloor", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ParkingZone", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ParkingSlot", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ParkingReaderID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("Reader_Read_DateandTime", typeof(DateTime));
            _DataTableFastNWRAW.Columns.Add("SignatureData", typeof(string));
            _DataTableFastNWRAW.Columns.Add("SignatureAuthentication", typeof(string));
            _DataTableFastNWRAW.Columns.Add("EPCVerified", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ProcRestrictionRes", typeof(string));
            _DataTableFastNWRAW.Columns.Add("VehicleAuth", typeof(string));
            _DataTableFastNWRAW.Columns.Add("PublicKeyCVV", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ReaderTransactionCounter", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ReaderTransactionStatus", typeof(string));
            _DataTableFastNWRAW.Columns.Add("PayerAddress", typeof(string));
            _DataTableFastNWRAW.Columns.Add("IssuerID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("PayerCode", typeof(string));
            _DataTableFastNWRAW.Columns.Add("Payername", typeof(string));
            _DataTableFastNWRAW.Columns.Add("PayerType", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTableFastNWRAW.Columns.Add("CurrencyCode", typeof(string));
            _DataTableFastNWRAW.Columns.Add("PayeeAddress", typeof(string));
            _DataTableFastNWRAW.Columns.Add("AcquirerID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("PayeeCode", typeof(string));
            _DataTableFastNWRAW.Columns.Add("Payeename", typeof(string));
            _DataTableFastNWRAW.Columns.Add("PayeeType", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ResponseCode", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TxnsStatus", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ApprovalNumber", typeof(string));
            _DataTableFastNWRAW.Columns.Add("PayeeErrorCode", typeof(string));
            _DataTableFastNWRAW.Columns.Add("SettlementAmount", typeof(decimal));
            _DataTableFastNWRAW.Columns.Add("SettlementCurrency", typeof(string));
            _DataTableFastNWRAW.Columns.Add("AccountType", typeof(string));
            _DataTableFastNWRAW.Columns.Add("AvailableBalance", typeof(decimal));
            _DataTableFastNWRAW.Columns.Add("LedgerBalance", typeof(decimal));
            _DataTableFastNWRAW.Columns.Add("AccountNo", typeof(string));

            _DataTableFastNWRAW.Columns.Add("CustomerName", typeof(string));
            _DataTableFastNWRAW.Columns.Add("InitiatedBy", typeof(string));
            _DataTableFastNWRAW.Columns.Add("Initiated_DateTime", typeof(DateTime));
            _DataTableFastNWRAW.Columns.Add("LastUpdatedBy", typeof(string));
            _DataTableFastNWRAW.Columns.Add("LastUpdatedTime", typeof(DateTime));
            _DataTableFastNWRAW.Columns.Add("VehicleRegistrationnumber", typeof(string));
            _DataTableFastNWRAW.Columns.Add("VehicleClass", typeof(string));
            _DataTableFastNWRAW.Columns.Add("VehicleType", typeof(string));
            _DataTableFastNWRAW.Columns.Add("Tagstatus", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TagIssue_Date", typeof(DateTime));

            _DataTableFastNWRAW.Columns.Add("DrCrType", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TxnsSubType", typeof(string));
            _DataTableFastNWRAW.Columns.Add("TxnsEntryType", typeof(string));
            ///////

            _DataTableFastNWRAW.Columns.Add("ReversalFlag", typeof(bool));
            _DataTableFastNWRAW.Columns.Add("ReserveField1", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ReserveField2", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ReserveField3", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ReserveField4", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ReserveField5", typeof(string));
            _DataTableFastNWRAW.Columns.Add("RevEntryLeg", typeof(int));
            _DataTableFastNWRAW.Columns.Add("NoOfDuplicate", typeof(int));
            _DataTableFastNWRAW.Columns.Add("FileName", typeof(string));
            _DataTableFastNWRAW.Columns.Add("FilePath", typeof(string));
            _DataTableFastNWRAW.Columns.Add("FileDate", typeof(DateTime));
            _DataTableFastNWRAW.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTableFastNWRAW.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTableFastNWRAW.Columns.Add("CreatedBy", typeof(string));
            _DataTableFastNWRAW.Columns.Add("ModifiedBy", typeof(string));
            _DataTableFastNWRAW.Columns.Add("Aggregator", typeof(string));
            _DataTableFastNWRAW.Columns.Add("AggregatorName", typeof(string));
            _DataTableFastNWRAW.Columns.Add("AgentID", typeof(string));
            _DataTableFastNWRAW.Columns.Add("AgentName", typeof(string));

            DataTable dtSheet = new DataTable();
            int ClientID = 0, ChannelID = 0, ModeID = 0;

            try
            {
                string LogType = dt.Rows[0]["FileName"].ToString();
                string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
                string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
                ds.ReadXml(new System.Xml.XmlTextReader(new System.IO.StringReader(xmlFile)));
                ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
                ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());
                ModeID = 2;

                string conString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Text;HDR=YES;FMT=Delimited;' ";

                conString = string.Format(conString, path.Replace(FileName, ""));



                string Getdatafromsheet1 = "SELECT * FROM [" + FileName + "]";

                using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                {
                    using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                    {
                        using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                        {
                            //Read Data from First Sheet.
                            cmdExcelSheet.Connection = connExcelSheet;
                            connExcelSheet.Open();
                            cmdExcelSheet.CommandText = Getdatafromsheet1;
                            odaExcelSheet.SelectCommand = cmdExcelSheet;
                            odaExcelSheet.Fill(dtSheet);
                            connExcelSheet.Close();
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            TotalCount = dtSheet.Rows.Count;

            int Incr = 1;
            bool ReversalFlag = false;
            string TerminalId = string.Empty, TRANS_MerchantType = string.Empty, ReferenceNumber = string.Empty, TransactionSequenceNumber = string.Empty,
                TransactionID = string.Empty, MessageID = string.Empty, Note = string.Empty, ReferenceID = string.Empty, ReferenceURL = string.Empty,
                TxnsType = string.Empty, OriginalTransactionID = string.Empty, TagID = string.Empty, TID = string.Empty, AVC = string.Empty, WIM = string.Empty, MerchantId = string.Empty, MerchantType = string.Empty, SubMerchantType = string.Empty, LanID = string.Empty, LaneDirection = string.Empty, LaneReaderID = string.Empty, ParkingFloor = string.Empty, ParkingZone = string.Empty, ParkingSlot = string.Empty, ParkingReaderID = string.Empty,
                SignatureData = string.Empty, SignatureAuthentication = string.Empty, EPCVerified = string.Empty, ProcRestrictionRes = string.Empty, VehicleAuth = string.Empty, PublicKeyCVV = string.Empty, ReaderTransactionCounter = string.Empty, ReaderTransactionStatus = string.Empty, PayerAddress = string.Empty, IssuerID = string.Empty, PayerCode = string.Empty,
                Payername = string.Empty, PayerType = string.Empty, TxnsAmount = string.Empty, CurrencyCode = string.Empty, PayeeAddress = string.Empty, AcquirerID = string.Empty, PayeeCode = string.Empty, Payeename = string.Empty, PayeeType = string.Empty, ResponseCode = string.Empty, TxnsStatus = string.Empty, ApprovalNumber = string.Empty, PayeeErrorCode = string.Empty, SettlementAmount = string.Empty, SettlementCurrency = string.Empty,
                AccountType = string.Empty, AvailableBalance = string.Empty, LedgerBalance = string.Empty, AccountNo = string.Empty, CustomerName = string.Empty, InitiatedBy = string.Empty, LastUpdatedBy = string.Empty, VehicleRegistrationnumber = string.Empty, VehicleClass = string.Empty, VehicleType = string.Empty, Tagstatus = string.Empty,
                DrCrType = string.Empty, TxnsSubType = string.Empty, TxnsEntryType = string.Empty, ReserveField1 = string.Empty, ReserveField2 = string.Empty, ReserveField3 = string.Empty, ReserveField4 = string.Empty, ReserveField5 = string.Empty, NoOfDuplicate = string.Empty, FilePath = string.Empty, FileDate = string.Empty, CreatedOn = string.Empty,
                ModifiedOn = string.Empty, CreatedBy = string.Empty, ModifiedBy = string.Empty, Aggregator = string.Empty, AggregatorName = string.Empty, AgentID = string.Empty, AgentName = string.Empty;

            string strTransactionDateandTime = string.Empty, strTxnsDateTime = string.Empty, strInitiated_DateTime = string.Empty, strLastUpdatedTime = string.Empty, strReader_Read_DateandTime = string.Empty, strTagIssue_Date = string.Empty;


            DateTime? TxnsDateTime = null; DateTime? TransactionDateandTime = null; DateTime? Initiated_DateTime = null;
            DateTime? LastUpdatedTime = null; DateTime? Reader_Read_DateandTime = null; DateTime? TagIssue_Date = null;

            string[] strDateTimeArrayAMPM = new string[2] { "d/M/yyyy h:mm:ss tt", "d-M-yyyy h:mm:ss tt" };
            string[] strDateTimeArray = new string[2] { "d/M/yyyy h:mm:ss", "d-M-yyyy h:mm:ss" };
            string[] DateTimeArrayAMPM = new string[2] { "M/d/yyyy h:mm:ss tt", "M-d-yyyy h:mm:ss tt" };
            string[] DateTimeArray = new string[2] { "M/d/yyyy h:mm:ss", "M-d-yyyy h:mm:ss" };

            if (dtSheet.Rows.Count > 1)
            {
                for (int k = 0; k < dtSheet.Rows.Count; k++)
                {
                    LineNo++;
                    try
                    {
                        //string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                        //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                        Incr = 1;
                        ReversalFlag = false;
                        TerminalId = string.Empty; TRANS_MerchantType = string.Empty; ReferenceNumber = string.Empty; TransactionSequenceNumber = string.Empty; TransactionID = string.Empty; MessageID = string.Empty; Note = string.Empty; ReferenceID = string.Empty; ReferenceURL = string.Empty;
                        TxnsType = string.Empty; OriginalTransactionID = string.Empty; TagID = string.Empty; TID = string.Empty; AVC = string.Empty; WIM = string.Empty; MerchantId = string.Empty; MerchantType = string.Empty; SubMerchantType = string.Empty; LanID = string.Empty; LaneDirection = string.Empty; LaneReaderID = string.Empty; ParkingFloor = string.Empty; ParkingZone = string.Empty; ParkingSlot = string.Empty; ParkingReaderID = string.Empty;
                        SignatureData = string.Empty; SignatureAuthentication = string.Empty; EPCVerified = string.Empty; ProcRestrictionRes = string.Empty; VehicleAuth = string.Empty; PublicKeyCVV = string.Empty; ReaderTransactionCounter = string.Empty; ReaderTransactionStatus = string.Empty; PayerAddress = string.Empty; IssuerID = string.Empty; PayerCode = string.Empty;
                        Payername = string.Empty; PayerType = string.Empty; TxnsAmount = string.Empty; CurrencyCode = string.Empty; PayeeAddress = string.Empty; AcquirerID = string.Empty; PayeeCode = string.Empty; Payeename = string.Empty; PayeeType = string.Empty; ResponseCode = string.Empty; TxnsStatus = string.Empty; ApprovalNumber = string.Empty; PayeeErrorCode = string.Empty; SettlementAmount = string.Empty; SettlementCurrency = string.Empty;
                        AccountType = string.Empty; AvailableBalance = string.Empty; LedgerBalance = string.Empty; AccountNo = string.Empty; CustomerName = string.Empty; InitiatedBy = string.Empty; LastUpdatedBy = string.Empty; VehicleRegistrationnumber = string.Empty; VehicleClass = string.Empty; VehicleType = string.Empty; Tagstatus = string.Empty;
                        DrCrType = string.Empty; TxnsSubType = string.Empty; TxnsEntryType = string.Empty; ReserveField1 = string.Empty; ReserveField2 = string.Empty; ReserveField3 = string.Empty; ReserveField4 = string.Empty; ReserveField5 = string.Empty; NoOfDuplicate = string.Empty; FilePath = string.Empty; FileDate = string.Empty; CreatedOn = string.Empty; ModifiedOn = string.Empty; CreatedBy = string.Empty; ModifiedBy = string.Empty; Aggregator = string.Empty;
                        AggregatorName = string.Empty; AgentID = string.Empty; AgentName = string.Empty; strTransactionDateandTime = string.Empty; strTxnsDateTime = string.Empty; strInitiated_DateTime = string.Empty; strLastUpdatedTime = string.Empty; strReader_Read_DateandTime = string.Empty; strTagIssue_Date = string.Empty;
                        TxnsDateTime = null; TransactionDateandTime = null; Initiated_DateTime = null; LastUpdatedTime = null; Reader_Read_DateandTime = null; TagIssue_Date = null;

                        if (ds.Tables[0].Rows[0]["TerminalID"].ToString() != "0")
                        {
                            TerminalId = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TerminalID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ReferenceNumber"].ToString() != "0")
                        {
                            ReferenceNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReferenceNumber"].ToString()) - Incr].ToString().Trim();
                        }

                        if (ds.Tables[0].Rows[0]["TransactionSequenceNumber"].ToString() != "0")
                        {
                            TransactionSequenceNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TransactionSequenceNumber"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["TransactionID"].ToString() != "0")
                        {
                            TransactionID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TransactionID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["MessageID"].ToString() != "0")
                        {
                            MessageID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["MessageID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["Note"].ToString() != "0")
                        {
                            Note = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Note"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ReferenceID"].ToString() != "0")
                        {
                            ReferenceID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReferenceID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ReferenceURL"].ToString() != "0")
                        {
                            ReferenceURL = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReferenceURL"].ToString()) - Incr].ToString().Trim();
                        }

                        if (ds.Tables[0].Rows[0]["TransactionDateandTime"].ToString() != "0")
                        {
                            strTransactionDateandTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TransactionDateandTime"].ToString()) - Incr].ToString().Trim();
                            try
                            {
                                if (strTransactionDateandTime.Contains("AM") || strTransactionDateandTime.Contains("PM"))
                                    TransactionDateandTime = DateTime.ParseExact(strTransactionDateandTime, strDateTimeArrayAMPM, System.Globalization.CultureInfo.InvariantCulture);
                                else TransactionDateandTime = DateTime.ParseExact(strTransactionDateandTime, strDateTimeArray, System.Globalization.CultureInfo.InvariantCulture);
                            }
                            catch
                            {
                                TransactionDateandTime = Convert.ToDateTime(strTransactionDateandTime);
                            }


                        }
                        if (ds.Tables[0].Rows[0]["TxnsDateTime"].ToString() != "0")
                        {
                            strTxnsDateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsDateTime"].ToString()) - Incr].ToString().Trim();
                            try
                            {
                                if (strTxnsDateTime.Contains("AM") || strTxnsDateTime.Contains("PM"))
                                    TxnsDateTime = DateTime.ParseExact(strTxnsDateTime, strDateTimeArrayAMPM, System.Globalization.CultureInfo.InvariantCulture);
                                else TxnsDateTime = DateTime.ParseExact(strTxnsDateTime, strDateTimeArray, System.Globalization.CultureInfo.InvariantCulture);
                            }
                            catch
                            {
                                TxnsDateTime = Convert.ToDateTime(strTxnsDateTime);
                            }


                        }
                        if (ds.Tables[0].Rows[0]["TxnsType"].ToString() != "0")
                        {
                            TxnsType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsType"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["OriginalTransactionID"].ToString() != "0")
                        {
                            OriginalTransactionID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["OriginalTransactionID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["TagID"].ToString() != "0")
                        {
                            TagID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TagID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["TID"].ToString() != "0")
                        {
                            TID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["AVC"].ToString() != "0")
                        {
                            AVC = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AVC"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["WIM"].ToString() != "0")
                        {
                            WIM = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["WIM"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["MerchantId"].ToString() != "0")
                        {
                            MerchantId = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["MerchantId"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["MerchantType"].ToString() != "0")
                        {
                            MerchantType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["MerchantType"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["SubMerchantType"].ToString() != "0")
                        {
                            SubMerchantType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SubMerchantType"].ToString()) - Incr].ToString().Trim();
                        }

                        if (ds.Tables[0].Rows[0]["LanID"].ToString() != "0")
                        {
                            LanID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["LanID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["LaneDirection"].ToString() != "0")
                        {
                            LaneDirection = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["LaneDirection"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["LaneReaderID"].ToString() != "0")
                        {
                            LaneReaderID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["LaneReaderID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ParkingFloor"].ToString() != "0")
                        {
                            ParkingFloor = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ParkingFloor"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ParkingZone"].ToString() != "0")
                        {
                            ParkingZone = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ParkingZone"].ToString()) - Incr].ToString().Trim();
                        }

                        if (ds.Tables[0].Rows[0]["ParkingSlot"].ToString() != "0")
                        {
                            ParkingSlot = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ParkingSlot"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ParkingReaderID"].ToString() != "0")
                        {
                            ParkingReaderID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ParkingReaderID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["Reader_Read_DateandTime"].ToString() != "0")
                        {
                            strReader_Read_DateandTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Reader_Read_DateandTime"].ToString()) - Incr].ToString().Trim();
                            try
                            {
                                if (strReader_Read_DateandTime.Contains("AM") || strReader_Read_DateandTime.Contains("PM"))
                                    Reader_Read_DateandTime = DateTime.ParseExact(strReader_Read_DateandTime, strDateTimeArrayAMPM, System.Globalization.CultureInfo.InvariantCulture);
                                else Reader_Read_DateandTime = DateTime.ParseExact(strReader_Read_DateandTime, strDateTimeArray, System.Globalization.CultureInfo.InvariantCulture);
                            }
                            catch
                            {
                                Reader_Read_DateandTime = Convert.ToDateTime(strReader_Read_DateandTime);
                            }


                        }
                        if (ds.Tables[0].Rows[0]["SignatureData"].ToString() != "0")
                        {
                            SignatureData = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SignatureData"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["SignatureAuthentication"].ToString() != "0")
                        {
                            SignatureAuthentication = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SignatureAuthentication"].ToString()) - Incr].ToString().Trim();
                        }

                        if (ds.Tables[0].Rows[0]["EPCVerified"].ToString() != "0")
                        {
                            EPCVerified = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["EPCVerified"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ProcRestrictionRes"].ToString() != "0")
                        {
                            ProcRestrictionRes = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ProcRestrictionRes"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["VehicleAuth"].ToString() != "0")
                        {
                            VehicleAuth = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["VehicleAuth"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["PublicKeyCVV"].ToString() != "0")
                        {
                            PublicKeyCVV = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["PublicKeyCVV"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ReaderTransactionCounter"].ToString() != "0")
                        {
                            ReaderTransactionCounter = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReaderTransactionCounter"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ReaderTransactionStatus"].ToString() != "0")
                        {
                            ReaderTransactionStatus = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReaderTransactionStatus"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["PayerAddress"].ToString() != "0")
                        {
                            PayerAddress = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["PayerAddress"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["IssuerID"].ToString() != "0")
                        {
                            IssuerID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["IssuerID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["PayerCode"].ToString() != "0")
                        {
                            PayerCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["PayerCode"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["Payername"].ToString() != "0")
                        {
                            Payername = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Payername"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["PayerType"].ToString() != "0")
                        {
                            PayerType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["PayerType"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["TxnsAmount"].ToString() != "0")
                        {
                            TxnsAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsAmount"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["CurrencyCode"].ToString() != "0")
                        {
                            CurrencyCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CurrencyCode"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["PayeeAddress"].ToString() != "0")
                        {
                            PayeeAddress = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["PayeeAddress"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["AcquirerID"].ToString() != "0")
                        {
                            AcquirerID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AcquirerID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["PayeeCode"].ToString() != "0")
                        {
                            PayeeCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["PayeeCode"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["Payeename"].ToString() != "0")
                        {
                            Payeename = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Payeename"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["PayeeType"].ToString() != "0")
                        {
                            PayeeType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["PayeeType"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ResponseCode"].ToString() != "0")
                        {
                            ResponseCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ResponseCode"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["TxnsStatus"].ToString() != "0")
                        {
                            TxnsStatus = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsStatus"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ApprovalNumber"].ToString() != "0")
                        {
                            ApprovalNumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ApprovalNumber"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["PayeeErrorCode"].ToString() != "0")
                        {
                            PayeeErrorCode = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["PayeeErrorCode"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["SettlementAmount"].ToString() != "0")
                        {
                            SettlementAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SettlementAmount"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["SettlementCurrency"].ToString() != "0")
                        {
                            SettlementCurrency = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SettlementCurrency"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["AccountType"].ToString() != "0")
                        {
                            AccountType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AccountType"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["AvailableBalance"].ToString() != "0")
                        {
                            AvailableBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AvailableBalance"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["LedgerBalance"].ToString() != "0")
                        {
                            LedgerBalance = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["LedgerBalance"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["AccountNo"].ToString() != "0")
                        {
                            AccountNo = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AccountNo"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["CustomerName"].ToString() != "0")
                        {
                            CustomerName = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["CustomerName"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["InitiatedBy"].ToString() != "0")
                        {
                            InitiatedBy = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["InitiatedBy"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["Initiated_DateTime"].ToString() != "0")
                        {
                            strInitiated_DateTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Initiated_DateTime"].ToString()) - Incr].ToString().Trim();
                            try
                            {
                                if (strInitiated_DateTime.Contains("AM") || strInitiated_DateTime.Contains("PM"))
                                    Initiated_DateTime = DateTime.ParseExact(strInitiated_DateTime, strDateTimeArrayAMPM, System.Globalization.CultureInfo.InvariantCulture);
                                else Initiated_DateTime = DateTime.ParseExact(strInitiated_DateTime, strDateTimeArray, System.Globalization.CultureInfo.InvariantCulture);
                            }
                            catch
                            {
                                Initiated_DateTime = DateTime.ParseExact(strInitiated_DateTime.Substring(0, 10).ToString().Trim(), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                            }


                        }
                        if (ds.Tables[0].Rows[0]["LastUpdatedBy"].ToString() != "0")
                        {
                            LastUpdatedBy = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["LastUpdatedBy"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["LastUpdatedTime"].ToString() != "0")
                        {
                            strLastUpdatedTime = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["LastUpdatedTime"].ToString()) - Incr].ToString().Trim();
                            try
                            {
                                if (strLastUpdatedTime.Contains("AM") || strLastUpdatedTime.Contains("PM"))
                                    LastUpdatedTime = DateTime.ParseExact(strLastUpdatedTime, strDateTimeArrayAMPM, System.Globalization.CultureInfo.InvariantCulture);
                                else LastUpdatedTime = DateTime.ParseExact(strLastUpdatedTime, strDateTimeArray, System.Globalization.CultureInfo.InvariantCulture);
                            }
                            catch
                            {
                                //LastUpdatedTime = Convert.ToDateTime(strLastUpdatedTime);
                                LastUpdatedTime = DateTime.ParseExact(strLastUpdatedTime.Substring(0, 10).ToString().Trim(), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
                            }


                        }

                        if (ds.Tables[0].Rows[0]["VehicleRegistrationnumber"].ToString() != "0")
                        {
                            VehicleRegistrationnumber = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["VehicleRegistrationnumber"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["VehicleClass"].ToString() != "0")
                        {
                            VehicleClass = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["VehicleClass"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["VehicleType"].ToString() != "0")
                        {
                            VehicleType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["VehicleType"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["Tagstatus"].ToString() != "0")
                        {
                            Tagstatus = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Tagstatus"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["TagIssue_Date"].ToString() != "0")
                        {
                            strTagIssue_Date = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TagIssue_Date"].ToString()) - Incr].ToString().Trim();
                            try
                            {
                                if (strTagIssue_Date.Contains("AM") || strTagIssue_Date.Contains("PM"))
                                    TagIssue_Date = DateTime.ParseExact(strTagIssue_Date, DateTimeArrayAMPM, System.Globalization.CultureInfo.InvariantCulture);
                                else TagIssue_Date = DateTime.ParseExact(strTagIssue_Date, DateTimeArray, System.Globalization.CultureInfo.InvariantCulture);
                            }
                            catch
                            {
                                strTagIssue_Date = strTagIssue_Date.Replace("/", "-") + " 00:00:00";
                                TagIssue_Date = DateTime.ParseExact(strTagIssue_Date, "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.InvariantCulture);
                            }

                            //TagIssue_Date = DateTime.ParseExact(strTagIssue_Date, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                        }
                        if (ds.Tables[0].Rows[0]["DrCrType"].ToString() != "0")
                        {
                            DrCrType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["DrCrType"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["TxnsSubType"].ToString() != "0")
                        {
                            TxnsSubType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsSubType"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["TxnsEntryType"].ToString() != "0")
                        {
                            TxnsEntryType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsEntryType"].ToString()) - Incr].ToString().Trim();
                        }
                        //   if (ds.Tables[0].Rows[0]["ReversalFlag"].ToString() != "0")
                        //{
                        //    ReversalFlag = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReversalFlag"].ToString()) - Incr].ToString().Trim();
                        //}


                        /////////////////////done above

                        if (ds.Tables[0].Rows[0]["ReserveField1"].ToString() != "0")
                        {
                            ReserveField1 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField1"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ReserveField2"].ToString() != "0")
                        {
                            ReserveField2 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField2"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ReserveField3"].ToString() != "0")
                        {
                            ReserveField3 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField3"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ReserveField4"].ToString() != "0")
                        {
                            ReserveField4 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField4"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["ReserveField5"].ToString() != "0")
                        {
                            ReserveField5 = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ReserveField5"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["Aggregator"].ToString() != "0")
                        {
                            Aggregator = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Aggregator"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["AggregatorName"].ToString() != "0")
                        {
                            AggregatorName = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AggregatorName"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["AgentID"].ToString() != "0")
                        {
                            AgentID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AgentID"].ToString()) - Incr].ToString().Trim();
                        }
                        if (ds.Tables[0].Rows[0]["AgentName"].ToString() != "0")
                        {
                            AgentName = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["AgentName"].ToString()) - Incr].ToString().Trim();
                        }



                        if (TxnsDateTime != null)
                        {

                            _DataTableFastNWRAW.Rows.Add(ClientID, ChannelID, ModeID, TerminalId, TRANS_MerchantType, ReferenceNumber, TransactionSequenceNumber, TransactionID
                                , MessageID, Note, ReferenceID, ReferenceURL, TransactionDateandTime, TxnsDateTime, TxnsType, OriginalTransactionID, TagID, TID, AVC, WIM
                                , MerchantId, MerchantType, SubMerchantType, LanID, LaneDirection, LaneReaderID, ParkingFloor, ParkingZone, ParkingSlot, ParkingReaderID
                                , Reader_Read_DateandTime, SignatureData, SignatureAuthentication, EPCVerified, ProcRestrictionRes, VehicleAuth, PublicKeyCVV
                                , ReaderTransactionCounter, ReaderTransactionStatus, PayerAddress, IssuerID, PayerCode, Payername, PayerType, Convert.ToDecimal(TxnsAmount), CurrencyCode
                                , PayeeAddress, AcquirerID, PayeeCode, Payeename, PayeeType, ResponseCode, TxnsStatus, ApprovalNumber, PayeeErrorCode, Convert.ToDecimal(SettlementAmount)
                                , SettlementCurrency, AccountType, AvailableBalance, LedgerBalance, AccountNo, CustomerName, InitiatedBy, Initiated_DateTime
                                , LastUpdatedBy, LastUpdatedTime, VehicleRegistrationnumber, VehicleClass, VehicleType, Tagstatus, TagIssue_Date, DrCrType, TxnsSubType, TxnsEntryType
                                , ReversalFlag, ReserveField1, ReserveField2, ReserveField3, ReserveField4, ReserveField5, 0, 0, FileName, path.Trim(), null, DateTime.Now
                                , DateTime.Now, UserName.Trim(), "", Aggregator, AggregatorName, AgentID, AgentName
                                );
                        }

                    }
                    catch (Exception ex)
                    {
                        ErrorCount++;
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }
                }
            }

            if (_DataTableFastNWRAW.Rows.Count > 0)
            {
                InsertCount = _DataTableFastNWRAW.Rows.Count;
            }


            return _DataTableFastNWRAW;

        }

        public DataTable SplitterAllDispute(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientID)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;
            DataTable _DataTable = new DataTable();
            int ErrorCount = 0;
            try
            {

                _DataTable.Columns.Add("ClientID", typeof(string));
                _DataTable.Columns.Add("ChannelID", typeof(string));
                _DataTable.Columns.Add("ReportDate", typeof(DateTime));
                _DataTable.Columns.Add("DisputeRaiseDate", typeof(DateTime));
                _DataTable.Columns.Add("DisputeRaisedSettlementDate", typeof(DateTime));
                _DataTable.Columns.Add("CaseNumber", typeof(string));
                _DataTable.Columns.Add("FunctionCode", typeof(string));
                _DataTable.Columns.Add("FunctionCodeandDescription", typeof(string));
                _DataTable.Columns.Add("TransactionSequenceNumber", typeof(string));
                _DataTable.Columns.Add("TagID", typeof(string));
                _DataTable.Columns.Add("TID", typeof(string));
                _DataTable.Columns.Add("TransactionDateandTime", typeof(DateTime));
                _DataTable.Columns.Add("ReaderReadDateandTime", typeof(DateTime));
                _DataTable.Columns.Add("TransactionSettlementDate", typeof(DateTime));
                _DataTable.Columns.Add("TransactionAmount", typeof(double));
                _DataTable.Columns.Add("SettlementAmount", typeof(double));
                _DataTable.Columns.Add("SettlementCurrencyCode", typeof(string));
                _DataTable.Columns.Add("Note", typeof(string));
                _DataTable.Columns.Add("TransactionID", typeof(string));
                _DataTable.Columns.Add("TransactionType", typeof(string));
                _DataTable.Columns.Add("MerchantID", typeof(string));
                _DataTable.Columns.Add("Lane_Id", typeof(string));
                _DataTable.Columns.Add("Merchanttype", typeof(string));
                _DataTable.Columns.Add("SubMerchantType", typeof(string));
                _DataTable.Columns.Add("TransactionStatus", typeof(string));
                _DataTable.Columns.Add("TAGStatus", typeof(string));
                _DataTable.Columns.Add("AVC", typeof(string));
                _DataTable.Columns.Add("WIM", typeof(string));
                _DataTable.Columns.Add("OriginatorPoint", typeof(string));
                _DataTable.Columns.Add("AcquirerID", typeof(string));
                _DataTable.Columns.Add("TransactionOriginatorInstitutionPID", typeof(string));
                _DataTable.Columns.Add("AcquirerNameandCountry", typeof(string));
                _DataTable.Columns.Add("IIN", typeof(string));
                _DataTable.Columns.Add("TransactionDestinationInstitutionPID", typeof(string));
                _DataTable.Columns.Add("IssuerNameandCountry", typeof(string));
                _DataTable.Columns.Add("VehicleRegistrationNumber", typeof(string));
                _DataTable.Columns.Add("VehicleClass", typeof(string));
                _DataTable.Columns.Add("VehicleType", typeof(string));
                _DataTable.Columns.Add("FinancialNonFinancialIndicator", typeof(string));
                _DataTable.Columns.Add("DisputeReasoncode", typeof(string));
                _DataTable.Columns.Add("DisputeReasoncodedescription", typeof(string));
                _DataTable.Columns.Add("DisputedAmount", typeof(double));
                _DataTable.Columns.Add("FullPartialIndicator", typeof(string));
                _DataTable.Columns.Add("MemberMessagetext", typeof(string));
                _DataTable.Columns.Add("DocumentIndicator", typeof(string));
                _DataTable.Columns.Add("DocumentAttachedDate", typeof(DateTime));
                _DataTable.Columns.Add("Deadlinedate", typeof(DateTime));
                _DataTable.Columns.Add("Daystoact", typeof(string));
                _DataTable.Columns.Add("DirectionofDispute", typeof(string));

                _DataTable.Columns.Add("CreatedOn", typeof(string));
                _DataTable.Columns.Add("CreatedBy", typeof(string));
                _DataTable.Columns.Add("ModifiedOn", typeof(string));
                _DataTable.Columns.Add("ModifiedBy", typeof(string));
                _DataTable.Columns.Add("FilePath", typeof(string));
                _DataTable.Columns.Add("FileDate", typeof(string));


                _DataTable.Columns.Add("SettledON", typeof(DateTime));
                _DataTable.Columns.Add("SettledRemarks", typeof(string));

                try
                {

                    DateTime? ReportDate = null;
                    DateTime? DisputeRaiseDate = null;
                    DateTime? DisputeRaisedSettlementDate = null;
                    DateTime? TransactionDateandTime = null;
                    DateTime? ReaderReadDateandTime = null;
                    DateTime? TransactionSettlementDate = null;
                    DateTime? DocumentAttachedDate = null;
                    DateTime? Deadlinedate = null;
                    DateTime? SettledON = null;
                    DateTime? CreatedOn = null;
                    DateTime? ModifiedOn = null;
                    DateTime? FileDate = null;

                    string CaseNumber = string.Empty;
                    string FunctionCode = string.Empty;
                    string FunctionCodeandDescription = string.Empty;
                    string TransactionSequenceNumber = string.Empty;
                    string TagID = string.Empty;
                    string TID = string.Empty;
                    double TransactionAmount;
                    double SettlementAmount;
                    string SettlementCurrencyCode = string.Empty;
                    string Note = string.Empty;
                    string TransactionID = string.Empty;
                    string TransactionType = string.Empty;
                    string MerchantID = string.Empty;
                    string Lane_Id = string.Empty;
                    string Merchanttype = string.Empty;
                    string SubMerchantType = string.Empty;
                    string TransactionStatus = string.Empty;
                    string TAGStatus = string.Empty;
                    string AVC = string.Empty;
                    string WIM = string.Empty;
                    string OriginatorPoint = string.Empty;
                    string AcquirerID = string.Empty;
                    string TransactionOriginatorInstitutionPID = string.Empty;
                    string AcquirerNameandCountry = string.Empty;
                    string IIN = string.Empty;
                    string TransactionDestinationInstitutionPID = string.Empty;
                    string IssuerNameandCountry = string.Empty;
                    string VehicleRegistrationNumber = string.Empty;
                    string VehicleClass = string.Empty;
                    string VehicleType = string.Empty;
                    string FinancialNonFinancialIndicator = string.Empty;
                    string DisputeReasoncode = string.Empty;
                    string DisputeReasoncodedescription = string.Empty;
                    double DisputedAmount;
                    string FullPartialIndicator = string.Empty;
                    string MemberMessagetext = string.Empty;
                    string DocumentIndicator = string.Empty;
                    string Daystoact = string.Empty;
                    string DirectionofDispute = string.Empty;
                    string DATE = string.Empty;
                    string SettledRemarks = string.Empty;
                    string CreatedBy = string.Empty;
                    string ModifiedBy = string.Empty;
                    string ChannelID = dt.Rows[0]["ChannelID"].ToString();

                    DataTable dtexcelsheetname = new DataTable();
                    DataTable dtfillsheet1 = new DataTable();

                    string connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;";

                    string extension = Path.GetExtension(path);

                    switch (extension.ToLower())
                    {

                        case ".xls": //Excel 97-03
                                     // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=No;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                            break;
                        case ".xlsx": //Excel 07 or higher
                                      //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text'";
                            break;
                        case ".csv":
                            connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Text;HDR=YES;FMT=Delimited;' ";
                            break;
                    }

                    if (extension.ToLower() == ".csv")
                    {
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Text;HDR=YES;FMT=Delimited;' ";

                        connString = string.Format(connString, path.Replace(FileName, ""));

                        string Getdatafromsheet1 = "SELECT * FROM [" + FileName + "]";

                        using (OleDbConnection connExcelSheet = new OleDbConnection(connString))
                        {
                            using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                            {
                                using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                {
                                    //Read Data from First Sheet.
                                    cmdExcelSheet.Connection = connExcelSheet;
                                    connExcelSheet.Open();
                                    cmdExcelSheet.CommandText = Getdatafromsheet1;
                                    odaExcelSheet.SelectCommand = cmdExcelSheet;
                                    odaExcelSheet.Fill(dtfillsheet1);
                                    connExcelSheet.Close();
                                }
                            }
                        }
                    }
                    else
                    {
                        try
                        {
                            using (OleDbConnection connExcel = new OleDbConnection(connString))
                            {
                                using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                                {
                                    connExcel.Open();
                                    //Get the name of First Sheet.
                                    dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                                    connExcel.Close();
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            DBLog.InsertLogs(ex.Message.ToString(), ClientID, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, 0, FileName, UserName, 'E', _connectionString);
                        }



                        string Getdatafromsheet1 = "SELECT * FROM [" + dtexcelsheetname.Rows[0]["TABLE_NAME"].ToString().Replace("'", "") + "]";


                        using (OleDbConnection connExcelSheet = new OleDbConnection(connString))
                        {
                            using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                            {
                                using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                {
                                    //Read Data from First Sheet.
                                    cmdExcelSheet.Connection = connExcelSheet;
                                    connExcelSheet.Open();
                                    cmdExcelSheet.CommandText = Getdatafromsheet1;
                                    odaExcelSheet.SelectCommand = cmdExcelSheet;
                                    odaExcelSheet.Fill(dtfillsheet1);
                                    connExcelSheet.Close();
                                }
                            }
                        }
                    }

                    TotalCount = dtfillsheet1.Rows.Count;
                    string[] DateTimeArrayAMPM = new string[2] { "M/d/yyyy h:mm:ss tt", "M-d-yyyy h:mm:ss tt" };
                    string[] DateTimeArray = new string[2] { "d-M-yyyy HH:mm:ss", "d/M/yyyy HH:mm:ss" };

                    for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                    {
                        try
                        {
                            LineNo++;
                            ReportDate = null;
                            DisputeRaiseDate = null;
                            DisputeRaisedSettlementDate = null;
                            TransactionDateandTime = null;
                            ReaderReadDateandTime = null;
                            TransactionSettlementDate = null;
                            DocumentAttachedDate = null;
                            Deadlinedate = null;
                            SettledON = null;
                            CreatedOn = null;
                            ModifiedOn = null;
                            FileDate = null;

                            CaseNumber = string.Empty;
                            FunctionCode = string.Empty;
                            FunctionCodeandDescription = string.Empty;
                            TransactionSequenceNumber = string.Empty;
                            TagID = string.Empty;
                            TID = string.Empty;
                            TransactionAmount = 0;
                            SettlementAmount = 0;
                            SettlementCurrencyCode = string.Empty;
                            Note = string.Empty;
                            TransactionID = string.Empty;
                            TransactionType = string.Empty;
                            MerchantID = string.Empty;
                            Lane_Id = string.Empty;
                            Merchanttype = string.Empty;
                            SubMerchantType = string.Empty;
                            TransactionStatus = string.Empty;
                            TAGStatus = string.Empty;
                            AVC = string.Empty;
                            WIM = string.Empty;
                            OriginatorPoint = string.Empty;
                            AcquirerID = string.Empty;
                            TransactionOriginatorInstitutionPID = string.Empty;
                            AcquirerNameandCountry = string.Empty;
                            IIN = string.Empty;
                            TransactionDestinationInstitutionPID = string.Empty;
                            IssuerNameandCountry = string.Empty;
                            VehicleRegistrationNumber = string.Empty;
                            VehicleClass = string.Empty;
                            VehicleType = string.Empty;
                            FinancialNonFinancialIndicator = string.Empty;
                            DisputeReasoncode = string.Empty;
                            DisputeReasoncodedescription = string.Empty;
                            DisputedAmount = 0;
                            FullPartialIndicator = string.Empty;
                            MemberMessagetext = string.Empty;
                            DocumentIndicator = string.Empty;
                            Daystoact = string.Empty;
                            DirectionofDispute = string.Empty;
                            DATE = string.Empty;
                            SettledRemarks = string.Empty;

                            SettledON = null;
                            SettledRemarks = null;

                            ReportDate = Convert.ToDateTime(dtfillsheet1.Rows[i][0].ToString());
                            DisputeRaiseDate = Convert.ToDateTime(dtfillsheet1.Rows[i][1].ToString()); ;
                            DisputeRaisedSettlementDate = Convert.ToDateTime(dtfillsheet1.Rows[i][2].ToString());
                            CaseNumber = dtfillsheet1.Rows[i][3].ToString();
                            FunctionCode = dtfillsheet1.Rows[i][4].ToString();
                            FunctionCodeandDescription = dtfillsheet1.Rows[i][5].ToString();
                            TransactionSequenceNumber = dtfillsheet1.Rows[i][6].ToString();
                            TagID = dtfillsheet1.Rows[i][7].ToString();
                            TID = dtfillsheet1.Rows[i][8].ToString();
                            try
                            {
                                TransactionDateandTime = DateTime.ParseExact(dtfillsheet1.Rows[i][9].ToString(), DateTimeArray, System.Globalization.CultureInfo.InvariantCulture);
                            }
                            catch
                            {
                                TransactionDateandTime = Convert.ToDateTime(dtfillsheet1.Rows[i][9].ToString());
                            }
                            try
                            {
                                ReaderReadDateandTime = DateTime.ParseExact(dtfillsheet1.Rows[i][10].ToString(), DateTimeArray, System.Globalization.CultureInfo.InvariantCulture);
                            }
                            catch
                            {
                                ReaderReadDateandTime = Convert.ToDateTime(dtfillsheet1.Rows[i][10].ToString());
                            }



                            TransactionSettlementDate = Convert.ToDateTime(dtfillsheet1.Rows[i][11].ToString());
                            TransactionAmount = Convert.ToDouble(dtfillsheet1.Rows[i][12].ToString());
                            SettlementAmount = Convert.ToDouble(dtfillsheet1.Rows[i][13].ToString());
                            SettlementCurrencyCode = dtfillsheet1.Rows[i][14].ToString();
                            Note = dtfillsheet1.Rows[i][15].ToString();
                            TransactionID = dtfillsheet1.Rows[i][16].ToString();
                            TransactionType = dtfillsheet1.Rows[i][17].ToString();
                            MerchantID = dtfillsheet1.Rows[i][18].ToString();
                            Lane_Id = dtfillsheet1.Rows[i][19].ToString();
                            Merchanttype = dtfillsheet1.Rows[i][20].ToString();
                            SubMerchantType = dtfillsheet1.Rows[i][21].ToString();
                            TransactionStatus = dtfillsheet1.Rows[i][22].ToString();
                            TAGStatus = dtfillsheet1.Rows[i][23].ToString();
                            AVC = dtfillsheet1.Rows[i][24].ToString();
                            WIM = dtfillsheet1.Rows[i][25].ToString();
                            OriginatorPoint = dtfillsheet1.Rows[i][26].ToString();
                            AcquirerID = dtfillsheet1.Rows[i][27].ToString();
                            TransactionOriginatorInstitutionPID = dtfillsheet1.Rows[i][28].ToString();
                            AcquirerNameandCountry = dtfillsheet1.Rows[i][29].ToString();
                            IIN = dtfillsheet1.Rows[i][30].ToString();
                            TransactionDestinationInstitutionPID = dtfillsheet1.Rows[i][31].ToString();
                            IssuerNameandCountry = dtfillsheet1.Rows[i][32].ToString();
                            VehicleRegistrationNumber = dtfillsheet1.Rows[i][33].ToString();
                            VehicleClass = dtfillsheet1.Rows[i][34].ToString();
                            VehicleType = dtfillsheet1.Rows[i][35].ToString();
                            FinancialNonFinancialIndicator = dtfillsheet1.Rows[i][36].ToString();
                            DisputeReasoncode = dtfillsheet1.Rows[i][37].ToString();
                            DisputeReasoncodedescription = dtfillsheet1.Rows[i][38].ToString();

                            DisputedAmount = Convert.ToDouble(dtfillsheet1.Rows[i][39].ToString());
                            FullPartialIndicator = dtfillsheet1.Rows[i][40].ToString();
                            MemberMessagetext = dtfillsheet1.Rows[i][41].ToString();
                            DocumentIndicator = dtfillsheet1.Rows[i][42].ToString();


                            try
                            {
                                if (dtfillsheet1.Rows[i][43].ToString().Trim().Length > 0)
                                    DocumentAttachedDate = Convert.ToDateTime(dtfillsheet1.Rows[i][43].ToString());
                            }
                            catch
                            {
                                DocumentAttachedDate = dtfillsheet1.Rows[i][43].ToString() == "" ? Deadlinedate : DateTime.ParseExact(dtfillsheet1.Rows[i][43].ToString(), new[] { "dd-MMM-yy", "dd-MM-yyyy", "d-MM-yyyy", "dd/MM/yyyy", "d/MM/yyyy", "dd/MM/yy", "dd-MMM-yy", "dd/MMM/yy", "MM/dd/yyyy hh:mm:ss tt", "M/dd/yyyy hh:mm:ss tt" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                            }

                            try
                            {
                                if (dtfillsheet1.Rows[i][44].ToString().Trim().Length > 0)
                                    Deadlinedate = Convert.ToDateTime(dtfillsheet1.Rows[i][44].ToString());
                            }
                            catch
                            {
                                Deadlinedate = dtfillsheet1.Rows[i][44].ToString() == "" ? Deadlinedate : DateTime.ParseExact(dtfillsheet1.Rows[i][44].ToString(), new[] { "dd-MMM-yy", "dd-MM-yyyy", "d-MM-yyyy", "dd/MM/yyyy", "d/MM/yyyy", "dd/MM/yy", "dd-MMM-yy", "dd/MMM/yy", "MM/dd/yyyy hh:mm:ss tt", "M/dd/yyyy hh:mm:ss tt" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None);
                            }


                            Daystoact = dtfillsheet1.Rows[i][45].ToString();
                            DirectionofDispute = dtfillsheet1.Rows[i][46].ToString();

                            _DataTable.Rows.Add(
                                ClientID
                            , ChannelID
                            , ReportDate
                            , DisputeRaiseDate
                            , DisputeRaisedSettlementDate
                            , CaseNumber
                            , FunctionCode
                            , FunctionCodeandDescription
                            , TransactionSequenceNumber
                            , TagID
                            , TID
                            , TransactionDateandTime
                            , ReaderReadDateandTime
                            , TransactionSettlementDate
                            , TransactionAmount
                            , SettlementAmount
                            , SettlementCurrencyCode
                            , Note
                            , TransactionID
                            , TransactionType
                            , MerchantID
                            , Lane_Id
                            , Merchanttype
                            , SubMerchantType
                            , TransactionStatus
                            , TAGStatus
                            , AVC
                            , WIM
                            , OriginatorPoint
                            , AcquirerID
                            , TransactionOriginatorInstitutionPID
                            , AcquirerNameandCountry
                            , IIN
                            , TransactionDestinationInstitutionPID
                            , IssuerNameandCountry
                            , VehicleRegistrationNumber
                            , VehicleClass
                            , VehicleType
                            , FinancialNonFinancialIndicator
                            , DisputeReasoncode
                            , DisputeReasoncodedescription
                            , DisputedAmount
                            , FullPartialIndicator
                            , MemberMessagetext
                            , DocumentIndicator
                            , DocumentAttachedDate
                            , Deadlinedate
                            , Daystoact
                            , DirectionofDispute



                            , DateTime.Now
                            , UserName
                            , DateTime.Now
                            , UserName
                            , ""
                            , null
                            , SettledON
                            , SettledRemarks
                                             );

                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            DBLog.InsertLogs(ex.Message.ToString(), ClientID, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                    }

                }
                catch (Exception ex)
                {
                    DBLog.InsertLogs(ex.Message.ToString(), ClientID, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientID, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;
        }

        public DataTable SplitterSettlement_FastTag(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("RTGSBankName", typeof(string));
            _DataTable.Columns.Add("MemberName", typeof(string));
            _DataTable.Columns.Add("MemberBankPID", typeof(string));
            _DataTable.Columns.Add("MemberBankType", typeof(string));
            _DataTable.Columns.Add("DrCr", typeof(string));

            _DataTable.Columns.Add("FinalSumCr", typeof(string));
            _DataTable.Columns.Add("‎FinalSumDr", typeof(string));
            _DataTable.Columns.Add("NetAmount", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));

            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0, ErrorCount = 0;


            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());

            InsertCount = 0;
            TotalCount = 0;
            DataTable dtexcelsheetname = null;
            DataTable dtSheet = new DataTable();

            string connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;";

            string extension = Path.GetExtension(path);
            switch (extension.ToLower())
            {

                case ".xls": //Excel 97-03
                             // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                    break;
                case ".xlsx": //Excel 07 or higher
                              //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=YES;TypeGuessRows=0;ImportMixedTypes=Text'";
                    break;

            }


            try
            {
                using (OleDbConnection connExcel = new OleDbConnection(connString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet.
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            string Getdatafromsheet1 = "SELECT * FROM [" + dtexcelsheetname.Rows[0]["TABLE_NAME"].ToString().Replace("'", "") + "]";

            using (OleDbConnection connExcelSheet = new OleDbConnection(connString))
            {
                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                {
                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                    {
                        //Read Data from First Sheet.
                        cmdExcelSheet.Connection = connExcelSheet;
                        connExcelSheet.Open();
                        cmdExcelSheet.CommandText = Getdatafromsheet1;
                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                        odaExcelSheet.Fill(dtSheet);
                        connExcelSheet.Close();
                    }
                }
            }

            try
            {
                TotalCount = dtSheet.Rows.Count;
                if (dtSheet.Rows.Count > 0)
                {
                    DateTime? Date;
                    Date = null;
                    string[] Filesplit = FileName.Split('_');
                    string length = Filesplit.Length.ToString();

                    if (length == "4")
                    {
                        string DateArray = string.Empty;
                        DateArray = Filesplit[3].ToString();
                        string strdd = DateArray.Substring(0, 10).ToString();
                        Date = Convert.ToDateTime(strdd.ToString());
                    }
                    else
                    {

                        string DateArray = string.Empty;
                        string[] datee = Filesplit[4].Split('.');
                        DateArray = datee[0].ToString();
                        string strdd = DateArray.Substring(0, 10).ToString();
                        Date = Convert.ToDateTime(strdd.ToString());
                    }

                    int Incr = 1;
                    string Description = string.Empty;
                    string Remarks = string.Empty;
                    string strDate = string.Empty, RTGSBankName = string.Empty, MemberName = string.Empty, MemberBankPID = string.Empty, MemberBankType = string.Empty,
                                  DrCr = string.Empty, FinalSumCr = string.Empty, FinalSumDr = string.Empty, NetAmount = string.Empty;
                    string RTGS = string.Empty;

                    try
                    {
                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            Incr = 1;
                            Description = string.Empty;

                            Remarks = string.Empty;

                            strDate = string.Empty;
                            MemberName = string.Empty; MemberBankPID = string.Empty; MemberBankType = string.Empty;
                            DrCr = string.Empty; FinalSumCr = string.Empty; FinalSumDr = string.Empty; NetAmount = string.Empty;
                            try
                            {
                                if (ds.Tables[0].Rows[0]["RTGSBankName"].ToString() != "0")
                                {

                                    RTGS = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["RTGSBankName"].ToString()) - Incr].ToString();
                                    if (RTGS == "")
                                    {
                                        RTGSBankName = RTGSBankName.ToString();
                                    }
                                    else
                                    {
                                        RTGSBankName = RTGS.ToString();
                                    }
                                }

                                if (ds.Tables[0].Rows[0]["MemberName"].ToString() != "0")
                                {
                                    MemberName = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["MemberName"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["MemberBankPID"].ToString() != "0")
                                {
                                    MemberBankPID = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["MemberBankPID"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["MemberBankType"].ToString() != "")
                                {
                                    MemberBankType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["MemberBankType"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["DrCr"].ToString() != "")
                                {
                                    DrCr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["DrCr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["FinalSumCr"].ToString() != "")
                                {
                                    FinalSumCr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["FinalSumCr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["FinalSumDr"].ToString() != "")
                                {
                                    FinalSumDr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["FinalSumDr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["NetAmount"].ToString() != "")
                                {
                                    NetAmount = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["NetAmount"].ToString()) - Incr].ToString();
                                }
                            }
                            catch (Exception ex)
                            {
                                ErrorCount++;
                            }

                            LineNo++;
                            if (RTGSBankName != "" && !NetAmount.Contains("Net Amount"))
                            {
                                _DataTable.Rows.Add(ClientID, Date, RTGSBankName, MemberName, MemberBankPID, MemberBankType
                                , DrCr, Convert.ToDecimal(FinalSumCr), Convert.ToDecimal(FinalSumDr), Convert.ToDecimal(NetAmount), Remarks
                                   , FileName, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                }


            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;

        }

        public DataTable SplitterServiceFEE_FastTag(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();


            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("ChannelID", typeof(string));
            _DataTable.Columns.Add("ModeID", typeof(string));

            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("ProductName", typeof(string));
            _DataTable.Columns.Add("BankName", typeof(string));
            _DataTable.Columns.Add("SettlementBin", typeof(string));
            _DataTable.Columns.Add("Acq_ID_ISS_IIN", typeof(string));
            _DataTable.Columns.Add("Inward_Outward", typeof(string));

            _DataTable.Columns.Add("TxnsCycle", typeof(string));
            _DataTable.Columns.Add("‎TxnsType", typeof(string));

            _DataTable.Columns.Add("Channel", typeof(string));
            _DataTable.Columns.Add("ServiceFeeCategory", typeof(string));

            _DataTable.Columns.Add("TXNCNT", typeof(string));
            _DataTable.Columns.Add("SETCCY", typeof(string));
            _DataTable.Columns.Add("TxnAmtCr", typeof(decimal));
            _DataTable.Columns.Add("TxnAmtDr", typeof(decimal));
            _DataTable.Columns.Add("ServiceFeeAmtCr", typeof(decimal));
            _DataTable.Columns.Add("ServiceFeeAmtDr", typeof(decimal));

            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));

            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));



            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0, ErrorCount = 0;

            DataTable dtexcelsheetname = null;
            DataTable dtSheet = new DataTable();

            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());
            int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());

            string connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;";

            string extension = Path.GetExtension(path);
            switch (extension.ToLower())
            {

                case ".xls": //Excel 97-03
                             // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                    break;
                case ".xlsx": //Excel 07 or higher
                              //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=YES;TypeGuessRows=0;ImportMixedTypes=Text'";
                    break;

            }


            try
            {
                using (OleDbConnection connExcel = new OleDbConnection(connString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet.
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            string Getdatafromsheet1 = "SELECT * FROM [" + dtexcelsheetname.Rows[0]["TABLE_NAME"].ToString().Replace("'", "") + "]";

            using (OleDbConnection connExcelSheet = new OleDbConnection(connString))
            {
                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                {
                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                    {
                        //Read Data from First Sheet.
                        cmdExcelSheet.Connection = connExcelSheet;
                        connExcelSheet.Open();
                        cmdExcelSheet.CommandText = Getdatafromsheet1;
                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                        odaExcelSheet.Fill(dtSheet);
                        connExcelSheet.Close();
                    }
                }
            }

            try
            {
                int Incr = 1;
                string Description = string.Empty;

                string Remarks = string.Empty;

                string strDate = string.Empty, ProductName = string.Empty, BankName = string.Empty, SettlementBin = string.Empty, Acq_ID_ISS_IIN = string.Empty
                        , Inward_Outward = string.Empty, TxnsCycle = string.Empty, TxnsType = string.Empty, Channel = string.Empty, TXNCNT = string.Empty, SETCCY = string.Empty
                        , TxnAmtCr = string.Empty, TxnAmtDr = string.Empty
                        , ServiceFeeAmtCr = string.Empty, ServiceFeeAmtDr = string.Empty, CreatedOn = string.Empty
                        , ModifiedOn = string.Empty, CreatedBy = string.Empty, ModifiedBy = string.Empty, ServiceFeeCategory = string.Empty, Cycle = string.Empty;


                string RTGS = string.Empty;
                TotalCount = dtSheet.Rows.Count;

                if (dtSheet.Rows.Count > 0)
                {
                    DateTime? Date;
                    Date = null;
                    string[] Filesplit = FileName.Split('_');
                    string DateArray = string.Empty;
                    DateArray = Filesplit[2].ToString();
                    string strdd = DateArray.Substring(0, 10).ToString();
                    Date = Convert.ToDateTime(strdd.ToString());


                    try
                    {
                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            Incr = 1;
                            Description = string.Empty;

                            Remarks = string.Empty;
                            Cycle = "";

                            strDate = string.Empty; ProductName = string.Empty; BankName = string.Empty; SettlementBin = string.Empty; Acq_ID_ISS_IIN = string.Empty
                              ; Inward_Outward = string.Empty; TxnsCycle = string.Empty; TxnsType = string.Empty; Channel = string.Empty; TXNCNT = string.Empty; SETCCY = string.Empty
                              ; TxnAmtCr = string.Empty; TxnAmtDr = string.Empty
                              ; ServiceFeeAmtCr = string.Empty; ServiceFeeAmtDr = string.Empty; CreatedOn = string.Empty
                              ; ModifiedOn = string.Empty; CreatedBy = string.Empty; ModifiedBy = string.Empty; ServiceFeeCategory = string.Empty;

                            CreatedOn = string.Empty; ModifiedOn = string.Empty; CreatedBy = string.Empty; ModifiedBy = string.Empty;


                            try
                            {

                                if (ds.Tables[0].Rows[0]["ProductName"].ToString() != "0")
                                {

                                    RTGS = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ProductName"].ToString()) - Incr].ToString();
                                    if (RTGS == "")
                                    {
                                        ProductName = ProductName.ToString();
                                    }
                                    else
                                    {
                                        ProductName = RTGS.ToString();
                                    }
                                }

                                if (ds.Tables[0].Rows[0]["BankName"].ToString() != "0")
                                {
                                    BankName = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["BankName"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["SettlementBin"].ToString() != "0")
                                {
                                    SettlementBin = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SettlementBin"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Acq_ID_ISS_IIN"].ToString() != "")
                                {
                                    Acq_ID_ISS_IIN = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Acq_ID_ISS_IIN"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["Inward_Outward"].ToString() != "")
                                {
                                    Inward_Outward = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Inward_Outward"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["TxnsCycle"].ToString() != "")
                                {
                                    TxnsCycle = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsCycle"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsType"].ToString() != "")
                                {
                                    TxnsType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsType"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Channel"].ToString() != "")
                                {
                                    Channel = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Channel"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ServiceFeeCategory"].ToString() != "")
                                {
                                    ServiceFeeCategory = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ServiceFeeCategory"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TXNCNT"].ToString() != "")
                                {
                                    TXNCNT = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TXNCNT"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["SETCCY"].ToString() != "")
                                {
                                    SETCCY = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SETCCY"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnAmtCr"].ToString() != "")
                                {
                                    TxnAmtCr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnAmtCr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnAmtDr"].ToString() != "")
                                {
                                    TxnAmtDr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnAmtDr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ServiceFeeAmtCr"].ToString() != "")
                                {
                                    ServiceFeeAmtCr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ServiceFeeAmtCr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ServiceFeeAmtDr"].ToString() != "")
                                {
                                    ServiceFeeAmtDr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ServiceFeeAmtDr"].ToString()) - Incr].ToString();
                                }

                                TxnAmtCr = TxnAmtCr.Trim().Length == 0 ? "0" : TxnAmtCr;
                                TxnAmtDr = TxnAmtDr.Trim().Length == 0 ? "0" : TxnAmtDr;
                                ServiceFeeAmtCr = ServiceFeeAmtCr.Trim().Length == 0 ? "0" : ServiceFeeAmtCr;
                                ServiceFeeAmtDr = ServiceFeeAmtDr.Trim().Length == 0 ? "0" : ServiceFeeAmtDr;

                                if (!TxnAmtDr.Contains("Amt"))
                                {
                                    _DataTable.Rows.Add(ClientID, ChannelID, ModeID, Date, Cycle, ProductName, BankName, SettlementBin, Acq_ID_ISS_IIN, Inward_Outward, TxnsCycle, TxnsType, Channel
                                        , ServiceFeeCategory
                                    , TXNCNT, SETCCY, Convert.ToDecimal(TxnAmtCr), Convert.ToDecimal(TxnAmtDr), Convert.ToDecimal(ServiceFeeAmtCr), Convert.ToDecimal(ServiceFeeAmtDr)
                                    , FileName, path, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);

                                }

                            }
                            catch (Exception ex)
                            {
                                ErrorCount++;
                            }

                            LineNo++;
                        }
                    }
                    catch (Exception ex)
                    {
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                }
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;

        }


        public DataTable SplitterNPCIFEE_FastTag(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();


            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(string));
            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("ProductName", typeof(string));
            _DataTable.Columns.Add("BankName", typeof(string));
            _DataTable.Columns.Add("SettlementBin", typeof(string));
            _DataTable.Columns.Add("Acq_ID_ISS_IIN", typeof(string));
            _DataTable.Columns.Add("Inward_Outward", typeof(string));
            _DataTable.Columns.Add("Txn_Status", typeof(string));
            _DataTable.Columns.Add("TxnsCycle", typeof(string));
            _DataTable.Columns.Add("‎TxnsType", typeof(string));

            _DataTable.Columns.Add("Channel", typeof(string));
            _DataTable.Columns.Add("TXNCNT", typeof(string));
            _DataTable.Columns.Add("TXNCCY", typeof(string));

            _DataTable.Columns.Add("TxnAmtDr", typeof(decimal));
            _DataTable.Columns.Add("TxnAmtCr", typeof(decimal));
            _DataTable.Columns.Add("SETCCY", typeof(string));

            _DataTable.Columns.Add("SETAMTDR", typeof(decimal));
            _DataTable.Columns.Add("SETAMTCR", typeof(decimal));
            _DataTable.Columns.Add("ServiceFeeAmtDr", typeof(decimal));
            _DataTable.Columns.Add("ServiceFeeAmtCr", typeof(decimal));

            _DataTable.Columns.Add("Mem_Inc_Fee_Amt_Dr", typeof(decimal));
            _DataTable.Columns.Add("Mem_Inc_Fee_Amt_Cr", typeof(decimal));
            _DataTable.Columns.Add("Oth_Fee_Amt_Dr", typeof(decimal));
            _DataTable.Columns.Add("Oth_Fee_Amt_Cr", typeof(decimal));
            _DataTable.Columns.Add("Oth_Fee_GST_Dr", typeof(decimal));
            _DataTable.Columns.Add("Oth_Fee_GST_Cr", typeof(decimal));
            _DataTable.Columns.Add("Final_Sum_Cr", typeof(decimal));
            _DataTable.Columns.Add("Final_Sum_Dr", typeof(decimal));
            _DataTable.Columns.Add("Final_Net_Amt", typeof(decimal));


            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));


            int LineNo = 0, ErrorCount = 0;


            InsertCount = 0;
            TotalCount = 0;

            DataTable dtexcelsheetname = null;
            DataTable dtSheet = new DataTable();

            DataSet ds = new DataSet();
            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new System.Xml.XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());
            int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());

            string connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;";

            string extension = Path.GetExtension(path);
            switch (extension.ToLower())
            {

                case ".xls": //Excel 97-03
                             // connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text";";
                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1;TypeGuessRows=0;ImportMixedTypes=Text\";";
                    break;
                case ".xlsx": //Excel 07 or higher
                              //connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + GLFilePath + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                    connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 12.0;IMEX=1;HDR=YES;TypeGuessRows=0;ImportMixedTypes=Text'";
                    break;

            }


            try
            {
                using (OleDbConnection connExcel = new OleDbConnection(connString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet.
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            string Getdatafromsheet1 = "SELECT * FROM [" + dtexcelsheetname.Rows[0]["TABLE_NAME"].ToString().Replace("'", "") + "]";

            using (OleDbConnection connExcelSheet = new OleDbConnection(connString))
            {
                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                {
                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                    {
                        //Read Data from First Sheet.
                        cmdExcelSheet.Connection = connExcelSheet;
                        connExcelSheet.Open();
                        cmdExcelSheet.CommandText = Getdatafromsheet1;
                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                        odaExcelSheet.Fill(dtSheet);
                        connExcelSheet.Close();
                    }
                }
            }


            try
            {

                string strDate = string.Empty, ProductName = string.Empty, BankName = string.Empty, SettlementBin = string.Empty, Acq_ID_ISS_IIN = string.Empty, Inward_Outward = string.Empty, Txn_Status = string.Empty, TxnsCycle = string.Empty, TxnsType = string.Empty, Channel = string.Empty, TXNCNT = string.Empty, TXNCCY = string.Empty, TxnAmtDr = string.Empty, TxnAmtCr = string.Empty, SETCCY = string.Empty, SETAMTDR = string.Empty, SETAMTCR = string.Empty, ServiceFeeAmtDr = string.Empty,
                          ServiceFeeAmtCr = string.Empty, Mem_Inc_Fee_Amt_Dr = string.Empty, Mem_Inc_Fee_Amt_Cr = string.Empty, Oth_Fee_Amt_Dr = string.Empty
                          , Oth_Fee_Amt_Cr = string.Empty, Oth_Fee_GST_Dr = string.Empty, Oth_Fee_GST_Cr = string.Empty, Final_Sum_Cr = string.Empty
                          , Final_Sum_Dr = string.Empty, Final_Net_Amt = string.Empty
                          //, ClientID = string.Empty, FileName = string.Empty
                          , CreatedOn = string.Empty,
                          ModifiedOn = string.Empty, CreatedBy = string.Empty, ModifiedBy = string.Empty;

                int Incr = 1;
                string Description = string.Empty;
                string Remarks = string.Empty;
                string RTGS = string.Empty;

                TotalCount = dtSheet.Rows.Count;

                if (dtSheet.Rows.Count > 0)
                {
                    DateTime? Date;
                    Date = null;
                    string[] Filesplit = FileName.Split('_');
                    string DateArray = string.Empty;
                    DateArray = Filesplit[2].ToString();
                    string strdd = DateArray.Substring(0, 10).ToString();
                    Date = Convert.ToDateTime(strdd.ToString());


                    try
                    {
                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                        {
                            Incr = 1;
                            Description = string.Empty;
                            Remarks = string.Empty;


                            strDate = string.Empty; ProductName = string.Empty; BankName = string.Empty; SettlementBin = string.Empty; Acq_ID_ISS_IIN = string.Empty;
                            Inward_Outward = string.Empty; Txn_Status = string.Empty; TxnsCycle = string.Empty; TxnsType = string.Empty; Channel = string.Empty;
                            TXNCNT = string.Empty; TXNCCY = string.Empty; TxnAmtDr = string.Empty; TxnAmtCr = string.Empty; SETCCY = string.Empty; SETAMTDR = string.Empty;
                            SETAMTCR = string.Empty; ServiceFeeAmtDr = string.Empty; ServiceFeeAmtCr = string.Empty; Mem_Inc_Fee_Amt_Dr = string.Empty;
                            Mem_Inc_Fee_Amt_Cr = string.Empty; Oth_Fee_Amt_Dr = string.Empty; Oth_Fee_Amt_Cr = string.Empty; Oth_Fee_GST_Dr = string.Empty;
                            Oth_Fee_GST_Cr = string.Empty; Final_Sum_Cr = string.Empty; Final_Sum_Dr = string.Empty; Final_Net_Amt = string.Empty;

                            CreatedOn = string.Empty; ModifiedOn = string.Empty; CreatedBy = string.Empty; ModifiedBy = string.Empty;


                            try
                            {
                                if (ds.Tables[0].Rows[0]["ProductName"].ToString() != "0")
                                {

                                    RTGS = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ProductName"].ToString()) - Incr].ToString();
                                    if (RTGS == "")
                                    {
                                        ProductName = ProductName.ToString();
                                    }
                                    else
                                    {
                                        ProductName = RTGS.ToString();
                                    }
                                }

                                if (ds.Tables[0].Rows[0]["BankName"].ToString() != "0")
                                {
                                    BankName = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["BankName"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["SettlementBin"].ToString() != "0")
                                {
                                    SettlementBin = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SettlementBin"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Acq_ID_ISS_IIN"].ToString() != "")
                                {
                                    Acq_ID_ISS_IIN = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Acq_ID_ISS_IIN"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["Inward_Outward"].ToString() != "")
                                {
                                    Inward_Outward = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Inward_Outward"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Txn_Status"].ToString() != "")
                                {
                                    Txn_Status = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Txn_Status"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsCycle"].ToString() != "")
                                {
                                    TxnsCycle = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsCycle"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnsType"].ToString() != "")
                                {
                                    TxnsType = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnsType"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Channel"].ToString() != "")
                                {
                                    Channel = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Channel"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TXNCNT"].ToString() != "")
                                {
                                    TXNCNT = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TXNCNT"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TXNCCY"].ToString() != "")
                                {
                                    TXNCCY = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TXNCCY"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["TxnAmtDr"].ToString() != "")
                                {
                                    TxnAmtDr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnAmtDr"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["TxnAmtCr"].ToString() != "")
                                {
                                    TxnAmtCr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["TxnAmtCr"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["SETCCY"].ToString() != "")
                                {
                                    SETCCY = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SETCCY"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["SETAMTDR"].ToString() != "")
                                {
                                    SETAMTDR = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SETAMTDR"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["SETAMTCR"].ToString() != "")
                                {
                                    SETAMTCR = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["SETAMTCR"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ServiceFeeAmtDr"].ToString() != "")
                                {
                                    ServiceFeeAmtDr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ServiceFeeAmtDr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["ServiceFeeAmtCr"].ToString() != "")
                                {
                                    ServiceFeeAmtCr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["ServiceFeeAmtCr"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["Mem_Inc_Fee_Amt_Dr"].ToString() != "")
                                {
                                    Mem_Inc_Fee_Amt_Dr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Mem_Inc_Fee_Amt_Dr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Mem_Inc_Fee_Amt_Cr"].ToString() != "")
                                {
                                    Mem_Inc_Fee_Amt_Cr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Mem_Inc_Fee_Amt_Cr"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["Oth_Fee_Amt_Dr"].ToString() != "")
                                {
                                    Oth_Fee_Amt_Dr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Oth_Fee_Amt_Dr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Oth_Fee_Amt_Cr"].ToString() != "")
                                {
                                    Oth_Fee_Amt_Cr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Oth_Fee_Amt_Cr"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["Oth_Fee_GST_Dr"].ToString() != "")
                                {
                                    Oth_Fee_GST_Dr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Oth_Fee_GST_Dr"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["Oth_Fee_GST_Cr"].ToString() != "")
                                {
                                    Oth_Fee_GST_Cr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Oth_Fee_GST_Cr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Final_Sum_Cr"].ToString() != "")
                                {
                                    Final_Sum_Cr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Final_Sum_Cr"].ToString()) - Incr].ToString();
                                }
                                if (ds.Tables[0].Rows[0]["Final_Sum_Dr"].ToString() != "")
                                {
                                    Final_Sum_Dr = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Final_Sum_Dr"].ToString()) - Incr].ToString();
                                }

                                if (ds.Tables[0].Rows[0]["Final_Net_Amt"].ToString() != "")
                                {
                                    Final_Net_Amt = dtSheet.Rows[k][int.Parse(ds.Tables[0].Rows[0]["Final_Net_Amt"].ToString()) - Incr].ToString();
                                }

                                TxnAmtCr = TxnAmtCr.Trim().Length == 0 ? "0" : TxnAmtCr;
                                TxnAmtDr = TxnAmtDr.Trim().Length == 0 ? "0" : TxnAmtDr;
                                SETAMTDR = SETAMTDR.Trim().Length == 0 ? "0" : SETAMTDR;
                                SETAMTCR = SETAMTCR.Trim().Length == 0 ? "0" : SETAMTCR;
                                ServiceFeeAmtDr = ServiceFeeAmtDr.Trim().Length == 0 ? "0" : ServiceFeeAmtDr;
                                ServiceFeeAmtCr = ServiceFeeAmtCr.Trim().Length == 0 ? "0" : ServiceFeeAmtCr;
                                Mem_Inc_Fee_Amt_Dr = Mem_Inc_Fee_Amt_Dr.Trim().Length == 0 ? "0" : Mem_Inc_Fee_Amt_Dr;
                                Mem_Inc_Fee_Amt_Cr = Mem_Inc_Fee_Amt_Cr.Trim().Length == 0 ? "0" : Mem_Inc_Fee_Amt_Cr;
                                Oth_Fee_Amt_Dr = Oth_Fee_Amt_Dr.Trim().Length == 0 ? "0" : Oth_Fee_Amt_Dr;
                                Oth_Fee_Amt_Cr = Oth_Fee_Amt_Cr.Trim().Length == 0 ? "0" : Oth_Fee_Amt_Cr;
                                Oth_Fee_GST_Dr = Oth_Fee_GST_Dr.Trim().Length == 0 ? "0" : Oth_Fee_GST_Dr;
                                Oth_Fee_GST_Cr = Oth_Fee_GST_Cr.Trim().Length == 0 ? "0" : Oth_Fee_GST_Cr;
                                Final_Sum_Cr = Final_Sum_Cr.Trim().Length == 0 ? "0" : Final_Sum_Cr;
                                Final_Sum_Dr = Final_Sum_Dr.Trim().Length == 0 ? "0" : Final_Sum_Dr;
                                Final_Net_Amt = Final_Net_Amt.Trim().Length == 0 ? "0" : Final_Net_Amt;


                                if (!TxnAmtDr.Contains("Amt"))
                                {
                                    _DataTable.Rows.Add(ClientID, Date, ProductName, BankName, SettlementBin, Acq_ID_ISS_IIN, Inward_Outward, Txn_Status, TxnsCycle, TxnsType, Channel
                                    , TXNCNT, TXNCCY, Convert.ToDecimal(TxnAmtDr), Convert.ToDecimal(TxnAmtCr), SETCCY, Convert.ToDecimal(SETAMTDR), Convert.ToDecimal(SETAMTCR)
                                     , Convert.ToDecimal(ServiceFeeAmtDr), Convert.ToDecimal(ServiceFeeAmtCr), Convert.ToDecimal(Mem_Inc_Fee_Amt_Dr), Convert.ToDecimal(Mem_Inc_Fee_Amt_Cr), Convert.ToDecimal(Oth_Fee_Amt_Dr)
                                     , Convert.ToDecimal(Oth_Fee_Amt_Cr), Convert.ToDecimal(Oth_Fee_GST_Dr), Convert.ToDecimal(Oth_Fee_GST_Cr), Convert.ToDecimal(Final_Sum_Cr)
                                     , Convert.ToDecimal(Final_Sum_Dr), Convert.ToDecimal(Final_Net_Amt)
                                    , FileName, DateTime.Now.ToString(), DateTime.Now.ToString(), UserName, UserName);


                                }

                            }
                            catch (Exception ex)
                            {
                                ErrorCount++;
                                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            }
                            LineNo++;
                        }
                    }
                    catch (Exception ex)
                    {
                        DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                    }

                }


            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;

        }

    }
} 