﻿ 
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Xml;
using TextFieldParserCore;
using Utility;
using System.Text.Json;
using System.Globalization;
using ImportData;
using System.Reflection;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Drawing;

namespace NetworkNPCI
{
    public class NPCIPOSECOM : ProcessPosSetFileSpliter
    { 
        private readonly string _connectionString;
        BulkImports bulkImports;
        public NPCIPOSECOM(string connectionString, string MekKey1, string MekKey2) : base(connectionString, MekKey1, MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkImports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        public DataTable SplitterNPCIIssuerPOS(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0; 
            

            DataSet ds = new DataSet();

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("MessageType", typeof(string));
            _DataTable.Columns.Add("ProductID", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("FromAccountType", typeof(string));
            _DataTable.Columns.Add("ToAccountType", typeof(string));
            _DataTable.Columns.Add("ActionCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("ApprovalNumber", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("MerchantCategoryCode", typeof(string));
            _DataTable.Columns.Add("CardAcceptorID", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("TerminalLocation", typeof(string));
            _DataTable.Columns.Add("AcquirerID", typeof(string));
            _DataTable.Columns.Add("TxnsCCYCode", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(Decimal));
            _DataTable.Columns.Add("CardHolderBillingCCY", typeof(string));
            _DataTable.Columns.Add("CardHolderBillingAmount", typeof(string));
            _DataTable.Columns.Add("PANEntryMode", typeof(string));
            _DataTable.Columns.Add("PINEntryCapability", typeof(string));
            _DataTable.Columns.Add("POSConditionCode", typeof(string));
            _DataTable.Columns.Add("AcquirerCountryCode", typeof(string));
            _DataTable.Columns.Add("AdditionalAmount", typeof(Decimal));
            _DataTable.Columns.Add("RuPayProduct", typeof(string));
            _DataTable.Columns.Add("CVD2MatchResult", typeof(string));
            _DataTable.Columns.Add("CVDICVDMatchResult", typeof(string));
            _DataTable.Columns.Add("RecurringPayIndicator", typeof(string));
            _DataTable.Columns.Add("ECIIndicator", typeof(string));
            _DataTable.Columns.Add("ICS1ResultCode", typeof(string));
            _DataTable.Columns.Add("FraudScore", typeof(string));
            _DataTable.Columns.Add("EMIAmount", typeof(Decimal));
            _DataTable.Columns.Add("ARQCAuthorization", typeof(string));
            _DataTable.Columns.Add("TxnsID", typeof(string));
            _DataTable.Columns.Add("LoyaltyPoint", typeof(string));
            _DataTable.Columns.Add("ICS2ResultCode", typeof(string));
            _DataTable.Columns.Add("CustMobileNumber", typeof(string));
            _DataTable.Columns.Add("ImageCode", typeof(string));
            _DataTable.Columns.Add("PersonalPhase", typeof(string));
            _DataTable.Columns.Add("UIDNumber", typeof(string));
            _DataTable.Columns.Add("CardDataInputCapability", typeof(string));
            _DataTable.Columns.Add("CardHolderAuthCapability", typeof(string));
            _DataTable.Columns.Add("CardCaptureCapability", typeof(string));
            _DataTable.Columns.Add("TerminalOpEnvironment", typeof(string));
            _DataTable.Columns.Add("CardholderPresentData", typeof(string));
            _DataTable.Columns.Add("CardPresentData", typeof(string));
            _DataTable.Columns.Add("CardDataInputMode", typeof(string));
            _DataTable.Columns.Add("CardHolderAuthMode", typeof(string));
            _DataTable.Columns.Add("CardholderAuthEntity", typeof(string));
            _DataTable.Columns.Add("CardDataOPCapability", typeof(string));
            _DataTable.Columns.Add("TerminalDataCapability", typeof(string));
            _DataTable.Columns.Add("PinCaptureCapability", typeof(string));
            _DataTable.Columns.Add("ZipCode", typeof(string));
            _DataTable.Columns.Add("AdviceReasonCode", typeof(string));
            _DataTable.Columns.Add("ITPAN", typeof(string));
            _DataTable.Columns.Add("INTRAUTHNW", typeof(string));
            _DataTable.Columns.Add("OTPIndicator", typeof(string));
            _DataTable.Columns.Add("ICSTXNID", typeof(string));
            _DataTable.Columns.Add("NWDATA", typeof(string));
            _DataTable.Columns.Add("ServiceCode", typeof(string));
            _DataTable.Columns.Add("CCYActualTxnsAmount", typeof(string));
            _DataTable.Columns.Add("ActualTxnsAmount", typeof(Decimal));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("NoOfDuplicate", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDDON", typeof(DateTime));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));



            string LogType = dt.Rows[0]["FileName"].ToString();
            string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = "1";
            ds.ReadXml(new XmlTextReader(new System.IO.StringReader(xmlFile)));
            int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());


            string[] TotalCountArray = System.IO.File.ReadAllLines(path);
            TotalCount = TotalCountArray.Length;
            string Cycle = string.Empty;
            Cycle = FileName.Substring(2, 1).Trim();
            DateTime? Filedate;
            Filedate = null;

            int Incr = 1;
            string MessageType = string.Empty;
            string ProductID = string.Empty;
            string TxnsType = string.Empty;
            string FromAccountType = string.Empty;
            string ToAccountType = string.Empty;
            string ActionCode = string.Empty;
            string ResponseCode = string.Empty;
            string CardNumber = string.Empty;
            string ApprovalNumber = string.Empty;
            string ReferenceNumber = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsTime = string.Empty;
            string MerchantCategoryCode = string.Empty;
            string CardAcceptorID = string.Empty;
            string TerminalId = string.Empty;
            string TerminalLocation = string.Empty;
            string AcquirerID = string.Empty;
            string TxnsCCYCode = string.Empty;
            string TxnsAmount = "0";
            string CardHolderBillingCCY = string.Empty;
            string CardHolderBillingAmount = "0";
            string PANEntryMode = string.Empty;
            string PINEntryCapability = string.Empty;
            string POSConditionCode = string.Empty;
            string AcquirerCountryCode = string.Empty;
            string AdditionalAmount = "0";
            string RuPayProduct = string.Empty;
            string CVD2MatchResult = string.Empty;
            string CVDICVDMatchResult = string.Empty;
            string RecurringPayIndicator = string.Empty;
            string ECIIndicator = string.Empty;
            string ICS1ResultCode = string.Empty;
            string FraudScore = string.Empty;
            string EMIAmount = "0";
            string ARQCAuthorization = string.Empty;
            string TxnsID = string.Empty;
            string LoyaltyPoint = string.Empty;
            string ICS2ResultCode = string.Empty;
            string CustMobileNumber = string.Empty;
            string ImageCode = string.Empty;
            string PersonalPhase = string.Empty;
            string UIDNumber = string.Empty;
            string CardDataInputCapability = string.Empty;
            string CardHolderAuthCapability = string.Empty;
            string CardCaptureCapability = string.Empty;
            string TerminalOpEnvironment = string.Empty;
            string CardholderPresentData = string.Empty;
            string CardPresentData = string.Empty;
            string CardDataInputMode = string.Empty;
            string CardHolderAuthMode = string.Empty;
            string CardholderAuthEntity = string.Empty;
            string CardDataOPCapability = string.Empty;
            string TerminalDataCapability = string.Empty;
            string PinCaptureCapability = string.Empty;
            string ZipCode = string.Empty;
            string AdviceReasonCode = string.Empty;
            string ITPAN = string.Empty;
            string INTRAUTHNW = string.Empty;
            string OTPIndicator = string.Empty;
            string ICSTXNID = string.Empty;
            string NWDATA = string.Empty;
            string ServiceCode = string.Empty;
            string CCYActualTxnsAmount = "0";
            string ActualTxnsAmount = "0";
            string CREATEDON = string.Empty;
            string MODIFIEDDON = string.Empty;
            string ModifiedBy = string.Empty;
            string CreatedBy = string.Empty;
            string ECardNumber = string.Empty;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;

            int Start = 0;
            int End = 0;

            foreach (string line in System.IO.File.ReadAllLines(path))
            {
                LineNo++;
                try
                {

                    string line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                    //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                    Incr = 1;
                    MessageType = string.Empty;
                    ProductID = string.Empty;
                    TxnsType = string.Empty;
                    FromAccountType = string.Empty;
                    ToAccountType = string.Empty;
                    ActionCode = string.Empty;
                    ResponseCode = string.Empty;
                    CardNumber = string.Empty;
                    ApprovalNumber = string.Empty;
                    ReferenceNumber = string.Empty;
                    TxnsDateTime = string.Empty;
                    TxnsTime = string.Empty;
                    MerchantCategoryCode = string.Empty;
                    CardAcceptorID = string.Empty;
                    TerminalId = string.Empty;
                    TerminalLocation = string.Empty;
                    AcquirerID = string.Empty;
                    TxnsCCYCode = string.Empty;
                    TxnsAmount = "0";
                    CardHolderBillingCCY = string.Empty;
                    CardHolderBillingAmount = "0";
                    PANEntryMode = string.Empty;
                    PINEntryCapability = string.Empty;
                    POSConditionCode = string.Empty;
                    AcquirerCountryCode = string.Empty;
                    AdditionalAmount = "0";
                    RuPayProduct = string.Empty;
                    CVD2MatchResult = string.Empty;
                    CVDICVDMatchResult = string.Empty;
                    RecurringPayIndicator = string.Empty;
                    ECIIndicator = string.Empty;
                    ICS1ResultCode = string.Empty;
                    FraudScore = string.Empty;
                    EMIAmount = "0";
                    ARQCAuthorization = string.Empty;
                    TxnsID = string.Empty;
                    LoyaltyPoint = string.Empty;
                    ICS2ResultCode = string.Empty;
                    CustMobileNumber = string.Empty;
                    ImageCode = string.Empty;
                    PersonalPhase = string.Empty;
                    UIDNumber = string.Empty;
                    CardDataInputCapability = string.Empty;
                    CardHolderAuthCapability = string.Empty;
                    CardCaptureCapability = string.Empty;
                    TerminalOpEnvironment = string.Empty;
                    CardholderPresentData = string.Empty;
                    CardPresentData = string.Empty;
                    CardDataInputMode = string.Empty;
                    CardHolderAuthMode = string.Empty;
                    CardholderAuthEntity = string.Empty;
                    CardDataOPCapability = string.Empty;
                    TerminalDataCapability = string.Empty;
                    PinCaptureCapability = string.Empty;
                    ZipCode = string.Empty;
                    AdviceReasonCode = string.Empty;
                    ITPAN = string.Empty;
                    INTRAUTHNW = string.Empty;
                    OTPIndicator = string.Empty;
                    ICSTXNID = string.Empty;
                    NWDATA = string.Empty;
                    ServiceCode = string.Empty;
                    CCYActualTxnsAmount = "0";
                    ActualTxnsAmount = "0";
                    CREATEDON = string.Empty;
                    MODIFIEDDON = string.Empty;
                    ModifiedBy = string.Empty;
                    CreatedBy = string.Empty;
                    ECardNumber = string.Empty;
                    CardScheme = string.Empty;

                    try
                    {
                        if (line1.StartsWith("HDR"))
                        {

                            string FileFormat = line1.Substring(3, 6).Trim();
                            Filedate = DateTime.ParseExact(FileFormat.ToString(), "yyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                        }

                        if (ds.Tables["MessageType"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MessageType"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["MessageType"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["MessageType"].Rows[0]["Length"].ToString());
                            MessageType = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["ProductID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ProductID"].Rows[0]["Length"].ToString() != "0")
                        {

                            Start = int.Parse(ds.Tables["ProductID"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ProductID"].Rows[0]["Length"].ToString());
                            ProductID = line1.Substring(Start - Incr, End);

                        }
                        if (ds.Tables["TxnsType"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsType"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["TxnsType"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["TxnsType"].Rows[0]["Length"].ToString());
                            TxnsType = line1.Substring(Start - Incr, End);

                        }
                        if (ds.Tables["FromAccountType"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FromAccountType"].Rows[0]["Length"].ToString() != "0")
                        {

                            Start = int.Parse(ds.Tables["FromAccountType"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["FromAccountType"].Rows[0]["Length"].ToString());
                            FromAccountType = line1.Substring(Start - Incr, End);


                        }
                        if (ds.Tables["ToAccountType"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ToAccountType"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ToAccountType"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ToAccountType"].Rows[0]["Length"].ToString());
                            ToAccountType = line1.Substring(Start - Incr, End);

                        }
                        if (ds.Tables["ActionCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ActionCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ActionCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ActionCode"].Rows[0]["Length"].ToString());
                            ActionCode = line1.Substring(Start - Incr, End);

                        }
                        if (ds.Tables["ResponseCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ResponseCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ResponseCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ResponseCode"].Rows[0]["Length"].ToString());
                            ResponseCode = line1.Substring(Start - Incr, End);

                        }
                        if (ds.Tables["CardNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardNumber"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardNumber"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardNumber"].Rows[0]["Length"].ToString());
                            CardNumber = Convert.ToString(Convert.ToUInt64(line1.Substring(Start - Incr, End).Trim()));
                        }
                        if (ds.Tables["ApprovalNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ApprovalNumber"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ApprovalNumber"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ApprovalNumber"].Rows[0]["Length"].ToString());
                            ApprovalNumber = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReferenceNumber"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ReferenceNumber"].Rows[0]["Length"].ToString());
                            ReferenceNumber = line1.Substring(Start - Incr, End);
                            //ReferenceNumber = ReferenceNumber.TrimStart('0');
                        }
                        if (ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsDateTime"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["TxnsDateTime"].Rows[0]["Length"].ToString());
                            TxnsDateTime = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["TxnsTime"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsTime"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["TxnsTime"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["TxnsTime"].Rows[0]["Length"].ToString());
                            TxnsTime = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["MerchantCategoryCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MerchantCategoryCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["MerchantCategoryCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["MerchantCategoryCode"].Rows[0]["Length"].ToString());
                            MerchantCategoryCode = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["CardAcceptorID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardAcceptorID"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardAcceptorID"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardAcceptorID"].Rows[0]["Length"].ToString());
                            CardAcceptorID = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["TerminalId"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalId"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["TerminalId"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["TerminalId"].Rows[0]["Length"].ToString());
                            TerminalId = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["TerminalLocation"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalLocation"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["TerminalLocation"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["TerminalLocation"].Rows[0]["Length"].ToString());
                            TerminalLocation = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["AcquirerID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AcquirerID"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["AcquirerID"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["AcquirerID"].Rows[0]["Length"].ToString());
                            AcquirerID = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["TxnsCCYCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsCCYCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["TxnsCCYCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["TxnsCCYCode"].Rows[0]["Length"].ToString());
                            TxnsCCYCode = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["TxnsAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsAmount"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["TxnsAmount"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["TxnsAmount"].Rows[0]["Length"].ToString());
                            TxnsAmount = line1.Substring(Start - Incr, End);
                            TxnsAmount = TxnsAmount.Substring(0, 13) + '.' + TxnsAmount.Substring(13, 2);
                        }

                        if (ds.Tables["CardHolderBillingCCY"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardHolderBillingCCY"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardHolderBillingCCY"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardHolderBillingCCY"].Rows[0]["Length"].ToString());
                            CardHolderBillingCCY = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["CardHolderBillingAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardHolderBillingAmount"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardHolderBillingAmount"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardHolderBillingAmount"].Rows[0]["Length"].ToString());
                            CardHolderBillingAmount = line1.Substring(Start - Incr, End);

                        }

                        if (ds.Tables["PANEntryMode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PANEntryMode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["PANEntryMode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["PANEntryMode"].Rows[0]["Length"].ToString());
                            PANEntryMode = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["PINEntryCapability"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PINEntryCapability"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["PINEntryCapability"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["PINEntryCapability"].Rows[0]["Length"].ToString());
                            PINEntryCapability = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["POSConditionCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["POSConditionCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["POSConditionCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["POSConditionCode"].Rows[0]["Length"].ToString());
                            POSConditionCode = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["AcquirerCountryCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AcquirerCountryCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["AcquirerCountryCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["AcquirerCountryCode"].Rows[0]["Length"].ToString());
                            AcquirerCountryCode = line1.Substring(Start - Incr, End);
                        }


                        if (ds.Tables["AdditionalAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AdditionalAmount"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["AdditionalAmount"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["AdditionalAmount"].Rows[0]["Length"].ToString());
                            AdditionalAmount = line1.Substring(Start - Incr, End);
                            AdditionalAmount = AdditionalAmount.Substring(0, 13) + '.' + AdditionalAmount.Substring(13, 2);
                        }
                        if (ds.Tables["RuPayProduct"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["RuPayProduct"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["RuPayProduct"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["RuPayProduct"].Rows[0]["Length"].ToString());
                            RuPayProduct = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["CVD2MatchResult"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CVD2MatchResult"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CVD2MatchResult"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CVD2MatchResult"].Rows[0]["Length"].ToString());
                            CVD2MatchResult = line1.Substring(Start - Incr, End);
                        }


                        if (ds.Tables["RecurringPayIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["RecurringPayIndicator"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["RecurringPayIndicator"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["RecurringPayIndicator"].Rows[0]["Length"].ToString());
                            RecurringPayIndicator = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["ECIIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ECIIndicator"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ECIIndicator"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ECIIndicator"].Rows[0]["Length"].ToString());
                            ECIIndicator = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["ICS1ResultCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ICS1ResultCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ICS1ResultCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ICS1ResultCode"].Rows[0]["Length"].ToString());
                            ICS1ResultCode = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["FraudScore"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FraudScore"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["FraudScore"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["FraudScore"].Rows[0]["Length"].ToString());
                            FraudScore = line1.Substring(Start - Incr, End);
                        }


                        if (ds.Tables["EMIAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["EMIAmount"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["EMIAmount"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["EMIAmount"].Rows[0]["Length"].ToString());
                            EMIAmount = line1.Substring(Start - Incr, End);
                            EMIAmount = EMIAmount.Substring(0, 24) + '.' + EMIAmount.Substring(24, 2);
                        }

                        if (ds.Tables["ARQCAuthorization"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ARQCAuthorization"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ARQCAuthorization"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ARQCAuthorization"].Rows[0]["Length"].ToString());
                            ARQCAuthorization = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["TxnsID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsID"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["TxnsID"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["TxnsID"].Rows[0]["Length"].ToString());
                            TxnsID = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["LoyaltyPoint"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LoyaltyPoint"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["LoyaltyPoint"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["LoyaltyPoint"].Rows[0]["Length"].ToString());
                            LoyaltyPoint = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["ICS2ResultCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ICS2ResultCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ICS2ResultCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ICS2ResultCode"].Rows[0]["Length"].ToString());
                            ICS2ResultCode = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["CustMobileNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CustMobileNumber"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CustMobileNumber"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CustMobileNumber"].Rows[0]["Length"].ToString());
                            CustMobileNumber = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["ImageCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ImageCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ImageCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ImageCode"].Rows[0]["Length"].ToString());
                            ImageCode = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["PersonalPhase"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PersonalPhase"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["PersonalPhase"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["PersonalPhase"].Rows[0]["Length"].ToString());
                            PersonalPhase = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["UIDNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["UIDNumber"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["UIDNumber"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["UIDNumber"].Rows[0]["Length"].ToString());
                            UIDNumber = line1.Substring(Start - Incr, End);
                        }


                        if (ds.Tables["CardDataInputCapability"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardDataInputCapability"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardDataInputCapability"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardDataInputCapability"].Rows[0]["Length"].ToString());
                            CardDataInputCapability = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["CardHolderAuthCapability"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardHolderAuthCapability"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardHolderAuthCapability"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardHolderAuthCapability"].Rows[0]["Length"].ToString());
                            CardHolderAuthCapability = line1.Substring(Start - Incr, End);
                        }


                        if (ds.Tables["TerminalOpEnvironment"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalOpEnvironment"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["TerminalOpEnvironment"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["TerminalOpEnvironment"].Rows[0]["Length"].ToString());
                            TerminalOpEnvironment = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["CardholderPresentData"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardholderPresentData"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardholderPresentData"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardholderPresentData"].Rows[0]["Length"].ToString());
                            CardholderPresentData = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["CardPresentData"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardPresentData"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardPresentData"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardPresentData"].Rows[0]["Length"].ToString());
                            CardPresentData = line1.Substring(Start - Incr, End);
                        }


                        if (ds.Tables["CardDataInputMode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardDataInputMode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardDataInputMode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardDataInputMode"].Rows[0]["Length"].ToString());
                            CardDataInputMode = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["CardHolderAuthMode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardHolderAuthMode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardHolderAuthMode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardHolderAuthMode"].Rows[0]["Length"].ToString());
                            CardHolderAuthMode = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["CardholderAuthEntity"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardholderAuthEntity"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardholderAuthEntity"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardholderAuthEntity"].Rows[0]["Length"].ToString());
                            CardholderAuthEntity = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["CardDataOPCapability"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardDataOPCapability"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CardDataOPCapability"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CardDataOPCapability"].Rows[0]["Length"].ToString());
                            CardDataOPCapability = line1.Substring(Start - Incr, End);
                        }



                        if (ds.Tables["TerminalDataCapability"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalDataCapability"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["TerminalDataCapability"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["TerminalDataCapability"].Rows[0]["Length"].ToString());
                            TerminalDataCapability = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["PinCaptureCapability"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PinCaptureCapability"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["PinCaptureCapability"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["PinCaptureCapability"].Rows[0]["Length"].ToString());
                            PinCaptureCapability = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["ZipCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ZipCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ZipCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ZipCode"].Rows[0]["Length"].ToString());
                            ZipCode = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["AdviceReasonCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AdviceReasonCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["AdviceReasonCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["AdviceReasonCode"].Rows[0]["Length"].ToString());
                            AdviceReasonCode = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["ITPAN"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ITPAN"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ITPAN"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ITPAN"].Rows[0]["Length"].ToString());
                            ITPAN = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["INTRAUTHNW"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["INTRAUTHNW"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["INTRAUTHNW"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["INTRAUTHNW"].Rows[0]["Length"].ToString());
                            INTRAUTHNW = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["OTPIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["OTPIndicator"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["OTPIndicator"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["OTPIndicator"].Rows[0]["Length"].ToString());
                            OTPIndicator = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["ICSTXNID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ICSTXNID"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ICSTXNID"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ICSTXNID"].Rows[0]["Length"].ToString());
                            ICSTXNID = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["NWDATA"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NWDATA"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["NWDATA"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["NWDATA"].Rows[0]["Length"].ToString());
                            NWDATA = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["ServiceCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ServiceCode"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ServiceCode"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ServiceCode"].Rows[0]["Length"].ToString());
                            ServiceCode = line1.Substring(Start - Incr, End);
                        }
                        if (ds.Tables["CCYActualTxnsAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CCYActualTxnsAmount"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["CCYActualTxnsAmount"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["CCYActualTxnsAmount"].Rows[0]["Length"].ToString());
                            CCYActualTxnsAmount = line1.Substring(Start - Incr, End);
                        }

                        if (ds.Tables["ActualTxnsAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ActualTxnsAmount"].Rows[0]["Length"].ToString() != "0")
                        {
                            Start = int.Parse(ds.Tables["ActualTxnsAmount"].Rows[0]["StartPosition"].ToString());
                            End = int.Parse(ds.Tables["ActualTxnsAmount"].Rows[0]["Length"].ToString());
                            ActualTxnsAmount = line1.Substring(Start - Incr, End);
                            ActualTxnsAmount = ActualTxnsAmount.Substring(0, 13) + '.' + ActualTxnsAmount.Substring(13, 2);
                        }
                    }
                    catch
                    {

                    }


                    #region StanderedFields
                    CardType = string.Empty;
                    TxnsDateTimeMain = null;


                    #region ValidateField

                    if (TxnsDateTime != "" && TxnsTime != "")
                    {
                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime + TxnsTime, "yyMMddHHmmss", System.Globalization.CultureInfo.InvariantCulture);
                    }
                     

                    if (CardNumber != "")
                    {
                        if (CardNumber.Substring(0, 1) == "4")
                        {
                            CardScheme = "VISA";
                        }
                        else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                        {
                            CardScheme = "MASTER";
                        }
                        else if (CardNumber.Substring(0, 2) == "62")
                        {
                            CardScheme = "CUP";
                        }
                        else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                        {
                            CardScheme = "RuPay";
                        }
                        else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                        {
                            CardScheme = "Maestro";
                        } 

                    }

                    #endregion ValidateField

                    #region InitilizedField

                    #endregion InitilizedField


                    #endregion StanderedFields

                    if (CardNumber != "")
                    {
                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                    }

                    if (CardNumber != "")
                    {
                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                    }

                    if (TxnsDateTime != "" && TxnsTime != "")
                    {
                        _DataTable.Rows.Add(ClientID
                                        , MessageType
                                        , ProductID
                                        , TxnsType
                                        , FromAccountType
                                        , ToAccountType
                                        , ActionCode
                                        , ResponseCode
                                        , CardNumber.Trim()
                                        , CardType
                                        , ApprovalNumber
                                        , ReferenceNumber
                                        , TxnsDateTimeMain
                                        , MerchantCategoryCode
                                        , CardAcceptorID
                                        , TerminalId
                                        , TerminalLocation
                                        , AcquirerID
                                        , TxnsCCYCode
                                        , Convert.ToDecimal(TxnsAmount)
                                        , CardHolderBillingCCY
                                        , CardHolderBillingAmount
                                        , PANEntryMode
                                        , PINEntryCapability
                                        , POSConditionCode
                                        , AcquirerCountryCode
                                        , Convert.ToDecimal(AdditionalAmount)
                                        , RuPayProduct
                                        , CVD2MatchResult
                                        , CVDICVDMatchResult
                                        , RecurringPayIndicator
                                        , ECIIndicator
                                        , ICS1ResultCode
                                        , FraudScore
                                        , Convert.ToDecimal(EMIAmount)
                                        , ARQCAuthorization
                                        , TxnsID
                                        , LoyaltyPoint
                                        , ICS2ResultCode
                                        , CustMobileNumber
                                        , ImageCode
                                        , PersonalPhase
                                        , UIDNumber
                                        , CardDataInputCapability
                                        , CardHolderAuthCapability
                                        , CardCaptureCapability
                                        , TerminalOpEnvironment
                                        , CardholderPresentData
                                        , CardPresentData
                                        , CardDataInputMode
                                        , CardHolderAuthMode
                                        , CardholderAuthEntity
                                        , CardDataOPCapability
                                        , TerminalDataCapability
                                        , PinCaptureCapability
                                        , ZipCode
                                        , AdviceReasonCode
                                        , ITPAN
                                        , INTRAUTHNW
                                        , OTPIndicator
                                        , ICSTXNID
                                        , NWDATA
                                        , ServiceCode
                                        , CCYActualTxnsAmount
                                        , Convert.ToDecimal(ActualTxnsAmount)
                                        , RevEntryLeg
                                        , 0
                                        , Cycle
                                        , Filedate
                                        , FileName
                                        , path
                                        , DateTime.Now
                                        , DateTime.Now
                                        , UserName
                                        , UserName
                                        , ECardNumber
                                        , CardScheme
                                        , IssuingNetwork
                                        );
                    }

                }
                catch (Exception ex)
                {
                    //objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }

            }
            if (_DataTable.Rows.Count > 0)
            {
                InsertCount = _DataTable.Rows.Count;
            }

            return _DataTable;

        }

        public DataTable SpliterPOSSummaryNPCI(string FilePath, string FileName, DataTable dt, string UserName, string BankCode, string ConnectionString, out int InsertCount, out int TotalCount)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            LogWriter _log = new LogWriter();
            int ErrorCount = 0;
            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();
            DataTable _DataTable1 = new DataTable();
            DataTable _DataTable2 = new DataTable();
            DataTable _name = new DataTable();

            _name.Columns.Add("Temp");
            try
            {
                if (FileName.Contains("DSRSummaryReport"))
                {
                    _DataTable.Columns.Add("ClientID", typeof(int));
                    _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("TXNCOUNT", typeof(string));
                    _DataTable.Columns.Add("TxnAmtDR", typeof(Decimal));
                    _DataTable.Columns.Add("TxnAmtCR", typeof(Decimal));
                    _DataTable.Columns.Add("SETAMTDR", typeof(Decimal));
                    _DataTable.Columns.Add("SETAMTCR", typeof(Decimal));
                    _DataTable.Columns.Add("IntFeeAmtDR", typeof(Decimal));
                    _DataTable.Columns.Add("IntFeeAmtCR", typeof(Decimal));
                    _DataTable.Columns.Add("MemIncFeeAmtDR", typeof(Decimal));
                    _DataTable.Columns.Add("MemIncFeeAmtCR", typeof(Decimal));
                    _DataTable.Columns.Add("OthFeeAmtDR", typeof(Decimal));
                    _DataTable.Columns.Add("OthFeeAmtCR", typeof(Decimal));
                    _DataTable.Columns.Add("OthFeeGSTDR", typeof(Decimal));
                    _DataTable.Columns.Add("OthFeeGSTCR", typeof(Decimal));
                    _DataTable.Columns.Add("FinalSumCr", typeof(Decimal));
                    _DataTable.Columns.Add("FinalSumDr", typeof(Decimal));
                    _DataTable.Columns.Add("FinalNet", typeof(Decimal));
                    _DataTable.Columns.Add("Cycle", typeof(string));
                    _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
                    _DataTable.Columns.Add("MODIFIEDDON", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedBy", typeof(string));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));
                    _DataTable.Columns.Add("Channel", typeof(string));
                    _DataTable.Columns.Add("CusCmpnstnDr", typeof(Decimal));
                    _DataTable.Columns.Add("CusCmpnstnCr", typeof(Decimal));

                    _DataTable.Columns.Add("FirstSP", typeof(string));
                    _DataTable = ProcessSummarySpliter(FilePath, dt, _DataTable, UserName, BankCode, FileName, ConnectionString, out InsertCount, out TotalCount);



                }

                else if (FileName.Contains("InterchangeSummaryReport"))
                {
                    _DataTable.Columns.Add("ClientID", typeof(int));
                    _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("TXNCOUNT", typeof(int));
                    _DataTable.Columns.Add("AmtCR", typeof(Decimal));
                    _DataTable.Columns.Add("AmtDR", typeof(Decimal));
                    _DataTable.Columns.Add("FeeCR", typeof(Decimal));
                    _DataTable.Columns.Add("FeeDR", typeof(Decimal));
                    _DataTable.Columns.Add("Cycle", typeof(string));
                    _DataTable.Columns.Add("Channel", typeof(string));
                    _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
                    _DataTable.Columns.Add("MODIFIEDDON", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedBy", typeof(string));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));

                    _DataTable.Columns.Add("FirstSP", typeof(string));


                    _DataTable = ProcessSummarySpliter(FilePath, dt, _DataTable, UserName, BankCode, FileName, ConnectionString, out InsertCount, out TotalCount);
                }

                else if (FileName.Contains("NPCIBillingSummary"))
                {
                    _DataTable.Columns.Add("ClientID", typeof(int));
                    _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("TXNCOUNT", typeof(int));
                    _DataTable.Columns.Add("FeeAmt", typeof(Decimal));
                    _DataTable.Columns.Add("FeeAmtGST", typeof(Decimal));
                    _DataTable.Columns.Add("Fee", typeof(Decimal));
                    _DataTable.Columns.Add("Cycle", typeof(string));
                    _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
                    _DataTable.Columns.Add("MODIFIEDDON", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedBy", typeof(string));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));
                    _DataTable.Columns.Add("Description", typeof(string));
                    _DataTable.Columns.Add("FirstSP", typeof(string));



                    _DataTable = ProcessSummarySpliter(FilePath, dt, _DataTable, UserName, BankCode, FileName, ConnectionString, out InsertCount, out TotalCount);
                }

                else if (FileName.Contains("Presentment"))
                {
                    _DataTable.Columns.Add("ClientID", typeof(int));
                    _DataTable.Columns.Add("ReportDate", typeof(DateTime));
                    _DataTable.Columns.Add("RaiseDate", typeof(DateTime));
                    _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("Description", typeof(string));
                    _DataTable.Columns.Add("PAN", typeof(string));
                    _DataTable.Columns.Add("Date", typeof(DateTime));
                    _DataTable.Columns.Add("RRN", typeof(string));
                    _DataTable.Columns.Add("ProcessingCode", typeof(string));
                    _DataTable.Columns.Add("CurrencyCode", typeof(string));
                    _DataTable.Columns.Add("Indicator", typeof(string));
                    _DataTable.Columns.Add("AmountTransaction", typeof(Decimal));
                    _DataTable.Columns.Add("AmountAdditional", typeof(Decimal));
                    _DataTable.Columns.Add("SettlementTxnAmount", typeof(Decimal));
                    _DataTable.Columns.Add("SettlementAddAmount", typeof(Decimal));
                    _DataTable.Columns.Add("ApprovalCode", typeof(string));
                    _DataTable.Columns.Add("OriginatorPoint", typeof(string));
                    _DataTable.Columns.Add("POSEntryMode", typeof(string));
                    _DataTable.Columns.Add("POSConditionCode", typeof(string));
                    _DataTable.Columns.Add("AcquirerID", typeof(string));
                    _DataTable.Columns.Add("AcquirerInstitutionID", typeof(string));
                    _DataTable.Columns.Add("AcquirerNameandCountry", typeof(string));
                    _DataTable.Columns.Add("IssuerID", typeof(string));
                    _DataTable.Columns.Add("IssuerInstitutionID", typeof(string));
                    _DataTable.Columns.Add("IssuerNameandCountry", typeof(string));
                    _DataTable.Columns.Add("CardType", typeof(string));
                    _DataTable.Columns.Add("CardBrand", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorTerminalID", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorName", typeof(string));
                    _DataTable.Columns.Add("CardAcceptoraddress", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorCountryCode", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorBusinessCode", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorIDCode", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorStateName", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorCity", typeof(string));
                    _DataTable.Columns.Add("DaysAged", typeof(string));
                    _DataTable.Columns.Add("MTI", typeof(string));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));
                    _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedBy", typeof(string));
                    _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
                    _DataTable.Columns.Add("FirstSP", typeof(string));
                    _DataTable = ProcessSummarySpliter(FilePath, dt, _DataTable, UserName, BankCode, FileName, ConnectionString, out InsertCount, out TotalCount);
                }

                else if (FileName.Contains("NetSettlementReport"))
                {
                    _DataTable.Columns.Add("ClientID", typeof(int));
                    _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("MemberBankPID", typeof(string));
                    _DataTable.Columns.Add("MemberBankType", typeof(string));
                    _DataTable.Columns.Add("DRCR", typeof(string));
                    _DataTable.Columns.Add("FinalSumCr", typeof(Decimal));
                    _DataTable.Columns.Add("FinalSumDr", typeof(Decimal));
                    _DataTable.Columns.Add("Net", typeof(Decimal));
                    _DataTable.Columns.Add("Cycle", typeof(string));
                    _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedBy", typeof(string));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));
                    _DataTable.Columns.Add("FirstSP", typeof(string));
                    _DataTable = ProcessSummarySpliter(FilePath, dt, _DataTable, UserName, BankCode, FileName, ConnectionString, out InsertCount, out TotalCount);
                }
            }


            catch (Exception EX)
            {
                variable();
                //_log.FunErrorLog(EX.Message.ToString(), BankCode, "BFSFileSpliterBFS", "ATMATMBFSFileSpliterBFS", 0, FileName, UserName, 'E');
                DBLog.InsertLogs(EX.Message.ToString(), BankCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, 0, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;

        }

        public string ProcessSummaryPresentmentSettlementSpliter(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            string MSG = string.Empty;
            int LineNo = 0;
            int ErrorCount = 0;
            string FileName1 = System.IO.Path.GetFileNameWithoutExtension(fileImportRequest.Path);
            string batchStartTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            DataSet ds = new DataSet();
            DataTable _DataTable = new DataTable();
            DataTable dtfillsheet1 = new DataTable();
            try
            {

                if (fileImportRequest.FileName.Contains("DSRSummaryReport"))
                {
                    _DataTable.Columns.Add("ClientID", typeof(int));
                    _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("TXNCOUNT", typeof(string));
                    _DataTable.Columns.Add("TxnAmtDR", typeof(Decimal));
                    _DataTable.Columns.Add("TxnAmtCR", typeof(Decimal));
                    _DataTable.Columns.Add("SETAMTDR", typeof(Decimal));
                    _DataTable.Columns.Add("SETAMTCR", typeof(Decimal));
                    _DataTable.Columns.Add("IntFeeAmtDR", typeof(Decimal));
                    _DataTable.Columns.Add("IntFeeAmtCR", typeof(Decimal));
                    _DataTable.Columns.Add("MemIncFeeAmtDR", typeof(Decimal));
                    _DataTable.Columns.Add("MemIncFeeAmtCR", typeof(Decimal));
                    _DataTable.Columns.Add("OthFeeAmtDR", typeof(Decimal));
                    _DataTable.Columns.Add("OthFeeAmtCR", typeof(Decimal));
                    _DataTable.Columns.Add("OthFeeGSTDR", typeof(Decimal));
                    _DataTable.Columns.Add("OthFeeGSTCR", typeof(Decimal));
                    _DataTable.Columns.Add("FinalSumCr", typeof(Decimal));
                    _DataTable.Columns.Add("FinalSumDr", typeof(Decimal));
                    _DataTable.Columns.Add("FinalNet", typeof(Decimal));
                    _DataTable.Columns.Add("Cycle", typeof(string));
                    _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
                    _DataTable.Columns.Add("MODIFIEDDON", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedBy", typeof(string));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));
                    _DataTable.Columns.Add("Channel", typeof(string));
                    _DataTable.Columns.Add("CusCmpnstnDr", typeof(Decimal));
                    _DataTable.Columns.Add("CusCmpnstnCr", typeof(Decimal));

                    dtfillsheet1 = ExtractExcel(fileImportRequest.Path, fileImportRequest.FileName);
                    //DateTime SettlementDate;
                    decimal TxnAmtDR = 0; decimal TxnAmtCR = 0;
                    decimal SETAMTDR = 0; decimal SETAMTCR = 0;
                    decimal IntFeeAmtDR = 0; decimal IntFeeAmtCR = 0;
                    decimal MemIncFeeAmtDR = 0; decimal MemIncFeeAmtCR = 0;
                    decimal OthFeeAmtDR = 0; decimal OthFeeAmtCR = 0;
                    decimal OthFeeGSTDR = 0; decimal OthFeeGSTCR = 0;
                    decimal CusCmpnstnDr = 0; decimal CusCmpnstnCr = 0;
                    decimal FinalSumCr = 0; decimal FinalSumDr = 0; decimal FinalNet = 0; Boolean FlagA = false; Boolean FlagNA = false;
                    Boolean FlagR = false;

                    fileImportRequest.TotalCount = dtfillsheet1.Rows.Count;

                    if (dtfillsheet1.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                        {
                            try
                            {

                                string[] columnNames = dtfillsheet1.Columns.Cast<DataColumn>().Select(x => x.ColumnName).ToArray();
                                string col = dtfillsheet1.Rows[0][6].ToString();
                                string Setdate = dtfillsheet1.Rows[0][0].ToString();
                                string dt = DateTime.ParseExact(Setdate, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);//Convert.ToDateTime(Setdate);
                                                                                                                                                                          //SettlementDate = DateTime.ParseExact(dt.ToString(), "yyyy-MM-dd", CultureInfo.InvariantCulture);

                                if (columnNames[6] == "Status(Approved/Declined)")
                                {
                                    string status = dtfillsheet1.Rows[i][6].ToString(); if (status == "A") { FlagA = true; FlagNA = false; }
                                    if (status == "D" || dtfillsheet1.Rows[i][5].ToString() == "Total") { FlagA = false; FlagNA = false; }
                                    if (status == "NA") { FlagNA = true; FlagA = false; }
                                    string status1 = dtfillsheet1.Rows[i][5].ToString();
                                    string tmp = dtfillsheet1.Rows[i][7].ToString();
                                    string Channel = dtfillsheet1.Rows[i][9].ToString();
                                    if (tmp == "Refund" && dtfillsheet1.Rows[i][5].ToString() == "")
                                    {
                                        FlagR = true;
                                        //Channel = "Refund" + " " + Channel;
                                    }
                                    else if (dtfillsheet1.Rows[i][5].ToString() != "")
                                    {
                                        FlagR = false;
                                    }
                                    if (FlagR == true)
                                    {
                                        Channel = "Refund" + " " + Channel;
                                    }

                                    if (FlagA == true || FlagNA == true)
                                    {
                                        //string TxnCount = dtfillsheet1.Rows[TableCount][10].ToString();
                                        string TxnCount = dtfillsheet1.Rows[i][10].ToString();
                                        string TxnAmtDR1 = dtfillsheet1.Rows[i][12].ToString();
                                        TxnAmtDR = Convert.ToDecimal(TxnAmtDR1);
                                        string TxnAmtCR1 = dtfillsheet1.Rows[i][13].ToString();
                                        TxnAmtCR = Convert.ToDecimal(TxnAmtCR1);
                                        string SETAMTDR1 = dtfillsheet1.Rows[i][15].ToString();
                                        SETAMTDR = Convert.ToDecimal(SETAMTDR1);
                                        string SETAMTCR1 = dtfillsheet1.Rows[i][16].ToString();
                                        SETAMTCR = Convert.ToDecimal(SETAMTCR1);
                                        string IntFeeAmtDR1 = dtfillsheet1.Rows[i][17].ToString();
                                        IntFeeAmtDR = Convert.ToDecimal(IntFeeAmtDR1);
                                        string IntFeeAmtCR1 = dtfillsheet1.Rows[i][18].ToString();
                                        IntFeeAmtCR = Convert.ToDecimal(IntFeeAmtCR1);
                                        string MemIncFeeAmtDR1 = dtfillsheet1.Rows[i][19].ToString();
                                        MemIncFeeAmtDR = Convert.ToDecimal(MemIncFeeAmtDR1);
                                        string MemIncFeeAmtCR1 = dtfillsheet1.Rows[i][20].ToString();
                                        MemIncFeeAmtCR = Convert.ToDecimal(MemIncFeeAmtCR1);
                                        string CusCmpnstnDr1 = dtfillsheet1.Rows[i][21].ToString();
                                        CusCmpnstnDr = Convert.ToDecimal(MemIncFeeAmtDR1);
                                        string CusCmpnstnCr1 = dtfillsheet1.Rows[i][22].ToString();
                                        CusCmpnstnCr = Convert.ToDecimal(MemIncFeeAmtCR1);
                                        string OthFeeAmtDR1 = dtfillsheet1.Rows[i][23].ToString();
                                        OthFeeAmtDR = Convert.ToDecimal(OthFeeAmtDR1);
                                        string OthFeeAmtCR1 = dtfillsheet1.Rows[i][24].ToString();
                                        OthFeeAmtCR = Convert.ToDecimal(OthFeeAmtCR1);
                                        string OthFeeGSTDR1 = dtfillsheet1.Rows[i][25].ToString();
                                        OthFeeGSTDR = Convert.ToDecimal(OthFeeGSTDR1);
                                        string OthFeeGSTCR1 = dtfillsheet1.Rows[i][26].ToString();
                                        OthFeeGSTCR = Convert.ToDecimal(OthFeeGSTCR1);
                                        string FinalSumCr1 = dtfillsheet1.Rows[i][27].ToString();
                                        FinalSumCr = Convert.ToDecimal(FinalSumCr1);
                                        string FinalSumDr1 = dtfillsheet1.Rows[i][28].ToString();
                                        FinalSumDr = Convert.ToDecimal(FinalSumDr1);
                                        string FinalNet1 = dtfillsheet1.Rows[i][29].ToString();
                                        FinalNet = Convert.ToDecimal(FinalNet1);

                                        string[] temp = fileImportRequest.FileName.Split('.');
                                        string tempCycle = temp[0];
                                        char Cycle = tempCycle[tempCycle.Length - 1];

                                        TxnCount = TxnCount.IndexOf(".") > 0 ? TxnCount.Trim().Substring(0, TxnCount.Trim().IndexOf(".")).Trim() : TxnCount.Trim();

                                        TxnCount = Common.IsNumeric(TxnCount) ? Convert.ToInt32(TxnCount).ToString() : "0";
                                        //if (FlagNA == true) Channel = "NA_" + Channel;
                                        //if (FlagA == true) Channel = "A_" + Channel;
                                        _DataTable.Rows.Add(fileImportRequest.ClientCode, dt, TxnCount, TxnAmtDR, TxnAmtCR, SETAMTDR, SETAMTCR, IntFeeAmtDR, IntFeeAmtCR, MemIncFeeAmtDR, MemIncFeeAmtCR,
                                                             OthFeeAmtDR, OthFeeAmtCR, OthFeeGSTDR, OthFeeGSTCR, FinalSumCr, FinalSumDr, FinalNet, Cycle, DateTime.Now, DateTime.Now, fileImportRequest.UserName, fileImportRequest.UserName, Channel, CusCmpnstnDr, CusCmpnstnCr);

                                        fileImportRequest.InsertCount++;

                                    }
                                    if (status1 == "INWARD GST")
                                    {

                                        string OthFeeGSTDR1 = dtfillsheet1.Rows[i][25].ToString();
                                        OthFeeGSTDR = Convert.ToDecimal(OthFeeGSTDR1);
                                        string OthFeeGSTCR1 = dtfillsheet1.Rows[i][26].ToString();
                                        OthFeeGSTCR = Convert.ToDecimal(OthFeeGSTCR1);
                                        string FinalSumCr1 = dtfillsheet1.Rows[i][27].ToString();
                                        FinalSumCr = Convert.ToDecimal(FinalSumCr1);
                                        string FinalSumDr1 = dtfillsheet1.Rows[i][28].ToString();
                                        FinalSumDr = Convert.ToDecimal(FinalSumDr1);
                                        string FinalNet1 = dtfillsheet1.Rows[i][29].ToString();
                                        FinalNet = Convert.ToDecimal(FinalNet1); 

                                        string[] temp = fileImportRequest.FileName.Split('.');
                                        string tempCycle = temp[0];
                                        char Cycle = tempCycle[tempCycle.Length - 1];
                                        Channel = "INWARD GST";

                                        _DataTable.Rows.Add(fileImportRequest.ClientCode, dt, null, null, null, null, null, null, null, null, null,
                                                         null, null, OthFeeGSTDR, OthFeeGSTCR, FinalSumCr, FinalSumDr, FinalNet, Cycle, DateTime.Now, DateTime.Now, fileImportRequest.UserName, fileImportRequest.UserName, status1, null, null);

                                        fileImportRequest.InsertCount++;
                                    }
                                }
                                LineNo++;
                            }
                            catch (Exception ex)
                            {
                                ErrorCount++;
                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                            }
                        }

                        if (_DataTable.Rows.Count > 0)
                        {
                            MSG = bulkImports.DSRSummarryDataTable(_DataTable);
                        }
                        else
                        {
                            MSG = "Error occrued kindly check the log file for more details";
                        }
                    }
                    else
                    {
                        fileImportRequest.ErrorMessage = "File contains no records";
                        MSG = "Successful";
                    }
                }
                else if (fileImportRequest.FileName.Contains("InterchangeSummaryReport"))
                {
                    _DataTable.Columns.Add("ClientID", typeof(int));
                    _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("TXNCOUNT", typeof(int));
                    _DataTable.Columns.Add("AmtCR", typeof(Decimal));
                    _DataTable.Columns.Add("AmtDR", typeof(Decimal));
                    _DataTable.Columns.Add("FeeCR", typeof(Decimal));
                    _DataTable.Columns.Add("FeeDR", typeof(Decimal));
                    _DataTable.Columns.Add("Cycle", typeof(string));
                    _DataTable.Columns.Add("Channel", typeof(string));
                    _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
                    _DataTable.Columns.Add("MODIFIEDDON", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedBy", typeof(string));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));


                    //DateTime SettlementDate;
                    dtfillsheet1 = ExtractExcel(fileImportRequest.Path, fileImportRequest.FileName);
                    decimal Amt_CR = 0; decimal Amt_DR = 0;
                    decimal Fee_CR = 0; decimal Fee_DR = 0;
                    Boolean FlagP = false; Boolean FlagNA = false; Boolean FlagE = false;
                    string Channel = string.Empty;

                    fileImportRequest.TotalCount = dtfillsheet1.Rows.Count;

                    if (dtfillsheet1.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                        {
                            try
                            {
                                //string col = dtfillsheet1.Columns[5].ColumnName;
                                //if(col == "Inward/ Outward")
                                if (dtfillsheet1.Rows[i][5].ToString() != "Total" && dtfillsheet1.Rows[i][4].ToString() != "Total" && dtfillsheet1.Rows[i][3].ToString() != "Total"
                                     && dtfillsheet1.Rows[i][2].ToString() != "Total" && dtfillsheet1.Rows[i][1].ToString() != "Total")
                                {

                                    Channel = dtfillsheet1.Rows[i][8].ToString();
                                    if (Channel == "POS") { FlagP = true; FlagE = false; }
                                    if (Channel == "ECOM") { FlagP = false; FlagE = true; }
                                    if (dtfillsheet1.Rows[i][6].ToString() == "Refund") FlagNA = true;

                                    if (FlagP == true && FlagNA == false) Channel = "POS"; if (FlagE == true && FlagNA == false) Channel = "ECOM";
                                    if (FlagNA == true && FlagP == true) Channel = "Refund_POS"; if (FlagNA == true && FlagE == true) Channel = "Refund_ECOM";

                                    string Setdate = dtfillsheet1.Rows[0][0].ToString();
                                    // SettlementDate = Convert.ToDateTime(Setdate);
                                    string dt = DateTime.ParseExact(Setdate, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                                    string TxnCount = dtfillsheet1.Rows[i][10].ToString();
                                    string Amt_CR1 = dtfillsheet1.Rows[i][12].ToString();
                                    Amt_CR = Convert.ToDecimal(Amt_CR1);
                                    string Amt_DR1 = dtfillsheet1.Rows[i][13].ToString();
                                    Amt_DR = Convert.ToDecimal(Amt_DR1);
                                    string Fee_CR1 = dtfillsheet1.Rows[i][14].ToString();
                                    Fee_CR = Convert.ToDecimal(Fee_CR1);
                                    string Fee_DR1 = dtfillsheet1.Rows[i][15].ToString();
                                    Fee_DR = Convert.ToDecimal(Fee_DR1); 

                                    string[] temp = fileImportRequest.FileName.Split('.');
                                    string tempCycle = temp[0];
                                    char Cycle = tempCycle[tempCycle.Length - 1];

                                    TxnCount = TxnCount.IndexOf(".") > 0 ? TxnCount.Trim().Substring(0, TxnCount.Trim().IndexOf(".")).Trim() : TxnCount.Trim();

                                    TxnCount = Common.IsNumeric(TxnCount) ? Convert.ToInt32(TxnCount).ToString() : "0";

                                    _DataTable.Rows.Add(fileImportRequest.ClientCode, dt, TxnCount, Amt_CR, Amt_DR, Fee_CR, Fee_DR, Cycle, Channel, DateTime.Now, DateTime.Now, fileImportRequest.UserName, fileImportRequest.UserName);

                                    fileImportRequest.InsertCount++;
                                }
                                LineNo++;
                            }
                            catch (Exception ex)
                            {
                                ErrorCount++;
                                // InsertCount--;
                                //_log.FunErrorLog(ex.Message.ToString(), BankCode, "ProcessIssuerFileSpliterNPCI", "ProcessBFSFileSpliterBOB", LineNo, FileName, UserName, 'E');
                                //_FileImport.FileImportLog("issuer File", BankCode, FileName, System.DateTime.Now, UserName, LineNo, InsertCount, TotalCount, "Unsuccessful", ex.Message, ConnectionString);
                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                            }
                        }
                        if (_DataTable.Rows.Count > 0)
                        {
                            MSG = bulkImports.InterchangeSummarryDataTable(_DataTable);
                        }
                        else
                        {
                            MSG = "Error occrued kindly check the log file for more details";
                        }
                    }
                    else
                    {
                        fileImportRequest.ErrorMessage = "File contains no records";
                        MSG = "Successful";
                    }
                }
                else if (fileImportRequest.FileName.Contains("NPCIBillingSummary"))
                {

                    _DataTable.Columns.Add("ClientID", typeof(int));
                    _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("TXNCOUNT", typeof(int));
                    _DataTable.Columns.Add("FeeAmt", typeof(Decimal));
                    _DataTable.Columns.Add("FeeAmtGST", typeof(Decimal));
                    _DataTable.Columns.Add("Fee", typeof(Decimal));
                    _DataTable.Columns.Add("Cycle", typeof(string));
                    _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
                    _DataTable.Columns.Add("MODIFIEDDON", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedBy", typeof(string));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));
                    _DataTable.Columns.Add("Description", typeof(string));

                    // DateTime SettlementDate;
                    dtfillsheet1 = ExtractExcel(fileImportRequest.Path, fileImportRequest.FileName);
                    decimal FeeAmt = 0; decimal FeeAmtGST = 0;
                    decimal Fee = 0;

                    fileImportRequest.TotalCount = dtfillsheet1.Rows.Count;
                    if (dtfillsheet1.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                        {
                            try
                            {
                                if (dtfillsheet1.Rows[i][5].ToString() != "Total" && dtfillsheet1.Rows[i][4].ToString() != "Total" && dtfillsheet1.Rows[i][3].ToString() != "Total"
                                     && dtfillsheet1.Rows[i][2].ToString() != "Total" && dtfillsheet1.Rows[i][1].ToString() != "Total")
                                {
                                    string Setdate = dtfillsheet1.Rows[0][0].ToString();
                                    // SettlementDate = Convert.ToDateTime(Setdate);
                                    string dt = DateTime.ParseExact(Setdate, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                                    string TxnCount = dtfillsheet1.Rows[i][8].ToString();
                                    string FeeAmt1 = dtfillsheet1.Rows[i][10].ToString();
                                    FeeAmt = Convert.ToDecimal(FeeAmt1);
                                    string FeeAmtGST1 = dtfillsheet1.Rows[i][11].ToString();
                                    FeeAmtGST = Convert.ToDecimal(FeeAmtGST1);
                                    string Fee1 = dtfillsheet1.Rows[i][12].ToString();
                                    Fee = Convert.ToDecimal(Fee1);
                                    string Description = dtfillsheet1.Rows[i][6].ToString(); 

                                    string[] temp = fileImportRequest.FileName.Split('.');
                                    string tempCycle = temp[0];
                                    char Cycle = tempCycle[tempCycle.Length - 1];

                                    TxnCount = TxnCount.IndexOf(".") > 0 ? TxnCount.Trim().Substring(0, TxnCount.Trim().IndexOf(".")).Trim() : TxnCount.Trim();

                                    TxnCount = Common.IsNumeric(TxnCount) ? Convert.ToInt32(TxnCount).ToString() : "0";

                                    _DataTable.Rows.Add(fileImportRequest.ClientCode, dt, TxnCount, FeeAmt, FeeAmtGST, Fee, Cycle, DateTime.Now, DateTime.Now, fileImportRequest.UserName, fileImportRequest.UserName, Description);

                                    fileImportRequest.InsertCount++;
                                }
                                LineNo++;
                            }
                            catch (Exception ex)
                            {
                                ErrorCount++;
                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                            }
                        }

                        if (_DataTable.Rows.Count > 0)
                        {
                            MSG = bulkImports.NPCIBillingSummarryDataTable(_DataTable);
                        }
                        else
                        {
                            MSG = "Error occrued kindly check the log file for more details";
                        }
                    }
                    else
                    {
                        fileImportRequest.ErrorMessage = "File contains no records";
                        MSG = "Successful";
                    }
                }

                else if (fileImportRequest.FileName.Contains("NetSettlementReport"))
                {
                    _DataTable.Columns.Add("ClientID", typeof(int));
                    _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("MemberBankPID", typeof(string));
                    _DataTable.Columns.Add("MemberBankType", typeof(string));
                    _DataTable.Columns.Add("DRCR", typeof(string));
                    _DataTable.Columns.Add("FinalSumCr", typeof(Decimal));
                    _DataTable.Columns.Add("FinalSumDr", typeof(Decimal));
                    _DataTable.Columns.Add("Net", typeof(Decimal));
                    _DataTable.Columns.Add("Cycle", typeof(string));
                    _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedBy", typeof(string));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));

                    // DateTime SettlementDate;
                    dtfillsheet1 = ExtractExcel(fileImportRequest.Path, fileImportRequest.FileName);
                    decimal FinalSumCr = 0; decimal FinalSumDr = 0;
                    decimal Net = 0;

                    fileImportRequest.TotalCount = dtfillsheet1.Rows.Count;

                    if (dtfillsheet1.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                        {
                            try
                            {
                                if (dtfillsheet1.Rows[i][5].ToString() != "Total" && dtfillsheet1.Rows[i][4].ToString() != "Total" && dtfillsheet1.Rows[i][3].ToString() != "Total"
                                     && dtfillsheet1.Rows[i][2].ToString() != "Total" && dtfillsheet1.Rows[i][1].ToString() != "Total")
                                {
                                    string Setdate = dtfillsheet1.Rows[0][0].ToString();
                                    //DateTime SettlementDate = Convert.ToDateTime(Setdate);
                                    //DateTime dt = DateTime.ParseExact(Setdate.ToString().Trim(), "dd-MMM-yy", CultureInfo.InvariantCulture);
                                    string dt = DateTime.ParseExact(Setdate, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                                    string MemberBankPID = dtfillsheet1.Rows[i][3].ToString();
                                    string MemberBankType = dtfillsheet1.Rows[i][4].ToString();
                                    string DRCR = dtfillsheet1.Rows[i][5].ToString();
                                    string FinalSumCr1 = dtfillsheet1.Rows[i][6].ToString();
                                    FinalSumCr = Convert.ToDecimal(FinalSumCr1);
                                    string FinalSumDr1 = dtfillsheet1.Rows[i][7].ToString();
                                    FinalSumDr = Convert.ToDecimal(FinalSumDr1);
                                    string Net1 = dtfillsheet1.Rows[i][8].ToString();
                                    Net = Convert.ToDecimal(Net1);

                                    string[] temp = fileImportRequest.FileName.Split('.');
                                    string tempCycle = temp[0];
                                    //char Cycle = tempCycle[tempCycle.Length - 1];
                                    string Cycle = tempCycle.Substring(tempCycle.Length - 1, 1);

                                    _DataTable.Rows.Add(fileImportRequest.ClientCode, dt, MemberBankPID, MemberBankType, DRCR, FinalSumCr, FinalSumDr, Net, Cycle, DateTime.Now, DateTime.Now, fileImportRequest.UserName, fileImportRequest.UserName);

                                    fileImportRequest.InsertCount++;
                                }
                                LineNo++;
                            }

                            catch (Exception ex)
                            {
                                ErrorCount++;
                                // InsertCount--;
                                //_log.FunErrorLog(ex.Message.ToString(), BankCode, "ProcessIssuerFileSpliterNPCI", "ProcessBFSFileSpliterBOB", LineNo, FileName, UserName, 'E');
                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                            }
                        }

                        if (_DataTable.Rows.Count > 0)
                        {
                            MSG = bulkImports.NetSettlementDataTable(_DataTable);
                        }
                        else
                        {
                            MSG = "Error occrued kindly check the log file for more details";
                        }
                    }
                    else
                    {
                        fileImportRequest.ErrorMessage = "File contains no records";
                        MSG = "Successful";
                    }

                }

                else if (fileImportRequest.FileName.Contains("Presentment"))
                {
                    _DataTable.Columns.Add("ClientID", typeof(int));
                    _DataTable.Columns.Add("ReportDate", typeof(DateTime));
                    _DataTable.Columns.Add("RaiseDate", typeof(DateTime));
                    _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
                    _DataTable.Columns.Add("Description", typeof(string));
                    _DataTable.Columns.Add("PAN", typeof(string));
                    _DataTable.Columns.Add("Date", typeof(DateTime));
                    _DataTable.Columns.Add("RRN", typeof(string));
                    _DataTable.Columns.Add("ProcessingCode", typeof(string));
                    _DataTable.Columns.Add("CurrencyCode", typeof(string));
                    _DataTable.Columns.Add("Indicator", typeof(string));
                    _DataTable.Columns.Add("AmountTransaction", typeof(Decimal));
                    _DataTable.Columns.Add("AmountAdditional", typeof(Decimal));
                    _DataTable.Columns.Add("SettlementTxnAmount", typeof(Decimal));
                    _DataTable.Columns.Add("SettlementAddAmount", typeof(Decimal));
                    _DataTable.Columns.Add("ApprovalCode", typeof(string));
                    _DataTable.Columns.Add("OriginatorPoint", typeof(string));
                    _DataTable.Columns.Add("POSEntryMode", typeof(string));
                    _DataTable.Columns.Add("POSConditionCode", typeof(string));
                    _DataTable.Columns.Add("AcquirerID", typeof(string));
                    _DataTable.Columns.Add("AcquirerInstitutionID", typeof(string));
                    _DataTable.Columns.Add("AcquirerNameandCountry", typeof(string));
                    _DataTable.Columns.Add("IssuerID", typeof(string));
                    _DataTable.Columns.Add("IssuerInstitutionID", typeof(string));
                    _DataTable.Columns.Add("IssuerNameandCountry", typeof(string));
                    _DataTable.Columns.Add("CardType", typeof(string));
                    _DataTable.Columns.Add("CardBrand", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorTerminalID", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorName", typeof(string));
                    _DataTable.Columns.Add("CardAcceptoraddress", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorCountryCode", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorBusinessCode", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorIDCode", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorStateName", typeof(string));
                    _DataTable.Columns.Add("CardAcceptorCity", typeof(string));
                    _DataTable.Columns.Add("DaysAged", typeof(string));
                    _DataTable.Columns.Add("MTI", typeof(string));
                    _DataTable.Columns.Add("CreatedBy", typeof(string));
                    _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
                    _DataTable.Columns.Add("ModifiedBy", typeof(string));
                    _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));

                    string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
                    fileImportRequest.TotalCount = TotalCountArray.Length;

                    if (TotalCountArray.Length > 0)
                    {
                        foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                        {
                            LineNo++;
                            try
                            {

                                string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);// dt.Rows[0]["SeparatorType"].ToString()
                                line1 = line.Replace("/", "").Replace("\"", "");
                                string[] colFields = line1.Split(new string[] { "," }, StringSplitOptions.None);
                                DateTime ReportDate;
                                DateTime RaiseDate;
                                DateTime SettlementDate;
                                string Description = string.Empty;
                                string PAN = string.Empty;
                                DateTime Date;
                                string RRN = string.Empty;
                                string ProcessingCode = string.Empty;
                                string CurrencyCode = string.Empty;
                                string Indicator = string.Empty;
                                Decimal AmountTransaction;
                                Decimal AmountAdditional;
                                Decimal SettlementTxnAmount;
                                Decimal SettlementAddAmount;
                                string ApprovalCode = string.Empty;
                                string OriginatorPoint = string.Empty;
                                string POSEntryMode = string.Empty;
                                string POSConditionCode = string.Empty;
                                string AcquirerID = string.Empty;
                                string AcquirerInstitutionID = string.Empty;
                                string AcquirerNameandCountry = string.Empty;
                                string IssuerID = string.Empty;
                                string IssuerInstitutionID = string.Empty;
                                string IssuerNameandCountry = string.Empty;
                                string CardType = string.Empty;
                                string CardBrand = string.Empty;
                                string CardAcceptorTerminalID = string.Empty;
                                string CardAcceptorName = string.Empty;
                                string CardAcceptoraddress = string.Empty;
                                string CardAcceptorCountryCode = string.Empty;
                                string CardAcceptorBusinessCode = string.Empty;
                                string CardAcceptorIDCode = string.Empty;
                                string CardAcceptorStateName = string.Empty;
                                string CardAcceptorCity = string.Empty;
                                string DaysAged = string.Empty;
                                string MTI = string.Empty;
                                string CreatedBy = string.Empty;
                                DateTime CreatedOn;
                                string ModifiedBy = string.Empty;
                                DateTime ModifiedOn;

                                ReportDate = DateTime.ParseExact(colFields[0].ToString().Trim(), "dd-MMM-yy", CultureInfo.InvariantCulture);
                                RaiseDate = DateTime.ParseExact(colFields[1].ToString().Trim(), "dd-MMM-yy", CultureInfo.InvariantCulture);
                                SettlementDate = DateTime.ParseExact(colFields[2].ToString().Trim(), "dd-MMM-yy", CultureInfo.InvariantCulture);
                                Description = colFields[3].ToString().Trim();
                                PAN = colFields[4].ToString().Trim();
                                Date = DateTime.ParseExact(colFields[5].ToString().Trim(), "dd-MMM-yy", CultureInfo.InvariantCulture);
                                RRN = colFields[6].ToString().Trim();
                                string[] RRN1 = RRN.Split('-');
                                RRN = RRN1[1].ToString();
                                ProcessingCode = colFields[7].ToString().Trim();
                                CurrencyCode = colFields[8].ToString().Trim();
                                Indicator = colFields[9].ToString().Trim();
                                AmountTransaction = Convert.ToDecimal(colFields[10].ToString().Trim());
                                AmountAdditional = Convert.ToDecimal(colFields[11].ToString().Trim());
                                SettlementTxnAmount = Convert.ToDecimal(colFields[12].ToString().Trim());
                                SettlementAddAmount = Convert.ToDecimal(colFields[13].ToString().Trim());
                                ApprovalCode = colFields[14].ToString().Trim();
                                OriginatorPoint = colFields[15].ToString().Trim();
                                POSEntryMode = colFields[16].ToString().Trim();
                                POSConditionCode = colFields[17].ToString().Trim();
                                AcquirerID = colFields[18].ToString().Trim();
                                AcquirerInstitutionID = colFields[19].ToString().Trim();
                                AcquirerNameandCountry = colFields[20].ToString().Trim();
                                IssuerID = colFields[21].ToString().Trim();
                                IssuerInstitutionID = colFields[22].ToString().Trim();
                                IssuerNameandCountry = colFields[23].ToString().Trim();
                                CardType = colFields[24].ToString().Trim();
                                CardBrand = colFields[25].ToString().Trim();
                                CardAcceptorTerminalID = colFields[26].ToString().Trim();
                                CardAcceptorTerminalID = CardAcceptorTerminalID.Replace("'", "");
                                CardAcceptorName = colFields[27].ToString().Trim();
                                CardAcceptoraddress = colFields[28].ToString().Trim();
                                CardAcceptorCountryCode = colFields[29].ToString().Trim();
                                CardAcceptorBusinessCode = colFields[30].ToString().Trim();
                                CardAcceptorIDCode = colFields[31].ToString().Trim();
                                CardAcceptorIDCode = CardAcceptorIDCode.Replace("'", "");
                                CardAcceptorStateName = colFields[32].ToString().Trim();
                                CardAcceptorCity = colFields[33].ToString().Trim();
                                DaysAged = colFields[34].ToString().Trim();
                                MTI = colFields[35].ToString().Trim();


                                _DataTable.Rows.Add(fileImportRequest.ClientCode, ReportDate, RaiseDate, SettlementDate, Description, PAN, Date, RRN, ProcessingCode, CurrencyCode, Indicator, AmountTransaction, AmountAdditional, SettlementTxnAmount, SettlementAddAmount, ApprovalCode, OriginatorPoint,
                                POSEntryMode, POSConditionCode, AcquirerID, AcquirerInstitutionID, AcquirerNameandCountry, IssuerID, IssuerInstitutionID, IssuerNameandCountry, CardType, CardBrand, CardAcceptorTerminalID, CardAcceptorName, CardAcceptoraddress, CardAcceptorCountryCode, CardAcceptorBusinessCode, CardAcceptorIDCode,
                                CardAcceptorStateName, CardAcceptorCity, DaysAged, MTI, fileImportRequest.UserName, DateTime.Now, fileImportRequest.UserName, DateTime.Now);
                                fileImportRequest.InsertCount++;
                                LineNo++;
                            }

                            catch (Exception ex)
                            {
                                ErrorCount++;
                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                            }
                        }

                        if (_DataTable.Rows.Count > 0)
                        {
                            MSG = bulkImports.PresentmentDataTable(_DataTable);
                        }
                        else
                        {
                            MSG = "Error occrued kindly check the log file for more details";
                        }
                    }
                    else
                    {
                        fileImportRequest.ErrorMessage = "File contains no records";
                        MSG = "Successful";
                    }
                }
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorCount++;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            List<BatchDetails> batchDetailsList = new List<BatchDetails>();

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = 1,
                BatchSize = 0,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }

        public string Splitter_POS_RefundLog(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DataTable _DataTable = new DataTable();
            int LineNo = 0, ErrorCount = 0;
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;

            string MSG = string.Empty;
            string batchStartTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

            //string m_RecordData = string.Empty;
            try
            {
                _DataTable.Columns.Add("ClientID", typeof(string));
                _DataTable.Columns.Add("SETTLEMENTDATE", typeof(DateTime));
                _DataTable.Columns.Add("DESCRIPTIONTYPE", typeof(string));
                _DataTable.Columns.Add("CARDNUMBER", typeof(string));
                _DataTable.Columns.Add("ACC_NUMBER", typeof(string));
                _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
                _DataTable.Columns.Add("TRANS_settlementDATE", typeof(DateTime));
                _DataTable.Columns.Add("TRANSACTIONAMT", typeof(double));
                _DataTable.Columns.Add("REFERENCENO", typeof(string));
                _DataTable.Columns.Add("POS_CODE", typeof(string));
                _DataTable.Columns.Add("CARDACCEP_NAME", typeof(string));
                _DataTable.Columns.Add("REFUNDAMT", typeof(string));
                _DataTable.Columns.Add("PartialIndicator", typeof(string));
                _DataTable.Columns.Add("DirectionDispute", typeof(string));

                _DataTable.Columns.Add("DisputeRaiseDate", typeof(DateTime));
                _DataTable.Columns.Add("CaseNumber", typeof(string));
                _DataTable.Columns.Add("FunctionCode", typeof(string));
                _DataTable.Columns.Add("ProcessingCode", typeof(string));
                _DataTable.Columns.Add("TransactionCurrencyCode", typeof(string));
                _DataTable.Columns.Add("SettlementAmount", typeof(decimal));
                _DataTable.Columns.Add("SettlementCurrencyCode", typeof(string));
                _DataTable.Columns.Add("TxnSettlement", typeof(string));
                _DataTable.Columns.Add("AmountsAdditional", typeof(decimal));
                _DataTable.Columns.Add("DisputeOrgPID", typeof(string));
                _DataTable.Columns.Add("DisputeDestPID", typeof(string));
                _DataTable.Columns.Add("ApprovalCode", typeof(string));
                _DataTable.Columns.Add("OriginatorPoint", typeof(string));
                _DataTable.Columns.Add("POSConditionCode", typeof(string));
                _DataTable.Columns.Add("AcqInstcode", typeof(string));
                _DataTable.Columns.Add("AcqNameandCountry", typeof(string));
                _DataTable.Columns.Add("IssuerInstIDcode", typeof(string));
                _DataTable.Columns.Add("IssuerNameandCountry", typeof(string));
                _DataTable.Columns.Add("CardType", typeof(string));
                _DataTable.Columns.Add("CardBrand", typeof(string));
                _DataTable.Columns.Add("CardAcceptorTerminalID", typeof(string));
                _DataTable.Columns.Add("CardAcceptorLocationAndaddress", typeof(string));
                _DataTable.Columns.Add("CardAcceptorCountryCode", typeof(string));
                _DataTable.Columns.Add("CardAcceptorBusinessCode", typeof(string));
                _DataTable.Columns.Add("DisputeReasoncode", typeof(string));
                _DataTable.Columns.Add("DisputeReasoncodedesc", typeof(string));
                _DataTable.Columns.Add("DisputeMemberMsgtxt", typeof(string));
                _DataTable.Columns.Add("DisputeDocIndicator", typeof(string));
                _DataTable.Columns.Add("DocumentAttachedDate", typeof(DateTime));
                _DataTable.Columns.Add("MTI", typeof(string));
                _DataTable.Columns.Add("IncentiveAmt", typeof(decimal));
                _DataTable.Columns.Add("TierCodenonfulfillment", typeof(string));
                _DataTable.Columns.Add("TierCodeofFulfillment", typeof(string));
                _DataTable.Columns.Add("Deadlinedate", typeof(DateTime));
                _DataTable.Columns.Add("DaysToact", typeof(string));
                _DataTable.Columns.Add("LastAdjStage", typeof(string));
                _DataTable.Columns.Add("LastAdjStage1", typeof(DateTime)); 

                string[] GLFieldData;
                //DateTime SETTLEMENTDATE1;
                DateTime? TRANS_settlementDATE = null;
                DateTime? TRANSACTIONDATE = null;
                string DESCRIPTIONTYPE = string.Empty; string CARDNUMBER = string.Empty;

                string ACC_NUMBER = string.Empty;
                string TRANSACTIONAMT = string.Empty; string REFERENCENO = string.Empty; string POS_CODE = string.Empty;
                string CARDACCEP_NAME = string.Empty; string REFUNDAMT = string.Empty; string PartialIndicator = string.Empty;
                string DirectionDispute = string.Empty; //string CREATEDON = string.Empty; string MODIFIEDON = string.Empty;
                // string sLine = string.Empty;

                DateTime? DisputeRaiseDate = null;
                string CaseNumber = string.Empty;
                string FunctionCode = string.Empty;
                string ProcessingCode = string.Empty;
                string TransactionCurrencyCode = string.Empty;
                decimal SettlementAmount = 0;
                string SettlementCurrencyCode = string.Empty;
                string TxnSettlement = string.Empty;
                decimal AmountsAdditional = 0;
                string DisputeOrgPID = string.Empty;
                string DisputeDestPID = string.Empty;
                string ApprovalCode = string.Empty;
                string OriginatorPoint = string.Empty;
                string POSConditionCode = string.Empty;
                string AcqInstcode = string.Empty;
                string AcqNameandCountry = string.Empty;
                string IssuerInstIDcode = string.Empty;
                string IssuerNameandCountry = string.Empty;
                string CardType = string.Empty;
                string CardBrand = string.Empty;
                string CardAcceptorTerminalID = string.Empty;
                string CardAcceptorLocationAndaddress = string.Empty;
                string CardAcceptorCountryCode = string.Empty;
                string CardAcceptorBusinessCode = string.Empty;
                string DisputeReasoncode = string.Empty;
                string DisputeReasoncodedesc = string.Empty;
                string DisputeMemberMsgtxt = string.Empty;
                string DisputeDocIndicator = string.Empty;
                DateTime? DocumentAttachedDate = null;
                string MTI = string.Empty;
                decimal? IncentiveAmt = 0;
                string TierCodenonfulfillment = string.Empty;
                string TierCodeofFulfillment = string.Empty;
                DateTime? Deadlinedate = null;
                string DaysToact = string.Empty;
                string LastAdjStage = string.Empty;
                DateTime? LastAdjStage1 = null;
                DateTime? _datetime = null;

                DtDetails DTdetails = new DtDetails();
                DTdetails = bulkImports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

                int i = 0;
                GLFieldData = File.ReadAllLines(fileImportRequest.Path, Encoding.Default);
                // int totalrecords = GLFieldData.Length;
                using (TextFieldParser csvReader = new TextFieldParser(fileImportRequest.Path))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();


                    string[] arrLines;

                    string sLine = string.Empty;
                    //int i = 0;
                    arrLines = File.ReadAllLines(fileImportRequest.Path, Encoding.Default);
                    int totalrecords = arrLines.Length - 1;

                    while (totalrecords > i)
                    {
                        try
                        {
                            LineNo++;
                            fileImportRequest.TotalCount++;
                            fileImportRequest.InsertCount++;


                            //string m_RecordData = GLFieldData[i];
                            GLFieldData = csvReader.ReadFields();
                            string FunctnCode = GLFieldData[5].ToString().Trim();
                            string timestamp = string.Empty;
                            //if (FunctnCode.Contains("Refund") || FunctnCode.Contains("Arbitration Acceptance") || FunctnCode.Contains("Credit Adjustment") || FunctnCode.Contains("Re-Presentment Raise")
                            //    || FunctnCode.Contains("Chargeback Raise") || FunctnCode.Contains("Presentment Reversal") || FunctnCode.Contains("470-Chargeback Acceptance") || FunctnCode.Contains("4Acceptance"))
                            //{
                            timestamp = GLFieldData[0].ToString().Trim();
                            _datetime = Convert.ToDateTime(timestamp);
                            //DateTime _datetime = DateTime.ParseExact(timestamp, "MM-dd-yyyy", CultureInfo.InvariantCulture);   
                            DESCRIPTIONTYPE = FunctnCode;
                            TRANS_settlementDATE = Convert.ToDateTime(GLFieldData[2].ToString().Trim());
                            CARDNUMBER = GLFieldData[6].ToString().Trim();
                            ACC_NUMBER = GLFieldData[15].ToString().Trim();
                            if (ACC_NUMBER == "")
                            {
                                ACC_NUMBER = " ";
                            }
                            else
                            {
                                ACC_NUMBER = ACC_NUMBER.Substring(1, 15).Trim();
                            }

                            if (FunctnCode.Contains("Tip & Surcharge Adjustment") || FunctnCode.Contains("Debit Adjustment"))
                            {
                                _datetime = Convert.ToDateTime(GLFieldData[0].ToString().Trim());
                                if (FunctnCode.Contains("Tip & Surcharge Adjustment"))
                                {
                                    DESCRIPTIONTYPE = "Tips/Scharge";
                                }
                                else
                                {
                                    DESCRIPTIONTYPE = "Debit Adjustment";
                                }
                            }

                            TRANS_settlementDATE = string.IsNullOrEmpty(Convert.ToString(GLFieldData[2])) || Convert.ToString(GLFieldData[2]).Equals("NULL") ? null : (DateTime?)Convert.ToDateTime(Convert.ToString(GLFieldData[2]));
                            CARDNUMBER = GLFieldData[6].ToString().Trim();
                            ACC_NUMBER = GLFieldData[15].ToString().Trim().Replace("'", "");
                            TRANSACTIONDATE = string.IsNullOrEmpty(Convert.ToString(GLFieldData[8])) || Convert.ToString(GLFieldData[8]).Equals("NULL") ? null : (DateTime?)Convert.ToDateTime(Convert.ToString(GLFieldData[8]));
                            REFERENCENO = GLFieldData[18].ToString().Replace("-", "").Trim();

                            try
                            {
                                if (REFERENCENO != "")
                                {
                                    REFERENCENO = REFERENCENO.Substring(25, 12).Trim();
                                    //REFERENCENO = REFERENCENO.Substring(25, 12).Trim();
                                }
                            }

                            catch (Exception ex)
                            {
                                REFERENCENO = REFERENCENO.Substring(25, 12).Trim();
                            }

                            POS_CODE = GLFieldData[21].ToString().Trim();
                            REFUNDAMT = GLFieldData[36].ToString().Trim();
                            PartialIndicator = GLFieldData[37].ToString().Trim();
                            DirectionDispute = GLFieldData[47].ToString().Trim();
                            CARDACCEP_NAME = GLFieldData[30].ToString().Trim();
                            TRANSACTIONAMT = GLFieldData[9].ToString().Trim();
                            // SETTLEMENTDATE11112,TRANSACTIONDATE,TRANS_settlementDATE
                            DisputeRaiseDate = Convert.ToDateTime(GLFieldData[1].ToString().Trim());
                            CaseNumber = GLFieldData[3].ToString().Trim();
                            FunctionCode = GLFieldData[4].ToString().Trim();
                            ProcessingCode = GLFieldData[7].ToString().Trim();
                            TransactionCurrencyCode = GLFieldData[10].ToString().Trim();
                            SettlementAmount = Convert.ToDecimal(GLFieldData[11].ToString().Trim());
                            SettlementCurrencyCode = GLFieldData[12].ToString().Trim();
                            TxnSettlement = GLFieldData[13].ToString().Trim();
                            AmountsAdditional = Convert.ToDecimal(GLFieldData[14].ToString().Trim());
                            DisputeOrgPID = GLFieldData[16].ToString().Trim();
                            DisputeDestPID = GLFieldData[17].ToString().Trim();
                            ApprovalCode = GLFieldData[19].ToString().Trim();
                            OriginatorPoint = GLFieldData[20].ToString().Trim();
                            POSConditionCode = GLFieldData[22].ToString().Trim();
                            AcqInstcode = GLFieldData[23].ToString().Trim();
                            AcqNameandCountry = GLFieldData[24].ToString().Trim();
                            IssuerInstIDcode = GLFieldData[25].ToString().Trim();
                            IssuerNameandCountry = GLFieldData[26].ToString().Trim();
                            CardType = GLFieldData[27].ToString().Trim();
                            CardBrand = GLFieldData[28].ToString().Trim();
                            CardAcceptorTerminalID = GLFieldData[29].ToString().Trim();
                            CardAcceptorLocationAndaddress = GLFieldData[31].ToString().Trim();
                            CardAcceptorCountryCode = GLFieldData[32].ToString().Trim();
                            CardAcceptorBusinessCode = GLFieldData[33].ToString().Trim();
                            DisputeReasoncode = GLFieldData[34].ToString().Trim();
                            DisputeReasoncodedesc = GLFieldData[35].ToString().Trim();
                            DisputeMemberMsgtxt = GLFieldData[38].ToString().Trim();
                            DisputeDocIndicator = GLFieldData[39].ToString().Trim();
                            DocumentAttachedDate = string.IsNullOrEmpty(Convert.ToString(GLFieldData[40])) || Convert.ToString(GLFieldData[40]).Equals("NULL") ? null : (DateTime?)Convert.ToDateTime(Convert.ToString(GLFieldData[40]));
                            // DocumentAttachedDate = Convert.ToDateTime(GLFieldData[40].ToString().Trim());
                            MTI = GLFieldData[41].ToString().Trim();
                            //IncentiveAmt = Convert.ToDecimal(GLFieldData[42].ToString().Trim());
                            IncentiveAmt = string.IsNullOrEmpty(Convert.ToString(GLFieldData[42])) || Convert.ToString(GLFieldData[42]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(GLFieldData[42]));
                            TierCodenonfulfillment = GLFieldData[43].ToString().Trim();
                            TierCodeofFulfillment = GLFieldData[44].ToString().Trim();
                            Deadlinedate = string.IsNullOrEmpty(Convert.ToString(GLFieldData[45])) || Convert.ToString(GLFieldData[45]).Equals("NULL") ? null : (DateTime?)Convert.ToDateTime(Convert.ToString(GLFieldData[45]));
                            //Convert.ToDateTime(GLFieldData[45].ToString().Trim());
                            DaysToact = GLFieldData[46].ToString().Trim();
                            LastAdjStage = GLFieldData[48].ToString().Trim();

                            if (GLFieldData[49].ToString().Trim() != "" || GLFieldData[49].ToString().Trim() != null)
                            {
                                LastAdjStage1 = Convert.ToDateTime(GLFieldData[49].ToString().Trim());
                            }
                            else
                            {
                                LastAdjStage1 = null;
                            }


                            _DataTable.Rows.Add(
                                               fileImportRequest.ClientCode,
                                                _datetime,
                                                DESCRIPTIONTYPE,
                                               CARDNUMBER,
                                               ACC_NUMBER,
                                               TRANSACTIONDATE,
                                               TRANS_settlementDATE,
                                               TRANSACTIONAMT,
                                               REFERENCENO,
                                               POS_CODE,
                                               CARDACCEP_NAME,
                                               REFUNDAMT,
                                               PartialIndicator,
                                               DirectionDispute,
                                               DisputeRaiseDate,
                                               CaseNumber,
                                               FunctionCode,
                                               ProcessingCode,
                                               TransactionCurrencyCode,
                                               SettlementAmount,
                                               SettlementCurrencyCode,
                                               TxnSettlement,
                                               AmountsAdditional,
                                               DisputeOrgPID,
                                               DisputeDestPID,
                                               ApprovalCode,
                                               OriginatorPoint,
                                               POSConditionCode,
                                               AcqInstcode,
                                               AcqNameandCountry,
                                               IssuerInstIDcode,
                                               IssuerNameandCountry,
                                               CardType,
                                               CardBrand,
                                               CardAcceptorTerminalID,
                                               CardAcceptorLocationAndaddress,
                                               CardAcceptorCountryCode,
                                               CardAcceptorBusinessCode,
                                               DisputeReasoncode,
                                               DisputeReasoncodedesc,
                                               DisputeMemberMsgtxt,
                                               DisputeDocIndicator,
                                               DocumentAttachedDate,
                                               MTI,
                                               IncentiveAmt,
                                               TierCodenonfulfillment,
                                               TierCodeofFulfillment,
                                               Deadlinedate,
                                               DaysToact,
                                               LastAdjStage,
                                               LastAdjStage1 
                                               );
                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                        }

                        i = i + 1;

                    }
                }

                if (_DataTable.Rows.Count == 0)
                {
                    MSG = "Error occrued kindly check the log file for more details";
                    fileImportRequest.ErrorMessage = MSG;
                    DBLog.InsertLogs("Record Not found", fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);

                }
                else 
                {
                    MSG = bulkImports.BulkInsertRefundlogs(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                    fileImportRequest.ErrorMessage = MSG;
                    fileImportRequest.InsertCount = _DataTable.Rows.Count;
                    fileImportRequest.TotalCount = _DataTable.Rows.Count; 
                }

                List<BatchDetails> batchDetailsList = new List<BatchDetails>();

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = 1,
                    BatchSize = 0,
                    TxnUploadCount = fileImportRequest.TotalCount,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                _DataTable = null;

                fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

                fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);

            }

            return MSG;
        }


        public DataTable ESAF_RefundLog(string FilePath, string FileName, string UserName, string ClientCode, DataTable dt, out int InsertCount, out int TotalCount)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DataTable _DataTable = new DataTable();
            int LineNo = 0, ErrorCount = 0;
            InsertCount = 0;
            TotalCount = 0;
            //string m_RecordData = string.Empty;
            try
            {
                _DataTable.Columns.Add("ClientID", typeof(string));
                _DataTable.Columns.Add("SETTLEMENTDATE", typeof(DateTime));
                _DataTable.Columns.Add("DESCRIPTIONTYPE", typeof(string));
                _DataTable.Columns.Add("CARDNUMBER", typeof(string));
                _DataTable.Columns.Add("ACC_NUMBER", typeof(string));
                _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
                _DataTable.Columns.Add("TRANS_settlementDATE", typeof(DateTime));
                _DataTable.Columns.Add("TRANSACTIONAMT", typeof(double));
                _DataTable.Columns.Add("REFERENCENO", typeof(string));
                _DataTable.Columns.Add("POS_CODE", typeof(string));
                _DataTable.Columns.Add("CARDACCEP_NAME", typeof(string));
                _DataTable.Columns.Add("REFUNDAMT", typeof(string));
                _DataTable.Columns.Add("PartialIndicator", typeof(string));
                _DataTable.Columns.Add("DirectionDispute", typeof(string));
             
                _DataTable.Columns.Add("DisputeRaiseDate", typeof(DateTime));
                _DataTable.Columns.Add("CaseNumber", typeof(string));
                _DataTable.Columns.Add("FunctionCode", typeof(string));
                _DataTable.Columns.Add("ProcessingCode", typeof(string));
                _DataTable.Columns.Add("TransactionCurrencyCode", typeof(string));
                _DataTable.Columns.Add("SettlementAmount", typeof(decimal));
                _DataTable.Columns.Add("SettlementCurrencyCode", typeof(string));
                _DataTable.Columns.Add("TxnSettlement", typeof(string));
                _DataTable.Columns.Add("AmountsAdditional", typeof(decimal));
                _DataTable.Columns.Add("DisputeOrgPID", typeof(string));
                _DataTable.Columns.Add("DisputeDestPID", typeof(string));
                _DataTable.Columns.Add("ApprovalCode", typeof(string));
                _DataTable.Columns.Add("OriginatorPoint", typeof(string));
                _DataTable.Columns.Add("POSConditionCode", typeof(string));
                _DataTable.Columns.Add("AcqInstcode", typeof(string));
                _DataTable.Columns.Add("AcqNameandCountry", typeof(string));
                _DataTable.Columns.Add("IssuerInstIDcode", typeof(string));
                _DataTable.Columns.Add("IssuerNameandCountry", typeof(string));
                _DataTable.Columns.Add("CardType", typeof(string));
                _DataTable.Columns.Add("CardBrand", typeof(string));
                _DataTable.Columns.Add("CardAcceptorTerminalID", typeof(string));
                _DataTable.Columns.Add("CardAcceptorLocationAndaddress", typeof(string));
                _DataTable.Columns.Add("CardAcceptorCountryCode", typeof(string));
                _DataTable.Columns.Add("CardAcceptorBusinessCode", typeof(string));
                _DataTable.Columns.Add("DisputeReasoncode", typeof(string));
                _DataTable.Columns.Add("DisputeReasoncodedesc", typeof(string));
                _DataTable.Columns.Add("DisputeMemberMsgtxt", typeof(string));
                _DataTable.Columns.Add("DisputeDocIndicator", typeof(string));
                _DataTable.Columns.Add("DocumentAttachedDate", typeof(DateTime));
                _DataTable.Columns.Add("MTI", typeof(string));
                _DataTable.Columns.Add("IncentiveAmt", typeof(decimal));
                _DataTable.Columns.Add("TierCodenonfulfillment", typeof(string));
                _DataTable.Columns.Add("TierCodeofFulfillment", typeof(string));
                _DataTable.Columns.Add("Deadlinedate", typeof(DateTime));
                _DataTable.Columns.Add("DaysToact", typeof(string));
                _DataTable.Columns.Add("LastAdjStage", typeof(string));
                _DataTable.Columns.Add("LastAdjStage1", typeof(DateTime));

                _DataTable.Columns.Add("FileName", typeof(string));
                _DataTable.Columns.Add("FilePath", typeof(string));
                _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
                _DataTable.Columns.Add("CREATEDBY", typeof(string));
                _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
                _DataTable.Columns.Add("MODIFIEDBY", typeof(string));

                string[] GLFieldData;
                //DateTime SETTLEMENTDATE1;
                DateTime? TRANS_settlementDATE = null;
                DateTime? TRANSACTIONDATE = null;
                string DESCRIPTIONTYPE = string.Empty; string CARDNUMBER = string.Empty;

                string ACC_NUMBER = string.Empty;
                string TRANSACTIONAMT = string.Empty; string REFERENCENO = string.Empty; string POS_CODE = string.Empty;
                string CARDACCEP_NAME = string.Empty; string REFUNDAMT = string.Empty; string PartialIndicator = string.Empty;
                string DirectionDispute = string.Empty; //string CREATEDON = string.Empty; string MODIFIEDON = string.Empty;
                // string sLine = string.Empty;

                DateTime? DisputeRaiseDate = null;
                string CaseNumber = string.Empty;
                string FunctionCode = string.Empty;
                string ProcessingCode = string.Empty;
                string TransactionCurrencyCode = string.Empty;
                decimal SettlementAmount = 0;
                string SettlementCurrencyCode = string.Empty;
                string TxnSettlement = string.Empty;
                decimal AmountsAdditional = 0;
                string DisputeOrgPID = string.Empty;
                string DisputeDestPID = string.Empty;
                string ApprovalCode = string.Empty;
                string OriginatorPoint = string.Empty;
                string POSConditionCode = string.Empty;
                string AcqInstcode = string.Empty;
                string AcqNameandCountry = string.Empty;
                string IssuerInstIDcode = string.Empty;
                string IssuerNameandCountry = string.Empty;
                string CardType = string.Empty;
                string CardBrand = string.Empty;
                string CardAcceptorTerminalID = string.Empty;
                string CardAcceptorLocationAndaddress = string.Empty;
                string CardAcceptorCountryCode = string.Empty;
                string CardAcceptorBusinessCode = string.Empty;
                string DisputeReasoncode = string.Empty;
                string DisputeReasoncodedesc = string.Empty;
                string DisputeMemberMsgtxt = string.Empty;
                string DisputeDocIndicator = string.Empty;
                DateTime? DocumentAttachedDate = null;
                string MTI = string.Empty;
                decimal? IncentiveAmt = 0;
                string TierCodenonfulfillment = string.Empty;
                string TierCodeofFulfillment = string.Empty;
                DateTime? Deadlinedate = null;
                string DaysToact = string.Empty;
                string LastAdjStage = string.Empty;
                DateTime? LastAdjStage1 = null;
                DateTime? _datetime = null;

                int i = 0;
                GLFieldData = File.ReadAllLines(FilePath, Encoding.Default);
                // int totalrecords = GLFieldData.Length;
                using (TextFieldParser csvReader = new TextFieldParser(FilePath))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields(); 


                    string[] arrLines;

                    string sLine = string.Empty;
                    //int i = 0;
                    arrLines = File.ReadAllLines(FilePath, Encoding.Default);
                    int totalrecords = arrLines.Length-1;

                    while (totalrecords > i)
                    {
                        try
                        { 
                            LineNo++;
                            TotalCount++;
                            InsertCount++;
                             

                            //string m_RecordData = GLFieldData[i];
                            GLFieldData = csvReader.ReadFields();
                            string FunctnCode = GLFieldData[5].ToString().Trim();
                            string timestamp = string.Empty;
                            //if (FunctnCode.Contains("Refund") || FunctnCode.Contains("Arbitration Acceptance") || FunctnCode.Contains("Credit Adjustment") || FunctnCode.Contains("Re-Presentment Raise")
                            //    || FunctnCode.Contains("Chargeback Raise") || FunctnCode.Contains("Presentment Reversal") || FunctnCode.Contains("470-Chargeback Acceptance") || FunctnCode.Contains("4Acceptance"))
                            //{
                            timestamp = GLFieldData[0].ToString().Trim();
                            _datetime = Convert.ToDateTime(timestamp);
                            //DateTime _datetime = DateTime.ParseExact(timestamp, "MM-dd-yyyy", CultureInfo.InvariantCulture);   
                            DESCRIPTIONTYPE = FunctnCode;
                            TRANS_settlementDATE = Convert.ToDateTime(GLFieldData[2].ToString().Trim());
                            CARDNUMBER = GLFieldData[6].ToString().Trim();
                            ACC_NUMBER = GLFieldData[15].ToString().Trim();
                            if (ACC_NUMBER == "")
                            {
                                ACC_NUMBER = " ";
                            }
                            else
                            {
                                ACC_NUMBER = ACC_NUMBER.Substring(1, 15).Trim();
                            }
                           
                            if (FunctnCode.Contains("Tip & Surcharge Adjustment") || FunctnCode.Contains("Debit Adjustment"))
                            {
                                _datetime = Convert.ToDateTime(GLFieldData[0].ToString().Trim());
                                if (FunctnCode.Contains("Tip & Surcharge Adjustment"))
                                {
                                    DESCRIPTIONTYPE = "Tips/Scharge";
                                }
                                else
                                {
                                    DESCRIPTIONTYPE = "Debit Adjustment";
                                }
                            }

                            TRANS_settlementDATE = string.IsNullOrEmpty(Convert.ToString(GLFieldData[2])) || Convert.ToString(GLFieldData[2]).Equals("NULL") ? null : (DateTime?)Convert.ToDateTime(Convert.ToString(GLFieldData[2]));
                            CARDNUMBER = GLFieldData[6].ToString().Trim();
                            ACC_NUMBER = GLFieldData[15].ToString().Trim().Replace("'", "");
                            TRANSACTIONDATE = string.IsNullOrEmpty(Convert.ToString(GLFieldData[8])) || Convert.ToString(GLFieldData[8]).Equals("NULL") ? null : (DateTime?)Convert.ToDateTime(Convert.ToString(GLFieldData[8]));
                            REFERENCENO = GLFieldData[18].ToString().Replace("-", "").Trim();

                            try
                            {
                                if (REFERENCENO != "")
                                {
                                    REFERENCENO = REFERENCENO.Substring(25, 12).Trim();
                                    //REFERENCENO = REFERENCENO.Substring(25, 12).Trim();
                                }
                            }

                            catch (Exception ex)
                            {
                                REFERENCENO = REFERENCENO.Substring(25, 12).Trim();
                            }

                            POS_CODE = GLFieldData[21].ToString().Trim();
                            REFUNDAMT = GLFieldData[36].ToString().Trim();
                            PartialIndicator = GLFieldData[37].ToString().Trim();
                            DirectionDispute = GLFieldData[47].ToString().Trim();
                            CARDACCEP_NAME = GLFieldData[30].ToString().Trim();
                            TRANSACTIONAMT = GLFieldData[9].ToString().Trim();
                            // SETTLEMENTDATE11112,TRANSACTIONDATE,TRANS_settlementDATE
                            DisputeRaiseDate = Convert.ToDateTime(GLFieldData[1].ToString().Trim());
                            CaseNumber = GLFieldData[3].ToString().Trim();
                            FunctionCode = GLFieldData[4].ToString().Trim();
                            ProcessingCode = GLFieldData[7].ToString().Trim();
                            TransactionCurrencyCode = GLFieldData[10].ToString().Trim();
                            SettlementAmount = Convert.ToDecimal(GLFieldData[11].ToString().Trim());
                            SettlementCurrencyCode = GLFieldData[12].ToString().Trim();
                            TxnSettlement = GLFieldData[13].ToString().Trim();
                            AmountsAdditional = Convert.ToDecimal(GLFieldData[14].ToString().Trim());
                            DisputeOrgPID = GLFieldData[16].ToString().Trim();
                            DisputeDestPID = GLFieldData[17].ToString().Trim();
                            ApprovalCode = GLFieldData[19].ToString().Trim();
                            OriginatorPoint = GLFieldData[20].ToString().Trim();
                            POSConditionCode = GLFieldData[22].ToString().Trim();
                            AcqInstcode = GLFieldData[23].ToString().Trim();
                            AcqNameandCountry = GLFieldData[24].ToString().Trim();
                            IssuerInstIDcode = GLFieldData[25].ToString().Trim();
                            IssuerNameandCountry = GLFieldData[26].ToString().Trim();
                            CardType = GLFieldData[27].ToString().Trim();
                            CardBrand = GLFieldData[28].ToString().Trim();
                            CardAcceptorTerminalID = GLFieldData[29].ToString().Trim();
                            CardAcceptorLocationAndaddress = GLFieldData[31].ToString().Trim();
                            CardAcceptorCountryCode = GLFieldData[32].ToString().Trim();
                            CardAcceptorBusinessCode = GLFieldData[33].ToString().Trim();
                            DisputeReasoncode = GLFieldData[34].ToString().Trim();
                            DisputeReasoncodedesc = GLFieldData[35].ToString().Trim();
                            DisputeMemberMsgtxt = GLFieldData[38].ToString().Trim();
                            DisputeDocIndicator = GLFieldData[39].ToString().Trim();
                            DocumentAttachedDate = string.IsNullOrEmpty(Convert.ToString(GLFieldData[40])) || Convert.ToString(GLFieldData[40]).Equals("NULL") ? null : (DateTime?)Convert.ToDateTime(Convert.ToString(GLFieldData[40]));
                            // DocumentAttachedDate = Convert.ToDateTime(GLFieldData[40].ToString().Trim());
                            MTI = GLFieldData[41].ToString().Trim();
                            //IncentiveAmt = Convert.ToDecimal(GLFieldData[42].ToString().Trim());
                            IncentiveAmt = string.IsNullOrEmpty(Convert.ToString(GLFieldData[42])) || Convert.ToString(GLFieldData[42]).Equals("NULL") ? null : (Decimal?)Convert.ToDecimal(Convert.ToString(GLFieldData[42]));
                            TierCodenonfulfillment = GLFieldData[43].ToString().Trim();
                            TierCodeofFulfillment = GLFieldData[44].ToString().Trim();
                            Deadlinedate = string.IsNullOrEmpty(Convert.ToString(GLFieldData[45])) || Convert.ToString(GLFieldData[45]).Equals("NULL") ? null : (DateTime?)Convert.ToDateTime(Convert.ToString(GLFieldData[45]));
                            //Convert.ToDateTime(GLFieldData[45].ToString().Trim());
                            DaysToact = GLFieldData[46].ToString().Trim();
                            LastAdjStage = GLFieldData[48].ToString().Trim();

                            if (GLFieldData[49].ToString().Trim() != "" || GLFieldData[49].ToString().Trim() != null)
                            {
                                LastAdjStage1 = Convert.ToDateTime(GLFieldData[49].ToString().Trim());
                            }
                            else
                            {
                                LastAdjStage1 = null;
                            }


                            _DataTable.Rows.Add(
                                                ClientCode,
                                                _datetime,
                                                DESCRIPTIONTYPE,
                                               CARDNUMBER,
                                               ACC_NUMBER,
                                               TRANSACTIONDATE,
                                               TRANS_settlementDATE,
                                               TRANSACTIONAMT,
                                               REFERENCENO,
                                               POS_CODE,
                                               CARDACCEP_NAME,
                                               REFUNDAMT,
                                               PartialIndicator,
                                               DirectionDispute, 
                                               DisputeRaiseDate,
                                               CaseNumber,
                                               FunctionCode,
                                               ProcessingCode,
                                               TransactionCurrencyCode,
                                               SettlementAmount,
                                               SettlementCurrencyCode,
                                               TxnSettlement,
                                               AmountsAdditional,
                                               DisputeOrgPID,
                                               DisputeDestPID,
                                               ApprovalCode,
                                               OriginatorPoint,
                                               POSConditionCode,
                                               AcqInstcode,
                                               AcqNameandCountry,
                                               IssuerInstIDcode,
                                               IssuerNameandCountry,
                                               CardType,
                                               CardBrand,
                                               CardAcceptorTerminalID,
                                               CardAcceptorLocationAndaddress,
                                               CardAcceptorCountryCode,
                                               CardAcceptorBusinessCode,
                                               DisputeReasoncode,
                                               DisputeReasoncodedesc,
                                               DisputeMemberMsgtxt,
                                               DisputeDocIndicator,
                                               DocumentAttachedDate,
                                               MTI,
                                               IncentiveAmt,
                                               TierCodenonfulfillment,
                                               TierCodeofFulfillment,
                                               Deadlinedate,
                                               DaysToact,
                                               LastAdjStage,
                                               LastAdjStage1,
                                               FileName,
                                               FilePath,
                                               System.DateTime.Now,
                                               UserName,
                                               null,
                                               null
                                               ); 
                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                        }

                        i = i + 1;

                    }
                }
                if (_DataTable.Rows.Count == 0)
                {
                    DBLog.InsertLogs("Record Not found", ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

            }

            return _DataTable;
        }

        public DataTable RefundLog(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("SETTLEMENTDATE", typeof(DateTime));
            _DataTable.Columns.Add("DESCRIPTIONTYPE", typeof(string));
            _DataTable.Columns.Add("CARDNUMBER", typeof(string));
            _DataTable.Columns.Add("ACC_NUMBER", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANS_settlementDATE", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONAMT", typeof(double));
            _DataTable.Columns.Add("REFERENCENO", typeof(string));
            _DataTable.Columns.Add("POS_CODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEP_NAME", typeof(string));
            _DataTable.Columns.Add("REFUNDAMT", typeof(string));
            _DataTable.Columns.Add("PartialIndicator", typeof(string));
            _DataTable.Columns.Add("DirectionDispute", typeof(string));
            _DataTable.Columns.Add("CREATEDON", typeof(DateTime));
            _DataTable.Columns.Add("MODIFIEDON", typeof(DateTime));
            _DataTable.Columns.Add("CREATEDBY", typeof(string));
            _DataTable.Columns.Add("MODIFIEDBY", typeof(string));
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;

            try
            {

                string[] GLFieldData;

                DateTime TRANS_settlementDATE;
                DateTime TRANSACTIONDATE;
                string DESCRIPTIONTYPE = string.Empty; string CARDNUMBER = string.Empty;

                string ACC_NUMBER = string.Empty;
                string TRANSACTIONAMT = string.Empty; string REFERENCENO = string.Empty; string POS_CODE = string.Empty;
                string CARDACCEP_NAME = string.Empty; string REFUNDAMT = string.Empty; string PartialIndicator = string.Empty;
                string DirectionDispute = string.Empty;

                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
                string[] TotalCountArray = File.ReadAllLines(path);
                TotalCount = TotalCountArray.Length;

                int i = 0;
                GLFieldData = File.ReadAllLines(path, Encoding.Default);

                using (TextFieldParser csvReader = new TextFieldParser(path))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();

                    string[] arrLines;

                    string sLine = string.Empty;

                    arrLines = File.ReadAllLines(path, Encoding.Default);
                    int totalrecords = arrLines.Length;

                    while (totalrecords > i)
                    {
                        try
                        {
                            LineNo++;
                            TotalCount++;
                            InsertCount++;



                            GLFieldData = csvReader.ReadFields();
                            string FunctnCode = GLFieldData[5].ToString().Trim();
                            DateTime SETTLEMENTDATE111;
                            DateTime SETTLEMENTDATE11112;
                            string timestamp = string.Empty;
                            //if (FunctnCode.Contains("Refund"))
                            if (FunctnCode.Contains("Refund") || FunctnCode.Contains("267-Auth Cancellation Request") || FunctnCode.Contains("Arbitration Acceptance") || FunctnCode.Contains("Credit Adjustment") || FunctnCode.Contains("Re-Presentment Raise"))
                            {
                                timestamp = GLFieldData[0].ToString().Trim();

                                DateTime _datetime = Convert.ToDateTime(timestamp);

                                DESCRIPTIONTYPE = GLFieldData[5].ToString().Trim();
                                TRANS_settlementDATE = Convert.ToDateTime(GLFieldData[2].ToString().Trim());
                                CARDNUMBER = GLFieldData[6].ToString().Trim();
                                ACC_NUMBER = GLFieldData[15].ToString().Trim();
                                if (ACC_NUMBER != "")
                                {
                                    ACC_NUMBER = ACC_NUMBER.Substring(1, 15).Trim();
                                }

                                else
                                {
                                    ACC_NUMBER = "";
                                }


                                TRANSACTIONDATE = Convert.ToDateTime(GLFieldData[8].ToString().Trim());

                                REFERENCENO = GLFieldData[18].ToString().Trim();
                                REFERENCENO = REFERENCENO.Substring(26, 12).Trim();

                                POS_CODE = GLFieldData[21].ToString().Trim();
                                REFUNDAMT = GLFieldData[36].ToString().Trim();
                                PartialIndicator = GLFieldData[37].ToString().Trim();
                                DirectionDispute = GLFieldData[47].ToString().Trim();
                                CARDACCEP_NAME = GLFieldData[30].ToString().Trim();
                                TRANSACTIONAMT = GLFieldData[9].ToString().Trim();


                                _DataTable.Rows.Add(ClientID, _datetime, DESCRIPTIONTYPE, CARDNUMBER, ACC_NUMBER, TRANSACTIONDATE, TRANS_settlementDATE, TRANSACTIONAMT, REFERENCENO,
                                           POS_CODE, CARDACCEP_NAME, REFUNDAMT, PartialIndicator, DirectionDispute
                                         , System.DateTime.Now, System.DateTime.Now, UserName, UserName);

                            }
                            //if (FunctnCode.Contains("Bulk NPCI Fee Disbursement"))
                            //{
                            //    timestamp = GLFieldData[0].ToString().Trim();

                            //    DateTime _datetime = Convert.ToDateTime(timestamp);

                            //    DESCRIPTIONTYPE = GLFieldData[5].ToString().Trim();
                            //    TRANS_settlementDATE = Convert.ToDateTime(GLFieldData[2].ToString().Trim());
                            //    CARDNUMBER = GLFieldData[6].ToString().Trim();
                            //    //ACC_NUMBER = GLFieldData[15].ToString().Trim();
                            //    //ACC_NUMBER = ACC_NUMBER.Substring(1, 15).Trim();
                            //    //TRANSACTIONDATE = Convert.ToDateTime(GLFieldData[8].ToString().Trim());

                            //    REFERENCENO = GLFieldData[18].ToString().Trim();
                            //    //REFERENCENO = REFERENCENO.Substring(26, 12).Trim();

                            //    POS_CODE = GLFieldData[21].ToString().Trim();
                            //    REFUNDAMT = GLFieldData[36].ToString().Trim();
                            //    PartialIndicator = GLFieldData[37].ToString().Trim();
                            //    DirectionDispute = GLFieldData[47].ToString().Trim();
                            //    CARDACCEP_NAME = GLFieldData[30].ToString().Trim();
                            //    TRANSACTIONAMT = GLFieldData[9].ToString().Trim();


                            //    _DataTable.Rows.Add(ClientID, _datetime, DESCRIPTIONTYPE, CARDNUMBER, ' ', null, TRANS_settlementDATE, TRANSACTIONAMT, REFERENCENO,
                            //               POS_CODE, CARDACCEP_NAME, REFUNDAMT, PartialIndicator, DirectionDispute
                            //             , System.DateTime.Now, System.DateTime.Now, UserName, UserName);

                            //}

                            if (FunctnCode.Contains("Credit Adjustment"))
                            {
                                timestamp = GLFieldData[0].ToString().Trim();

                                DateTime _datetime = Convert.ToDateTime(timestamp);

                                DESCRIPTIONTYPE = GLFieldData[5].ToString().Trim();
                                TRANS_settlementDATE = Convert.ToDateTime(GLFieldData[2].ToString().Trim());
                                CARDNUMBER = GLFieldData[6].ToString().Trim();

                                TRANSACTIONDATE = Convert.ToDateTime(GLFieldData[8].ToString().Trim());
                                REFERENCENO = GLFieldData[18].ToString().Trim();
                                REFERENCENO = REFERENCENO.Substring(26, 12).Trim();

                                POS_CODE = GLFieldData[21].ToString().Trim();
                                REFUNDAMT = GLFieldData[36].ToString().Trim();
                                PartialIndicator = GLFieldData[37].ToString().Trim();
                                DirectionDispute = GLFieldData[47].ToString().Trim();
                                CARDACCEP_NAME = GLFieldData[30].ToString().Trim();
                                TRANSACTIONAMT = GLFieldData[9].ToString().Trim();


                                _DataTable.Rows.Add(ClientID, _datetime, DESCRIPTIONTYPE, CARDNUMBER, ACC_NUMBER, TRANSACTIONDATE, TRANS_settlementDATE, TRANSACTIONAMT, REFERENCENO,
                                           POS_CODE, CARDACCEP_NAME, REFUNDAMT, PartialIndicator, DirectionDispute
                                         , System.DateTime.Now, System.DateTime.Now, UserName, UserName);

                            }
                            if (FunctnCode.Contains("Tip & Surcharge Adjustment"))
                            {
                                SETTLEMENTDATE11112 = Convert.ToDateTime(GLFieldData[0].ToString().Trim());
                                DESCRIPTIONTYPE = "Tips/Scharge";
                                TRANS_settlementDATE = Convert.ToDateTime(GLFieldData[2].ToString().Trim());
                                CARDNUMBER = GLFieldData[6].ToString().Trim();
                                ACC_NUMBER = GLFieldData[15].ToString().Trim();
                                TRANSACTIONDATE = Convert.ToDateTime(GLFieldData[8].ToString().Trim());
                                REFERENCENO = GLFieldData[18].ToString().Trim();
                                REFERENCENO = REFERENCENO.Substring(26, 12).Trim();
                                POS_CODE = GLFieldData[21].ToString().Trim();
                                REFUNDAMT = GLFieldData[36].ToString().Trim();
                                PartialIndicator = GLFieldData[37].ToString().Trim();
                                DirectionDispute = GLFieldData[47].ToString().Trim();
                                CARDACCEP_NAME = GLFieldData[30].ToString().Trim();
                                TRANSACTIONAMT = GLFieldData[9].ToString().Trim();

                                _DataTable.Rows.Add(ClientID, SETTLEMENTDATE11112, DESCRIPTIONTYPE, CARDNUMBER, ACC_NUMBER, TRANSACTIONDATE, TRANS_settlementDATE, TRANSACTIONAMT, REFERENCENO,
                                           POS_CODE, CARDACCEP_NAME, REFUNDAMT, PartialIndicator, DirectionDispute
                                         , System.DateTime.Now, System.DateTime.Now, UserName, UserName);

                            }
                            if (FunctnCode.Contains("760-Bulk NPCI Fee Collection") || FunctnCode.Contains("761-Bulk NPCI Fee Disbursement")
                                || FunctnCode.Contains("450-Chargeback Raise"))
                            {
                                timestamp = GLFieldData[0].ToString().Trim();

                                DateTime _datetime = Convert.ToDateTime(timestamp);

                                DESCRIPTIONTYPE = GLFieldData[5].ToString().Trim();
                                TRANS_settlementDATE = Convert.ToDateTime(GLFieldData[2].ToString().Trim());
                                CARDNUMBER = GLFieldData[6].ToString().Trim();
                                //ACC_NUMBER = GLFieldData[15].ToString().Trim();
                                //ACC_NUMBER = ACC_NUMBER.Substring(1, 15).Trim();
                                //TRANSACTIONDATE = Convert.ToDateTime(GLFieldData[8].ToString().Trim());

                                REFERENCENO = GLFieldData[18].ToString().Trim();
                                //REFERENCENO = REFERENCENO.Substring(26, 12).Trim();

                                POS_CODE = GLFieldData[21].ToString().Trim();
                                REFUNDAMT = GLFieldData[36].ToString().Trim();
                                PartialIndicator = GLFieldData[37].ToString().Trim();
                                DirectionDispute = GLFieldData[47].ToString().Trim();
                                CARDACCEP_NAME = GLFieldData[30].ToString().Trim();
                                TRANSACTIONAMT = GLFieldData[9].ToString().Trim();


                                _DataTable.Rows.Add(ClientID, _datetime, DESCRIPTIONTYPE, CARDNUMBER, ' ', null, TRANS_settlementDATE, TRANSACTIONAMT, REFERENCENO,
                                           POS_CODE, CARDACCEP_NAME, REFUNDAMT, PartialIndicator, DirectionDispute
                                         , System.DateTime.Now, System.DateTime.Now, UserName, UserName);

                            }


                        }

                        catch(Exception ex)
                        {
                            DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }

                        i = i + 1;

                    }


                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;


                }

            }

            catch(Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

            }
            //LineError = ErrorLine;
            //(LineNo - _DataTable.Rows.Count );
            return _DataTable;
        }

         
        public string Splitter_POS_Issuer_Text_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            bool ErrorOccurred = false;
            fileImportRequest.ErrorMessage = string.Empty;
            int LineNumber = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkImports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("MessageType", typeof(string));
            _DataTable.Columns.Add("ProductID", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("FromAccountType", typeof(string));
            _DataTable.Columns.Add("ToAccountType", typeof(string));
            _DataTable.Columns.Add("ActionCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("ApprovalNumber", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("MerchantCategoryCode", typeof(string));
            _DataTable.Columns.Add("CardAcceptorID", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("TerminalLocation", typeof(string));
            _DataTable.Columns.Add("AcquirerID", typeof(string));
            _DataTable.Columns.Add("TxnsCCYCode", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(Decimal));
            _DataTable.Columns.Add("CardHolderBillingCCY", typeof(string));
            _DataTable.Columns.Add("CardHolderBillingAmount", typeof(string));
            _DataTable.Columns.Add("PANEntryMode", typeof(string));
            _DataTable.Columns.Add("PINEntryCapability", typeof(string));
            _DataTable.Columns.Add("POSConditionCode", typeof(string));
            _DataTable.Columns.Add("AcquirerCountryCode", typeof(string));
            _DataTable.Columns.Add("AdditionalAmount", typeof(Decimal));
            _DataTable.Columns.Add("RuPayProduct", typeof(string));
            _DataTable.Columns.Add("CVD2MatchResult", typeof(string));
            _DataTable.Columns.Add("CVDICVDMatchResult", typeof(string));
            _DataTable.Columns.Add("RecurringPayIndicator", typeof(string));
            _DataTable.Columns.Add("ECIIndicator", typeof(string));
            _DataTable.Columns.Add("ICS1ResultCode", typeof(string));
            _DataTable.Columns.Add("FraudScore", typeof(string));
            _DataTable.Columns.Add("EMIAmount", typeof(Decimal));
            _DataTable.Columns.Add("ARQCAuthorization", typeof(string));
            _DataTable.Columns.Add("TxnsID", typeof(string));
            _DataTable.Columns.Add("LoyaltyPoint", typeof(string));
            _DataTable.Columns.Add("ICS2ResultCode", typeof(string));
            _DataTable.Columns.Add("CustMobileNumber", typeof(string));
            _DataTable.Columns.Add("ImageCode", typeof(string));
            _DataTable.Columns.Add("PersonalPhase", typeof(string));
            _DataTable.Columns.Add("UIDNumber", typeof(string));
            _DataTable.Columns.Add("CardDataInputCapability", typeof(string));
            _DataTable.Columns.Add("CardHolderAuthCapability", typeof(string));
            _DataTable.Columns.Add("CardCaptureCapability", typeof(string));
            _DataTable.Columns.Add("TerminalOpEnvironment", typeof(string));
            _DataTable.Columns.Add("CardholderPresentData", typeof(string));
            _DataTable.Columns.Add("CardPresentData", typeof(string));
            _DataTable.Columns.Add("CardDataInputMode", typeof(string));
            _DataTable.Columns.Add("CardHolderAuthMode", typeof(string));
            _DataTable.Columns.Add("CardholderAuthEntity", typeof(string));
            _DataTable.Columns.Add("CardDataOPCapability", typeof(string));
            _DataTable.Columns.Add("TerminalDataCapability", typeof(string));
            _DataTable.Columns.Add("PinCaptureCapability", typeof(string));
            _DataTable.Columns.Add("ZipCode", typeof(string));
            _DataTable.Columns.Add("AdviceReasonCode", typeof(string));
            _DataTable.Columns.Add("ITPAN", typeof(string));
            _DataTable.Columns.Add("INTRAUTHNW", typeof(string));
            _DataTable.Columns.Add("OTPIndicator", typeof(string));
            _DataTable.Columns.Add("ICSTXNID", typeof(string));
            _DataTable.Columns.Add("NWDATA", typeof(string));
            _DataTable.Columns.Add("ServiceCode", typeof(string));
            _DataTable.Columns.Add("CCYActualTxnsAmount", typeof(string));
            _DataTable.Columns.Add("ActualTxnsAmount", typeof(Decimal));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            int Incr = 1;
            string MessageType = string.Empty;
            string ProductID = string.Empty;
            string TxnsType = string.Empty;
            string FromAccountType = string.Empty;
            string ToAccountType = string.Empty;
            string ActionCode = string.Empty;
            string ResponseCode = string.Empty;
            string CardNumber = string.Empty;
            string ApprovalNumber = string.Empty;
            string ReferenceNumber = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string MerchantCategoryCode = string.Empty;
            string CardAcceptorID = string.Empty;
            string TerminalId = string.Empty;
            string TerminalLocation = string.Empty;
            string AcquirerID = string.Empty;
            string TxnsCCYCode = string.Empty;
            string TxnsAmount = "0";
            string CardHolderBillingCCY = string.Empty;
            string CardHolderBillingAmount = "0";
            string PANEntryMode = string.Empty;
            string PINEntryCapability = string.Empty;
            string POSConditionCode = string.Empty;
            string AcquirerCountryCode = string.Empty;
            string AdditionalAmount = "0";
            string RuPayProduct = string.Empty;
            string CVD2MatchResult = string.Empty;
            string CVDICVDMatchResult = string.Empty;
            string RecurringPayIndicator = string.Empty;
            string ECIIndicator = string.Empty;
            string ICS1ResultCode = string.Empty;
            string FraudScore = string.Empty;
            string EMIAmount = "0";
            string ARQCAuthorization = string.Empty;
            string TxnsID = string.Empty;
            string LoyaltyPoint = string.Empty;
            string ICS2ResultCode = string.Empty;
            string CustMobileNumber = string.Empty;
            string ImageCode = string.Empty;
            string PersonalPhase = string.Empty;
            string UIDNumber = string.Empty;
            string CardDataInputCapability = string.Empty;
            string CardHolderAuthCapability = string.Empty;
            string CardCaptureCapability = string.Empty;
            string TerminalOpEnvironment = string.Empty;
            string CardholderPresentData = string.Empty;
            string CardPresentData = string.Empty;
            string CardDataInputMode = string.Empty;
            string CardHolderAuthMode = string.Empty;
            string CardholderAuthEntity = string.Empty;
            string CardDataOPCapability = string.Empty;
            string TerminalDataCapability = string.Empty;
            string PinCaptureCapability = string.Empty;
            string ZipCode = string.Empty;
            string AdviceReasonCode = string.Empty;
            string ITPAN = string.Empty;
            string INTRAUTHNW = string.Empty;
            string OTPIndicator = string.Empty;
            string ICSTXNID = string.Empty;
            string NWDATA = string.Empty;
            string ServiceCode = string.Empty;
            string CCYActualTxnsAmount = "0";
            string ActualTxnsAmount = "0";
            string CREATEDON = string.Empty;
            string MODIFIEDDON = string.Empty;
            string ModifiedBy = string.Empty;
            string CreatedBy = string.Empty;
            string ECardNumber = string.Empty;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";
            string RevEntryLeg = "1";

            string[] TxnDateTime = null;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            string Cycle = string.Empty;

            ushort MessageType_StartPosition = 0;
            ushort MessageType_Length = 0;
            ushort ProductID_StartPosition = 0;
            ushort ProductID_Length = 0;
            ushort TxnsType_StartPosition = 0;
            ushort TxnsType_Length = 0;
            ushort FromAccountType_StartPosition = 0;
            ushort FromAccountType_Length = 0;
            ushort ToAccountType_StartPosition = 0;
            ushort ToAccountType_Length = 0;
            ushort ActionCode_StartPosition = 0;
            ushort ActionCode_Length = 0;
            ushort ResponseCode_StartPosition = 0;
            ushort ResponseCode_Length = 0;
            ushort CardNumber_StartPosition = 0;
            ushort CardNumber_Length = 0;
            ushort ApprovalNumber_StartPosition = 0;
            ushort ApprovalNumber_Length = 0;
            ushort ReferenceNumber_StartPosition = 0;
            ushort ReferenceNumber_Length = 0;
            ushort TxnsDateTime_StartPosition = 0;
            ushort TxnsDateTime_Length = 0;
            ushort TxnsDate_StartPosition = 0;
            ushort TxnsDate_Length = 0;
            ushort TxnsTime_StartPosition = 0;
            ushort TxnsTime_Length = 0;
            ushort MerchantCategoryCode_StartPosition = 0;
            ushort MerchantCategoryCode_Length = 0;
            ushort CardAcceptorID_StartPosition = 0;
            ushort CardAcceptorID_Length = 0;
            ushort TerminalId_StartPosition = 0;
            ushort TerminalId_Length = 0;
            ushort TerminalLocation_StartPosition = 0;
            ushort TerminalLocation_Length = 0;
            ushort AcquirerID_StartPosition = 0;
            ushort AcquirerID_Length = 0;
            ushort TxnsCCYCode_StartPosition = 0;
            ushort TxnsCCYCode_Length = 0;
            ushort TxnsAmount_StartPosition = 0;
            ushort TxnsAmount_Length = 0;
            ushort CardHolderBillingCCY_StartPosition = 0;
            ushort CardHolderBillingCCY_Length = 0;
            ushort CardHolderBillingAmount_StartPosition = 0;
            ushort CardHolderBillingAmount_Length = 0;
            ushort PANEntryMode_StartPosition = 0;
            ushort PANEntryMode_Length = 0;
            ushort PINEntryCapability_StartPosition = 0;
            ushort PINEntryCapability_Length = 0;
            ushort POSConditionCode_StartPosition = 0;
            ushort POSConditionCode_Length = 0;
            ushort AcquirerCountryCode_StartPosition = 0;
            ushort AcquirerCountryCode_Length = 0;
            ushort AdditionalAmount_StartPosition = 0;
            ushort AdditionalAmount_Length = 0;
            ushort RuPayProduct_StartPosition = 0;
            ushort RuPayProduct_Length = 0;
            ushort CVD2MatchResult_StartPosition = 0;
            ushort CVD2MatchResult_Length = 0;
            ushort RecurringPayIndicator_StartPosition = 0;
            ushort RecurringPayIndicator_Length = 0;
            ushort ECIIndicator_StartPosition = 0;
            ushort ECIIndicator_Length = 0;
            ushort ICS1ResultCode_StartPosition = 0;
            ushort ICS1ResultCode_Length = 0;
            ushort FraudScore_StartPosition = 0;
            ushort FraudScore_Length = 0;
            ushort EMIAmount_StartPosition = 0;
            ushort EMIAmount_Length = 0;
            ushort ARQCAuthorization_StartPosition = 0;
            ushort ARQCAuthorization_Length = 0;
            ushort TxnsID_StartPosition = 0;
            ushort TxnsID_Length = 0;
            ushort LoyaltyPoint_StartPosition = 0;
            ushort LoyaltyPoint_Length = 0;
            ushort ICS2ResultCode_StartPosition = 0;
            ushort ICS2ResultCode_Length = 0;
            ushort CustMobileNumber_StartPosition = 0;
            ushort CustMobileNumber_Length = 0;
            ushort ImageCode_StartPosition = 0;
            ushort ImageCode_Length = 0;
            ushort PersonalPhase_StartPosition = 0;
            ushort PersonalPhase_Length = 0;
            ushort UIDNumber_StartPosition = 0;
            ushort UIDNumber_Length = 0;
            ushort CardDataInputCapability_StartPosition = 0;
            ushort CardDataInputCapability_Length = 0;
            ushort CardHolderAuthCapability_StartPosition = 0;
            ushort CardHolderAuthCapability_Length = 0;
            ushort TerminalOpEnvironment_StartPosition = 0;
            ushort TerminalOpEnvironment_Length = 0;
            ushort CardholderPresentData_StartPosition = 0;
            ushort CardholderPresentData_Length = 0;
            ushort CardPresentData_StartPosition = 0;
            ushort CardPresentData_Length = 0;
            ushort CardDataInputMode_StartPosition = 0;
            ushort CardDataInputMode_Length = 0;
            ushort CardHolderAuthMode_StartPosition = 0;
            ushort CardHolderAuthMode_Length = 0;
            ushort CardholderAuthEntity_StartPosition = 0;
            ushort CardholderAuthEntity_Length = 0;
            ushort CardDataOPCapability_StartPosition = 0;
            ushort CardDataOPCapability_Length = 0;
            ushort TerminalDataCapability_StartPosition = 0;
            ushort TerminalDataCapability_Length = 0;
            ushort PinCaptureCapability_StartPosition = 0;
            ushort PinCaptureCapability_Length = 0;
            ushort ZipCode_StartPosition = 0;
            ushort ZipCode_Length = 0;
            ushort AdviceReasonCode_StartPosition = 0;
            ushort AdviceReasonCode_Length = 0;
            ushort ITPAN_StartPosition = 0;
            ushort ITPAN_Length = 0;
            ushort INTRAUTHNW_StartPosition = 0;
            ushort INTRAUTHNW_Length = 0;
            ushort OTPIndicator_StartPosition = 0;
            ushort OTPIndicator_Length = 0;
            ushort ICSTXNID_StartPosition = 0;
            ushort ICSTXNID_Length = 0;
            ushort NWDATA_StartPosition = 0;
            ushort NWDATA_Length = 0;
            ushort ServiceCode_StartPosition = 0;
            ushort ServiceCode_Length = 0;
            ushort CCYActualTxnsAmount_StartPosition = 0;
            ushort CCYActualTxnsAmount_Length = 0;
            ushort ActualTxnsAmount_StartPosition = 0;
            ushort ActualTxnsAmount_Length = 0;

            double TrnAmount = 0, ActualAmount=0, AdditionalAmt = 0, EMIAmt=0;

            int ErrorCount = 0, LineNo = 0;

            try
            {
                
                

                
                
                
                

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();
               

                DataSet ds = new DataSet();

                ds.ReadXml(new XmlTextReader(new System.IO.StringReader(xmlFile)));

                Cycle = fileImportRequest.FileName.Length > 2 ? fileImportRequest.FileName.Substring(2, 1).Trim() : string.Empty;

                MessageType_StartPosition = Convert.ToUInt16(ds.Tables["MessageType"].Rows[0]["StartPosition"]);
                MessageType_Length = Convert.ToUInt16(ds.Tables["MessageType"].Rows[0]["Length"]);

                ProductID_StartPosition = Convert.ToUInt16(ds.Tables["ProductID"].Rows[0]["StartPosition"]);
                ProductID_Length = Convert.ToUInt16(ds.Tables["ProductID"].Rows[0]["Length"]);

                TxnsType_StartPosition = Convert.ToUInt16(ds.Tables["TxnsType"].Rows[0]["StartPosition"]);
                TxnsType_Length = Convert.ToUInt16(ds.Tables["TxnsType"].Rows[0]["Length"]);

                FromAccountType_StartPosition = Convert.ToUInt16(ds.Tables["FromAccountType"].Rows[0]["StartPosition"]);
                FromAccountType_Length = Convert.ToUInt16(ds.Tables["FromAccountType"].Rows[0]["Length"]);

                ToAccountType_StartPosition = Convert.ToUInt16(ds.Tables["ToAccountType"].Rows[0]["StartPosition"]);
                ToAccountType_Length = Convert.ToUInt16(ds.Tables["ToAccountType"].Rows[0]["Length"]);

                ActionCode_StartPosition = Convert.ToUInt16(ds.Tables["ActionCode"].Rows[0]["StartPosition"]);
                ActionCode_Length = Convert.ToUInt16(ds.Tables["ActionCode"].Rows[0]["Length"]);

                ResponseCode_StartPosition = Convert.ToUInt16(ds.Tables["ResponseCode"].Rows[0]["StartPosition"]);
                ResponseCode_Length = Convert.ToUInt16(ds.Tables["ResponseCode"].Rows[0]["Length"]);

                CardNumber_StartPosition = Convert.ToUInt16(ds.Tables["CardNumber"].Rows[0]["StartPosition"]);
                CardNumber_Length = Convert.ToUInt16(ds.Tables["CardNumber"].Rows[0]["Length"]);

                ApprovalNumber_StartPosition = Convert.ToUInt16(ds.Tables["ApprovalNumber"].Rows[0]["StartPosition"]);
                ApprovalNumber_Length = Convert.ToUInt16(ds.Tables["ApprovalNumber"].Rows[0]["Length"]);

                ReferenceNumber_StartPosition = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"]);
                ReferenceNumber_Length = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["Length"]);

                TxnsDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"]);
                TxnsDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["Length"]);

                TxnsDate_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDate"].Rows[0]["StartPosition"]);
                TxnsDate_Length = Convert.ToUInt16(ds.Tables["TxnsDate"].Rows[0]["Length"]);

                TxnsTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsTime"].Rows[0]["StartPosition"]);
                TxnsTime_Length = Convert.ToUInt16(ds.Tables["TxnsTime"].Rows[0]["Length"]);

                MerchantCategoryCode_StartPosition = Convert.ToUInt16(ds.Tables["MerchantCategoryCode"].Rows[0]["StartPosition"]);
                MerchantCategoryCode_Length = Convert.ToUInt16(ds.Tables["MerchantCategoryCode"].Rows[0]["Length"]);

                CardAcceptorID_StartPosition = Convert.ToUInt16(ds.Tables["CardAcceptorID"].Rows[0]["StartPosition"]);
                CardAcceptorID_Length = Convert.ToUInt16(ds.Tables["CardAcceptorID"].Rows[0]["Length"]);

                TerminalId_StartPosition = Convert.ToUInt16(ds.Tables["TerminalId"].Rows[0]["StartPosition"]);
                TerminalId_Length = Convert.ToUInt16(ds.Tables["TerminalId"].Rows[0]["Length"]);

                TerminalLocation_StartPosition = Convert.ToUInt16(ds.Tables["TerminalLocation"].Rows[0]["StartPosition"]);
                TerminalLocation_Length = Convert.ToUInt16(ds.Tables["TerminalLocation"].Rows[0]["Length"]);

                AcquirerID_StartPosition = Convert.ToUInt16(ds.Tables["AcquirerID"].Rows[0]["StartPosition"]);
                AcquirerID_Length = Convert.ToUInt16(ds.Tables["AcquirerID"].Rows[0]["Length"]);

                TxnsCCYCode_StartPosition = Convert.ToUInt16(ds.Tables["TxnsCCYCode"].Rows[0]["StartPosition"]);
                TxnsCCYCode_Length = Convert.ToUInt16(ds.Tables["TxnsCCYCode"].Rows[0]["Length"]);

                TxnsAmount_StartPosition = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["StartPosition"]);
                TxnsAmount_Length = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["Length"]);

                CardHolderBillingCCY_StartPosition = Convert.ToUInt16(ds.Tables["CardHolderBillingCCY"].Rows[0]["StartPosition"]);
                CardHolderBillingCCY_Length = Convert.ToUInt16(ds.Tables["CardHolderBillingCCY"].Rows[0]["Length"]);

                CardHolderBillingAmount_StartPosition = Convert.ToUInt16(ds.Tables["CardHolderBillingAmount"].Rows[0]["StartPosition"]);
                CardHolderBillingAmount_Length = Convert.ToUInt16(ds.Tables["CardHolderBillingAmount"].Rows[0]["Length"]);

                PANEntryMode_StartPosition = Convert.ToUInt16(ds.Tables["PANEntryMode"].Rows[0]["StartPosition"]);
                PANEntryMode_Length = Convert.ToUInt16(ds.Tables["PANEntryMode"].Rows[0]["Length"]);

                PINEntryCapability_StartPosition = Convert.ToUInt16(ds.Tables["PINEntryCapability"].Rows[0]["StartPosition"]);
                PINEntryCapability_Length = Convert.ToUInt16(ds.Tables["PINEntryCapability"].Rows[0]["Length"]);

                POSConditionCode_StartPosition = Convert.ToUInt16(ds.Tables["POSConditionCode"].Rows[0]["StartPosition"]);
                POSConditionCode_Length = Convert.ToUInt16(ds.Tables["POSConditionCode"].Rows[0]["Length"]);

                AcquirerCountryCode_StartPosition = Convert.ToUInt16(ds.Tables["AcquirerCountryCode"].Rows[0]["StartPosition"]);
                AcquirerCountryCode_Length = Convert.ToUInt16(ds.Tables["AcquirerCountryCode"].Rows[0]["Length"]);

                AdditionalAmount_StartPosition = Convert.ToUInt16(ds.Tables["AdditionalAmount"].Rows[0]["StartPosition"]);
                AdditionalAmount_Length = Convert.ToUInt16(ds.Tables["AdditionalAmount"].Rows[0]["Length"]);

                RuPayProduct_StartPosition = Convert.ToUInt16(ds.Tables["RuPayProduct"].Rows[0]["StartPosition"]);
                RuPayProduct_Length = Convert.ToUInt16(ds.Tables["RuPayProduct"].Rows[0]["Length"]);

                CVD2MatchResult_StartPosition = Convert.ToUInt16(ds.Tables["CVD2MatchResult"].Rows[0]["StartPosition"]);
                CVD2MatchResult_Length = Convert.ToUInt16(ds.Tables["CVD2MatchResult"].Rows[0]["Length"]);

                RecurringPayIndicator_StartPosition = Convert.ToUInt16(ds.Tables["RecurringPayIndicator"].Rows[0]["StartPosition"]);
                RecurringPayIndicator_Length = Convert.ToUInt16(ds.Tables["RecurringPayIndicator"].Rows[0]["Length"]);

                ECIIndicator_StartPosition = Convert.ToUInt16(ds.Tables["ECIIndicator"].Rows[0]["StartPosition"]);
                ECIIndicator_Length = Convert.ToUInt16(ds.Tables["ECIIndicator"].Rows[0]["Length"]);

                ICS1ResultCode_StartPosition = Convert.ToUInt16(ds.Tables["ICS1ResultCode"].Rows[0]["StartPosition"]);
                ICS1ResultCode_Length = Convert.ToUInt16(ds.Tables["ICS1ResultCode"].Rows[0]["Length"]);

                FraudScore_StartPosition = Convert.ToUInt16(ds.Tables["FraudScore"].Rows[0]["StartPosition"]);
                FraudScore_Length = Convert.ToUInt16(ds.Tables["FraudScore"].Rows[0]["Length"]);

                EMIAmount_StartPosition = Convert.ToUInt16(ds.Tables["EMIAmount"].Rows[0]["StartPosition"]);
                EMIAmount_Length = Convert.ToUInt16(ds.Tables["EMIAmount"].Rows[0]["Length"]);

                ARQCAuthorization_StartPosition = Convert.ToUInt16(ds.Tables["ARQCAuthorization"].Rows[0]["StartPosition"]);
                ARQCAuthorization_Length = Convert.ToUInt16(ds.Tables["ARQCAuthorization"].Rows[0]["Length"]);

                TxnsID_StartPosition = Convert.ToUInt16(ds.Tables["TxnsID"].Rows[0]["StartPosition"]);
                TxnsID_Length = Convert.ToUInt16(ds.Tables["TxnsID"].Rows[0]["Length"]);

                LoyaltyPoint_StartPosition = Convert.ToUInt16(ds.Tables["LoyaltyPoint"].Rows[0]["StartPosition"]);
                LoyaltyPoint_Length = Convert.ToUInt16(ds.Tables["LoyaltyPoint"].Rows[0]["Length"]);

                ICS2ResultCode_StartPosition = Convert.ToUInt16(ds.Tables["ICS2ResultCode"].Rows[0]["StartPosition"]);
                ICS2ResultCode_Length = Convert.ToUInt16(ds.Tables["ICS2ResultCode"].Rows[0]["Length"]);

                CustMobileNumber_StartPosition = Convert.ToUInt16(ds.Tables["CustMobileNumber"].Rows[0]["StartPosition"]);
                CustMobileNumber_Length = Convert.ToUInt16(ds.Tables["CustMobileNumber"].Rows[0]["Length"]);

                ImageCode_StartPosition = Convert.ToUInt16(ds.Tables["ImageCode"].Rows[0]["StartPosition"]);
                ImageCode_Length = Convert.ToUInt16(ds.Tables["ImageCode"].Rows[0]["Length"]);

                PersonalPhase_StartPosition = Convert.ToUInt16(ds.Tables["PersonalPhase"].Rows[0]["StartPosition"]);
                PersonalPhase_Length = Convert.ToUInt16(ds.Tables["PersonalPhase"].Rows[0]["Length"]);

                UIDNumber_StartPosition = Convert.ToUInt16(ds.Tables["UIDNumber"].Rows[0]["StartPosition"]);
                UIDNumber_Length = Convert.ToUInt16(ds.Tables["UIDNumber"].Rows[0]["Length"]);

                CardDataInputCapability_StartPosition = Convert.ToUInt16(ds.Tables["CardDataInputCapability"].Rows[0]["StartPosition"]);
                CardDataInputCapability_Length = Convert.ToUInt16(ds.Tables["CardDataInputCapability"].Rows[0]["Length"]);

                CardHolderAuthCapability_StartPosition = Convert.ToUInt16(ds.Tables["CardHolderAuthCapability"].Rows[0]["StartPosition"]);
                CardHolderAuthCapability_Length = Convert.ToUInt16(ds.Tables["CardHolderAuthCapability"].Rows[0]["Length"]);

                TerminalOpEnvironment_StartPosition = Convert.ToUInt16(ds.Tables["TerminalOpEnvironment"].Rows[0]["StartPosition"]);
                TerminalOpEnvironment_Length = Convert.ToUInt16(ds.Tables["TerminalOpEnvironment"].Rows[0]["Length"]);

                CardholderPresentData_StartPosition = Convert.ToUInt16(ds.Tables["CardholderPresentData"].Rows[0]["StartPosition"]);
                CardholderPresentData_Length = Convert.ToUInt16(ds.Tables["CardholderPresentData"].Rows[0]["Length"]);

                CardPresentData_StartPosition = Convert.ToUInt16(ds.Tables["CardPresentData"].Rows[0]["StartPosition"]);
                CardPresentData_Length = Convert.ToUInt16(ds.Tables["CardPresentData"].Rows[0]["Length"]);

                CardDataInputMode_StartPosition = Convert.ToUInt16(ds.Tables["CardDataInputMode"].Rows[0]["StartPosition"]);
                CardDataInputMode_Length = Convert.ToUInt16(ds.Tables["CardDataInputMode"].Rows[0]["Length"]);

                CardHolderAuthMode_StartPosition = Convert.ToUInt16(ds.Tables["CardHolderAuthMode"].Rows[0]["StartPosition"]);
                CardHolderAuthMode_Length = Convert.ToUInt16(ds.Tables["CardHolderAuthMode"].Rows[0]["Length"]);

                CardholderAuthEntity_StartPosition = Convert.ToUInt16(ds.Tables["CardholderAuthEntity"].Rows[0]["StartPosition"]);
                CardholderAuthEntity_Length = Convert.ToUInt16(ds.Tables["CardholderAuthEntity"].Rows[0]["Length"]);

                CardDataOPCapability_StartPosition = Convert.ToUInt16(ds.Tables["CardDataOPCapability"].Rows[0]["StartPosition"]);
                CardDataOPCapability_Length = Convert.ToUInt16(ds.Tables["CardDataOPCapability"].Rows[0]["Length"]);

                TerminalDataCapability_StartPosition = Convert.ToUInt16(ds.Tables["TerminalDataCapability"].Rows[0]["StartPosition"]);
                TerminalDataCapability_Length = Convert.ToUInt16(ds.Tables["TerminalDataCapability"].Rows[0]["Length"]);

                PinCaptureCapability_StartPosition = Convert.ToUInt16(ds.Tables["PinCaptureCapability"].Rows[0]["StartPosition"]);
                PinCaptureCapability_Length = Convert.ToUInt16(ds.Tables["PinCaptureCapability"].Rows[0]["Length"]);

                ZipCode_StartPosition = Convert.ToUInt16(ds.Tables["ZipCode"].Rows[0]["StartPosition"]);
                ZipCode_Length = Convert.ToUInt16(ds.Tables["ZipCode"].Rows[0]["Length"]);

                AdviceReasonCode_StartPosition = Convert.ToUInt16(ds.Tables["AdviceReasonCode"].Rows[0]["StartPosition"]);
                AdviceReasonCode_Length = Convert.ToUInt16(ds.Tables["AdviceReasonCode"].Rows[0]["Length"]);

                ITPAN_StartPosition = Convert.ToUInt16(ds.Tables["ITPAN"].Rows[0]["StartPosition"]);
                ITPAN_Length = Convert.ToUInt16(ds.Tables["ITPAN"].Rows[0]["Length"]);

                INTRAUTHNW_StartPosition = Convert.ToUInt16(ds.Tables["INTRAUTHNW"].Rows[0]["StartPosition"]);
                INTRAUTHNW_Length = Convert.ToUInt16(ds.Tables["INTRAUTHNW"].Rows[0]["Length"]);

                OTPIndicator_StartPosition = Convert.ToUInt16(ds.Tables["OTPIndicator"].Rows[0]["StartPosition"]);
                OTPIndicator_Length = Convert.ToUInt16(ds.Tables["OTPIndicator"].Rows[0]["Length"]);

                ICSTXNID_StartPosition = Convert.ToUInt16(ds.Tables["ICSTXNID"].Rows[0]["StartPosition"]);
                ICSTXNID_Length = Convert.ToUInt16(ds.Tables["ICSTXNID"].Rows[0]["Length"]);

                NWDATA_StartPosition = Convert.ToUInt16(ds.Tables["NWDATA"].Rows[0]["StartPosition"]);
                NWDATA_Length = Convert.ToUInt16(ds.Tables["NWDATA"].Rows[0]["Length"]);

                ServiceCode_StartPosition = Convert.ToUInt16(ds.Tables["ServiceCode"].Rows[0]["StartPosition"]);
                ServiceCode_Length = Convert.ToUInt16(ds.Tables["ServiceCode"].Rows[0]["Length"]);

                CCYActualTxnsAmount_StartPosition = Convert.ToUInt16(ds.Tables["CCYActualTxnsAmount"].Rows[0]["StartPosition"]);
                CCYActualTxnsAmount_Length = Convert.ToUInt16(ds.Tables["CCYActualTxnsAmount"].Rows[0]["Length"]);

                ActualTxnsAmount_StartPosition = Convert.ToUInt16(ds.Tables["ActualTxnsAmount"].Rows[0]["StartPosition"]);
                ActualTxnsAmount_Length = Convert.ToUInt16(ds.Tables["ActualTxnsAmount"].Rows[0]["Length"]);

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                string[] TotalCountArray = System.IO.File.ReadAllLines(fileImportRequest.Path);
                fileImportRequest.TotalCount = TotalCountArray.Length;
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                //objLogWriter.FunErrorLog(ex.Message.ToString(), fileImportRequest.ClientCode, "PlainTextSplitter.cs", "SplitData", LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E');
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                //Get Batch Size
                batchSize = bulkImports.GetBatchSize(DTdetails.ConfigID);

                foreach (var batchDetail in fileImportRequest.FailedBatches)
                {
                    if (batchDetail.BatchNo != 0)
                    {
                        BatchNo = batchDetail.BatchNo - 1;
                    }


                    bool NewEntry = false;

                    if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                    {
                        //set the flag if it is new Entry
                        NewEntry = false;
                    }
                    else
                    {
                        if (batchDetail.BatchStatus == "None")
                        {
                            break;
                        }
                        else
                        {
                            //set the flag if it is old and  Partial Entry
                            NewEntry = true;
                        }
                    }
                    int TxnAmountIsDecimal = Convert.ToInt32(fileImportRequest.ConfigData.Rows[0]["TxnAmountIsDecimal"]);

                    foreach (string line in System.IO.File.ReadAllLines(fileImportRequest.Path))
                    {
                        LineNo++;
                        LineNumber++;
                        if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                        {
                            continue;
                        }
                        try
                        {

                            string line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            Incr = 1;
                            MessageType = string.Empty;
                            ProductID = string.Empty;
                            TxnsType = string.Empty;
                            FromAccountType = string.Empty;
                            ToAccountType = string.Empty;
                            ActionCode = string.Empty;
                            ResponseCode = string.Empty;
                            CardNumber = string.Empty;
                            ApprovalNumber = string.Empty;
                            ReferenceNumber = string.Empty;
                            TxnsDateTime = string.Empty;
                            TxnsDate = string.Empty;
                            TxnsTime = string.Empty;
                            MerchantCategoryCode = string.Empty;
                            CardAcceptorID = string.Empty;
                            TerminalId = string.Empty;
                            TerminalLocation = string.Empty;
                            AcquirerID = string.Empty;
                            TxnsCCYCode = string.Empty;
                            TxnsAmount = "0";
                            CardHolderBillingCCY = string.Empty;
                            CardHolderBillingAmount = "0";
                            PANEntryMode = string.Empty;
                            PINEntryCapability = string.Empty;
                            POSConditionCode = string.Empty;
                            AcquirerCountryCode = string.Empty;
                            AdditionalAmount = "0";
                            RuPayProduct = string.Empty;
                            CVD2MatchResult = string.Empty;
                            CVDICVDMatchResult = string.Empty;
                            RecurringPayIndicator = string.Empty;
                            ECIIndicator = string.Empty;
                            ICS1ResultCode = string.Empty;
                            FraudScore = string.Empty;
                            EMIAmount = "0";
                            ARQCAuthorization = string.Empty;
                            TxnsID = string.Empty;
                            LoyaltyPoint = string.Empty;
                            ICS2ResultCode = string.Empty;
                            CustMobileNumber = string.Empty;
                            ImageCode = string.Empty;
                            PersonalPhase = string.Empty;
                            UIDNumber = string.Empty;
                            CardDataInputCapability = string.Empty;
                            CardHolderAuthCapability = string.Empty;
                            CardCaptureCapability = string.Empty;
                            TerminalOpEnvironment = string.Empty;
                            CardholderPresentData = string.Empty;
                            CardPresentData = string.Empty;
                            CardDataInputMode = string.Empty;
                            CardHolderAuthMode = string.Empty;
                            CardholderAuthEntity = string.Empty;
                            CardDataOPCapability = string.Empty;
                            TerminalDataCapability = string.Empty;
                            PinCaptureCapability = string.Empty;
                            ZipCode = string.Empty;
                            AdviceReasonCode = string.Empty;
                            ITPAN = string.Empty;
                            INTRAUTHNW = string.Empty;
                            OTPIndicator = string.Empty;
                            ICSTXNID = string.Empty;
                            NWDATA = string.Empty;
                            ServiceCode = string.Empty;
                            CCYActualTxnsAmount = "0";
                            ActualTxnsAmount = "0";
                            CREATEDON = string.Empty;
                            MODIFIEDDON = string.Empty;
                            ModifiedBy = string.Empty;
                            CreatedBy = string.Empty;
                            ECardNumber = string.Empty;
                            CardScheme = string.Empty;
                            TrnAmount = 0; ActualAmount = 0; AdditionalAmt = 0; EMIAmt = 0;

                            MessageType = MessageType_StartPosition > 0 && MessageType_Length > 0 ? line1.Substring(MessageType_StartPosition - Incr, MessageType_Length).Trim() : string.Empty;
                            ProductID = ProductID_StartPosition > 0 && ProductID_Length > 0 ? line1.Substring(ProductID_StartPosition - Incr, ProductID_Length).Trim() : string.Empty;
                            FromAccountType = FromAccountType_StartPosition > 0 && FromAccountType_Length > 0 ? line1.Substring(FromAccountType_StartPosition - Incr, FromAccountType_Length).Trim() : string.Empty;
                            TxnsType = TxnsType_StartPosition > 0 && TxnsType_Length > 0 ? line1.Substring(TxnsType_StartPosition - Incr, TxnsType_Length).Trim() : string.Empty;
                            ToAccountType = ToAccountType_StartPosition > 0 && ToAccountType_Length > 0 ? line1.Substring(ToAccountType_StartPosition - Incr, ToAccountType_Length).Trim() : string.Empty;
                            ActionCode = ActionCode_StartPosition > 0 && ActionCode_Length > 0 ? line1.Substring(ActionCode_StartPosition - Incr, ActionCode_Length).Trim() : string.Empty;
                            ResponseCode = ResponseCode_StartPosition > 0 && ResponseCode_Length > 0 ? line1.Substring(ResponseCode_StartPosition - Incr, ResponseCode_Length).Trim() : string.Empty;
                            CardNumber = CardNumber_StartPosition > 0 && CardNumber_Length > 0 ? line1.Substring(CardNumber_StartPosition - Incr, CardNumber_Length).Trim() : string.Empty;
                            ApprovalNumber = ApprovalNumber_StartPosition > 0 && ApprovalNumber_Length > 0 ? line1.Substring(ApprovalNumber_StartPosition - Incr, ApprovalNumber_Length).Trim() : string.Empty;
                            ReferenceNumber = ReferenceNumber_StartPosition > 0 && ReferenceNumber_Length > 0 ? line1.Substring(ReferenceNumber_StartPosition - Incr, ReferenceNumber_Length).Trim() : string.Empty;
                            TxnsDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length).Trim() : string.Empty;
                            TxnsDate = TxnsDate_StartPosition > 0 && TxnsDate_Length > 0 ? line1.Substring(TxnsDate_StartPosition - Incr, TxnsDate_Length).Trim() : string.Empty;
                            TxnsTime = TxnsTime_StartPosition > 0 && TxnsTime_Length > 0 ? line1.Substring(TxnsTime_StartPosition - Incr, TxnsTime_Length).Trim() : string.Empty;
                            MerchantCategoryCode = MerchantCategoryCode_StartPosition > 0 && MerchantCategoryCode_Length > 0 ? line1.Substring(MerchantCategoryCode_StartPosition - Incr, MerchantCategoryCode_Length).Trim() : string.Empty;


                            CardAcceptorID = CardAcceptorID_StartPosition > 0 && CardAcceptorID_Length > 0 ? line1.Substring(CardAcceptorID_StartPosition - Incr, CardAcceptorID_Length).Trim() : string.Empty;
                            TerminalId = TerminalId_StartPosition > 0 && TerminalId_Length > 0 ? line1.Substring(TerminalId_StartPosition - Incr, TerminalId_Length).Trim() : string.Empty;
                            TerminalLocation = TerminalLocation_StartPosition > 0 && TerminalLocation_Length > 0 ? line1.Substring(TerminalLocation_StartPosition - Incr, TerminalLocation_Length).Trim() : string.Empty;
                            AcquirerID = AcquirerID_StartPosition > 0 && AcquirerID_Length > 0 ? line1.Substring(AcquirerID_StartPosition - Incr, AcquirerID_Length).Trim() : string.Empty;
                            TxnsCCYCode = TxnsCCYCode_StartPosition > 0 && TxnsCCYCode_Length > 0 ? line1.Substring(TxnsCCYCode_StartPosition - Incr, TxnsCCYCode_Length).Trim() : string.Empty;
                            TxnsAmount = TxnsAmount_StartPosition > 0 && TxnsAmount_Length > 0 ? line1.Substring(TxnsAmount_StartPosition - Incr, TxnsAmount_Length).Trim() : string.Empty;
                            CardHolderBillingCCY = CardHolderBillingCCY_StartPosition > 0 && CardHolderBillingCCY_Length > 0 ? line1.Substring(CardHolderBillingCCY_StartPosition - Incr, CardHolderBillingCCY_Length).Trim() : string.Empty;
                            CardHolderBillingAmount = CardHolderBillingAmount_StartPosition > 0 && CardHolderBillingAmount_Length > 0 ? line1.Substring(CardHolderBillingAmount_StartPosition - Incr, CardHolderBillingAmount_Length).Trim() : string.Empty;
                            PANEntryMode = PANEntryMode_StartPosition > 0 && PANEntryMode_Length > 0 ? line1.Substring(PANEntryMode_StartPosition - Incr, PANEntryMode_Length).Trim() : string.Empty;
                            PINEntryCapability = PINEntryCapability_StartPosition > 0 && PINEntryCapability_Length > 0 ? line1.Substring(PINEntryCapability_StartPosition - Incr, PINEntryCapability_Length).Trim() : string.Empty;
                            POSConditionCode = POSConditionCode_StartPosition > 0 && POSConditionCode_Length > 0 ? line1.Substring(POSConditionCode_StartPosition - Incr, POSConditionCode_Length).Trim() : string.Empty;
                            AcquirerCountryCode = AcquirerCountryCode_StartPosition > 0 && AcquirerCountryCode_Length > 0 ? line1.Substring(AcquirerCountryCode_StartPosition - Incr, AcquirerCountryCode_Length).Trim() : string.Empty;
                            AdditionalAmount = AdditionalAmount_StartPosition > 0 && AdditionalAmount_Length > 0 ? line1.Substring(AdditionalAmount_StartPosition - Incr, AdditionalAmount_Length).Trim() : string.Empty;
                            RuPayProduct = RuPayProduct_StartPosition > 0 && RuPayProduct_Length > 0 ? line1.Substring(RuPayProduct_StartPosition - Incr, RuPayProduct_Length).Trim() : string.Empty;
                            CVD2MatchResult = CVD2MatchResult_StartPosition > 0 && CVD2MatchResult_Length > 0 ? line1.Substring(CVD2MatchResult_StartPosition - Incr, CVD2MatchResult_Length).Trim() : string.Empty;
                            RecurringPayIndicator = RecurringPayIndicator_StartPosition > 0 && RecurringPayIndicator_Length > 0 ? line1.Substring(RecurringPayIndicator_StartPosition - Incr, RecurringPayIndicator_Length).Trim() : string.Empty;


                            ECIIndicator = ECIIndicator_StartPosition > 0 && ECIIndicator_Length > 0 ? line1.Substring(ECIIndicator_StartPosition - Incr, ECIIndicator_Length).Trim() : string.Empty;
                            ICS1ResultCode = ICS1ResultCode_StartPosition > 0 && ICS1ResultCode_Length > 0 ? line1.Substring(ICS1ResultCode_StartPosition - Incr, ICS1ResultCode_Length).Trim() : string.Empty;
                            FraudScore = FraudScore_StartPosition > 0 && FraudScore_Length > 0 ? line1.Substring(FraudScore_StartPosition - Incr, FraudScore_Length).Trim() : string.Empty;
                            EMIAmount = EMIAmount_StartPosition > 0 && EMIAmount_Length > 0 ? line1.Substring(EMIAmount_StartPosition - Incr, EMIAmount_Length).Trim() : string.Empty;
                            ARQCAuthorization = ARQCAuthorization_StartPosition > 0 && ARQCAuthorization_Length > 0 ? line1.Substring(ARQCAuthorization_StartPosition - Incr, ARQCAuthorization_Length).Trim() : string.Empty;
                            TxnsID = TxnsID_StartPosition > 0 && TxnsID_Length > 0 ? line1.Substring(TxnsID_StartPosition - Incr, TxnsID_Length).Trim() : string.Empty;
                            LoyaltyPoint = LoyaltyPoint_StartPosition > 0 && LoyaltyPoint_Length > 0 ? line1.Substring(LoyaltyPoint_StartPosition - Incr, LoyaltyPoint_Length).Trim() : string.Empty;
                            ICS2ResultCode = ICS2ResultCode_StartPosition > 0 && ICS2ResultCode_Length > 0 ? line1.Substring(ICS2ResultCode_StartPosition - Incr, ICS2ResultCode_Length).Trim() : string.Empty;
                            CustMobileNumber = CustMobileNumber_StartPosition > 0 && CustMobileNumber_Length > 0 ? line1.Substring(CustMobileNumber_StartPosition - Incr, CustMobileNumber_Length).Trim() : string.Empty;

                            ImageCode = ImageCode_StartPosition > 0 && ImageCode_Length > 0 ? line1.Substring(ImageCode_StartPosition - Incr, ImageCode_Length).Trim() : string.Empty;
                            PersonalPhase = PersonalPhase_StartPosition > 0 && PersonalPhase_Length > 0 ? line1.Substring(PersonalPhase_StartPosition - Incr, PersonalPhase_Length).Trim() : string.Empty;
                            UIDNumber = UIDNumber_StartPosition > 0 && UIDNumber_Length > 0 ? line1.Substring(UIDNumber_StartPosition - Incr, UIDNumber_Length).Trim() : string.Empty;
                            CardDataInputCapability = CardDataInputCapability_StartPosition > 0 && CardDataInputCapability_Length > 0 ? line1.Substring(CardDataInputCapability_StartPosition - Incr, CardDataInputCapability_Length).Trim() : string.Empty;
                            CardHolderAuthCapability = CardHolderAuthCapability_StartPosition > 0 && CardHolderAuthCapability_Length > 0 ? line1.Substring(CardHolderAuthCapability_StartPosition - Incr, CardHolderAuthCapability_Length).Trim() : string.Empty;
                            TerminalOpEnvironment = TerminalOpEnvironment_StartPosition > 0 && TerminalOpEnvironment_Length > 0 ? line1.Substring(TerminalOpEnvironment_StartPosition - Incr, TerminalOpEnvironment_Length).Trim() : string.Empty;
                            CardholderPresentData = CardholderPresentData_StartPosition > 0 && CardholderPresentData_Length > 0 ? line1.Substring(CardholderPresentData_StartPosition - Incr, CardholderPresentData_Length).Trim() : string.Empty;
                            CardPresentData = CardPresentData_StartPosition > 0 && CardPresentData_Length > 0 ? line1.Substring(CardPresentData_StartPosition - Incr, CardPresentData_Length).Trim() : string.Empty;
                            CardDataInputMode = CardDataInputMode_StartPosition > 0 && CardDataInputMode_Length > 0 ? line1.Substring(CardDataInputMode_StartPosition - Incr, CardDataInputMode_Length).Trim() : string.Empty;
                            CardHolderAuthMode = CardHolderAuthMode_StartPosition > 0 && CardHolderAuthMode_Length > 0 ? line1.Substring(CardHolderAuthMode_StartPosition - Incr, CardHolderAuthMode_Length).Trim() : string.Empty;
                            CardholderAuthEntity = CardholderAuthEntity_StartPosition > 0 && CardholderAuthEntity_Length > 0 ? line1.Substring(CardholderAuthEntity_StartPosition - Incr, CardholderAuthEntity_Length).Trim() : string.Empty;
                            CardDataOPCapability = CardDataOPCapability_StartPosition > 0 && CardDataOPCapability_Length > 0 ? line1.Substring(CardDataOPCapability_StartPosition - Incr, CardDataOPCapability_Length).Trim() : string.Empty;
                            TerminalDataCapability = TerminalDataCapability_StartPosition > 0 && TerminalDataCapability_Length > 0 ? line1.Substring(TerminalDataCapability_StartPosition - Incr, TerminalDataCapability_Length).Trim() : string.Empty;

                            PinCaptureCapability = PinCaptureCapability_StartPosition > 0 && PinCaptureCapability_Length > 0 ? line1.Substring(PinCaptureCapability_StartPosition - Incr, PinCaptureCapability_Length).Trim() : string.Empty;
                            ZipCode = ZipCode_StartPosition > 0 && ZipCode_Length > 0 ? line1.Substring(ZipCode_StartPosition - Incr, ZipCode_Length).Trim() : string.Empty;
                            AdviceReasonCode = AdviceReasonCode_StartPosition > 0 && AdviceReasonCode_Length > 0 ? line1.Substring(AdviceReasonCode_StartPosition - Incr, AdviceReasonCode_Length).Trim() : string.Empty;
                            ITPAN = ITPAN_StartPosition > 0 && ITPAN_Length > 0 ? line1.Substring(ITPAN_StartPosition - Incr, ITPAN_Length).Trim() : string.Empty;
                            INTRAUTHNW = INTRAUTHNW_StartPosition > 0 && INTRAUTHNW_Length > 0 ? line1.Substring(INTRAUTHNW_StartPosition - Incr, INTRAUTHNW_Length).Trim() : string.Empty;
                            OTPIndicator = OTPIndicator_StartPosition > 0 && OTPIndicator_Length > 0 ? line1.Substring(OTPIndicator_StartPosition - Incr, OTPIndicator_Length).Trim() : string.Empty;
                            ICSTXNID = ICSTXNID_StartPosition > 0 && ICSTXNID_Length > 0 ? line1.Substring(ICSTXNID_StartPosition - Incr, ICSTXNID_Length).Trim() : string.Empty;

                            NWDATA = NWDATA_StartPosition > 0 && NWDATA_Length > 0 ? line1.Substring(NWDATA_StartPosition - Incr, NWDATA_Length).Trim() : string.Empty;
                            ServiceCode = ServiceCode_StartPosition > 0 && ServiceCode_Length > 0 ? line1.Substring(ServiceCode_StartPosition - Incr, ServiceCode_Length).Trim() : string.Empty;
                            CCYActualTxnsAmount = CCYActualTxnsAmount_StartPosition > 0 && CCYActualTxnsAmount_Length > 0 ? line1.Substring(CCYActualTxnsAmount_StartPosition - Incr, CCYActualTxnsAmount_Length).Trim() : string.Empty;
                            ActualTxnsAmount = ActualTxnsAmount_StartPosition > 0 && ActualTxnsAmount_Length > 0 ? line1.Substring(ActualTxnsAmount_StartPosition - Incr, ActualTxnsAmount_Length).Trim() : string.Empty;

                            TxnsDateTimeMain = null;

                            if (TxnsDate != "" && TxnsTime != "" && TxnDateTime.Length > 0)
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDate + " " + TxnsTime, TxnDateTime, System.Globalization.CultureInfo.InvariantCulture);
                            }

                            if (TxnsDateTime != "" && TxnDateTime.Length > 0)
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTime, System.Globalization.CultureInfo.InvariantCulture);
                            }


                            try
                            {
                                TrnAmount = 0;

                                if (TxnAmountIsDecimal > 0)
                                {
                                    TrnAmount = double.Parse(TxnsAmount) / Math.Pow(10, TxnAmountIsDecimal);
                                    AdditionalAmt = double.Parse(AdditionalAmount) / Math.Pow(10, TxnAmountIsDecimal);
                                    EMIAmt = double.Parse(EMIAmount) / Math.Pow(10, TxnAmountIsDecimal);
                                }
                                else
                                {
                                    TrnAmount = double.Parse(TxnsAmount);
                                    AdditionalAmt = double.Parse(AdditionalAmount);
                                    EMIAmt = double.Parse(EMIAmount);
                                }
                                ActualAmount = double.Parse(ActualTxnsAmount);
                            }
                            catch
                            {

                            }

                            CardType = string.Empty;

                            if (CardNumber != "")
                            {
                                CardNumber = CardNumber.TrimStart('0');

                                if (CardNumber.Substring(0, 1) == "4")
                                {
                                    CardScheme = "VISA";
                                }
                                else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                                {
                                    CardScheme = "MASTER";
                                }
                                else if (CardNumber.Substring(0, 2) == "62")
                                {
                                    CardScheme = "CUP";
                                }
                                else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                                {
                                    CardScheme = "RuPay";
                                }
                                else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                                {
                                    CardScheme = "Maestro";
                                }

                            }

                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);
                            }

                            if (CardNumber != "" && CardNumber.Length == 16)
                            {
                                CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                            }

                            if (TxnsDateTimeMain != null)
                            {
                                _DataTable.Rows.Add(MessageType
                                                , ProductID
                                                , TxnsType
                                                , FromAccountType
                                                , ToAccountType
                                                , ActionCode
                                                , ResponseCode
                                                , CardNumber.Trim()
                                                , CardType
                                                , ApprovalNumber
                                                , ReferenceNumber
                                                , TxnsDateTimeMain
                                                , MerchantCategoryCode
                                                , CardAcceptorID
                                                , TerminalId
                                                , TerminalLocation
                                                , AcquirerID
                                                , TxnsCCYCode
                                                , TrnAmount
                                                , CardHolderBillingCCY
                                                , CardHolderBillingAmount
                                                , PANEntryMode
                                                , PINEntryCapability
                                                , POSConditionCode
                                                , AcquirerCountryCode
                                                , AdditionalAmt
                                                , RuPayProduct
                                                , CVD2MatchResult
                                                , CVDICVDMatchResult
                                                , RecurringPayIndicator
                                                , ECIIndicator
                                                , ICS1ResultCode
                                                , FraudScore
                                                , EMIAmt
                                                , ARQCAuthorization
                                                , TxnsID
                                                , LoyaltyPoint
                                                , ICS2ResultCode
                                                , CustMobileNumber
                                                , ImageCode
                                                , PersonalPhase
                                                , UIDNumber
                                                , CardDataInputCapability
                                                , CardHolderAuthCapability
                                                , CardCaptureCapability
                                                , TerminalOpEnvironment
                                                , CardholderPresentData
                                                , CardPresentData
                                                , CardDataInputMode
                                                , CardHolderAuthMode
                                                , CardholderAuthEntity
                                                , CardDataOPCapability
                                                , TerminalDataCapability
                                                , PinCaptureCapability
                                                , ZipCode
                                                , AdviceReasonCode
                                                , ITPAN
                                                , INTRAUTHNW
                                                , OTPIndicator
                                                , ICSTXNID
                                                , NWDATA
                                                , ServiceCode
                                                , CCYActualTxnsAmount
                                                , ActualAmount
                                                , RevEntryLeg
                                                , Cycle
                                                , ECardNumber
                                                , CardScheme
                                                , IssuingNetwork
                                                );

                                if (_DataTable.Rows.Count >= batchSize)
                                {
                                    BatchNo++;

                                    MSG = bulkImports.BulkInsertIssuerDataPOS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                    BatchDetails batchDetails = new BatchDetails
                                    {
                                        BatchNo = BatchNo,
                                        BatchSize = batchSize,
                                        TxnUploadCount = _DataTable.Rows.Count,
                                        TxnsCount = fileImportRequest.InsertCount,
                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                        FailedCount = ErrorCount,
                                        BatchStartTime = batchStartTime,
                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                    };

                                    batchDetailsList.Add(batchDetails);
                                    _DataTable.Clear();
                                    StartTime = DateTime.Now;
                                    ErrorCount = 0;
                                    if (NewEntry)
                                    {
                                        break;
                                    }
                                }
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkImports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                        }
                    }

                    LineNo = 0;
                }
            }

                if (_DataTable.Rows.Count > 0)
                {
                    BatchNo = BatchNo + 1;

                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                    MSG = bulkImports.BulkInsertIssuerDataPOS(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                    BatchDetails batchDetails = new BatchDetails
                    {
                        BatchNo = BatchNo,
                        BatchSize = batchSize,
                        TxnUploadCount = _DataTable.Rows.Count,
                        TxnsCount = fileImportRequest.InsertCount,
                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                        FailedCount = ErrorCount,
                        BatchStartTime = batchStartTime,
                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    };

                    batchDetailsList.Add(batchDetails);

                }
                fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

                fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

                return MSG;

            }


    }
}
