﻿
using DocumentFormat.OpenXml.Drawing.Diagrams;
using DocumentFormat.OpenXml.Wordprocessing;
using System; 
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Text.Json;
using Utility;
using ImportData;
using System.Reflection;
using ASPTrace.Models;
using System.Security.Principal;

namespace NetworkNPCI
{
    public class NPCIUPI
    {
        private readonly string _connectionString;
        BulkImports bulkimports;
        public NPCIUPI(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        public string Splitter_UPI_Issuer_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            bool ErrorOccurred = false;
            int LineNo = 0;
            int LineNumber = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("UPI_TransactionID", typeof(string));
            _DataTable.Columns.Add("PayerIFSC", typeof(string));
            _DataTable.Columns.Add("PayeeIFSC", typeof(string));
            _DataTable.Columns.Add("FromACCTYPE", typeof(string));
            _DataTable.Columns.Add("ToACCTYPE", typeof(string));
            _DataTable.Columns.Add("PayerPSPCode", typeof(string));
            _DataTable.Columns.Add("PayerCode", typeof(string));
            _DataTable.Columns.Add("PayerVPA", typeof(string));
            _DataTable.Columns.Add("PayerMCC", typeof(string));
            _DataTable.Columns.Add("PayeePSPCode", typeof(string));
            _DataTable.Columns.Add("PayeeCode", typeof(string));
            _DataTable.Columns.Add("PayeeVPA", typeof(string));
            _DataTable.Columns.Add("PayeeMCC", typeof(string));
            _DataTable.Columns.Add("MapperId", typeof(string));
            _DataTable.Columns.Add("TRANSDATE", typeof(string));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));

            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string ReferenceNumber = string.Empty;
            string Response_Code = string.Empty;

            string timestamp = string.Empty;
            string Transaction_Date = string.Empty;
            string Transaction_Time = string.Empty;
            string Transaction_Amount = string.Empty;
            string ACCTUALTRANAMOUNT = string.Empty;
            string Transaction_Currency_Code = string.Empty;

            string Payer_VPA = string.Empty;
            string Payee_Code = string.Empty;
            string Payee_MCC = string.Empty;
            string Rem_Code = string.Empty;
            string REM_IFSC_CODE = string.Empty;
            string REM_ACCOUNT_NUMBER = string.Empty;
            string Bene_Code = string.Empty;
            string BENI_IFSC_CODE = string.Empty;
            string BENE_ACCOUNT_NUMBER = string.Empty;


            string UPI_TransactionID = string.Empty;
            string MapperId = string.Empty;
            string PayerCode = string.Empty;
            string PayerMCC = string.Empty;

            string PayeeVPA = string.Empty;
            string BeneAccountType = string.Empty;
            string RemitterAccountType = string.Empty;
            string ACCOUNTNO = string.Empty;


            DateTime? TxnsDateTimeMain = null;
            string[] TxnDateTimeFormat = null;
            string line1 = string.Empty;
            string Cycle = string.Empty;

            string[] SplitArr = null;

            int Incr = 1;

            string CardScheme = string.Empty;

            string SplitType = ",";

            ushort TRANSSERIALNO_CoulmnIndex = 0;
            ushort RESPONSECODE_CoulmnIndex = 0;
            ushort TRANSCURCODE_CoulmnIndex = 0;
            ushort TRANSAMOUNT_CoulmnIndex = 0;
            //ushort ACCTUALTRANSAMOUNT_CoulmnIndex = 0;

            ushort PayerVPA_CoulmnIndex = 0;
            ushort PayeeCode_CoulmnIndex = 0;
            ushort PayeeMCC_CoulmnIndex = 0;
            ushort RemCode_CoulmnIndex = 0;
            ushort REMIFSCCODE_CoulmnIndex = 0;
            ushort FROMACCOUNTTYPE_CoulmnIndex = 0;
            ushort TOACCOUNTTYPE_CoulmnIndex = 0;
            ushort BeneCode_CoulmnIndex = 0;
            ushort BENIIFSCCODE_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;

            ushort TRANSDATE_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;

            ushort UPI_TransactionID_CoulmnIndex = 0;
            ushort MapperId_CoulmnIndex = 0;
            ushort PayerCode_CoulmnIndex = 0;
            ushort PayerMCC_CoulmnIndex = 0;
            ushort PayeeVPA_CoulmnIndex = 0;

            int largestIndex = 0, CoulmnIndex = 0;
            int ErrorCount = 0, TxnAmountIsDecimal = 0;
            double temp = 0;

            try
            {

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string[] FDA = fileImportRequest.FileName.Split('_', '.');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                TRANSSERIALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                TRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                RESPONSECODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                PayeeCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeCode"]);
                PayeeMCC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeMCC"]);
                PayerVPA_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerVPA"]);
                REMIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerIFSC"]);
                BENIIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeIFSC"]);

                PayerCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerCode"]);
                PayerMCC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerMCC"]);
                PayeeVPA_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeVPA"]);

                FROMACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FROMACCTYPE"]);
                TOACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TOACCTYPE"]);

                RemCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerPSPCode"]);
                BeneCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeePSPCode"]);

                //ACCTUALTRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANAMOUNT"]);

                MapperId_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MapperId"]);
                UPI_TransactionID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UPI_TransactionID"]);


                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSDATE"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTIME"]);

                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

                TxnAmountIsDecimal = Convert.ToInt32(fileImportRequest.ConfigData.Rows[0]["TxnAmountIsDecimal"]);
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            SplitArr = new string[0];

                            SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            if (TRANSDATE_CoulmnIndex > 0 && TRANSTIME_CoulmnIndex > 0)
                            {
                                Transaction_Date = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;
                                tempTxnDateTime = Transaction_Date + " " + Transaction_Time;
                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }

                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                if (LineNo < dateStartIndex)
                                {
                                    LineNumber++;
                                    LineNo++;
                                    continue;
                                }

                                try
                                {
                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                                    SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                    if (SplitArr.Length < largestIndex) continue;

                                    LineNumber++;

                                    From_Account_Type = string.Empty; ;
                                    To_Account_Type = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    Response_Code = string.Empty;
                                    Transaction_Date = string.Empty;
                                    Transaction_Time = string.Empty;

                                    Payer_VPA = string.Empty;
                                    Payee_Code = string.Empty;
                                    Payee_MCC = string.Empty;
                                    Rem_Code = string.Empty;
                                    REM_IFSC_CODE = string.Empty;
                                    Bene_Code = string.Empty;
                                    BENI_IFSC_CODE = string.Empty;
                                    BENE_ACCOUNT_NUMBER = string.Empty;
                                    Transaction_Amount = "0";
                                    ACCTUALTRANAMOUNT = "0";

                                    UPI_TransactionID = string.Empty;
                                    MapperId = string.Empty;
                                    PayerCode = string.Empty;
                                    PayerMCC = string.Empty;


                                    PayeeVPA = string.Empty;
                                    BeneAccountType = string.Empty;
                                    RemitterAccountType = string.Empty;
                                    ACCOUNTNO = string.Empty;

                                    TxnsDateTimeMain = null;

                                    ReferenceNumber = TRANSSERIALNO_CoulmnIndex > 0 ? SplitArr[TRANSSERIALNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Date = TRANSDATE_CoulmnIndex > 0 ? SplitArr[TRANSDATE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? SplitArr[TRANSTIME_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Amount = TRANSAMOUNT_CoulmnIndex > 0 ? SplitArr[TRANSAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Response_Code = RESPONSECODE_CoulmnIndex > 0 ? SplitArr[RESPONSECODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Currency_Code = TRANSCURCODE_CoulmnIndex > 0 ? SplitArr[TRANSCURCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    REM_ACCOUNT_NUMBER = FromAccount_CoulmnIndex > 0 ? SplitArr[FromAccount_CoulmnIndex - Incr].Trim() : string.Empty;
                                    BENE_ACCOUNT_NUMBER = ToAccount_CoulmnIndex > 0 ? SplitArr[ToAccount_CoulmnIndex - Incr].Trim() : string.Empty;
                                    UPI_TransactionID = UPI_TransactionID_CoulmnIndex > 0 ? SplitArr[UPI_TransactionID_CoulmnIndex - Incr].Trim() : string.Empty;

                                    REM_IFSC_CODE = REMIFSCCODE_CoulmnIndex > 0 ? SplitArr[REMIFSCCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    BENI_IFSC_CODE = BENIIFSCCODE_CoulmnIndex > 0 ? SplitArr[BENIIFSCCODE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    From_Account_Type = FROMACCOUNTTYPE_CoulmnIndex > 0 ? SplitArr[FROMACCOUNTTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    To_Account_Type = TOACCOUNTTYPE_CoulmnIndex > 0 ? SplitArr[TOACCOUNTTYPE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    //ACCTUALTRANAMOUNT = ACCTUALTRANSAMOUNT_CoulmnIndex > 0 ? SplitArr[ACCTUALTRANSAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;


                                    PayerCode = PayerCode_CoulmnIndex > 0 ? SplitArr[PayerCode_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Payer_VPA = PayerVPA_CoulmnIndex > 0 ? SplitArr[PayerVPA_CoulmnIndex - Incr].Trim() : string.Empty;
                                    PayerMCC = PayerMCC_CoulmnIndex > 0 ? SplitArr[PayerMCC_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Rem_Code = RemCode_CoulmnIndex > 0 ? SplitArr[RemCode_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Bene_Code = BeneCode_CoulmnIndex > 0 ? SplitArr[BeneCode_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Payee_Code = PayeeCode_CoulmnIndex > 0 ? SplitArr[PayeeCode_CoulmnIndex - Incr].Trim() : string.Empty;
                                    PayeeVPA = PayeeVPA_CoulmnIndex > 0 ? SplitArr[PayeeVPA_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Payee_MCC = PayeeMCC_CoulmnIndex > 0 ? SplitArr[PayeeMCC_CoulmnIndex - Incr].Trim() : string.Empty;

                                    MapperId = MapperId_CoulmnIndex > 0 ? SplitArr[MapperId_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                                    //ACCTUALTRANAMOUNT = Common.IsNumeric(ACCTUALTRANAMOUNT) ? ACCTUALTRANAMOUNT : "0";

                                    if (TxnAmountIsDecimal > 0)
                                    {
                                        temp = Convert.ToDouble(Transaction_Amount);

                                        if (temp > 0)
                                        {
                                            Transaction_Amount = (temp / (Math.Pow((double)10, (double)TxnAmountIsDecimal))).ToString();
                                        }
                                    }

                                    if (Transaction_Date.Length > 0 && Transaction_Time.Length > 0)
                                    {
                                        timestamp = Transaction_Date + " " + Transaction_Time;
                                    }

                                    TxnsDateTimeMain = DateTime.ParseExact(timestamp, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None);

                                    if (TxnsDateTimeMain != null)
                                    {

                                        _DataTable.Rows.Add(ReferenceNumber.Trim(), TxnsDateTimeMain, Transaction_Amount, Response_Code.Trim(), Transaction_Currency_Code, REM_ACCOUNT_NUMBER.Trim(), BENE_ACCOUNT_NUMBER.Trim(), UPI_TransactionID.Trim(),
                                             REM_IFSC_CODE.Trim(), BENI_IFSC_CODE.Trim(), From_Account_Type.Trim(), To_Account_Type.Trim(), Rem_Code.Trim(), PayerCode.Trim(), PayeeVPA.Trim(), PayerMCC.Trim(), Bene_Code.Trim(), Payee_Code.Trim(), Payer_VPA.Trim(), Payee_MCC.Trim(), MapperId.Trim(),
                                              Transaction_Date.Trim(), Transaction_Time.Trim(), Cycle);


                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;

                                            MSG = bulkimports.BulkInsertIssuerDataUPITable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                            BatchDetails batchDetails = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetails);
                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }

                                    }

                                }
                                catch (Exception ex)
                                {
                                    ErrorCount++;
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                }
                            }
                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertIssuerDataUPITable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (fileImportRequest.ErrorMessage.Length == 0 && _DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }

                    }
                    else
                    {
                        BatchNo++;
                        if (tempTxnDateTime.Length > 0)
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        }
                        else
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + " File is Empty OR DateTime Format not matched;  ";
                        }
                        MSG = fileImportRequest.ErrorMessage;
                    }
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails1 = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails1);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        public string Splitter_UPI_Acquirer_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            bool ErrorOccurred = false;
            int LineNo = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("UPI_TransactionID", typeof(string));
            _DataTable.Columns.Add("PayerIFSC", typeof(string));
            _DataTable.Columns.Add("PayeeIFSC", typeof(string));
            _DataTable.Columns.Add("FromACCTYPE", typeof(string));
            _DataTable.Columns.Add("ToACCTYPE", typeof(string));
            _DataTable.Columns.Add("PayerPSPCode", typeof(string));
            _DataTable.Columns.Add("PayerCode", typeof(string));
            _DataTable.Columns.Add("PayerVPA", typeof(string));
            _DataTable.Columns.Add("PayerMCC", typeof(string));
            _DataTable.Columns.Add("PayeePSPCode", typeof(string));
            _DataTable.Columns.Add("PayeeCode", typeof(string));
            _DataTable.Columns.Add("PayeeVPA", typeof(string));
            _DataTable.Columns.Add("PayeeMCC", typeof(string));
            _DataTable.Columns.Add("MapperId", typeof(string));
            _DataTable.Columns.Add("TRANSDATE", typeof(string));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));

            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string ReferenceNumber = string.Empty;
            string Response_Code = string.Empty;

            string timestamp = string.Empty;
            string Transaction_Date = string.Empty;
            string Transaction_Time = string.Empty;
            string Transaction_Amount = string.Empty;
            string ACCTUALTRANAMOUNT = string.Empty;
            string Transaction_Currency_Code = string.Empty;

            string Payer_VPA = string.Empty;
            string Payee_Code = string.Empty;
            string Payee_MCC = string.Empty;
            string Rem_Code = string.Empty;
            string REM_IFSC_CODE = string.Empty;
            string REM_ACCOUNT_NUMBER = string.Empty;
            string Bene_Code = string.Empty;
            string BENI_IFSC_CODE = string.Empty;
            string BENE_ACCOUNT_NUMBER = string.Empty;


            string UPI_TransactionID = string.Empty;
            string MapperId = string.Empty;
            string PayerCode = string.Empty;
            string PayerMCC = string.Empty;

            string PayeeVPA = string.Empty;
            string BeneAccountType = string.Empty;
            string RemitterAccountType = string.Empty;
            string ACCOUNTNO = string.Empty;


            DateTime? TxnsDateTimeMain = null;
            string[] TxnDateTimeFormat = null;
            string line1 = string.Empty;
            string Cycle = string.Empty;

            string[] SplitArr = null;

            int Incr = 1;

            string CardScheme = string.Empty;

            string SplitType = ",";

            ushort TRANSSERIALNO_CoulmnIndex = 0;
            ushort RESPONSECODE_CoulmnIndex = 0;
            ushort TRANSCURCODE_CoulmnIndex = 0;
            ushort TRANSAMOUNT_CoulmnIndex = 0;
            //ushort ACCTUALTRANSAMOUNT_CoulmnIndex = 0;

            ushort PayerVPA_CoulmnIndex = 0;
            ushort PayeeCode_CoulmnIndex = 0;
            ushort PayeeMCC_CoulmnIndex = 0;
            ushort RemCode_CoulmnIndex = 0;
            ushort REMIFSCCODE_CoulmnIndex = 0;
            ushort FROMACCOUNTTYPE_CoulmnIndex = 0;
            ushort TOACCOUNTTYPE_CoulmnIndex = 0;
            ushort BeneCode_CoulmnIndex = 0;
            ushort BENIIFSCCODE_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;

            ushort TRANSDATE_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;

            ushort UPI_TransactionID_CoulmnIndex = 0;
            ushort MapperId_CoulmnIndex = 0;
            ushort PayerCode_CoulmnIndex = 0;
            ushort PayerMCC_CoulmnIndex = 0;
            ushort PayeeVPA_CoulmnIndex = 0;

            int largestIndex = 0, CoulmnIndex = 0, TxnAmountIsDecimal = 0;
            int ErrorCount = 0, LineNumber = 0;
            double temp = 0;

            try
            {

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string[] FDA = fileImportRequest.FileName.Split('_', '.');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                TRANSSERIALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                TRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                RESPONSECODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                PayeeCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeCode"]);
                PayeeMCC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeMCC"]);
                PayerVPA_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerVPA"]);
                REMIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerIFSC"]);
                BENIIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeIFSC"]);

                PayerCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerCode"]);
                PayerMCC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerMCC"]);
                PayeeVPA_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeVPA"]);

                FROMACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FROMACCTYPE"]);
                TOACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TOACCTYPE"]);

                RemCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerPSPCode"]);
                BeneCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeePSPCode"]);

                //ACCTUALTRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANAMOUNT"]);

                MapperId_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MapperId"]);
                UPI_TransactionID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UPI_TransactionID"]);


                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSDATE"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTIME"]);



                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

                TxnAmountIsDecimal = Convert.ToInt32(fileImportRequest.ConfigData.Rows[0]["TxnAmountIsDecimal"]);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    //Get Batch Size
                    batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            SplitArr = new string[0];

                            SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            if (TRANSDATE_CoulmnIndex > 0 && TRANSTIME_CoulmnIndex > 0)
                            {
                                Transaction_Date = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;
                                tempTxnDateTime = Transaction_Date + " " + Transaction_Time;
                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }

                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                if (LineNo < dateStartIndex)
                                {
                                    LineNumber++;
                                    LineNo++;
                                    continue;
                                }

                                LineNo++;

                                try
                                {

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }
                                    line1 = Regex.Replace(line, "[^ -~]+", string.Empty);

                                    SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                    if (SplitArr.Length < largestIndex) continue;

                                    LineNumber++;

                                    From_Account_Type = string.Empty; ;
                                    To_Account_Type = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    Response_Code = string.Empty;
                                    Transaction_Date = string.Empty;
                                    Transaction_Time = string.Empty;

                                    Payer_VPA = string.Empty;
                                    Payee_Code = string.Empty;
                                    Payee_MCC = string.Empty;
                                    Rem_Code = string.Empty;
                                    REM_IFSC_CODE = string.Empty;
                                    Bene_Code = string.Empty;
                                    BENI_IFSC_CODE = string.Empty;
                                    BENE_ACCOUNT_NUMBER = string.Empty;
                                    Transaction_Amount = "0";
                                    ACCTUALTRANAMOUNT = "0";

                                    UPI_TransactionID = string.Empty;
                                    MapperId = string.Empty;
                                    PayerCode = string.Empty;
                                    PayerMCC = string.Empty;


                                    PayeeVPA = string.Empty;
                                    BeneAccountType = string.Empty;
                                    RemitterAccountType = string.Empty;
                                    ACCOUNTNO = string.Empty;

                                    TxnsDateTimeMain = null;

                                    ReferenceNumber = TRANSSERIALNO_CoulmnIndex > 0 ? SplitArr[TRANSSERIALNO_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Date = TRANSDATE_CoulmnIndex > 0 ? SplitArr[TRANSDATE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? SplitArr[TRANSTIME_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Amount = TRANSAMOUNT_CoulmnIndex > 0 ? SplitArr[TRANSAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Response_Code = RESPONSECODE_CoulmnIndex > 0 ? SplitArr[RESPONSECODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Transaction_Currency_Code = TRANSCURCODE_CoulmnIndex > 0 ? SplitArr[TRANSCURCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    REM_ACCOUNT_NUMBER = FromAccount_CoulmnIndex > 0 ? SplitArr[FromAccount_CoulmnIndex - Incr].Trim() : string.Empty;
                                    BENE_ACCOUNT_NUMBER = ToAccount_CoulmnIndex > 0 ? SplitArr[ToAccount_CoulmnIndex - Incr].Trim() : string.Empty;
                                    UPI_TransactionID = UPI_TransactionID_CoulmnIndex > 0 ? SplitArr[UPI_TransactionID_CoulmnIndex - Incr].Trim() : string.Empty;

                                    REM_IFSC_CODE = REMIFSCCODE_CoulmnIndex > 0 ? SplitArr[REMIFSCCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    BENI_IFSC_CODE = BENIIFSCCODE_CoulmnIndex > 0 ? SplitArr[BENIIFSCCODE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    From_Account_Type = FROMACCOUNTTYPE_CoulmnIndex > 0 ? SplitArr[FROMACCOUNTTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                                    To_Account_Type = TOACCOUNTTYPE_CoulmnIndex > 0 ? SplitArr[TOACCOUNTTYPE_CoulmnIndex - Incr].Trim() : string.Empty;

                                    //ACCTUALTRANAMOUNT = ACCTUALTRANSAMOUNT_CoulmnIndex > 0 ? SplitArr[ACCTUALTRANSAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;


                                    PayerCode = PayerCode_CoulmnIndex > 0 ? SplitArr[PayerCode_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Payer_VPA = PayerVPA_CoulmnIndex > 0 ? SplitArr[PayerVPA_CoulmnIndex - Incr].Trim() : string.Empty;
                                    PayerMCC = PayerMCC_CoulmnIndex > 0 ? SplitArr[PayerMCC_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Rem_Code = RemCode_CoulmnIndex > 0 ? SplitArr[RemCode_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Bene_Code = BeneCode_CoulmnIndex > 0 ? SplitArr[BeneCode_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Payee_Code = PayeeCode_CoulmnIndex > 0 ? SplitArr[PayeeCode_CoulmnIndex - Incr].Trim() : string.Empty;
                                    PayeeVPA = PayeeVPA_CoulmnIndex > 0 ? SplitArr[PayeeVPA_CoulmnIndex - Incr].Trim() : string.Empty;
                                    Payee_MCC = PayeeMCC_CoulmnIndex > 0 ? SplitArr[PayeeMCC_CoulmnIndex - Incr].Trim() : string.Empty;

                                    MapperId = MapperId_CoulmnIndex > 0 ? SplitArr[MapperId_CoulmnIndex - Incr].Trim() : string.Empty;

                                    Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                                    //ACCTUALTRANAMOUNT = Common.IsNumeric(ACCTUALTRANAMOUNT) ? ACCTUALTRANAMOUNT : "0";

                                    if (TxnAmountIsDecimal > 0)
                                    {
                                        temp = Convert.ToDouble(Transaction_Amount);

                                        if (temp > 0)
                                        {
                                            Transaction_Amount = (temp / (Math.Pow((double)10, (double)TxnAmountIsDecimal))).ToString();
                                        }
                                    }

                                    if (Transaction_Date.Length > 0 && Transaction_Time.Length > 0)
                                    {
                                        timestamp = Transaction_Date + " " + Transaction_Time;
                                    }

                                    TxnsDateTimeMain = DateTime.ParseExact(timestamp, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None);

                                    if (TxnsDateTimeMain != null)
                                    {

                                        _DataTable.Rows.Add(ReferenceNumber.Trim(), TxnsDateTimeMain, Transaction_Amount, Response_Code.Trim(), Transaction_Currency_Code, REM_ACCOUNT_NUMBER.Trim(), BENE_ACCOUNT_NUMBER.Trim(), UPI_TransactionID.Trim(),
                                             REM_IFSC_CODE.Trim(), BENI_IFSC_CODE.Trim(), From_Account_Type.Trim(), To_Account_Type.Trim(), Rem_Code.Trim(), PayerCode.Trim(), PayeeVPA.Trim(), PayerMCC.Trim(), Bene_Code.Trim(), Payee_Code.Trim(), Payer_VPA.Trim(), Payee_MCC.Trim(), MapperId.Trim(),
                                              Transaction_Date.Trim(), Transaction_Time.Trim(), Cycle);


                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;

                                            MSG = bulkimports.BulkInsertAcquirerDataUPITable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);
                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }

                                    }

                                }
                                catch (Exception ex)
                                {
                                    ErrorCount++;
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                }
                            }
                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo = BatchNo + 1;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertAcquirerDataUPITable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (fileImportRequest.ErrorMessage.Length == 0 && _DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        if (tempTxnDateTime.Length > 0)
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        }
                        else
                        {
                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + " File is Empty OR DateTime Format not matched;  ";
                        }
                        MSG = fileImportRequest.ErrorMessage;
                    }
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }

            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        //Splitter for UPI Outward Delimiter
        public string Splitter_UPI_Acquirer_Delimiter_Dynamic1(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            bool ErrorOccurred = false;
            int LineNo = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("AccountNo", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNO", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSDATE", typeof(string));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("UMN", typeof(string));//new column
            _DataTable.Columns.Add("InitiationMode", typeof(string));
            _DataTable.Columns.Add("PurposeCode", typeof(string));
            _DataTable.Columns.Add("PayerCode", typeof(string));
            _DataTable.Columns.Add("PayerVPA", typeof(string));
            _DataTable.Columns.Add("PayeeCode", typeof(string));
            _DataTable.Columns.Add("PayeeMCC", typeof(string));
            _DataTable.Columns.Add("RemCode", typeof(string));
            _DataTable.Columns.Add("REMIFSCCODE", typeof(string));
            _DataTable.Columns.Add("RemitterAccountType", typeof(string));
            _DataTable.Columns.Add("BeneCode", typeof(string));
            _DataTable.Columns.Add("BENIIFSCCODE", typeof(string));
            _DataTable.Columns.Add("BeneAccountType", typeof(string));
            _DataTable.Columns.Add("BENEACCOUNTNUMBER", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));
            _DataTable.Columns.Add("PayeeVPA", typeof(string));


            _DataTable.Columns.Add("PayerMCC", typeof(string));
            _DataTable.Columns.Add("UPI_TransactionID", typeof(string));
            _DataTable.Columns.Add("MapperId", typeof(string));

            //[InitiationMode][varchar](100) NULL,
            //[PurposeCode][varchar](100) NULL,
            //[PayerCode][varchar](100) NULL,
            //[PayerVPA][varchar](100) NULL,
            //[PayeeCode][varchar](100) NULL,
            //[PayeeMCC][varchar](100) NULL,
            //[RemCode][varchar](100) NULL,
            //[REMIFSCCODE][varchar](100) NULL,
            //[RemitterAccountType][varchar](100) NULL,
            //[BeneCode][varchar](100) NULL,
            //[BENIIFSCCODE][varchar](100) NULL,
            //[BeneAccountType][varchar](100) NULL,
            //[BENEACCOUNTNUMBER][varchar](100) NULL,
            //[CardScheme][varchar](100) NULL,
            //[IssuingNetwork][varchar](100) NULL,
            //[PayeeVPA][varchar](100) NULL,
            //[PayerMCC][varchar](100) NULL,
            //[UPI_TransactionID][varchar](100) NULL,
            //[MapperId][varchar](100) NULL




            int Incr = 1;
            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string MEMNUMBER = string.Empty;
            string Approval_Number = string.Empty;
            string SYSTRACAUDITNO = "0";
            string Transaction_Time = string.Empty;
            string TxnDate = string.Empty;
            string Merchant_Category_Code = string.Empty;
            string CARDACCEPTSETDATE = "0";
            string CARDACCID = string.Empty;
            string Card_Acceptor_ID = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string Acquirer_ID = string.Empty;
            string ACCSETDATE = "0";
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = string.Empty;
            string ACCTUALTRANSAMOUNT = string.Empty;
            string TRANSACTIVITYFEE = "0";
            string ACCURSETCURCODE = string.Empty;
            string ACQUIERSETAMOUNT = "0";
            string ACQUIERSETFEE = "0";
            string ACQUIERSETPROFEEE = "0";
            string TRANSACQUIERCONVERRATE = "0";
            int FORCEMATCH = 0;
            string UMN = string.Empty;
            string Initiation_Mode = string.Empty;
            string Purpose_Code = string.Empty;
            string Payer_Code = string.Empty;
            string Payer_VPA = string.Empty;
            string Payee_Code = string.Empty;
            string Payee_MCC = string.Empty;
            string Rem_Code = string.Empty;
            string REM_IFSC_CODE = string.Empty;
            string Remitter_Account_Type = string.Empty;
            string Bene_Code = string.Empty;
            string BENI_IFSC_CODE = string.Empty;
            string Bene_Account_Type = string.Empty;
            string BENE_ACCOUNT_NUMBER = string.Empty;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";
            string timestamp = string.Empty;

            string AccountNo = string.Empty;
            string PayeeVPA = string.Empty;

            string PayerMCC = string.Empty;
            string UPI_TransactionID = string.Empty;
            string MapperId = string.Empty;


            DateTime? TxnsDateTimeMain = null;

            string[] SplitArr = null;
            string[] TxnDateTime = null;
            string line1 = string.Empty;
            string Cycle = string.Empty;

            ushort PARTICIPENTID_CoulmnIndex = 0;
            ushort TRANSTYPE_CoulmnIndex = 0;
            ushort TRANSSERIALNO_CoulmnIndex = 0;
            ushort RESPONSECODE_CoulmnIndex = 0;
            ushort PANNO_CoulmnIndex = 0;
            ushort MEMNUMBER_CoulmnIndex = 0;
            ushort APPROVALNO_CoulmnIndex = 0;
            ushort TRANSDATE_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;
            ushort TRANSCURCODE_CoulmnIndex = 0;
            ushort TRANSAMOUNT_CoulmnIndex = 0;
            ushort ACCTUALTRANSAMOUNT_CoulmnIndex = 0;
            ushort UMN_CoulmnIndex = 0;
            ushort InitiationMode_CoulmnIndex = 0;
            ushort PurposeCode_CoulmnIndex = 0;
            ushort PayerVPA_CoulmnIndex = 0;
            ushort PayeeCode_CoulmnIndex = 0;
            ushort PayeeMCC_CoulmnIndex = 0;
            ushort PayerCode_CoulmnIndex = 0;
            ushort RemCode_CoulmnIndex = 0;
            ushort REMIFSCCODE_CoulmnIndex = 0;
            ushort RemitterAccountType_CoulmnIndex = 0;
            ushort BeneCode_CoulmnIndex = 0;
            ushort BENIIFSCCODE_CoulmnIndex = 0;
            ushort BENEACCOUNTNUMBER_CoulmnIndex = 0;
            ushort ACCURSETCURCODE_CoulmnIndex = 0;
            ushort ACQUIERSETAMOUNT_CoulmnIndex = 0;
            ushort ACQUIERSETFEE_CoulmnIndex = 0;
            ushort ACQUIERSETPROFEE_CoulmnIndex = 0;
            ushort CARDACCEPTERTERLOC_CoulmnIndex = 0;
            ushort CARDACCEPTERSETDATE_CoulmnIndex = 0;
            ushort CARDACCEPTERID_CoulmnIndex = 0;

            ushort AccountNo_CoulmnIndex = 0;
            ushort PayeeVPA_CoulmnIndex = 0;


            ushort PayerMCC_CoulmnIndex = 0;
            ushort UPI_TransactionID_CoulmnIndex = 0;
            ushort MapperId_CoulmnIndex = 0;

            int ErrorCount = 0, Line = 0;
            int largestIndex = 0, CoulmnIndex = 0;

            try
            {
                DataSet ds = new DataSet();

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string[] FDA = fileImportRequest.FileName.Split('_', '.');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);


                PARTICIPENTID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PARTICIPENTID"]);
                TRANSTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTYPE"]);
                TRANSSERIALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSSERIALNO"]);
                RESPONSECODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RESPONSECODE"]);
                PANNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PANNO"]);
                MEMNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MEMNUMBER"]);
                APPROVALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["APPROVALNO"]);
                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSDATE"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTIME"]);
                TRANSCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSCURCODE"]);
                TRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSAMOUNT"]);
                ACCTUALTRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANSAMOUNT"]);
                UMN_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UMN"]);
                InitiationMode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InitiationMode"]);
                PurposeCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PurposeCode"]);
                PayerVPA_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerVPA"]);
                PayeeCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeCode"]);
                PayeeMCC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeMCC"]);
                PayerCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerCode"]);
                RemCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RemCode"]);
                REMIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["REMIFSCCODE"]);
                RemitterAccountType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RemitterAccountType"]);
                BeneCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneCode"]);
                BENIIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BENIIFSCCODE"]);
                BENEACCOUNTNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BENEACCOUNTNUMBER"]);
                ACCURSETCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCURSETCURCODE"]);
                ACQUIERSETAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETAMOUNT"]);
                ACQUIERSETFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETFEE"]);
                ACQUIERSETPROFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETPROFEE"]);
                CARDACCEPTERTERLOC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERTERLOC"]);
                CARDACCEPTERSETDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERSETDATE"]);
                CARDACCEPTERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERID"]);
                AccountNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AccountNo"]);
                PayeeVPA_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeVPA"]);


                PayerMCC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerMCC"]);
                UPI_TransactionID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UPI_TransactionID"]);
                MapperId_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MapperId"]);

                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                foreach (var batchDetail in fileImportRequest.FailedBatches)
                {
                    if (batchDetail.BatchNo != 0)
                    {
                        BatchNo = batchDetail.BatchNo - 1;
                    }


                    bool NewEntry = false;

                    if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                    {
                        //set the flag if it is new Entry
                        NewEntry = false;
                    }
                    else
                    {
                        if (batchDetail.BatchStatus == "None")
                        {
                            break;
                        }
                        else
                        {
                            //set the flag if it is old and  Partial Entry
                            NewEntry = true;
                        }
                    }
                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {

                        try
                        {
                            LineNo++;

                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                            {
                                continue;
                            }

                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            if (SplitArr.Length < largestIndex) continue;

                            Line++;

                            Participant_ID = string.Empty;
                            Transaction_Type = string.Empty;
                            From_Account_Type = string.Empty;
                            To_Account_Type = string.Empty;
                            Transaction_Serial_Number = string.Empty;
                            Response_Code = string.Empty;
                            PAN_Number = string.Empty;
                            MEMNUMBER = string.Empty;
                            Approval_Number = string.Empty;
                            Transaction_Time = string.Empty;
                            TxnDate = string.Empty;

                            CARDACCID = string.Empty;
                            Card_Acceptor_ID = string.Empty;
                            CARDACCEPTERTERLOC = string.Empty;
                            Acquirer_ID = string.Empty;
                            Transaction_Currency_Code = string.Empty;
                            Transaction_Amount = string.Empty;
                            ACCTUALTRANSAMOUNT = string.Empty;
                            ACCURSETCURCODE = string.Empty;

                            UMN = string.Empty;
                            Initiation_Mode = string.Empty;
                            Purpose_Code = string.Empty;
                            Payer_Code = string.Empty;
                            Payer_VPA = string.Empty;
                            Payee_Code = string.Empty;
                            Payee_MCC = string.Empty;
                            Rem_Code = string.Empty;
                            REM_IFSC_CODE = string.Empty;
                            Remitter_Account_Type = string.Empty;
                            Bene_Code = string.Empty;
                            BENI_IFSC_CODE = string.Empty;
                            Bene_Account_Type = string.Empty;
                            BENE_ACCOUNT_NUMBER = string.Empty;
                            timestamp = string.Empty;

                            SYSTRACAUDITNO = "0";
                            Merchant_Category_Code = "0";
                            CARDACCEPTSETDATE = "0";
                            ACCSETDATE = "0";
                            ACCTUALTRANSAMOUNT = "0";
                            TRANSACTIVITYFEE = "0";

                            ACQUIERSETAMOUNT = "0";
                            ACQUIERSETFEE = "0";
                            ACQUIERSETPROFEEE = "0";
                            TRANSACQUIERCONVERRATE = "0";

                            AccountNo = "0";
                            PayeeVPA = "0";


                            PayerMCC = string.Empty;
                            UPI_TransactionID = string.Empty;
                            MapperId = string.Empty;

                            TxnsDateTimeMain = null;



                            Participant_ID = PARTICIPENTID_CoulmnIndex > 0 ? SplitArr[PARTICIPENTID_CoulmnIndex - Incr].Trim() : string.Empty;
                            Transaction_Type = TRANSTYPE_CoulmnIndex > 0 ? SplitArr[TRANSTYPE_CoulmnIndex - Incr].Trim() : string.Empty;
                            Transaction_Serial_Number = TRANSSERIALNO_CoulmnIndex > 0 ? SplitArr[TRANSSERIALNO_CoulmnIndex - Incr].Trim() : string.Empty;
                            Response_Code = RESPONSECODE_CoulmnIndex > 0 ? SplitArr[RESPONSECODE_CoulmnIndex - Incr].Trim() : string.Empty;
                            PAN_Number = PANNO_CoulmnIndex > 0 ? SplitArr[PANNO_CoulmnIndex - Incr].Trim() : string.Empty;
                            MEMNUMBER = MEMNUMBER_CoulmnIndex > 0 ? SplitArr[MEMNUMBER_CoulmnIndex - Incr].Trim() : string.Empty;
                            Approval_Number = APPROVALNO_CoulmnIndex > 0 ? SplitArr[APPROVALNO_CoulmnIndex - Incr].Trim() : string.Empty;
                            TxnDate = TRANSDATE_CoulmnIndex > 0 ? SplitArr[TRANSDATE_CoulmnIndex - Incr].Trim() : string.Empty;
                            Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? SplitArr[TRANSTIME_CoulmnIndex - Incr].Trim() : string.Empty;
                            Transaction_Currency_Code = TRANSCURCODE_CoulmnIndex > 0 ? SplitArr[TRANSCURCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                            Transaction_Amount = TRANSAMOUNT_CoulmnIndex > 0 ? SplitArr[TRANSAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                            ACCTUALTRANSAMOUNT = ACCTUALTRANSAMOUNT_CoulmnIndex > 0 ? SplitArr[ACCTUALTRANSAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                            UMN = UMN_CoulmnIndex > 0 ? SplitArr[UMN_CoulmnIndex - Incr].Trim() : string.Empty;
                            Initiation_Mode = InitiationMode_CoulmnIndex > 0 ? SplitArr[InitiationMode_CoulmnIndex - Incr].Trim() : string.Empty;

                            Purpose_Code = PurposeCode_CoulmnIndex > 0 ? SplitArr[PurposeCode_CoulmnIndex - Incr].Trim() : string.Empty;
                            Payer_VPA = PayerVPA_CoulmnIndex > 0 ? SplitArr[PayerVPA_CoulmnIndex - Incr].Trim() : string.Empty;
                            Payee_Code = PayeeCode_CoulmnIndex > 0 ? SplitArr[PayeeCode_CoulmnIndex - Incr].Trim() : string.Empty;
                            Payee_MCC = PayeeMCC_CoulmnIndex > 0 ? SplitArr[PayeeMCC_CoulmnIndex - Incr].Trim() : string.Empty;
                            Payer_Code = PayerCode_CoulmnIndex > 0 ? SplitArr[PayerCode_CoulmnIndex - Incr].Trim() : string.Empty;
                            Rem_Code = RemCode_CoulmnIndex > 0 ? SplitArr[RemCode_CoulmnIndex - Incr].Trim() : string.Empty;
                            REM_IFSC_CODE = REMIFSCCODE_CoulmnIndex > 0 ? SplitArr[REMIFSCCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                            Remitter_Account_Type = RemitterAccountType_CoulmnIndex > 0 ? SplitArr[RemitterAccountType_CoulmnIndex - Incr].Trim() : string.Empty;
                            Bene_Code = BeneCode_CoulmnIndex > 0 ? SplitArr[BeneCode_CoulmnIndex - Incr].Trim() : string.Empty;
                            BENI_IFSC_CODE = BENIIFSCCODE_CoulmnIndex > 0 ? SplitArr[BENIIFSCCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                            BENE_ACCOUNT_NUMBER = BENEACCOUNTNUMBER_CoulmnIndex > 0 ? SplitArr[BENEACCOUNTNUMBER_CoulmnIndex - Incr].Trim() : string.Empty;

                            ACCURSETCURCODE = ACCURSETCURCODE_CoulmnIndex > 0 ? SplitArr[ACCURSETCURCODE_CoulmnIndex - Incr].Trim() : string.Empty;
                            ACQUIERSETAMOUNT = ACQUIERSETAMOUNT_CoulmnIndex > 0 ? SplitArr[ACQUIERSETAMOUNT_CoulmnIndex - Incr].Trim() : string.Empty;
                            ACQUIERSETFEE = ACQUIERSETFEE_CoulmnIndex > 0 ? SplitArr[ACQUIERSETFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                            ACQUIERSETPROFEEE = ACQUIERSETPROFEE_CoulmnIndex > 0 ? SplitArr[ACQUIERSETPROFEE_CoulmnIndex - Incr].Trim() : string.Empty;
                            CARDACCEPTERTERLOC = CARDACCEPTERTERLOC_CoulmnIndex > 0 ? SplitArr[CARDACCEPTERTERLOC_CoulmnIndex - Incr].Trim() : string.Empty;
                            CARDACCEPTSETDATE = CARDACCEPTERSETDATE_CoulmnIndex > 0 ? SplitArr[CARDACCEPTERSETDATE_CoulmnIndex - Incr].Trim() : string.Empty;
                            Card_Acceptor_ID = CARDACCEPTERID_CoulmnIndex > 0 ? SplitArr[CARDACCEPTERID_CoulmnIndex - Incr].Trim() : string.Empty;


                            AccountNo = AccountNo_CoulmnIndex > 0 ? SplitArr[AccountNo_CoulmnIndex - Incr].Trim() : string.Empty;
                            PayeeVPA = PayeeVPA_CoulmnIndex > 0 ? SplitArr[PayeeVPA_CoulmnIndex - Incr].Trim() : string.Empty;


                            PayerMCC = PayerMCC_CoulmnIndex > 0 ? SplitArr[PayerMCC_CoulmnIndex - Incr].Trim() : string.Empty;
                            UPI_TransactionID = UPI_TransactionID_CoulmnIndex > 0 ? SplitArr[UPI_TransactionID_CoulmnIndex - Incr].Trim() : string.Empty;
                            MapperId = MapperId_CoulmnIndex > 0 ? SplitArr[MapperId_CoulmnIndex - Incr].Trim() : string.Empty;

                            Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                            ACCTUALTRANSAMOUNT = Common.IsNumeric(ACCTUALTRANSAMOUNT) ? ACCTUALTRANSAMOUNT : "0";
                            TRANSACTIVITYFEE = Common.IsNumeric(TRANSACTIVITYFEE) ? TRANSACTIVITYFEE : "0";
                            ACQUIERSETAMOUNT = Common.IsNumeric(ACQUIERSETAMOUNT) ? ACQUIERSETAMOUNT : "0";
                            ACQUIERSETFEE = Common.IsNumeric(ACQUIERSETFEE) ? ACQUIERSETFEE : "0";
                            ACQUIERSETPROFEEE = Common.IsNumeric(ACQUIERSETPROFEEE) ? ACQUIERSETPROFEEE : "0";
                            TRANSACQUIERCONVERRATE = Common.IsNumeric(TRANSACQUIERCONVERRATE) ? TRANSACQUIERCONVERRATE : "0";
                            CARDACCEPTSETDATE = Common.IsNumeric(CARDACCEPTSETDATE) ? CARDACCEPTSETDATE : "0";
                            SYSTRACAUDITNO = Common.IsNumeric(SYSTRACAUDITNO) ? SYSTRACAUDITNO : "0";
                            Merchant_Category_Code = Common.IsNumeric(Merchant_Category_Code) ? Merchant_Category_Code : "0";
                            ACCSETDATE = Common.IsNumeric(ACCSETDATE) ? ACCSETDATE : "0";

                            if (TxnDate.Length > 0 && Transaction_Time.Length > 0)
                            {
                                timestamp = TxnDate + " " + Transaction_Time;
                            }

                            TxnsDateTimeMain = DateTime.ParseExact(timestamp, TxnDateTime, CultureInfo.InvariantCulture);

                            if (TxnsDateTimeMain != null)
                            {

                                _DataTable.Rows.Add(Participant_ID.Trim(), Transaction_Type.Trim(), AccountNo.Trim(), From_Account_Type.Trim(), To_Account_Type.Trim(), Transaction_Serial_Number.Trim(), Response_Code.Trim(), PAN_Number.Trim(), MEMNUMBER.Trim(),
                        Approval_Number.Trim(), SYSTRACAUDITNO.Trim(), TxnsDateTimeMain, TxnDate, Transaction_Time, Merchant_Category_Code.Trim(), CARDACCEPTSETDATE.Trim(), CARDACCID.Trim(), Card_Acceptor_ID.Trim(), CARDACCEPTERTERLOC.Trim(),
                        Acquirer_ID.Trim(), ACCSETDATE.Trim(), Transaction_Currency_Code.Trim(), Transaction_Amount.Trim(), ACCTUALTRANSAMOUNT.Trim(), TRANSACTIVITYFEE.Trim(), ACCURSETCURCODE.Trim(), ACQUIERSETAMOUNT.Trim(), ACQUIERSETFEE.Trim(),
                        ACQUIERSETPROFEEE.Trim(), TRANSACQUIERCONVERRATE.Trim(), FORCEMATCH, Cycle.Trim(), UMN.Trim(), Initiation_Mode.Trim(), Purpose_Code.Trim(), Payer_Code.Trim(), Payer_VPA.Trim(), Payee_Code.Trim(), Payee_MCC.Trim(), Rem_Code.Trim(), REM_IFSC_CODE.Trim(), Remitter_Account_Type.Trim(),
                        Bene_Code.Trim(), BENI_IFSC_CODE.Trim(), Bene_Account_Type.Trim(), BENE_ACCOUNT_NUMBER.Trim(), CardScheme, IssuingNetwork, PayeeVPA.Trim(), PayerMCC.Trim(), UPI_TransactionID.Trim(), MapperId.Trim());


                                if (_DataTable.Rows.Count >= batchSize)
                                {
                                    BatchNo++;

                                    MSG = bulkimports.BulkInsertAcquirerDataUPITable(_DataTable, DTdetails.ConfigID, "0");
                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                    //  _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);

                                    BatchDetails batchDetails = new BatchDetails
                                    {
                                        BatchNo = BatchNo,
                                        BatchSize = batchSize,
                                        TxnUploadCount = _DataTable.Rows.Count,
                                        TxnsCount = fileImportRequest.InsertCount,
                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                        FailedCount = ErrorCount,
                                        BatchStartTime = batchStartTime,
                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                    };

                                    batchDetailsList.Add(batchDetails);
                                    _DataTable.Clear();
                                    StartTime = DateTime.Now;
                                    ErrorCount = 0;
                                    if (NewEntry)
                                    {
                                        break;
                                    }
                                }

                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                        }
                    }

                    LineNo = 0;
                }
                fileImportRequest.TotalCount = Line;
            }

            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkimports.BulkInsertAcquirerDataUPITable(_DataTable, DTdetails.ConfigID, "0");
                // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                // _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";


            return MSG;
        }

        //Splitter for UPI Inward Excel
        public string Splitter_UPI_Issuer_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            bool ErrorOccurred = false;
            int SheetLineNo = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("PARICIPATEID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCOUNTTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNUMBER", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVNO", typeof(string));
            _DataTable.Columns.Add("STAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSACTIONDATE", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONTIME", typeof(string));
            _DataTable.Columns.Add("MERCHENTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTORID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTTERMINALID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOCATION", typeof(string));
            _DataTable.Columns.Add("ACQUIRERID", typeof(string));
            _DataTable.Columns.Add("NETWORKID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO1", typeof(string));
            _DataTable.Columns.Add("ACCOUNTBRANCHID", typeof(string));
            _DataTable.Columns.Add("ACCOUNTNO2", typeof(string));
            _DataTable.Columns.Add("ACCOUNT2BRANCHID", typeof(string));
            _DataTable.Columns.Add("TRANSCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACCVITYFEE", typeof(string));
            _DataTable.Columns.Add("ISSUERSETCURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ISSURESETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ISSUERSETFEE", typeof(string));
            _DataTable.Columns.Add("ISSURESETPROCFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLCURNCCODE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILLAMOUNT", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILACTFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILPROFEE", typeof(string));
            _DataTable.Columns.Add("CARDHOLDERBILSRVICEFEE", typeof(string));
            _DataTable.Columns.Add("TRAN_ISSUERCONVERSRATE", typeof(string));
            _DataTable.Columns.Add("TRANS_CARDHOLDERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("UMN", typeof(string));//new column
            _DataTable.Columns.Add("InitiationMode", typeof(string));
            _DataTable.Columns.Add("PurposeCode", typeof(string));
            _DataTable.Columns.Add("PayerVPA", typeof(string));
            _DataTable.Columns.Add("PayeeCode", typeof(string));
            _DataTable.Columns.Add("PayeeMCC", typeof(string));
            _DataTable.Columns.Add("RemCode", typeof(string));
            _DataTable.Columns.Add("REMIFSCCODE", typeof(string));
            _DataTable.Columns.Add("REMACCOUNTNUMBER", typeof(string));
            _DataTable.Columns.Add("BeneCode", typeof(string));
            _DataTable.Columns.Add("BENIIFSCCODE", typeof(string));
            _DataTable.Columns.Add("BENEACCOUNTNUMBER", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string MEMNUMBER = string.Empty;
            string Approval_Number = string.Empty;
            string STAUDITNO = "0";
            string timestamp = string.Empty;
            string Transaction_Date = string.Empty;
            string Transaction_Time = string.Empty;

            string Merchant_Category_Code = string.Empty;

            string CARDACCEPTSETDATE = "0";
            string Card_Acceptor_ID = string.Empty;
            string CARDACCEPTTERMINALID = string.Empty;
            string CARDACCEPTERTERLOCATION = string.Empty;
            string Acquirer_ID = string.Empty;
            string NETWORKID = string.Empty;
            string ACCOUNTNO1 = string.Empty;
            string ACCOUNTBRANCHID = string.Empty;
            string ACCOUNTNO2 = string.Empty;
            string ACCOUNT2BRANCHID = string.Empty;
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = "0";
            string ACCTUALTRANAMOUNT = "0";
            string TRANSACCVITYFEE = "0";
            string ISSUERSETCURRENCYCODE = string.Empty;
            string ISSURESETAMOUNT = "0";
            string ISSUERSETFEE = "0";
            string ISSURESETPROCFEE = "0";
            string CARDHOLDERBILLCURNCCODE = string.Empty;
            string CARDHOLDERBILLAMOUNT = "0";
            string CARDHOLDERBILACTFEE = "0";
            string CARDHOLDERBILPROFEE = "0";
            string CARDHOLDERBILSRVICEFEE = "0";
            string TRAN_ISSUERCONVERSRATE = "0";
            string TRANS_CARDHOLDERCONVERRATE = "0";
            int FORCEMATCH = 0;
            string UMN = string.Empty;
            string Initiation_Mode = string.Empty;
            string Purpose_Code = string.Empty;
            string Payer_VPA = string.Empty;
            string Payee_Code = string.Empty;
            string Payee_MCC = string.Empty;
            string Rem_Code = string.Empty;
            string REM_IFSC_CODE = string.Empty;
            string REM_ACCOUNT_NUMBER = string.Empty;
            string Bene_Code = string.Empty;
            string BENI_IFSC_CODE = string.Empty;
            string BENE_ACCOUNT_NUMBER = string.Empty;

            DateTime? TxnsDateTimeMain = null;
            string[] TxnDateTimeFormat = null;
            string line1 = string.Empty;
            string Cycle = string.Empty;

            int Incr = 1;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";

            string SplitType = ",";

            ushort PARTICIPENTID_CoulmnIndex = 0;
            ushort TRANSTYPE_CoulmnIndex = 0;
            ushort FROMACCOUNTTYPE_CoulmnIndex = 0;
            ushort TOACCOUNTTYPE_CoulmnIndex = 0;
            ushort TRANSSERIALNO_CoulmnIndex = 0;
            ushort RESPONSECODE_CoulmnIndex = 0;
            ushort REMACCOUNTNUMBER_CoulmnIndex = 0;
            ushort MEMNUMBER_CoulmnIndex = 0;
            ushort APPROVALNO_CoulmnIndex = 0;
            ushort STAUDITNO_CoulmnIndex = 0;
            ushort TRANSDATE_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;
            ushort MERCHENTCATCODE_CoulmnIndex = 0;
            ushort CARDACCEPTERSETDATE_CoulmnIndex = 0;
            ushort CARDACCEPTERID_CoulmnIndex = 0;
            ushort CARDACCEPTTERMINALID_CoulmnIndex = 0;
            ushort CARDACCEPTERTERLOCATION_CoulmnIndex = 0;


            ushort ACQUIRERID_CoulmnIndex = 0;
            ushort NETWORKID_CoulmnIndex = 0;
            ushort ACCOUNTNO1_CoulmnIndex = 0;
            ushort ACCOUNTBRANCHID_CoulmnIndex = 0;
            ushort ACCOUNTNO2_CoulmnIndex = 0;
            ushort ACCOUNT2BRANCHID_CoulmnIndex = 0;

            ushort TRANSCURCODE_CoulmnIndex = 0;
            ushort TRANSAMOUNT_CoulmnIndex = 0;
            ushort ACCTUALTRANSAMOUNT_CoulmnIndex = 0;
            ushort UMN_CoulmnIndex = 0;
            ushort InitiationMode_CoulmnIndex = 0;
            ushort PurposeCode_CoulmnIndex = 0;
            ushort PayerVPA_CoulmnIndex = 0;
            ushort PayeeCode_CoulmnIndex = 0;
            ushort PayeeMCC_CoulmnIndex = 0;
            ushort RemCode_CoulmnIndex = 0;
            ushort REMIFSCCODE_CoulmnIndex = 0;

            ushort BeneCode_CoulmnIndex = 0;
            ushort BENIIFSCCODE_CoulmnIndex = 0;
            ushort BENEACCOUNTNUMBER_CoulmnIndex = 0;

            ushort TRANSACCVITYFEE_CoulmnIndex = 0;
            ushort ISSUERSETCURRENCYCODE_CoulmnIndex = 0;
            ushort ISSURESETAMOUNT_CoulmnIndex = 0;
            ushort ISSUERSETFEE_CoulmnIndex = 0;
            ushort ISSURESETPROCFEE_CoulmnIndex = 0;

            ushort CARDHOLDERBILLCURNCCODE_CoulmnIndex = 0;
            ushort CARDHOLDERBILLAMOUNT_CoulmnIndex = 0;
            ushort CARDHOLDERBILACTFEE_CoulmnIndex = 0;
            ushort CARDHOLDERBILPROFEE_CoulmnIndex = 0;
            ushort CARDHOLDERBILSRVICEFEE_CoulmnIndex = 0;
            ushort TRAN_ISSUERCONVERSRATE_CoulmnIndex = 0;
            ushort TRANS_CARDHOLDERCONVERRATE_CoulmnIndex = 0;

            int ErrorCount = 0, LineNo = 0;

            string conString = string.Empty;
            DataTable dtexcelsheetname = new DataTable();
            DataTable dtSheet = new DataTable();

            try
            {
                TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string[] FDA = fileImportRequest.FileName.Split('_', '.');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                PARTICIPENTID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PARICIPATEID"]);
                TRANSTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONTYPE"]);
                FROMACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FROMACCOUNTTYPE"]);
                TOACCOUNTTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TOACCOUNTTYPE"]);
                TRANSSERIALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSSERIALNO"]);
                RESPONSECODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RESPONSECODE"]);
                REMACCOUNTNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["REMACCOUNTNUMBER"]);
                MEMNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MEMNUMBER"]);
                APPROVALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["APPROVNO"]);
                STAUDITNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["STAUDITNO"]);
                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONDATE"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACTIONTIME"]);
                MERCHENTCATCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MERCHENTCATCODE"]);
                CARDACCEPTERSETDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTSETDATE"]);
                CARDACCEPTERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTORID"]);
                CARDACCEPTTERMINALID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTTERMINALID"]);
                CARDACCEPTERTERLOCATION_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERTERLOCATION"]);


                ACQUIRERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIRERID"]);
                NETWORKID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NETWORKID"]);
                ACCOUNTNO1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTNO1"]);
                ACCOUNTBRANCHID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTBRANCHID"]);
                ACCOUNTNO2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNTNO2"]);
                ACCOUNT2BRANCHID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCOUNT2BRANCHID"]);

                TRANSCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSCURRENCYCODE"]);
                TRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSAMOUNT"]);
                ACCTUALTRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANAMOUNT"]);
                UMN_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UMN"]);
                InitiationMode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InitiationMode"]);
                PurposeCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PurposeCode"]);
                PayerVPA_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerVPA"]);
                PayeeCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeCode"]);
                PayeeMCC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeMCC"]);
                RemCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RemCode"]);
                REMIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["REMIFSCCODE"]);

                BeneCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneCode"]);
                BENIIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BENIIFSCCODE"]);
                BENEACCOUNTNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BENEACCOUNTNUMBER"]);

                TRANSACCVITYFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSACCVITYFEE"]);
                ISSUERSETCURRENCYCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSUERSETCURRENCYCODE"]);
                ISSURESETAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSURESETAMOUNT"]);
                ISSUERSETFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSUERSETFEE"]);
                ISSURESETPROCFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ISSURESETPROCFEE"]);

                CARDHOLDERBILLCURNCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILLCURNCCODE"]);
                CARDHOLDERBILLAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILLAMOUNT"]);
                CARDHOLDERBILACTFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILACTFEE"]);
                CARDHOLDERBILPROFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILPROFEE"]);
                CARDHOLDERBILSRVICEFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDHOLDERBILSRVICEFEE"]);
                TRAN_ISSUERCONVERSRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRAN_ISSUERCONVERSRATE"]);
                TRANS_CARDHOLDERCONVERRATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANS_CARDHOLDERCONVERRATE"]);

                //Read the connection string for the Excel file.
                conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                conString = string.Format(conString, fileImportRequest.Path);

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }
            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {

                // _logger.LogInformation("Ready for read");
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);
                int j = 0;

                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {
                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }
                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            dtSheet = new DataTable();

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = "SELECT * From [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            Incr = 1;

                            if (dtSheet.Rows.Count > 0)
                            {
                                // Find first data row based on whether the "Join Date" cell can be parsed as a date
                                int dateStartIndex = -1;

                                for (int i = 0; i < dtSheet.Rows.Count; i++)
                                {
                                    try
                                    {
                                        if (TRANSDATE_CoulmnIndex > 0 && TRANSTIME_CoulmnIndex > 0)
                                        {
                                            string value = dtSheet.Rows[i][TRANSDATE_CoulmnIndex - Incr]?.ToString()?.Trim() + " " + dtSheet.Rows[i][TRANSTIME_CoulmnIndex - Incr]?.ToString()?.Trim();

                                            bool isValid = DateTime.TryParseExact(value, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                            if (isValid)
                                            {
                                                dateStartIndex = i;
                                                break;
                                            }
                                        }
                                    }
                                    catch
                                    {
                                        SheetDateError++;
                                    }

                                    if (i > 25)
                                        break;
                                }

                                // Remove rows before first data row
                                if (dateStartIndex > -1)
                                {
                                    fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                    for (int k = 0; k < dtSheet.Rows.Count; k++)
                                    {
                                        LineNo++;
                                        SheetLineNo++;
                                        if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                        {
                                            continue;
                                        }
                                        try
                                        {
                                            Participant_ID = string.Empty;
                                            Transaction_Type = string.Empty;
                                            From_Account_Type = string.Empty; ;
                                            To_Account_Type = string.Empty;
                                            Transaction_Serial_Number = string.Empty;
                                            Response_Code = string.Empty;
                                            PAN_Number = string.Empty;
                                            MEMNUMBER = string.Empty;
                                            Approval_Number = string.Empty;

                                            Transaction_Date = string.Empty;
                                            //DateTime  Transaction_Date ;//= string.Empty;
                                            Transaction_Time = "0";
                                            Merchant_Category_Code = "0";
                                            Acquirer_ID = string.Empty;
                                            FORCEMATCH = 0;
                                            UMN = string.Empty;
                                            Initiation_Mode = string.Empty;
                                            Purpose_Code = string.Empty;
                                            Payer_VPA = string.Empty;
                                            Payee_Code = string.Empty;
                                            Payee_MCC = string.Empty;
                                            Rem_Code = string.Empty;
                                            REM_IFSC_CODE = string.Empty;
                                            Bene_Code = string.Empty;
                                            BENI_IFSC_CODE = string.Empty;
                                            BENE_ACCOUNT_NUMBER = string.Empty;
                                            Transaction_Amount = "0";
                                            ACCTUALTRANAMOUNT = "0";
                                            TRANSACCVITYFEE = "0";
                                            ISSUERSETCURRENCYCODE = string.Empty;
                                            ISSURESETAMOUNT = "0";
                                            ISSUERSETFEE = "0";
                                            ISSURESETPROCFEE = "0";
                                            CARDHOLDERBILLCURNCCODE = string.Empty;
                                            CARDHOLDERBILLAMOUNT = "0";
                                            CARDHOLDERBILACTFEE = "0";
                                            CARDHOLDERBILPROFEE = "0";
                                            CARDHOLDERBILSRVICEFEE = "0";
                                            TRAN_ISSUERCONVERSRATE = "0";
                                            TRANS_CARDHOLDERCONVERRATE = "0";
                                            CARDACCEPTSETDATE = "0";
                                            STAUDITNO = "0";

                                            TxnsDateTimeMain = null;

                                            Participant_ID = PARTICIPENTID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PARTICIPENTID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Type = TRANSTYPE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSTYPE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            From_Account_Type = FROMACCOUNTTYPE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FROMACCOUNTTYPE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            To_Account_Type = TOACCOUNTTYPE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TOACCOUNTTYPE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Serial_Number = TRANSSERIALNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSSERIALNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Response_Code = RESPONSECODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][RESPONSECODE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            MEMNUMBER = MEMNUMBER_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][MEMNUMBER_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Approval_Number = APPROVALNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][APPROVALNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            STAUDITNO = STAUDITNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][STAUDITNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Date = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Merchant_Category_Code = MERCHENTCATCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][MERCHENTCATCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDACCEPTSETDATE = CARDACCEPTERSETDATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERSETDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Card_Acceptor_ID = CARDACCEPTERID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDACCEPTTERMINALID = CARDACCEPTTERMINALID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTTERMINALID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDACCEPTERTERLOCATION = CARDACCEPTERTERLOCATION_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERTERLOCATION_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            Acquirer_ID = ACQUIRERID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQUIRERID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            NETWORKID = NETWORKID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][NETWORKID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACCOUNTNO1 = ACCOUNTNO1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACCOUNTNO1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACCOUNTBRANCHID = ACCOUNTBRANCHID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACCOUNTBRANCHID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACCOUNTNO2 = ACCOUNTNO2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACCOUNTNO2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACCOUNT2BRANCHID = ACCOUNT2BRANCHID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACCOUNT2BRANCHID_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            Transaction_Currency_Code = TRANSCURCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSCURCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Amount = TRANSAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACCTUALTRANAMOUNT = ACCTUALTRANSAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACCTUALTRANSAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            UMN = UMN_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][UMN_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Initiation_Mode = InitiationMode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][InitiationMode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            Purpose_Code = PurposeCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PurposeCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Payer_VPA = PayerVPA_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayerVPA_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Payee_Code = PayeeCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayeeCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Payee_MCC = PayeeMCC_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayeeMCC_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            Rem_Code = RemCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][RemCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            REM_IFSC_CODE = REMIFSCCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][REMIFSCCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            REM_ACCOUNT_NUMBER = REMACCOUNTNUMBER_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][REMACCOUNTNUMBER_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Bene_Code = BeneCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BeneCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            BENI_IFSC_CODE = BENIIFSCCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BENIIFSCCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            BENE_ACCOUNT_NUMBER = BENEACCOUNTNUMBER_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BENEACCOUNTNUMBER_CoulmnIndex - Incr]).Trim() : string.Empty;


                                            TRANSACCVITYFEE = TRANSACCVITYFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSACCVITYFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ISSUERSETCURRENCYCODE = ISSUERSETCURRENCYCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISSUERSETCURRENCYCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ISSURESETAMOUNT = ISSURESETAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISSURESETAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ISSUERSETFEE = ISSUERSETFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISSUERSETFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ISSURESETPROCFEE = ISSURESETPROCFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ISSURESETPROCFEE_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            CARDHOLDERBILLCURNCCODE = CARDHOLDERBILLCURNCCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDHOLDERBILLCURNCCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDHOLDERBILLAMOUNT = CARDHOLDERBILLAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDHOLDERBILLAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDHOLDERBILACTFEE = CARDHOLDERBILACTFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDHOLDERBILACTFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDHOLDERBILPROFEE = CARDHOLDERBILPROFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDHOLDERBILPROFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDHOLDERBILSRVICEFEE = CARDHOLDERBILSRVICEFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDHOLDERBILSRVICEFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TRAN_ISSUERCONVERSRATE = TRAN_ISSUERCONVERSRATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRAN_ISSUERCONVERSRATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TRANS_CARDHOLDERCONVERRATE = TRANS_CARDHOLDERCONVERRATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANS_CARDHOLDERCONVERRATE_CoulmnIndex - Incr]).Trim() : string.Empty;


                                            Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                                            ACCTUALTRANAMOUNT = Common.IsNumeric(ACCTUALTRANAMOUNT) ? ACCTUALTRANAMOUNT : "0";
                                            TRANSACCVITYFEE = Common.IsNumeric(TRANSACCVITYFEE) ? TRANSACCVITYFEE : "0";
                                            ISSURESETAMOUNT = Common.IsNumeric(ISSURESETAMOUNT) ? ISSURESETAMOUNT : "0";
                                            ISSUERSETFEE = Common.IsNumeric(ISSUERSETFEE) ? ISSUERSETFEE : "0";
                                            ISSURESETPROCFEE = Common.IsNumeric(ISSURESETPROCFEE) ? ISSURESETPROCFEE : "0";
                                            CARDHOLDERBILLAMOUNT = Common.IsNumeric(CARDHOLDERBILLAMOUNT) ? CARDHOLDERBILLAMOUNT : "0";
                                            CARDHOLDERBILACTFEE = Common.IsNumeric(CARDHOLDERBILACTFEE) ? CARDHOLDERBILACTFEE : "0";
                                            CARDHOLDERBILPROFEE = Common.IsNumeric(CARDHOLDERBILPROFEE) ? CARDHOLDERBILPROFEE : "0";
                                            CARDHOLDERBILSRVICEFEE = Common.IsNumeric(CARDHOLDERBILSRVICEFEE) ? CARDHOLDERBILSRVICEFEE : "0";
                                            TRAN_ISSUERCONVERSRATE = Common.IsNumeric(TRAN_ISSUERCONVERSRATE) ? TRAN_ISSUERCONVERSRATE : "0";
                                            TRANS_CARDHOLDERCONVERRATE = Common.IsNumeric(TRANS_CARDHOLDERCONVERRATE) ? TRANS_CARDHOLDERCONVERRATE : "0";
                                            CARDACCEPTSETDATE = Common.IsNumeric(CARDACCEPTSETDATE) ? CARDACCEPTSETDATE : "0";
                                            STAUDITNO = Common.IsNumeric(STAUDITNO) ? STAUDITNO : "0";
                                            Merchant_Category_Code = Common.IsNumeric(Merchant_Category_Code) ? Merchant_Category_Code : "0";

                                            if (Transaction_Date.Length > 0 && Transaction_Time.Length > 0)
                                            {
                                                timestamp = Transaction_Date + Transaction_Time;
                                            }

                                            TxnsDateTimeMain = DateTime.ParseExact(timestamp, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None);
                                            if (TxnsDateTimeMain != null)
                                            {
                                                _DataTable.Rows.Add(Participant_ID.Trim(), Transaction_Type.Trim(), From_Account_Type.Trim(), To_Account_Type.Trim(), Transaction_Serial_Number.Trim(), Response_Code.Trim(), PAN_Number.Trim(), MEMNUMBER.Trim(),
                                                                   Approval_Number.Trim(), STAUDITNO.Trim(), TxnsDateTimeMain, Transaction_Time.Trim(), Merchant_Category_Code.Trim(), CARDACCEPTSETDATE.Trim(), Card_Acceptor_ID.Trim(), CARDACCEPTTERMINALID.Trim(), CARDACCEPTERTERLOCATION.Trim(),
                                                                   Acquirer_ID, NETWORKID, ACCOUNTNO1, ACCOUNTBRANCHID, ACCOUNTNO2, ACCOUNT2BRANCHID, Transaction_Currency_Code, Transaction_Amount, ACCTUALTRANAMOUNT,
                                                                   TRANSACCVITYFEE.Trim(), ISSUERSETCURRENCYCODE.Trim(), ISSURESETAMOUNT.Trim(), ISSUERSETFEE.Trim(), ISSURESETPROCFEE.Trim(), CARDHOLDERBILLCURNCCODE.Trim(), CARDHOLDERBILLAMOUNT.Trim(), CARDHOLDERBILACTFEE.Trim(), CARDHOLDERBILPROFEE.Trim(),
                                                                   CARDHOLDERBILSRVICEFEE.Trim(), TRAN_ISSUERCONVERSRATE.Trim(), TRANS_CARDHOLDERCONVERRATE.Trim(), FORCEMATCH, Cycle, UMN.Trim(), Initiation_Mode.Trim(), Purpose_Code.Trim(), Payer_VPA.Trim(), Payee_Code.Trim(),
                                                                   Payee_MCC.Trim(), Rem_Code.Trim(), REM_IFSC_CODE.Trim(), REM_ACCOUNT_NUMBER.Trim(), Bene_Code.Trim(), BENI_IFSC_CODE.Trim(), BENE_ACCOUNT_NUMBER.Trim(), CardScheme, IssuingNetwork);


                                                if (_DataTable.Rows.Count >= batchSize)
                                                {
                                                    BatchNo++;
                                                    MSG = bulkimports.BulkInsertIssuerDataUPITable(_DataTable, DTdetails.ConfigID, "0");
                                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                    BatchDetails batchDetails = new BatchDetails
                                                    {
                                                        BatchNo = BatchNo,
                                                        BatchSize = batchSize,
                                                        TxnUploadCount = _DataTable.Rows.Count,
                                                        TxnsCount = fileImportRequest.InsertCount,
                                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                        FailedCount = ErrorCount,
                                                        BatchStartTime = batchStartTime,
                                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                    };
                                                    batchDetailsList.Add(batchDetails);
                                                    _DataTable.Clear();
                                                    ErrorCount = 0;
                                                    StartTime = DateTime.Now;

                                                    if (NewEntry)
                                                    {
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            ErrorCount++;
                                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                        }
                                    }
                                }
                                else
                                {
                                    if (j == 0)
                                    {
                                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched";
                                    }
                                    break;
                                }

                            }

                            j++;
                        }

                        LineNo = 0;
                    }
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkimports.BulkInsertIssuerDataUPITable(_DataTable, DTdetails.ConfigID, "0");

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                // _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

        //Splitter for UPI Outward Excel
        public string Splitter_UPI_Acquirer_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            bool ErrorOccurred = false;
            int SheetLineNo = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("PARTICIPENTID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("FROMACCTYPE", typeof(string));
            _DataTable.Columns.Add("TOACCTYPE", typeof(string));
            _DataTable.Columns.Add("TRANSSERIALNO", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("PANNO", typeof(string));
            _DataTable.Columns.Add("MEMNUMBER", typeof(string));
            _DataTable.Columns.Add("APPROVALNO", typeof(string));
            _DataTable.Columns.Add("SYSTRACAUDITNO", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TRANSDATE", typeof(string));
            _DataTable.Columns.Add("TRANSTIME", typeof(string));
            _DataTable.Columns.Add("MERCHANTCATCODE", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERSETDATE", typeof(string));
            _DataTable.Columns.Add("CARDACCID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERID", typeof(string));
            _DataTable.Columns.Add("CARDACCEPTERTERLOC", typeof(string));
            _DataTable.Columns.Add("ACCIQUIERID", typeof(string));
            _DataTable.Columns.Add("ACCSETDATE", typeof(string));
            _DataTable.Columns.Add("TRANSCURCODE", typeof(string));
            _DataTable.Columns.Add("TRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACCTUALTRANSAMOUNT", typeof(string));
            _DataTable.Columns.Add("TRANSACTIVITYFEE", typeof(string));
            _DataTable.Columns.Add("ACCURSETCURCODE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETAMOUNT", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETFEE", typeof(string));
            _DataTable.Columns.Add("ACQUIERSETPROFEE", typeof(string));
            _DataTable.Columns.Add("TRANSACQUIERCONVERRATE", typeof(string));
            _DataTable.Columns.Add("FORCEMATCH", typeof(string));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("UMN", typeof(string));//new column
            _DataTable.Columns.Add("InitiationMode", typeof(string));
            _DataTable.Columns.Add("PurposeCode", typeof(string));
            _DataTable.Columns.Add("PayerCode", typeof(string));
            _DataTable.Columns.Add("PayerVPA", typeof(string));
            _DataTable.Columns.Add("PayeeCode", typeof(string));
            _DataTable.Columns.Add("PayeeMCC", typeof(string));
            _DataTable.Columns.Add("RemCode", typeof(string));
            _DataTable.Columns.Add("REMIFSCCODE", typeof(string));
            _DataTable.Columns.Add("RemitterAccountType", typeof(string));
            _DataTable.Columns.Add("BeneCode", typeof(string));
            _DataTable.Columns.Add("BENIIFSCCODE", typeof(string));
            _DataTable.Columns.Add("BeneAccountType", typeof(string));
            _DataTable.Columns.Add("BENEACCOUNTNUMBER", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));

            int Incr = 1;
            string Participant_ID = string.Empty;
            string Transaction_Type = string.Empty;
            string From_Account_Type = string.Empty;
            string To_Account_Type = string.Empty;
            string Transaction_Serial_Number = string.Empty;
            string Response_Code = string.Empty;
            string PAN_Number = string.Empty;
            string MEMNUMBER = string.Empty;
            string Approval_Number = string.Empty;
            string SYSTRACAUDITNO = "0";
            string Transaction_Time = string.Empty;
            string TxnDate = string.Empty;
            string Merchant_Category_Code = string.Empty;
            string CARDACCEPTSETDATE = "0";
            string CARDACCID = string.Empty;
            string Card_Acceptor_ID = string.Empty;
            string CARDACCEPTERTERLOC = string.Empty;
            string Acquirer_ID = string.Empty;
            string ACCSETDATE = "0";
            string Transaction_Currency_Code = string.Empty;
            string Transaction_Amount = string.Empty;
            string ACCTUALTRANSAMOUNT = string.Empty;
            string TRANSACTIVITYFEE = "0";
            string ACCURSETCURCODE = string.Empty;
            string ACQUIERSETAMOUNT = "0";
            string ACQUIERSETFEE = "0";
            string ACQUIERSETPROFEEE = "0";
            string TRANSACQUIERCONVERRATE = "0";
            int FORCEMATCH = 0;
            string UMN = string.Empty;
            string Initiation_Mode = string.Empty;
            string Purpose_Code = string.Empty;
            string Payer_Code = string.Empty;
            string Payer_VPA = string.Empty;
            string Payee_Code = string.Empty;
            string Payee_MCC = string.Empty;
            string Rem_Code = string.Empty;
            string REM_IFSC_CODE = string.Empty;
            string Remitter_Account_Type = string.Empty;
            string Bene_Code = string.Empty;
            string BENI_IFSC_CODE = string.Empty;
            string Bene_Account_Type = string.Empty;
            string BENE_ACCOUNT_NUMBER = string.Empty;

            string CardScheme = string.Empty;
            string IssuingNetwork = "NPCI";
            string timestamp = string.Empty;
            DateTime? TxnsDateTimeMain = null;


            string[] TxnDateTimeFormat = null;
            string line1 = string.Empty;
            string Cycle = string.Empty;

            ushort PARTICIPENTID_CoulmnIndex = 0;
            ushort TRANSTYPE_CoulmnIndex = 0;
            ushort TRANSSERIALNO_CoulmnIndex = 0;
            ushort RESPONSECODE_CoulmnIndex = 0;
            ushort PANNO_CoulmnIndex = 0;
            ushort MEMNUMBER_CoulmnIndex = 0;
            ushort APPROVALNO_CoulmnIndex = 0;
            ushort TRANSDATE_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;
            ushort TRANSCURCODE_CoulmnIndex = 0;
            ushort TRANSAMOUNT_CoulmnIndex = 0;
            ushort ACCTUALTRANSAMOUNT_CoulmnIndex = 0;
            ushort UMN_CoulmnIndex = 0;
            ushort InitiationMode_CoulmnIndex = 0;
            ushort PurposeCode_CoulmnIndex = 0;
            ushort PayerVPA_CoulmnIndex = 0;
            ushort PayeeCode_CoulmnIndex = 0;
            ushort PayeeMCC_CoulmnIndex = 0;
            ushort PayerCode_CoulmnIndex = 0;
            ushort RemCode_CoulmnIndex = 0;
            ushort REMIFSCCODE_CoulmnIndex = 0;
            ushort RemitterAccountType_CoulmnIndex = 0;
            ushort BeneCode_CoulmnIndex = 0;
            ushort BENIIFSCCODE_CoulmnIndex = 0;
            ushort BENEACCOUNTNUMBER_CoulmnIndex = 0;
            ushort ACCURSETCURCODE_CoulmnIndex = 0;
            ushort ACQUIERSETAMOUNT_CoulmnIndex = 0;
            ushort ACQUIERSETFEE_CoulmnIndex = 0;
            ushort ACQUIERSETPROFEE_CoulmnIndex = 0;
            ushort CARDACCEPTERTERLOC_CoulmnIndex = 0;
            ushort CARDACCEPTERSETDATE_CoulmnIndex = 0;
            ushort CARDACCEPTERID_CoulmnIndex = 0;

            int ErrorCount = 0, LineNo = 0;

            string conString = string.Empty;
            DataTable dtexcelsheetname = new DataTable();
            DataTable dtSheet = new DataTable();

            try
            {
                DataSet ds = new DataSet();

                string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                string[] FDA = fileImportRequest.FileName.Split('_', '.');
                Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

                TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);


                PARTICIPENTID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PARTICIPENTID"]);
                TRANSTYPE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTYPE"]);
                TRANSSERIALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSSERIALNO"]);
                RESPONSECODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RESPONSECODE"]);
                PANNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PANNO"]);
                MEMNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MEMNUMBER"]);
                APPROVALNO_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["APPROVALNO"]);
                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSDATE"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSTIME"]);
                TRANSCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSCURCODE"]);
                TRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TRANSAMOUNT"]);
                ACCTUALTRANSAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCTUALTRANSAMOUNT"]);
                UMN_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UMN"]);
                InitiationMode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InitiationMode"]);
                PurposeCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PurposeCode"]);
                PayerVPA_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerVPA"]);
                PayeeCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeCode"]);
                PayeeMCC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeMCC"]);
                PayerCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerCode"]);
                RemCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RemCode"]);
                REMIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["REMIFSCCODE"]);
                RemitterAccountType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RemitterAccountType"]);
                BeneCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneCode"]);
                BENIIFSCCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BENIIFSCCODE"]);
                BENEACCOUNTNUMBER_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BENEACCOUNTNUMBER"]);
                ACCURSETCURCODE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACCURSETCURCODE"]);
                ACQUIERSETAMOUNT_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETAMOUNT"]);
                ACQUIERSETFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETFEE"]);
                ACQUIERSETPROFEE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ACQUIERSETPROFEE"]);
                CARDACCEPTERTERLOC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERTERLOC"]);
                CARDACCEPTERSETDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERSETDATE"]);
                CARDACCEPTERID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CARDACCEPTERID"]);

                //Read the connection string for the Excel file.
                conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                conString = string.Format(conString, fileImportRequest.Path);

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {
                int j = 0;
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {
                    int SheetLineNumber = 0;

                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }

                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            dtSheet = new DataTable();

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = "SELECT * From [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            Incr = 1;

                            if (dtSheet.Rows.Count > 1)
                            {
                                // Find first data row based on whether the "Join Date" cell can be parsed as a date
                                int dateStartIndex = -1;

                                for (int i = 0; i < dtSheet.Rows.Count; i++)
                                {
                                    try
                                    {
                                        if (TRANSDATE_CoulmnIndex > 0 && TRANSTIME_CoulmnIndex > 0)
                                        {
                                            string value = dtSheet.Rows[i][TRANSDATE_CoulmnIndex - Incr]?.ToString()?.Trim() + " " + dtSheet.Rows[i][TRANSTIME_CoulmnIndex - Incr]?.ToString()?.Trim();

                                            bool isValid = DateTime.TryParseExact(value, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                            if (isValid)
                                            {
                                                dateStartIndex = i;
                                                break;
                                            }
                                        }
                                    }
                                    catch
                                    {
                                        SheetDateError++;
                                    }

                                    if (i > 25)
                                        break;
                                }

                                // Remove rows before first data row
                                if (dateStartIndex > -1)
                                {
                                    fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;
                                    fileImportRequest.SkippedRows = fileImportRequest.SkippedRows + dateStartIndex;

                                    for (int k = dateStartIndex; k < dtSheet.Rows.Count; k++)
                                    {
                                        LineNo++;
                                        SheetLineNo++;

                                        if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                        {
                                            continue;
                                        }
                                        try
                                        {

                                            Participant_ID = string.Empty;
                                            Transaction_Type = string.Empty;
                                            From_Account_Type = string.Empty;
                                            To_Account_Type = string.Empty;
                                            Transaction_Serial_Number = string.Empty;
                                            Response_Code = string.Empty;
                                            PAN_Number = string.Empty;
                                            MEMNUMBER = string.Empty;
                                            Approval_Number = string.Empty;
                                            Transaction_Time = string.Empty;
                                            TxnDate = string.Empty;

                                            CARDACCID = string.Empty;
                                            Card_Acceptor_ID = string.Empty;
                                            CARDACCEPTERTERLOC = string.Empty;
                                            Acquirer_ID = string.Empty;
                                            Transaction_Currency_Code = string.Empty;
                                            Transaction_Amount = string.Empty;
                                            ACCTUALTRANSAMOUNT = string.Empty;
                                            ACCURSETCURCODE = string.Empty;

                                            UMN = string.Empty;
                                            Initiation_Mode = string.Empty;
                                            Purpose_Code = string.Empty;
                                            Payer_Code = string.Empty;
                                            Payer_VPA = string.Empty;
                                            Payee_Code = string.Empty;
                                            Payee_MCC = string.Empty;
                                            Rem_Code = string.Empty;
                                            REM_IFSC_CODE = string.Empty;
                                            Remitter_Account_Type = string.Empty;
                                            Bene_Code = string.Empty;
                                            BENI_IFSC_CODE = string.Empty;
                                            Bene_Account_Type = string.Empty;
                                            BENE_ACCOUNT_NUMBER = string.Empty;
                                            timestamp = string.Empty;

                                            SYSTRACAUDITNO = "0";
                                            Merchant_Category_Code = "0";
                                            CARDACCEPTSETDATE = "0";
                                            ACCSETDATE = "0";
                                            ACCTUALTRANSAMOUNT = "0";
                                            TRANSACTIVITYFEE = "0";

                                            ACQUIERSETAMOUNT = "0";
                                            ACQUIERSETFEE = "0";
                                            ACQUIERSETPROFEEE = "0";
                                            TRANSACQUIERCONVERRATE = "0";

                                            TxnsDateTimeMain = null;


                                            Participant_ID = PARTICIPENTID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PARTICIPENTID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Type = TRANSTYPE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSTYPE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Serial_Number = TRANSSERIALNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSSERIALNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Response_Code = RESPONSECODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][RESPONSECODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            PAN_Number = PANNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PANNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            MEMNUMBER = MEMNUMBER_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][MEMNUMBER_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Approval_Number = APPROVALNO_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][APPROVALNO_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            TxnDate = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Time = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Currency_Code = TRANSCURCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSCURCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Transaction_Amount = TRANSAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TRANSAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACCTUALTRANSAMOUNT = ACCTUALTRANSAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACCTUALTRANSAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            UMN = UMN_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][UMN_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Initiation_Mode = InitiationMode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][InitiationMode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            Purpose_Code = PurposeCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PurposeCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Payer_VPA = PayerVPA_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayerVPA_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Payee_Code = PayeeCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayeeCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Payee_MCC = PayeeMCC_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayeeMCC_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Payer_Code = PayerCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayerCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Rem_Code = RemCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][RemCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            REM_IFSC_CODE = REMIFSCCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][REMIFSCCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Remitter_Account_Type = RemitterAccountType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][RemitterAccountType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Bene_Code = BeneCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BeneCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            BENI_IFSC_CODE = BENIIFSCCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BENIIFSCCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            BENE_ACCOUNT_NUMBER = BENEACCOUNTNUMBER_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BENEACCOUNTNUMBER_CoulmnIndex - Incr]).Trim() : string.Empty;

                                            ACCURSETCURCODE = ACCURSETCURCODE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACCURSETCURCODE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACQUIERSETAMOUNT = ACQUIERSETAMOUNT_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQUIERSETAMOUNT_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACQUIERSETFEE = ACQUIERSETFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQUIERSETFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            ACQUIERSETPROFEEE = ACQUIERSETPROFEE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ACQUIERSETPROFEE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDACCEPTERTERLOC = CARDACCEPTERTERLOC_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERTERLOC_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            CARDACCEPTSETDATE = CARDACCEPTERSETDATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERSETDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                            Card_Acceptor_ID = CARDACCEPTERID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CARDACCEPTERID_CoulmnIndex - Incr]).Trim() : string.Empty;


                                            Transaction_Amount = Common.IsNumeric(Transaction_Amount) ? Transaction_Amount : "0";
                                            ACCTUALTRANSAMOUNT = Common.IsNumeric(ACCTUALTRANSAMOUNT) ? ACCTUALTRANSAMOUNT : "0";
                                            TRANSACTIVITYFEE = Common.IsNumeric(TRANSACTIVITYFEE) ? TRANSACTIVITYFEE : "0";
                                            ACQUIERSETAMOUNT = Common.IsNumeric(ACQUIERSETAMOUNT) ? ACQUIERSETAMOUNT : "0";
                                            ACQUIERSETFEE = Common.IsNumeric(ACQUIERSETFEE) ? ACQUIERSETFEE : "0";
                                            ACQUIERSETPROFEEE = Common.IsNumeric(ACQUIERSETPROFEEE) ? ACQUIERSETPROFEEE : "0";
                                            TRANSACQUIERCONVERRATE = Common.IsNumeric(TRANSACQUIERCONVERRATE) ? TRANSACQUIERCONVERRATE : "0";
                                            CARDACCEPTSETDATE = Common.IsNumeric(CARDACCEPTSETDATE) ? CARDACCEPTSETDATE : "0";
                                            SYSTRACAUDITNO = Common.IsNumeric(SYSTRACAUDITNO) ? SYSTRACAUDITNO : "0";
                                            Merchant_Category_Code = Common.IsNumeric(Merchant_Category_Code) ? Merchant_Category_Code : "0";
                                            ACCSETDATE = Common.IsNumeric(ACCSETDATE) ? ACCSETDATE : "0";

                                            if (TxnDate.Length > 0 && Transaction_Time.Length > 0)
                                            {
                                                timestamp = TxnDate + Transaction_Time;
                                            }
                                            //timestamp = TxnDate.Substring(0, 2).ToString() + "-" + TxnDate.Substring(2, 2).ToString() + "-" + TxnDate.Substring(4, 2).ToString() + " " + Transaction_Time.Substring(0, 2).ToString() + ":" + Transaction_Time.Substring(2, 2).ToString() + ":" + Transaction_Time.Substring(4, 2).ToString();

                                            TxnsDateTimeMain = DateTime.ParseExact(timestamp, TxnDateTimeFormat, CultureInfo.InvariantCulture);

                                            if (TxnsDateTimeMain != null)
                                            {
                                                _DataTable.Rows.Add(Participant_ID.Trim(), Transaction_Type.Trim(), From_Account_Type.Trim(), To_Account_Type.Trim(), Transaction_Serial_Number.Trim(), Response_Code.Trim(), PAN_Number.Trim(), MEMNUMBER.Trim(),
                                             Approval_Number.Trim(), SYSTRACAUDITNO.Trim(), TxnsDateTimeMain, TxnDate, Transaction_Time, Merchant_Category_Code.Trim(), CARDACCEPTSETDATE.Trim(), CARDACCID.Trim(), Card_Acceptor_ID.Trim(), CARDACCEPTERTERLOC.Trim(),
                                             Acquirer_ID.Trim(), ACCSETDATE.Trim(), Transaction_Currency_Code.Trim(), Transaction_Amount.Trim(), ACCTUALTRANSAMOUNT.Trim(), TRANSACTIVITYFEE.Trim(), ACCURSETCURCODE.Trim(), ACQUIERSETAMOUNT.Trim(), ACQUIERSETFEE.Trim(),
                                             ACQUIERSETPROFEEE.Trim(), TRANSACQUIERCONVERRATE.Trim(), FORCEMATCH, Cycle.Trim(), UMN.Trim(), Initiation_Mode.Trim(), Purpose_Code.Trim(), Payer_Code.Trim(), Payer_VPA.Trim(), Payee_Code.Trim(), Payee_MCC.Trim(), Rem_Code.Trim(), REM_IFSC_CODE.Trim(), Remitter_Account_Type.Trim(),
                                             Bene_Code.Trim(), BENI_IFSC_CODE.Trim(), Bene_Account_Type.Trim(), BENE_ACCOUNT_NUMBER.Trim(), CardScheme, IssuingNetwork);

                                                if (_DataTable.Rows.Count >= batchSize)
                                                {
                                                    BatchNo++;
                                                    MSG = bulkimports.BulkInsertAcquirerDataUPITable(_DataTable, DTdetails.ConfigID, "0");
                                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                    BatchDetails batchDetails = new BatchDetails
                                                    {
                                                        BatchNo = BatchNo,
                                                        BatchSize = batchSize,
                                                        TxnUploadCount = _DataTable.Rows.Count,
                                                        TxnsCount = fileImportRequest.InsertCount,
                                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                        FailedCount = ErrorCount,
                                                        BatchStartTime = batchStartTime,
                                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                    };

                                                    batchDetailsList.Add(batchDetails);
                                                    _DataTable.Clear();
                                                    ErrorCount = 0;
                                                    StartTime = DateTime.Now;

                                                    if (NewEntry)
                                                    {
                                                        break;
                                                    }
                                                }

                                            }


                                        }
                                        catch (Exception ex)
                                        {
                                            ErrorCount++;
                                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                        }

                                    }
                                }
                                else
                                {
                                    if (j == 0)
                                    {
                                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched";
                                    }
                                    break;
                                }
                            }

                            j++;
                        }

                        LineNo = 0;
                    }

                }
            }

            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkimports.BulkInsertAcquirerDataUPITable(_DataTable, DTdetails.ConfigID, "0");


                // _logger.LogInformation("Batch Completed : {BatchNo}", BatchNo);

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                // _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }

        //Splitter for UPI Settlement
        public string Splitter_NPCI_Settlement_UPI_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            string TempRemark = string.Empty;
            int LineNo = 0, ErrorCount = 0;
            int SheetLineNumber = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int SheetLineNo = 0;
           
            string MSG = string.Empty;
            int BatchNo = 0;

            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("Date", typeof(DateTime));
            _DataTable.Columns.Add("Cycle", typeof(string));
            _DataTable.Columns.Add("NoTxns", typeof(int));
            _DataTable.Columns.Add("Debit", typeof(decimal));
            _DataTable.Columns.Add("Credit", typeof(decimal));
            _DataTable.Columns.Add("Bank", typeof(string));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("Remarks", typeof(string));

            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
            string FileDateFormat = fileImportRequest.ConfigData.Rows[0]["FileDateFormat"].ToString();

            DateTime? TxnsDateTimeMain = null;
            DateTime? FileDateTime = null;

            string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

            string[] FDA = Path.GetFileNameWithoutExtension(fileImportRequest.FileName).Split('_');

            string Cycle = string.Empty;

            if (FDA.Length == 3)
            {
                Cycle = FDA[2];
            }
            else if (FDA.Length == 2)
            {
                Cycle = FDA[1];
            }

            DataSet ds = new DataSet();


            try
            {

                conString = string.Format(conString, fileImportRequest.Path);

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                ushort Description_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Description"]);
                ushort NoTxns_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NoTxns"]);
                ushort Debit_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Debit"]);
                ushort Credit_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Credit"]);
                ushort Remarks_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remarks"]);
                ushort Date_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Date"]);

                DataTable dtexcelsheetname = new DataTable();
                DataTable dtSheet = new DataTable();

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }
                DateTime StartTime = DateTime.Now;
                string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);


                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {


                    //  _logger.LogInformation("Ready for read");
                    //Get Batch Size
                   


                    int j = 0;

                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }

                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = Getdatafromsheet1;
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            int Incr = 1;
                            string Description = string.Empty;
                            string NoTxnsValue = "0";
                            string DebitValue = "0";
                            string CreditValue = "0";
                            string Remarks = string.Empty;
                            string TxnsDate = string.Empty;
                            string BankName = ClientID.ToString();
                            int start, end;

                            

                            if (dtSheet.Rows.Count > 1)
                            {
                                fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                for (int k = 0; k < dtSheet.Rows.Count; k++)
                                {
                                    Incr = 1;
                                    SheetLineNumber++;
                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    Description = string.Empty;
                                    NoTxnsValue = "0";
                                    DebitValue = "0";
                                    CreditValue = "0";
                                    Remarks = string.Empty;
                                    TxnsDate = string.Empty;
                                    TxnsDateTimeMain = null;

                                    try
                                    {

                                        Description = Description_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Description_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        if (Description.Contains("Daily Settlement Statement for"))
                                        {
                                            TempRemark = Description;

                                            start = TempRemark.IndexOf("for ") + 4;
                                            end = TempRemark.IndexOf("as on");

                                            if (end > start)
                                            {
                                                BankName = TempRemark.Substring(start, end - start).Trim();
                                                BankName = BankName.Substring(0, BankName.Length > 100 ? 100 : BankName.Length);
                                            }
                                        }
                                        NoTxnsValue = NoTxns_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][NoTxns_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        DebitValue = Debit_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Debit_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        CreditValue = Credit_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Credit_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Remarks = Remarks_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Remarks_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsDate = Date_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Date_CoulmnIndex - Incr]).Trim() : string.Empty;


                                        if (TxnsDate.Length > 0)
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDate, TxnDateTime, CultureInfo.InvariantCulture);
                                        }
                                        else
                                        {
                                            TxnsDateTimeMain = fileImportRequest.FileDateTime;
                                        }

                                        NoTxnsValue = Common.IsNumeric(NoTxnsValue) ? NoTxnsValue : "0";
                                        DebitValue = Common.IsNumeric(DebitValue) ? DebitValue : "0";
                                        CreditValue = Common.IsNumeric(CreditValue) ? CreditValue : "0";

                                        if (fileImportRequest.ClientCode == "56" && Description.Contains("Credit Card"))
                                        {
                                            TempRemark = "Credit Card";
                                        }
                                        else if (fileImportRequest.ClientCode == "56" && TempRemark != "Credit Card")
                                        {
                                            TempRemark = "ESF";
                                        }


                                        if (Remarks.Length == 0)
                                        {
                                            Remarks = TempRemark;
                                        }

                                        if (Description != "" && (Convert.ToDecimal(DebitValue) > 0 || Convert.ToDecimal(CreditValue) > 0) && TxnsDateTimeMain != null)
                                        {
                                            _DataTable.Rows.Add
                                                (TxnsDateTimeMain,
                                                Cycle,
                                                Convert.ToDecimal(NoTxnsValue),
                                                Convert.ToDecimal(DebitValue),
                                                Convert.ToDecimal(CreditValue),
                                                 BankName,
                                                Description,
                                                Remarks);

                                            if (_DataTable.Rows.Count >= batchSize)
                                            {
                                                BatchNo++;
                                                MSG = bulkimports.BulkInsertSettlementDataUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                                //  _logger.LogInformation("Batch Completed : {BatchNo}", BatchNo);
                                                BatchDetails batchDetails = new BatchDetails
                                                {
                                                    BatchNo = BatchNo,
                                                    BatchSize = batchSize,
                                                    TxnUploadCount = _DataTable.Rows.Count,
                                                    TxnsCount = fileImportRequest.InsertCount,
                                                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                    FailedCount = ErrorCount,
                                                    BatchStartTime = batchStartTime,
                                                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                };

                                                batchDetailsList.Add(batchDetails);
                                                _DataTable.Clear();
                                                ErrorCount = 0;
                                                StartTime = DateTime.Now;

                                                if (NewEntry)
                                                {
                                                    break;
                                                }
                                            }
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorCount++;
                                        DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    }

                                    SheetLineNo++;
                                }
                            }

                            j++;
                        }
                        LineNo = 0;
                    }
                }

            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkimports.BulkInsertSettlementDataUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                // _logger.LogInformation("Batch Completed : {BatchNo}", BatchNo);
                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                //  _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
            {
                MSG = "Successful";
            }
        }
    
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

          fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }
        string ExtractNumber(string original)
        {
            return new string(original.Where(c => Char.IsDigit(c)).ToArray());
        }



        //SPliter for UPI Delimter
        public string Splitter_UPI_Adjustment_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int ErrorCount = 0;
            int LineNumber = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;
            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("Txnuid", typeof(string));
            _DataTable.Columns.Add("Uid", typeof(string));
            _DataTable.Columns.Add("Adjdate", typeof(DateTime));
            _DataTable.Columns.Add("Adjtype", typeof(string));
            _DataTable.Columns.Add("Remitter", typeof(string));
            _DataTable.Columns.Add("Beneficiery", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("TxnDateTime", typeof(DateTime));
            _DataTable.Columns.Add("RRN", typeof(string));
            _DataTable.Columns.Add("Terminalid", typeof(string));
            _DataTable.Columns.Add("Ben_Mobile_No", typeof(string));
            _DataTable.Columns.Add("Rem_Mobile_No", typeof(string));
            _DataTable.Columns.Add("ChargebackDate", typeof(DateTime));
            _DataTable.Columns.Add("Chbref", typeof(string));
            _DataTable.Columns.Add("TxnAmount", typeof(string));
            _DataTable.Columns.Add("AdjAmount", typeof(string));
            _DataTable.Columns.Add("Rem_Fee", typeof(string));
            _DataTable.Columns.Add("Ben_Fee", typeof(string));
            _DataTable.Columns.Add("Ben_FeeSW", typeof(string));
            _DataTable.Columns.Add("AdjFee", typeof(string));
            _DataTable.Columns.Add("NPCIFee", typeof(string));
            _DataTable.Columns.Add("Remfeetax", typeof(string));
            _DataTable.Columns.Add("Benfeetax", typeof(string));
            _DataTable.Columns.Add("Npcitax", typeof(string));
            _DataTable.Columns.Add("AdjRef", typeof(string));
            _DataTable.Columns.Add("BankAdjRef", typeof(string));
            _DataTable.Columns.Add("AdjProof", typeof(string));
            _DataTable.Columns.Add("Compensation_amount", typeof(string));
            _DataTable.Columns.Add("Adj_Raise_Time", typeof(string));
            _DataTable.Columns.Add("No_of_Days_for_Penalty", typeof(string));
            _DataTable.Columns.Add("SHDT73", typeof(string));
            _DataTable.Columns.Add("SHDT74", typeof(string));
            _DataTable.Columns.Add("SHDT75", typeof(string));
            _DataTable.Columns.Add("SHDT76", typeof(string));
            _DataTable.Columns.Add("SHDT77", typeof(string));
            _DataTable.Columns.Add("Transaction_Type", typeof(string));
            _DataTable.Columns.Add("Transaction_Indicator", typeof(string));
            _DataTable.Columns.Add("Beneficiary_Account_number", typeof(string));
            _DataTable.Columns.Add("Remitter_Account_number", typeof(string));
            _DataTable.Columns.Add("Aadhar_Number", typeof(string));
            _DataTable.Columns.Add("Mobile_Number", typeof(string));
            _DataTable.Columns.Add("Payer_PSP", typeof(string));
            _DataTable.Columns.Add("Payee_PSP", typeof(string));
            _DataTable.Columns.Add("UPI_Transaction_ID", typeof(string));
            _DataTable.Columns.Add("Virtual_Address", typeof(string));
            _DataTable.Columns.Add("Dispute_Flag", typeof(string));
            _DataTable.Columns.Add("Reason_Code", typeof(string));
            _DataTable.Columns.Add("MCC", typeof(string));
            _DataTable.Columns.Add("Originating_Channel", typeof(string));
            //  _DataTable.Columns.Add("Cycle", typeof(string));

            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int Incr = 1;

            string Txnuid = string.Empty;
            string Uid = string.Empty;
            string Adjdate = string.Empty;
            string Adjtype = string.Empty;
            string Remitter = string.Empty;
            string Beneficiery = string.Empty;
            string ResponseCode = string.Empty;
            string TxnDateTime = string.Empty;
            string RRN = string.Empty;
            string Terminalid = string.Empty;
            string Ben_Mobile_No = string.Empty;
            string Rem_Mobile_No = string.Empty;
            string ChargebackDate = string.Empty;
            string Chbref = string.Empty;
            string TxnAmount = string.Empty;
            string AdjAmount = string.Empty;
            string Rem_Fee = string.Empty;
            string Ben_Fee = string.Empty;
            string BenFeeSW = string.Empty;
            string AdjFee = string.Empty;
            string NPCIFee = string.Empty;
            string Remfeetax = string.Empty;
            string Benfeetax = string.Empty;
            string Npcitax = string.Empty;
            string AdjRef = string.Empty;
            string BankAdjRef = string.Empty;
            string AdjProof = string.Empty;
            string Compensation_amount = string.Empty;
            string Adj_Raise_Time = string.Empty;
            string No_of_Days_for_Penalty = string.Empty;
            string SHDT73 = string.Empty;
            string SHDT74 = string.Empty;
            string SHDT75 = string.Empty;
            string SHDT76 = string.Empty;
            string SHDT77 = string.Empty;

            string Transaction_Type = string.Empty;
            string Transaction_Indicator = string.Empty;
            string Beneficiary_Account_number = string.Empty;
            string Remitter_Account_number = string.Empty;
            string Aadhar_Number = string.Empty;
            string Mobile_Number = string.Empty;
            string Payer_PSP = string.Empty;
            string Payee_PSP = string.Empty;
            string UPI_Transaction_ID = string.Empty;
            string Virtual_Address = string.Empty;
            string Dispute_Flag = string.Empty;
            string Reason_Code = string.Empty;
            string MCC = string.Empty;
            string Originating_Channel = string.Empty;
            string Transaction_Date = string.Empty;
            string Transaction_Time = string.Empty;
            string Cycle = string.Empty;
            string TRANSDATE = string.Empty;
            string TRANSTIME = string.Empty;


            DateTime? TxnsDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;

            ushort Txnuid_CoulmnIndex = 0;
            ushort Uid_CoulmnIndex = 0;
            ushort Adjdate_CoulmnIndex = 0;
            ushort Adjtype_CoulmnIndex = 0;
            ushort Remitter_CoulmnIndex = 0;
            ushort Beneficiery_CoulmnIndex = 0;
            ushort ResponseCode_CoulmnIndex = 0;
            ushort TxnDateTime_CoulmnIndex = 0;
            ushort RRN_CoulmnIndex = 0;
            ushort Terminalid_CoulmnIndex = 0;
            ushort Ben_Mobile_No_CoulmnIndex = 0;
            ushort Rem_Mobile_No_CoulmnIndex = 0;
            ushort ChargebackDate_CoulmnIndex = 0;
            ushort Chbref_CoulmnIndex = 0;
            ushort TxnAmount_CoulmnIndex = 0;
            ushort AdjAmount_CoulmnIndex = 0;
            ushort Rem_Fee_CoulmnIndex = 0;
            ushort Ben_Fee_CoulmnIndex = 0;
            ushort BenFeeSW_CoulmnIndex = 0;
            ushort AdjFee_CoulmnIndex = 0;
            ushort NPCIFee_CoulmnIndex = 0;
            ushort Remfeetax_CoulmnIndex = 0;
            ushort Benfeetax_CoulmnIndex = 0;
            ushort Npcitax_CoulmnIndex = 0;
            ushort AdjRef_CoulmnIndex = 0;
            ushort BankAdjRef_CoulmnIndex = 0;
            ushort AdjProof_CoulmnIndex = 0;
            ushort Compensation_amount_CoulmnIndex = 0;
            ushort Adj_Raise_Time_CoulmnIndex = 0;
            ushort No_of_Days_for_Penalty_CoulmnIndex = 0;
            ushort SHDT73_CoulmnIndex = 0;
            ushort SHDT74_CoulmnIndex = 0;
            ushort SHDT75_CoulmnIndex = 0;
            ushort SHDT76_CoulmnIndex = 0;
            ushort SHDT77_CoulmnIndex = 0;
            ushort Transaction_Type_CoulmnIndex = 0;
            ushort Transaction_Indicator_CoulmnIndex = 0;
            ushort Beneficiary_Account_number_CoulmnIndex = 0;
            ushort Remitter_Account_number_CoulmnIndex = 0;
            ushort Aadhar_Number_CoulmnIndex = 0;
            ushort Mobile_Number_CoulmnIndex = 0;
            ushort Payer_PSP_CoulmnIndex = 0;
            ushort Payee_PSP_CoulmnIndex = 0;
            ushort UPI_Transaction_ID_CoulmnIndex = 0;
            ushort Virtual_Address_CoulmnIndex = 0;
            ushort Dispute_Flag_CoulmnIndex = 0;
            ushort Reason_Code_CoulmnIndex = 0;
            ushort MCC_CoulmnIndex = 0;
            ushort Originating_Channel_CoulmnIndex = 0;
            ushort TRANSTIME_CoulmnIndex = 0;
            ushort TRANSDATE_CoulmnIndex = 0;

            DateTime? AdjustmentDate = null;
            DateTime? ChBkdate = null;


            string line1 = string.Empty;
            bool ErrorOccurred = false;
            string[] TxnsDateTime = null;
            string Status = "0";
            string[] colFields = null;
            try
            { 

                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                int j = 0;

                Txnuid_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Txnuid"]);
                Uid_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Uid"]);
                Adjdate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Adjdate"]);
                Adjtype_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Adjtype"]);
                Remitter_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remitter"]);
                Beneficiery_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Beneficiery"]);
                ResponseCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode"]);
                TxnDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnDateTime"]);
                RRN_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RRN"]);
                Terminalid_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Terminalid"]);
                Ben_Mobile_No_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Ben_Mobile_No"]);
                Rem_Mobile_No_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Rem_Mobile_No"]);
                ChargebackDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChargebackDate"]);
                Chbref_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Chbref"]);
                TxnAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnAmount"]);
                AdjAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjAmount"]);
                Rem_Fee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Rem_Fee"]);
                Ben_Fee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Ben_Fee"]);
                BenFeeSW_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Ben_FeeSW"]);
                AdjFee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjFee"]);
                NPCIFee_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["NPCIFee"]);
                Remfeetax_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remfeetax"]);
                Benfeetax_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Benfeetax"]);
                Npcitax_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Npcitax"]);
                AdjRef_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Adjref"]);
                BankAdjRef_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BankAdjRef"]);
                AdjProof_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AdjProof"]);
                Compensation_amount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Compensation_amount"]);
                Adj_Raise_Time_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Adj_Raise_Time"]);
                No_of_Days_for_Penalty_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["No_of_Days_for_Penalty"]);
                SHDT73_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT73"]);
                SHDT74_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT74"]);
                SHDT75_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT75"]);
                SHDT76_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT76"]);
                SHDT77_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SHDT77"]);
                Transaction_Type_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Transaction_Type"]);
                Transaction_Indicator_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Transaction_Indicator"]);
                Beneficiary_Account_number_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Beneficiary_Account_number"]);
                Remitter_Account_number_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remitter_Account_number"]);
                Aadhar_Number_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Aadhar_Number"]);
                Mobile_Number_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Mobile_Number"]);
                Payer_PSP_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Payer_PSP"]);
                Payee_PSP_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Payee_PSP"]);
                UPI_Transaction_ID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UPI_Transaction_ID"]);
                Virtual_Address_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Virtual_Address"]);
                Dispute_Flag_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Dispute_Flag"]);
                Reason_Code_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Reason_Code"]);
                MCC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["MCC"]);
                Originating_Channel_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Originating_Channel"]);
                TRANSTIME_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TRANSDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
                fileImportRequest.TotalCount = TotalCountArray.Length;

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnsDateTime = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                foreach (var batchDetail in fileImportRequest.FailedBatches)
                {
                    if (batchDetail.BatchNo != 0)
                    {
                        BatchNo = batchDetail.BatchNo - 1;
                    }
                    bool NewEntry = false;

                    if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                    {
                        //set the flag if it is new Entry
                        NewEntry = false;
                    }
                    else
                    {
                        if (batchDetail.BatchStatus == "None")
                        {
                            break;
                        }
                        else
                        {
                            //set the flag if it is old and  Partial Entry
                            NewEntry = true;
                        }
                    }
                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            LineNo++;
                            LineNumber++;
                            if (LineNumber == 1)
                            {
                                continue;
                            }
                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                            {
                                continue;
                            }

                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);
                            colFields = new string[0];

                            colFields = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            TxnsDateTimeDiff = string.Empty;

                            Txnuid = string.Empty;
                            Uid = string.Empty;
                            Adjdate = string.Empty;
                            Adjtype = string.Empty;
                            Remitter = string.Empty;
                            Beneficiery = string.Empty;
                            ResponseCode = string.Empty;
                            TxnDateTime = string.Empty;
                            RRN = string.Empty;
                            Terminalid = string.Empty;
                            Ben_Mobile_No = string.Empty;
                            Rem_Mobile_No = string.Empty;
                            ChargebackDate = string.Empty;
                            Chbref = string.Empty;
                            TxnAmount = string.Empty;
                            AdjAmount = string.Empty;
                            Rem_Fee = string.Empty;
                            Ben_Fee = string.Empty;
                            BenFeeSW = string.Empty;
                            AdjFee = string.Empty;
                            NPCIFee = string.Empty;
                            Remfeetax = string.Empty;
                            Benfeetax = string.Empty;
                            Npcitax = string.Empty;
                            AdjRef = string.Empty;
                            BankAdjRef = string.Empty;
                            AdjProof = string.Empty;
                            Compensation_amount = string.Empty;
                            Adj_Raise_Time = string.Empty;
                            No_of_Days_for_Penalty = string.Empty;
                            SHDT73 = string.Empty;
                            SHDT74 = string.Empty;
                            SHDT75 = string.Empty;
                            SHDT76 = string.Empty;
                            SHDT77 = string.Empty;

                            Transaction_Type = string.Empty;
                            Transaction_Indicator = string.Empty;
                            Beneficiary_Account_number = string.Empty;
                            Remitter_Account_number = string.Empty;
                            Aadhar_Number = string.Empty;
                            Mobile_Number = string.Empty;
                            Payer_PSP = string.Empty;
                            Payee_PSP = string.Empty;
                            UPI_Transaction_ID = string.Empty;
                            Virtual_Address = string.Empty;
                            Dispute_Flag = string.Empty;
                            Reason_Code = string.Empty;
                            MCC = string.Empty;
                            Originating_Channel = string.Empty;
                            Transaction_Date = string.Empty;
                            Transaction_Time = string.Empty;
                            // Cycle = string.Empty;


                            Txnuid = Txnuid_CoulmnIndex > 0 ? Convert.ToString(colFields[Txnuid_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Uid = Uid_CoulmnIndex > 0 ? Convert.ToString(colFields[Uid_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Adjdate = Adjdate_CoulmnIndex > 0 ? Convert.ToString(colFields[Adjdate_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Adjtype = Adjtype_CoulmnIndex > 0 ? Convert.ToString(colFields[Adjtype_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Remitter = Remitter_CoulmnIndex > 0 ? Convert.ToString(colFields[Remitter_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Beneficiery = Beneficiery_CoulmnIndex > 0 ? Convert.ToString(colFields[Beneficiery_CoulmnIndex - Incr]).Trim() : string.Empty;
                            ResponseCode = ResponseCode_CoulmnIndex > 0 ? Convert.ToString(colFields[ResponseCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                            TxnDateTime = TxnDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                            RRN = RRN_CoulmnIndex > 0 ? Convert.ToString(colFields[RRN_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Terminalid = Terminalid_CoulmnIndex > 0 ? Convert.ToString(colFields[Terminalid_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Ben_Mobile_No = Ben_Mobile_No_CoulmnIndex > 0 ? Convert.ToString(colFields[Ben_Mobile_No_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Rem_Mobile_No = Rem_Mobile_No_CoulmnIndex > 0 ? Convert.ToString(colFields[Rem_Mobile_No_CoulmnIndex - Incr]).Trim() : string.Empty;
                            ChargebackDate = ChargebackDate_CoulmnIndex > 0 ? Convert.ToString(colFields[ChargebackDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Chbref = Chbref_CoulmnIndex > 0 ? Convert.ToString(colFields[Chbref_CoulmnIndex - Incr]).Trim() : string.Empty;
                            TxnAmount = TxnAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                            AdjAmount = AdjAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[AdjAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Rem_Fee = Rem_Fee_CoulmnIndex > 0 ? Convert.ToString(colFields[Rem_Fee_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Ben_Fee = Ben_Fee_CoulmnIndex > 0 ? Convert.ToString(colFields[Ben_Fee_CoulmnIndex - Incr]).Trim() : string.Empty;
                            BenFeeSW = BenFeeSW_CoulmnIndex > 0 ? Convert.ToString(colFields[BenFeeSW_CoulmnIndex - Incr]).Trim() : string.Empty;
                            AdjFee = AdjFee_CoulmnIndex > 0 ? Convert.ToString(colFields[AdjFee_CoulmnIndex - Incr]).Trim() : string.Empty;
                            NPCIFee = NPCIFee_CoulmnIndex > 0 ? Convert.ToString(colFields[NPCIFee_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Remfeetax = Remfeetax_CoulmnIndex > 0 ? Convert.ToString(colFields[Remfeetax_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Benfeetax = Benfeetax_CoulmnIndex > 0 ? Convert.ToString(colFields[Benfeetax_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Npcitax = Npcitax_CoulmnIndex > 0 ? Convert.ToString(colFields[Npcitax_CoulmnIndex - Incr]).Trim() : string.Empty;
                            AdjRef = AdjRef_CoulmnIndex > 0 ? Convert.ToString(colFields[AdjRef_CoulmnIndex - Incr]).Trim() : string.Empty;
                            BankAdjRef = BankAdjRef_CoulmnIndex > 0 ? Convert.ToString(colFields[BankAdjRef_CoulmnIndex - Incr]).Trim() : string.Empty;
                            AdjProof = AdjProof_CoulmnIndex > 0 ? Convert.ToString(colFields[AdjProof_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Compensation_amount = Compensation_amount_CoulmnIndex > 0 ? Convert.ToString(colFields[Compensation_amount_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Adj_Raise_Time = Adj_Raise_Time_CoulmnIndex > 0 ? Convert.ToString(colFields[Adj_Raise_Time_CoulmnIndex - Incr]).Trim() : string.Empty;
                            No_of_Days_for_Penalty = No_of_Days_for_Penalty_CoulmnIndex > 0 ? Convert.ToString(colFields[No_of_Days_for_Penalty_CoulmnIndex - Incr]).Trim() : string.Empty;
                            SHDT73 = SHDT73_CoulmnIndex > 0 ? Convert.ToString(colFields[SHDT73_CoulmnIndex - Incr]).Trim() : string.Empty;
                            SHDT74 = SHDT74_CoulmnIndex > 0 ? Convert.ToString(colFields[SHDT74_CoulmnIndex - Incr]).Trim() : string.Empty;
                            SHDT75 = SHDT75_CoulmnIndex > 0 ? Convert.ToString(colFields[SHDT75_CoulmnIndex - Incr]).Trim() : string.Empty;
                            SHDT76 = SHDT76_CoulmnIndex > 0 ? Convert.ToString(colFields[SHDT76_CoulmnIndex - Incr]).Trim() : string.Empty;
                            SHDT77 = SHDT77_CoulmnIndex > 0 ? Convert.ToString(colFields[SHDT77_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Transaction_Type = Transaction_Type_CoulmnIndex > 0 ? Convert.ToString(colFields[Transaction_Type_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Transaction_Indicator = Transaction_Indicator_CoulmnIndex > 0 ? Convert.ToString(colFields[Transaction_Indicator_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Beneficiary_Account_number = Beneficiary_Account_number_CoulmnIndex > 0 ? Convert.ToString(colFields[Beneficiary_Account_number_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Remitter_Account_number = Remitter_Account_number_CoulmnIndex > 0 ? Convert.ToString(colFields[Remitter_Account_number_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Aadhar_Number = Aadhar_Number_CoulmnIndex > 0 ? Convert.ToString(colFields[Aadhar_Number_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Mobile_Number = Mobile_Number_CoulmnIndex > 0 ? Convert.ToString(colFields[Mobile_Number_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Payer_PSP = Payer_PSP_CoulmnIndex > 0 ? Convert.ToString(colFields[Payer_PSP_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Payee_PSP = Payee_PSP_CoulmnIndex > 0 ? Convert.ToString(colFields[Payee_PSP_CoulmnIndex - Incr]).Trim() : string.Empty;
                            UPI_Transaction_ID = UPI_Transaction_ID_CoulmnIndex > 0 ? Convert.ToString(colFields[UPI_Transaction_ID_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Virtual_Address = Virtual_Address_CoulmnIndex > 0 ? Convert.ToString(colFields[Virtual_Address_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Dispute_Flag = Dispute_Flag_CoulmnIndex > 0 ? Convert.ToString(colFields[Dispute_Flag_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Reason_Code = Reason_Code_CoulmnIndex > 0 ? Convert.ToString(colFields[Reason_Code_CoulmnIndex - Incr]).Trim() : string.Empty;
                            MCC = MCC_CoulmnIndex > 0 ? Convert.ToString(colFields[MCC_CoulmnIndex - Incr]).Trim() : string.Empty;
                            Originating_Channel = Originating_Channel_CoulmnIndex > 0 ? Convert.ToString(colFields[Originating_Channel_CoulmnIndex - Incr]).Trim() : string.Empty;
                            TRANSTIME = TRANSTIME_CoulmnIndex > 0 ? Convert.ToString(colFields[TRANSTIME_CoulmnIndex - Incr]).Trim() : string.Empty;
                            TRANSDATE = TRANSDATE_CoulmnIndex > 0 ? Convert.ToString(colFields[TRANSDATE_CoulmnIndex - Incr]).Trim() : string.Empty;

                            RRN = RRN.Replace("'", "");
                            Ben_Mobile_No = Ben_Mobile_No.Replace("'", "");
                            Rem_Mobile_No = Rem_Mobile_No.Replace("'", "");
                            Mobile_Number = Mobile_Number.Replace("'", "");



                            #region ValidateField
                            if (TRANSDATE != "" && TRANSTIME != "")
                            {
                                TxnsDateTimeDiff = TRANSDATE + " " + TRANSTIME;

                                TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnsDateTime, CultureInfo.InvariantCulture);
                            }

                            if (TxnsDateTime[0].ToString() != "" && TxnDateTime != "")
                            {
                                TxnsDateTimeMain = DateTime.ParseExact(TxnDateTime, TxnsDateTime, CultureInfo.InvariantCulture);
                            }

                            ChBkdate = ChargebackDate == "-" ? null : DateTime.TryParse(ChargebackDate, out DateTime parsedDate) ? (DateTime?)parsedDate : null; ;
                            AdjustmentDate = DateTime.ParseExact(Adjdate, new[] { "d-MM-yyyy", "d-MMM-yyyy", "d-MM-yy", "d-MMM-yy", "d/MM/yyyy", "d/MMM/yyyy", "d/MM/yy", "d/MMM/yy" }, CultureInfo.InvariantCulture);


                            #endregion ValidateField

                            if (TxnsDateTimeMain != null)
                            {
                                _DataTable.Rows.Add(
                                 Txnuid,
                                 Uid,
                                 AdjustmentDate,
                                 Adjtype,
                                 Remitter,
                                 Beneficiery,
                                 ResponseCode,
                                 TxnsDateTimeMain,
                                 RRN,
                                 Terminalid,
                                 Ben_Mobile_No,
                                 Rem_Mobile_No,
                                 ChBkdate,
                                 Chbref,
                                 TxnAmount,
                                 AdjAmount,
                                 Rem_Fee,
                                 Ben_Fee,
                                 BenFeeSW,
                                 AdjFee,
                                 NPCIFee,
                                 Remfeetax,
                                 Benfeetax,
                                 Npcitax,
                                 AdjRef,
                                 BankAdjRef,
                                 AdjProof,
                                 Compensation_amount,
                                 Adj_Raise_Time,
                                 No_of_Days_for_Penalty,
                                 SHDT73,
                                 SHDT74,
                                 SHDT75,
                                 SHDT76,
                                 SHDT77,
                                 Transaction_Type,
                                 Transaction_Indicator,
                                 Beneficiary_Account_number,
                                 Remitter_Account_number,
                                 Aadhar_Number,
                                 Mobile_Number,
                                 Payer_PSP,
                                 Payee_PSP,
                                 UPI_Transaction_ID,
                                 Virtual_Address,
                                 Dispute_Flag,
                                 Reason_Code,
                                 MCC,
                                 Originating_Channel
                                        );


                                if (_DataTable.Rows.Count >= batchSize)
                                {
                                    BatchNo++;
                                    MSG = bulkimports.BulkInsertNPCIAdjustmentUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                    BatchDetails batchDetails = new BatchDetails
                                    {
                                        BatchNo = BatchNo,
                                        BatchSize = batchSize,
                                        TxnUploadCount = _DataTable.Rows.Count,
                                        TxnsCount = fileImportRequest.InsertCount,
                                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                        FailedCount = ErrorCount,
                                        BatchStartTime = batchStartTime,
                                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                    };

                                    batchDetailsList.Add(batchDetails);
                                    _DataTable.Clear();
                                    ErrorCount = 0;
                                    StartTime = DateTime.Now;

                                    if (NewEntry)
                                    {
                                        break;
                                    }
                                }


                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                        }

                    }

                    LineNo = 0;
                }
            }
            if (_DataTable.Rows.Count > 0)
            {
                BatchNo = BatchNo + 1;

                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                MSG = bulkimports.BulkInsertNPCIAdjustmentUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                BatchDetails batchDetails = new BatchDetails
                {
                    BatchNo = BatchNo,
                    BatchSize = batchSize,
                    TxnUploadCount = _DataTable.Rows.Count,
                    TxnsCount = fileImportRequest.InsertCount,
                    BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                    FailedCount = ErrorCount,
                    BatchStartTime = batchStartTime,
                    BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                };

                batchDetailsList.Add(batchDetails);

                //  _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }

        //Splitter for UPI IMPS_UPI_TimeOut
        public string Splitter_NPCI_IMPS_UPI_TimeOut_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNumber = 0;
            string TempRemark = string.Empty;
            int LineNo = 0, ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;

            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;

            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("REFERENCENO", typeof(string));
            _DataTable.Columns.Add("AMOUNT", typeof(decimal));
            _DataTable.Columns.Add("AccountNumber", typeof(decimal));
            _DataTable.Columns.Add("CYCLE", typeof(string));
            _DataTable.Columns.Add("FILEDATE", typeof(DateTime));
            _DataTable.Columns.Add("REMARKS", typeof(string));
            _DataTable.Columns.Add("TXNTYPE", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));

            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
            string FileDateFormat = fileImportRequest.ConfigData.Rows[0]["FileDateFormat"].ToString();

            DateTime? TxnsDateTimeMain = null;

            DataSet ds = new DataSet();

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            try
            {

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                ushort AccountNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AccountNumber"]);
                ushort Cycle_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Cycle"]);
                ushort ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                ushort Remarks_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remarks"]);
                ushort ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ushort ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ushort TxnAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnAmount"]);
                ushort TxnType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnType"]);
                ushort Date_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TimeOutDate"]);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
                string[] SplitArr = null;
                int largestIndex = 0, CoulmnIndex = 0;

                if (TotalCountArray.Length > 0)
                {

                    batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                    int j = 0;

                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }

                        int Incr = 1;

                        string REFERENCENO = string.Empty;
                        string AMOUNT = string.Empty;
                        string AccountNumber = string.Empty;
                        string CYCLE = string.Empty;
                        string Remarks = string.Empty;
                        string TxnsDate = string.Empty;
                        string TXNTYPE = string.Empty;
                        string ReserveField1 = string.Empty;
                        string ReserveField2 = string.Empty;


                        if (ds.Tables.Count > 0)
                        {
                            for (int x = 0; x < ds.Tables.Count; x++)
                            {
                                foreach (DataRow dr in ds.Tables[x].Rows)
                                {
                                    foreach (DataColumn dc in ds.Tables[x].Columns)
                                    {
                                        CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                        if (CoulmnIndex > largestIndex)
                                        {
                                            largestIndex = CoulmnIndex;
                                        }
                                    }
                                }
                            }
                        }


                        foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                        {

                            LineNumber++;
                            LineNo++;

                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                            {
                                continue;
                            }

                            string line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                            if (SplitArr.Length < largestIndex) continue;


                            Incr = 1;

                            REFERENCENO = string.Empty;
                            AMOUNT = string.Empty;
                            AccountNumber = string.Empty;
                            CYCLE = string.Empty;
                            Remarks = string.Empty;
                            TxnsDate = string.Empty;
                            TXNTYPE = string.Empty;
                            ReserveField1 = string.Empty;
                            ReserveField2 = string.Empty;
                            TxnsDateTimeMain = null;

                            try
                            {

                                AccountNumber = AccountNumber_CoulmnIndex > 0 ? Convert.ToString(SplitArr[AccountNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                CYCLE = Cycle_CoulmnIndex > 0 ? Convert.ToString(SplitArr[Cycle_CoulmnIndex - Incr]).Trim() : string.Empty;
                                REFERENCENO = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(SplitArr[ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                Remarks = Remarks_CoulmnIndex > 0 ? Convert.ToString(SplitArr[Remarks_CoulmnIndex - Incr]).Trim() : string.Empty;
                                ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(SplitArr[ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(SplitArr[ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                AMOUNT = TxnAmount_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TxnAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                TXNTYPE = TxnType_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TxnType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                TxnsDate = Date_CoulmnIndex > 0 ? Convert.ToString(SplitArr[Date_CoulmnIndex - Incr]).Trim() : string.Empty;

                                if (Remarks.Length == 0)
                                {
                                    Remarks = TempRemark;
                                }

                                if (TxnsDate.Length > 0)
                                {
                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDate, TxnDateTime, CultureInfo.InvariantCulture);
                                }
                                else
                                {
                                    TxnsDateTimeMain = FileDateTime;
                                }

                                if (REFERENCENO != "" && TxnsDateTimeMain != null)
                                {
                                    _DataTable.Rows.Add(REFERENCENO, AMOUNT, AccountNumber, CYCLE, TxnsDateTimeMain, Remarks, TXNTYPE, ReserveField1, ReserveField2);
                                }

                            }
                            catch (Exception ex)
                            {
                                ErrorCount++;
                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                            }


                        }
                        LineNo = 0;
                    }
                }



            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            fileImportRequest.TotalCount = LineNumber;

            if (_DataTable.Rows.Count > 0)
            {

                string outParam = string.Empty;

                DataTable dataTable = bulkimports.VerifyIMPSUPITimeOutData(_DataTable, fileImportRequest.ClientCode, Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ChannelID"]), out outParam);

                if (dataTable != null && dataTable.Rows.Count > 0 && outParam == "Successful")
                {
                    MSG = "Following Reference Numbers are not found: ";

                    foreach (DataRow row in dataTable.Rows)
                    {
                        MSG += Convert.ToString(row["ReferenceNumber"]) + ",";
                    }

                    MSG += " Please check the file and upload again.";
                }
                else
                {

                    BatchNo = BatchNo + 1;

                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                    MSG = bulkimports.BulkInsertIMPSUPITimeOutData(_DataTable, DTdetails.ConfigID, DTdetails.FileDateTime, fileImportRequest.Path, fileImportRequest.FileName, fileImportRequest.UserName);
                    // _logger.LogInformation("Batch Completed : {BatchNo}", BatchNo);
                    BatchDetails batchDetails = new BatchDetails
                    {
                        BatchNo = BatchNo,
                        BatchSize = batchSize,
                        TxnUploadCount = _DataTable.Rows.Count,
                        TxnsCount = fileImportRequest.InsertCount,
                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                        FailedCount = ErrorCount,
                        BatchStartTime = batchStartTime,
                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    };

                    batchDetailsList.Add(batchDetails);

                    //  _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);
                }

            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";



            return MSG;

        }

        //Splitter for UPI TimeOut Excel
        public string Splitter_NPCI_IMPS_UPI_TimeOut_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            string TempRemark = string.Empty;
            int LineNo = 0, ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int SheetLineNo = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;

            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("REFERENCENO", typeof(string));
            _DataTable.Columns.Add("AMOUNT", typeof(decimal));
            _DataTable.Columns.Add("AccountNumber", typeof(decimal));
            _DataTable.Columns.Add("CYCLE", typeof(string));
            _DataTable.Columns.Add("FILEDATE", typeof(DateTime));
            _DataTable.Columns.Add("REMARKS", typeof(string));
            _DataTable.Columns.Add("TXNTYPE", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));

            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

            string[] TxnDateTime = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
            string FileDateFormat = fileImportRequest.ConfigData.Rows[0]["FileDateFormat"].ToString();

            DateTime? TxnsDateTimeMain = null;

            string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

            string[] FDA = fileImportRequest.FileName.Split('_', '.');
            string Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

            DataSet ds = new DataSet();

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            try
            {

                conString = string.Format(conString, fileImportRequest.Path);

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                ushort AccountNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AccountNumber"]);
                ushort Cycle_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Cycle"]);
                ushort ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                ushort Remarks_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remarks"]);
                ushort ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ushort ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ushort TxnAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnAmount"]);
                ushort TxnType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnType"]);
                ushort Date_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TimeOutDate"]);


                DataTable dtexcelsheetname = new DataTable();
                DataTable dtSheet = new DataTable();

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }


                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {


                    //  _logger.LogInformation("Ready for read");
                    //Get Batch Size
                    batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);


                    int j = 0;

                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }

                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            string Getdatafromsheet1 = "SELECT * FROM [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = Getdatafromsheet1;
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            int Incr = 1;
                            string REFERENCENO = string.Empty;
                            string AMOUNT = string.Empty;
                            string AccountNumber = string.Empty;
                            string CYCLE = string.Empty;
                            string Remarks = string.Empty;
                            string TxnsDate = string.Empty;
                            string TXNTYPE = string.Empty;
                            string ReserveField1 = string.Empty;
                            string ReserveField2 = string.Empty;


                            if (FileDateFormat.Length > 0)
                            {
                                string dateFile = ExtractNumber(fileImportRequest.FileName).Substring(0, FileDateFormat.Length);
                                try
                                {
                                    FileDateTime = DateTime.ParseExact(dateFile, FileDateFormat, CultureInfo.InvariantCulture);
                                }
                                catch (Exception ex)
                                {
                                    FileDateTime = DateTime.Now;
                                }
                            }
                            else
                            {
                                FileDateTime = DateTime.Now;
                            }

                            if (dtSheet.Rows.Count > 0)
                            {
                                fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                for (int k = 0; k < dtSheet.Rows.Count; k++)
                                {
                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }
                                    Incr = 1;

                                    REFERENCENO = string.Empty;
                                    AMOUNT = string.Empty;
                                    AccountNumber = string.Empty;
                                    CYCLE = string.Empty;
                                    Remarks = string.Empty;
                                    TxnsDate = string.Empty;
                                    TXNTYPE = string.Empty;
                                    ReserveField1 = string.Empty;
                                    ReserveField2 = string.Empty;
                                    TxnsDateTimeMain = null;

                                    try
                                    {

                                        AccountNumber = AccountNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AccountNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        CYCLE = Cycle_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Cycle_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        REFERENCENO = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Remarks = Remarks_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Remarks_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        AMOUNT = TxnAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TXNTYPE = TxnType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsDate = Date_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Date_CoulmnIndex - Incr]).Trim() : string.Empty;

                                        if (Remarks.Length == 0)
                                        {
                                            Remarks = TempRemark;
                                        }

                                        if (TxnsDate.Length > 0)
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDate, TxnDateTime, CultureInfo.InvariantCulture);
                                        }
                                        else
                                        {
                                            TxnsDateTimeMain = FileDateTime;
                                        }

                                        if (REFERENCENO != "" && TxnsDateTimeMain != null)
                                        {
                                            _DataTable.Rows.Add(REFERENCENO, AMOUNT, AccountNumber, CYCLE, TxnsDateTimeMain, Remarks, TXNTYPE, ReserveField1, ReserveField2);
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorCount++;
                                        DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    }

                                    SheetLineNo++;
                                }
                            }

                            j++;
                        }
                        LineNo = 0;
                    }
                }



            }
            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            if (_DataTable.Rows.Count > 0)
            {
                string outParam = string.Empty;

                DataTable dataTable = bulkimports.VerifyIMPSUPITimeOutData(_DataTable, fileImportRequest.ClientCode, Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ChannelID"]), out outParam);

                if (dataTable != null && dataTable.Rows.Count > 0 && outParam == "Successful")
                {
                    MSG = "Following Reference Numbers are not found: ";

                    foreach (DataRow row in dataTable.Rows)
                    {
                        MSG += Convert.ToString(row["ReferenceNumber"]) + ",";
                    }

                    MSG += " Please check the file and upload again.";
                }
                else
                {
                    BatchNo = BatchNo + 1;

                    fileImportRequest.InsertCount += _DataTable.Rows.Count;

                    MSG = bulkimports.BulkInsertIMPSUPITimeOutData(_DataTable, DTdetails.ConfigID, DTdetails.FileDateTime, fileImportRequest.Path, fileImportRequest.FileName, fileImportRequest.UserName);
                    // _logger.LogInformation("Batch Completed : {BatchNo}", BatchNo);
                    BatchDetails batchDetails = new BatchDetails
                    {
                        BatchNo = BatchNo,
                        BatchSize = batchSize,
                        TxnUploadCount = _DataTable.Rows.Count,
                        TxnsCount = fileImportRequest.InsertCount,
                        BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                        FailedCount = ErrorCount,
                        BatchStartTime = batchStartTime,
                        BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    };

                    batchDetailsList.Add(batchDetails);
                }

                //  _logger.LogInformation("Data table count: {fileImportRequest.InsertCount}", fileImportRequest.InsertCount);

            }
            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";


            return MSG;

        }

        public string Splitter_NPCI_UPI_DRC_Excel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            string TempRemark = string.Empty;
            int LineNo = 0, ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int SheetLineNo = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;

            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;
            bool ErrorOccurred = false;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("TxnsUID", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsDate", typeof(string));
            _DataTable.Columns.Add("TxnsTime", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("STAN", typeof(string));
            _DataTable.Columns.Add("Remitter", typeof(string));
            _DataTable.Columns.Add("Beneficiary", typeof(string));
            _DataTable.Columns.Add("BeneficiaryNumber", typeof(string));
            _DataTable.Columns.Add("RemitterNumber", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("UTXNID", typeof(string));
            _DataTable.Columns.Add("PayerPSP", typeof(string));
            _DataTable.Columns.Add("PayeePSP", typeof(string));

            ushort Beneficiary_CoulmnIndex = 0;
            ushort BeneficiaryNumber_CoulmnIndex = 0;
            ushort PayeePSP_CoulmnIndex = 0;
            ushort PayerPSP_CoulmnIndex = 0;
            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort Remitter_CoulmnIndex = 0;
            ushort RemitterNumber_CoulmnIndex = 0;
            ushort ResponseCode_CoulmnIndex = 0;
            ushort SETTLEMENTDATE_CoulmnIndex = 0;
            ushort STAN_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Txns_Date_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsType_CoulmnIndex = 0;
            ushort TxnsUID_CoulmnIndex = 0;
            ushort UTXNID_CoulmnIndex = 0;

            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

            string[] TxnDateTimeDateFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
            string FileDateFormat = fileImportRequest.ConfigData.Rows[0]["FileDateFormat"].ToString();

            DateTime? TxnsDateTimeMain = null;

            string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

            string strFileName = Path.GetFileNameWithoutExtension(fileImportRequest.Path);
            string FD = strFileName.Substring(strFileName.Length - 9);
            string[] FDA = FD.Split('_');

            string Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

            DataSet ds = new DataSet();

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            DataTable dtexcelsheetname = new DataTable();
            DataTable dtSheet = new DataTable();

            try
            {

                //conString = string.Format(conString, path);

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                Beneficiary_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Beneficiary"]);
                BeneficiaryNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneficiaryNumber"]);
                PayeePSP_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeePSP"]);
                PayerPSP_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerPSP"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                Remitter_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remitter"]);
                RemitterNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RemitterNumber"]);
                ResponseCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode"]);
                SETTLEMENTDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SETTLEMENTDATE"]);
                STAN_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["STAN"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                Txns_Date_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TxnsType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsType"]);
                TxnsUID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsUID"]);
                UTXNID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UTXNID"]);

                using (OleDbConnection connExcel = new OleDbConnection(conString))
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        connExcel.Open();
                        //Get the name of First Sheet. 
                        dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        connExcel.Close();
                    }
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            int Incr = 1;
            string Beneficiary = string.Empty;
            string BeneficiaryNumber = string.Empty;
            string PayeePSP = string.Empty;
            string PayerPSP = string.Empty;
            string ReferenceNumber = string.Empty;
            string Remitter = string.Empty;
            string RemitterNumber = string.Empty;
            string ResponseCode = string.Empty;
            string SETTLEMENTDATE = string.Empty;
            string STAN = string.Empty;
            string TxnsAmount = string.Empty;
            string Txns_Date = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsType = string.Empty;
            string TxnsUID = string.Empty;
            string UTXNID = string.Empty;

            if (!ErrorOccurred)
            {
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                {
                    //  _logger.LogInformation("Ready for read"); 

                    string[] excelSheets = new string[dtexcelsheetname.Rows.Count];
                    int j = 0;

                    foreach (var batchDetail in fileImportRequest.FailedBatches)
                    {
                        if (batchDetail.BatchNo != 0)
                        {
                            BatchNo = batchDetail.BatchNo - 1;
                        }
                        bool NewEntry = false;

                        if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                        {
                            //set the flag if it is new Entry
                            NewEntry = false;
                        }
                        else
                        {
                            if (batchDetail.BatchStatus == "None")
                            {
                                break;
                            }
                            else
                            {
                                //set the flag if it is old and  Partial Entry
                                NewEntry = true;
                            }
                        }

                        foreach (DataRow row in dtexcelsheetname.Rows)
                        {
                            dtSheet = new DataTable();

                            using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                            {
                                using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                {
                                    using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                    {
                                        //Read Data from First Sheet.
                                        cmdExcelSheet.Connection = connExcelSheet;
                                        connExcelSheet.Open();
                                        cmdExcelSheet.CommandText = "SELECT * FROM [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]";
                                        odaExcelSheet.SelectCommand = cmdExcelSheet;
                                        odaExcelSheet.Fill(dtSheet);
                                        connExcelSheet.Close();
                                    }
                                }
                            }

                            if (dtSheet.Rows.Count > 0)
                            {
                                fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                for (int k = 0; k < dtSheet.Rows.Count; k++)
                                {
                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }
                                    Incr = 1;

                                    Beneficiary = string.Empty;
                                    BeneficiaryNumber = string.Empty;
                                    PayeePSP = string.Empty;
                                    PayerPSP = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    Remitter = string.Empty;
                                    RemitterNumber = string.Empty;
                                    ResponseCode = string.Empty;
                                    SETTLEMENTDATE = string.Empty;
                                    STAN = string.Empty;
                                    TxnsAmount = string.Empty;
                                    Txns_Date = string.Empty;
                                    TxnsDateTime = string.Empty;
                                    TxnsTime = string.Empty;
                                    TxnsType = string.Empty;
                                    TxnsUID = string.Empty;
                                    UTXNID = string.Empty;

                                    try
                                    {


                                        Beneficiary = Beneficiary_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Beneficiary_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        BeneficiaryNumber = BeneficiaryNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BeneficiaryNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        PayeePSP = PayeePSP_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayeePSP_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        PayerPSP = PayerPSP_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayerPSP_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Remitter = Remitter_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Remitter_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        RemitterNumber = RemitterNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][RemitterNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        ResponseCode = ResponseCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        SETTLEMENTDATE = SETTLEMENTDATE_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SETTLEMENTDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        STAN = STAN_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][STAN_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Txns_Date = Txns_Date_CoulmnIndex > 0 ? Convert.ToDateTime(dtSheet.Rows[k][Txns_Date_CoulmnIndex - Incr]).ToString("dd-MM-yyyy") : string.Empty;
                                        TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToDateTime(dtSheet.Rows[k][TxnsTime_CoulmnIndex - Incr]).ToString("HH:mm:ss") : string.Empty;
                                        TxnsType = TxnsType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsUID = TxnsUID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsUID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        UTXNID = UTXNID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][UTXNID_CoulmnIndex - Incr]).Trim() : string.Empty;

                                        if (Txns_Date != "" && TxnsTime != "")
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(Txns_Date + " " + TxnsTime, TxnDateTimeDateFormat, CultureInfo.InvariantCulture);
                                        }

                                        if (TxnDateTimeDateFormat[0].ToString() != "" && TxnsDateTime != "")
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeDateFormat, CultureInfo.InvariantCulture);
                                        }

                                        ResponseCode = ResponseCode.Trim().Replace("'", "");
                                        ReferenceNumber = ReferenceNumber.Trim().Replace("'", "");
                                        Beneficiary = Beneficiary.Trim().Replace("'", "");
                                        BeneficiaryNumber = BeneficiaryNumber.Trim().Replace("'", "");
                                        RemitterNumber = RemitterNumber.Trim().Replace("'", "");

                                        if (ReferenceNumber != "" && TxnsDateTimeMain != null)
                                        {
                                            _DataTable.Rows.Add(TxnsUID, TxnsType, Txns_Date, TxnsTime, TxnsDateTimeMain, SETTLEMENTDATE, ResponseCode, ReferenceNumber, STAN, Remitter, Beneficiary, BeneficiaryNumber, RemitterNumber, TxnsAmount, UTXNID, PayerPSP, PayeePSP);
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorCount++;
                                        DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    }

                                    SheetLineNo++;
                                }
                            }

                            j++;
                        }

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo = BatchNo + 1;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertUPIDebitReversal(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                        }

                        LineNo = 0;
                    }
                }


            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }


          

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = _DataTable.Rows.Count,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";


            return MSG;

        }
        public string Splitter_NPCI_UPI_DRC_Delimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            string TempRemark = string.Empty;
            int LineNo = 0, ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            int SheetLineNo = 0;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;

            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;
            bool ErrorOccurred = false;

            DtDetails DTdetails = new DtDetails();

            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("TxnsUID", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsDate", typeof(string));
            _DataTable.Columns.Add("TxnsTime", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("SettlementDate", typeof(DateTime));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("STAN", typeof(string));
            _DataTable.Columns.Add("Remitter", typeof(string));
            _DataTable.Columns.Add("Beneficiary", typeof(string));
            _DataTable.Columns.Add("BeneficiaryNumber", typeof(string));
            _DataTable.Columns.Add("RemitterNumber", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("UTXNID", typeof(string));
            _DataTable.Columns.Add("PayerPSP", typeof(string));
            _DataTable.Columns.Add("PayeePSP", typeof(string));

            ushort Beneficiary_CoulmnIndex = 0;
            ushort BeneficiaryNumber_CoulmnIndex = 0;
            ushort PayeePSP_CoulmnIndex = 0;
            ushort PayerPSP_CoulmnIndex = 0;
            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort Remitter_CoulmnIndex = 0;
            ushort RemitterNumber_CoulmnIndex = 0;
            ushort ResponseCode_CoulmnIndex = 0;
            ushort SETTLEMENTDATE_CoulmnIndex = 0;
            ushort STAN_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Txns_Date_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsType_CoulmnIndex = 0;
            ushort TxnsUID_CoulmnIndex = 0;
            ushort UTXNID_CoulmnIndex = 0;

            int ClientID = int.Parse(fileImportRequest.ConfigData.Rows[0]["ClientID"].ToString());
            string xmlFile = fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"].ToString();

            string[] TxnDateTimeFormat = fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"].ToString().Split(new string[] { "," }, StringSplitOptions.None);
            string FileDateFormat = fileImportRequest.ConfigData.Rows[0]["FileDateFormat"].ToString();

            DateTime? TxnsDateTimeMain = null;
            DateTime? SettlementDateTime = null;

            string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

            string strFileName = Path.GetFileNameWithoutExtension(fileImportRequest.Path);
            string FD = strFileName.Substring(strFileName.Length - 9);
            string[] FDA = FD.Split('_');

            string Cycle = FDA.Length > 1 ? FDA[1].ToString() : string.Empty;

            DataSet ds = new DataSet();

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            string[] SplitArr = null;
            string line1 = string.Empty;
            int largestIndex = 0, CoulmnIndex = 0, LineNumber = 0;

            if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
            {
                fileImportRequest.ErrorMessage = "TxnDateTime Format not specified";
                ErrorOccurred = true;
            }

            if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
            {
                fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                ErrorOccurred = true;
            }

            if (!ErrorOccurred)
            {
                try
                {
                    ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                    Beneficiary_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Beneficiary"]);
                    BeneficiaryNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BeneficiaryNumber"]);
                    PayeePSP_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeePSP"]);
                    PayerPSP_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerPSP"]);
                    ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                    Remitter_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Remitter"]);
                    RemitterNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["RemitterNumber"]);
                    ResponseCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode"]);
                    SETTLEMENTDATE_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SETTLEMENTDATE"]);
                    STAN_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["STAN"]);
                    TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                    Txns_Date_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                    TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                    TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                    TxnsType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsType"]);
                    TxnsUID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsUID"]);
                    UTXNID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["UTXNID"]);

                    if (ds.Tables.Count > 0)
                    {
                        for (int x = 0; x < ds.Tables.Count; x++)
                        {
                            foreach (DataRow dr in ds.Tables[x].Rows)
                            {
                                foreach (DataColumn dc in ds.Tables[x].Columns)
                                {
                                    CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                    if (CoulmnIndex > largestIndex)
                                    {
                                        largestIndex = CoulmnIndex;
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    fileImportRequest.ErrorMessage = ex.Message;
                    ErrorOccurred = true;
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }

                if (!ErrorOccurred)
                {
                    string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                    string tempTxnDateTime = string.Empty;

                    if (TotalCountArray.Length > 0)
                    {
                        int dateStartIndex = -1;
                        int i = 0;
                        int Incr = 1;
                        string Txns_Date = string.Empty;
                        string TxnsDateTime = string.Empty;
                        string TxnsTime = string.Empty;

                        foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                        {
                            try
                            {
                                line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                SplitArr = new string[0];

                                SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                if (Txns_Date_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                                {
                                    Txns_Date = Txns_Date_CoulmnIndex > 0 ? Convert.ToString(SplitArr[Txns_Date_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    tempTxnDateTime = Txns_Date + " " + TxnsTime;
                                    bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                    if (isValid)
                                    {
                                        dateStartIndex = i;
                                        break;
                                    }
                                }
                            }
                            catch
                            {
                                dateStartIndex = -1;
                            }

                            i++;

                            if (i > 25)
                                break; 
                            
                        } 

                        if (dateStartIndex > -1)
                        {

                            string Beneficiary = string.Empty;
                            string BeneficiaryNumber = string.Empty;
                            string PayeePSP = string.Empty;
                            string PayerPSP = string.Empty;
                            string ReferenceNumber = string.Empty;
                            string Remitter = string.Empty;
                            string RemitterNumber = string.Empty;
                            string ResponseCode = string.Empty;
                            string SETTLEMENTDATE = string.Empty;
                            string STAN = string.Empty;
                            string TxnsAmount = string.Empty;

                            string TxnsType = string.Empty;
                            string TxnsUID = string.Empty;
                            string UTXNID = string.Empty;

                            //Get Batch Size
                            batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                            foreach (var batchDetail in fileImportRequest.FailedBatches)
                            {
                                if (batchDetail.BatchNo != 0)
                                {
                                    BatchNo = batchDetail.BatchNo - 1;
                                }
                                bool NewEntry = false;

                                if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                                {
                                    //set the flag if it is new Entry
                                    NewEntry = false;
                                }
                                else
                                {
                                    if (batchDetail.BatchStatus == "None")
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        //set the flag if it is old and  Partial Entry
                                        NewEntry = true;
                                    }
                                }

                                foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                                {
                                    LineNo++;
                                    LineNumber++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }
                                    Incr = 1;

                                    Beneficiary = string.Empty;
                                    BeneficiaryNumber = string.Empty;
                                    PayeePSP = string.Empty;
                                    PayerPSP = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    Remitter = string.Empty;
                                    RemitterNumber = string.Empty;
                                    ResponseCode = string.Empty;
                                    SETTLEMENTDATE = string.Empty;
                                    STAN = string.Empty;
                                    TxnsAmount = string.Empty;
                                    Txns_Date = string.Empty;
                                    TxnsDateTime = string.Empty;
                                    TxnsTime = string.Empty;
                                    TxnsType = string.Empty;
                                    TxnsUID = string.Empty;
                                    UTXNID = string.Empty;
                                    SettlementDateTime = null;

                                    try
                                    {
                                        line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                        SplitArr = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                        if (SplitArr.Length < largestIndex) continue;

                                        Beneficiary = Beneficiary_CoulmnIndex > 0 ? Convert.ToString(SplitArr[Beneficiary_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        BeneficiaryNumber = BeneficiaryNumber_CoulmnIndex > 0 ? Convert.ToString(SplitArr[BeneficiaryNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        PayeePSP = PayeePSP_CoulmnIndex > 0 ? Convert.ToString(SplitArr[PayeePSP_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        PayerPSP = PayerPSP_CoulmnIndex > 0 ? Convert.ToString(SplitArr[PayerPSP_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(SplitArr[ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Remitter = Remitter_CoulmnIndex > 0 ? Convert.ToString(SplitArr[Remitter_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        RemitterNumber = RemitterNumber_CoulmnIndex > 0 ? Convert.ToString(SplitArr[RemitterNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        ResponseCode = ResponseCode_CoulmnIndex > 0 ? Convert.ToString(SplitArr[ResponseCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        SETTLEMENTDATE = SETTLEMENTDATE_CoulmnIndex > 0 ? Convert.ToString(SplitArr[SETTLEMENTDATE_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        STAN = STAN_CoulmnIndex > 0 ? Convert.ToString(SplitArr[STAN_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TxnsAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        Txns_Date = Txns_Date_CoulmnIndex > 0 ? Convert.ToDateTime(SplitArr[Txns_Date_CoulmnIndex - Incr]).ToString("dd-MM-yyyy") : string.Empty;
                                        TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToDateTime(SplitArr[TxnsTime_CoulmnIndex - Incr]).ToString("HH:mm:ss") : string.Empty;
                                        TxnsType = TxnsType_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TxnsType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        TxnsUID = TxnsUID_CoulmnIndex > 0 ? Convert.ToString(SplitArr[TxnsUID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                        UTXNID = UTXNID_CoulmnIndex > 0 ? Convert.ToString(SplitArr[UTXNID_CoulmnIndex - Incr]).Trim() : string.Empty;

                                        if (Txns_Date != "" && TxnsTime != "")
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(Txns_Date + " " + TxnsTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                        }

                                        if (TxnDateTimeFormat[0].ToString() != "" && TxnsDateTime != "")
                                        {
                                            TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                        }

                                        if (SETTLEMENTDATE.Length > 0)
                                        {
                                            SettlementDateTime = DateTime.ParseExact(SETTLEMENTDATE, new[] { "d/M/yyyy", "d/M/yy" }, null, DateTimeStyles.None);
                                        }

                                        ResponseCode = ResponseCode.Trim().Replace("'", "");
                                        ReferenceNumber = ReferenceNumber.Trim().Replace("'", "");
                                        Beneficiary = Beneficiary.Trim().Replace("'", "");
                                        BeneficiaryNumber = BeneficiaryNumber.Trim().Replace("'", "");
                                        RemitterNumber = RemitterNumber.Trim().Replace("'", "");

                                        if (ReferenceNumber != "" && TxnsDateTimeMain != null)
                                        {
                                            _DataTable.Rows.Add(TxnsUID, TxnsType, Txns_Date, TxnsTime, TxnsDateTimeMain, SettlementDateTime, ResponseCode, ReferenceNumber, STAN, Remitter, Beneficiary, BeneficiaryNumber, RemitterNumber, TxnsAmount, UTXNID, PayerPSP, PayeePSP);
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        ErrorCount++;
                                        DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    }


                                }
                            }

                            fileImportRequest.SkippedRows = dateStartIndex;
                            fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                            if (_DataTable.Rows.Count > 0)
                            {
                                BatchNo = BatchNo + 1;

                                fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                MSG = bulkimports.BulkInsertUPIDebitReversal(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                            }
                            else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                            {
                                BatchNo++;
                                MSG = "Successful";
                            }
                        }
                        else
                        {
                            if (dateStartIndex == -1 && i == 1)
                            {
                                BatchNo++;
                                fileImportRequest.ErrorMessage = "The file contains no data or Header is present on first line.";
                                MSG = fileImportRequest.ErrorMessage;
                            }
                            else
                            {
                                BatchNo++;
                                if (tempTxnDateTime.Length > 0)
                                {
                                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                                }
                                else
                                {
                                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + " File is Empty OR DateTime Format not matched;  ";
                                }
                                MSG = fileImportRequest.ErrorMessage;
                            }
                        }
                    }
                    else
                    {
                        BatchNo++;
                        fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                        MSG = fileImportRequest.ErrorMessage;
                    }
                }
                else
                {
                    BatchNo++;
                    MSG = fileImportRequest.ErrorMessage;
                }

            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }


            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = _DataTable.Rows.Count,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }

    }
}
