﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO; 
using System.Text.RegularExpressions;
using System.Xml;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Packaging;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using System.Linq;
using Utility;
using ImportData;
using System.Reflection;

namespace NetworkNPCI
{
    public class ProcessPosSetFileSpliter
    { 
        private readonly string _connectionString;
        BulkImports bulkimports;
        public ProcessPosSetFileSpliter()
        {

        }
        public ProcessPosSetFileSpliter(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        string TransactionDate = string.Empty;
        string CardNumber = string.Empty;
        string TransactionType = string.Empty;
        string IssuerReferenceNumber = string.Empty;
        string RRNumber = string.Empty;
        string TerminalID = string.Empty;
        string StanNumber = string.Empty;
        string Amount = string.Empty;
        string TransactionCurrency = string.Empty;
        string TransactionStatus = string.Empty;
        string Remarks = string.Empty;

        internal void variable()
        {
            TransactionDate = string.Empty;
            CardNumber = string.Empty;
            TransactionType = string.Empty;
            IssuerReferenceNumber = string.Empty;
            RRNumber = string.Empty;
            TerminalID = string.Empty;
            StanNumber = string.Empty;
            Amount = string.Empty;
            TransactionCurrency = string.Empty;
            TransactionStatus = string.Empty;
            Remarks = string.Empty;
        }
        public System.Data.DataTable ExtractExcel(string fullPath, string FileName)
        {
            
            System.Data.DataTable dtExcel = new System.Data.DataTable();
            try
            {
                var excelFileToImport = Directory.GetFiles(Path.GetDirectoryName(fullPath), FileName, System.IO.SearchOption.AllDirectories);
                using (SpreadsheetDocument doc = SpreadsheetDocument.Open(excelFileToImport[0], false))
                {
                    Sheet sheet = doc.WorkbookPart.Workbook.Sheets.GetFirstChild<Sheet>();
                    Worksheet titlesWorksheet = (doc.WorkbookPart.GetPartById(sheet.Id.Value) as WorksheetPart).Worksheet;
                    IEnumerable<Row> rows = titlesWorksheet.GetFirstChild<SheetData>().Descendants<Row>();
                    foreach (Cell cell in rows.ElementAt(0))
                    {
                        dtExcel.Columns.Add(GetCellValue(doc, cell)); // this will include 2nd row a header row
                    }
                    foreach (Row row in rows)
                    {
                        if (row.RowIndex.Value > 1) //this will exclude first two rows
                        {
                            System.Data.DataRow tempRow = dtExcel.NewRow();
                            int columnIndex = 0;
                            foreach (Cell cell in row.Descendants<Cell>())
                            {
                                int cellColumnIndex = (int)GetColumnIndexFromName(GetColumnName(cell.CellReference));
                                cellColumnIndex--; //zero based index
                                if (columnIndex < cellColumnIndex)
                                {
                                    do
                                    {
                                        tempRow[columnIndex] = ""; //Insert blank data here;
                                        columnIndex++;
                                    }
                                    while (columnIndex < cellColumnIndex);
                                }
                                tempRow[columnIndex] = GetCellValue(doc, cell);

                                columnIndex++;
                            }
                            dtExcel.Rows.Add(tempRow);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            return dtExcel;
        }
        public static string GetCellValue(SpreadsheetDocument document, Cell cell)
        {
            SharedStringTablePart stringTablePart = document.WorkbookPart.SharedStringTablePart;
            if (cell.CellValue == null)
            {
                return "";
            }
            string value = cell.CellValue.InnerXml;
            if (cell.DataType != null && cell.DataType.Value == CellValues.SharedString)
            {
                return stringTablePart.SharedStringTable.ChildElements[Int32.Parse(value)].InnerText;
            }
            else
            {
                return value;
            }
        }
        public static string GetColumnName(string cellReference)
        {
            // Create a regular expression to match the column name portion of the cell name.
            Regex regex = new Regex("[A-Za-z]+");
            Match match = regex.Match(cellReference);
            return match.Value;
        }
        public static int? GetColumnIndexFromName(string columnName)
        {
            //return columnIndex;
            string name = columnName;
            int number = 0;
            int pow = 1;
            for (int i = name.Length - 1; i >= 0; i--)
            {
                number += (name[i] - 'A' + 1) * pow;
                pow *= 26;
            }
            return number;
        }
        protected DataTable ProcessSummarySpliter(string SummaryFilePath, DataTable dt1, DataTable _DataTable, string UserName, string BankCode, string FileName, string ConnectionString, out int InsertCount, out int TotalCount)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            int LineNo = 0;
            InsertCount = 0;
            TotalCount = 0;
            int ErrorCount = 0;
            string FileName1 = System.IO.Path.GetFileNameWithoutExtension(SummaryFilePath); 

            DataSet ds = new DataSet();
            string LogType = dt1.Rows[0]["FileName"].ToString();
            string xmlFile = dt1.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = dt1.Rows[0]["RevEntryLeg"].ToString();
            ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            int ClientID = int.Parse(dt1.Rows[0]["ClientID"].ToString()); 
            
          
            DataTable dtfillsheet1 = new DataTable();
            try
            {
                //dtfillsheet1 = ExtractExcel(SummaryFilePath, FileName);

                if (SummaryFilePath.Contains("DSRSummaryReport"))
                {
                    dtfillsheet1 = ExtractExcel(SummaryFilePath, FileName);
                    //DateTime SettlementDate;
                    decimal TxnAmtDR = 0; decimal TxnAmtCR = 0;
                    decimal SETAMTDR = 0; decimal SETAMTCR = 0;
                    decimal IntFeeAmtDR = 0; decimal IntFeeAmtCR = 0;
                    decimal MemIncFeeAmtDR = 0; decimal MemIncFeeAmtCR = 0;
                    decimal OthFeeAmtDR = 0; decimal OthFeeAmtCR = 0;
                    decimal OthFeeGSTDR = 0; decimal OthFeeGSTCR = 0;
                    decimal CusCmpnstnDr = 0; decimal CusCmpnstnCr = 0;
                    decimal FinalSumCr = 0; decimal FinalSumDr = 0; decimal FinalNet = 0; Boolean FlagA = false; Boolean FlagNA = false;
                    Boolean FlagR = false;

                    TotalCount = dtfillsheet1.Rows.Count;

                    for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                    {
                        try
                        {

                            string[] columnNames = dtfillsheet1.Columns.Cast<DataColumn>()
                                .Select(x => x.ColumnName).ToArray();
                            string col = dtfillsheet1.Rows[0][6].ToString();
                            string Setdate = dtfillsheet1.Rows[0][0].ToString();
                            string dt = DateTime.ParseExact(Setdate, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);//Convert.ToDateTime(Setdate);
                            //SettlementDate = DateTime.ParseExact(dt.ToString(), "yyyy-MM-dd", CultureInfo.InvariantCulture);

                            if (columnNames[6] == "Status(Approved/Declined)")
                            {
                                string status = dtfillsheet1.Rows[i][6].ToString(); if (status == "A") { FlagA = true; FlagNA = false; }
                                if (status == "D" || dtfillsheet1.Rows[i][5].ToString() == "Total") { FlagA = false; FlagNA = false; }
                                if (status == "NA") { FlagNA = true; FlagA = false; }
                                string status1 = dtfillsheet1.Rows[i][5].ToString();
                                string tmp = dtfillsheet1.Rows[i][7].ToString();
                                string Channel = dtfillsheet1.Rows[i][9].ToString();
                                if (tmp == "Refund" && dtfillsheet1.Rows[i][5].ToString() == "")
                                {
                                    FlagR = true;
                                    //Channel = "Refund" + " " + Channel;
                                }
                                else if (dtfillsheet1.Rows[i][5].ToString() != "")
                                {
                                    FlagR = false;
                                }
                                if (FlagR == true)
                                {
                                    Channel = "Refund" + " " + Channel;
                                }

                                if (FlagA == true || FlagNA == true)
                                {
                                    //string TxnCount = dtfillsheet1.Rows[TableCount][10].ToString();
                                    string TxnCount = dtfillsheet1.Rows[i][10].ToString();
                                    string TxnAmtDR1 = dtfillsheet1.Rows[i][12].ToString();
                                    TxnAmtDR = Convert.ToDecimal(TxnAmtDR1);
                                    string TxnAmtCR1 = dtfillsheet1.Rows[i][13].ToString();
                                    TxnAmtCR = Convert.ToDecimal(TxnAmtCR1);
                                    string SETAMTDR1 = dtfillsheet1.Rows[i][15].ToString();
                                    SETAMTDR = Convert.ToDecimal(SETAMTDR1);
                                    string SETAMTCR1 = dtfillsheet1.Rows[i][16].ToString();
                                    SETAMTCR = Convert.ToDecimal(SETAMTCR1);
                                    string IntFeeAmtDR1 = dtfillsheet1.Rows[i][17].ToString();
                                    IntFeeAmtDR = Convert.ToDecimal(IntFeeAmtDR1);
                                    string IntFeeAmtCR1 = dtfillsheet1.Rows[i][18].ToString();
                                    IntFeeAmtCR = Convert.ToDecimal(IntFeeAmtCR1);
                                    string MemIncFeeAmtDR1 = dtfillsheet1.Rows[i][19].ToString();
                                    MemIncFeeAmtDR = Convert.ToDecimal(MemIncFeeAmtDR1);
                                    string MemIncFeeAmtCR1 = dtfillsheet1.Rows[i][20].ToString();
                                    MemIncFeeAmtCR = Convert.ToDecimal(MemIncFeeAmtCR1);
                                    string CusCmpnstnDr1 = dtfillsheet1.Rows[i][21].ToString();
                                    CusCmpnstnDr = Convert.ToDecimal(MemIncFeeAmtDR1);
                                    string CusCmpnstnCr1 = dtfillsheet1.Rows[i][22].ToString();
                                    CusCmpnstnCr = Convert.ToDecimal(MemIncFeeAmtCR1);
                                    string OthFeeAmtDR1 = dtfillsheet1.Rows[i][23].ToString();
                                    OthFeeAmtDR = Convert.ToDecimal(OthFeeAmtDR1);
                                    string OthFeeAmtCR1 = dtfillsheet1.Rows[i][24].ToString();
                                    OthFeeAmtCR = Convert.ToDecimal(OthFeeAmtCR1);
                                    string OthFeeGSTDR1 = dtfillsheet1.Rows[i][25].ToString();
                                    OthFeeGSTDR = Convert.ToDecimal(OthFeeGSTDR1);
                                    string OthFeeGSTCR1 = dtfillsheet1.Rows[i][26].ToString();
                                    OthFeeGSTCR = Convert.ToDecimal(OthFeeGSTCR1);
                                    string FinalSumCr1 = dtfillsheet1.Rows[i][27].ToString();
                                    FinalSumCr = Convert.ToDecimal(FinalSumCr1);
                                    string FinalSumDr1 = dtfillsheet1.Rows[i][28].ToString();
                                    FinalSumDr = Convert.ToDecimal(FinalSumDr1);
                                    string FinalNet1 = dtfillsheet1.Rows[i][29].ToString();
                                    FinalNet = Convert.ToDecimal(FinalNet1);
                                    string spname = "DSRSummaryReport";
                                    string[] temp = FileName.Split('.');
                                    string tempCycle = temp[0];
                                    char Cycle = tempCycle[tempCycle.Length - 1];

                                    TxnCount = TxnCount.IndexOf(".") > 0 ? TxnCount.Trim().Substring(0, TxnCount.Trim().IndexOf(".")).Trim() : TxnCount.Trim();

                                    TxnCount = Common.IsNumeric(TxnCount) ? Convert.ToInt32(TxnCount).ToString() : "0";
                                    //if (FlagNA == true) Channel = "NA_" + Channel;
                                    //if (FlagA == true) Channel = "A_" + Channel;
                                    _DataTable.Rows.Add(ClientID, dt, TxnCount, TxnAmtDR, TxnAmtCR, SETAMTDR, SETAMTCR, IntFeeAmtDR, IntFeeAmtCR, MemIncFeeAmtDR, MemIncFeeAmtCR,
                                                         OthFeeAmtDR, OthFeeAmtCR, OthFeeGSTDR, OthFeeGSTCR, FinalSumCr, FinalSumDr, FinalNet, Cycle, DateTime.Now, DateTime.Now, UserName, UserName, Channel, CusCmpnstnDr, CusCmpnstnCr, spname);

                                    InsertCount++;

                                }
                                if (status1 == "INWARD GST")
                                {

                                    string OthFeeGSTDR1 = dtfillsheet1.Rows[i][25].ToString();
                                    OthFeeGSTDR = Convert.ToDecimal(OthFeeGSTDR1);
                                    string OthFeeGSTCR1 = dtfillsheet1.Rows[i][26].ToString();
                                    OthFeeGSTCR = Convert.ToDecimal(OthFeeGSTCR1);
                                    string FinalSumCr1 = dtfillsheet1.Rows[i][27].ToString();
                                    FinalSumCr = Convert.ToDecimal(FinalSumCr1);
                                    string FinalSumDr1 = dtfillsheet1.Rows[i][28].ToString();
                                    FinalSumDr = Convert.ToDecimal(FinalSumDr1);
                                    string FinalNet1 = dtfillsheet1.Rows[i][29].ToString();
                                    FinalNet = Convert.ToDecimal(FinalNet1);
                                    string spname = "DSRSummaryReport";
                                    string[] temp = FileName.Split('.');
                                    string tempCycle = temp[0];
                                    char Cycle = tempCycle[tempCycle.Length - 1];
                                    Channel = "INWARD GST";

                                    _DataTable.Rows.Add(ClientID, dt, null, null, null, null, null, null, null, null, null,
                                                     null, null, OthFeeGSTDR, OthFeeGSTCR, FinalSumCr, FinalSumDr, FinalNet, Cycle, DateTime.Now, DateTime.Now, UserName, UserName, status1, null, null, spname);

                                    InsertCount++;
                                }
                            }
                            LineNo++;
                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            //InsertCount--;
                            //_log.FunErrorLog(ex.Message.ToString(), BankCode, "ProcessIssuerFileSpliterNPCI", "ProcessBFSFileSpliterBOB", LineNo, FileName, UserName, 'E');
                            //_FileImport.FileImportLog("issuer File", BankCode, FileName, System.DateTime.Now, UserName, LineNo, InsertCount, TotalCount, "Unsuccessful", ex.Message, ConnectionString);
                            DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                    }
                }
                else if (SummaryFilePath.Contains("InterchangeSummaryReport"))
                {
                    //DateTime SettlementDate;
                    dtfillsheet1 = ExtractExcel(SummaryFilePath, FileName);
                    decimal Amt_CR = 0; decimal Amt_DR = 0;
                    decimal Fee_CR = 0; decimal Fee_DR = 0;
                    Boolean FlagP = false; Boolean FlagNA = false; Boolean FlagE = false;
                    string Channel = string.Empty;

                    TotalCount = dtfillsheet1.Rows.Count;

                    for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                    {
                        try
                        {
                            //string col = dtfillsheet1.Columns[5].ColumnName;
                            //if(col == "Inward/ Outward")
                            if (dtfillsheet1.Rows[i][5].ToString() != "Total" && dtfillsheet1.Rows[i][4].ToString() != "Total" && dtfillsheet1.Rows[i][3].ToString() != "Total"
                                 && dtfillsheet1.Rows[i][2].ToString() != "Total" && dtfillsheet1.Rows[i][1].ToString() != "Total")
                            {

                                Channel = dtfillsheet1.Rows[i][8].ToString();
                                if (Channel == "POS") { FlagP = true; FlagE = false; }
                                if (Channel == "ECOM") { FlagP = false; FlagE = true; }
                                if (dtfillsheet1.Rows[i][6].ToString() == "Refund") FlagNA = true;

                                if (FlagP == true && FlagNA == false) Channel = "POS"; if (FlagE == true && FlagNA == false) Channel = "ECOM";
                                if (FlagNA == true && FlagP == true) Channel = "Refund_POS"; if (FlagNA == true && FlagE == true) Channel = "Refund_ECOM";

                                string Setdate = dtfillsheet1.Rows[0][0].ToString();
                                // SettlementDate = Convert.ToDateTime(Setdate);
                                string dt = DateTime.ParseExact(Setdate, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                                string TxnCount = dtfillsheet1.Rows[i][10].ToString();
                                string Amt_CR1 = dtfillsheet1.Rows[i][12].ToString();
                                Amt_CR = Convert.ToDecimal(Amt_CR1);
                                string Amt_DR1 = dtfillsheet1.Rows[i][13].ToString();
                                Amt_DR = Convert.ToDecimal(Amt_DR1);
                                string Fee_CR1 = dtfillsheet1.Rows[i][14].ToString();
                                Fee_CR = Convert.ToDecimal(Fee_CR1);
                                string Fee_DR1 = dtfillsheet1.Rows[i][15].ToString();
                                Fee_DR = Convert.ToDecimal(Fee_DR1);

                                string spname = "InterchangeSummaryReport";

                                string[] temp = FileName.Split('.');
                                string tempCycle = temp[0];
                                char Cycle = tempCycle[tempCycle.Length - 1];

                                TxnCount = TxnCount.IndexOf(".") > 0 ? TxnCount.Trim().Substring(0, TxnCount.Trim().IndexOf(".")).Trim() : TxnCount.Trim();

                                TxnCount = Common.IsNumeric(TxnCount) ? Convert.ToInt32(TxnCount).ToString() : "0";

                                _DataTable.Rows.Add(ClientID, dt, TxnCount, Amt_CR, Amt_DR, Fee_CR, Fee_DR, Cycle, Channel, DateTime.Now, DateTime.Now, UserName, UserName, spname);

                                InsertCount++;
                            }
                            LineNo++;
                        }
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            // InsertCount--;
                            //_log.FunErrorLog(ex.Message.ToString(), BankCode, "ProcessIssuerFileSpliterNPCI", "ProcessBFSFileSpliterBOB", LineNo, FileName, UserName, 'E');
                            //_FileImport.FileImportLog("issuer File", BankCode, FileName, System.DateTime.Now, UserName, LineNo, InsertCount, TotalCount, "Unsuccessful", ex.Message, ConnectionString);
                            DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                    }
                }
                else if (SummaryFilePath.Contains("NPCIBillingSummary"))
                {
                    // DateTime SettlementDate;
                    dtfillsheet1 = ExtractExcel(SummaryFilePath, FileName);
                    decimal FeeAmt = 0; decimal FeeAmtGST = 0;
                    decimal Fee = 0;

                    TotalCount = dtfillsheet1.Rows.Count;

                    for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                    {
                        try
                        {
                            if (dtfillsheet1.Rows[i][5].ToString() != "Total" && dtfillsheet1.Rows[i][4].ToString() != "Total" && dtfillsheet1.Rows[i][3].ToString() != "Total"
                                 && dtfillsheet1.Rows[i][2].ToString() != "Total" && dtfillsheet1.Rows[i][1].ToString() != "Total")
                            {
                                string Setdate = dtfillsheet1.Rows[0][0].ToString();
                                // SettlementDate = Convert.ToDateTime(Setdate);
                                string dt = DateTime.ParseExact(Setdate, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                                string TxnCount = dtfillsheet1.Rows[i][8].ToString();
                                string FeeAmt1 = dtfillsheet1.Rows[i][10].ToString();
                                FeeAmt = Convert.ToDecimal(FeeAmt1);
                                string FeeAmtGST1 = dtfillsheet1.Rows[i][11].ToString();
                                FeeAmtGST = Convert.ToDecimal(FeeAmtGST1);
                                string Fee1 = dtfillsheet1.Rows[i][12].ToString();
                                Fee = Convert.ToDecimal(Fee1);
                                string Description = dtfillsheet1.Rows[i][6].ToString();
                                string spname = "NPCIBillingSummary";

                                string[] temp = FileName.Split('.');
                                string tempCycle = temp[0];
                                char Cycle = tempCycle[tempCycle.Length - 1];

                                TxnCount = TxnCount.IndexOf(".") > 0 ? TxnCount.Trim().Substring(0, TxnCount.Trim().IndexOf(".")).Trim() : TxnCount.Trim();

                                TxnCount = Common.IsNumeric(TxnCount) ? Convert.ToInt32(TxnCount).ToString() : "0";

                                _DataTable.Rows.Add(ClientID, dt, TxnCount, FeeAmt, FeeAmtGST, Fee, Cycle, DateTime.Now, DateTime.Now, UserName, UserName, Description, spname);

                                InsertCount++;
                            }
                            LineNo++;
                        }
                        //try
                        //{
                        //    string Setdate = dtfillsheet1.Rows[0][0].ToString();
                        //    // SettlementDate = Convert.ToDateTime(Setdate);
                        //    string dt = DateTime.ParseExact(Setdate, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                        //    string TxnCount = dtfillsheet1.Rows[TableCount][8].ToString();
                        //    string FeeAmt1 = dtfillsheet1.Rows[TableCount][10].ToString();
                        //    FeeAmt = Convert.ToDecimal(FeeAmt1);
                        //    string FeeAmtGST1 = dtfillsheet1.Rows[TableCount][11].ToString();
                        //    FeeAmtGST = Convert.ToDecimal(FeeAmtGST1);
                        //    string Fee1 = dtfillsheet1.Rows[TableCount][12].ToString();
                        //    Fee = Convert.ToDecimal(Fee1);

                        //    string spname = "NPCIBillingSummary";

                        //    _DataTable.Rows.Add(dt, TxnCount, FeeAmt, FeeAmtGST, Fee, DateTime.Now, DateTime.Now, UserName, UserName, spname);
                        //    LineNo++;
                        //}
                        catch (Exception ex)
                        {
                            ErrorCount++;
                            // InsertCount--;
                            //_log.FunErrorLog(ex.Message.ToString(), BankCode, "ProcessIssuerFileSpliterNPCI", "ProcessBFSFileSpliterBOB", LineNo, FileName, UserName, 'E');
                            //   _FileImport.FileImportLog("issuer File", BankCode, FileName, System.DateTime.Now, UserName, LineNo, InsertCount, TotalCount, "Unsuccessful", ex.Message, ConnectionString);
                            DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                    }

                }

                else if (SummaryFilePath.Contains("NetSettlementReport"))
                {
                    // DateTime SettlementDate;
                    dtfillsheet1 = ExtractExcel(SummaryFilePath, FileName);
                    decimal FinalSumCr = 0; decimal FinalSumDr = 0;
                    decimal Net = 0;

                    TotalCount = dtfillsheet1.Rows.Count;

                    for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                    {
                        try
                        {
                            if (dtfillsheet1.Rows[i][5].ToString() != "Total" && dtfillsheet1.Rows[i][4].ToString() != "Total" && dtfillsheet1.Rows[i][3].ToString() != "Total"
                                 && dtfillsheet1.Rows[i][2].ToString() != "Total" && dtfillsheet1.Rows[i][1].ToString() != "Total")
                            {
                                string Setdate = dtfillsheet1.Rows[0][0].ToString();
                                //DateTime SettlementDate = Convert.ToDateTime(Setdate);
                                //DateTime dt = DateTime.ParseExact(Setdate.ToString().Trim(), "dd-MMM-yy", CultureInfo.InvariantCulture);
                                string dt = DateTime.ParseExact(Setdate, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                                string MemberBankPID = dtfillsheet1.Rows[i][3].ToString();
                                string MemberBankType = dtfillsheet1.Rows[i][4].ToString();
                                string DRCR = dtfillsheet1.Rows[i][5].ToString();
                                string FinalSumCr1 = dtfillsheet1.Rows[i][6].ToString();
                                FinalSumCr = Convert.ToDecimal(FinalSumCr1);
                                string FinalSumDr1 = dtfillsheet1.Rows[i][7].ToString();
                                FinalSumDr = Convert.ToDecimal(FinalSumDr1);
                                string Net1 = dtfillsheet1.Rows[i][8].ToString();
                                Net = Convert.ToDecimal(Net1);

                                string spname = "NetSettlementReport";
                                string[] temp = FileName.Split('.');
                                string tempCycle = temp[0];
                                //char Cycle = tempCycle[tempCycle.Length - 1];
                                string Cycle = tempCycle.Substring(tempCycle.Length - 1, 1);
                                
                                _DataTable.Rows.Add(ClientID, dt, MemberBankPID, MemberBankType, DRCR, FinalSumCr, FinalSumDr, Net, Cycle, DateTime.Now, DateTime.Now, UserName, UserName, spname);

                                InsertCount++;
                            }
                            LineNo++;
                        }

                        catch (Exception ex)
                        {
                            ErrorCount++;
                            // InsertCount--;
                            //_log.FunErrorLog(ex.Message.ToString(), BankCode, "ProcessIssuerFileSpliterNPCI", "ProcessBFSFileSpliterBOB", LineNo, FileName, UserName, 'E');
                            DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                    }

                }

                else if (SummaryFilePath.Contains("Presentment"))
                {
                    string[] TotalCountArray = File.ReadAllLines(SummaryFilePath);
                    TotalCount = TotalCountArray.Length;

                    foreach (string line in File.ReadAllLines(SummaryFilePath))
                    {
                        LineNo++;
                        try
                        {

                            string line1 = Regex.Replace(line, "[^ -~]+", string.Empty);// dt.Rows[0]["SeparatorType"].ToString()
                            line1 = line.Replace("/", "").Replace("\"", "");
                            string[] colFields = line1.Split(new string[] { "," }, StringSplitOptions.None);
                            DateTime ReportDate;
                            DateTime RaiseDate;
                            DateTime SettlementDate;
                            string Description = string.Empty;
                            string PAN = string.Empty;
                            DateTime Date;
                            string RRN = string.Empty;
                            string ProcessingCode = string.Empty;
                            string CurrencyCode = string.Empty;
                            string Indicator = string.Empty;
                            Decimal AmountTransaction;
                            Decimal AmountAdditional;
                            Decimal SettlementTxnAmount;
                            Decimal SettlementAddAmount;
                            string ApprovalCode = string.Empty;
                            string OriginatorPoint = string.Empty;
                            string POSEntryMode = string.Empty;
                            string POSConditionCode = string.Empty;
                            string AcquirerID = string.Empty;
                            string AcquirerInstitutionID = string.Empty;
                            string AcquirerNameandCountry = string.Empty;
                            string IssuerID = string.Empty;
                            string IssuerInstitutionID = string.Empty;
                            string IssuerNameandCountry = string.Empty;
                            string CardType = string.Empty;
                            string CardBrand = string.Empty;
                            string CardAcceptorTerminalID = string.Empty;
                            string CardAcceptorName = string.Empty;
                            string CardAcceptoraddress = string.Empty;
                            string CardAcceptorCountryCode = string.Empty;
                            string CardAcceptorBusinessCode = string.Empty;
                            string CardAcceptorIDCode = string.Empty;
                            string CardAcceptorStateName = string.Empty;
                            string CardAcceptorCity = string.Empty;
                            string DaysAged = string.Empty;
                            string MTI = string.Empty;
                            string CreatedBy = string.Empty;
                            DateTime CreatedOn;
                            string ModifiedBy = string.Empty;
                            DateTime ModifiedOn;

                            ReportDate = DateTime.ParseExact(colFields[0].ToString().Trim(), "dd-MMM-yy", CultureInfo.InvariantCulture);
                            RaiseDate = DateTime.ParseExact(colFields[1].ToString().Trim(), "dd-MMM-yy", CultureInfo.InvariantCulture);
                            SettlementDate = DateTime.ParseExact(colFields[2].ToString().Trim(), "dd-MMM-yy", CultureInfo.InvariantCulture);
                            Description = colFields[3].ToString().Trim();
                            PAN = colFields[4].ToString().Trim();
                            Date = DateTime.ParseExact(colFields[5].ToString().Trim(), "dd-MMM-yy", CultureInfo.InvariantCulture);
                            RRN = colFields[6].ToString().Trim();
                            string[] RRN1 = RRN.Split('-');
                            RRN = RRN1[1].ToString();
                            ProcessingCode = colFields[7].ToString().Trim();
                            CurrencyCode = colFields[8].ToString().Trim();
                            Indicator = colFields[9].ToString().Trim();
                            AmountTransaction = Convert.ToDecimal(colFields[10].ToString().Trim());
                            AmountAdditional = Convert.ToDecimal(colFields[11].ToString().Trim());
                            SettlementTxnAmount = Convert.ToDecimal(colFields[12].ToString().Trim());
                            SettlementAddAmount = Convert.ToDecimal(colFields[13].ToString().Trim());
                            ApprovalCode = colFields[14].ToString().Trim();
                            OriginatorPoint = colFields[15].ToString().Trim();
                            POSEntryMode = colFields[16].ToString().Trim();
                            POSConditionCode = colFields[17].ToString().Trim();
                            AcquirerID = colFields[18].ToString().Trim();
                            AcquirerInstitutionID = colFields[19].ToString().Trim();
                            AcquirerNameandCountry = colFields[20].ToString().Trim();
                            IssuerID = colFields[21].ToString().Trim();
                            IssuerInstitutionID = colFields[22].ToString().Trim();
                            IssuerNameandCountry = colFields[23].ToString().Trim();
                            CardType = colFields[24].ToString().Trim();
                            CardBrand = colFields[25].ToString().Trim();
                            CardAcceptorTerminalID = colFields[26].ToString().Trim();
                            CardAcceptorTerminalID = CardAcceptorTerminalID.Replace("'", "");
                            CardAcceptorName = colFields[27].ToString().Trim();
                            CardAcceptoraddress = colFields[28].ToString().Trim();
                            CardAcceptorCountryCode = colFields[29].ToString().Trim();
                            CardAcceptorBusinessCode = colFields[30].ToString().Trim();
                            CardAcceptorIDCode = colFields[31].ToString().Trim();
                            CardAcceptorIDCode = CardAcceptorIDCode.Replace("'", "");
                            CardAcceptorStateName = colFields[32].ToString().Trim();
                            CardAcceptorCity = colFields[33].ToString().Trim();
                            DaysAged = colFields[34].ToString().Trim();
                            MTI = colFields[35].ToString().Trim();


                            _DataTable.Rows.Add(ClientID, ReportDate, RaiseDate, SettlementDate, Description, PAN, Date, RRN, ProcessingCode, CurrencyCode, Indicator, AmountTransaction, AmountAdditional, SettlementTxnAmount, SettlementAddAmount, ApprovalCode, OriginatorPoint,
                            POSEntryMode, POSConditionCode, AcquirerID, AcquirerInstitutionID, AcquirerNameandCountry, IssuerID, IssuerInstitutionID, IssuerNameandCountry, CardType, CardBrand, CardAcceptorTerminalID, CardAcceptorName, CardAcceptoraddress, CardAcceptorCountryCode, CardAcceptorBusinessCode, CardAcceptorIDCode,
                            CardAcceptorStateName, CardAcceptorCity, DaysAged, MTI, UserName, DateTime.Now, UserName, DateTime.Now, "Presentment");
                            InsertCount++;
                            LineNo++;
                        }

                        catch (Exception ex)
                        {
                            ErrorCount++;
                            // InsertCount--;
                            //_log.FunErrorLog(ex.Message.ToString(), BankCode, "ProcessIssuerFileSpliterNPCI", "Presentment", LineNo, FileName, UserName, 'E');
                            //   _FileImport.FileImportLog("issuer File", BankCode, FileName, System.DateTime.Now, UserName, LineNo, InsertCount, TotalCount, "Unsuccessful", ex.Message, ConnectionString);
                            DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                        }
                    }

                }

                if (_DataTable.Rows.Count == 0)
                {
                    ErrorCount++;
                    // InsertCount--;
                    //_log.FunErrorLog("Transaction not found", BankCode, "ProcessSummarySpliter", "ProcessSummarySpliter", LineNo, FileName, UserName, 'E');
                    DBLog.InsertLogs("Transaction not found", BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                }
            }
            catch (Exception ex)
            {
                ErrorCount++;
                // InsertCount--;

                //_log.FunErrorLog(EX.Message.ToString(), BankCode, "ProcessSummarySpliter", "ProcessSummarySpliter", LineNo, FileName, UserName, 'E');
                //   _FileImport.FileImportLog("issuer File", BankCode, FileName, System.DateTime.Now, UserName, LineNo, InsertCount, TotalCount, "Unsuccessful", EX.Message, ConnectionString);
                DBLog.InsertLogs(ex.Message.ToString(), BankCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            return _DataTable;
        }

        public string ConvertNPCIExcel(string OldFilepath, string OldFileName)
        {
            string NewFileName = "";
            try
            {

                NewFileName = OldFilepath.Replace(OldFileName, "");
                string extension = Path.GetExtension(OldFileName);
                NewFileName = NewFileName + OldFileName.Replace(extension, "") + "_New" + extension;

                string xmlPathName = OldFilepath;

                //NewFileName = @"D:\Rupali\SVN_Live\Ankita\sachinSir\files\NTSLSMU020919_1C_backup.xls";
                Excel.Application activeExcel = new Excel.Application();
                Excel.Workbook openWorkBook;
                openWorkBook = activeExcel.Workbooks.Open(xmlPathName);
                openWorkBook.SaveAs(NewFileName, Excel.XlFileFormat.xlExcel9795);
                openWorkBook.Close();

            }
            catch (Exception ex)
            {
                //LogWriter objLogWriter = new LogWriter();

                NewFileName = OldFileName;
            }

            return NewFileName;
        }
    }
}
