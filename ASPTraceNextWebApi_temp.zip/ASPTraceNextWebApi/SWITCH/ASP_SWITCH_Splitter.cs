﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Xml;
using Utility;
using System.Text.RegularExpressions;
using System.Text.Json;
using ImportData;
using System.Reflection;

namespace SWITCH
{
    public class ASP_SWITCH_Splitter
    {

        private readonly string _connectionString;
        public ASP_SWITCH_Splitter(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
        }

        public string SplitterExcel_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("AcquirerID", typeof(string));
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
            _DataTable.Columns.Add("ATMAccountNo", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
            _DataTable.Columns.Add("ATMBalance", typeof(decimal));
            _DataTable.Columns.Add("BranchCode", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string NoOfDuplicate = string.Empty;
            string ECardNumber = string.Empty;

            string NetworkType = string.Empty;

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;


            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;

            ushort AcquirerID_CoulmnIndex = 0;
            ushort TerminalID_CoulmnIndex = 0;
            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort CardNumber_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort InterchangeAccountNo_CoulmnIndex = 0;
            ushort ATMAccountNo_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Amount1_CoulmnIndex = 0;
            ushort DestinationAmount_CoulmnIndex = 0;
            //ushort Amount2_CoulmnIndex = 0;
            //ushort Amount3_CoulmnIndex = 0;

            ushort TxnsSubType_CoulmnIndex = 0;
            ushort ChannelType_CoulmnIndex = 0;
            ushort TxnsNumber_CoulmnIndex = 0;
            ushort TxnsPerticulars_CoulmnIndex = 0;
            ushort DrCrType_CoulmnIndex = 0;
            ushort ResponseCode1_CoulmnIndex = 0;
            ushort ResponseCode2_CoulmnIndex = 0;
            ushort ReversalCode1_CoulmnIndex = 0;
            ushort ReversalCode2_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort TxnsValueDateTime_CoulmnIndex = 0;
            ushort AuthCode_CoulmnIndex = 0;
            ushort ProcessingCode_CoulmnIndex = 0;
            ushort FeeAmount_CoulmnIndex = 0;
            //ushort CurrencyCode_CoulmnIndex = 0;
            ushort CustBalance_CoulmnIndex = 0;
            ushort InterchangeBalance_CoulmnIndex = 0;
            ushort ATMBalance_CoulmnIndex = 0;
            ushort BranchCode_CoulmnIndex = 0;
            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;
            ushort ReserveField5_CoulmnIndex = 0;

            string PostTxnsDate = string.Empty;
            string PostTxnsTime = string.Empty;
            ushort PostTxnsDate_CoulmnIndex = 0;
            ushort PostTxnsTime_CoulmnIndex = 0;

            string RevEntryLeg = string.Empty;

            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeDateFormat = null;

            bool ErrorOccurred = false;

            try
            {
                DataSet ds = new DataSet();

                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                AcquirerID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AcquirerID"]);
                TerminalID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TerminalID"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                CardNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CardNumber"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                InterchangeAccountNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InterchangeAccountNo"]);
                ATMAccountNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ATMAccountNo"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                Amount1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount1"]);
                DestinationAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationAmount"]);
                // Amount2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount2"]);
                // Amount3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount3"]);

                TxnsSubType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsSubType"]);
                ChannelType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChannelType"]);
                TxnsNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsNumber"]);
                TxnsPerticulars_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPerticulars"]);
                DrCrType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DrCrType"]);
                ResponseCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode1"]);
                ResponseCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode2"]);
                ReversalCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode1"]);
                ReversalCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode2"]);
                TxnsPostDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPostDateTime"]);
                TxnsValueDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsValueDateTime"]);
                AuthCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AuthCode"]);
                ProcessingCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ProcessingCode"]);
                FeeAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FeeAmount"]);
                // CurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CurrencyCode"]);
                CustBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CustBalance"]);
                InterchangeBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InterchangeBalance"]);
                ATMBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ATMBalance"]);
                BranchCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BranchCode"]);
                ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ReserveField3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField3"]);
                ReserveField4_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField4"]);
                ReserveField5_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField5"]);

                PostTxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PostDate"]);
                PostTxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PostTime"]);

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTimeFormat Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeDateFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty; 

                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                try
                {
                    DataTable dtexcelsheetname = new DataTable();
                    DataTable dtSheet = new DataTable();
                    //Read the connection string for the Excel file.
                    string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                    conString = string.Format(conString, fileImportRequest.Path);

                    using (OleDbConnection connExcel = new OleDbConnection(conString))
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            connExcel.Open();
                            //Get the name of First Sheet. 
                            dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            connExcel.Close();
                        }
                    }

                    if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                    {

                        int j = 0;
                        int SheetLineNumber = 0;

                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }
                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }


                            foreach (DataRow row in dtexcelsheetname.Rows)
                            {
                                dtSheet = new DataTable();

                                using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                                {
                                    using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                    {
                                        using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                        {
                                            //Read Data from First Sheet.
                                            cmdExcelSheet.Connection = connExcelSheet;
                                            connExcelSheet.Open();
                                            cmdExcelSheet.CommandText = "SELECT * From [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                                            odaExcelSheet.SelectCommand = cmdExcelSheet;
                                            odaExcelSheet.Fill(dtSheet);
                                            connExcelSheet.Close();
                                        }
                                    }
                                }

                                Incr = 1;

                                if (dtSheet.Rows.Count > 0)
                                {
                                    // Find first data row based on whether the "Join Date" cell can be parsed as a date
                                    int dateStartIndex = -1;

                                    for (int i = 0; i < dtSheet.Rows.Count; i++)
                                    {
                                        try
                                        {
                                            if (TxnsDateTime_CoulmnIndex > 0)
                                            {
                                                tempTxnDateTime = dtSheet.Rows[i][TxnsDateTime_CoulmnIndex - Incr]?.ToString()?.Trim();

                                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                                if (isValid)
                                                {
                                                    dateStartIndex = i;
                                                    break;
                                                }
                                            }
                                            else if (TxnsDate_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                                            {
                                                tempTxnDateTime = dtSheet.Rows[i][TxnsDate_CoulmnIndex - Incr]?.ToString()?.Trim() + " " + dtSheet.Rows[i][TxnsTime_CoulmnIndex - Incr]?.ToString()?.Trim();

                                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                                if (isValid)
                                                {
                                                    dateStartIndex = i;
                                                    break;
                                                }
                                            }
                                        }
                                        catch
                                        {
                                            SheetDateError++;
                                        }

                                        if (i > 25)
                                            break;
                                    }

                                    // Remove rows before first data row
                                    if (dateStartIndex > -1)
                                    {
                                        fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                                        {
                                            LineNo++;
                                            SheetLineNumber++;
                                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                            {
                                                continue;
                                            }
                                            try
                                            {
                                                TerminalID = string.Empty;
                                                AcquirerID = string.Empty;
                                                ReferenceNumber = string.Empty;
                                                CardNumber = string.Empty;
                                                FromAccount = string.Empty;
                                                ToAccount = string.Empty;
                                                InterchangeAccountNo = string.Empty;
                                                ATMAccountNo = string.Empty;
                                                TxnsDateTime = string.Empty;
                                                TxnsDate = string.Empty;
                                                TxnsTime = string.Empty;
                                                TxnsAmount = "0";
                                                Amount1 = "0";
                                                Amount2 = "0";
                                                Amount3 = "0";
                                                ChannelType = string.Empty;
                                                TxnsSubType = string.Empty;
                                                TxnsNumber = string.Empty;
                                                TxnsPerticulars = string.Empty;
                                                DrCrType = string.Empty;
                                                ResponseCode1 = string.Empty;
                                                ResponseCode2 = string.Empty;
                                                ReversalCode1 = string.Empty;
                                                ReversalCode2 = string.Empty;
                                                TxnsPostDateTime = string.Empty;
                                                TxnsValueDateTime = string.Empty;
                                                TxnsDateTimeDiff = string.Empty;
                                                AuthCode = string.Empty;
                                                ProcessingCode = string.Empty;
                                                FeeAmount = "0";
                                                CurrencyCode = string.Empty;
                                                CustBalance = "0";
                                                InterchangeBalance = "0";
                                                ATMBalance = "0";
                                                DestinationAmount = "0";
                                                BranchCode = string.Empty;
                                                ReserveField1 = string.Empty;
                                                ReserveField2 = string.Empty;
                                                ReserveField3 = string.Empty;
                                                ReserveField4 = string.Empty;
                                                ReserveField5 = string.Empty;
                                                NoOfDuplicate = string.Empty;
                                                ECardNumber = string.Empty;
                                                DestinationCurrencyCode = string.Empty;
                                                SourceCurrencyCode = string.Empty;
                                                NetworkType = string.Empty;

                                                AcquirerID = AcquirerID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AcquirerID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TerminalID = TerminalID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TerminalID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                CardNumber = CardNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CardNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                InterchangeAccountNo = InterchangeAccountNo_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][InterchangeAccountNo_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ATMAccountNo = ATMAccountNo_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ATMAccountNo_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsAmount_CoulmnIndex - Incr]) : string.Empty;
                                                Amount1 = Amount1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Amount1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DestinationAmount = DestinationAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DestinationAmount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsSubType = TxnsSubType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsSubType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ChannelType = ChannelType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ChannelType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsNumber = TxnsNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsPerticulars = TxnsPerticulars_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsPerticulars_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DrCrType = DrCrType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DrCrType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ResponseCode1 = ResponseCode1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode1_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ResponseCode2 = ResponseCode2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReversalCode1 = ReversalCode1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReversalCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReversalCode2 = ReversalCode2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReversalCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsValueDateTime = TxnsValueDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsValueDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AuthCode = AuthCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AuthCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ProcessingCode = ProcessingCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ProcessingCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                FeeAmount = FeeAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FeeAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                //CurrencyCode = CurrencyCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                CustBalance = CustBalance_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][CustBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                InterchangeBalance = InterchangeBalance_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][InterchangeBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ATMBalance = ATMBalance_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ATMBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                BranchCode = BranchCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][BranchCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField5 = ReserveField5_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField5_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                PostTxnsDate = PostTxnsDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PostTxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                PostTxnsTime = PostTxnsTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PostTxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                #region StanderedFields 

                                                ReversalFlag = false;
                                                TxnsStatus = string.Empty;
                                                DebitCreditType = string.Empty;
                                                TxnsType = string.Empty;
                                                TxnsSubTypeMain = string.Empty;
                                                TxnsEntryType = string.Empty;
                                                CardType = string.Empty;
                                                TxnsDateTimeMain = null;
                                                TxnsPostDateTimeMain = null;



                                                #region ValidateField
                                                if (TxnsDate != "" && TxnsTime != "")
                                                {
                                                    TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                                {
                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (PostTxnsDate != "" && PostTxnsTime != "")
                                                {
                                                    if (PostTxnsTime.Length < 6 && !PostTxnsTime.Contains(":"))
                                                    {
                                                        PostTxnsTime = PostTxnsTime.PadLeft(6, '0');
                                                    }

                                                    TxnsPostDateTimeMain = DateTime.ParseExact(PostTxnsDate + " " + PostTxnsTime, TxnPostDateTimeDateFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (TxnPostDateTimeDateFormat[0].ToString() != "" && TxnsPostDateTime != "")
                                                {
                                                    TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnPostDateTimeDateFormat, CultureInfo.InvariantCulture);
                                                }

                                                #endregion ValidateField


                                                #endregion StanderedFields


                                                if (CardNumber != "")
                                                {
                                                    ECardNumber = AesEncryption.EncryptString(CardNumber);
                                                }

                                                if (CardNumber != "" && CardNumber.Length == 16)
                                                {
                                                    CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();
                                                }

                                                CardType = Common.GetCardType(CardNumber);

                                                TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                                Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                                DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                                FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";
                                                CustBalance = Common.IsNumeric(CustBalance) ? CustBalance : "0";
                                                InterchangeBalance = Common.IsNumeric(InterchangeBalance) ? InterchangeBalance : "0";
                                                ATMBalance = Common.IsNumeric(ATMBalance) ? ATMBalance : "0";

                                                if (TxnsDateTimeMain != null)
                                                {
                                                    _DataTable.Rows.Add(AcquirerID
                                                            , ChannelType
                                                            , TerminalID
                                                            , ReferenceNumber
                                                            , CardNumber.Trim()
                                                            , FromAccount
                                                            , ToAccount
                                                            , InterchangeAccountNo
                                                            , ATMAccountNo
                                                            , TxnsDateTimeMain
                                                            , Convert.ToDecimal(TxnsAmount)
                                                            , Convert.ToDecimal(DestinationAmount)
                                                            , Convert.ToDecimal(FeeAmount)
                                                            , Convert.ToDecimal(Amount1)
                                                            , SourceCurrencyCode
                                                            , DestinationCurrencyCode
                                                            , TxnsStatus
                                                            , TxnsType
                                                            , TxnsSubType
                                                            , TxnsEntryType
                                                            , TxnsNumber
                                                            , TxnsPerticulars
                                                            , DrCrType
                                                            , AuthCode
                                                            , ProcessingCode
                                                            , ResponseCode1
                                                            , ResponseCode2
                                                            , ReversalCode1
                                                            , ReversalCode2
                                                            , ReversalFlag
                                                            , TxnsPostDateTimeMain
                                                            , TxnsValueDateTimeMain
                                                            , RevEntryLeg
                                                            , Convert.ToDecimal(CustBalance)
                                                            , Convert.ToDecimal(InterchangeBalance)
                                                            , Convert.ToDecimal(ATMBalance)
                                                            , BranchCode
                                                            , ReserveField1
                                                            , ReserveField2
                                                            , ReserveField3
                                                            , ReserveField4
                                                            , ReserveField5
                                                            , ECardNumber.Trim()
                                                            , CardType
                                                            , NetworkType
                                                            );


                                                    if (_DataTable.Rows.Count >= batchSize)
                                                    {
                                                        BatchNo++;
                                                        MSG = bulkimports.BulkInsertSWITCHTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                        fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                                        BatchDetails batchDetailsPartial = new BatchDetails
                                                        {
                                                            BatchNo = BatchNo,
                                                            BatchSize = batchSize,
                                                            TxnUploadCount = _DataTable.Rows.Count,
                                                            TxnsCount = fileImportRequest.InsertCount,
                                                            BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                            FailedCount = ErrorCount,
                                                            BatchStartTime = batchStartTime,
                                                            BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                        };

                                                        batchDetailsList.Add(batchDetailsPartial);
                                                        _DataTable.Clear();
                                                        ErrorCount = 0;
                                                        StartTime = DateTime.Now;

                                                        if (NewEntry)
                                                        {
                                                            break;
                                                        }
                                                    }

                                                }

                                            }
                                            catch (Exception ex)
                                            {
                                                ErrorCount++;
                                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                            }
                                            j++;
                                        }
                                    }
                                    else
                                    {
                                        if (j == 0)
                                        {
                                            BatchNo++;
                                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime String : " + tempTxnDateTime;
                                            MSG = fileImportRequest.ErrorMessage;
                                        }
                                        break;
                                    }
                                }

                                if (fileImportRequest.ErrorMessage.Trim().Length > 0)
                                {
                                    break;
                                }
                            }
                            LineNo = 0;
                        }
                    }

                    if (fileImportRequest.ErrorMessage.Trim().Length > 0)
                    {
                        BatchNo++;
                        MSG = fileImportRequest.ErrorMessage; 
                    }
                    else
                    {
                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertSWITCHTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                             
                        }
                        else if (fileImportRequest.ErrorMessage.Length == 0 && _DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                        else
                        {
                            BatchNo++;
                            MSG = fileImportRequest.ErrorMessage; 
                        }
                    }
                }
                catch (Exception ex)
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = ex.Message; 
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage; 
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = 0,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = 1,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }
        public string SplitterDelimiter_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0, LineNumber = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;


            DtDetails DTdetails = new DtDetails();

            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);



            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("AcquirerID", typeof(string));
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
            _DataTable.Columns.Add("ATMAccountNo", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
            _DataTable.Columns.Add("ATMBalance", typeof(decimal));
            _DataTable.Columns.Add("BranchCode", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string NoOfDuplicate = string.Empty;
            string ECardNumber = string.Empty;

            string NetworkType = string.Empty;

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;

            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;
            string RevEntryLeg = string.Empty;

            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeDateFormat = null;

            string[] colFields = null;
            string line1 = string.Empty;
            bool ErrorOccurred = false;

            ushort AcquirerID_CoulmnIndex = 0;
            ushort TerminalID_CoulmnIndex = 0;
            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort CardNumber_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort InterchangeAccountNo_CoulmnIndex = 0;
            ushort ATMAccountNo_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Amount1_CoulmnIndex = 0;
            ushort DestinationAmount_CoulmnIndex = 0;
            ushort SourceCurrencyCode_CoulmnIndex = 0;
            ushort DestinationCurrencyCode_CoulmnIndex = 0;

            ushort TxnsSubType_CoulmnIndex = 0;
            ushort ChannelType_CoulmnIndex = 0;
            ushort TxnsNumber_CoulmnIndex = 0;
            ushort TxnsPerticulars_CoulmnIndex = 0;
            ushort DrCrType_CoulmnIndex = 0;
            ushort ResponseCode1_CoulmnIndex = 0;
            ushort ResponseCode2_CoulmnIndex = 0;
            ushort ReversalCode1_CoulmnIndex = 0;
            ushort ReversalCode2_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort TxnsValueDateTime_CoulmnIndex = 0;
            ushort AuthCode_CoulmnIndex = 0;
            ushort ProcessingCode_CoulmnIndex = 0;
            ushort FeeAmount_CoulmnIndex = 0;
            //ushort CurrencyCode_CoulmnIndex = 0;
            ushort CustBalance_CoulmnIndex = 0;
            ushort InterchangeBalance_CoulmnIndex = 0;
            ushort ATMBalance_CoulmnIndex = 0;
            ushort BranchCode_CoulmnIndex = 0;
            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;
            ushort ReserveField5_CoulmnIndex = 0;

            string PostTxnsDate = string.Empty;
            string PostTxnsTime = string.Empty;
            ushort PostTxnsDate_CoulmnIndex = 0;
            ushort PostTxnsTime_CoulmnIndex = 0;

            int largestIndex = 0, CoulmnIndex = 0;

            try
            {

                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                AcquirerID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AcquirerID"]);
                TerminalID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TerminalID"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                CardNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CardNumber"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                InterchangeAccountNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InterchangeAccountNo"]);
                ATMAccountNo_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ATMAccountNo"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                Amount1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount1"]);
                DestinationAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationAmount"]);
                SourceCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SourceCurrencyCode"]);
                DestinationCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationCurrencyCode"]);

                TxnsSubType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsSubType"]);
                ChannelType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChannelType"]);
                TxnsNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsNumber"]);
                TxnsPerticulars_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPerticulars"]);
                DrCrType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DrCrType"]);
                ResponseCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode1"]);
                ResponseCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode2"]);
                ReversalCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode1"]);
                ReversalCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode2"]);
                TxnsPostDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPostDateTime"]);
                TxnsValueDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsValueDateTime"]);
                AuthCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AuthCode"]);
                ProcessingCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ProcessingCode"]);
                FeeAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FeeAmount"]);
                //ushort CurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CurrencyCode"]);
                CustBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["CustBalance"]);
                InterchangeBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["InterchangeBalance"]);
                ATMBalance_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ATMBalance"]);
                BranchCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["BranchCode"]);
                ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ReserveField3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField3"]);
                ReserveField4_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField4"]);
                ReserveField5_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField5"]);

                PostTxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PostDate"]);
                PostTxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PostTime"]); 

                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTimeFormat Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeDateFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }


            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            colFields = new string[0];

                            colFields = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);


                            if (TxnsDateTime_CoulmnIndex > 0)
                            {
                                TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                
                                tempTxnDateTime = TxnsDateTime;

                                bool isValid = DateTime.TryParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                            else if (TxnsDate_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                            {
                                TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;

                                tempTxnDateTime = TxnsDate + " " + TxnsTime;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }

                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                try
                                {
                                    if (LineNo < dateStartIndex)
                                    {
                                        LineNumber++;
                                        LineNo++;
                                        continue;
                                    }


                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                    colFields = new string[0];

                                    colFields = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                    if (colFields.Length < largestIndex) continue;

                                    LineNumber++;

                                    TerminalID = string.Empty;
                                    AcquirerID = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    CardNumber = string.Empty;
                                    FromAccount = string.Empty;
                                    ToAccount = string.Empty;
                                    InterchangeAccountNo = string.Empty;
                                    ATMAccountNo = string.Empty;
                                    TxnsDateTime = string.Empty;
                                    TxnsDate = string.Empty;
                                    TxnsTime = string.Empty;
                                    TxnsAmount = "0";
                                    Amount1 = "0";
                                    Amount2 = "0";
                                    Amount3 = "0";
                                    ChannelType = string.Empty;
                                    TxnsSubType = string.Empty;
                                    TxnsNumber = string.Empty;
                                    TxnsPerticulars = string.Empty;
                                    DrCrType = string.Empty;
                                    ResponseCode1 = string.Empty;
                                    ResponseCode2 = string.Empty;
                                    ReversalCode1 = string.Empty;
                                    ReversalCode2 = string.Empty;
                                    TxnsPostDateTime = string.Empty;
                                    TxnsValueDateTime = string.Empty;
                                    TxnsDateTimeDiff = string.Empty;
                                    AuthCode = string.Empty;
                                    ProcessingCode = string.Empty;
                                    FeeAmount = "0";
                                    CurrencyCode = string.Empty;
                                    CustBalance = "0";
                                    InterchangeBalance = "0";
                                    ATMBalance = "0";
                                    DestinationAmount = "0";
                                    BranchCode = string.Empty;
                                    ReserveField1 = string.Empty;
                                    ReserveField2 = string.Empty;
                                    ReserveField3 = string.Empty;
                                    ReserveField4 = string.Empty;
                                    ReserveField5 = string.Empty;
                                    NoOfDuplicate = string.Empty;
                                    ECardNumber = string.Empty;
                                    DestinationCurrencyCode = string.Empty;
                                    SourceCurrencyCode = string.Empty;
                                    NetworkType = string.Empty;

                                    AcquirerID = AcquirerID_CoulmnIndex > 0 ? Convert.ToString(colFields[AcquirerID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TerminalID = TerminalID_CoulmnIndex > 0 ? Convert.ToString(colFields[TerminalID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(colFields[ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    CardNumber = CardNumber_CoulmnIndex > 0 ? Convert.ToString(colFields[CardNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    InterchangeAccountNo = InterchangeAccountNo_CoulmnIndex > 0 ? Convert.ToString(colFields[InterchangeAccountNo_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ATMAccountNo = ATMAccountNo_CoulmnIndex > 0 ? Convert.ToString(colFields[ATMAccountNo_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsAmount_CoulmnIndex - Incr]) : string.Empty;
                                    Amount1 = Amount1_CoulmnIndex > 0 ? Convert.ToString(colFields[Amount1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DestinationAmount = DestinationAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[DestinationAmount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    TxnsSubType = TxnsSubType_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsSubType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    ChannelType = ChannelType_CoulmnIndex > 0 ? Convert.ToString(colFields[ChannelType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsNumber = TxnsNumber_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsNumber_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsPerticulars = TxnsPerticulars_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsPerticulars_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DrCrType = DrCrType_CoulmnIndex > 0 ? Convert.ToString(colFields[DrCrType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ResponseCode1 = ResponseCode1_CoulmnIndex > 0 ? Convert.ToString(colFields[ResponseCode1_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    ResponseCode2 = ResponseCode2_CoulmnIndex > 0 ? Convert.ToString(colFields[ResponseCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReversalCode1 = ReversalCode1_CoulmnIndex > 0 ? Convert.ToString(colFields[ReversalCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReversalCode2 = ReversalCode2_CoulmnIndex > 0 ? Convert.ToString(colFields[ReversalCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsValueDateTime = TxnsValueDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsValueDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    AuthCode = AuthCode_CoulmnIndex > 0 ? Convert.ToString(colFields[AuthCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ProcessingCode = ProcessingCode_CoulmnIndex > 0 ? Convert.ToString(colFields[ProcessingCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    FeeAmount = FeeAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[FeeAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    //CurrencyCode = CurrencyCode_CoulmnIndex > 0 ? Convert.ToString(colFields[CurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    CustBalance = CustBalance_CoulmnIndex > 0 ? Convert.ToString(colFields[CustBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    InterchangeBalance = InterchangeBalance_CoulmnIndex > 0 ? Convert.ToString(colFields[InterchangeBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ATMBalance = ATMBalance_CoulmnIndex > 0 ? Convert.ToString(colFields[ATMBalance_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    BranchCode = BranchCode_CoulmnIndex > 0 ? Convert.ToString(colFields[BranchCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField5 = ReserveField5_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField5_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    DestinationCurrencyCode = DestinationCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(colFields[DestinationCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    SourceCurrencyCode = SourceCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(colFields[SourceCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    PostTxnsDate = PostTxnsDate_CoulmnIndex > 0 ? Convert.ToString(colFields[PostTxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    PostTxnsTime = PostTxnsTime_CoulmnIndex > 0 ? Convert.ToString(colFields[PostTxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;


                                    #region StanderedFields 

                                    ReversalFlag = false;
                                    TxnsStatus = string.Empty;
                                    DebitCreditType = string.Empty;
                                    TxnsType = string.Empty;
                                    TxnsSubTypeMain = string.Empty;
                                    TxnsEntryType = string.Empty;
                                    CardType = string.Empty;
                                    TxnsDateTimeMain = null;
                                    TxnsPostDateTimeMain = null;



                                    #region ValidateField
                                    if (TxnsDate != "" && TxnsTime != "" && TxnDateTimeFormat.Length > 0)
                                    {
                                        if (TxnsTime.Length < 6 && !TxnsTime.Contains(":"))
                                        {
                                            TxnsTime = TxnsTime.PadLeft(6, '0');
                                        }

                                        TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (PostTxnsDate != "" && PostTxnsTime != "")
                                    {
                                        if (PostTxnsTime.Length < 6 && !PostTxnsTime.Contains(":"))
                                        {
                                            PostTxnsTime = PostTxnsTime.PadLeft(6, '0');
                                        }

                                        TxnsPostDateTimeMain = DateTime.ParseExact(PostTxnsDate + " " + PostTxnsTime, TxnPostDateTimeDateFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnPostDateTimeDateFormat.Length > 0 && TxnsPostDateTime != "")
                                    {
                                        TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnPostDateTimeDateFormat, CultureInfo.InvariantCulture);
                                    }



                                    #endregion ValidateField


                                    #endregion StanderedFields


                                    if (CardNumber != "")
                                    {
                                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                                    }

                                    if (CardNumber != "" && CardNumber.Length == 16)
                                    {
                                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXX" + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();
                                    }
                                    else if (CardNumber != "" && CardNumber.Length == 19)
                                    {
                                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXX" + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();
                                    }

                                    CardType = Common.GetCardType(CardNumber);

                                    if (ToAccount.Any(char.IsLetter))
                                    {
                                        string TempToAccount = Regex.Replace(ToAccount, "[^0-9]", "");
                                        ToAccount = TempToAccount.TrimStart('0');
                                    }
                                    else
                                    {
                                        ToAccount = ToAccount.TrimStart('0');
                                    }

                                    TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                    Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                    DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                    FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";
                                    CustBalance = Common.IsNumeric(CustBalance) ? CustBalance : "0";
                                    InterchangeBalance = Common.IsNumeric(InterchangeBalance) ? InterchangeBalance : "0";
                                    ATMBalance = Common.IsNumeric(ATMBalance) ? ATMBalance : "0";



                                    if (TxnsDateTimeMain != null)
                                    { 
                                        _DataTable.Rows.Add(AcquirerID
                                                , ChannelType
                                                , TerminalID
                                                , ReferenceNumber
                                                , CardNumber.Trim()
                                                , FromAccount
                                                , ToAccount
                                                , InterchangeAccountNo
                                                , ATMAccountNo
                                                , TxnsDateTimeMain
                                                , Convert.ToDecimal(TxnsAmount)
                                                , Convert.ToDecimal(DestinationAmount)
                                                , Convert.ToDecimal(FeeAmount)
                                                , Convert.ToDecimal(Amount1)
                                                , SourceCurrencyCode
                                                , DestinationCurrencyCode
                                                , TxnsStatus
                                                , TxnsType
                                                , TxnsSubType
                                                , TxnsEntryType
                                                , TxnsNumber
                                                , TxnsPerticulars
                                                , DrCrType
                                                , AuthCode
                                                , ProcessingCode
                                                , ResponseCode1
                                                , ResponseCode2
                                                , ReversalCode1
                                                , ReversalCode2
                                                , ReversalFlag
                                                , TxnsPostDateTimeMain
                                                , TxnsValueDateTimeMain
                                                , RevEntryLeg
                                                , Convert.ToDecimal(CustBalance)
                                                , Convert.ToDecimal(InterchangeBalance)
                                                , Convert.ToDecimal(ATMBalance)
                                                , BranchCode
                                                , ReserveField1
                                                , ReserveField2
                                                , ReserveField3
                                                , ReserveField4
                                                , ReserveField5
                                                , ECardNumber.Trim()
                                                , CardType
                                                , NetworkType
                                                );

                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;

                                            MSG = bulkimports.BulkInsertSWITCHTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);
                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }

                                    }
                                }
                                catch (Exception ex)
                                {
                                    ErrorCount++;
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    //_logger.LogInformation("Error At Inserting data into Datatable : {ex} ", ex);
                                }
                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertSWITCHTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        MSG = fileImportRequest.ErrorMessage;
                    }
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                } 
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = 1,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";


            return MSG;
        }
        public string SplitterText_Dynamic(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0, LineNumber = 0 ;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);

            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("AcquirerID", typeof(string));
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("TerminalId", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
            _DataTable.Columns.Add("ATMAccountNo", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("ReversalFlag", typeof(bool));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("CustBalance", typeof(decimal));
            _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
            _DataTable.Columns.Add("ATMBalance", typeof(decimal));
            _DataTable.Columns.Add("BranchCode", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            int Start = 0;
            int End = 0;
            string line1 = string.Empty;
            bool ErrorOccurred = false;

            string TerminalID = string.Empty;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string NoOfDuplicate = string.Empty;
            string ECardNumber = string.Empty;

            string NetworkType = string.Empty;

            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = string.Empty;
            string CardType = string.Empty;
            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;


            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;

            ushort AcquirerID_StartPosition = 0;
            ushort TerminalID_StartPosition = 0;
            ushort ReferenceNumber_StartPosition = 0;
            ushort CardNumber_StartPosition = 0;
            ushort FromAccount_StartPosition = 0;
            ushort ToAccount_StartPosition = 0;
            ushort InterchangeAccountNo_StartPosition = 0;
            ushort ATMAccountNo_StartPosition = 0;
            ushort TxnsDateTime_StartPosition = 0;
            ushort TxnsDate_StartPosition = 0;
            ushort TxnsTime_StartPosition = 0;
            ushort TxnsAmount_StartPosition = 0;
            ushort Amount1_StartPosition = 0;
            ushort DestinationAmount_StartPosition = 0;
            //ushort Amount2_StartPosition = 0;
            //ushort Amount3_StartPosition = 0;

            ushort TxnsSubType_StartPosition = 0;
            ushort ChannelType_StartPosition = 0;
            ushort TxnsNumber_StartPosition = 0;
            ushort TxnsPerticulars_StartPosition = 0;
            ushort DrCrType_StartPosition = 0;
            ushort ResponseCode1_StartPosition = 0;
            ushort ResponseCode2_StartPosition = 0;
            ushort ReversalCode1_StartPosition = 0;
            ushort ReversalCode2_StartPosition = 0;
            ushort TxnsPostDateTime_StartPosition = 0;
            ushort TxnsValueDateTime_StartPosition = 0;
            ushort AuthCode_StartPosition = 0;
            ushort ProcessingCode_StartPosition = 0;
            ushort FeeAmount_StartPosition = 0;
            //ushort CurrencyCode_StartPosition = 0;
            ushort CustBalance_StartPosition = 0;
            ushort InterchangeBalance_StartPosition = 0;
            ushort ATMBalance_StartPosition = 0;
            ushort BranchCode_StartPosition = 0;
            ushort ReserveField1_StartPosition = 0;
            ushort ReserveField2_StartPosition = 0;
            ushort ReserveField3_StartPosition = 0;
            ushort ReserveField4_StartPosition = 0;
            ushort ReserveField5_StartPosition = 0;

            string PostTxnsDate = string.Empty;
            string PostTxnsTime = string.Empty;
            ushort DestinationCurrencyCode_StartPosition = 0;
            ushort SourceCurrencyCode_StartPosition = 0;


            ushort AcquirerID_Length = 0;
            ushort TerminalID_Length = 0;
            ushort ReferenceNumber_Length = 0;
            ushort CardNumber_Length = 0;
            ushort FromAccount_Length = 0;
            ushort ToAccount_Length = 0;
            ushort InterchangeAccountNo_Length = 0;
            ushort ATMAccountNo_Length = 0;
            ushort TxnsDateTime_Length = 0;
            ushort TxnsDate_Length = 0;
            ushort TxnsTime_Length = 0;
            ushort TxnsAmount_Length = 0;
            ushort Amount1_Length = 0;
            ushort DestinationAmount_Length = 0;
            //ushort Amount2_Length = 0;
            //ushort Amount3_Length = 0;

            ushort TxnsSubType_Length = 0;
            ushort ChannelType_Length = 0;
            ushort TxnsNumber_Length = 0;
            ushort TxnsPerticulars_Length = 0;
            ushort DrCrType_Length = 0;
            ushort ResponseCode1_Length = 0;
            ushort ResponseCode2_Length = 0;
            ushort ReversalCode1_Length = 0;
            ushort ReversalCode2_Length = 0;
            ushort TxnsPostDateTime_Length = 0;
            ushort TxnsValueDateTime_Length = 0;
            ushort AuthCode_Length = 0;
            ushort ProcessingCode_Length = 0;
            ushort FeeAmount_Length = 0;
            //ushort CurrencyCode_Length = 0;
            ushort CustBalance_Length = 0;
            ushort InterchangeBalance_Length = 0;
            ushort ATMBalance_Length = 0;
            ushort BranchCode_Length = 0;
            ushort ReserveField1_Length = 0;
            ushort ReserveField2_Length = 0;
            ushort ReserveField3_Length = 0;
            ushort ReserveField4_Length = 0;
            ushort ReserveField5_Length = 0;

            ushort DestinationCurrencyCode_Length = 0;
            ushort SourceCurrencyCode_Length = 0;


            string RevEntryLeg = string.Empty;

            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeDateFormat = null;

            try
            {

                DateTimeConverter objDateTimeConverter = new DateTimeConverter();
                System.Text.RegularExpressions.Regex reNum = new System.Text.RegularExpressions.Regex(@"^\d+$");


                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));


                AcquirerID_StartPosition = Convert.ToUInt16(ds.Tables["AcquirerID"].Rows[0]["StartPosition"]);
                TerminalID_StartPosition = Convert.ToUInt16(ds.Tables["TerminalID"].Rows[0]["StartPosition"]);
                ReferenceNumber_StartPosition = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["StartPosition"]);
                CardNumber_StartPosition = Convert.ToUInt16(ds.Tables["CardNumber"].Rows[0]["StartPosition"]);
                FromAccount_StartPosition = Convert.ToUInt16(ds.Tables["FromAccount"].Rows[0]["StartPosition"]);
                ToAccount_StartPosition = Convert.ToUInt16(ds.Tables["ToAccount"].Rows[0]["StartPosition"]);
                InterchangeAccountNo_StartPosition = Convert.ToUInt16(ds.Tables["InterchangeAccountNo"].Rows[0]["StartPosition"]);
                ATMAccountNo_StartPosition = Convert.ToUInt16(ds.Tables["ATMAccountNo"].Rows[0]["StartPosition"]);
                TxnsDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["StartPosition"]);
                TxnsDate_StartPosition = Convert.ToUInt16(ds.Tables["TxnsDate"].Rows[0]["StartPosition"]);
                TxnsTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsTime"].Rows[0]["StartPosition"]);
                TxnsAmount_StartPosition = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["StartPosition"]);
                Amount1_StartPosition = Convert.ToUInt16(ds.Tables["Amount1"].Rows[0]["StartPosition"]);
                DestinationAmount_StartPosition = Convert.ToUInt16(ds.Tables["DestinationAmount"].Rows[0]["StartPosition"]);

                TxnsSubType_StartPosition = Convert.ToUInt16(ds.Tables["TxnsSubType"].Rows[0]["StartPosition"]);
                ChannelType_StartPosition = Convert.ToUInt16(ds.Tables["ChannelType"].Rows[0]["StartPosition"]);
                TxnsNumber_StartPosition = Convert.ToUInt16(ds.Tables["TxnsNumber"].Rows[0]["StartPosition"]);
                TxnsPerticulars_StartPosition = Convert.ToUInt16(ds.Tables["TxnsPerticulars"].Rows[0]["StartPosition"]);
                DrCrType_StartPosition = Convert.ToUInt16(ds.Tables["DrCrType"].Rows[0]["StartPosition"]);
                ResponseCode1_StartPosition = Convert.ToUInt16(ds.Tables["ResponseCode1"].Rows[0]["StartPosition"]);
                ResponseCode2_StartPosition = Convert.ToUInt16(ds.Tables["ResponseCode2"].Rows[0]["StartPosition"]);
                ReversalCode1_StartPosition = Convert.ToUInt16(ds.Tables["ReversalCode1"].Rows[0]["StartPosition"]);
                ReversalCode2_StartPosition = Convert.ToUInt16(ds.Tables["ReversalCode2"].Rows[0]["StartPosition"]);
                TxnsPostDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsPostDateTime"].Rows[0]["StartPosition"]);
                TxnsValueDateTime_StartPosition = Convert.ToUInt16(ds.Tables["TxnsValueDateTime"].Rows[0]["StartPosition"]);
                AuthCode_StartPosition = Convert.ToUInt16(ds.Tables["AuthCode"].Rows[0]["StartPosition"]);
                ProcessingCode_StartPosition = Convert.ToUInt16(ds.Tables["ProcessingCode"].Rows[0]["StartPosition"]);
                FeeAmount_StartPosition = Convert.ToUInt16(ds.Tables["FeeAmount"].Rows[0]["StartPosition"]);

                CustBalance_StartPosition = Convert.ToUInt16(ds.Tables["CustBalance"].Rows[0]["StartPosition"]);
                InterchangeBalance_StartPosition = Convert.ToUInt16(ds.Tables["InterchangeBalance"].Rows[0]["StartPosition"]);
                ATMBalance_StartPosition = Convert.ToUInt16(ds.Tables["ATMBalance"].Rows[0]["StartPosition"]);
                BranchCode_StartPosition = Convert.ToUInt16(ds.Tables["BranchCode"].Rows[0]["StartPosition"]);
                ReserveField1_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField1"].Rows[0]["StartPosition"]);
                ReserveField2_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField2"].Rows[0]["StartPosition"]);
                ReserveField3_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField3"].Rows[0]["StartPosition"]);
                ReserveField4_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField4"].Rows[0]["StartPosition"]);
                ReserveField5_StartPosition = Convert.ToUInt16(ds.Tables["ReserveField5"].Rows[0]["StartPosition"]);

                AcquirerID_Length = Convert.ToUInt16(ds.Tables["AcquirerID"].Rows[0]["Length"]);
                TerminalID_Length = Convert.ToUInt16(ds.Tables["TerminalID"].Rows[0]["Length"]);
                ReferenceNumber_Length = Convert.ToUInt16(ds.Tables["ReferenceNumber"].Rows[0]["Length"]);
                CardNumber_Length = Convert.ToUInt16(ds.Tables["CardNumber"].Rows[0]["Length"]);
                FromAccount_Length = Convert.ToUInt16(ds.Tables["FromAccount"].Rows[0]["Length"]);
                ToAccount_Length = Convert.ToUInt16(ds.Tables["ToAccount"].Rows[0]["Length"]);
                InterchangeAccountNo_Length = Convert.ToUInt16(ds.Tables["InterchangeAccountNo"].Rows[0]["Length"]);
                ATMAccountNo_Length = Convert.ToUInt16(ds.Tables["ATMAccountNo"].Rows[0]["Length"]);
                TxnsDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsDateTime"].Rows[0]["Length"]);
                TxnsDate_Length = Convert.ToUInt16(ds.Tables["TxnsDate"].Rows[0]["Length"]);
                TxnsTime_Length = Convert.ToUInt16(ds.Tables["TxnsTime"].Rows[0]["Length"]);
                TxnsAmount_Length = Convert.ToUInt16(ds.Tables["TxnsAmount"].Rows[0]["Length"]);
                Amount1_Length = Convert.ToUInt16(ds.Tables["Amount1"].Rows[0]["Length"]);
                DestinationAmount_Length = Convert.ToUInt16(ds.Tables["DestinationAmount"].Rows[0]["Length"]);

                TxnsSubType_Length = Convert.ToUInt16(ds.Tables["TxnsSubType"].Rows[0]["Length"]);
                ChannelType_Length = Convert.ToUInt16(ds.Tables["ChannelType"].Rows[0]["Length"]);
                TxnsNumber_Length = Convert.ToUInt16(ds.Tables["TxnsNumber"].Rows[0]["Length"]);
                TxnsPerticulars_Length = Convert.ToUInt16(ds.Tables["TxnsPerticulars"].Rows[0]["Length"]);
                DrCrType_Length = Convert.ToUInt16(ds.Tables["DrCrType"].Rows[0]["Length"]);
                ResponseCode1_Length = Convert.ToUInt16(ds.Tables["ResponseCode1"].Rows[0]["Length"]);
                ResponseCode2_Length = Convert.ToUInt16(ds.Tables["ResponseCode2"].Rows[0]["Length"]);
                ReversalCode1_Length = Convert.ToUInt16(ds.Tables["ReversalCode1"].Rows[0]["Length"]);
                ReversalCode2_Length = Convert.ToUInt16(ds.Tables["ReversalCode2"].Rows[0]["Length"]);
                TxnsPostDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsPostDateTime"].Rows[0]["Length"]);
                TxnsValueDateTime_Length = Convert.ToUInt16(ds.Tables["TxnsValueDateTime"].Rows[0]["Length"]);
                AuthCode_Length = Convert.ToUInt16(ds.Tables["AuthCode"].Rows[0]["Length"]);
                ProcessingCode_Length = Convert.ToUInt16(ds.Tables["ProcessingCode"].Rows[0]["Length"]);
                FeeAmount_Length = Convert.ToUInt16(ds.Tables["FeeAmount"].Rows[0]["Length"]);

                CustBalance_Length = Convert.ToUInt16(ds.Tables["CustBalance"].Rows[0]["Length"]);
                InterchangeBalance_Length = Convert.ToUInt16(ds.Tables["InterchangeBalance"].Rows[0]["Length"]);
                ATMBalance_Length = Convert.ToUInt16(ds.Tables["ATMBalance"].Rows[0]["Length"]);
                BranchCode_Length = Convert.ToUInt16(ds.Tables["BranchCode"].Rows[0]["Length"]);
                ReserveField1_Length = Convert.ToUInt16(ds.Tables["ReserveField1"].Rows[0]["Length"]);
                ReserveField2_Length = Convert.ToUInt16(ds.Tables["ReserveField2"].Rows[0]["Length"]);
                ReserveField3_Length = Convert.ToUInt16(ds.Tables["ReserveField3"].Rows[0]["Length"]);
                ReserveField4_Length = Convert.ToUInt16(ds.Tables["ReserveField4"].Rows[0]["Length"]);
                ReserveField5_Length = Convert.ToUInt16(ds.Tables["ReserveField5"].Rows[0]["Length"]);

                DestinationCurrencyCode_StartPosition = Convert.ToUInt16(ds.Tables["DestinationCurrencyCode"].Rows[0]["StartPosition"]);
                SourceCurrencyCode_StartPosition = Convert.ToUInt16(ds.Tables["SourceCurrencyCode"].Rows[0]["StartPosition"]);

                DestinationCurrencyCode_Length = Convert.ToUInt16(ds.Tables["DestinationCurrencyCode"].Rows[0]["Length"]);
                SourceCurrencyCode_Length = Convert.ToUInt16(ds.Tables["SourceCurrencyCode"].Rows[0]["Length"]);


                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);
                fileImportRequest.TotalCount = TotalCountArray.Length;

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTimeFormat Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeDateFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);


            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty); 

                            if (TxnsDateTime_Length > 0)
                            {
                                tempTxnDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length).Trim() : string.Empty;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                            else if (TxnsDate_Length > 0 && TxnsTime_Length > 0)
                            {
                                TxnsDate = TxnsDate_StartPosition > 0 && TxnsDate_Length > 0 ? line1.Substring(TxnsDate_StartPosition - Incr, TxnsDate_Length).Trim() : string.Empty;
                                TxnsTime = TxnsTime_StartPosition > 0 && TxnsTime_Length > 0 ? line1.Substring(TxnsTime_StartPosition - Incr, TxnsTime_Length).Trim() : string.Empty;

                                tempTxnDateTime = TxnsDate + " " + TxnsTime;

                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }
                            NetworkType = string.Empty;


                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                if (LineNo < dateStartIndex)
                                {
                                    LineNumber++;
                                    LineNo++;
                                    continue;
                                } 

                                TerminalID = string.Empty;
                                AcquirerID = string.Empty;
                                ReferenceNumber = string.Empty;
                                CardNumber = string.Empty;
                                FromAccount = string.Empty;
                                ToAccount = string.Empty;
                                InterchangeAccountNo = string.Empty;
                                ATMAccountNo = string.Empty;
                                TxnsDateTime = string.Empty;
                                TxnsDate = string.Empty;
                                TxnsTime = string.Empty;
                                TxnsAmount = "0";
                                Amount1 = "0";
                                Amount2 = "0";
                                Amount3 = "0";
                                ChannelType = string.Empty;
                                TxnsSubType = string.Empty;
                                TxnsNumber = string.Empty;
                                TxnsPerticulars = string.Empty;
                                DrCrType = string.Empty;
                                ResponseCode1 = string.Empty;
                                ResponseCode2 = string.Empty;
                                ReversalCode1 = string.Empty;
                                ReversalCode2 = string.Empty;
                                TxnsPostDateTime = string.Empty;
                                TxnsValueDateTime = string.Empty;
                                TxnsDateTimeDiff = string.Empty;
                                AuthCode = string.Empty;
                                ProcessingCode = string.Empty;
                                FeeAmount = "0";
                                CurrencyCode = string.Empty;
                                CustBalance = "0";
                                InterchangeBalance = "0";
                                ATMBalance = "0";
                                DestinationAmount = "0";
                                BranchCode = string.Empty;
                                ReserveField1 = string.Empty;
                                ReserveField2 = string.Empty;
                                ReserveField3 = string.Empty;
                                ReserveField4 = string.Empty;
                                ReserveField5 = string.Empty;
                                NoOfDuplicate = string.Empty;
                                ECardNumber = string.Empty;
                                DestinationCurrencyCode = string.Empty;
                                SourceCurrencyCode = string.Empty;
                                NetworkType = string.Empty;

                                ReversalFlag = false;
                                TxnsStatus = string.Empty;
                                DebitCreditType = string.Empty;
                                TxnsType = string.Empty;
                                TxnsSubTypeMain = string.Empty;
                                TxnsEntryType = string.Empty;
                                CardType = string.Empty;
                                TxnsDateTimeMain = null;
                                TxnsPostDateTimeMain = null;

                                try
                                {
                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }

                                    LineNumber++;

                                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                    AcquirerID = AcquirerID_StartPosition > 0 && AcquirerID_Length > 0 ? line1.Substring(AcquirerID_StartPosition - Incr, AcquirerID_Length).Trim() : string.Empty;
                                    TerminalID = TerminalID_StartPosition > 0 && TerminalID_Length > 0 ? line1.Substring(TerminalID_StartPosition - Incr, TerminalID_Length).Trim() : string.Empty;

                                    ReferenceNumber = ReferenceNumber_StartPosition > 0 && ReferenceNumber_Length > 0 ? line1.Substring(ReferenceNumber_StartPosition - Incr, ReferenceNumber_Length).Trim() : string.Empty;
                                    CardNumber = CardNumber_StartPosition > 0 && CardNumber_Length > 0 ? line1.Substring(CardNumber_StartPosition - Incr, CardNumber_Length).Trim() : string.Empty;
                                    FromAccount = FromAccount_StartPosition > 0 && FromAccount_Length > 0 ? line1.Substring(FromAccount_StartPosition - Incr, FromAccount_Length).Trim() : string.Empty;
                                    ToAccount = ToAccount_StartPosition > 0 && ToAccount_Length > 0 ? line1.Substring(ToAccount_StartPosition - Incr, ToAccount_Length).Trim() : string.Empty;
                                    InterchangeAccountNo = InterchangeAccountNo_StartPosition > 0 && InterchangeAccountNo_Length > 0 ? line1.Substring(InterchangeAccountNo_StartPosition - Incr, InterchangeAccountNo_Length).Trim() : string.Empty;
                                    ATMAccountNo = ATMAccountNo_StartPosition > 0 && ATMAccountNo_Length > 0 ? line1.Substring(ATMAccountNo_StartPosition - Incr, ATMAccountNo_Length).Trim() : string.Empty;

                                    TxnsDateTime = TxnsDateTime_StartPosition > 0 && TxnsDateTime_Length > 0 ? line1.Substring(TxnsDateTime_StartPosition - Incr, TxnsDateTime_Length).Trim() : string.Empty;
                                    TxnsDate = TxnsDate_StartPosition > 0 && TxnsDate_Length > 0 ? line1.Substring(TxnsDate_StartPosition - Incr, TxnsDate_Length).Trim() : string.Empty;
                                    TxnsTime = TxnsTime_StartPosition > 0 && TxnsTime_Length > 0 ? line1.Substring(TxnsTime_StartPosition - Incr, TxnsTime_Length).Trim() : string.Empty;
                                    TxnsAmount = TxnsAmount_StartPosition > 0 && TxnsAmount_Length > 0 ? line1.Substring(TxnsAmount_StartPosition - Incr, TxnsAmount_Length).Trim() : string.Empty;
                                    Amount1 = Amount1_StartPosition > 0 && Amount1_Length > 0 ? line1.Substring(Amount1_StartPosition - Incr, Amount1_Length).Trim() : string.Empty;
                                    DestinationAmount = DestinationAmount_StartPosition > 0 && DestinationAmount_Length > 0 ? line1.Substring(DestinationAmount_StartPosition - Incr, DestinationAmount_Length).Trim() : string.Empty;
                                    FeeAmount = FeeAmount_StartPosition > 0 && FeeAmount_Length > 0 ? line1.Substring(FeeAmount_StartPosition - Incr, FeeAmount_Length).Trim() : string.Empty;

                                    TxnsSubType = TxnsSubType_StartPosition > 0 && TxnsSubType_Length > 0 ? line1.Substring(TxnsSubType_StartPosition - Incr, TxnsSubType_Length).Trim() : string.Empty;
                                    ChannelType = ChannelType_StartPosition > 0 && ChannelType_Length > 0 ? line1.Substring(ChannelType_StartPosition - Incr, ChannelType_Length).Trim() : string.Empty;
                                    TxnsNumber = TxnsNumber_StartPosition > 0 && TxnsNumber_Length > 0 ? line1.Substring(TxnsNumber_StartPosition - Incr, TxnsNumber_Length).Trim() : string.Empty;
                                    TxnsPerticulars = TxnsPerticulars_StartPosition > 0 && TxnsPerticulars_Length > 0 ? line1.Substring(TxnsPerticulars_StartPosition - Incr, TxnsPerticulars_Length).Trim() : string.Empty;
                                    DrCrType = DrCrType_StartPosition > 0 && DrCrType_Length > 0 ? line1.Substring(DrCrType_StartPosition - Incr, DrCrType_Length).Trim() : string.Empty;

                                    ResponseCode1 = ResponseCode1_StartPosition > 0 && ResponseCode1_Length > 0 ? line1.Substring(ResponseCode1_StartPosition - Incr, ResponseCode1_Length).Trim() : string.Empty;
                                    ResponseCode2 = ResponseCode2_StartPosition > 0 && ResponseCode2_Length > 0 ? line1.Substring(ResponseCode2_StartPosition - Incr, ResponseCode2_Length).Trim() : string.Empty;
                                    ReversalCode1 = ReversalCode1_StartPosition > 0 && ReversalCode1_Length > 0 ? line1.Substring(ReversalCode1_StartPosition - Incr, ReversalCode1_Length).Trim() : string.Empty;
                                    ReversalCode2 = ReversalCode2_StartPosition > 0 && ReversalCode2_Length > 0 ? line1.Substring(ReversalCode2_StartPosition - Incr, ReversalCode2_Length).Trim() : string.Empty;
                                    TxnsPostDateTime = TxnsPostDateTime_StartPosition > 0 && TxnsPostDateTime_Length > 0 ? line1.Substring(TxnsPostDateTime_StartPosition - Incr, TxnsPostDateTime_Length).Trim() : string.Empty;
                                    TxnsValueDateTime = TxnsValueDateTime_StartPosition > 0 && TxnsValueDateTime_Length > 0 ? line1.Substring(TxnsValueDateTime_StartPosition - Incr, TxnsValueDateTime_Length).Trim() : string.Empty;

                                    AuthCode = AuthCode_StartPosition > 0 && AuthCode_Length > 0 ? line1.Substring(AuthCode_StartPosition - Incr, AuthCode_Length).Trim() : string.Empty;
                                    ProcessingCode = ProcessingCode_StartPosition > 0 && ProcessingCode_Length > 0 ? line1.Substring(ProcessingCode_StartPosition - Incr, ProcessingCode_Length).Trim() : string.Empty;
                                    //SourceCurrencyCode = SourceCurrencyCode_StartPosition > 0 && SourceCurrencyCode_Length > 0 ? line1.Substring(SourceCurrencyCode_StartPosition - Incr, SourceCurrencyCode_Length).Trim() : string.Empty;
                                    //DestinationCurrencyCode = DestinationCurrencyCode_StartPosition > 0 && DestinationCurrencyCode_Length > 0 ? line1.Substring(DestinationCurrencyCode_StartPosition - Incr, DestinationCurrencyCode_Length).Trim() : string.Empty;

                                    CustBalance = CustBalance_StartPosition > 0 && CustBalance_Length > 0 ? line1.Substring(CustBalance_StartPosition - Incr, CustBalance_Length).Trim() : string.Empty;
                                    InterchangeBalance = InterchangeBalance_StartPosition > 0 && InterchangeBalance_Length > 0 ? line1.Substring(InterchangeBalance_StartPosition - Incr, InterchangeBalance_Length).Trim() : string.Empty;
                                    ATMBalance = ATMBalance_StartPosition > 0 && ATMBalance_Length > 0 ? line1.Substring(ATMBalance_StartPosition - Incr, ATMBalance_Length).Trim() : string.Empty;
                                    BranchCode = BranchCode_StartPosition > 0 && BranchCode_Length > 0 ? line1.Substring(BranchCode_StartPosition - Incr, BranchCode_Length).Trim() : string.Empty;

                                    ReserveField1 = ReserveField1_StartPosition > 0 && ReserveField1_Length > 0 ? line1.Substring(ReserveField1_StartPosition - Incr, ReserveField1_Length).Trim() : string.Empty;
                                    ReserveField2 = ReserveField2_StartPosition > 0 && ReserveField2_Length > 0 ? line1.Substring(ReserveField2_StartPosition - Incr, ReserveField2_Length).Trim() : string.Empty;
                                    ReserveField3 = ReserveField3_StartPosition > 0 && ReserveField3_Length > 0 ? line1.Substring(ReserveField3_StartPosition - Incr, ReserveField3_Length).Trim() : string.Empty;
                                    ReserveField4 = ReserveField4_StartPosition > 0 && ReserveField4_Length > 0 ? line1.Substring(ReserveField4_StartPosition - Incr, ReserveField4_Length).Trim() : string.Empty;
                                    ReserveField5 = ReserveField5_StartPosition > 0 && ReserveField5_Length > 0 ? line1.Substring(ReserveField5_StartPosition - Incr, ReserveField5_Length).Trim() : string.Empty;


                                    if (TxnsDate != "" && TxnsTime != "")
                                    {
                                        TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }


                                    if (TxnPostDateTimeDateFormat[0].ToString() != "" && TxnsPostDateTime != "")
                                    {
                                        TxnsPostDateTimeMain = DateTime.ParseExact(TxnsPostDateTime, TxnPostDateTimeDateFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (CardNumber != "")
                                    {
                                        ECardNumber = AesEncryption.EncryptString(CardNumber);
                                    }

                                    if (CardNumber != "" && CardNumber.Length == 16)
                                    {
                                        CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4).Trim();
                                    }


                                    CardType = Common.GetCardType(CardNumber);

                                    TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                    Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                    DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                    FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";
                                    CustBalance = Common.IsNumeric(CustBalance) ? CustBalance : "0";
                                    InterchangeBalance = Common.IsNumeric(InterchangeBalance) ? InterchangeBalance : "0";
                                    ATMBalance = Common.IsNumeric(ATMBalance) ? ATMBalance : "0";

                                    if (TxnsDateTimeMain != null)
                                    {
                                        _DataTable.Rows.Add(AcquirerID
                                                                , ChannelType
                                                                , TerminalID
                                                                , ReferenceNumber
                                                                , CardNumber.Trim()
                                                                , FromAccount
                                                                , ToAccount
                                                                , InterchangeAccountNo
                                                                , ATMAccountNo
                                                                , TxnsDateTimeMain
                                                                , Convert.ToDecimal(TxnsAmount)
                                                                , Convert.ToDecimal(DestinationAmount)
                                                                , Convert.ToDecimal(FeeAmount)
                                                                , Convert.ToDecimal(Amount1)
                                                                , SourceCurrencyCode
                                                                , DestinationCurrencyCode
                                                                , TxnsStatus
                                                                , TxnsType
                                                                , TxnsSubType
                                                                , TxnsEntryType
                                                                , TxnsNumber
                                                                , TxnsPerticulars
                                                                , DrCrType
                                                                , AuthCode
                                                                , ProcessingCode
                                                                , ResponseCode1
                                                                , ResponseCode2
                                                                , ReversalCode1
                                                                , ReversalCode2
                                                                , ReversalFlag
                                                                , TxnsPostDateTimeMain
                                                                , TxnsValueDateTimeMain
                                                                , RevEntryLeg
                                                                , Convert.ToDecimal(CustBalance)
                                                                , Convert.ToDecimal(InterchangeBalance)
                                                                , Convert.ToDecimal(ATMBalance)
                                                                , BranchCode
                                                                , ReserveField1
                                                                , ReserveField2
                                                                , ReserveField3
                                                                , ReserveField4
                                                                , ReserveField5
                                                                , ECardNumber.Trim()
                                                                , CardType
                                                                , NetworkType
                                                                );

                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;

                                            MSG = bulkimports.BulkInsertSWITCHTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                                            BatchDetails batchDetailsPartial = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetailsPartial);

                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                    ErrorCount++;
                                }
                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex; 

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo++;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertSWITCHTable(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        MSG = fileImportRequest.ErrorMessage;
                    }                  
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;               
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));
            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;

        }
        public string SplitterDelimiter_Dynamic_UPI(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0, LineNumber = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataSet _dataSetUpi = new DataSet();
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsID", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable.Columns.Add("PayerIFSC", typeof(string));
            _DataTable.Columns.Add("PayeeIFSC", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;
            string RevEntryLeg = string.Empty;
            string ChannelType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string TxnsSubType = string.Empty;
            string TxnsStatus = string.Empty;
            string TxnsID = string.Empty;
            string PayerIFSC = string.Empty;
            string PayeeIFSC = string.Empty;

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;


            string NetworkType = string.Empty;

            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;



            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;
            string[] colFields = null;
            string line1 = string.Empty;
            bool ErrorOccurred = false;

            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Amount1_CoulmnIndex = 0;
            ushort DestinationAmount_CoulmnIndex = 0;
            ushort DestinationCurrencyCode_CoulmnIndex = 0;
            ushort SourceCurrencyCode_CoulmnIndex = 0;
            ushort ChannelType_CoulmnIndex = 0;
            ushort TxnsSubType_CoulmnIndex = 0;
            ushort TxnsStatus_CoulmnIndex = 0;
            ushort TxnsPerticulars_CoulmnIndex = 0;
            ushort DrCrType_CoulmnIndex = 0;
            ushort ResponseCode1_CoulmnIndex = 0;
            ushort ResponseCode2_CoulmnIndex = 0;
            ushort ReversalCode1_CoulmnIndex = 0;
            ushort ReversalCode2_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort TxnsValueDateTime_CoulmnIndex = 0;
            ushort AuthCode_CoulmnIndex = 0;
            ushort ProcessingCode_CoulmnIndex = 0;
            ushort FeeAmount_CoulmnIndex = 0;
            ushort TxnsID_CoulmnIndex = 0;

            ushort PayerIFSC_CoulmnIndex = 0;
            ushort PayeeIFSC_CoulmnIndex = 0;

            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;
            ushort ReserveField5_CoulmnIndex = 0;

            int largestIndex = 0, CoulmnIndex = 0;

            try
            {

                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));


                ChannelType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChannelType"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TxnsID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsID"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                DestinationAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationAmount"]);
                FeeAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FeeAmount"]);
                Amount1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount1"]);
                DestinationCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationCurrencyCode"]);
                SourceCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SourceCurrencyCode"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                TxnsSubType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsSubType"]);
                TxnsStatus_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsStatus"]);
                TxnsPerticulars_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPerticulars"]);
                DrCrType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DrCrType"]);
                AuthCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AuthCode"]);
                ProcessingCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ProcessingCode"]);
                TxnsPostDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPostDateTime"]);
                TxnsValueDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsValueDateTime"]);
                ResponseCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode1"]);
                ResponseCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode2"]);
                ReversalCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode1"]);
                ReversalCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode2"]);

                PayerIFSC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerIFSC"]);
                PayeeIFSC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeIFSC"]);

                ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ReserveField3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField3"]);
                ReserveField4_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField4"]);
                ReserveField5_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField5"]);

                if (ds.Tables.Count > 0)
                {
                    for (int x = 0; x < ds.Tables.Count; x++)
                    {
                        foreach (DataRow dr in ds.Tables[x].Rows)
                        {
                            foreach (DataColumn dc in ds.Tables[x].Columns)
                            {
                                CoulmnIndex = Convert.ToInt32(dr[dc.ColumnName]);

                                if (CoulmnIndex > largestIndex)
                                {
                                    largestIndex = CoulmnIndex;
                                }
                            }
                        }
                    }
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTimeFormat Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");

            if (!ErrorOccurred)
            { 
                string tempTxnDateTime = string.Empty;
                //Get Batch Size
                batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                string[] TotalCountArray = File.ReadAllLines(fileImportRequest.Path);

                if (TotalCountArray.Length > 0)
                {
                    int dateStartIndex = -1;
                    int i = 0;

                    foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                    {
                        try
                        {
                            line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                            colFields = new string[0];

                            colFields = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);


                            if (TxnsDateTime_CoulmnIndex > 0)
                            {
                                TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                tempTxnDateTime = TxnsDateTime;
                                bool isValid = DateTime.TryParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                            else if (TxnsDate_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                            {
                                TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                tempTxnDateTime = TxnsDate + " " + TxnsTime;
                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                if (isValid)
                                {
                                    dateStartIndex = i;
                                    break;
                                }
                            }
                        }
                        catch
                        {
                            dateStartIndex = -1;
                        }

                        i++;

                        if (i > 25)
                            break;
                    }

                    if (dateStartIndex > -1)
                    {
                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }


                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            } 

                            foreach (string line in File.ReadAllLines(fileImportRequest.Path))
                            {
                                try
                                {
                                    if (LineNo < dateStartIndex)
                                    {
                                        LineNumber++;
                                        LineNo++;
                                        continue;
                                    }

                                    LineNo++;

                                    if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                    {
                                        continue;
                                    }
                                    line1 = System.Text.RegularExpressions.Regex.Replace(line, "[^ -~]+", string.Empty);

                                    colFields = new string[0];

                                    colFields = line1.Split(new string[] { fileImportRequest.ConfigData.Rows[0]["FileSeparator"].ToString() }, StringSplitOptions.None);

                                    if (colFields.Length < largestIndex) continue;

                                    LineNumber++;

                                    AcquirerID = string.Empty;
                                    ReferenceNumber = string.Empty;
                                    FromAccount = string.Empty;
                                    ToAccount = string.Empty;

                                    TxnsDateTime = string.Empty;
                                    TxnsDate = string.Empty;
                                    TxnsTime = string.Empty;
                                    TxnsAmount = "0";
                                    Amount1 = "0";

                                    ChannelType = string.Empty;
                                    TxnsPerticulars = string.Empty;
                                    DrCrType = string.Empty;
                                    ResponseCode1 = string.Empty;
                                    ResponseCode2 = string.Empty;
                                    ReversalCode1 = string.Empty;
                                    ReversalCode2 = string.Empty;
                                    TxnsPostDateTime = string.Empty;
                                    TxnsValueDateTime = string.Empty;
                                    TxnsDateTimeDiff = string.Empty;
                                    AuthCode = string.Empty;
                                    ProcessingCode = string.Empty;
                                    FeeAmount = "0";
                                    DestinationAmount = "0";
                                    TxnsSubType = string.Empty;
                                    TxnsStatus = string.Empty;
                                    TxnsID = string.Empty;
                                    PayerIFSC = string.Empty;
                                    PayeeIFSC = string.Empty;

                                    ReserveField1 = string.Empty;
                                    ReserveField2 = string.Empty;
                                    ReserveField3 = string.Empty;
                                    ReserveField4 = string.Empty;
                                    ReserveField5 = string.Empty;

                                    DestinationCurrencyCode = string.Empty;
                                    SourceCurrencyCode = string.Empty;
                                    NetworkType = string.Empty;

                                    ChannelType = ChannelType_CoulmnIndex > 0 ? Convert.ToString(colFields[ChannelType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(colFields[ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(colFields[ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsAmount_CoulmnIndex - Incr]) : string.Empty;
                                    Amount1 = Amount1_CoulmnIndex > 0 ? Convert.ToString(colFields[Amount1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DestinationAmount = DestinationAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[DestinationAmount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    TxnsStatus = TxnsStatus_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsStatus_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsID = TxnsID_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsPerticulars = TxnsPerticulars_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsPerticulars_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DrCrType = DrCrType_CoulmnIndex > 0 ? Convert.ToString(colFields[DrCrType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    ResponseCode1 = ResponseCode1_CoulmnIndex > 0 ? Convert.ToString(colFields[ResponseCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ResponseCode2 = ResponseCode2_CoulmnIndex > 0 ? Convert.ToString(colFields[ResponseCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReversalCode1 = ReversalCode1_CoulmnIndex > 0 ? Convert.ToString(colFields[ReversalCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReversalCode2 = ReversalCode2_CoulmnIndex > 0 ? Convert.ToString(colFields[ReversalCode2_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    TxnsValueDateTime = TxnsValueDateTime_CoulmnIndex > 0 ? Convert.ToString(colFields[TxnsValueDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    AuthCode = AuthCode_CoulmnIndex > 0 ? Convert.ToString(colFields[AuthCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ProcessingCode = ProcessingCode_CoulmnIndex > 0 ? Convert.ToString(colFields[ProcessingCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    FeeAmount = FeeAmount_CoulmnIndex > 0 ? Convert.ToString(colFields[FeeAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    SourceCurrencyCode = SourceCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(colFields[SourceCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    DestinationCurrencyCode = DestinationCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(colFields[DestinationCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    PayerIFSC = PayerIFSC_CoulmnIndex > 0 ? Convert.ToString(colFields[PayerIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    PayeeIFSC = PayeeIFSC_CoulmnIndex > 0 ? Convert.ToString(colFields[PayeeIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;

                                    ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;
                                    ReserveField5 = ReserveField5_CoulmnIndex > 0 ? Convert.ToString(colFields[ReserveField5_CoulmnIndex - Incr]).Trim() : string.Empty;


                                    TxnsDateTimeMain = null;
                                    TxnsPostDateTimeMain = null;


                                    if (TxnsDate != "" && TxnsTime != "")
                                    {
                                        if (TxnsTime.Length < 6 && !TxnsTime.Contains(":"))
                                        {
                                            TxnsTime = TxnsTime.PadLeft(6, '0');
                                        }

                                        TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                    {
                                        TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                    }

                                    if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime != "")
                                    {
                                        DateTime dateTime = DateTime.Parse(TxnsPostDateTime);
                                        string formattedDate = dateTime.ToString(TxnPostDateTimeFormat[0]);
                                        TxnsPostDateTimeMain = DateTime.ParseExact(formattedDate, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                                    }


                                    TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                    Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                    DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                    FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";


                                    if (TxnsDateTimeMain != null && ReferenceNumber.Trim().Length > 0)
                                    {

                                        // _logger.LogInformation("Date time Correct : ", TxnsDateTimeMain);

                                        _DataTable.Rows.Add(AcquirerID
                                                , ChannelType
                                                , ReferenceNumber
                                                , TxnsDateTimeMain
                                                , Convert.ToDecimal(TxnsAmount)
                                                , TxnsID
                                                , FromAccount
                                                , ToAccount
                                                , Convert.ToDecimal(DestinationAmount)
                                                , Convert.ToDecimal(FeeAmount)
                                                , Convert.ToDecimal(Amount1)
                                                , SourceCurrencyCode
                                                , DestinationCurrencyCode
                                                , TxnsSubType
                                                , TxnsStatus
                                                , TxnsPerticulars
                                                , DrCrType
                                                , AuthCode
                                                , ProcessingCode
                                                , ResponseCode1
                                                , ResponseCode2
                                                , ReversalCode1
                                                , ReversalCode2
                                                , TxnsPostDateTimeMain
                                                , TxnsValueDateTimeMain
                                                , PayerIFSC
                                                , PayeeIFSC
                                                , ReserveField1
                                                , ReserveField2
                                                , ReserveField3
                                                , ReserveField4
                                                , ReserveField5
                                                , NetworkType
                                                );


                                        if (_DataTable.Rows.Count >= batchSize)
                                        {
                                            BatchNo++;

                                            MSG = bulkimports.BulkInsertSWITCHTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                            fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                            // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                                            BatchDetails batchDetails = new BatchDetails
                                            {
                                                BatchNo = BatchNo,
                                                BatchSize = batchSize,
                                                TxnUploadCount = _DataTable.Rows.Count,
                                                TxnsCount = fileImportRequest.InsertCount,
                                                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                FailedCount = ErrorCount,
                                                BatchStartTime = batchStartTime,
                                                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                            };

                                            batchDetailsList.Add(batchDetails);
                                            _DataTable.Clear();
                                            StartTime = DateTime.Now;
                                            ErrorCount = 0;
                                            if (NewEntry)
                                            {
                                                break;
                                            }
                                        }
                                    }



                                }
                                catch (Exception ex)
                                {
                                    // _logger.LogInformation("Error At Inserting data into Datatable : ", ex);
                                    ErrorCount++;
                                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                }
                            }

                            LineNo = 0;
                        }

                        fileImportRequest.SkippedRows = dateStartIndex;
                        fileImportRequest.TotalCount = LineNumber - dateStartIndex;

                        if (_DataTable.Rows.Count > 0)
                        {
                            BatchNo = BatchNo + 1;

                            fileImportRequest.InsertCount += _DataTable.Rows.Count;

                            MSG = bulkimports.BulkInsertSWITCHTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                        }
                        else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0)
                        {
                            BatchNo++;
                            MSG = "Successful";
                        }
                    }
                    else
                    {
                        BatchNo++;
                        fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                        MSG = fileImportRequest.ErrorMessage;
                    }                   
                }
                else
                {
                    BatchNo++;
                    fileImportRequest.ErrorMessage = "The file is empty or contains no data.";
                    MSG = fileImportRequest.ErrorMessage;
                }
            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails1 = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = ErrorCount,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails1);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";



            return MSG;
        }
        public string SplitterExcel_Dynamic_UPI(FileImportRequest fileImportRequest)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            fileImportRequest.InsertCount = 0;
            fileImportRequest.TotalCount = 0;
            int LineNo = 0;
            int ErrorCount = 0;
            fileImportRequest.ErrorMessage = string.Empty;
            DateTime? FileDateTime = null;
            string MSG = string.Empty;
            int BatchNo = 0;
            int batchSize = 0;
            int BatchStart = 0;
            List<BatchDetails> batchDetailsList = new List<BatchDetails>();
            string BatchDetailString = string.Empty;
            int FailedBatchCount = 0;

            DtDetails DTdetails = new DtDetails();

            BulkImports bulkimports = new BulkImports(_connectionString, AesEncryption.EMEK1, AesEncryption.EMEK2);
            DTdetails = bulkimports.GetdetailsFromDataTable(fileImportRequest.ConfigData, fileImportRequest.FileName);


            DataSet _dataSetUpi = new DataSet();
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ChannelType", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
            _DataTable.Columns.Add("TxnsID", typeof(string));
            _DataTable.Columns.Add("FromAccount", typeof(string));
            _DataTable.Columns.Add("ToAccount", typeof(string));
            _DataTable.Columns.Add("DestinationAmount", typeof(decimal));
            _DataTable.Columns.Add("FeeAmount", typeof(decimal));
            _DataTable.Columns.Add("Amount1", typeof(decimal));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("AuthCode", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode1", typeof(string));
            _DataTable.Columns.Add("ResponseCode2", typeof(string));
            _DataTable.Columns.Add("ReversalCode1", typeof(string));
            _DataTable.Columns.Add("ReversalCode2", typeof(string));
            _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
            _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
            _DataTable.Columns.Add("PayerIFSC", typeof(string));
            _DataTable.Columns.Add("PayeeIFSC", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("NetworkType", typeof(string));

            int Incr = 1;
            string AcquirerID = string.Empty;
            string ReferenceNumber = string.Empty;
            string FromAccount = string.Empty;
            string ToAccount = string.Empty;
            string TxnsDateTime = string.Empty;
            string TxnsDate = string.Empty;
            string TxnsTime = string.Empty;
            string TxnsAmount = "0";
            string Amount1 = "0";
            string DestinationAmount = "0";
            string DestinationCurrencyCode = string.Empty;
            string SourceCurrencyCode = string.Empty;
            string RevEntryLeg = string.Empty;
            string ChannelType = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string TxnsSubType = string.Empty;
            string TxnsStatus = string.Empty;
            string TxnsID = string.Empty;
            string PayerIFSC = string.Empty;
            string PayeeIFSC = string.Empty;

            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;


            string NetworkType = string.Empty;

            DateTime? TxnsDateTimeMain = null;
            DateTime? TxnsPostDateTimeMain = null;
            DateTime? TxnsValueDateTimeMain = null;
            string TxnsDateTimeDiff = string.Empty;



            string[] TxnDateTimeFormat = null;
            string[] TxnPostDateTimeFormat = null;
            string line1 = string.Empty;
            bool ErrorOccurred = false;

            ushort ReferenceNumber_CoulmnIndex = 0;
            ushort FromAccount_CoulmnIndex = 0;
            ushort ToAccount_CoulmnIndex = 0;
            ushort TxnsDateTime_CoulmnIndex = 0;
            ushort TxnsDate_CoulmnIndex = 0;
            ushort TxnsTime_CoulmnIndex = 0;
            ushort TxnsAmount_CoulmnIndex = 0;
            ushort Amount1_CoulmnIndex = 0;
            ushort DestinationAmount_CoulmnIndex = 0;
            ushort DestinationCurrencyCode_CoulmnIndex = 0;
            ushort SourceCurrencyCode_CoulmnIndex = 0;
            ushort ChannelType_CoulmnIndex = 0;
            ushort TxnsSubType_CoulmnIndex = 0;
            ushort TxnsPerticulars_CoulmnIndex = 0;
            ushort DrCrType_CoulmnIndex = 0;
            ushort ResponseCode1_CoulmnIndex = 0;
            ushort ResponseCode2_CoulmnIndex = 0;
            ushort ReversalCode1_CoulmnIndex = 0;
            ushort ReversalCode2_CoulmnIndex = 0;
            ushort TxnsPostDateTime_CoulmnIndex = 0;
            ushort TxnsValueDateTime_CoulmnIndex = 0;
            ushort AuthCode_CoulmnIndex = 0;
            ushort ProcessingCode_CoulmnIndex = 0;
            ushort FeeAmount_CoulmnIndex = 0;
            ushort TxnsID_CoulmnIndex = 0;
            ushort TxnsStatus_CoulmnIndex = 0;
            ushort PayerIFSC_CoulmnIndex = 0;
            ushort PayeeIFSC_CoulmnIndex = 0;

            ushort ReserveField1_CoulmnIndex = 0;
            ushort ReserveField2_CoulmnIndex = 0;
            ushort ReserveField3_CoulmnIndex = 0;
            ushort ReserveField4_CoulmnIndex = 0;
            ushort ReserveField5_CoulmnIndex = 0;

            try
            {
                string LogType = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["VendorType"]);
                string xmlFile = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ColumnsPositionXML"]);

                DataSet ds = new DataSet();
                ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));

                ChannelType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ChannelType"]);
                TxnsStatus_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsStatus"]);
                ReferenceNumber_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReferenceNumber"]);
                TxnsDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDateTime"]);
                TxnsDate_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsDate"]);
                TxnsTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsTime"]);
                TxnsID_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsID"]);
                TxnsAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsAmount"]);
                DestinationAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationAmount"]);
                FeeAmount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FeeAmount"]);
                Amount1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["Amount1"]);
                DestinationCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DestinationCurrencyCode"]);
                SourceCurrencyCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["SourceCurrencyCode"]);
                FromAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["FromAccount"]);
                ToAccount_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ToAccount"]);
                TxnsSubType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsSubType"]);
                TxnsStatus_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsStatus"]);
                TxnsPerticulars_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPerticulars"]);
                DrCrType_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["DrCrType"]);
                AuthCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["AuthCode"]);
                ProcessingCode_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ProcessingCode"]);
                TxnsPostDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsPostDateTime"]);
                TxnsValueDateTime_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["TxnsValueDateTime"]);
                ResponseCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode1"]);
                ResponseCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ResponseCode2"]);
                ReversalCode1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode1"]);
                ReversalCode2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReversalCode2"]);

                PayerIFSC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayerIFSC"]);
                PayeeIFSC_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["PayeeIFSC"]);

                ReserveField1_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField1"]);
                ReserveField2_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField2"]);
                ReserveField3_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField3"]);
                ReserveField4_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField4"]);
                ReserveField5_CoulmnIndex = Convert.ToUInt16(ds.Tables[0].Rows[0]["ReserveField5"]);

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = "TxnDateTimeFormat Format not specified";
                    ErrorOccurred = true;
                }

                if (Convert.ToString(fileImportRequest.ConfigData.Rows[0]["FileDateFormat"]).Length == 0)
                {
                    fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; FileDate Format not specified";
                    ErrorOccurred = true;
                }

                TxnDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);
                TxnPostDateTimeFormat = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["TxnPostDateTimeDateFormat"]).Split(new string[] { "," }, StringSplitOptions.None);

            }
            catch (Exception ex)
            {
                fileImportRequest.ErrorMessage = ex.Message;
                ErrorOccurred = true;
                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
            }

            DateTime StartTime = DateTime.Now;
            string batchStartTime = StartTime.ToString("yyyy-MM-dd HH:mm:ss");
            int SheetDateError = 0;

            if (!ErrorOccurred)
            {
                string tempTxnDateTime = string.Empty;

                try
                {
                    //Get Batch Size
                    batchSize = bulkimports.GetBatchSize(DTdetails.ConfigID);

                    DataTable dtexcelsheetname = new DataTable();
                    DataTable dtSheet = new DataTable();
                    //Read the connection string for the Excel file.
                    string conString = Convert.ToString(fileImportRequest.ConfigData.Rows[0]["ConnectionString"]);

                    conString = string.Format(conString, fileImportRequest.Path);

                    using (OleDbConnection connExcel = new OleDbConnection(conString))
                    {
                        using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                        {
                            connExcel.Open();
                            //Get the name of First Sheet. 
                            dtexcelsheetname = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                            connExcel.Close();
                        }
                    }

                    if (dtexcelsheetname != null && dtexcelsheetname.Rows.Count > 0)
                    { 
                        int j = 0;
                        int SheetLineNumber = 0;

                        foreach (var batchDetail in fileImportRequest.FailedBatches)
                        {
                            if (batchDetail.BatchNo != 0)
                            {
                                BatchNo = batchDetail.BatchNo - 1;
                            }
                            bool NewEntry = false;

                            if (fileImportRequest.FailedBatches.Count() == 1 && batchDetail.TxnsCount == 0 && batchDetail.BatchStatus == "None")
                            {
                                //set the flag if it is new Entry
                                NewEntry = false;
                            }
                            else
                            {
                                if (batchDetail.BatchStatus == "None")
                                {
                                    break;
                                }
                                else
                                {
                                    //set the flag if it is old and  Partial Entry
                                    NewEntry = true;
                                }
                            }


                            foreach (DataRow row in dtexcelsheetname.Rows)
                            {
                                dtSheet = new DataTable();

                                using (OleDbConnection connExcelSheet = new OleDbConnection(conString))
                                {
                                    using (OleDbCommand cmdExcelSheet = new OleDbCommand())
                                    {
                                        using (OleDbDataAdapter odaExcelSheet = new OleDbDataAdapter())
                                        {
                                            try
                                            {
                                                if (Convert.ToString(row["TABLE_NAME"]).EndsWith("$") || Convert.ToString(row["TABLE_NAME"]).EndsWith("$'"))
                                                {
                                                    //Read Data from First Sheet.
                                                    cmdExcelSheet.Connection = connExcelSheet;
                                                    connExcelSheet.Open();
                                                    cmdExcelSheet.CommandText = "SELECT * From [" + Convert.ToString(row["TABLE_NAME"]).Replace("'", "") + "]";
                                                    odaExcelSheet.SelectCommand = cmdExcelSheet;
                                                    odaExcelSheet.Fill(dtSheet);
                                                    connExcelSheet.Close();
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                SheetDateError = 0;
                                                continue;
                                            } 
                                        }
                                    }
                                }

                                Incr = 1;

                                if (dtSheet.Rows.Count > 0)
                                {
                                    // Find first data row based on whether the "Join Date" cell can be parsed as a date
                                    int dateStartIndex = -1;

                                    for (int i = 0; i < dtSheet.Rows.Count; i++)
                                    {
                                        try
                                        {
                                            if (TxnsDateTime_CoulmnIndex > 0)
                                            {
                                                tempTxnDateTime = dtSheet.Rows[i][TxnsDateTime_CoulmnIndex - Incr]?.ToString()?.Trim();
                                               
                                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                                if (isValid)
                                                {
                                                    dateStartIndex = i;
                                                    break;
                                                }
                                            }
                                            else if (TxnsDate_CoulmnIndex > 0 && TxnsTime_CoulmnIndex > 0)
                                            {
                                                tempTxnDateTime = dtSheet.Rows[i][TxnsDate_CoulmnIndex - Incr]?.ToString()?.Trim() + " " + dtSheet.Rows[i][TxnsTime_CoulmnIndex - Incr]?.ToString()?.Trim();

                                                bool isValid = DateTime.TryParseExact(tempTxnDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime tempDate);

                                                if (isValid)
                                                {
                                                    dateStartIndex = i;
                                                    break;
                                                }
                                            }
                                        }
                                        catch
                                        {
                                            SheetDateError++;
                                        }

                                        if (i > 25)
                                            break;
                                    }

                                    if (dateStartIndex > -1)
                                    {
                                        fileImportRequest.TotalCount = fileImportRequest.TotalCount + dtSheet.Rows.Count;

                                        for (int k = 0; k < dtSheet.Rows.Count; k++)
                                        {
                                            LineNo++;
                                            SheetLineNumber++;

                                            if (LineNo < (batchDetail.TxnsCount - batchDetail.TxnUploadCount))
                                            {
                                                continue;
                                            }

                                            try
                                            {

                                                AcquirerID = string.Empty;
                                                ReferenceNumber = string.Empty;
                                                FromAccount = string.Empty;
                                                ToAccount = string.Empty;

                                                TxnsDateTime = string.Empty;
                                                TxnsDate = string.Empty;
                                                TxnsTime = string.Empty;
                                                TxnsAmount = "0";
                                                Amount1 = "0";

                                                ChannelType = string.Empty;
                                                TxnsPerticulars = string.Empty;
                                                TxnsStatus = string.Empty;
                                                DrCrType = string.Empty;
                                                ResponseCode1 = string.Empty;
                                                ResponseCode2 = string.Empty;
                                                ReversalCode1 = string.Empty;
                                                ReversalCode2 = string.Empty;
                                                TxnsPostDateTime = string.Empty;
                                                TxnsValueDateTime = string.Empty;
                                                TxnsDateTimeDiff = string.Empty;
                                                AuthCode = string.Empty;
                                                ProcessingCode = string.Empty;
                                                FeeAmount = "0";
                                                DestinationAmount = "0";
                                                TxnsSubType = string.Empty;
                                                TxnsID = string.Empty;
                                                PayerIFSC = string.Empty;
                                                PayeeIFSC = string.Empty;

                                                ReserveField1 = string.Empty;
                                                ReserveField2 = string.Empty;
                                                ReserveField3 = string.Empty;
                                                ReserveField4 = string.Empty;
                                                ReserveField5 = string.Empty;

                                                DestinationCurrencyCode = string.Empty;
                                                SourceCurrencyCode = string.Empty;
                                                NetworkType = string.Empty;

                                                ChannelType = ChannelType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ChannelType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReferenceNumber = ReferenceNumber_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReferenceNumber_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                FromAccount = FromAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FromAccount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ToAccount = ToAccount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ToAccount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsDateTime = TxnsDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsDate = TxnsDate_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsDate_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsTime = TxnsTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsAmount = TxnsAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsAmount_CoulmnIndex - Incr]) : string.Empty;
                                                Amount1 = Amount1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][Amount1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DestinationAmount = DestinationAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DestinationAmount_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsSubType = TxnsSubType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsSubType_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsID = TxnsID_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsID_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsPerticulars = TxnsPerticulars_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsPerticulars_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsStatus = TxnsStatus_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsStatus_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DrCrType = DrCrType_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DrCrType_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ResponseCode1 = ResponseCode1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ResponseCode2 = ResponseCode2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ResponseCode2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReversalCode1 = ReversalCode1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReversalCode1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReversalCode2 = ReversalCode2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReversalCode2_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                TxnsPostDateTime = TxnsPostDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsPostDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                TxnsValueDateTime = TxnsValueDateTime_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][TxnsValueDateTime_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                AuthCode = AuthCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][AuthCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ProcessingCode = ProcessingCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ProcessingCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                FeeAmount = FeeAmount_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][FeeAmount_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                SourceCurrencyCode = SourceCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][SourceCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                DestinationCurrencyCode = DestinationCurrencyCode_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][DestinationCurrencyCode_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                PayerIFSC = PayerIFSC_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayerIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                PayeeIFSC = PayeeIFSC_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][PayeeIFSC_CoulmnIndex - Incr]).Trim() : string.Empty;

                                                ReserveField1 = ReserveField1_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField1_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField2 = ReserveField2_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField2_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField3 = ReserveField3_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField3_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField4 = ReserveField4_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField4_CoulmnIndex - Incr]).Trim() : string.Empty;
                                                ReserveField5 = ReserveField5_CoulmnIndex > 0 ? Convert.ToString(dtSheet.Rows[k][ReserveField5_CoulmnIndex - Incr]).Trim() : string.Empty;


                                                TxnsDateTimeMain = null;
                                                TxnsPostDateTimeMain = null;


                                                if (TxnsDate != "" && TxnsTime != "")
                                                {
                                                    if (TxnsTime.Length < 6 && !TxnsTime.Contains(":"))
                                                    {
                                                        TxnsTime = TxnsTime.PadLeft(6, '0');
                                                    }

                                                    TxnsDateTimeDiff = TxnsDate + " " + TxnsTime;

                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTimeDiff, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (TxnDateTimeFormat.Length > 0 && TxnsDateTime != "")
                                                {
                                                    TxnsDateTimeMain = DateTime.ParseExact(TxnsDateTime, TxnDateTimeFormat, CultureInfo.InvariantCulture);
                                                }

                                                if (TxnPostDateTimeFormat.Length > 0 && TxnsPostDateTime != "")
                                                {
                                                    DateTime dateTime = DateTime.Parse(TxnsPostDateTime);
                                                    string formattedDate = dateTime.ToString(TxnPostDateTimeFormat[0]);
                                                    TxnsPostDateTimeMain = DateTime.ParseExact(formattedDate, TxnPostDateTimeFormat, CultureInfo.InvariantCulture);
                                                }


                                                TxnsAmount = Common.IsNumeric(TxnsAmount) ? TxnsAmount : "0";
                                                Amount1 = Common.IsNumeric(Amount1) ? Amount1 : "0";
                                                DestinationAmount = Common.IsNumeric(DestinationAmount) ? DestinationAmount : "0";
                                                FeeAmount = Common.IsNumeric(FeeAmount) ? FeeAmount : "0";


                                                if (TxnsDateTimeMain != null && ReferenceNumber.Trim().Length>0)
                                                { 
                                                    _DataTable.Rows.Add(
                                                             ChannelType
                                                            , ReferenceNumber
                                                            , TxnsDateTimeMain
                                                            , Convert.ToDecimal(TxnsAmount)
                                                            , TxnsID
                                                            , FromAccount
                                                            , ToAccount
                                                            , Convert.ToDecimal(DestinationAmount)
                                                            , Convert.ToDecimal(FeeAmount)
                                                            , Convert.ToDecimal(Amount1)
                                                            , SourceCurrencyCode
                                                            , DestinationCurrencyCode
                                                            , TxnsSubType
                                                            , TxnsStatus
                                                            , TxnsPerticulars
                                                            , DrCrType
                                                            , AuthCode
                                                            , ProcessingCode
                                                            , ResponseCode1
                                                            , ResponseCode2
                                                            , ReversalCode1
                                                            , ReversalCode2
                                                            , TxnsPostDateTimeMain
                                                            , TxnsValueDateTimeMain
                                                            , PayerIFSC
                                                            , PayeeIFSC
                                                            , ReserveField1
                                                            , ReserveField2
                                                            , ReserveField3
                                                            , ReserveField4
                                                            , ReserveField5
                                                            , NetworkType
                                                            );


                                                    if (_DataTable.Rows.Count >= batchSize)
                                                    {
                                                        BatchNo++;

                                                        MSG = bulkimports.BulkInsertSWITCHTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);
                                                        fileImportRequest.InsertCount += _DataTable.Rows.Count;
                                                        // _logger.LogInformation("Batch Completed: {BatchNo}", BatchNo);
                                                        BatchDetails batchDetailsPartial = new BatchDetails
                                                        {
                                                            BatchNo = BatchNo,
                                                            BatchSize = batchSize,
                                                            TxnUploadCount = _DataTable.Rows.Count,
                                                            TxnsCount = fileImportRequest.InsertCount,
                                                            BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                                                            FailedCount = ErrorCount,
                                                            BatchStartTime = batchStartTime,
                                                            BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                                        };

                                                        batchDetailsList.Add(batchDetailsPartial);

                                                        _DataTable.Clear();
                                                        StartTime = DateTime.Now;
                                                        ErrorCount = 0;
                                                        if (NewEntry)
                                                        {
                                                            break;
                                                        }
                                                    }
                                                }



                                            }
                                            catch (Exception ex)
                                            {
                                                // _logger.LogInformation("Error At Inserting data into Datatable : ", ex);
                                                ErrorCount++;
                                                DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (j == 0 || _DataTable.Rows.Count == 0)
                                        {
                                            BatchNo++;
                                            fileImportRequest.ErrorMessage = fileImportRequest.ErrorMessage + "; DateTime Format not matched; DateTime Value : " + tempTxnDateTime;
                                            MSG = fileImportRequest.ErrorMessage;
                                        }
                                        break;
                                    }
                                }
                                j++;
                            }
                            LineNo = 0;
                        }
                    }

                    if (_DataTable.Rows.Count > 0)
                    {
                        BatchNo++;

                        fileImportRequest.InsertCount += _DataTable.Rows.Count;

                        MSG = bulkimports.BulkInsertSWITCHTableUPI(_DataTable, DTdetails.ConfigID, fileImportRequest.FileImportID);

                    }
                    else if (_DataTable.Rows.Count == 0 && ErrorCount == 0 && fileImportRequest.TotalCount == 0 && MSG.Length == 0)
                    {
                        BatchNo++;
                        MSG = "Successful";
                    }

                }
                catch (Exception ex)
                {
                    // objLogWriter.FunErrorLog(ex.Message.ToString(), fileImportRequest.ClientCode, "ASP_CBS_Splitter.cs", "SplitData", LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E');
                    DBLog.InsertLogs(ex.Message.ToString(), fileImportRequest.ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, fileImportRequest.FileName, fileImportRequest.UserName, 'E', _connectionString);
                }

            }
            else
            {
                BatchNo++;
                MSG = fileImportRequest.ErrorMessage;
            }

            BatchDetails batchDetails = new BatchDetails
            {
                BatchNo = BatchNo,
                BatchSize = batchSize,
                TxnUploadCount = fileImportRequest.TotalCount,
                TxnsCount = fileImportRequest.InsertCount,
                BatchStatus = MSG == "Successful" ? "Successful" : "partial",
                FailedCount = 1,
                BatchStartTime = batchStartTime,
                BatchEndTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
            };

            batchDetailsList.Add(batchDetails);

            _DataTable = null;

            fileImportRequest.FinalBatchDetails = string.Join(",", batchDetailsList.Select(b => JsonSerializer.Serialize(b)));

            fileImportRequest.FinalBatchDetails = "[" + fileImportRequest.FinalBatchDetails + "]";

            return MSG;
        }
    }


    public enum TxnsChannelID
    {
        ATM = 1,
        POS = 2,
        E_COMMERCE = 3,
        IMPS = 4,
        MICRO_ATM = 5,
        MOBILE_RECHARGE = 6,
        UPI = 7,
        BFS = 12
    }

    public enum TxnsMode
    {
        ONUS = 1,
        ACQUIRER = 2,
        ISSUER = 3,
        INWARD = 4,
        OUTWARD = 5,
        INTRA = 14
    }

}
