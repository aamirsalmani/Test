﻿using ImportData;
using System; 
using System.Data;
using System.Data.OleDb;
using System.Reflection;
using Utility;

namespace SWITCH
{
    public class Bhutan_SWITCH_Splitter
    {
        private readonly string _connectionString;
        public Bhutan_SWITCH_Splitter(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString;
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
        }

        public DataTable BDB_SplitData(string path, string FileName, out int InsertCount, out int TotalCount, string UserName, string ClientID, string RevEntryLeg)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            InsertCount = 0;
            TotalCount = 0;

            DataTable _DataTable = new DataTable();

            int LineNo = 0;
            int ErrorCount = 0;

            string TerminalID = string.Empty;
            string ReferenceNumber = string.Empty;
            string CardNumber = string.Empty;
            string AccountNumber = string.Empty;
            DateTime? TxnsDateTime;
            double Amount;
            string ResponseCode = string.Empty;
            string TxnsType = string.Empty;
            string TxnsSubType = string.Empty;
            string TxnsAgentTypeone = string.Empty;
            string TxnsAgentTypetwo = string.Empty;
            string DATETIME = string.Empty;
            string Reversalcode = string.Empty;

            int ModeID = 0;
            int ChannelID = 0;
            bool ReversalFlag = false;
            string TxnsStatus = string.Empty;
            string DebitCreditType = string.Empty;
            string TxnsSubTypeMain = string.Empty;
            string TxnsEntryType = "Auto";
            string CardType = string.Empty;

            string CustAccountNo = string.Empty;
            string InterchangeAccountNo = string.Empty;
            string ATMAccountNo = string.Empty;

            string Amount1 = "0";
            string Amount2 = "0";
            string Amount3 = "0";
            string ChannelType = string.Empty;
            string TxnsNumber = string.Empty;
            string TxnsPerticulars = string.Empty;
            string DrCrType = string.Empty;
            string ResponseCode1 = string.Empty;
            string ResponseCode2 = string.Empty;
            string ReversalCode1 = string.Empty;
            string ReversalCode2 = string.Empty;
            string TxnsPostDateTime = string.Empty;
            string TxnsValueDateTime = string.Empty;
            string AuthCode = string.Empty;
            string ProcessingCode = string.Empty;
            string FeeAmount = "0";
            string CurrencyCode = string.Empty;
            string CustBalance = "0";
            string InterchangeBalance = "0";
            string ATMBalance = "0";
            string BranchCode = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string NoOfDuplicate = string.Empty;
            string ECardNumber = string.Empty;

            string CommandType = string.Empty;
            string Channel = string.Empty;
            string TransMode = string.Empty;

            
            //

            
            
            
             


            DataTable dtexcelsheetname = null;
            DataTable dtfillsheet1 = new DataTable();
            OleDbConnection objConn = null;
            try
            {
                String connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + path + ";Extended Properties=Excel 8.0;";
                string extension = System.IO.Path.GetExtension(path);
                switch (extension.ToLower())
                {
                    case ".xls": //Excel 97-03
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"HTML Import;HDR=NO;IMEX=1\";";
                        break;
                    case ".xlsx": //Excel 07 or higher
                        connString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=\"Excel 12.0 Xml;HDR=Yes;IMEX=1\";";
                        break;
                }
                objConn = new OleDbConnection(connString);
                objConn.Open();
                dtexcelsheetname = objConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

            }
            catch (Exception ex)
            {
                _DataTable.Rows.Clear();
              //  DBLog.InsertLogs(ex.Message.ToString(), ClientID, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

                //DBLog.InsertLogs(ex.Message.ToString(), ClientID, "Bhutan_SWITCH_Splitter.cs", "BDB_SplitData", 0, FileName, UserName, 'E', _connectionString);
            }


            DateTime? FileDate = null;
            try
            { 
                FileDate = DateTime.ParseExact(FileName.Substring(FileName.IndexOf("TLF") + 1, 10).Trim(), "dd-MM-yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch
            {
                FileDate = DateTime.Now.Date;
            }

            if (dtexcelsheetname.Rows.Count > 1)
            {
                _DataTable.Columns.Add("ClientID", typeof(int));
                _DataTable.Columns.Add("ChannelID", typeof(int));
                _DataTable.Columns.Add("ModeID", typeof(int));
                _DataTable.Columns.Add("TerminalId", typeof(string));
                _DataTable.Columns.Add("ReferenceNumber", typeof(string));
                _DataTable.Columns.Add("CardNumber", typeof(string));
                _DataTable.Columns.Add("CardType", typeof(string));
                _DataTable.Columns.Add("CustAccountNo", typeof(string));
                _DataTable.Columns.Add("InterchangeAccountNo", typeof(string));
                _DataTable.Columns.Add("ATMAccountNo", typeof(string));
                _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
                _DataTable.Columns.Add("TxnsAmount", typeof(decimal));
                _DataTable.Columns.Add("Amount1", typeof(decimal));
                _DataTable.Columns.Add("Amount2", typeof(decimal));
                _DataTable.Columns.Add("Amount3", typeof(decimal));
                _DataTable.Columns.Add("TxnsStatus", typeof(string));
                _DataTable.Columns.Add("TxnsType", typeof(string));
                _DataTable.Columns.Add("TxnsSubType", typeof(string));
                _DataTable.Columns.Add("TxnsEntryType", typeof(string));
                _DataTable.Columns.Add("TxnsNumber", typeof(string));
                _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
                _DataTable.Columns.Add("DrCrType", typeof(string));
                _DataTable.Columns.Add("ResponseCode", typeof(string));
                _DataTable.Columns.Add("ReversalFlag", typeof(bool));
                _DataTable.Columns.Add("TxnsPostDateTime", typeof(DateTime));
                _DataTable.Columns.Add("TxnsValueDateTime", typeof(DateTime));
                _DataTable.Columns.Add("AuthCode", typeof(string));
                _DataTable.Columns.Add("ProcessingCode", typeof(string));
                _DataTable.Columns.Add("FeeAmount", typeof(decimal));
                _DataTable.Columns.Add("CurrencyCode", typeof(string));
                _DataTable.Columns.Add("CustBalance", typeof(decimal));
                _DataTable.Columns.Add("InterchangeBalance", typeof(decimal));
                _DataTable.Columns.Add("ATMBalance", typeof(decimal));
                _DataTable.Columns.Add("BranchCode", typeof(string));
                _DataTable.Columns.Add("ReserveField1", typeof(string));
                _DataTable.Columns.Add("ReserveField2", typeof(string));
                _DataTable.Columns.Add("ReserveField3", typeof(string));
                _DataTable.Columns.Add("ReserveField4", typeof(string));
                _DataTable.Columns.Add("ReserveField5", typeof(string));
                _DataTable.Columns.Add("RevEntryLeg", typeof(string));
                _DataTable.Columns.Add("NoOfDuplicate", typeof(string));
                _DataTable.Columns.Add("FileName", typeof(string));
                _DataTable.Columns.Add("FilePath", typeof(string));
                _DataTable.Columns.Add("FileDate", typeof(DateTime));
                _DataTable.Columns.Add("CreatedOn", typeof(DateTime));
                _DataTable.Columns.Add("ModifiedOn", typeof(DateTime));
                _DataTable.Columns.Add("CreatedBy", typeof(string));
                _DataTable.Columns.Add("ModifiedBy", typeof(string));
                _DataTable.Columns.Add("ECardNumber", typeof(string));
            }

            foreach (DataRow row in dtexcelsheetname.Rows)
            {
                OleDbCommand cmd = new OleDbCommand("SELECT * FROM [" + row["TABLE_NAME"].ToString().Replace("'", "") + "]", objConn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                da.Fill(dtfillsheet1);

                TotalCount = TotalCount + dtfillsheet1.Rows.Count;

                for (int i = 0; i < dtfillsheet1.Rows.Count; i++)
                {

                    LineNo++;
                    TerminalID = string.Empty;
                    ReferenceNumber = string.Empty;
                    CardNumber = string.Empty;
                    CustAccountNo = string.Empty;
                    InterchangeAccountNo = string.Empty;
                    ATMAccountNo = string.Empty;

                    Amount = 0;
                    //Amount1 = "0";
                    //Amount2 = "0";
                    //Amount3 = "0";
                    ChannelType = string.Empty;
                    TxnsSubType = string.Empty;
                    TxnsNumber = string.Empty;
                    TxnsPerticulars = string.Empty;
                    DrCrType = string.Empty;
                    ResponseCode1 = string.Empty;
                    ResponseCode2 = string.Empty;
                    ReversalCode1 = string.Empty;
                    ReversalCode2 = string.Empty;
                    TxnsPostDateTime = string.Empty;
                    TxnsValueDateTime = string.Empty;
                    AuthCode = string.Empty;
                    ProcessingCode = string.Empty;
                    FeeAmount = "0";
                    CurrencyCode = "064";
                    CustBalance = "0";
                    InterchangeBalance = "0";
                    ATMBalance = "0";
                    BranchCode = string.Empty;
                    ReserveField1 = string.Empty;
                    ReserveField2 = string.Empty;
                    ReserveField3 = string.Empty;
                    ReserveField4 = string.Empty;
                    ReserveField5 = string.Empty;
                    NoOfDuplicate = string.Empty;
                    ECardNumber = string.Empty;

                    CommandType = string.Empty;
                    Channel = string.Empty;
                    TransMode = string.Empty; 
                    TxnsDateTime = null;

                    try
                    {

                        CommandType = dtfillsheet1.Rows[i][0].ToString().Trim();
                        Channel = dtfillsheet1.Rows[i][1].ToString().Trim();
                        TransMode = dtfillsheet1.Rows[i][2].ToString().Trim();
                        TxnsSubType = dtfillsheet1.Rows[i][3].ToString();
                        Reversalcode = dtfillsheet1.Rows[i][4].ToString();
                        ProcessingCode = dtfillsheet1.Rows[i][4].ToString();
                        Amount = Convert.ToDouble(dtfillsheet1.Rows[i][5].ToString());
                        CardNumber = dtfillsheet1.Rows[i][6].ToString().Trim();
                        TxnsNumber = dtfillsheet1.Rows[i][7].ToString().Trim();
                        TxnsDateTime = Convert.ToDateTime(dtfillsheet1.Rows[i][8].ToString());
                        ReferenceNumber = dtfillsheet1.Rows[i][11].ToString();
                        AuthCode = dtfillsheet1.Rows[i][12].ToString();
                        ResponseCode = dtfillsheet1.Rows[i][13].ToString();
                        TerminalID = dtfillsheet1.Rows[i][14].ToString();
                       
                        CustAccountNo = dtfillsheet1.Rows[i][16].ToString().Trim(); 
                        TxnsStatus = dtfillsheet1.Rows[i][19].ToString();

                        ReserveField2 = dtfillsheet1.Rows[i][15].ToString().Trim();
                        ReserveField3 = dtfillsheet1.Rows[i][9].ToString().Trim();
                        ReserveField4 = dtfillsheet1.Rows[i][10].ToString().Trim();
                        ReserveField5 = dtfillsheet1.Rows[i][18].ToString().Trim();

                        TxnsPerticulars = TransMode;

                        if (CardNumber != "")
                        {
                            if (CardNumber.Substring(0, 1) == "4")
                            {
                                CardType = "VISA";
                            }
                            else if (CardNumber.Substring(0, 2) == "51" || CardNumber.Substring(0, 2) == "52" || CardNumber.Substring(0, 2) == "53" || CardNumber.Substring(0, 2) == "54" || CardNumber.Substring(0, 2) == "55")
                            {
                                CardType = "MASTER";
                            }
                            else if (CardNumber.Substring(0, 2) == "62")
                            {
                                CardType = "CUP";
                            }
                            else if (CardNumber.Substring(0, 2) == "60" || CardNumber.Substring(0, 2) == "65" || CardNumber.Substring(0, 2) == "81" || CardNumber.Substring(0, 2) == "82" || CardNumber.Substring(0, 3) == "508" || CardNumber.Substring(0, 3) == "353" || CardNumber.Substring(0, 3) == "356")
                            {
                                CardType = "RuPay";
                            }
                            else if (CardNumber.Substring(0, 2) == "50" || CardNumber.Substring(0, 2) == "56" || CardNumber.Substring(0, 2) == "57" || CardNumber.Substring(0, 2) == "58" || CardNumber.Substring(0, 1) == "6")
                            {
                                CardType = "Maestro";
                            }

                             ECardNumber = AesEncryption.EncryptString(CardNumber); 
                        }

                        if (Channel == "ATM")
                        {
                            ChannelID = (int)TxnsChannelID.ATM;
                        }
                        else if (Channel == "BFS")
                        {
                            ChannelID = (int)TxnsChannelID.ATM;
                        }

                        if (TransMode == "ONUS")
                        {
                            ModeID = 1;
                        }
                        if (TransMode == "ACQUIRER")
                        {
                            ModeID = 2;
                        }
                        if (TransMode == "ISSUER")
                        {
                            ModeID = 3;
                        }

                        if (TxnsStatus == "Reversal")
                        {
                            ReversalFlag = true;
                        }
                        else  
                        {
                            ReversalFlag = false;
                        }

                        TxnsType = "Financial";

                    }
                    catch
                    {
                        ErrorCount++;
                    }

                    //_DataTable.Rows.Add(TerminalID, ReferenceNumber, CardNumber, AccountNumber, TxnsDateTime, ResponseCode, Amount, TxnsType, TxnsSubType, Reversalcode, System.DateTime.Now, System.DateTime.Now, UserName, UserName);
                    if (TxnsDateTime != null)
                    {
                        _DataTable.Rows.Add(ClientID
                                        , ChannelID
                                        , ModeID
                                        , TerminalID
                                        , ReferenceNumber
                                        , CardNumber.Trim()
                                        , CardType
                                        , CustAccountNo
                                        , InterchangeAccountNo
                                        , ATMAccountNo
                                        , TxnsDateTime
                                        , Convert.ToDecimal(Amount)
                                        , Amount1
                                        , Amount2
                                        , Amount3
                                        , TxnsStatus
                                        , TxnsType
                                        , TxnsSubType
                                        , TxnsEntryType
                                        , TxnsNumber
                                        , TxnsPerticulars
                                        , DebitCreditType
                                        , ResponseCode
                                        , ReversalFlag
                                        , null
                                        , null
                                        , AuthCode
                                        , ProcessingCode
                                        , Convert.ToDecimal(FeeAmount)
                                        , CurrencyCode
                                        , Convert.ToDecimal(CustBalance)
                                        , Convert.ToDecimal(InterchangeBalance)
                                        , Convert.ToDecimal(ATMBalance)
                                        , BranchCode
                                        , Channel
                                        , ReserveField2
                                        , ReserveField3
                                        , ReserveField4
                                        , ReserveField5
                                        , RevEntryLeg
                                        , 0
                                        , FileName
                                        , path
                                        , FileDate
                                        , DateTime.Now
                                        , null
                                        , UserName
                                        , null
                                        , ECardNumber.Trim()
                                        );

                        InsertCount++;
                    }

                }

            }

            if (_DataTable.Rows.Count == 0)
            {
                //Utility.DBLog.InsertLogs("Transaction not found", ClientID, "Bhutan_SWITCH_Splitter.cs", "BDB_SplitData", LineNo, FileName, UserName, 'E', _connectionString);
            } 

            return _DataTable;
        }
    }
}
