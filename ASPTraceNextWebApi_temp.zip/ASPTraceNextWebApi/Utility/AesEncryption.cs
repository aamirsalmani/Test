﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Utility
{
    public static class AesEncryption
    {
        private const int AesKeySize = 32; // 256 bits
        private const int IvSize = 16;     // AES block size is 128 bits
        private static readonly byte[] FixedIV = new byte[16];
        public static string EMEK1 { get; set; } = string.Empty;
        public static string EMEK2 { get; set; } = string.Empty;

        public static string EncryptString(string plainText) =>
            EncryptWithTwoMeks(plainText, EMEK1, EMEK2);

        public static string DecryptString(string cipherText) =>
            DecryptWithTwoMeks(cipherText, EMEK1, EMEK2);

        private static Aes CreateAes(byte[] key, byte[]? iv = null)
        {
            if (key.Length != AesKeySize)
                throw new ArgumentException("Key must be 256 bits (32 bytes).");

            var aes = Aes.Create();
            aes.Key = key;
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;
            if (iv != null)
                aes.IV = iv;
            return aes;
        }

        public static string EncryptWithTwoMeks(string plainText, string mek1, string mek2)
        {
            var firstEncryption = Encrypt(plainText, mek1);
            return Encrypt(firstEncryption, mek2);
        }

        public static string DecryptWithTwoMeks(string cipherText, string mek1, string mek2)
        {
            var firstDecryption = Decrypt(cipherText, mek2);
            return Decrypt(firstDecryption, mek1);
        }

        private static string Encrypt(string plainText, string base64Key)
        {
            var key = Convert.FromBase64String(base64Key);
            var plainBytes = Encoding.UTF8.GetBytes(plainText);

            using var aes = CreateAes(key, FixedIV); // use fixed IV
            using var encryptor = aes.CreateEncryptor();
            var cipherBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

            // For deterministic encryption, no need to prepend IV
            return Convert.ToBase64String(cipherBytes);
        }

        private static string Decrypt(string cipherText, string base64Key)
        {
            var cipherBytes = Convert.FromBase64String(cipherText);
            var key = Convert.FromBase64String(base64Key);

            using var aes = CreateAes(key, FixedIV); // use same fixed IV
            using var decryptor = aes.CreateDecryptor();

            var plainBytes = decryptor.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);
            return Encoding.UTF8.GetString(plainBytes);
        }

        public static string EncryptUsingSHA2Algorithm(string input)
        {
            var bytes = Encoding.Unicode.GetBytes(input);
            using var sha256 = SHA256.Create();
            var hash = sha256.ComputeHash(bytes);
            return Convert.ToBase64String(hash);
        }

        public static string RandomStringGenerator()
        {
            const string specialSymbols = "~!@#$%^&*()_+|}{:?><`-\\=][';/.,";
            const string alphabets = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

            using var rng = RandomNumberGenerator.Create();
            var numberBytes = new byte[2];
            int number;

            do
            {
                rng.GetBytes(numberBytes);
                number = BitConverter.ToUInt16(numberBytes, 0) % 100;
            } while (number >= alphabets.Length);

            int secondDigit = number % 10;
            var selectedChar = alphabets[number];
            var selectedSymbol = specialSymbols.Substring(secondDigit, Math.Min(2, specialSymbols.Length - secondDigit));

            return DateTime.Now.ToString("yyddHHMMss") + secondDigit + selectedChar + selectedSymbol;
        }
    }
}