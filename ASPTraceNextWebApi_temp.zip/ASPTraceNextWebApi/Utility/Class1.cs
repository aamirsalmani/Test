﻿namespace Utility
{
    public class Class1
    {

    }
}
