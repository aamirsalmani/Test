﻿using System;
using System.Data;

namespace Utility
{
    public class Common
    {
        public static int GetIndex(string[] aryLines, int StartIndex, string searchStr)
        {
            int idx = -1;
            try
            {
                if (aryLines != null && aryLines.Length > 0)
                {
                    bool found = false;
                    for (idx = StartIndex; idx < aryLines.Length; idx++)
                    {
                        if (aryLines[idx].Contains(searchStr))
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        idx = -1;
                }
            }
            catch { }
            return idx;
        }

        public static string RemoveAdditionalChars(string input)
        {
            input = input.Trim().ToUpper();
            string pattern = "\\s+";
            string replacement = " ";
            System.Text.RegularExpressions.Regex rgx = new System.Text.RegularExpressions.Regex(pattern);
            string result = rgx.Replace(input, replacement);
            return result;
        }

        public static string ConvertStringArrayToString(string[] array)
        {
            // Concatenate all the elements into a StringBuilder.
            System.Text.StringBuilder builder = new System.Text.StringBuilder();
            foreach (string value in array)
            {
                builder.Append(value);
                //builder.Append('.');
            }
            return builder.ToString();
        }

        public static decimal ExtractDecimal(string @this)
        {
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i < @this.Length; i++)
            {
                if (Char.IsDigit(@this[i]) || @this[i] == '.')
                {
                    if (sb.Length == 0 && i > 0 && @this[i - 1] == '-')
                    {
                        sb.Append('-');
                    }
                    sb.Append(@this[i]);
                }
            }

            return Convert.ToDecimal(sb.ToString());
        }

        public static bool IsNumeric(string str)
        {
            return double.TryParse(str, out _);
        }

        public static string GetCardType(string CardNumber)
        {
            string CardType = string.Empty;

            if (!string.IsNullOrEmpty(CardNumber))
            {
                int.TryParse(CardNumber.Substring(0, 6), out int firstSixDigits); // Parse first 6 digits as integer
                int.TryParse(CardNumber.Substring(0, 4), out int firstFourDigits); // Parse first 4 digits as integer
                int.TryParse(CardNumber.Substring(0, 2), out int firstTwoDigits);  // Parse first 2 digits as integer
                int.TryParse(CardNumber.Substring(0, 1), out int firstDigit);      // Parse first digit as integer

                if (firstDigit == 4)
                {
                    CardType = "VISA";
                }
                else if ((firstTwoDigits >= 51 && firstTwoDigits <= 55) || (firstFourDigits >= 2221 && firstFourDigits <= 2720))
                {
                    CardType = "MASTER";
                }
                else if (firstTwoDigits == 62)
                {
                    CardType = "CUP";
                }
                else if (firstTwoDigits == 60 || firstTwoDigits == 65 || firstTwoDigits == 81 || firstTwoDigits == 82 ||
                         (firstSixDigits >= 508000 && firstSixDigits <= 508999) ||
                         (firstSixDigits >= 353000 && firstSixDigits <= 353999) ||
                         (firstSixDigits >= 356000 && firstSixDigits <= 356999))
                {
                    CardType = "RuPay";
                }
                else if (firstTwoDigits == 50 || (firstTwoDigits >= 56 && firstTwoDigits <= 58) || firstDigit == 6)
                {
                    CardType = "Maestro";
                }
                else if (firstTwoDigits == 35)
                {
                    CardType = "JCB";
                }
                else
                {
                    CardType = string.Empty; // Unknown card type
                }
            }

            return CardType;
        }

        public static DataTable GetCassetteInfoByTerminalId(string connectionString, string ClientID, string TerminalID)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter odaCard = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        connExcel.Open();
                        cmd.CommandText = "uspCassetteInfoByTerminalId_Core";
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = ClientID;
                        cmd.Parameters.AddWithValue("@TerminalID", SqlDbType.VarChar).Value = TerminalID;

                        odaCard.SelectCommand = cmd;
                        odaCard.Fill(dt);
                        connExcel.Close();
                    }
                }
            }
            return dt;
        }

        public static DataSet GetCardNetwork(string connectionString)
        {
            DataSet ds = new DataSet();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter odaCard = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        connExcel.Open();
                        cmd.CommandText = "spGetCardNetwork";
                        cmd.CommandType = CommandType.StoredProcedure;
                        odaCard.SelectCommand = cmd;
                        odaCard.Fill(ds);
                        connExcel.Close();
                    }
                }
            }

            return ds;
        }

        public static DataTable GetEncryptedDEK(string connectionString)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter odaDEK = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        connExcel.Open();
                        cmd.CommandText = "GetEncryptedDEK";
                        cmd.CommandType = CommandType.StoredProcedure;
                        odaDEK.SelectCommand = cmd;
                        odaDEK.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }


        public static DataTable GetBOBInfoByTerminalId(string connectionString, string ClientID, string TerminalID)
        {
            DataTable dt = new DataTable();

            using (System.Data.SqlClient.SqlConnection connExcel = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {
                    using (System.Data.SqlClient.SqlDataAdapter odaCard = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        cmd.Connection = connExcel;
                        connExcel.Open();
                        cmd.CommandText = "SpBOBTerminalMaster";
                        cmd.CommandType = CommandType.StoredProcedure;



                        cmd.Parameters.AddWithValue("@ClientID", SqlDbType.Int).Value = ClientID;
                        cmd.Parameters.AddWithValue("@TerminalID", SqlDbType.VarChar).Value = TerminalID;



                        odaCard.SelectCommand = cmd;
                        odaCard.Fill(dt);
                        connExcel.Close();
                    }
                }
            }

            return dt;
        }


        public static int GetValue(string input)  //Sidd
        {
            string[] parts = input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string numericPart = parts.Length > 1 ? parts[1].TrimStart('0') : "0";
            return int.TryParse(numericPart, out int value) ? value : 0;
        }

    }

    public enum TxnsMode
    {
        ONUS = 1,
        ACQUIRER = 2,
        ISSUER = 3,
        INWARD = 4,
        OUTWARD = 5,
        INTRA = 14
    }

    public enum TxnsChannelID
    {
        ATM = 1,
        POS = 2,
        E_COMMERCE = 3,
        IMPS = 4,
        MICRO_ATM = 5,
        MOBILE_RECHARGE = 6,
        UPI = 7,
        NEFT=15,
        RTGS=16,
        BBPS=17
    }

    public class BatchDetails
    {
        public int BatchNo { get; set; }
        public int BatchSize { get; set; }
        public int TxnUploadCount { get; set; }
        public int TxnsCount { get; set; }
        public string BatchStatus { get; set; }
        public int FailedCount { get; set; }
        public string BatchStartTime { get; set; }
        public string BatchEndTime { get; set; }

    }

    public class DtDetails
    {
        public DateTime? FileDateTime { get; set; }
        public string ConfigID { get; set; }
    }

}
