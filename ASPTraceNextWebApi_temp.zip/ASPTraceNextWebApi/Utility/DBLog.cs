﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Utility
{
    public class DBLog
    {
        public static void InsertLogs(string Msg, string ClientCode, string MachineIp,string className, string FunctionName, int Lineno, string Filename, string UserName, char LogType, string connectionString)
        {
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand())
                {

                    cmd.Parameters.AddWithValue("@LogType", LogType);
                    cmd.Parameters.AddWithValue("@ClientCode", ClientCode);
                    cmd.Parameters.AddWithValue("@MachineIP", MachineIp);
                    cmd.Parameters.AddWithValue("@ClassName", className);
                    cmd.Parameters.AddWithValue("@Description", Msg);
                    cmd.Parameters.AddWithValue("@UploadFilename", Filename);
                    cmd.Parameters.AddWithValue("@LineNo", Lineno);
                    cmd.Parameters.AddWithValue("@MethodName", FunctionName);
                    cmd.Parameters.AddWithValue("@UploadBy", UserName);

                    cmd.CommandText = "UspInsertLogs";
                    cmd.Connection = connection;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    connection.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

    }
}
