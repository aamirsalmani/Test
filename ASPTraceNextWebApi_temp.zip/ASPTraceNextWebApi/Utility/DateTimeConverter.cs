﻿using System; 
 

namespace Utility
{
    public class DateTimeConverter
    {
        LogWriter objLogWriter = new LogWriter();
        public DateTime ConvertToDateTime(string FormatString, string DateTimeString)
        {
            DateTime rtDateTime = new DateTime();
            try
            {

                string MM = string.Empty;
                string dd = string.Empty;
                string HH = "00";
                string mm = "00";
                string ss = "00";
                string HHmmss = string.Empty;
                string FullTime = "00";
                string yyyyHHmmss = string.Empty;
                string yyyy = string.Empty; 

                string[] splitFormatString = FormatString.Split(new string[] { "/", ".", "-", ":", " " }, StringSplitOptions.None);
                string[] splitDateTimeString = DateTimeString.Split(new string[] { "/", ".", "-", ":", " " }, StringSplitOptions.None);

                for (int i = 0; i < splitFormatString.Length; i++)
                {
                    if (splitFormatString[i].ToString() == "yyyy")
                    {
                        yyyy = splitDateTimeString[i].ToString();
                    }
                    if (splitFormatString[i].ToString() == "yy")
                    {
                        yyyy = "20" + splitDateTimeString[i].ToString();
                    }

                    if (splitFormatString[i].ToString() == "MM")
                    {
                        MM = splitDateTimeString[i].ToString();
                    }

                    if (splitFormatString[i].ToString() == "MMM")
                    {
                        int month = DateTime.ParseExact(splitDateTimeString[i].ToString(), "MMM",  System.Globalization.CultureInfo.CurrentCulture).Month;
                        MM = month.ToString();
                    }
                    if (splitFormatString[i].ToString() == "M")
                    {
                        MM = splitDateTimeString[i].ToString();
                    }

                    if (splitFormatString[i].ToString() == "dd")
                    {
                        dd = splitDateTimeString[i].ToString();
                    }

                    if (splitFormatString[i].ToString() == "HH")
                    {
                        HH = splitDateTimeString[i].ToString();
                    }
                    if (splitFormatString[i].ToString() == "hh")
                    {
                        HH = splitDateTimeString[i].ToString();
                    }
                    if (splitFormatString[i].ToString() == "mm")
                    {
                        mm = splitDateTimeString[i].ToString();
                    }
                    if (splitFormatString[i].ToString() == "ss")
                    {
                        ss = splitDateTimeString[i].ToString();
                    }
                    if (splitFormatString[i].ToString() == "HHmmss")
                    {
                        HHmmss = splitDateTimeString[i].ToString();
                        FullTime = HHmmss.Substring(0, 2).ToString();
                    }

                    if (splitFormatString[i].ToString() == "yyyyHHmmss")
                    {
                        yyyyHHmmss = splitDateTimeString[i].ToString();
                    }

                }


                for (int i = 0; i < splitFormatString.Length; i++)
                {

                    if (splitFormatString[i].ToString() == "MM" && splitDateTimeString[i].ToString().Length < 2)
                    {
                        MM = "0" + splitDateTimeString[i].ToString();
                    }
                    if (splitFormatString[i].ToString() == "MMM" && MM.ToString().Length < 2)
                    {
                        MM = "0" + MM;//splitDateTimeString[i].ToString();
                    }

                    if (splitFormatString[i].ToString() == "dd" && splitDateTimeString[i].ToString().Length < 2)
                    {
                        dd = "0" + splitDateTimeString[i].ToString();
                    }

                    if (splitFormatString[i].ToString() == "HH" && splitDateTimeString[i].ToString().Length < 2)
                    {
                        HH = "0" + splitDateTimeString[i].ToString();
                    }
                    if (splitFormatString[i].ToString() == "hh" && splitDateTimeString[i].ToString().Length < 2)
                    {
                        HH = "0" + splitDateTimeString[i].ToString();
                    }
                    if (splitFormatString[i].ToString() == "mm" && splitDateTimeString[i].ToString().Length < 2)
                    {
                        mm = "0" + splitDateTimeString[i].ToString();
                    }

                    if (splitFormatString[i].ToString() == "ss" && splitDateTimeString[i].ToString().Length < 2)
                    {
                        ss = "0" + splitDateTimeString[i].ToString();
                    }

                }

                if (ss == "")
                {
                    ss = "00";
                }
                if ((int.Parse(HH) <= 12) && (int.Parse(FullTime) <= 12))
                {
                    if (HHmmss != "")
                    {
                        rtDateTime = DateTime.ParseExact(dd + MM + yyyy + HHmmss, "ddMMyyyyhhmmss", System.Globalization.CultureInfo.InvariantCulture);
                    }
                    else if (yyyyHHmmss != "")
                    {
                        rtDateTime = DateTime.ParseExact(dd + MM + yyyyHHmmss, "ddMMyyyyhhmmss",  System.Globalization.CultureInfo.InvariantCulture);
                    }
                    else
                    {
                        rtDateTime = DateTime.ParseExact(dd + MM + yyyy + HH + mm + ss, "ddMMyyyyhhmmss",  System.Globalization.CultureInfo.InvariantCulture);
                    }

                }
                else
                {
                    if (HHmmss != "")
                    {
                        rtDateTime = DateTime.ParseExact(dd + MM + yyyy + HHmmss, "ddMMyyyyHHmmss",  System.Globalization.CultureInfo.InvariantCulture);
                    }
                    else
                    {
                        rtDateTime = DateTime.ParseExact(dd + MM + yyyy + HH + mm + ss, "ddMMyyyyHHmmss",  System.Globalization.CultureInfo.InvariantCulture);
                    }
                }

            }
            catch (Exception ex)
            {

                objLogWriter.FunErrorLog(ex.Message.ToString(), "MDD", "DateTimeConverter.cs", "ConvertToDateTime", 0, "", "Admin", 'E');
            }

            return rtDateTime;
        }

        public DateTime ConvertToDateTimeAMPM(string FormatString, string DateTimeString)
        {
            DateTime rtDateTime1 = new DateTime();
            try
            {

                string MM = string.Empty;
                string dd = string.Empty;
                string HH = "00";
                string mm = "00";
                Int32 PMHH;
                string ss = "00";
                string HHmmss = string.Empty;
                string FullTime = "00";

                string yyyy = string.Empty; 

                string[] splitFormatString = FormatString.Split(new string[] { "/", ".", "-", ":", " " }, StringSplitOptions.None);
                string[] splitDateTimeString = DateTimeString.Split(new string[] { "/", ".", "-", ":", " " }, StringSplitOptions.None);
                if (splitDateTimeString[01] == "" || splitDateTimeString[03] == "")
                {
                    DateTimeString = DateTimeString.Replace("  ", ".");
                    splitDateTimeString = DateTimeString.Split(new string[] { "/", ".", "-", ":", " " }, StringSplitOptions.None);
                }
               
                if (DateTimeString.Contains("PM") || DateTimeString.Contains("pm"))
                {

                    for (int i = 0; i < splitFormatString.Length; i++)
                    {
                        if (splitFormatString[i].ToString() == "yyyy")
                        {
                            yyyy = splitDateTimeString[i].ToString();
                        }
                        if (splitFormatString[i].ToString() == "yy")
                        {
                            yyyy = "20" + splitDateTimeString[i].ToString();
                        }

                        if (splitFormatString[i].ToString() == "MM")
                        {
                            MM = splitDateTimeString[i].ToString();
                        }

                        if (splitFormatString[i].ToString() == "MMM")
                        {
                            int month = DateTime.ParseExact(splitDateTimeString[i].ToString(), "MMM",  System.Globalization.CultureInfo.CurrentCulture).Month;
                            MM = month.ToString();
                        }

                        if (splitFormatString[i].ToString() == "dd")
                        {
                            dd = splitDateTimeString[i].ToString();
                        }

                        if (splitFormatString[i].ToString() == "HH")
                        {
                            HH = splitDateTimeString[i].ToString();
                        }
                        if (splitFormatString[i].ToString() == "hh")
                        {
                            HH = splitDateTimeString[i].ToString();
                        }
                        if (splitFormatString[i].ToString() == "mm")
                        {
                            mm = splitDateTimeString[i].ToString();
                            if (mm.Length > 2)
                            {
                                mm = mm.Substring(0, 2);
                            }
                        }
                        if (splitFormatString[i].ToString() == "ss")
                        {
                            ss = splitDateTimeString[i].ToString();
                        }
                        if (splitFormatString[i].ToString() == "HHmmss")
                        {
                            HHmmss = splitDateTimeString[i].ToString();
                            FullTime = HHmmss.Substring(0, 2).ToString();
                        }

                    }


                    for (int i = 0; i < splitFormatString.Length; i++)
                    {

                        if (splitFormatString[i].ToString() == "MM" && splitDateTimeString[i].ToString().Length < 2)
                        {
                            MM = "0" + splitDateTimeString[i].ToString();
                        }
                        if (splitFormatString[i].ToString() == "MMM" && MM.ToString().Length < 2)
                        {
                            MM = "0" + MM;//splitDateTimeString[i].ToString();
                        }

                        if (splitFormatString[i].ToString() == "dd" && splitDateTimeString[i].ToString().Length < 2)
                        {
                            dd = "0" + splitDateTimeString[i].ToString();
                        }

                        if (splitFormatString[i].ToString() == "HH" && splitDateTimeString[i].ToString().Length <= 2)
                        {
                            if (splitDateTimeString[i].ToString() == "12")
                            {
                                HH = splitDateTimeString[i].ToString();

                            }
                            else
                            {
                                string HH1 = splitDateTimeString[i].ToString();
                                HH = (int.Parse(HH1) + 12).ToString();
                            }

                        }
                        if (splitFormatString[i].ToString() == "hh" && splitDateTimeString[i].ToString().Length <= 2)
                        {
                            string HH1 = "0" + splitDateTimeString[i].ToString();
                            PMHH = (int.Parse(HH1) + 12);
                        }
                        if (splitFormatString[i].ToString() == "mm" && splitDateTimeString[i].ToString().Length < 2)
                        {
                            mm = "0" + splitDateTimeString[i].ToString();
                        }

                        if (splitFormatString[i].ToString() == "ss" && splitDateTimeString[i].ToString().Length < 2)
                        {
                            ss = "0" + splitDateTimeString[i].ToString();
                        }

                    }

                    if (ss == "")
                    {
                        ss = "00";
                    }
                    if ((int.Parse(HH) <= 12) && (int.Parse(FullTime) <= 12))
                    {
                        if (HHmmss != "")
                        {
                            rtDateTime1 = DateTime.ParseExact(dd + MM + yyyy + HHmmss, "ddMMyyyyhhmmss",  System.Globalization.CultureInfo.InvariantCulture);
                        }
                        else
                        {
                            try
                            {
                                rtDateTime1 = DateTime.ParseExact(dd + "/" + MM + "/" + yyyy + " " + HH + ":" + mm + ":" + ss, "dd/MM/yyyy HH:mm:ss",  System.Globalization.CultureInfo.InvariantCulture);
                            }
                            catch (Exception)
                            {

                                rtDateTime1 = DateTime.ParseExact(dd + MM + yyyy + HH + mm + ss, "ddMMyyyyhhmmss",  System.Globalization.CultureInfo.InvariantCulture);
                            }
                            //rtDateTime1 = DateTime.ParseExact(dd + MM + yyyy + HH + mm + ss, "ddMMyyyyhhmmss",  System.Globalization.CultureInfo.InvariantCulture);

                        }

                    }
                    else
                    {
                        if (HHmmss != "")
                        {
                            rtDateTime1 = DateTime.ParseExact(dd + MM + yyyy + HHmmss, "ddMMyyyyHHmmss",  System.Globalization.CultureInfo.InvariantCulture);
                        }
                        else
                        {

                            rtDateTime1 = DateTime.ParseExact(dd + "/" + MM + "/" + yyyy + " " + HH + ":" + mm + ":" + ss, "dd/MM/yyyy HH:mm:ss",  System.Globalization.CultureInfo.InvariantCulture);

                        }
                    }
                }



            }
            catch (Exception ex)
            {

                objLogWriter.FunErrorLog(ex.Message.ToString(), "MDD", "DateTimeConverter.cs", "ConvertToDateTime", 0, "", "Admin", 'E');
            }

            return rtDateTime1;
        }

        //public DateTime ConvertToDateTime(string FormatString, string DateTimeString)
        //{
        //    DateTime rtDateTime = new DateTime();
        //    try
        //    {

        //        string MM = string.Empty;
        //        string dd = string.Empty;
        //        string HH = "00";
        //        string mm = "00";
        //        string ss = "00";
        //        string yyyy = string.Empty;
        //        string input2 = "2017.12.20 1:11:36";
        //        string input1 = "yyyy/MM/dd HH:mm:ss";
        //        string[] splitFormatString = FormatString.Split(new string[] { "/", ".", "-", ":", " " }, StringSplitOptions.None);
        //        string[] splitDateTimeString = DateTimeString.Split(new string[] { "/", ".", "-", ":", " " }, StringSplitOptions.None);

        //        for (int i = 0; i < splitFormatString.Length; i++)
        //        {
        //            if (splitFormatString[i].ToString() == "yyyy")
        //            {
        //                yyyy = splitDateTimeString[i].ToString();
        //            }
        //            if (splitFormatString[i].ToString() == "yy")
        //            {
        //                yyyy = "20" + splitDateTimeString[i].ToString();
        //            }

        //            if (splitFormatString[i].ToString() == "MM")
        //            {
        //                MM = splitDateTimeString[i].ToString();
        //            }

        //            if (splitFormatString[i].ToString() == "MMM")
        //            {
        //                int month = DateTime.ParseExact(splitDateTimeString[i].ToString(), "MMM",  System.Globalization.CultureInfo.CurrentCulture).Month;
        //                MM = month.ToString();
        //            }

        //            if (splitFormatString[i].ToString() == "dd")
        //            {
        //                dd = splitDateTimeString[i].ToString();
        //            }

        //            if (splitFormatString[i].ToString() == "HH")
        //            {
        //                HH = splitDateTimeString[i].ToString();
        //            }
        //            if (splitFormatString[i].ToString() == "hh")
        //            {
        //                HH = splitDateTimeString[i].ToString();
        //            }
        //            if (splitFormatString[i].ToString() == "mm")
        //            {
        //                mm = splitDateTimeString[i].ToString();
        //            }
        //            if (splitFormatString[i].ToString() == "ss")
        //            {
        //                ss = splitDateTimeString[i].ToString();
        //            }

        //        }


        //        for (int i = 0; i < splitFormatString.Length; i++)
        //        {

        //            if (splitFormatString[i].ToString() == "MM" && splitDateTimeString[i].ToString().Length < 2)
        //            {
        //                MM = "0" + splitDateTimeString[i].ToString();
        //            }
        //            if (splitFormatString[i].ToString() == "MMM" && MM.ToString().Length < 2)
        //            {
        //                MM = "0" + MM;//splitDateTimeString[i].ToString();
        //            }

        //            if (splitFormatString[i].ToString() == "dd" && splitDateTimeString[i].ToString().Length < 2)
        //            {
        //                dd = "0" + splitDateTimeString[i].ToString();
        //            }

        //            if (splitFormatString[i].ToString() == "HH" && splitDateTimeString[i].ToString().Length < 2)
        //            {
        //                HH = "0" + splitDateTimeString[i].ToString();
        //            }
        //            if (splitFormatString[i].ToString() == "hh" && splitDateTimeString[i].ToString().Length < 2)
        //            {
        //                HH = "0" + splitDateTimeString[i].ToString();
        //            }
        //            if (splitFormatString[i].ToString() == "mm" && splitDateTimeString[i].ToString().Length < 2)
        //            {
        //                mm = "0" + splitDateTimeString[i].ToString();
        //            }

        //            if (splitFormatString[i].ToString() == "ss" && splitDateTimeString[i].ToString().Length < 2)
        //            {
        //                ss = "0" + splitDateTimeString[i].ToString();
        //            }

        //        }

        //        if (ss == "")
        //        {
        //            ss = "00";
        //        }
        //        if (int.Parse(HH) <= 12)
        //        {
        //            rtDateTime = DateTime.ParseExact(dd + MM + yyyy + HH + mm + ss, "ddMMyyyyhhmmss",  System.Globalization.CultureInfo.InvariantCulture);
        //        }
        //        else
        //        {
        //            rtDateTime = DateTime.ParseExact(dd + MM + yyyy + HH + mm + ss, "ddMMyyyyHHmmss",  System.Globalization.CultureInfo.InvariantCulture);
        //        }

        //    }
        //    catch (Exception ex)
        //    {

        //        objLogWriter.FunErrorLog(ex.Message.ToString(), "MDD", "DateTimeConverter.cs", "ConvertToDateTime", 0, "", "Admin", 'E');
        //    }

        //    return rtDateTime;
        //}



    }
}
