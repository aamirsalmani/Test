﻿using System;
using System.Data;
using HtmlAgilityPack;

namespace Utility
{ 
    public class HtmlExcelReader
    {
        public static DataTable ReadHtmlExcel(string filePath, int sheetIndex = 1)
        {
            DataTable dt = new DataTable($"Sheet{sheetIndex}");

            HtmlDocument doc = new HtmlDocument
            {
                OptionFixNestedTags = true,   // try to auto-close unclosed tags
                OptionAutoCloseOnEnd = true,  // close open tags at EOF
                OptionCheckSyntax = true      // try to correct bad HTML
            };

            doc.Load(filePath);

            var tables = doc.DocumentNode.SelectNodes("//table");
            if (tables == null || tables.Count < sheetIndex)
                return dt;

            var rows = tables[sheetIndex - 1].SelectNodes("./tr");
            if (rows == null) return dt;

            int MaxCellsCount = 0;

            foreach (var row in rows)
            {
                var cells = row.SelectNodes("th|td");

                if (cells != null && cells.Count > MaxCellsCount)
                {
                    MaxCellsCount = cells.Count;
                }
            }

            bool headerAdded = false;

            // Create columns dynamically (all as string)
            for (int i = 0; i < MaxCellsCount; i++)
            {
                dt.Columns.Add("Column" + (i + 1), typeof(string));
            }

            foreach (var row in rows)
            {
                var cells = row.SelectNodes("th|td");
                if (cells == null) continue;

                DataRow dr = dt.NewRow();
                for (int i = 0; i < cells.Count; i++)
                {
                    dr[i] = cells[i].InnerText.Trim().Replace("'", "");
                }
                dt.Rows.Add(dr);

            }

            return dt;
        }
    }

}
