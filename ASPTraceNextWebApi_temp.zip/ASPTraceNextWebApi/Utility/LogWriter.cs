﻿using System; 
using System.IO;
using System.Net;

namespace Utility
{
    public class LogWriter
    {
        public string strAppPath = string.Empty;
        public StreamWriter oWrite;
        object obj = new object();
        static string MachineName = string.Empty;
        static string IP = string.Empty;
        public void Info()
        {
            try
            {
                MachineName = System.Environment.MachineName;// + " " + System.Net.Dns.GetHostName()
            }
            catch (Exception)
            {
                MachineName = "Unable to get machine name";
            }
            try
            {
                IP = GetIP();
            }
            catch
            {
                IP = "Unable to get machine IP";
            }
        }

        private string GetIP()
        {
            string strHostName = "";
            strHostName = System.Net.Dns.GetHostName();
            IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            return addr[addr.Length - 1].ToString();
        }
        #region Write Error into Log File
        public string CreateFileDirectry(string filepath)
        {
            if (!Directory.Exists(filepath))
            {
                Directory.CreateDirectory(filepath);
            }
            return filepath;
        }

        public void FunErrorLog(string Msg, string ClientCode, string FormName, string FunctionName, int Lineno, string Filename, string UserName, char LogType)
        {

            string path = string.Empty;
            if (LogType == 'T')
            {
                //path = Server.MapPath("~/TraceLogs/" + ClientCode + "/" + DateTime.Now.Year.ToString() + "/" + DateTime.Today.ToString("MMM") + "/");
                path= Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\TraceLogs\\", ClientCode + "\\" + DateTime.Now.Year.ToString() + "\\" + DateTime.Today.ToString("MMM") + "\\");
            }
            if (LogType == 'E')
            {
                //path = Server.MapPath("~/ErrorLogs/" + ClientCode + "/" + DateTime.Now.Year.ToString() + "/" + DateTime.Today.ToString("MMM") + "/");
                path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot\\ErrorLogs\\", ClientCode + "\\" + DateTime.Now.Year.ToString() + "\\" + DateTime.Today.ToString("MMM") + "\\");
            }

            if (!File.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            string Filepath = path + "Log_" + DateTime.Today.ToString("dd-MM-yy") + ".txt";

            StreamWriter sw = new StreamWriter(Filepath, true);
            try
            {
                lock (obj)
                {
                    Info();
                    sw.WriteLine(string.Format("Client Code: {0} Machine: {1}-{2}", ClientCode, MachineName, IP));
                    sw.WriteLine("Description : " + Msg);
                    sw.WriteLine(string.Format("Filename: {0} Line NO: {1}", Filename, Lineno));
                    sw.WriteLine("Function : " + FunctionName);
                    sw.WriteLine("Form : " + FormName);
                    sw.WriteLine("Login Name: " + UserName + " At : " + String.Format("Time : {0} {1}", DateTime.Now.ToString("dd-MMM-yyyy"), DateTime.Now.ToShortTimeString()));
                    sw.WriteLine("-------------****-----------------");
                }
            }
            catch (Exception ex)
            {
                sw.WriteLine(string.Format("Bank Code: {0} Machine: {1}-{2}", ClientCode, MachineName, IP));
                sw.WriteLine("Description : " + ex.Message.ToString());
                sw.WriteLine(string.Format("Filename: {0} Line NO: {1}", Filename, Lineno));
                sw.WriteLine("Function : FunErrorLog");
                sw.WriteLine("Form : LogWriter");
                sw.WriteLine("Login Name: " + UserName + " At : " + String.Format("Time : {0} {1}", DateTime.Now.ToString("dd-MMM-yyyy"), DateTime.Now.ToShortTimeString()));
                sw.WriteLine("-------------****-----------------");
            }
            finally
            {
                sw.Flush();
                sw.Close();
            }
        }

        #endregion
    }
}
