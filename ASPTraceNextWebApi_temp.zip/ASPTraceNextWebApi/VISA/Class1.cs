﻿namespace VISA
{
    public class Class1
    {

    }
}
